char F2C_version[] = "20010821";
char xxxvers[] = "\n@(#) FORTRAN 77 to C Translator, VERSION 20010821\n";
