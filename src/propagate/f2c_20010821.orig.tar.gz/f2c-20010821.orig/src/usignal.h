#include <signal.h>
#ifndef SIGHUP
#define	SIGHUP	1	/* hangup */
#endif
#ifndef SIGQUIT
#define	SIGQUIT	3	/* quit */
#endif
