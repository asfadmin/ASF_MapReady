Installing argtable2 on unix systems
------------------------------------
The basic compile and install procedure for unix systems is:

    $ ./configure
    $ make
    $ make check (optional)
    $ su
    # make install
    # exit
    $ make installcheck (optional)
    $ make clean

Remember to update your system's LD_LIBRARY_PATH to include
/usr/local/lib/ (the install location of the dynamic library)
otherwise your applications wont be able to find it and
consequently "make installcheck" will fail.

The configuration script will install argtable into /usr/local/
by default. To install into a different directory, specify
that directory path when you run configure, as in

    $ ./configure --prefix=~fred/mystuff                                    

See install.txt for a detailed description of the configure script.

Caveats:
   1) "make check" does not work on Mac OS X because it is lacking
      a static version of libcrt0.
   2) Mac OS X uses DYLD_LIBRARY_PATH instead of LD_LIBRARY_PATH.
   3) DJGPP users may need to specify the compiler name at configure
      time, as in "./configure CC=gcc.exe"

    

Installing argtable2 on DOS/Windows systems
-------------------------------------------
To build argtable.lib         :

    > cd src
    > nmake -f Makefile.nmake

Then copy the argtable2.h, argtable2.lib, argtable2.dll, impargtable2.lib
files to wherever you choose.

To build the example programs:
    
    > cd example
    > nmake -f Makefile.nmake

