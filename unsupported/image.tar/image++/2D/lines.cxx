#include "main.h"
#include "object.h"
#include "buffer2D.h"
void buffer2D::lineTo(int fromX,int fromY,int toX,int toY,long toWhat)
{
#define minX 10
#define minY 10
	register int maxX=wid-1-minX;
	register int maxY=height-1-minY;
	register int state=((fromX<minX)<<13)|((fromX>maxX)<<12)|((toX<minX)<<9)|((toX>maxX)<<8)|
	          ((fromY<minY)<<5 )|((fromY>maxY)<<4 )|((toY<minY)<<1)| (toY>maxY);
	         
	if (state!=0)
	{
		int loopCount=0;
		#define bitsSet(b) ((state&(b))==(b))
		#define eitherSet(b) ((state&(b))!=0)
		if (bitsSet(0x2200)||bitsSet(0x1100)||bitsSet(0x0022)||bitsSet(0x0011))
			return; /*Both Coords off-- trivial return.*/
		Bool slopeXexists=True,slopeYexists=True;
		double_t slopeX,interceptX;
		double_t slopeY,interceptY;
		if (fromX-toX)
		{
			slopeX=((double_t)(fromY-toY))/(fromX-toX);
			interceptX=fromY-slopeX*fromX;
		} else slopeXexists=False;
		if (fromY-toY)
		{
			slopeY=((double_t)(fromX-toX))/(fromY-toY);
			interceptY=fromX-slopeY*fromY;
		} else slopeYexists=False;
		do
		{
			loopCount++;
			if (eitherSet(0x3000))
			{
				fromX=bitsSet(0x2000)?minX:maxX;
				if (slopeXexists)
				{
					fromY=slopeX*fromX+interceptX;
					state=(state&0x0f0f)|((fromY<minY)<<5 )|((fromY>maxY)<<4 );
				} else state&=0x0fff;
			}
			if (eitherSet(0x0300))
			{
				toX=bitsSet(0x0200)?minX:maxX;
				if (slopeXexists)
				{
					toY=slopeX*toX+interceptX;
					state=(state&0xf0f0)|((toY<minY)<<1 )| (toY>maxY);
				} else state&=0xf0ff;
			}
			if (eitherSet(0x0030))
			{
				fromY=bitsSet(0x0020)?minY:maxY;
				if (slopeYexists)
				{
					fromX=slopeY*fromY+interceptY;
					state=(state&0x0f0f)|((fromX<minX)<<13)|((fromX>maxX)<<12);
				} else state&=0xff0f;
			}
			if (eitherSet(0x0003))
			{
				toY=bitsSet(0x0002)?minY:maxY;
				if (slopeYexists)
				{
					toX=slopeY*toY+interceptY;
					state=(state&0xf0f0)|((toX<minX)<<9)|((toX>maxX)<<8);
				} else state&=0xfff0;
			}
		}
		while ((loopCount<2)&&(state!=0));
		
		if ((fromX==toX)&&(fromY==toY)) return;
		
		if (loopCount>=2) return;
		
		if ((fromX<minX)|(fromX>maxX)|(toX<minX)|(toX>maxX)|
	                (fromY<minY)|(fromY>maxY)|(toY<minY)|(toY>maxY))
	              	debugger();/*Out-of-bounds pixel detected.*/
	}
	fixLineTo((long(fromX))<<16,(long(fromY))<<16,(long(toX))<<16,(long(toY))<<16,toWhat);
}
void buffer2D::fixLineTo(long fromX,long fromY,long toX,long toY,long toWhat)
{
#define order(a,b) if (a>b) {short temp=a;a=b;b=temp;}
	short fromx=fromX>>16,fromy=fromY>>16,tox=toX>>16,toy=toY>>16;
	long dx=tox-fromx,dy=toy-fromy;
	register char *theAddr;
	if (abs(dx)>abs(dy))
	{//go by x's
		short start=fromx,end=tox;
		if (end-start)
		{
			long outx,outY=fromY,multAdd=(toY-fromY)/(end-start);
			if (start>end)
				{short temp=start;start=end;end=temp;outY=toY;}
			switch(depthBytes)
			{
			case 1:
				for (outx=start;outx<=end;outx++)
				{
					theAddr=(char *)(lineStarts[outY>>16]+outx);
					*(char *)theAddr=toWhat;
					outY+=multAdd;
				}
				break;
			case 2:
				for (outx=start;outx<=end;outx++)
				{
					theAddr=(char *)(lineStarts[outY>>16]+outx*2);
					*(short *)theAddr=toWhat;
					outY+=multAdd;
				}
				break;
			case 4:
				for (outx=start;outx<=end;outx++)
				{
					theAddr=(char *)(lineStarts[outY>>16]+outx*4);
					*(long *)theAddr=toWhat;
					outY+=multAdd;
				}
				break;
			}
		}
	} else {//go by y's
		long start=fromy,end=toy;
		if (end-start)
		{
			long outy,outX=fromX,multAdd=(toX-fromX)/(end-start);
			if (start>end)
				{short temp=start;start=end;end=temp;outX=toX;}
			theAddr=(char *)(lineStarts[start]);
			switch(depthBytes)
			{
			case 1:
				for (outy=start;outy<=end;outy++)
				{
					*(char *)(theAddr+(outX>>16))=toWhat;
					theAddr+=rowBytes;
					outX+=multAdd;
				}
				break;
			case 2:
				for (outy=start;outy<=end;outy++)
				{
					*(short *)(theAddr+((outX>>15)&(~0x1)))=toWhat;
					theAddr+=rowBytes;
					outX+=multAdd;
				}
				break;
			case 4:
				for (outy=start;outy<=end;outy++)
				{
					*(long *)(theAddr+((outX>>14)&(~0x3)))=toWhat;
					theAddr+=rowBytes;
					outX+=multAdd;
				}
				break;
			}
		}
	}
}