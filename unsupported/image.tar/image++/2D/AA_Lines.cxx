#include "MyUnivHeader.h"
#endif
const float fixConv=65536;
void blendPixel(short *toBlend,long val,long proportion);//0- all source; 1- all val;
void blendPixel(short *toBlend,long val,long proportion)
{
#define useTable 1
#if useTable
	static unsigned char *table=nil;
	if (!table)
	{
		table=(unsigned char *)defAlloc(32L*32*8);
		for (int blendStrength=0;blendStrength<8;blendStrength++)
		{
			int bsByTen=blendStrength<<10;
			float bsMul=float(blendStrength)/float(7);
			for (int v=0;v<32;v++)
				for (int s=0;s<32;s++)
				{
					table[bsByTen+(v<<5)+s]=v+bsMul*(s-v);
				}
		}	
	}
	register unsigned int prop=(proportion>>13)<<10;
	register unsigned int redV=0x1f&(val>>10),greenV=0x1f&(val>>5),blueV=0x1f&val;
	register unsigned int src=*toBlend;
	register unsigned int redS=0x1f&(src>>10),greenS=0x1f&(src>>5),blueS=0x1f&src;
	*toBlend=(table[prop+(redV<<5)+redS]<<10)
			+(table[prop+(greenV<<5)+greenS]<<5)
			 +table[prop+(blueV<<5)+blueS];
#else
	register double prop=float(proportion)/float(65536);
	register unsigned int redV=0x1f&(val>>10),greenV=0x1f&(val>>5),blueV=0x1f&val;
	register unsigned int src=*toBlend;
	register unsigned int redS=0x1f&(src>>10),greenS=0x1f&(src>>5),blueS=0x1f&src;
	register unsigned int red=redV+prop*(redS-redV),
						  green=greenV+prop*(greenS-greenV),
						  blue=blueV+prop*(blueS-blueV);
	*toBlend=(red<<10)+(green<<5)+blue;
#endif
}
void buffer2D::aaLineTo(long fromX,long fromY,long toX,long toY,long toWhat)
{
	int fromx=fromX>>16,fromy=fromY>>16,tox=toX>>16,toy=toY>>16;
	long dx=abs(tox-fromx),dy=abs(toy-fromy);
	register char *theAddr;
	float multAddRl;
	long start,end,multAdd;
	if (dx>dy)
	{//go by x's
		start=fromx;end=tox;
		if (abs(end-start)>1)
		{
			multAddRl=float(toY-fromY)/float(toX-fromX);
			multAdd=fixConv*multAddRl;
			long outY=fromY+((start<<16)-fromX)*multAddRl;
			if (start>end)
				{int temp=start;start=end;end=temp;outY=toY+((start<<16)-toX)*multAddRl;}
			for (long outx=start;outx<=end;outx++)
			{
				theAddr=(char *)(baseAddr+lineStarts[outY>>16]+(outx<<1));
				blendPixel((short *)(theAddr),toWhat,0xffff&outY);
				blendPixel((short *)(theAddr+rowBytes),toWhat,0xffff-(0xffff&outY));
				outY+=multAdd;
			}
		}
	} else {//go by y's
		start=fromy;end=toy;
		if (abs(end-start)>1)
		{
			float multAddRl=float(toX-fromX)/float(toY-fromY);
			long multAdd=fixConv*multAddRl;
			long outX=fromX+((start<<16)-fromY)*multAddRl;
			if (start>end)
				{int temp=start;start=end;end=temp;outX=toX+((start<<16)-toY)*multAddRl;}
			theAddr=(char *)(baseAddr+lineStarts[start]);
			for (long outy=start;outy<=end;outy++)
			{
				blendPixel((short *)(theAddr+((outX>>16)<<1)),toWhat,0xffFF&outX);
				blendPixel((short *)(theAddr+((outX>>16)<<1)+2),toWhat,0xffFF-(0xffFF&outX));
				theAddr+=rowBytes;
				outX+=multAdd;
			}
		}
	}
}