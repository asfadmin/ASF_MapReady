#include "main.h"
#include "object.h"
#include "buffer2D.h"

void buffer2D::fill(long color)
{
	register double colorDouble=expand64(color);
	register int doublesPerLine=wid*depthBytes/sizeof(double);
	register int extraBytes=wid*depthBytes-doublesPerLine*sizeof(double);
	register double *outPtr;
	register int y,x;
	for (y=0;y<height;y++)
	{
		outPtr=(double *)(baseAddr+y*rowBytes)-1;
		for (x=0;x<doublesPerLine;x++)
			*(++outPtr)=colorDouble;
		if (extraBytes)
		{
			char *colorChar=(char *)&colorDouble;
			char *outPtr2=(char *)(outPtr+1);
			for (x=0;x<extraBytes;x++)
				*outPtr2++=*colorChar++;
		}
	}
}

double buffer2D::expand64(long color)
{
	double outVal;
	int i;
	char *buf=(char *)&outVal;
	switch(depthBytes)
	{
		case 1:
			for (i=0;i<8;i++)
				buf[i]=color;
			break;
		case 2:
			*(short *)(&buf[0])=color;
			*(short *)(&buf[2])=color;
			*(short *)(&buf[4])=color;
			*(short *)(&buf[6])=color;
			break;
		case 4:
			*(long *)(&buf[0])=color;
			*(long *)(&buf[4])=color;
			break;
	}
	return outVal;
}
