#include "main.h"
#include "object.h"
#include "buffer2D.h"
	
void buffer2D::init3(int sizeX, int sizeY, int Ndepth)
{
	init0();
	if ((sizeX<1)||(sizeY<1))
	{
		fprintf(stderr,"Internal Error: illegal size %ix%i passed to buffer2D::init.\n",sizeX,sizeY);
		exit(1);
	}
	frame.top=frame.left=0;
	wid=sizeX;
	height=sizeY;
	switch(Ndepth)
	{
		case 1:
		case 2:
		case 4:
		case 8:
			depth=Ndepth;
			depthBytes=1;
			break;
		case 15:
		case 16:
			depth=16;
			depthBytes=2;
			break;
		case 24:
		case 32:
			depth=32;
			depthBytes=4;
			break;
		default:
			fprintf(stderr,"Internal Error: unknown depth %i passed to buffer2D::init.\n",Ndepth);
			exit(1);
	}
	depth=Ndepth;
	/*get=set=getA=setA=getX=setX=NULL;*/
	rowBytes=baseAddr=0;
	realBaseAddr=0;
	realLineStarts=NULL;
	p=0;
	img=NULL;
}
Bool buffer2D::okToDraw(void) /*Call this to set up the buffer.*/
{
	if (p)
	{
		XFreePixmap(display,p);
		p=0;
	}
	if (img)
	{
	/*	XDestroyImage(img);
	*/	img=0;
	}
	if (!realBaseAddr)
	{
		register long y;
		rowBytes=((depthBytes*wid+sizeof(double)-1)/sizeof(double))*sizeof(double);
		realBaseAddr=(long)Malloc(rowBytes*height);
		realLineStarts=(long *)Malloc(sizeof(long)*height);
		for (y=0;y<height;y++)
			realLineStarts[y]=realBaseAddr+y*rowBytes;
	}
	baseAddr=realBaseAddr;
	lineStarts=realLineStarts;
	return True;
}
void buffer2D::doneDrawing(void) /*Be sure to call this when done.*/
{
	lineStarts=0;
	baseAddr=0;
}
	
XImage *buffer2D::getImage(void)
{
	if (!img)
	{
		img=XCreateImage(display,visual,depth,ZPixmap,0,(char *)realBaseAddr,wid,height,8,rowBytes);
	}
	return img;
}
Pixmap buffer2D::getPixmap(void)
{
	if (!p)
	{
		GC myGC;
		p=XCreatePixmap(display,DefaultRootWindow(display),wid,height,depth);
		myGC=XCreateGC(display,p,0,NULL);
		XPutImage(display,p,myGC,getImage(),0,0,0,0,wid,height);
		XFreeGC(display,myGC);
	}
	return p;
}

void buffer2D::die(void)
{
	if (p)
		XFreePixmap(display,p);
	if (realBaseAddr)
		Free((void *)realBaseAddr);
	if (realLineStarts)
		Free((void *)realLineStarts);
	object::die();

}

