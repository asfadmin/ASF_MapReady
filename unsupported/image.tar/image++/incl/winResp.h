#include "responder.h"
#include "window.h"
#include "menu.h"
/*The singleWinResponder adds a single window and menu handling to
the basic responder.*/
class singleWinResponder:public responder { public:
	virtual void init4(int argc,char **argv,int maxX,int maxY);
	virtual char *getWindowName(void);
	virtual menuBlock *getMenus(void);
	virtual void mouseClick(Window w,int button,int x,int y);
	virtual void mouseMove(Window w,int state,int x,int y);
	virtual void mouseRelease(Window w,int button,int x,int y);
	virtual void drawWindow(Window w);
	virtual void resizeWindow(Window w,int newX,int newY);
	virtual void die(void);
protected:
	window * win;
	menuBlock * menus;
};
