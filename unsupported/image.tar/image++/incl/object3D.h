class camera3D;
class object3D:public object { public:
	virtual void render(camera3D *cam,buffer2D *b)=0;
};
object3D *createObject3D(const char *description);
