
class camera3D:public object { public:
	virtual void init7(double_t viewAngleX,double_t viewAngleY,const point3D &loc,const point3D &lookAt,const point3D &up, int NsizeX, int NsizeY);
	void setViewAngle(double_t NangleX,double_t NangleY);
	void setLocation(const point3D &loc);
	void setLookAt(const point3D &lookAt);
	void setUp(const point3D &up);
	void setSize(int sizeX,int sizeY);
	void to2D(const point3D &p,int *x,int *y);
	void to2Dv(const point3D p[],int x[],int y[],int numPts);
	void checkMatrix(void);
	virtual void die(void);
	
	matrix3D *addMatrix(matrix3D *newMatrix);
	void removeMatrix(matrix3D *oldMatrix);
	double qx,qy;
	int cenX,cenY;
	point3D loc,lookAt,up;
protected:
	double viewAngleX,viewAngleY;
	int sizeX,sizeY;
	Bool matrixCached;
	matrix3D *m;
	void fillMatrix(void);
};
