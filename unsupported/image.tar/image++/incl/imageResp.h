#include "winResp.h"
#include "buffer2D.h"
#include "image.h"
/*An imageDisplayResponder adds the simplest possible
image display interface to the basic responder class.
It's reponsible for scrolling.*/

class imageDisplayResponder:public singleWinResponder { public:
	virtual void init3(int argc,char **argv,image *Nimg);
	virtual void on2off(float *x,float *y);
	virtual void off2on(float *x,float *y);
	virtual char *getWindowName(void);
	virtual menuBlock *getMenus(void);
	virtual void doIdle(void);
	virtual void mouseClick(Window w,int button,int x,int y);
	virtual void mouseMove(Window w,int state,int x,int y);
	virtual void mouseRelease(Window w,int button,int x,int y);
	virtual void resizeWindow(Window w,int newX,int newY);
	virtual void drawWindow(Window w);
	virtual void setMag(float factor);
	virtual void processMenuItem(int menu,int item);
	virtual void die(void);
protected:
	int offX,offY,lastX,lastY;
	float magFactor;
	image * img;
	buffer2D *buf;
	Bool drawForReal;
	virtual void checkOff(void);
};
