class window:public object { public:
	Rect frame;/*Size of window.*/
	Window w;
	Colormap cmap;
	char name[255];
	virtual void init3(char *windowName,int maxX,int maxY);
	virtual void installGreyColormap(void);
	virtual void setSize(int sizeX,int sizeY);
	virtual void die(void);
};
window * createWindow(char *windowName,int sizeX,int sizeY);
