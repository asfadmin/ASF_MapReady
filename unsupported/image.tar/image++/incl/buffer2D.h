typedef struct {
	unsigned char alpha;
	unsigned char red;
	unsigned char green;
	unsigned char blue;
} trueColor;

class buffer2D;

#if defined(m68k)
#define bgParm  buffer2D *buf:__A0,long x:__D2,short y:__D1
#define bgParmA  char *addr:__A1,long x:__D2
#define bgParmX  char *addr:__A1,long x:__D2
#define bsParm  buffer2D *buf:__A0,long x:__D2,short y:__D1,long toWhat:__D0
#define bsParmA  char *addr:__A1,long x:__D2,long toWhat:__D0
#define bsParmX  char *addr:__A1,long x:__D2,long toWhat:__D0
#else
#define bgParm  buffer2D *buf,long x,short y
#define bgParmA  char *addr,long x
#define bgParmX  char *addr,long x
#define bsParm  buffer2D *buf,long x,short y,long toWhat
#define bsParmA  char *addr,long x,long toWhat
#define bsParmX  char *addr,long x,long toWhat
#endif

typedef long (*bg)(bgParm);typedef long (*bgA)(bgParmA);typedef long (*bgX)(bgParmX);
typedef void (*bs)(bsParm);typedef void (*bsA)(bsParmA);typedef void (*bsX)(bsParmX);

class buffer2D: public object {public:
	Rect frame;
	short depth,depthBytes;
	long baseAddr;
	bg get;bs set;
	bgA getA;bsA setA;//have address
	bgX getX;bsX setX;//have everything, including ANDed X
	long rowBytes,addrShiftRight,addrShiftLeft,andBy,shiftBy;
	long *lineStarts;
	
	void init3(int sizeX, int sizeY, int depth);
	Bool okToDraw(void); /*Call this to set up the buffer.*/
	void doneDrawing(void); /*Be sure to call this when done.*/
	
	XImage *getImage(void);
	Pixmap getPixmap(void);
	
	void fill(long color);
	void lineTo(int fromX,int fromY,int toX,int toY,long toWhat);
	void fixLineTo(long fromX,long fromY,long toX,long toY,long toWhat);
	
	virtual void die(void);
protected:
	long realBaseAddr;
	long *realLineStarts;
	Pixmap p;
	XImage *img;
	double expand64(long color);
};	

#define makeGrey16(value) ((value)|((value)<<5)|((value)<<10))
#define makeGrey32(value) ((value)|((value)<<8)|((value)<<8))
long makeGrey(float value); /*value=0.0 --> black; value=1.0 --> white.*/

