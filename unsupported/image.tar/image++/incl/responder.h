#include "object.h"
/*The responder is the base class for all responders.
Responders are the glue that holds an application together--
while they shouldn't actually contain algorithms or do
data processing, they do call objects for that.  They
form the "interface" portion of the old interface/implementation
division.
	You can also think of them as bureaucrats-- they don't
ever actually do work, but they're (sort of) necessary to tell
everyone else what to do, and to negotiate with third parties
(like governments, or operating system event loops).*/
class responder:public object {public:
	virtual void init2(int argc,char **argv);
	virtual void mouseClick(Window w,int button,int x,int y);
	virtual void mouseMove(Window w,int state,int x,int y);
	virtual void mouseRelease(Window w,int button,int x,int y);
	virtual void drawWindow(Window w)=0;
	virtual void doIdle(void);
	virtual void resizeWindow(Window w,int newX,int newY)=0;
	virtual void processMenuItem(int menu,int item);
	virtual void die(void);
};
responder * createResponder(int argc,char **argv);
