#define demDex(x,y) (y*wid+x)

typedef struct pointRec{
	point3D normal;
	long color;
	double_t x,y;
	double_t ht;
} pointRec;
class heightGrid:public object3D { public:
	Rect frame;
	virtual void init0(void);
	virtual void render(camera3D *cam,buffer2D *b);
	virtual void die(void);
protected:
	Bool pointsCached;
	virtual void cachePoints(void);
	long num_pts;
	point3D *p_pts;
	pointRec *pts;
	int *screenX,*screenY;
};

class dem3D:public heightGrid { public:
	virtual void init1(char *lasDEMName);
	virtual char *getName(void);
	virtual void die(void);
protected:
	image *img;
	char fileName[255];
};
