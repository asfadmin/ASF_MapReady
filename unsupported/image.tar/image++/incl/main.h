#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef M_PI
	#define M_PI 3.14159265358979323
#endif

#if defined(unix)
	#include <X11/Xlib.h>
	#include <X11/Xutil.h>
#else
	#define __TYPES__
	#define USG
	int fork(void);
	#include <X11/Xlib.h>
	#include <X11/Xutil.h>
#endif

extern Display *display;
extern Visual *visual;
extern GC gc;
extern int screen,screenBits,screenBytes;/*number and depth of main screen, in bits and bytes.*/
extern int startColor,lenColor;/*First palette/direct index, number of palette/direct indices.*/
extern long BlackPixel,WhitePixel;
extern long screenWid,screenHeight;
extern int done;
/*Debugger will crash the computer.  It's probably only useful during debugging.*/
#define debugger() *(int *)NULL=0;
#define interrupt() {fprintf(stderr,"Ack! Thrrpt! Bad Programmer! Bad!\n");debugger();exit(1);}
#define nil NULL
#define defAlloc(size) Malloc(size)
#define defDel(size) Free(size)
void *Malloc(size_t size);
void Free(void *p);

#define malloc(b) !@$%^&*(b)
#define free(b) !@$%^&*(b)


/*A double_t is the fastest reasonably accurate floating-point representation.
  (it's not necessarily a double.)*/
typedef float double_t;
#define cex const double_t

typedef union {
unsigned char c;
short s;
long l;
float f;
} pixelType;

#ifndef Bool
	#define Bool int
#endif
#ifndef False
	#define False 0
#endif
#ifndef True
	#define True 1
#endif


typedef struct {
	int top,left,bottom,right;
} Rect;

#define wid frame.right
#define height frame.bottom

float getRand(float minV,float maxV);
