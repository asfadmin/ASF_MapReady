class points3D:public object3D { public:
	virtual void init0(void);
	virtual void render(camera3D *cam,buffer2D *b);
	virtual void die(void);
protected:
	point3D *pts;
	long *color;
	int *screenX,*screenY;
	int num_pts;
};
class lines3D:public points3D {public:
	virtual void render(camera3D *cam,buffer2D *b);
};
