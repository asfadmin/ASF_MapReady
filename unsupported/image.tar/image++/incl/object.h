class object {public:
	long status;
	virtual void init0(void);
	virtual void die(void);
};
