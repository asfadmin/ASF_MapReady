class menuItem;
class responder;
class menuBlock:public object { public:
	virtual void init12(int menuNo,
		menuItem *item1,
		menuItem *item2=NULL,
		menuItem *item3=NULL,
		menuItem *item4=NULL,
		menuItem *item5=NULL,
		menuItem *item6=NULL,
		menuItem *item7=NULL,
		menuItem *item8=NULL,
		menuItem *item9=NULL,
		menuItem *item10=NULL,
		menuItem *item11=NULL,
		menuItem *item12=NULL);
	virtual void show(Window w,int x,int y);
	virtual Bool mouseMove(int x, int y);
	virtual void menuActivate(int newSelected);
	virtual void draw(void);
	virtual void hide(responder *destination);
	virtual void die(void);
protected:
	menuItem *item[12];
	int selectedItem,numItems,menuNo;
	Rect frame;
	int top,left;
	Window menuW;
};

class menuItem : public object { public:
	menuBlock *block;
	menuItem(const char *name,menuBlock *block);
	virtual void setName(const char *name);
	virtual void setHilite(Window w,Bool newHilite,int itemNumber,int menuWid);
	virtual void draw(Window w,int itemNumber, int menuWid);
	virtual Bool inSubMenu(int x, int y);
	virtual void die(void);
protected:
	Bool hilited;
	const char *name;
	int nameLen;
};
