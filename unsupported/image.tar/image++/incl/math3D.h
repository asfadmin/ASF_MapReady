#define point3D vector
#define Point3D vector

class vector { public:
	double_t x,y,z;
	vector(void) {}
	vector(const vector &v) {x=v.x;y=v.y;z=v.z;}
	vector(const double_t Nx,const double_t Ny, const double_t Nz) {x=Nx;y=Ny;z=Nz;}
	vector(const double_t initAllElements);
};

double_t magnitude(const vector& av);
vector normalize(const vector& av);
vector operator+(const vector& a,const vector& b);
vector operator-(const vector& a,const vector& b);
vector operator*(const vector& a,const vector& b);
vector operator*(const vector& a,double_t b);
vector operator*(double_t a,const vector& b);
vector operator/(const vector& a,const vector& b);
vector operator/(const vector& a,const double_t& b);
double_t getCosAngle(const vector& a,const vector& b);
vector getPerpVector(const vector& a,const vector& b);



class matrix3D { public:
	double_t e[4][3];
	vector transformVector(const vector &v);
	matrix3D *invert(void);
	matrix3D *dup(void);
};

extern Bool matrix3DquickAlloc;
matrix3D *uninitMatrix3D(void);
matrix3D *identityMatrix3D(void);
void deleteQuickMatrix(matrix3D *m);
matrix3D *translationMatrix(cex tX,cex tY,cex tZ);
matrix3D *scaleMatrix(cex scaleX,cex scaleY,cex scaleZ);
matrix3D *postMultBy(const matrix3D *a,const matrix3D *b);
matrix3D *rotationXMatrix(cex angle);
matrix3D *rotationYMatrix(cex angle);
matrix3D *rotationZMatrix(cex angle);
matrix3D *rotationXYZMatrix(cex angleX,cex angleY,cex angleZ);
