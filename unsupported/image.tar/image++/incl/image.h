class image:public object {public:
	Rect frame;
	virtual Bool needsRedraw(void);
	virtual Bool mouseClick(int button,double x,double y);
	virtual Bool mouseMove(int state,double x,double y);
	virtual void mouseRelease(int button,double x,double y);
	virtual Bool resizeOK(int sizeX,int sizeY);
	virtual double getImageValue(double x,double y);
	virtual double getIntImageValue(int x,int y);
	virtual char *getName(void);
	virtual Bool drawIntoBuffer(buffer2D *b,Bool needToDraw);
	virtual Bool drawSlowly(buffer2D *b,Bool needToDraw,Window w,int sizeX,int sizeY);
	virtual void initUserWait(Window w);
	virtual void tellUserToWait(Window w,int sizeX,int sizeY,int currWhat,int outOfWhat);
protected:
	int lastAngle;
	unsigned long lastTime;
};
image * createImage(const char *imageName);
