image *create3DViewer(object3D *mainObj);
