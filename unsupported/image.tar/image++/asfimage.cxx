#include <stdio.h>
#include "main.h"
#include "object.h"
#include "buffer2D.h"
#include "TWZimage.h"
#include "ceos.h"

image *createASF(const char *fileBaseName,const char *ext);
image *createASF(const char *fileBaseName,const char *ext)
{
	return NULL;
}
