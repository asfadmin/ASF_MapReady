#include "main.h"
#include "object.h"
#include "buffer2D.h"
#include "TWZimage.h"
#include "math3D.h"
#include "object3D.h"
#include "camera3D.h"
#include "viewer3D.h"

void camera3D::init7(double_t NviewAngleX,double_t NviewAngleY,const point3D &Nloc,const point3D &NlookAt,const point3D &Nup, int NsizeX, int NsizeY)
{
	object::init0();
	qx=qy=0;
	m=NULL;
	matrixCached=False;
	setViewAngle(NviewAngleX,NviewAngleY);
	setLocation(Nloc);
	setLookAt(NlookAt);
	setUp(Nup);
	setSize(NsizeX,NsizeY);
}
void camera3D::setViewAngle(double_t NangleX,double_t NangleY)
{
	viewAngleX=NangleX;
	viewAngleY=NangleY;
	matrixCached=False;
}
void camera3D::setLocation(const point3D &Nloc)
{
	loc=Nloc;
	matrixCached=False;
}
void camera3D::setLookAt(const point3D &NlookAt)
{
	lookAt=NlookAt;
	matrixCached=False;
}
void camera3D::setUp(const point3D &Nup)
{
	up=Nup;
	matrixCached=False;
}
void camera3D::setSize(int NsizeX,int NsizeY)
{
	sizeX=NsizeX;
	sizeY=NsizeY;
	matrixCached=False;
}
void camera3D::checkMatrix(void)
{
	if (!matrixCached)
		fillMatrix();
}
void camera3D::to2Dv(const point3D p[],int x[],int y[],int numPts)
{
	register int i;
	if (!matrixCached)
		fillMatrix();
	register double_t
		e00=m->e[0][0],e10=m->e[1][0],e20=m->e[2][0],e30=m->e[3][0],
		e01=m->e[0][1],e11=m->e[1][1],e21=m->e[2][1],e31=m->e[3][1],
		e02=m->e[0][2],e12=m->e[1][2],e22=m->e[2][2],e32=m->e[3][2];
	
	for (i=0;i<numPts;i++)
	{
		register double_t px=p[i].x,py=p[i].y,pz=p[i].z;
		register double_t outputZ=px*e02+py*e12+pz*e22+e32;
		if (outputZ<0.01)
			x[i]=y[i]=-1;
		else {
			x[i]=cenX+(px*e00+py*e10+pz*e20+e30)/outputZ;
			y[i]=cenY-(px*e01+py*e11+pz*e21+e31)/outputZ;
		}
	}
}
void camera3D::to2D(const point3D &p,int *x,int *y)
{
	if (!matrixCached)
		fillMatrix();
	double_t outputZ=p.x*m->e[0][2]+p.y*m->e[1][2]+p.z*m->e[2][2]+m->e[3][2];
	if (outputZ<0.00001)
		*x=*y=-1;
	else {
		*x=cenX+(p.x*m->e[0][0]+p.y*m->e[1][0]+p.z*m->e[2][0]+m->e[3][0])/outputZ;
		*y=cenY-(p.x*m->e[0][1]+p.y*m->e[1][1]+p.z*m->e[2][1]+m->e[3][1])/outputZ;
	}
}
void printVector(const char *mess,const vector &v);
void printVector(const char *mess,const vector &v)
{
	printf("%s=(%f,%f,%f)\n",mess,v.x,v.y,v.z);
}
void camera3D::fillMatrix(void)
{
	/*Fill in output matrix.*/
	vector X,Y,Z;
	matrix3DquickAlloc=True;
	matrix3D *mat=uninitMatrix3D();
	matrix3DquickAlloc=False;
	int smallerDim;
	if (sizeX<sizeY) 
		smallerDim=sizeX;
	else 
		smallerDim=sizeY;
	qx=smallerDim/tan(viewAngleX*M_PI/180.0);
	qy=smallerDim/tan(viewAngleY*M_PI/180.0);
	cenX=sizeX/2;
	cenY=sizeY/2;
	Z=normalize(lookAt-loc);
	X=normalize(getPerpVector(Z,up));
	Y=normalize(getPerpVector(X,Z));
	/*printVector("loc",loc);
	printVector("lookAt",lookAt);
	printVector("up",up);
	printVector("Z",Z);
	printVector("X",X);
	printVector("Y",Y);
	printf("Test: X*Y=%f, X*Z=%f, Y*Z=%f\n\n",getCosAngle(X,Y),getCosAngle(X,Z),getCosAngle(Y,Z));*/
	mat->e[0][0]=X.x;mat->e[1][0]=Y.x;mat->e[2][0]=Z.x;mat->e[3][0]=loc.x;
	mat->e[0][1]=X.y;mat->e[1][1]=Y.y;mat->e[2][1]=Z.y;mat->e[3][1]=loc.y;
	mat->e[0][2]=X.z;mat->e[1][2]=Y.z;mat->e[2][2]=Z.z;mat->e[3][2]=loc.z;
	matrix3DquickAlloc=False;
	if (m) 
		deleteQuickMatrix(m);
	m=mat->invert();
	matrix3DquickAlloc=True;
	deleteQuickMatrix(mat);
	matrix3DquickAlloc=False;
	m->e[0][0]*=qx;m->e[1][0]*=qx;m->e[2][0]*=qx;m->e[3][0]*=qx;
	m->e[0][1]*=qy;m->e[1][1]*=qy;m->e[2][1]*=qy;m->e[3][1]*=qy;
	matrixCached=True;
}

matrix3D *camera3D::addMatrix(matrix3D *newMatrix)
{
	matrix3D *oldM=m;
	if (!matrixCached)
		fillMatrix();
	matrix3DquickAlloc=True;
	m=postMultBy(newMatrix,m);
	matrix3DquickAlloc=False;
	return oldM;
}
void camera3D::removeMatrix(matrix3D *oldMatrix)
{
	matrix3DquickAlloc=True;
	deleteQuickMatrix(m);
	matrix3DquickAlloc=False;
	m=oldMatrix;
}
void camera3D::die(void)
{
	matrix3DquickAlloc=False;
	if (m) 
		deleteQuickMatrix(m);
	object::die();
}