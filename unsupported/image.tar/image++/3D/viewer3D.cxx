#include "main.h"
#include "object.h"
#include "buffer2D.h"
#include "TWZimage.h"
#include "math3D.h"
#include "object3D.h"
#include "camera3D.h"
#include "viewer3D.h"

class viewer3D:public image {public:
	virtual void init1(object3D *mainObj);
	virtual Bool mouseClick(int button,double x, double y);
	virtual Bool mouseMove(int state,double x, double y);
	virtual void mouseRelease(int button,double x, double y);
	virtual Bool needsRedraw(void);
	virtual Bool resizeOK(int sizeX,int sizeY);
	virtual Bool drawIntoBuffer(buffer2D *b,Bool needToDraw);
	virtual void die(void);
protected:
	object3D *obj;
	camera3D *cam;
#define buttonMask(button) (1<<(button))
	int buttonDown;
	double lastX,lastY;
	virtual Bool updatePos(void);
};

image *create3DViewer(object3D *mainObj)
{
	viewer3D *v=new viewer3D;
	v->init1(mainObj);
	return v;
}

void viewer3D::init1(object3D *mainObj)
{
	obj=mainObj;
	image::init0();
	wid=(int)(screenWid*0.95);
	height=(int)(screenHeight*0.95);
	buttonDown=0;
	cam=new camera3D;
	cam->init7(45.0,45.0,Point3D(0,0,10),Point3D(0,0,0),Point3D(0,1,0),wid,height);
}
Bool viewer3D::updatePos(void)
{
	double nx=(lastX-wid/2)/wid*3;
	double ny=(lastY-height/2)/height*3;
	if (buttonDown&buttonMask(1))
	{
		cam->setLocation(Point3D(cam->loc.x+nx,cam->loc.y+ny,cam->loc.z));
		return True;
	} else if (buttonDown&buttonMask(2))
	{
		cam->setLocation(Point3D(cam->loc.x,cam->loc.y,cam->loc.z+ny));
		return True;
	}
	return False;
}
Bool viewer3D::mouseClick(int button,double x, double y)
{
	buttonDown|=buttonMask(button);
	lastX=x;
	lastY=y;
	return (button!=3);
}
Bool viewer3D::mouseMove(int state,double x, double y)
{
	lastX=x;
	lastY=y;
	return !(state&Button3Mask);
}
void viewer3D::mouseRelease(int button,double x, double y)
{
	buttonDown&=~buttonMask(button);
	lastX=x;
	lastY=y;
}
Bool viewer3D::needsRedraw(void) {return True;}
Bool viewer3D::resizeOK(int sizeX,int sizeY)
{
	wid=sizeX;
	height=sizeY;
	cam->setSize(sizeX,sizeY);
	return True;
}
Bool viewer3D::drawIntoBuffer(buffer2D *b,Bool needToDraw)
{
	if (needToDraw||updatePos())
	{
		b->fill(BlackPixel);
		obj->render(cam,b);
		return True;
	}
	return False;
}
void viewer3D::die(void)
{
	cam->die();
	obj->die();
	image::die();
}
