#include "main.h"
#include "3D.h"
#include "dem3D.h"

void heightGrid::init0(void)
{
	frame.top=frame.left=frame.right=frame.bottom=0;
	pointsCached=False;
	screenX=screenY=NULL;
	p_pts=NULL;
	pts=NULL;
	object::init0();
}
void heightGrid::render(camera3D *cam,buffer2D *b)
{
	int i,j;
	if (!pointsCached)
		cachePoints();
	cam->to2Dv(p_pts,screenX,screenY,num_pts);
	for (i=1;i<wid;i++)
	{
		for (j=1;j<height;j++)
		{
			int id=demDex(i,j);
			pointRec *p=&pts[demDex(i,j)];
			if ((screenY[id]!=-1)&&(screenY[id-1]!=-1)&&(screenY[id-wid]!=-1))
			{
			 b->lineTo(screenX[id],screenY[id],screenX[id-1],screenY[id-1],p->color);
			 b->lineTo(screenX[id],screenY[id],screenX[id-wid],screenY[id-wid],p->color);
			}
		}
	}
}
void heightGrid::die(void)
{
	if (screenX)
	{
		Free((void *)screenX);
		Free((void *)screenY);
	}
	if (p_pts) Free((void *)p_pts);
	if (pts) Free((void *)pts);
	object::die();
}
void heightGrid::cachePoints(void)
{
	int i,j;
	num_pts=((long)wid)*height;
	if (!p_pts)
		p_pts=(point3D *)Malloc(sizeof(point3D)*num_pts);
	if (!screenX)
	{
		screenX=(int *)Malloc(sizeof(int)*num_pts);
		screenY=(int *)Malloc(sizeof(int)*num_pts);
	}
	for (i=0;i<num_pts;i++)
	{
		p_pts[i].x=pts[i].x;
		p_pts[i].z=pts[i].y;
		p_pts[i].y=pts[i].ht;
	}
	vector lightSource(0.5,1.0,0);
	lightSource=normalize(lightSource);
	for (i=1;i<wid;i++)
	{
		for (j=1;j<height;j++)
		{
			pointRec *p=&pts[demDex(i,j)];
			int id=demDex(i,j);
			p->normal=normalize(getPerpVector(p_pts[id]-p_pts[id-wid],p_pts[id]-p_pts[id-1]));
			float dotProd=getCosAngle(p->normal,lightSource);
			float color=dotProd;
			if (color<0) color=0;
			color=pow(color,2.0);
			p->color=makeGrey(color);
			/*if ((i%10==0)&&(j%10==0))
				printf("I=%i,J=%i, Normal=%f,%f,%f; dotProd=%f, color=%f.\n",
					i,j,p->normal.x,p->normal.y,p->normal.z,dotProd,color);*/
		}
	}
	pointsCached=True;
}

image *createLAS(const char *fileBaseName,const char *ext);
void dem3D::init1(char *lasDEMName)
{
	int i,j;
	float cenHeight,pixelSize=20.0;
	int wid2,height2;
	heightGrid::init0();
	strcpy(fileName,lasDEMName);
	img=createLAS(fileName,"ht");
	wid=100;/*img->wid;*/
	wid2=wid/2;
	height=100;/*img->height;*/
	height2=height/2;
	cenHeight=img->getIntImageValue(wid2,height2);
	pts=(pointRec *)Malloc(sizeof(pointRec)*wid*height);
	printf("Loading LAS DEM '%s'.\n",fileName);
	for (i=0;i<wid;i++)
		for (j=0;j<height;j++)
		{
			const float scale=0.001;
			pointRec *p=&pts[demDex(i,j)];
			p->x=(i-wid2)*pixelSize*img->wid/wid*scale;
			p->y=(j-height2)*pixelSize*img->height/height*scale;
			p->ht=(img->getIntImageValue(i*(img->wid-1)/(wid-1),j*(img->height-1)/(height-1))-cenHeight)*scale;
			p->color=makeGrey(0.5+(p->ht/scale)/500.0);
		}
}
char *dem3D::getName(void)
{
	return fileName;
}
void dem3D::die(void)
{
	img->die();
	heightGrid::die();
}
