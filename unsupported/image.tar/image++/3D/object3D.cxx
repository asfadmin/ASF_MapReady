#include "main.h"
#include "3D.h"
#include "demos3D.h"
#include "dem3D.h"

object3D *createObject3D(const char *description)
{
	object3D *ret=NULL;
	Bool inited=False;
	if (0==strcmp(description,"-3Dpoints"))
		ret=new points3D;
	else if (0==strcmp(description,"-3Dlines"))
		ret=new lines3D;
	else
	{
		char elevBase[255];
		strcpy(elevBase,&(description[3]));
		ret=new dem3D;
		((dem3D *)ret)->init1(elevBase);
		inited=True;
	}
	if (ret==NULL)
	{
		printf("Unknown 3D object type '%s'\n",description);
		return NULL;
	}
	if (!inited)
		ret->init0();
	return ret;
}
