#include "main.h"
#include "object.h"
#include "buffer2D.h"
#include "TWZimage.h"
#include "math3D.h"
#include "object3D.h"
#include "camera3D.h"
#include "viewer3D.h"
#include "demos3D.h"

float getPoint(void)
{
	float ret=-10;
	while ((-2.0>ret)||(2.0<ret))
	{
		ret=getRand(-2,2);
		ret*=ret*ret;
	}
	return ret;
}
void points3D::init0(void)
{
	int i;
	object3D::init0();
	num_pts=10000;
	screenX=(int *)Malloc(sizeof(int)*num_pts);
	screenY=(int *)Malloc(sizeof(int)*num_pts);
	pts=(point3D *)Malloc(sizeof(point3D)*num_pts);
	color=(long *)Malloc(sizeof(long)*num_pts);
	pts[0]=Point3D(2,0,0);
	pts[1]=Point3D(0,2,0);
	pts[2]=Point3D(0,0,2);
	for (i=3;i<num_pts;i++)
	{
		pts[i].x=getPoint();
		pts[i].y=getPoint();
		pts[i].z=getPoint();
		color[i]=rand()|(rand()<<8);
	}
}
int bufferX,bufferY;
void move(int x, int y,buffer2D *b);
void line(int dx, int dy,buffer2D *b);
void move(int x, int y,buffer2D *b)
{
	bufferX=x,bufferY=y;
}
void line(int dx, int dy,buffer2D *b)
{
	b->lineTo(bufferX,bufferY,bufferX+dx,bufferY+dy,WhitePixel);
	bufferX+=dx;
	bufferY+=dy;
}
void points3D::render(camera3D *cam,buffer2D *b)
{
	int i;
	srand(1);
	cam->to2Dv(pts,screenX,screenY,num_pts);
	move(screenX[0]-5,screenY[0]-5,b);
	line(10,10,b);
	move(screenX[0]+5,screenY[0]-5,b);
	line(-10,10,b);
	move(screenX[1],screenY[1],b);
	line(5,5,b);
	line(-5,5,b);
	line(10,-10,b);
	move(screenX[2],screenY[2],b);
	line(10,0,b);
	line(-10,10,b);
	line(10,0,b);
	
	for (i=3;i<num_pts;i++)
	{
		register unsigned int x,y;
		/*pts[i].x+=getRand(-0.1,0.1);
		pts[i].y+=getRand(-0.1,0.1);
		pts[i].z+=getRand(-0.1,0.1);*/
		x=screenX[i];
		y=screenY[i];
		if ((x<b->wid)&&(y<b->height))
		{
			switch(b->depthBytes)
			{
				case 1:
					*(char *)(b->lineStarts[y]+x)=color[i];
					break;
				case 2:
					*(char *)(b->lineStarts[y]+x*2)=color[i];
					break;
				case 4:
					*(char *)(b->lineStarts[y]+x*4)=color[i];
					break;
			}
		}
	}
}
void lines3D::render(camera3D *cam,buffer2D *b)
{
	int i;
	srand(1);
	cam->to2Dv(pts,screenX,screenY,num_pts);
	for (i=1;i<num_pts;i++)
	{
		register unsigned int x,y;
		/*pts[i].x+=getRand(-0.1,0.1);
		pts[i].y+=getRand(-0.1,0.1);
		pts[i].z+=getRand(-0.1,0.1);
		x=screenX[i];
		y=screenY[i];*/
		b->lineTo(screenX[i],screenY[i],screenX[i-1],screenY[i-1],color[i]);
	}
}
void points3D::die(void)
{
	Free((void *)pts);
	Free((void *)screenX);
	Free((void *)screenY);
	Free((void *)color);
	object3D::die();
}