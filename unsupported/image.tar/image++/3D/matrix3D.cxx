#include "main.h"
#include "math3D.h"
matrix3D *matrix3D::invert(void)
{
	register short i,j,i3,j3;
	double_t scratch[4*3],oute[4*3]={0},temp;
	oute[0*3+0]=1.0;
	oute[1*3+1]=1.0;
	oute[2*3+2]=1.0;
	//copy ourselves into scratch
	for (j=0;j<4;j++)
		for (i=0;i<3;i++)
			scratch[j*3+i]=e[j][i];
	matrix3D *out=uninitMatrix3D();
	for (i=0;i<3;i++) {
		register short pivot=i*3+i;
		if (scratch[pivot]==0.0)
		{
			//if the pivot is zero, then we have to swap rows so that it ain't.
			register short rowToSwap=i+1;
			while ((rowToSwap<3)&&(!scratch[rowToSwap*3+i]))
				rowToSwap++;
			if (rowToSwap!=3)
			{
				register short newPivot=i*3,oldPivot=rowToSwap*3;
				for (j=0;j<4;j++)
				{
					temp=scratch[newPivot];
					scratch[newPivot]=scratch[oldPivot];
					scratch[oldPivot]=temp;
					temp=oute[newPivot];
					oute[newPivot]=oute[oldPivot];
					oute[oldPivot]=temp;
					newPivot++;oldPivot++;
				}
			}
		}
		register double_t divby=1/scratch[pivot],mulby;
		i3=i*3;
		if (divby!=1) {
			scratch[i3]*=divby;
			oute[i3]*=divby;
			scratch[i3+1]*=divby;
			oute[i3+1]*=divby;
			scratch[i3+2]*=divby;
			oute[i3+2]*=divby;
		}
		for (j=0;j<3;j++) {
			j3=j*3;
			if ((j!=i)&&((mulby=scratch[j3+i])!=0)) {
				scratch[j3+0]-=mulby*scratch[i3+0];
				oute[j3+0]-=mulby*oute[i3+0];
				scratch[j3+1]-=mulby*scratch[i3+1];
				oute[j3+1]-=mulby*oute[i3+1];
				scratch[j3+2]-=mulby*scratch[i3+2];
				oute[j3+2]-=mulby*oute[i3+2];
			}
		}
		oute[3*3+i]=0;
	}
	out->e[3][0]=0;out->e[3][1]=0;out->e[3][2]=0;
	for (j=0;j<3;j++)
		for (i=0;i<3;i++)
		{
			out->e[j][i]=oute[j*3+i];
			out->e[3][i]-=oute[j*3+i]*e[3][j];
		}
	return out;
}
matrix3D *matrix3D::dup(void)
{
	matrix3D *retMatx=new matrix3D;
	*retMatx=*this;
	return retMatx;
}
const int size_of_matrixpile=50;
Bool matrix3DquickAlloc=False;
matrix3D *matrix3Dpile=nil,*matrix3DsavedVal;
matrix3D *uninitMatrix3D(void)
{
	if (matrix3DquickAlloc)
	{
		if (!matrix3Dpile)
			matrix3DsavedVal=matrix3Dpile=(matrix3D *)defAlloc(sizeof(matrix3D)*size_of_matrixpile);
		matrix3D *m=matrix3Dpile;
		matrix3Dpile++;
		return m;
	} else
		return new matrix3D;
}
matrix3D *identityMatrix3D(void)
{
	matrix3D *m=uninitMatrix3D();
	m->e[0][0]=1;m->e[1][0]=0;m->e[2][0]=0;m->e[3][0]=0;
	m->e[0][1]=0;m->e[1][1]=1;m->e[2][1]=0;m->e[3][1]=0;
	m->e[0][2]=0;m->e[1][2]=0;m->e[2][2]=1;m->e[3][2]=0;
	return m;
}
void deleteQuickMatrix(matrix3D *m)
{
	if (matrix3DquickAlloc)
	{
		matrix3Dpile--;
		if (m!=matrix3Dpile)
			interrupt();//when you set matrix3DquickAlloc true, you need to dispose of
			//the matricies in the exact opposite of the order you allocated them.
	} else
		delete m;
}
matrix3D *translationMatrix(cex tX,cex tY,cex tZ)
{
	matrix3D *m=identityMatrix3D();
	m->e[3][0]=tX;
	m->e[3][1]=tY;
	m->e[3][2]=tZ;
	return m;
}
matrix3D *scaleMatrix(cex scaleX,cex scaleY,cex scaleZ)
{
	matrix3D *m=identityMatrix3D();
	m->e[0][0]=scaleX;
	m->e[1][1]=scaleY;
	m->e[2][2]=scaleZ;
	return m;
}
/*This procedure returns a matrix equivalent to first applying a, then applying b.*/
matrix3D *postMultBy(const matrix3D *a,const matrix3D *b)
{
	matrix3D *ret=uninitMatrix3D();
	short x,y;
	for (y=0;y<3;y++)
	{
		for (x=0;x<3;x++)
			ret->e[x][y]=a->e[x][0]*b->e[0][y]+a->e[x][1]*b->e[1][y]+a->e[x][2]*b->e[2][y];
		ret->e[3][y]=a->e[3][0]*b->e[0][y]+a->e[3][1]*b->e[1][y]+a->e[3][2]*b->e[2][y]+b->e[3][y];
	}
	return ret;
}
vector matrix3D::transformVector(const vector &v)
{
	vector ret(
		e[3][0]+v.x*e[0][0]+v.y*e[1][0]+v.z*e[2][0],
		e[3][1]+v.x*e[0][1]+v.y*e[1][1]+v.z*e[2][1],
		e[3][2]+v.x*e[0][2]+v.y*e[1][2]+v.z*e[2][2]);
	return ret;
}
matrix3D *rotationXMatrix(cex angle)
{
	matrix3D *m=identityMatrix3D();
	double_t cosine=cos(angle);
	double_t sine=sin(angle);
	m->e[1][1]=cosine;
	m->e[2][1]=-sine;
	m->e[1][2]=sine;
	m->e[2][2]=cosine;
	return m;
}
matrix3D *rotationYMatrix(cex angle)
{
	matrix3D *m=identityMatrix3D();
	double_t cosine=cos(angle);
	double_t sine=sin(angle);
	m->e[0][0]=cosine;
	m->e[2][0]=-sine;
	m->e[0][2]=sine;
	m->e[2][2]=cosine;
	return m;
}
matrix3D *rotationZMatrix(cex angle)
{
	matrix3D *m=identityMatrix3D();
	double_t cosine=cos(angle);
	double_t sine=sin(angle);
	m->e[0][0]=cosine;
	m->e[1][0]=-sine;
	m->e[0][1]=sine;
	m->e[1][1]=cosine;
	return m;
}
matrix3D *rotationXYZMatrix(cex angleX,cex angleY,cex angleZ)
{
	matrix3D *m=identityMatrix3D();
	return m;
}