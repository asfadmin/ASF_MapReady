#include "main.h"
#include "math3D.h"
vector::vector(const double_t initAllElements)
{
	x=y=z=initAllElements;
}
double_t magnitude(const vector& av)
{
	return sqrt(av.x*av.x+av.y*av.y+av.z*av.z);
}
vector normalize(const vector& av)
{
	return av/magnitude(av);
}
vector operator+(const vector& a,const vector& b) 
{
	return vector(a.x+b.x,a.y+b.y,a.z+b.z);
}
vector operator-(const vector& a,const vector& b) 
{
	return vector(a.x-b.x,a.y-b.y,a.z-b.z);
}
vector operator*(const vector& a,const vector& b) 
{
	return vector(a.x*b.x,a.y*b.y,a.z*b.z);
}
vector operator*(const vector& a,double_t b) 
{
	return vector(a.x*b,a.y*b,a.z*b);
}
vector operator*(double_t a,const vector& b) 
{
	return vector(b.x*a,b.y*a,b.z*a);
}
vector operator/(const vector& a,const vector& b) 
{
	return vector(a.x/b.x,a.y/b.y,a.z/b.z);
}
vector operator/(const vector& a,const double_t& b) 
{
	return vector(a.x/b,a.y/b,a.z/b);
}
double_t getCosAngle(const vector& a,const vector& b) 
{
	return (a.x*b.x+a.y*b.y+a.z*b.z);
}
vector getPerpVector(const vector& a,const vector& b) 
{
	return vector(a.y*b.z-a.z*b.y,
				  a.z*b.x-a.x*b.z,
				  a.x*b.y-a.y*b.x);
}
