/* ==========================================================================
   $MODULE_HEADER

      $NAME         ERRS_EPEL

      $FUNCTION     Write the exit message in the process error log

      $ROUTINE      ERRSIP_EPEL_exit_proc_err_log

      $HISTORY

                SCR NO.      DATE        INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
                N/A       07-OCT-1992       DD       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>

#include "libname.h"
#include ERRS_INTF_H
#include ERRS_PGLB_H


/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */
 
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_EPEL_exit_proc_err_log

      $FUNCTION     Write a procedure exit message in the PROCESS ERROR LOG

      $INPUT        routine_name              : routine name
                    ret_status                : return status

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid

      $RET_STATUS   NONE

      $DESCRIPTION  This routine write in the process error log an  exit
                    string containing the routine name and the exit time.
                    Decrement the nesting level.

      $WARNING      NONE

   $EH
   ========================================================================== */
   void ERRSIP_EPEL_exit_proc_err_log
                        ( /*IN    */ const ERRSIT_proc_name proc_name,
                          /*IN    */ ERRSIT_status          ret_status,
                          /*   OUT*/ ERRSIT_status         *status_code )
{

   const ERRSIT_proc_name routine_name = "ERRSIP_EPEL_exit_proc_err_log";

   char                      date_time[25];
   
/* ==========================================================================
   Default initialization.  
   ========================================================================== */
   *status_code = ERRSID_normal;

   if ( ERRSPV_proc_err_log_fid != NULL )
   {

      fprintf(ERRSPV_proc_err_log_fid,"%03d %s Terminated : ", ERRSIV_level,
                                                               proc_name );

/* ==========================================================================
   Get current date and write it to the process error log.
   ========================================================================== */
      fprintf( ERRSPV_proc_err_log_fid,"%s", 
               ERRSIF_LODT_out_date( date_time ) );

      fprintf( ERRSPV_proc_err_log_fid," - Status code : %4d\n\n", 
                                       (int) ret_status );

      fflush( ERRSPV_proc_err_log_fid );

   } /* ERRSPV_proc_err_log_fid != NULL */

   
error_exit:;

}/* end ERRSIP_EPEL_exit_proc_err_log */
