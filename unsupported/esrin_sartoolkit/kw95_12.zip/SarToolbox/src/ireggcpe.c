/* ==========================================================================
   $MODULE_HEADER

      $NAME              IREG_GCPE

      $FUNCTION          This module contains the procedures to evaluate the
                         GCPs grids on images to co-register

      $ROUTINE           IREGPP_GCPE_Init
                         IREGPP_GCPE_Close
                         IREGPP_GCPE_GCPRegistrator
                         IREGPP_GCPE_GridCreator
                         IREGPP_GCPE_MasterGCP
                         IREGPP_GCPE_MasRowCol2LatLon
                         IREGPP_GCPE_SlaveGCP
                         IREGPP_GCPE_CellExtraction
                         IREGPP_GCPE_FillImaCell
                         IREGPP_GCPE_PointSubMatrix
                         IREGPP_GCPE_RotAngleEval
                         IREGPP_GCPE_SlaveCorners
                         IREGPP_GCPE_SlaveToMaster
                         IREGPP_GCPE_AngleEval
                         IREGPP_GCPE_CellExtractor
                         IREGPP_GCPE_ElemSizeEval
                         IREGPP_GCPE_EnlCellAndGridAlloc
                         IREGPP_GCPE_FillRotGrid
                         IREGPP_GCPE_ShiftEvaluation
                         IREGPP_GCPE_FillArray
                         IREGPP_GCPE_ZeroPadding
                         IREGPP_GCPE_FindMaximum
                         IREGPP_GCPE_CoarseRegistrator
                         IREGPP_GCPE_SetDataType
                         IREGPP_GCPE_ModulEval
                         IREGPP_GCPE_FFTAbsImaEval
                         IREGPP_GCPE_ArrayModulEval
                         IREGPP_GCPE_Shifts
                         IREGPP_GCPE_CrossCorrInterp
                         IREGPP_GCPE_ShiftRotate
                         IREGPP_GCPE_ArraysAllocation
                         IREGPP_GCPE_SmoothIma2float
                         IREGPP_GCPE_SmoothImafloat
                         IREGPF_GCPE_Coherfloat
                         IREGPF_GCPE_Coher2float
                         IREGPP_GCPE_CoherMaxim
                         IREGPP_GCPE_InitFineReg
                         IREGPP_GCPE_CloseFineReg
                         IREGPP_GCPE_FineRegistrator
                         IREGPP_GCPE_ReadGCPs

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       23-OCT-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>
#include <string.h>
#include <math.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include IANN_INTF_H
#include MATH_INTF_H
#include TIFS_INTF_H
#include COOR_INTF_H
#include SRVS_INTF_H
#include IREG_INTF_H
#include IREG_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_GCPRegistrator

        $TYPE         PROCEDURE

        $INPUT        TLRow       : row coordinate of the top left corner of
                                    the AoI in which the registrator must act
                      TLCol       : column coordinate of the top left corner
                                    of the AoI in which the registrator must
                                    act
                      BRRow       : row coordinate of the bottom right corner
                                    of the AoI in which the registrator must
                                    act
                      BRCol       : column coordinate of the bottom right corner
                                    of the AoI in which the registrator must act
                      inp_io      : array of descriptors of the opened files
                      GCPFileName : name of the optional master GCP file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the driver for the GCPs registration

        $WARNING      NONE

        $PDL          - Creates the GCPs grid
                      - Makes the coarse registration
                      - Makes the fine registration

   $EH
   ========================================================================== */

void IREGPP_GCPE_GCPRegistrator
                        (/*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                BRRow,
                         /*IN    */ INTx4                BRCol,
                         /*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ char                *GCPFileName,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_GCPRegistrator";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 mas_imanum = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Create the GCPs grid
   ========================================================================== */
   IREGPP_GCPE_GridCreator ( TLRow, TLCol, BRRow, BRCol, GCPFileName,
                             status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Make the coarse registration
   ========================================================================== */
   IREGPP_GCPE_CoarseRegistrator ( inp_io, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Make the fine registration
   ========================================================================== */
   if ( inp_io[ mas_imanum ].val.tif.bpar.sampleperpixel == 1 ) {
      if ( IREGIV_FineRegFlag == 'Y' ) {
         IREGPP_GCPE_FineRegistrator ( inp_io, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }
   else {
      IREGPP_GCPE_FineRegistrator ( inp_io, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_GCPRegistrator */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_Init

        $TYPE         PROCEDURE

        $INPUT        NGCPRow              : number of GCPs in the rows
                                             direction
                      NGCPCol              : number of GCPs in the columns
                                             direction
                      row_coarse_cell_size : cell dimension in the row
                                             direction for the coarse 
                                             registration
                      col_coarse_cell_size : cell dimension in the column
                                             direction for the coarse 
                                             registration
                      int_fact_row         : interpolation factor in the
                                             row direction for the coarse
                                             registration
                      int_fact_col         : interpolation factor in the
                                             column direction for the coarse
                                             registration
                      row_fine_cell_size   : cell dimension in the row
                                             direction for the fine
                                             registration
                      col_fine_cell_size   : cell dimension in the column
                                             direction for the fine
                                             registration
                      coher_wsiz           : size of the square window for
                                             the coherence evaluation
                      coher_ftol           : tolerance in the function
                                             values for the convergence in
                                             the coherence evaluation
                      coher_vtol           : tolerance in the variables
                                             values for the convergence in
                                             the coherence evaluation
                      NImages              : number of input images
                      GCPFileName          : optional file name for the
                                             master GCPs

        $MODIFIED     NONE

        $OUTPUT       The array of structures that will contain the GCPs is
                      allocated

        $GLOBAL       IREGPV_GCP_mas_num_row     : number of GCPs in the rows
                                                   direction
                      IREGPV_GCP_mas_num_col     : number of GCPs in the columns
                                                   direction
                      IREGPV_coarse_cell_dim_row : cell dimension in the row
                                                   direction for the coarse
                                                   registration
                      IREGPV_coarse_cell_dim_col : cell dimension in the columns
                                                   direction for the coarse
                                                   registration
                      IREGPV_int_fact_row        : interpolation factor in the
                                                   rows direction for the coarse
                                                   registration
                      IREGPV_int_fact_col        : interpolation factor in the
                                                   columns direction for the
                                                   coarse registration
                      IREGPV_fine_cell_dim_row   : cell dimension in the rows
                                                   direction for the fine
                                                   registration
                      IREGPV_fine_cell_dim_col   : cell dimension in the columns
                                                   direction for the fine
                                                   registration
                      IREGPV_coher_wsiz          : size of the square window for
                                                   the coherence evaluation
                      IREGPV_coher_ftol          : tolerance in the function
                                                   values for the convergence in
                                                   the coherence evaluation
                      IREGPV_coher_vtol          : tolerance in the variables
                                                   values for the convergence in
                                                   the coherence evaluation
                      IREGPV_gcp                 : the structure with all the GCP
                                                   INFO

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_GCP_num_invalid
                      ERRSID_IREG_int_fact
                      ERRSID_IREG_coher_wsiz_null
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure initializes the structures that will
                      contain the GCPs and the related information

        $WARNING      THE VARIABLE THAT CONTAINS THE NUMBER OF OPENED IMAGES
                      AND THE VARIABLES WHITH THE NUMBER OF GCPS IN THE TWO
                      DIRECTIONS MUST BE FILLED BEFORE CALLING THIS PROCEDURE

        $PDL          - Fills the global variables and checks them
                      - Checks the image number
                      - If the number of GCPs is greather then the maximum
                        number
                            Sets the GCP number equals to the maximum number
                      - End if
                      - Evaluates the number of GCPs
                      - Zeroes the array of structures containing the GCPs info
                      - Loop over the images
                            - Allocates the array of structures with the GCPs
                            - Zeroes the allocated memories
                      - End loop
                      - Loop over the images
                            - Initializes the coordinates conversions
                      - End loop

   $EH
   ========================================================================== */

void IREGPP_GCPE_Init
                        (/*IN    */ INTx4                NGCPRow,
                         /*IN    */ INTx4                NGCPCol,
                         /*IN    */ INTx4                row_coarse_cell_size,
                         /*IN    */ INTx4                col_coarse_cell_size,
                         /*IN    */ float                int_fact_row,
                         /*IN    */ float                int_fact_col,
                         /*IN    */ INTx4                row_fine_cell_size,
                         /*IN    */ INTx4                col_fine_cell_size,
                         /*IN    */ INTx2                coher_wsiz,
                         /*IN    */ double               coher_ftol,
                         /*IN    */ double               coher_vtol,
                         /*IN    */ INTx4                NImages,
                         /*IN    */ char                *GCPFileName,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_Init";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 Ngcp;
   UINTx4                 ima;
   UINTx4                 pt;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the number of images to manage
   ========================================================================== */
   if ( ( NImages < 2 ) || ( NImages > IREGPD_max_img ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_ima_num_inv, "" );
   }

/* ==========================================================================
   Set the number of images
   ========================================================================== */
   IREGIV_ima_num = NImages;

/* ==========================================================================
   Check the GCPs file existence
   ========================================================================== */
   if ( GCPFileName == (char *)NULL ) {

/* ==========================================================================
   Set the number of GCPs
   ========================================================================== */
      IREGPV_GCP_mas_num_row = NGCPRow;
      IREGPV_GCP_mas_num_col = NGCPCol;

/* ==========================================================================
   Check the number of GCP required
   ========================================================================== */
      if ( ( IREGPV_GCP_mas_num_row < 1 ) || ( IREGPV_GCP_mas_num_col < 1 ) ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_GCP_num_invalid, "" );
      }
      if ( IREGPV_GCP_mas_num_row > IREGPD_max_GCP_dir_number ) {
         ERRSIM_print_warning (
            "The rows GCPs num exceed maximum value. Default is set" );
         IREGPV_GCP_mas_num_row = IREGPD_max_GCP_dir_number;
      }
      if ( IREGPV_GCP_mas_num_col > IREGPD_max_GCP_dir_number ) {
         ERRSIM_print_warning (
            "The columns GCPs num exceed maximum value. Default is set" );
         IREGPV_GCP_mas_num_col = IREGPD_max_GCP_dir_number;
      }

/* ==========================================================================
   Evaluate the GCP number
   ========================================================================== */
      Ngcp = IREGPV_GCP_mas_num_row * IREGPV_GCP_mas_num_col;
   }
   else {

/* ==========================================================================
   Set the GCPs number to their maximum
   ========================================================================== */
      Ngcp = IREGPD_max_GCP_dir_number * IREGPD_max_GCP_dir_number;
   }

/* ==========================================================================
   Set the coarse cells dimensions
   ========================================================================== */
   IREGPV_coarse_cell_dim_row = row_coarse_cell_size;
   IREGPV_coarse_cell_dim_col = col_coarse_cell_size;

/* ==========================================================================
   Check the windows dimensions
   ========================================================================== */
   if ( ( IREGPV_coarse_cell_dim_row <= 0 ) ||
        ( IREGPV_coarse_cell_dim_col <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_win_size,
                         "for the coarse registration cells" );
   }

/* ==========================================================================
   Check they are odd
   ========================================================================== */
   if ( !( IREGPV_coarse_cell_dim_row % 2 ) ) {
      IREGPV_coarse_cell_dim_row += 1;
   }
   if ( !( IREGPV_coarse_cell_dim_col % 2 ) ) {
      IREGPV_coarse_cell_dim_col += 1;
   }

/* ==========================================================================
   Set the coarse registration interpolation factors
   ========================================================================== */
   IREGPV_int_fact_row = int_fact_row;
   IREGPV_int_fact_col = int_fact_col;

/* ==========================================================================
   Check they are not lesser then 1
   ========================================================================== */
   if ( IREGPV_int_fact_row < 1. ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_int_fact,
                         "in the row direction" );
   }
   if ( IREGPV_int_fact_col < 1. ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_int_fact,
                         "in the column direction" );
   }

/* ==========================================================================
   Set the fine registration cell dimensions
   ========================================================================== */
   IREGPV_fine_cell_dim_row = row_fine_cell_size;
   IREGPV_fine_cell_dim_col = col_fine_cell_size;

/* ==========================================================================
   Check the windows dimensions
   ========================================================================== */
   if ( ( IREGPV_fine_cell_dim_row <= 0 ) ||
        ( IREGPV_fine_cell_dim_col <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_win_size,
                         "for the fine registration cells" );
   }

/* ==========================================================================
   Check they are odd
   ========================================================================== */
   if ( !( IREGPV_fine_cell_dim_row % 2 ) ) {
      IREGPV_fine_cell_dim_row += 1;
   }
   if ( !( IREGPV_fine_cell_dim_col % 2 ) ) {
      IREGPV_fine_cell_dim_col += 1;
   }

/* ==========================================================================
   Set the coherence window size
   ========================================================================== */
   IREGPV_coher_wsiz = coher_wsiz;

/* ==========================================================================
   Check it's greather then 0
   ========================================================================== */
   if ( IREGPV_coher_wsiz < 1 ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_coher_wsiz_null, "" );
   }

/* ==========================================================================
   Set the iteration tolerances
   ========================================================================== */
   IREGPV_coher_ftol = coher_ftol;
   IREGPV_coher_vtol = coher_vtol;

/* ==========================================================================
   Check they're positive
   ========================================================================== */
   if ( ( IREGPV_coher_ftol <= (double)0 ) ||
        ( IREGPV_coher_vtol <= (double)0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_neg_val,
                         "for the coherence maximization procedure" );
   }

/* ==========================================================================
   Zeroes the GCP descriptor
   ========================================================================== */
   memset ( (void *)IREGPV_gcp, 0, (size_t)(IREGPD_max_img *
            sizeof (IREGPT_gcps_descr)) );

/* ==========================================================================
   Loop over the images
   ========================================================================== */
   for ( ima=0; ima<IREGIV_ima_num; ima++ ) {

/* ==========================================================================
   Allocate the array memories
   ========================================================================== */
      if ( ( IREGPV_gcp[ ima ].gcp_arr = (IREGPT_gcp *)
                MEMSIP_alloc ( (size_t)(Ngcp * sizeof (IREGPT_gcp)) ) ) ==
           (IREGPT_gcp *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the GCP array allocation" );
      }

/* ==========================================================================
   Zeroes the created array
   ========================================================================== */
      memset ( (void *)IREGPV_gcp[ ima ].gcp_arr, 0, (size_t)(Ngcp *
               sizeof (IREGPT_gcp)) );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_Init */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_Close

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     The allocated memories to store the GCPs are freed

        $OUTPUT       NONE

        $GLOBAL       IREGIV_ima_num : number of images involved in the tool
                      IREGPV_gcp     : array of structure with the GCPs info

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure deallocates the GCP info structure
                      allocated in the initialization procedure

        $WARNING      NONE

        $PDL          - Loop over the images
                            - Frees the gcp array
                      - End loop

   $EH
   ========================================================================== */

void IREGPP_GCPE_Close
                        (/*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_Close";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 ima;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   for ( ima=0; ima<IREGIV_ima_num; ima++ ) {
      MEMSIP_free ( (void **)&(IREGPV_gcp[ ima ].gcp_arr) );
   }

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_Close */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_GridCreator

        $TYPE         PROCEDURE

        $INPUT        TLRow       : row coordinate of the top left corner of
                                    the AoI in which the registrator must act
                      TLCol       : column coordinate of the top left corner
                                    of the AoI in which the registrator must
                                    act
                      BRRow       : row coordinate of the bottom right corner
                                    of the AoI in which the registrator must
                                    act
                      BRCol       : column coordinate of the bottom right corner
                                    of the AoI in which the registrator must act
                      GCPFileName : name of the optional master GCP file

        $MODIFIED     The GCP grids are filled

        $OUTPUT       NONE

        $GLOBAL       IREGPV_GCP_mas_num_row
                      IREGPV_GCP_mas_num_col
                      IREGIV_ima_num

        $RET_STATUS   ERRSID_IREG_incons_corn
                      ERRSID_IREG_image_number_out
                      ERRSID_IREG_grid_number_out
                      ERRSID_IREG_GCP_num_invalid
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure creates the grids of GCP on the images
                      opened in the tool of co-registration

        $WARNING      THE INIT PROCEDURE MUST BE EXECUTED BEFORE ALL THE
                      OTHER PROCEDURES OF IREG AND AFTER THE IMAGE ANNOTATIONS
                      READING PROCEDURE

        $PDL          - Checks the number of GCP in the rows and columns
                        direction
                      - Checks the number of images
                      - Evaluates the total number of GCPs
                      - Creates the GCP grid on the master image
                      - Allocates a grid to contain the geodetic coordinates
                        of the master GCPs grid
                      - Converts the GCP grid from master image ( row, col )
                        into ( lat, lon ) coordinates
                      - Loop over the slaves images
                            - Fill the slave GCP grid
                      - End loop

   $EH
   ========================================================================== */

void IREGPP_GCPE_GridCreator
                        (/*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                BRRow,
                         /*IN    */ INTx4                BRCol,
                         /*IN    */ char                *GCPFileName,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_GridCreator";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 Ngcp;
   MATHIT_LLH            *geo_grid = (MATHIT_LLH *)NULL;
   INTx1                  mas_imanum = 0;
   INTx1                  mas_gridnum = 0;
   INTx4                  ima;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check if the initialization has been done
   ========================================================================== */

   /* rows and columns GCPs numbers */
   if ( ( IREGPV_GCP_mas_num_row < 1 ) || ( IREGPV_GCP_mas_num_col < 1 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_GCP_num_invalid, "" );
   }
   if ( IREGPV_GCP_mas_num_row > IREGPD_max_GCP_dir_number ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_GCP_num_invalid,
                         " in the rows direction" );
   }
   if ( IREGPV_GCP_mas_num_col > IREGPD_max_GCP_dir_number ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_GCP_num_invalid,
                         " in the columns direction" );
   }

   /* images number */
   if ( ( IREGIV_ima_num < 2 ) || ( IREGIV_ima_num > IREGPD_max_img ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_ima_num_inv, "" );
   }

/* ==========================================================================
   Check the corners
   ========================================================================== */
   if ( ( TLRow >= BRRow ) || ( TLCol >= BRCol ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_incons_corn, "" );
   }


/* ==========================================================================
   Evaluate the total number of GCP
   ========================================================================== */
   Ngcp = IREGPV_GCP_mas_num_row * IREGPV_GCP_mas_num_col;

/* ==========================================================================
   Switch between read the master GCPs from file or create them
   ========================================================================== */
#ifdef __TRACE__
   fprintf ( stdout, "\n GCPs File Name = %s", GCPFileName );
#endif
   if ( GCPFileName != (char *)NULL ) {

/* ==========================================================================
   Read the master GCPs from file
   ========================================================================== */
      IREGPP_GCPE_ReadGCPs ( TLRow, TLCol, BRRow, BRCol, GCPFileName,
                             status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Set the number of GCPs
   ========================================================================== */
      Ngcp = IREGPV_gcp[ mas_gridnum ].n_gcp;
   }
   else {

/* ==========================================================================
   Create the Master GCP grid
   ========================================================================== */
      IREGPP_GCPE_MasterGCP ( TLRow, TLCol, BRRow, BRCol, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Allocate the output grid
   ========================================================================== */
   if ( ( geo_grid = (MATHIT_LLH *)MEMSIP_alloc ( (size_t)(Ngcp *
           sizeof (MATHIT_LLH) ) ) ) == (MATHIT_LLH *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         " allocating the output grid" );
   }

/* ==========================================================================
   Convert the GCP from master (row, col) into (lat,lon)
   ========================================================================== */
   IREGPP_GCPE_MasRowCol2LatLon ( geo_grid, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the grids in the slave images
   ========================================================================== */
   for ( ima=1; ima<IREGIV_ima_num; ima++ ) {

/* ==========================================================================
   Converts the (lat,lon) coordinates into (row, col) of the current slave
   ========================================================================== */
      IREGPP_GCPE_SlaveGCP ( ima, ima, geo_grid, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&geo_grid );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_GridCreator */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_MasterGCP

        $TYPE         PROCEDURE

        $INPUT        TLRow : row coordinate of the top left corner of the
                              AoI in which the registrator must act
                      TLCol : column coordinate of the top left corner of the
                              AoI in which the registrator must act
                      BRRow : row coordinate of the bottom right corner of the
                              AoI in which the registrator must act
                      BRCol : column coordinate of the bottom right corner of the
                              AoI in which the registrator must act

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[0] : the structure with the
                                             image annotations that
                                             must be filled

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_grid_number_out
                      ERRSID_IREG_GCP_num_invalid

        $DESCRIPTION  This procedure evaluates the grid of GCPs coordinates
                      for the image co-registration on the Master image
                      reference system

        $WARNING      NONE

        $PDL          - Evaluates the deltas between the GCPs
                      - Loop over the grid rows
                            - Loop over the grid columns
                                  - Evaluates the rows and columns row columns
                                    coordinates of each GCP
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void IREGPP_GCPE_MasterGCP
                        (/*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                BRRow,
                         /*IN    */ INTx4                BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_MasterGCP";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   MATHIT_RC              delta;
   UINTx4                 i;
   UINTx4                 j;
   INTx1                  mas_imanum = 0;
   INTx1                  mas_gridnum = 0;
   INTx4                  NRow;
   INTx4                  NCol;
                          
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the number of GCP required
   ========================================================================== */
   if ( ( IREGPV_GCP_mas_num_row < 1 ) || ( IREGPV_GCP_mas_num_col < 1 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_GCP_num_invalid, "" );
   }
   if ( IREGPV_GCP_mas_num_row > IREGPD_max_GCP_dir_number ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_GCP_num_invalid,
                         " in the rows direction" );
   }
   if ( IREGPV_GCP_mas_num_col > IREGPD_max_GCP_dir_number ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_GCP_num_invalid,
                         " in the columns direction" );
   }

/* ==========================================================================
   Fill the GCP number
   ========================================================================== */
   IREGPV_gcp[ mas_gridnum ].n_gcp = IREGPV_GCP_mas_num_row *
      IREGPV_GCP_mas_num_col;

/* ==========================================================================
   Evaluate the number of rows and columns
   ========================================================================== */
   NRow = BRRow - TLRow + 1;
   NCol = BRCol - TLCol + 1;

/* ==========================================================================
   Evaluate the delta between the GCPs
   ========================================================================== */
   delta.row = (double)NRow / ( IREGPV_GCP_mas_num_row + 1 );
   delta.col = (double)NCol / ( IREGPV_GCP_mas_num_col + 1 );

/* ==========================================================================
   Create the master GCP grid
   ========================================================================== */
   for ( i=0; i<IREGPV_GCP_mas_num_row; i++ ) {
      for ( j=0; j<IREGPV_GCP_mas_num_col; j++ ) {
         IREGPV_gcp[ mas_gridnum ].gcp_arr[
            i * IREGPV_GCP_mas_num_col + j ].coor.row = TLRow +
            ROUND ( ( i + 1 ) * delta.row );
         IREGPV_gcp[ mas_gridnum ].gcp_arr[
            i * IREGPV_GCP_mas_num_col + j ].coor.col = TLCol +
            ROUND ( ( j + 1 ) * delta.col );
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_MasterGCP */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_MasRowCol2LatLon

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       geo_grid    : grid corresponding to the master image one
                                    evaluated in geodetic coordinates

        $GLOBAL       IREGPV_gcp[0]        : the structure with the
                                             GCP info
                      IANNIV_ImageAnnot[0] : the structure with the
                                             image annotations that
                                             must be filled

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_grid_number_out
                      ERRSID_IREG_GCP_num_invalid

        $DESCRIPTION  This procedure evaluates the master grid into geodetic
                      coordinates

        $WARNING      THE MASTER GRID MUST BE CREATED BEFORE

        $PDL          - Checks the number of GCPs
                      - Converts the master grid in row columns coordinates
                        into geodetc coordinates

   $EH
   ========================================================================== */

void IREGPP_GCPE_MasRowCol2LatLon
                        (/*   OUT*/ MATHIT_LLH          *geo_grid,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_MasRowCol2LatLon";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 i;
   INTx1                  mas_imanum = 0;
   INTx1                  mas_gridnum = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the number of created GCPs
   ========================================================================== */
   if ( ( IREGPV_gcp[ mas_gridnum ].n_gcp < 1 ) ||
        ( IREGPV_gcp[ mas_gridnum ].n_gcp > ( IREGPD_max_GCP_dir_number *
           IREGPD_max_GCP_dir_number ) ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_GCP_num_invalid, "" );
   }

/* ==========================================================================
   Zero the output grid
   ========================================================================== */
   memset ( (void *)geo_grid, 0, (size_t)(IREGPV_gcp[ mas_gridnum ].n_gcp *
            sizeof (MATHIT_LLH)) );

/* ==========================================================================
   Initialize the master coordinates conversions
   ========================================================================== */
   COORIP_CONV_Init ( mas_imanum, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Convert from master (row, col) to (lat, lon, h)
   ========================================================================== */
   for ( i=0; i<IREGPV_gcp[ mas_gridnum ].n_gcp; i++ ) {
      COORIP_CONV_rc_llh ( &(IREGPV_gcp[ mas_gridnum ].gcp_arr[ i ].coor),
                           (INTx4)mas_imanum, &(geo_grid[ i ]), status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      geo_grid[ i ].h = 0.;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_MasRowCol2LatLon */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SlaveGCP

        $TYPE         PROCEDURE

        $INPUT        imanum   : image number among the others of the tool
                      gridnum  : grid number among the others of the tool
                      geo_grid : grid of geodetic values

        $MODIFIED     The global structure with the GCPs info is filled

        $OUTPUT       NONE

        $GLOBAL       IREGPV_gcp[gridnum]       : the structure with the GCPs
                                                  info
                      IANNIV_ImageAnnot[imanum] : the structure with the image
                                                  annotations

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_grid_number_out

        $DESCRIPTION  This procedure fills the slave GCPs info structure

        $WARNING      NONE

        $PDL          - Checks the image number
                      - Evaluates the number of GCPs
                      - Loop over the master GCPs
                            - Converts the GCP geodetic coordinates into
                              image coordinates in the slave reference system
                            - If the point is internal to the image range
                                  - Puts the GCP flag to TRUE
                                  - Increments the counter of valid GCP in the
                                    image
                            - Endif
                      - End loop
                      - Fill the number of GCP in the GCP info structure

   $EH
   ========================================================================== */

void IREGPP_GCPE_SlaveGCP
                        (/*IN    */ INTx4                imanum,
                         /*IN    */ INTx4                gridnum,
                         /*IN    */ MATHIT_LLH          *geo_grid,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_SlaveGCP";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 mas_gnum = 0;
   UINTx4                 pt;
   INTx4                  Ngcp;
   UINTx4                 count = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( ( imanum < 0 ) || ( imanum > IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out, "" );
   }

/* ==========================================================================
   Check the grid number
   ========================================================================== */
   if ( ( gridnum < 0 ) || ( gridnum > IREGPD_max_img ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_grid_number_out, "" );
   }

/* ==========================================================================
   Set the number of GCPs
   ========================================================================== */
   Ngcp = IREGPV_gcp[ mas_gnum ].n_gcp;

/* ==========================================================================
   Initialize the slave coordinates conversions
   ========================================================================== */
   COORIP_CONV_Init ( imanum, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Loop over the grid point
   ========================================================================== */
   for ( pt=0; pt<Ngcp; pt++ ) {

/* ==========================================================================
   Convert the (lat, lon) coordinates into (row, col ) coordinates
   ========================================================================== */
      COORIP_CONV_llh_rc ( &(geo_grid[ pt ]), imanum,
                           &(IREGPV_gcp[ gridnum ].gcp_arr[ pt ].coor),
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check if the point is internal or not to the image
   ========================================================================== */
      if ( ( ( IREGPV_gcp[ gridnum ].gcp_arr[ pt ].coor.row >= 0. ) &&
             ( IREGPV_gcp[ gridnum ].gcp_arr[ pt ].coor.row <
                IANNIV_ImageAnnot[ imanum ].ImageLength ) ) &&
           ( ( IREGPV_gcp[ gridnum ].gcp_arr[ pt ].coor.col >= 0. ) &&
             ( IREGPV_gcp[ gridnum ].gcp_arr[ pt ].coor.col <
                IANNIV_ImageAnnot[ imanum ].ImageWidth ) ) ) {
         IREGPV_gcp[ gridnum ].gcp_arr[ pt ].valid = TRUE;
         count ++;
      }
   }

/* ==========================================================================
   Fill the GCP number
   ========================================================================== */
   IREGPV_gcp[ gridnum ].n_gcp = count;

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_SlaveGCP */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CellExtraction

        $TYPE         PROCEDURE

        $INPUT        inp_io    : input file descriptor
                      centre    : centre coordinates of the cell to extract
                      NRowInp   : number of rows to extract
                      NColInp   : number of columns to extract
                      imanum    : image ID
                      filler    : value to fill the out of borders pixel of the
                                  image

        $MODIFIED     valid     : flag indicating if the GCP is valid or not
                                  through three possible values that it returns:
                                  - value: 0      the cell has a portion
                                                  external to the image
                                  - value: 1      the cell is all inside the
                                                  image
                                  - value: - 1    the image is all out of image
                                                  borders

        $OUTPUT       ImageCell : image cell

        $GLOBAL       IREGID_MaxImaNum            : maximum number of images that
                                                  can be treated in the SAR -
                                                  Toolbox
                      IANNIV_ImageAnnot[imanum] : structure with the <imanum>
                                                  images INFO

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_null_cell_dim
                      ERRSID_IREG_cell_dim_out
                      ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure extract an image cell from a specified
                      image file channel. If the cell is not all inside the
                      image borders, the outlayer part is filled with a <filler>
                      value

        $WARNING      NONE

        $PDL          - Checks the image ID
                      - Checks the number of image rows and columns
                      - Evaluates the number of columns elements in a row
                        considering two for the complex images
                      - Loop over the image cell rows
                            - Loop over the image cell columns
                                  - Fills the image element with the filler
                                    value
                            - End loop
                      - End loop
                      - Evaluates the starting and stopping row and column
                        indices of the image cell to extract
                      - If the block is outside the image
                            - The flag is set to invalid
                      - Else If the block is part inside part out of the image
                            - Resets the extreems of the cell
                            - Opens the read mode of the input file
                            - Reads the image block
                            - Closes the read mode of the input file
                            - Sets the flag to 0
                      - Else If the block is inside the image
                            - Resets the extreems of the cell
                            - Opens the read mode of the input file
                            - Reads the image block
                            - Closes the read mode of the input file
                            - Sets the flag to 1
                      - End

   $EH
   ========================================================================== */

void IREGPP_GCPE_CellExtraction
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ MATHIT_RC            centre,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ INTx1                imanum,
                         /*IN    */ float                filler,
                         /*   OUT*/ INTx1               *valid,
                         /*   OUT*/ float              **ImageCell,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_CellExtraction";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  start_row;
   INTx4                  start_col;
   INTx4                  stop_row;
   INTx4                  stop_col;
   INTx4                  true_start_row;
   INTx4                  true_start_col;
   INTx4                  true_stop_row;
   INTx4                  true_stop_col;
   INTx4                  NLines;
   INTx4                  NColumns;
   INTx4                  StartR;
   INTx4                  StartC;
   INTx4                  row;
   INTx4                  col;
   void                  *p = (void *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( ( imanum < 0 ) || ( imanum >= IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out, "" );
   }

/* ==========================================================================
   Check the number of rows and columns of the image cell
   ========================================================================== */
   if ( ( NRowInp < 1 ) || ( NColInp < 1 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_cell_dim, "" );
   }
/*
   if ( ( NRowInp > IANNIV_ImageAnnot[ imanum ].ImageLength ) ||
        ( NColInp > IANNIV_ImageAnnot[ imanum ].ImageWidth ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_cell_dim_out, "" );
   }
*/

/* ==========================================================================
   Evaluate the cell extreems
   ========================================================================== */
   start_row = (INTx4)centre.row - (INTx4)(NRowInp / 2.);
   start_col = (INTx4)centre.col - (INTx4)(NColInp / 2.);
   stop_row = start_row + NRowInp - 1;
   stop_col = start_col + NColInp - 1;

/* ==========================================================================
   Check the cell position in the image
   ========================================================================== */
   if ( ( stop_row < 0 ) || ( stop_col < 0 ) ||
        ( start_row >= IANNIV_ImageAnnot[ imanum ].ImageLength ) ||
        ( start_col >= IANNIV_ImageAnnot[ imanum ].ImageWidth ) ) {

/* ==========================================================================
   Out of borders at all
   ========================================================================== */
      *valid = - 1;
   }
   else {
      if ( ( start_row < 0 ) ||
        ( stop_row >= IANNIV_ImageAnnot[ imanum ].ImageLength ) ||
        ( start_col < 0 ) ||
        ( stop_col >= IANNIV_ImageAnnot[ imanum ].ImageWidth ) ) {

/* ==========================================================================
   The cell is on the borders.
   Reset the coordinates
   ========================================================================== */
         if ( start_row < 0 ) {
            true_start_row = 0;
         }
         else {
            true_start_row = start_row;
         }

         if ( stop_row >= IANNIV_ImageAnnot[ imanum ].ImageLength ) {
            true_stop_row = IANNIV_ImageAnnot[ imanum ].ImageLength - 1;
         }
         else {
            true_stop_row = stop_row;
         }
         if ( start_col < 0 ) {
            true_start_col = 0;
         }
         else {
            true_start_col = start_col;
         }
         if ( stop_col >= IANNIV_ImageAnnot[ imanum ].ImageWidth ) {
            true_stop_col = IANNIV_ImageAnnot[ imanum ].ImageWidth - 1;
         }
         else {
            true_stop_col = stop_col;
         }

/* ==========================================================================
   Set the validity flag
   ========================================================================== */
         *valid = 0;
      }
      else {

/* ==========================================================================
   The cell is all inside the image
   Reset the coordinates
   ========================================================================== */
         true_start_row = start_row;
         true_stop_row = stop_row;
         true_start_col = start_col;
         true_stop_col = stop_col;

/* ==========================================================================
   Set the validity flag
   ========================================================================== */
         *valid = 1;
      }
   }

/* ==========================================================================
   Extract the cell
   ========================================================================== */
   if ( (*valid) >= 0 ) {

/* ==========================================================================
   Open the read line mode for the input file
   ========================================================================== */
      GIOSIP_open_line ( inp_io, 'x', true_start_col, true_stop_col,
                         status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the number of rows and columns to read
   ========================================================================== */
      NLines = true_stop_row - true_start_row + 1;
      NColumns = true_stop_col - true_start_col + 1;

/* ==========================================================================
   Reset the starting rows and columns
   ========================================================================== */
      StartR = true_start_row - start_row;
      StartC = true_start_col - start_col;

/* ==========================================================================
   Loop over the image lines
   ========================================================================== */
      for ( row=0; row<NLines; row++ ) {

/* ==========================================================================
   Read the image line
   ========================================================================== */
         GIOSIP_read_line ( inp_io, (UINTx4)(row + true_start_row), (INTx4)0,
                            &p, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Copy the line in the output image cell
   ========================================================================== */
         switch ( inp_io->dt ) {
            case LDEFIE_dt_UINTx1:
               for ( col=0; col<NColumns; col++ ) {
                  ImageCell[ StartR + row ][ StartC + col ] = (float )
                     ((UINTx1 *)p)[ col ];
               }
            break;
            case LDEFIE_dt_UINTx2:
               for ( col=0; col<NColumns; col++ ) {
                  ImageCell[ StartR + row ][ StartC + col ] = (float)
                     ((UINTx2 *)p)[ col ];
               }
            break;
            case LDEFIE_dt_2_INTx2:
               for ( col=0; col<NColumns; col++ ) {
                  ImageCell[ StartR + row ][ 2 * ( StartC + col ) ] = (float)
                     ((INTx2 *)p)[ 2 * col ];
                  ImageCell[ StartR + row ][ 2 * ( StartC + col ) + 1 ] =
                     (float)(((INTx2 *)p)[ 2 * col + 1 ]);
               }
            break;
            case LDEFIE_dt_float:
               for ( col=0; col<NColumns; col++ ) {
                  ImageCell[ StartR + row ][ StartC + col ] =
                     ((float *)p)[ col ];
               }
            break;
            case LDEFIE_dt_2_float:
               for ( col=0; col<NColumns; col++ ) {
                  ImageCell[ StartR + row ][ 2 * ( StartC + col ) ] =
                     ((float *)p)[ 2 * col ];
                  ImageCell[ StartR + row ][ 2 * ( StartC + col ) + 1 ] =
                     ((float *)p)[ 2 * col + 1 ];
               }
            break;
            default:
               ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                                  "for the co-registration tool" );
         }
      }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
      GIOSIP_close_line ( inp_io, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code,
                          &log_status_code );

}/* IREGPP_GCPE_CellExtraction */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FillImaCell

        $TYPE         PROCEDURE

        $INPUT        NRowInp   : number of rows of the image cell
                      NColInp   : number of columns of the image cell
                      DataType  : data type of the image cell
                      filler    : value with which to fill the outer part of
                                  the image cell

        $MODIFIED     ImageCell : image cell

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure fills the image cell to give in output

        $WARNING      NONE

        $PDL          - Evaluates the number of elements of the column
                      - Switch over the data type
                            - Loop over the cell rows
                                  - Loop over the columns of the row
                                        - Fills the cell element
                                  - End loop
                            - End loop
                      - End switch

   $EH
   ========================================================================== */

void IREGPP_GCPE_FillImaCell
                        (/*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ float                filler,
                         /*IN OUT*/ void               **ImageCell,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_FillImaCell";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Fill the image cell with the filler value
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_2_INTx2:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               ((INTx2 **)ImageCell)[ row ][ 2 * col ] = (INTx2)filler;
               ((INTx2 **)ImageCell)[ row ][ 2 * col + 1 ] = (INTx2)filler;
            }
         }
      break;
      case LDEFIE_dt_UINTx2:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               ((UINTx2 **)ImageCell)[ row ][ col ] = (UINTx2)filler;
            }
         }
      break;
      case LDEFIE_dt_float:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               ((float **)ImageCell)[ row ][ col ] = (float)filler;
            }
         }
      break;
      case LDEFIE_dt_2_float:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               ((float **)ImageCell)[ row ][ 2 * col ] = (float)filler;
               ((float **)ImageCell)[ row ][ 2 * col + 1 ] = (float)filler;
            }
         }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                            "for the co-registration tool" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_FillImaCell */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_PointSubMatrix

        $TYPE         PROCEDURE

        $INPUT        DataType  : input data type
                      ImageCell : image block
                      NLines    : number of lines of the image block to copy
                      StartR    : starting row to point
                      StartC    : starting column to point

        $MODIFIED     NONE

        $OUTPUT       p         : array of pointers to the image block rows

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure makes an array of pointers to point to
                      the first elements of the rows of the sub matrix starting
                      in <StartR>, <StartC> element

        $WARNING      NONE

        $PDL          - Switch over data types
                            - Loop over the rows of the sub matrix
                                  - Point the array of pointers element to the
                                    first element of the sub matrix row
                            - End loop
                      - End switch

   $EH
   ========================================================================== */

void IREGPP_GCPE_PointSubMatrix
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ void               **ImageCell,
                         /*IN    */ INTx4                NLines,
                         /*IN    */ INTx4                StartR,
                         /*IN    */ INTx4                StartC,
                         /*   OUT*/ void               **p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_PointSubMatrix";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Switch over data types
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_2_INTx2:
         for ( row=0; row<NLines; row++ ) {
            p[ row ] = (void *)&(((INTx2 **)ImageCell)[ StartR + row ]
                                               [ 2 * StartC ]);
         }
      break;
      case LDEFIE_dt_UINTx2:
         for ( row=0; row<NLines; row++ ) {
            p[ row ] = (void *)&(((UINTx2 **)ImageCell)[ StartR + row ]
                                                [ StartC ]);
         }
      break;
      case LDEFIE_dt_float:
         for ( row=0; row<NLines; row++ ) {
            p[ row ] = (void *)&(((float **)ImageCell)[ StartR + row ]
                                               [ StartC ]);
         }
      break;
      case LDEFIE_dt_2_float:
         for ( row=0; row<NLines; row++ ) {
            p[ row ] = (void *)&(((float **)ImageCell)[ StartR + row ]
                                               [ 2 * StartC ]);
         }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                            "for the co-registration tool" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_PointSubMatrix */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_RotAngleEval

        $TYPE         PROCEDURE

        $INPUT        mas_imanum : number identifing the master image
                      sla_imanum : number identifing the slave image

        $MODIFIED     NONE

        $OUTPUT       alpha      : angle of rotation between the two images
                                   (master and slave) in radians

        $GLOBAL       IANNIV_ImageAnnot : structure with the information about
                                          the images

        $RET_STATUS   ERRSID_IREG_image_number_out

        $DESCRIPTION  This procedure evaluates the angle between the orbits of
                      the two images

        $WARNING      THE STRUCTURES IANNIV_ImageAnnot OF THE TWO IMAGES MUST
                      BE FILLED BEFORE CALLING THIS PROCEDURE BY
                      IANNIP_GETP_ImageAnnotation

        $PDL 

   $EH
   ========================================================================== */

void IREGPP_GCPE_RotAngleEval
                        (/*IN    */ INTx1                mas_imanum,
                         /*IN    */ INTx1                sla_imanum,
                         /*   OUT*/ double              *alpha,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_RotAngleEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   MATHIT_RC              mas_vx;
   MATHIT_RC              mas_vy;
   MATHIT_RC              sla_p[ 3 ];
   MATHIT_LLH             point[ 3 ];
   double                 alpha_y;
   double                 alpha_x;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Checks the image numbers
   ========================================================================== */
   if ( ( mas_imanum < 0 ) || ( mas_imanum >= IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out,
                         "master image" );
   }
   if ( ( sla_imanum < 0 ) || ( sla_imanum >= IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out,
                         "slave image" );
   }

/* ==========================================================================
   Zero the arrays
   ========================================================================== */
   memset ( (void *)point, 0, (size_t)(3 * sizeof (MATHIT_LLH)) );

/* ==========================================================================
   Fill the versor of the master directions
   ========================================================================== */
   mas_vy.row = (double)1;
   mas_vy.col = (double)0;
   mas_vx.row = (double)0;
   mas_vx.col = (double)1;

/* ==========================================================================
   Converts the slave corners into geodetic coordinates
   ========================================================================== */
   IREGPP_GCPE_SlaveCorners ( sla_imanum, sla_p, point, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Zero the array to contain the row, col point coordinates
   ========================================================================== */
   memset ( (void *)sla_p, 0, (size_t)(3 * sizeof (MATHIT_RC)) );

/* ==========================================================================
   Converts the slave coordinates into row, col coordinates in the master
   reference system
   ========================================================================== */
   IREGPP_GCPE_SlaveToMaster ( mas_imanum, point, sla_p, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluates the angle between the y axes ...
   ========================================================================== */
   IREGPP_GCPE_AngleEval ( mas_vy, sla_p[ 1 ], sla_p[ 0 ], &alpha_y,
                           status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   ... and the x axes
   ========================================================================== */
   IREGPP_GCPE_AngleEval ( mas_vx, sla_p[ 2 ], sla_p[ 0 ], &alpha_x,
                           status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Makes the averaged value of the angle
   ========================================================================== */
   *alpha = ( alpha_x + alpha_y ) / 2.;

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_RotAngleEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SlaveCorners

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID number identifing the slave image
                      points_rc  : array with the row, col coordinates of the
                                   top left, top rigth and bottom left corners
                                   in the slave reference system

        $MODIFIED     NONE

        $OUTPUT       points_llh : array with the geodetic coordinates of the
                                   top left, top rigth and bottom left corners

        $GLOBAL       IANNIV_ImageAnnot : the structure with the global image
                                          info

        $RET_STATUS   ERRSID_IREG_image_number_out

        $DESCRIPTION  This procedure converts the top left, top rigth and
                      bottom left slave image corners from row, col coordinates
                      to geodetic coordinates

        $WARNING      NONE

        $PDL          - Initializes the coordinates conversions for the slave
                        image
                      - Fills the row, col coordinates of the top left corner
                      - Converts them into geodetic ones
                      - Fills the row, col coordinates of the top rigth corner
                      - Converts them into geodetic ones
                      - Fills the row, col coordinates of the bottom left corner
                      - Converts them into geodetic ones

   $EH
   ========================================================================== */

void IREGPP_GCPE_SlaveCorners
                        (/*IN    */ INTx1                imanum,
                         /*IN    */ MATHIT_RC           *points_rc,
                         /*   OUT*/ MATHIT_LLH          *points_llh,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_SlaveCorners";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image ID
   ========================================================================== */
   if ( ( imanum < 0 ) || ( imanum >= IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out, "" );
   }

/* ==========================================================================
   Initialize the coordinates conversions for the slave image
   ========================================================================== */
   COORIP_CONV_Init ( imanum, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate three corners geodetic coordinates
   ========================================================================== */

   /* top left corner */
   points_rc[ 0 ].row = (double)0;
   points_rc[ 0 ].col = (double)0;
   COORIP_CONV_rc_llh ( points_rc, imanum, points_llh, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* bottom left corner */
   points_rc[ 1 ].row = (double)(IANNIV_ImageAnnot[ imanum ].ImageLength - 1);
   points_rc[ 1 ].col = (double)0;
   COORIP_CONV_rc_llh ( &points_rc[ 1 ], imanum, &points_llh[ 1 ],
                        status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* top rigth corner */
   points_rc[ 2 ].row = (double)0;
   points_rc[ 2 ].col = (double)(IANNIV_ImageAnnot[ imanum ].ImageWidth - 1);
   COORIP_CONV_rc_llh ( &points_rc[ 2 ], imanum, &points_llh[ 2 ],
                        status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_SlaveCorners */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SlaveToMaster

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID number identifing the master image
                      points_llh : array with the geodetic coordinates of the
                                   top left, top rigth and bottom left corner

        $MODIFIED     NONE

        $OUTPUT       points_rc  : array with the row, col coordinates of the
                                   top left, top rigth and bottom left corners
                                   in the master reference system

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_image_number_out

        $DESCRIPTION  This procedure converts the slave corners in geodetic
                      coordinates into row, col master reference system

        $WARNING      NONE

        $PDL          - Initializes the maser coordinates conversions
                      - Converts the top left corner
                      - Converts the top rigth corner
                      - Converts the bottom left corner

   $EH
   ========================================================================== */

void IREGPP_GCPE_SlaveToMaster
                        (/*IN    */ INTx1                imanum,
                         /*IN    */ MATHIT_LLH          *points_llh,
                         /*   OUT*/ MATHIT_RC           *points_rc,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_SlaveToMaster";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image ID
   ========================================================================== */
   if ( ( imanum < 0 ) || ( imanum >= IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out, "" );
   }

/* ==========================================================================
   Init the coordinates conversions in the master reference frame
   ========================================================================== */
   COORIP_CONV_Init ( imanum, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Convert the top left corner
   ========================================================================== */
   COORIP_CONV_llh_rc ( points_llh, imanum, points_rc, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Convert the bottom left corner
   ========================================================================== */
   COORIP_CONV_llh_rc ( &points_llh[ 1 ], imanum, &points_rc[ 1 ],
                        status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Convert the top rigth corner
   ========================================================================== */
   COORIP_CONV_llh_rc ( &points_llh[ 2 ], imanum, &points_rc[ 2 ],
                        status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_SlaveToMaster */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_AngleEval

        $TYPE         PROCEDURE

        $INPUT        vers1     : versor of one of the axis
                      point1    : coordinates in row, col of the first corner
                      point2    : coordinates in row, col of the second corner

        $MODIFIED     NONE

        $OUTPUT       angle_rad : angle between the axes in radians

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the angle between two vectors
                      definited the first through its versor, the other through
                      two points of the vector describing the direction

        $WARNING      NONE

        $PDL          - Evaluates the versor to the second direction
                      - Makes the scalar product of the two versor of the two
                        directions
                      - Evaluates the angle between the two
                      - Makes a 3D vector with x and y on the (row, col) plane
                        (x = col, y = row, z = 0) for the first versor
                      - Makes the analogous for the second versor
                      - Makes the cross product of the two vectors
                      - If the z component of the cross product vector is lesser
                        than zero, changes the angle sign

   $EH
   ========================================================================== */

void IREGPP_GCPE_AngleEval
                        (/*IN    */ MATHIT_RC            vers1,
                         /*IN    */ MATHIT_RC            point1,
                         /*IN    */ MATHIT_RC            point2,
                         /*   OUT*/ double              *angle_rad,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_AngleEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   MATHIT_RC              vers2;
   double                 prod;
   MATHIT_XYZ             vect1;
   MATHIT_XYZ             vect2;
   MATHIT_XYZ             cross_p;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the versor
   ========================================================================== */
   MATHIP_STYP_RCSubt ( point1, point2, &vers2, status_code );
   MATHIP_STYP_RCVers ( vers2, &vers2, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the angle between the axes
   ========================================================================== */
   MATHIP_STYP_RCScalProd ( vers1, vers2, &prod, status_code );
   *angle_rad = ACOS ( prod );

/* ==========================================================================
   Fill the first vector
   ========================================================================== */
   vect1.x = vers2.col;
   vect1.y = vers2.row;
   vect1.z = (double)0;

/* ==========================================================================
   Fill the second vector
   ========================================================================== */
   vect2.x = vers1.col;
   vect2.y = vers1.row;
   vect2.z = (double)0;

/* ==========================================================================
   Make the cross product
   ========================================================================== */
   MATHIP_STYP_XYZCrosProd ( vect1, vect2, &cross_p, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Set the sign of the angle
   ========================================================================== */
   if ( cross_p.z < 0 ) {
      *angle_rad = - *angle_rad;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_AngleEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CellExtractor

        $TYPE         PROCEDURE

        $INPUT        inp_io       : input file descriptor
                      centre       : centre coordinates of the cell to
                                     extract
                      NRowInp      : number of rows to extract
                      NColInp      : number of columns to extract
                      imanum       : image ID
                      filler       : value to fill the out of borders pixel
                                     of the image
                      RotAngle_rad : angle of rotation (in radians) of which
                                     the cell must be rotated

        $MODIFIED     NONE

        $OUTPUT       valid     : flag indicating if the GCP is valid or not
                                  through three possible values that it returns:
                                  - value: 0      the cell has a portion
                                                  external to the image
                                  - value: 1      the cell is all inside the
                                                  image
                                  - value: - 1    the image is all out of image
                                                  borders

                      ImageCell : output image cell

        $GLOBAL       IREGID_MaxImaNum            : maximum number of images that
                                                  can be treated in the SAR -
                                                  Toolbox
                      IANNIV_ImageAnnot[imanum] : structure with the <imanum>
                                                  images INFO

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_null_cell_dim
                      ERRSID_IREG_cell_dim_out
                      ERRSID_IREG_err_mem_alloc
                      ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure extract an image cell from the file
                      described by the <inp_io> descriptor, and, if necessary,
                      rotates it by the indicated angle in anticlockwise
                      direction if positive

        $WARNING      THE OUTPUT IMAGE CELL IS ALWAYS OF TYPE float ( OR 2
                      TIMES float IF COMPLEX )

        $PDL          - Checks the image ID number
                      - Checks the number of rows and columns of the cell
                      - Sets the parameters indicating the input image data
                        type and size
                      - If the angle of rotation is almost null
                            - Allocates a temporary matrix
                            - Extracts a cell of the wanted dimensions centered
                              in the centre coordinates and of the same type of
                              the input image
                            - Evaluates the number of row elements (
                              considering two if the image is complex )
                      - Else If
                            - Evaluates the half diagonal of the cell
                            - Evaluates the number of elements of the cell
                              of dimensions equals to the diagonal
                            - Allocates the enlarged cell and the grid for the
                              interpolation
                            - Fills the rotation grid with the coordinates of
                              the points of the rotated cell
                            - Extracts the enlarged cell of the same data type
                              of the input one
                            - Makes a bilinear interpolation of the cell
                      - End If
                      - Deallocates the allocated memories

   $EH
   ========================================================================== */

void IREGPP_GCPE_CellExtractor
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ MATHIT_RC            centre,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ INTx1                imanum,
                         /*IN    */ float                filler,
                         /*IN    */ double               RotAngle_rad,
                         /*   OUT*/ INTx1               *valid,
                         /*   OUT*/ float              **ImageCell,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_CellExtractor";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double                 h_diag;
   float                **EnlargedCell = (float **)NULL;
   size_t                 elem_size;
   INTx4                  NElem;
   UINTx4                 NElemEnl;
   INTx4                  row;
   INTx4                  col;
   double                 rp;
   double                 cp;
   MATHIT_RC_float      **rot_grid = (MATHIT_RC_float **)NULL;
   LDEFIT_data_type       ima_type;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image ID number
   ========================================================================== */
   if ( ( imanum < 0 ) || ( imanum >= IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out, "" );
   }

/* ==========================================================================
   Check the number of required rows and columns
   ========================================================================== */
   if ( ( NRowInp < 1 ) || ( NColInp < 1 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_cell_dim, "" );
   }
/*
   if ( ( NRowInp > IANNIV_ImageAnnot[ imanum ].ImageLength ) ||
        ( NColInp > IANNIV_ImageAnnot[ imanum ].ImageWidth ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_cell_dim_out, "" );
   }
*/

/* ==========================================================================
   Set the element size and data type
   ========================================================================== */
   if ( inp_io->spp == 2 ) {
      ima_type = LDEFIE_dt_2_float;
      elem_size = 2 * sizeof (float);
   }
   else {
      ima_type = LDEFIE_dt_float;
      elem_size = sizeof (float);
   }
   IREGPP_GCPE_FillImaCell ( NRowInp, NColInp, ima_type, filler,
                             (void **)ImageCell, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Switch over the rotation angle
   ========================================================================== */
   if ( ABS ( RotAngle_rad ) < IREGPD_rot_ang_min ) {

/* ==========================================================================
   No rotation
   ========================================================================== */
      IREGPP_GCPE_CellExtraction ( inp_io, centre, NRowInp, NColInp, imanum,
                                   filler, valid, ImageCell, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }
   else {

/* ==========================================================================
   Rotation applied.
   Evaluate the diagonal of the square circumscribed to the circle having as
   radius the cell diagonal
   ========================================================================== */
      h_diag = ceil ( 0.5 * sqrt ( POW ( NRowInp, 2 ) + POW ( NColInp, 2 ) ) );
      NElemEnl = (UINTx4)(2 * h_diag + 1);

/* ==========================================================================
   Allocate the necessary memories
   ========================================================================== */
      IREGPP_GCPE_EnlCellAndGridAlloc ( NElemEnl, elem_size, NRowInp, NColInp,
                                        &EnlargedCell, &rot_grid, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the rotated grid
   ========================================================================== */
      IREGPP_GCPE_FillRotGrid ( NRowInp, NColInp, RotAngle_rad, rot_grid,
                                status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Extract the enlarged cell
   ========================================================================== */
      IREGPP_GCPE_CellExtraction ( inp_io, centre, NElemEnl, NElemEnl, imanum,
                                   filler, valid, EnlargedCell, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Rotate the cell with a bilinear interpolation
   ========================================================================== */
      MATHIP_INTR_Bilinear ( (void **)EnlargedCell, NElemEnl, NElemEnl,
                             rot_grid, NRowInp, NColInp, filler, ima_type,
                             (void **)ImageCell, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   if ( EnlargedCell != (float **)NULL ) {
      for ( row=0; row<NElemEnl; row++ ) {
         MEMSIP_free ( (void **)&( EnlargedCell[ row ] ) );
      }
      MEMSIP_free ( (void **)&EnlargedCell );
   }

   if ( rot_grid != (MATHIT_RC_float **)NULL ) {
      for ( row=0; row<NRowInp; row++ ) {
         MEMSIP_free ( (void **)&( rot_grid[ row ] ) );
      }
      MEMSIP_free ( (void **)&rot_grid );
   }

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_CellExtractor */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ElemSizeEval

        $TYPE         PROCEDURE

        $INPUT        DataType  : input data type

        $MODIFIED     NONE

        $OUTPUT       elem_size : size in bytes of a row element

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure fills two variables indicating the
                      element data size in bytes of an image

        $WARNING      NONE

        $PDL          - Evaluates the number of elements (time 2 if the
                        input image is complex)
                      - Switches over the image data type
                            - Sets the element size in bytes
                      - End switch

   $EH
   ========================================================================== */

void IREGPP_GCPE_ElemSizeEval
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ size_t              *elem_size,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_ElemSizeEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the element size
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx1:
         *elem_size = sizeof (UINTx1);
      break;
      case LDEFIE_dt_UINTx2:
         *elem_size = sizeof ( UINTx2 );
      break;
      case LDEFIE_dt_2_INTx2:
         *elem_size = 2 * sizeof ( INTx2 );
      break;
      case LDEFIE_dt_float:
         *elem_size = sizeof ( float );
      break;
      case LDEFIE_dt_2_float:
         *elem_size = 2 * sizeof ( float );
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                            "for the co-registration tool" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_ElemSizeEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_EnlCellAndGridAlloc

        $TYPE         PROCEDURE

        $INPUT        NElem        : number of rows and columns of the cell
                      elem_size    : size in bytes of the image element
                      NGridRow     : number of rows of points for the grid
                      NGridCol     : number of columns of points for the grid

        $MODIFIED     NONE

        $OUTPUT       ImageCell    : image cell to allocate
                      rot_grid     : grid to allocate

        $GLOBAL       MATHIT_RC : the row, columns type

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure allocates the image cell to extract and
                      the grid of points for the interpolation

        $WARNING      NONE

        $PDL          - Allocates the array of pointers for the image cell
                      - Loop over the rows of the image cell
                            - Allocates the row of elements
                      - End Loop
                      - Loop over the rows of the grid points
                            - Allocates the row of grid points
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_GCPE_EnlCellAndGridAlloc
                        (/*IN    */ UINTx4               NElem,
                         /*IN    */ size_t               elem_size,
                         /*IN    */ UINTx4               NGridRow,
                         /*IN    */ UINTx4               NGridCol,
                         /*   OUT*/ float             ***ImageCell,
                         /*   OUT*/ MATHIT_RC_float   ***rot_grid,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_EnlCellAndGridAlloc";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Allocate the enlarged cell
   ========================================================================== */
   if ( ( *ImageCell = ( float **)MEMSIP_alloc ( (size_t)(NElem *
						 sizeof (float *)) ) ) ==
	(float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
			 "in the enlarged cell" );
   }
   for ( row=0; row<NElem; row++ ) {
      (*ImageCell)[ row ] = (float *)NULL;
      if ( ( (*ImageCell)[ row ] = (float *)MEMSIP_alloc ( (size_t)(NElem *
							  elem_size) ) ) ==
	   (float *)NULL ) {
	 ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
			    "in the enlarged cell" );
      }
   }

/* ==========================================================================
   Allocated the interpolation grid
   ========================================================================== */
   if ( ( *rot_grid = (MATHIT_RC_float **)MEMSIP_alloc ( (size_t)(NGridRow *
                                             sizeof (MATHIT_RC_float *)) ) ) ==
	(MATHIT_RC_float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
			 "in the interpolation grid" );
   }
   for ( row=0; row<NGridRow; row++ ) {
      (*rot_grid)[ row ] = (MATHIT_RC_float *)NULL;
      if ( ( (*rot_grid)[ row ] = (MATHIT_RC_float *)MEMSIP_alloc ( (size_t)
                                   (NGridCol * sizeof (MATHIT_RC_float)) ) ) ==
	   (MATHIT_RC_float *)NULL ) {
	 ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
			    "in the interpolation grid" );
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_EnlCellAndGridAlloc */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FillRotGrid

        $TYPE         PROCEDURE

        $INPUT        NRowInp   : number of rows of points to fill
                      NColInp   : number of columns of points to fill
                      Angle_rad : angle of rotation

        $MODIFIED     NONE

        $OUTPUT       Grid      : grid of points to be used for the
                                  interpolation

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the grid with the value of the pixels
                      coordinates rotated by the angle <Angle_rad>

        $WARNING      NONE

        $PDL          - Loop over the grid rows
                            - Evaluates the not rotated row coordinate
                            - Evaluates the part of the rotated row coordinate
                              depending by the not rotated row coordinate
                            - Evaluates the part of the rotated column
                              coordinate depending by the not rotated row
                              coordinate
                            - Loop over the grid columns
                                  - Evaluates the not rotated column coordinate
                                  - Sums to the rotated row coordinate the part
                                    depending by the not rotated column
                                    coordinate
                                  - Sums to the rotated column coordinate the
                                    part depending by the not rotated column
                                    coordinate
                            - End Loop
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_GCPE_FillRotGrid
                        (/*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ double               Angle_rad,
                         /*IN OUT*/ MATHIT_RC_float    **Grid,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_FillRotGrid";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double                 h_diag;
   double                 rp;
   double                 cp;
   INTx4                  row;
   INTx4                  col = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the half diagonal
   ========================================================================== */
   h_diag = ceil ( 0.5 * sqrt ( POW ( NRowInp, 2 ) + POW ( NColInp, 2 ) ) );

/* ==========================================================================
   Fill the rotated grid
   ========================================================================== */
   for ( row=0; row<NRowInp; row++ ) {
      rp = (double)row - (double)((INTx4)(NRowInp / 2.));
      for ( col=0; col<NColInp; col++ ) {
         cp = (double)col - (double)((INTx4)(NColInp / 2.));
         Grid[ row ][ col ].row = (float)(rp * cos ( Angle_rad ) -
            cp * sin ( Angle_rad ) + h_diag);
         Grid[ row ][ col ].col = (float)(rp * sin ( Angle_rad ) +
            cp * cos ( Angle_rad ) + h_diag);
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_FillRotGrid */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ShiftEvaluation

        $TYPE         PROCEDURE

        $INPUT        master_fft : FFT of the absolute value of the master cell
                                   to correlate
                      SlaveCell  : slave image cell to correlate
                      DataType   : flag indicating the image data type

        $MODIFIED     NONE

        $OUTPUT       Shift
                      QualityFlag : quality flag value indicating the goodness
                                    of the correlation

        $GLOBAL       IREGPV_coarse_cell_dim_row : dimension in the row direction of
                                            the image cell
                      IREGPV_coarse_cell_dim_col : dimension in the columns direction
                                            of the image cell
                      IREGPV_int_fact_row : interpolation factor in the row
                                            direction
                      IREGPV_int_fact_col : interpolation factor in the column
                                            direction

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the shift in the row and column
                      directions between two image cells using the maximum peak
                      of the cross-correlation matrix between them

        $WARNING      NONE

        $PDL          - Evaluates the dimensions of the temporary arrays
                      - Fills the array of the slave cell with the rows of
                        the slave matrix stored sequentially
                      - Evaluates the complex array with the absolute value of
                        the slave one in the real part
                      - Makes the direct FFT of the modulus of the slave cell
                      - Makes the conjugate of the FFT
                      - Makes the cross correlation matrix as the product of
                        the master and slave cells
                      - Interpolates the cross correlaction matrix by the
                        wanted interpolation factors vis zero-padding
                      - Makes the inverse FFT of the interpolated cross 
                        correlation matrix
                      - Finds the index of the maximum value in the absolute
                        value interpolated cross correlation matrix
                      - Evaluates the rescaled shifts values

   $EH
   ========================================================================== */

void IREGPP_GCPE_ShiftEvaluation
                        (/*IN    */ MATHIT_array         master_fft,
                         /*IN    */ void               **SlaveCell,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_RC           *Shift,
                         /*   OUT*/ float               *QualityFlag,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_ShiftEvaluation";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   MATHIT_array           cross_corr;
   MATHIT_array           int_corr;
   MATHIT_array           slave_fft;
   INTx4                  NElements;
   INTx4                  NElementsInt;
   INTx4                  NRowInt;
   INTx4                  NColInt;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the dimensions variables
   ========================================================================== */
   NElements = (INTx4)(IREGPV_coarse_cell_dim_row * IREGPV_coarse_cell_dim_col);
   NRowInt = (INTx4)(IREGPV_coarse_cell_dim_row * IREGPV_int_fact_row);
   NColInt = (INTx4)(IREGPV_coarse_cell_dim_col * IREGPV_int_fact_col);
   NElementsInt = (INTx4)(NRowInt * NColInt);

/* ==========================================================================
   Allocate the slave array memory
   ========================================================================== */
   MATHIP_VECT_Make ( NElements, MATHIE_complex, &slave_fft, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Allocate the cross correlation matrix
   ========================================================================== */
   MATHIP_VECT_Make ( NElements, MATHIE_complex, &cross_corr, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluates the FFT of the ABS of the slave image cell
   ========================================================================== */
   IREGPP_GCPE_FFTAbsImaEval ( SlaveCell, IREGPV_coarse_cell_dim_row,
                               IREGPV_coarse_cell_dim_col, DataType, &slave_fft,
                               status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   ... conjugate it, ...
   ========================================================================== */
   MATHIP_VECT_Conj ( slave_fft, &slave_fft, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   ... and multiplicate it vs the master one
   ========================================================================== */
   MATHIP_VECT_Prod ( master_fft, slave_fft, &cross_corr, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Free the slave array
   ========================================================================== */
   MATHIP_VECT_Free ( &slave_fft, status_code );

/* ==========================================================================
   Allocate the interpolation array
   ========================================================================== */
   MATHIP_VECT_Make ( NElementsInt, MATHIE_complex, &int_corr, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluates the inverse FFT of the interpolated matrix
   ========================================================================== */
   IREGPP_GCPE_CrossCorrInterp ( cross_corr, IREGPV_coarse_cell_dim_row,
                                 IREGPV_coarse_cell_dim_col, NRowInt, NColInt,
                                 &int_corr, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluates the shifts and the quality flag
   ========================================================================== */
   IREGPP_GCPE_Shifts ( int_corr, NRowInt, NColInt, IREGPV_int_fact_row,
                        IREGPV_int_fact_col, Shift, QualityFlag, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MATHIP_VECT_Free ( &cross_corr, &log_status_code );
   MATHIP_VECT_Free ( &int_corr, &log_status_code );
   MATHIP_VECT_Free ( &slave_fft, &log_status_code );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_ShiftEvaluation */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FillArray

        $TYPE         PROCEDURE

        $INPUT        Matrix   : input matrix to convert into its modulus
                      DataType : data type flag

        $MODIFIED     NONE

        $OUTPUT       arrout   : array to fill with the elements of the input
                                 matrix stored sequentially by row<s

        $GLOBAL       IREGPV_coarse_cell_dim_row : the matrix row dimension
                      IREGPV_coarse_cell_dim_col : the matrix col dimension

        $RET_STATUS   ERRSID_IREG_data_type_not_allow 

        $DESCRIPTION  This procedure fills a complex array with the values of
                      the float input matrix stored sequentially

        $WARNING      THE ARRAY MUST BE ALLOCATED BEFORE THE CALLING TO THE
                      PROCEDURE

        $PDL          - Switch over the various data types
                            - Loop over the matrix rows
                                  - Loop over the matrix columns
                                        - Fills the array with the matrix cell
                                  - End Loop
                            - End Loop
                      - End Switch

   $EH
   ========================================================================== */

void IREGPP_GCPE_FillArray
                        (/*IN    */ void               **Matrix,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_FillArray";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Fills the array
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx2:
         for ( row=0; row<IREGPV_coarse_cell_dim_row; row++ ) {
            for ( col=0; col<IREGPV_coarse_cell_dim_col; col++ ) {
               (((MATHIT_complex *)(arrout->ap))[ row * IREGPV_coarse_cell_dim_col +
                  col ]).rea = ((float **)Matrix)[ row ][ col ];
            }
         }
      break;
      case LDEFIE_dt_2_INTx2:
         for ( row=0; row<IREGPV_coarse_cell_dim_row; row++ ) {
            for ( col=0; col<IREGPV_coarse_cell_dim_col; col++ ) {
               (((MATHIT_complex *)(arrout->ap))[ row * IREGPV_coarse_cell_dim_col +
                  col ]).rea = ((float **)Matrix)[ row ][ 2 * col ];
               (((MATHIT_complex *)(arrout->ap))[ row * IREGPV_coarse_cell_dim_col +
                  col ]).ima = ((float **)Matrix)[ row ][ 2*col + 1 ];
            }
         }
      break;
      case LDEFIE_dt_float:
         for ( row=0; row<IREGPV_coarse_cell_dim_row; row++ ) {
            for ( col=0; col<IREGPV_coarse_cell_dim_col; col++ ) {
               (((MATHIT_complex *)(arrout->ap))[ row * IREGPV_coarse_cell_dim_col +
                  col ]).rea = ((float **)Matrix)[ row ][ col ];
            }
         }
      break;
      case LDEFIE_dt_2_float:
         for ( row=0; row<IREGPV_coarse_cell_dim_row; row++ ) {
            for ( col=0; col<IREGPV_coarse_cell_dim_col; col++ ) {
               (((MATHIT_complex *)(arrout->ap))[ row * IREGPV_coarse_cell_dim_col +
                  col ]).rea = ((float **)Matrix)[ row ][ 2 * col ];
               (((MATHIT_complex *)(arrout->ap))[ row * IREGPV_coarse_cell_dim_col +
                  col ]).ima = ((float **)Matrix)[ row ][ 2 * col + 1 ];
            }
         }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow , "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_FillArray */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ZeroPadding

        $TYPE         PROCEDURE

        $INPUT        MatrInp : input matrix to enlarge
                      NRowOut : number of wanted output rows
                      NColOut : number of wanted output columns

        $MODIFIED     NONE

        $OUTPUT       MatrOut : output zero padded matrix

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_no_enlarge_zp

        $DESCRIPTION  This procedure makes the zero padding of the input matrix
                      described by a complex array that stores sequentially
                      the matrix

        $WARNING      NONE

        $PDL          - Checks the number of output rows and columns
                      - Evaluate the correction deltas for the arrays indices
                        for odd cell dimensions
                      - Evaluates the half dimensions of the input matrix
                      - Copies the half top left of the input matrix into the
                        output one
                      - The same for the top rigth part
                      - The same for the bottom left part
                      - The same for the bottom rigth part

   $EH
   ========================================================================== */

void IREGPP_GCPE_ZeroPadding
                        (/*IN    */ MATHIT_array         MatrInp,
                         /*IN    */ INTx4                NRowInp,
                         /*IN    */ INTx4                NColInp,
                         /*IN    */ INTx4                NRowOut,
                         /*IN    */ INTx4                NColOut,
                         /*   OUT*/ MATHIT_array        *MatrOut,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_ZeroPadding";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx2                  dr = 0;
   INTx2                  dc = 0;
   INTx4                  row;
   INTx4                  half_dim_row;
   INTx4                  half_dim_col;
   INTx4                  row_out;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the goodness of the out dimensions
   ========================================================================== */
   if ( ( NRowOut < NRowInp ) ||
        ( NColOut < NColInp ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_no_enlarge_zp, "" );
   }

/* ==========================================================================
   Set the correction factors for the odd size cell
   ========================================================================== */
   if ( NRowInp % 2 )  {
      dr = 1;
   }
   if ( NColInp % 2 ) {
      dc = 1;
   }

/* ==========================================================================
   Evaluate the half dimensions
   ========================================================================== */
   half_dim_row = (INTx4)(NRowInp / 2.);
   half_dim_col = (INTx4)(NColInp / 2.);

/* ==========================================================================
   Copy the top left and rigth matrix part
   ========================================================================== */
   for ( row=0; row<half_dim_row; row++ ) {
      MATHIP_VECT_SubCopy ( MatrInp, (INTx4)(row * NColInp),
                            half_dim_col, MatrOut, (INTx4)(row * NColOut),
                            status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      MATHIP_VECT_SubCopy ( MatrInp, (INTx4)
                            (row * NColInp + half_dim_col + dc),
                            half_dim_col, MatrOut, (INTx4)
                            (( row + 1 ) * NColOut - half_dim_col ),
                            status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Copy the bottom matrix part
   ========================================================================== */
   row_out = NRowOut - half_dim_row - 1;
   for ( row=half_dim_row+dr; row<NRowInp; row++ ) {
      row_out++;
      MATHIP_VECT_SubCopy ( MatrInp, (INTx4)(row * NColInp),
                            half_dim_col, MatrOut, (INTx4)(row_out * NColOut),
                            status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      MATHIP_VECT_SubCopy ( MatrInp, (INTx4)
                            (row * NColInp + half_dim_col + dc),
                            half_dim_col, MatrOut, (INTx4)
                            (( row_out + 1 ) * NColOut - half_dim_col ),
                            status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_ZeroPadding */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FindMaximum

        $TYPE         PROCEDURE

        $INPUT        arr_inp : input array

        $MODIFIED     NONE

        $OUTPUT       index   : sequential index where ther's the array maximum
                                value in modulus
                      max_value : maximum absolute value of the array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_no_complex_out

        $DESCRIPTION  This procedure finds the index relative to the maximum
                      array value in modulus

        $WARNING      NONE

        $PDL          - Checks the type of the input array
                      - Loop over the elements of the array
                            - Evaluates the modulus of the complex element
                            - IF the array value is greather then the reference
                              maximum value set
                                  - Resets the reference maximum value
                                  - Fills the index
                            - End IF
                      - End Loop
                      - Sets the maximum value

   $EH
   ========================================================================== */

void IREGPP_GCPE_FindMaximum
                        (/*IN    */ MATHIT_array         arr_inp,
                         /*   OUT*/ INTx4               *index,
                         /*   OUT*/ float               *max_value,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_FindMaximum";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   float                  max_val = -1.e+30;
   INTx4                  elem;
   float                  modul;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check if the array is complex as it must be !
   ========================================================================== */
   if ( arr_inp.atype != MATHIE_complex ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_no_complex_out, "" );
   }

/* ==========================================================================
   Find the maximum of the real part
   ========================================================================== */
   for ( elem=0; elem<arr_inp.nelem; elem++ ) {
      modul = ( (((MATHIT_complex *)arr_inp.ap)[ elem ]).rea < 0 ) ?
         - (((MATHIT_complex *)arr_inp.ap)[ elem ]).rea : 
         (((MATHIT_complex *)arr_inp.ap)[ elem ]).rea;
      if ( (float)modul > max_val ) {
         max_val = (float)modul;
         *index = elem;
      }
   }

/* ==========================================================================
   Set the maximum value
   ========================================================================== */
   *max_value = max_val;

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_FindMaximum */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CoarseRegistrator

        $TYPE         PROCEDURE

        $INPUT        inp_io : array of descriptors of the opened files

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGIV_ima_num       : number of images opened
                      IREGPV_coarse_cell_dim_row  : cells dimension in the row
                                             direction
                      IREGPV_coarse_cell_dim_col  : cells dimension in the column
                                             direction
                      IREGPV_gcp[<imanum>] : array of structure with the GCP(s)
                                             INFO

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_err_mem_alloc
                      
        $DESCRIPTION  This procedure is the driver of the GCP(s) coarse
                      registration that evaluates the shifts between the GCP(s)
                      in the master image and each of the slaves using the image
                      geometry and the peak of the cross correlation matrix.
 
        $WARNING      NONE

        $PDL          - Checks the number of images opened
                      - Allocates the array for the rotation angle
                      - Allocates the necessary memories for the master and
                        slave cells matrix storage
                      - Evaluates the total number of elements of the cells
                      - Allocates the arrays
                      - Loop over the opened slaves images
                            - Evaluates the rotation angle between the master
                              and the current slave image
                      - End Loop
                      - Evaluates the number of total GCPs
                      - Sets the image data type
                      - Loop over the GCP(s)
                            - Extracts the master cell
                            - If the cell is all inside the master image
                                  - Sets the validity flag in the descriptor
                                    of the master GCP(s) TRUE for the current
                                    GCP
                                  - Evaluates the FFT of the absolute value
                                    of the master cell
                                  - Loop over the slave(s) image(s)
                                        - If the validity flag of the GCP in
                                          the slave is TRUE
                                              - Extracts the slave cell at the
                                                given centre coordinates
                                              - If the cell is all inside
                                                the slave image
                                                    - Evaluates the shifts
                                                      in row and col
                                                      directions between the
                                                      two cells
                                                    - Rotates the shifts for
                                                      the rotation angle to
                                                      compensate the cell
                                                      rotation
                                                    - Updates the centre
                                                      coordinates by the
                                                      compensated shifts
                                                    - Sets the quality
                                                      flag
                                                    - Checks the goodness
                                                      of the GCP with a
                                                      stability test
                                                    - If the test is not
                                                      passed
                                                          - Sets in the
                                                            slave GCP(s)
                                                            INFO structure
                                                            the validity
                                                            flag to FALSE
                                                    - Else
                                                          - Sets in the
                                                            slave GCP(s)
                                                            INFO structure
                                                            the validity
                                                            flag to TRUE
                                                    - End If
                                              - Else
                                                    - Sets in the slave GCP(s)
                                                      INFO structure the
                                                      validity flag to FALSE
                                              - End If
                                        - End If
                                  - End Loop
                            - Else
                                  - Sets in the master GCP(s) INFO structure
                                    the validity flag to FALSE
                            - End If
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_GCPE_CoarseRegistrator
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_CoarseRegistrator";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double                *RotAngle = (double *)NULL;
   LDEFIT_data_type       DataType = LDEFIE_dt_undef;
   float                **master = (float **)NULL;
   float                **slave = (float **)NULL;
   MATHIT_array           master_fft;
   MATHIT_RC              shift;
   MATHIT_RC              point;
   float                  q;
   INTx1                  mas_imanum = 0;
   INTx1                  mas_gridnum = 0;
   INTx4                  Ngcp;
   INTx4                  NElements;
   INTx4                  gcp_i;
   INTx4                  ima;
   INTx4                  row;
   float                  filler = 0;
   INTx1                  valid_flag = 0;
   LDEFIT_boolean         ok_test;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the number of opened image
   ========================================================================== */
   if ( ( IREGIV_ima_num < 2 ) || ( IREGIV_ima_num > IREGPD_max_img ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_ima_num_inv, "" );
   }

/* ==========================================================================
   Allocate the array of rotation angles and the master and slave cells
   ========================================================================== */
   IREGPP_GCPE_ArraysAllocation ( inp_io, mas_imanum,
                                  IREGPV_coarse_cell_dim_row,
                                  IREGPV_coarse_cell_dim_col, &RotAngle,
                                  &master, &slave, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the number of elements of the master cell
   ========================================================================== */
   NElements = (INTx4)(IREGPV_coarse_cell_dim_row * IREGPV_coarse_cell_dim_col);

/* ==========================================================================
   Allocate the array for the master FFT storage
   ========================================================================== */
   MATHIP_VECT_Make ( NElements, MATHIE_complex, &master_fft, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the rotation angle of the slave(s)
   ========================================================================== */
   if ( inp_io[ mas_imanum ].val.tif.bpar.sampleperpixel == 1 ) {
      for ( ima=1; ima<IREGIV_ima_num; ima++ ) {
         IREGPP_GCPE_RotAngleEval ( mas_imanum, (INTx1)ima, &RotAngle[ ima ],
                                    status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }
   else {
      memset ( (void *)RotAngle, '\0', (size_t)(IREGIV_ima_num *
               sizeof (double)) );
   }

/* ==========================================================================
   Copy the GCP number
   ========================================================================== */
   Ngcp = IREGPV_gcp[ mas_gridnum ].n_gcp;

/* ==========================================================================
   Set the data type
   ========================================================================== */
   IREGPP_GCPE_SetDataType ( inp_io[ mas_imanum ], &DataType, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Print out
   ========================================================================== */
#ifndef __TRACE__
   fprintf ( stdout, "\n\n\n Coarse Registration started ... \n\n\n" );
#endif

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) Ngcp*(IREGIV_ima_num-1), &log_status_code );

/* ==========================================================================
   Check for the shifts between the images
   ========================================================================== */
   for ( gcp_i=0; gcp_i<Ngcp; gcp_i++ ) {

/* ==========================================================================
   Extract the master image cell
   ========================================================================== */
      IREGPP_GCPE_CellExtractor ( &inp_io[ mas_imanum ],
                                  IREGPV_gcp[ mas_gridnum ].gcp_arr[
                                  gcp_i ].coor, IREGPV_coarse_cell_dim_row,
                                  IREGPV_coarse_cell_dim_col, mas_imanum,
                                  filler, (double)0, &valid_flag,
                                  master, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the validity flag
   ========================================================================== */
      if ( valid_flag == 1 ) {

/* ==========================================================================
   Set the validity flag of the GCP
   ========================================================================== */
         IREGPV_gcp[ mas_gridnum ].gcp_arr[ gcp_i ].valid = TRUE;

/* ==========================================================================
   Evaluates the FFT of the ABS of the image cell
   ========================================================================== */
         IREGPP_GCPE_FFTAbsImaEval ( (void **)master,
                                     IREGPV_coarse_cell_dim_row,
                                     IREGPV_coarse_cell_dim_col, DataType,
                                     &master_fft, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Loop over the slave(s)
   ========================================================================== */
         for ( ima=1; ima<IREGIV_ima_num; ima++ ) {

/* ==========================================================================
   Print out
   ========================================================================== */
            SRVSIP_trace_comp ( &log_status_code );

/* ==========================================================================
   Check the validity flag for the slave GCP
   ========================================================================== */
            if ( IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].valid ) {

/* ==========================================================================
   Approximate the slave coordinates
   ========================================================================== */
               IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.row = (double)
                  ROUND ( IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.row );
               IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.col = (double)
                  ROUND ( IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.col );

/* ==========================================================================
   Extract the (rotated) slave cell
   ========================================================================== */
               valid_flag = 0;
               IREGPP_GCPE_CellExtractor ( &inp_io[ ima ],
                                           IREGPV_gcp[ ima ].gcp_arr[
                                           gcp_i ].coor,
                                           IREGPV_coarse_cell_dim_row,
                                           IREGPV_coarse_cell_dim_col, ima,
                                           filler,
                                           - RotAngle[ ima ], &valid_flag,
                                           slave, status_code );
               ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the validity flag of the slave cell extraction
   ========================================================================== */
               if ( valid_flag == 1 ) {

/* ==========================================================================
   Evaluate the shifts between the master and slave cell
   ========================================================================== */
                  IREGPP_GCPE_ShiftEvaluation ( master_fft, (void **)slave,
                                                DataType, &shift, &q,
                                                status_code );
                  ERRSIM_on_err_goto_exit ( *status_code );

#ifdef __TRACE__
   fprintf ( stdout, "\n\n ** GCP #%0d master coor = ( %f, %f )", gcp_i + 1,
             IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor.row,
             IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor.col ); 
   fprintf ( stdout, "\n eval shift = ( %f, %f ), q = %f", 
             shift.row, shift.col, q );
#endif
/* ==========================================================================
   Check the quality flag
   ========================================================================== */
                  if ( q != 0. ) {

/* ==========================================================================
   Compensate the shifts for the rotation angle
   ========================================================================== */
                     IREGPP_GCPE_RCRotate ( RotAngle[ ima ], &shift,
                                            status_code );
                     ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Define the re-fined coordinates
   ========================================================================== */
                     point.row = IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.row +
                        shift.row;
                     point.col = IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.col +
                        shift.col;

/* ==========================================================================
   Save the quality flag
   ========================================================================== */
                     IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].quality = q;

/* ==========================================================================
   Stability test
   ========================================================================== */
                     IREGPP_GCPE_StabilityTest ( &inp_io[ ima ], ima, slave,
                                                 DataType, RotAngle[ ima ],
                                                 point, master_fft, &ok_test,
                                                 status_code );
                     ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Printout
   ========================================================================== */
#ifndef __TRACE__
/*
                     fprintf ( stdout, "\r The GCPs registered are the %3d ",
                               ROUND (((float)(gcp_i + 1) /
                               IREGPV_gcp[ mas_gridnum ].n_gcp) * 100) );
                     fprintf ( stdout, "%% of the total" );
*/
#endif

/* ==========================================================================
   Check the stability
   ========================================================================== */
                     if ( ! ( ok_test ) ) {

/* ==========================================================================
   Set invalid the GCP for the slave
   ========================================================================== */
                        IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].valid = FALSE;
                     }
                     else {

/* ==========================================================================
   Set the validity flag for the slave GCP
   ========================================================================== */
                        IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].valid = TRUE;

/* ==========================================================================
   Refine the GCP coordinates with the shifts
   ========================================================================== */
                        IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.row +=
                           shift.row;
                        IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.col +=
                           shift.col;
                     }
                  }
                  else {

/* ==========================================================================
   Set the GCP invalid for the slave
   ========================================================================== */
                     IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].valid = FALSE;
                  }
               }
               else {

/* ==========================================================================
   Set the GCP invalid for the slave
   ========================================================================== */
                  IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].valid = FALSE;
               }
            }
         }
      }
      else {

/* ==========================================================================
   Print out over the slave(s) to reach 100%
   ========================================================================== */
         for ( ima=1; ima<IREGIV_ima_num; ima++ ) {
            SRVSIP_trace_comp ( &log_status_code );
         }

/* ==========================================================================
   Set invalid the GCP master
   ========================================================================== */
         IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].valid = FALSE;

      }
   }

/* ==========================================================================
   Print out
   ========================================================================== */
#ifndef __TRACE__
   fprintf ( stdout, "\n\n Coarse Registration ended\n" );
#endif

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&RotAngle );

   if ( master != (float **)NULL ) {
      for ( row=0; row<IREGPV_coarse_cell_dim_row; row++ ) {
         MEMSIP_free ( (void **)&(master[ row ]) );
      }
      MEMSIP_free ( (void **)&master );
   }

   if ( slave != (float **)NULL ) {
      for ( row=0; row<IREGPV_coarse_cell_dim_row; row++ ) {
         MEMSIP_free ( (void **)&(slave[ row ]) );
      }
      MEMSIP_free ( (void **)&slave );
   }

   MATHIP_VECT_Free ( &master_fft, &log_status_code );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_CoarseRegistrator */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SetDataType

        $TYPE         PROCEDURE

        $INPUT        inp_io   : descriptor of the image file

        $MODIFIED     NONE

        $OUTPUT       DataType : image data type

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure sets the image data type according to the
                      image file descriptor

        $WARNING      NONE

        $PDL          - Switch over the sample format flag
                            - Switch over the sample per pixel flag or bits per
                              sample flag
                            - Sets the data type
                      - End Switch

   $EH
   ========================================================================== */

void IREGPP_GCPE_SetDataType
                        (/*IN    */ GIOSIT_io            inp_io,
                         /*   OUT*/ LDEFIT_data_type    *DataType,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_SetDataType";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Set the data type
   ========================================================================== */
   switch ( inp_io.val.tif.bpar.sampleformat[ 0 ] ) {
      case TIFSID_uintdata:
         if ( inp_io.val.tif.bpar.bitspersample[ 0 ] == 8 ) {
            *DataType = LDEFIE_dt_UINTx1;
         }
         else if ( inp_io.val.tif.bpar.bitspersample[ 0 ] == 16 ) {
            *DataType = LDEFIE_dt_UINTx2;
         }
         else {
            ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                               "data type not allowed" );
         }
      break;
      case TIFSID_sintdata:
         if ( ( inp_io.val.tif.bpar.bitspersample[ 0 ] == 16 ) &&
              ( inp_io.val.tif.bpar.sampleperpixel == 2 ) ) {
            *DataType = LDEFIE_dt_2_INTx2;
         }
         else {
            ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                               "data type not allowed" );
         }
      break;
      case TIFSID_float:
         if ( inp_io.val.tif.bpar.sampleperpixel == 1 ) {
            *DataType = LDEFIE_dt_float;
         }
         else if ( inp_io.val.tif.bpar.sampleperpixel == 2 ) {
            *DataType = LDEFIE_dt_2_float;
         }
         else {
            ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                               "data type not allowed" );
         }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                            "data type not allowed" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_SetDataType */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ModulEval

        $TYPE         PROCEDURE

        $INPUT        ImaCell  : input image cell
                      NRowInp  : number of rows of the image cell
                      NColInp  : number of columns of the image cell
                      DataType : data type of the input image

        $MODIFIED     NONE

        $OUTPUT       ImaModul : array of complex type with the real part filled
                                 with the image cell modul

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure fills a complex array with the modulus of
                      the input image cell sequentially stored

        $WARNING      NONE

        $PDL          - Evaluates the number of elements of the array
                      - Allocates the arrays for the real and imaginary part
                      - Zeros the imaginary array
                      - Fills an array with the image
                      - Evaluates the image modulus
                      - Fills with the modulus the output array
                      - Frees all the allocated arrays

   $EH
   ========================================================================== */

void IREGPP_GCPE_ModulEval
                        (/*IN    */ void               **ImaCell,
                         /*IN    */ INTx4                NRowInp,
                         /*IN    */ INTx4                NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *ImaModul,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_ModulEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   float                 *real = (float *)NULL;
   float                 *imag = (float *)NULL;
   INTx4                  NElements;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the number of elements of the cell
   ========================================================================== */
   NElements = (INTx4)(NRowInp * NColInp);

/* ==========================================================================
   Allocate the array for modulus evaluation
   ========================================================================== */

   /* modulus array */
   if ( ( real = (float *)MEMSIP_alloc ( (size_t)(NElements *
                                         sizeof (float)) )) ==
        (float *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "the modulus array" );
   }

   /* imaginary array */
   if ( ( imag = (float *)MEMSIP_alloc ( (size_t)(NElements *
                                         sizeof (float)) )) ==
        (float *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "the imaginary array" );
   }

   /* zero the imaginary array */
   memset ( (void *)imag, '\0', (size_t)(NElements * sizeof (float)) );

/* ==========================================================================
   Fill the array with the matrix
   ========================================================================== */
   IREGPP_GCPE_FillArray ( (void **)ImaCell, DataType, ImaModul, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the FFT of the absolute value 
   ========================================================================== */
   MATHIP_VECT_Modul ( *ImaModul, real, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the complex array
   ========================================================================== */
   MATHIP_VECT_Complex ( real, imag, ImaModul, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

/* ==========================================================================
   Free the allocated arrays
   ========================================================================== */
   MEMSIP_free ( (void **)&real );
   MEMSIP_free ( (void **)&imag );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_ModulEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FFTAbsImaEval

        $TYPE         PROCEDURE

        $INPUT        ImaCell  : input image cell
                      NRowInp  : number of image cell rows
                      NColInp  : number of image cell columns
                      DataType : image data type

        $MODIFIED     NONE

        $OUTPUT       ImaFFT   : array with the absolute image cell fft 

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the fft of the absolute value
                      of the image cell passed in input

        $WARNING      NONE

        $PDL          - Evaluates the image modulus
                      - Evaluates the image direct FFT

   $EH
   ========================================================================== */

void IREGPP_GCPE_FFTAbsImaEval
                        (/*IN    */ void               **ImaCell,
                         /*IN    */ INTx4                NRowInp,
                         /*IN    */ INTx4                NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *ImaFFT,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_FFTAbsImaEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx1                  flag = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Converts the image into a complex array with the real part with its modulus
   ========================================================================== */
   IREGPP_GCPE_ModulEval ( ImaCell, NRowInp, NColInp, DataType, ImaFFT,
                           status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the FFT of the modulus of the master image cell
   ========================================================================== */
   MATHIP_DFFT_2D ( *ImaFFT, (INTx4)NRowInp, (INTx4)NColInp, flag, ImaFFT,
                    status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_FFTAbsImaEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ArrayModulEval

        $TYPE         PROCEDURE

        $INPUT        NElements : number of elements of the input array

        $MODIFIED     arr_inp   : array with the matrix to transform

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the modulus of a complex array
                      and gives it in output

        $WARNING      NONE

        $PDL          - Allocates the real and the imaginary arrays
                      - Zeroes the imaginary array
                      - Evaluates the modulus of the array
                      - Fills the complex array with the array modulus
                      - Deallocates the real and imaginary arrays

   $EH
   ========================================================================== */

void IREGPP_GCPE_ArrayModulEval
                        (/*IN    */ INTx4                NElements,
                         /*IN OUT*/ MATHIT_array        *arr_inp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_ArrayModulEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   float                 *real = (float *)NULL;
   float                 *imag = (float *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Allocate the array for the modulus matrix
   ========================================================================== */
   if ( ( real = (float *)MEMSIP_alloc ( (size_t)(NElements *
                                          sizeof (float)) ) ) ==
        (float *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "the modulus array" );
   }

   /* imaginary array */
   if ( ( imag = (float *)MEMSIP_alloc ( (size_t)(NElements *
                                         sizeof (float)) )) ==
        (float *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "the modulus array" );
   }

   /* zero the imaginary array */
   memset ( (void *)imag, '\0', (size_t)(NElements * sizeof (float)) );

/* ==========================================================================
   Evaluate the modulus of the matrix
   ========================================================================== */
   MATHIP_VECT_Modul ( *arr_inp, real, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the complex array
   ========================================================================== */
   MATHIP_VECT_Complex ( real, imag, arr_inp, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

/* ==========================================================================
   Free the memories
   ========================================================================== */
   MEMSIP_free ( (void **)&real );
   MEMSIP_free ( (void **)&imag );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_ArrayModulEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_Shifts

        $TYPE         PROCEDURE

        $INPUT        matrix      : input matrix to which the maximum value and
                                    the corresponding index must be evaluated
                      NRow        : number of rows of the input matrix
                      NCol        : number of columns of the input matrix
                      fact_row    : interpolation factor in the row direction
                      fact_col    : interpolation factor in the column direction

        $MODIFIED     NONE

        $OUTPUT       Shift       : shifts in the row and columns directions
                      QualityFlag : quality flag

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the shifts in the rows and
                      columns directions and evaluates the quality flag

        $WARNING      NONE

        $PDL          - Finds the maximum value of the cross correlation
                        matrix and the index of the matrix corresponding
                        to the peak
                      - Evaluates the rows and columns indices from the
                        sequential one
                      - Checks the correctness of the shift range
                      - Evaluates the matrix mean value
                      - Evaluates the quality indicator as the ratio between
                        the peak value and the background

   $EH
   ========================================================================== */

void IREGPP_GCPE_Shifts
                        (/*IN    */ MATHIT_array         matrix,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ float                fact_row,
                         /*IN    */ float                fact_col,
                         /*   OUT*/ MATHIT_RC           *Shift,
                         /*   OUT*/ float               *QualityFlag,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_Shifts";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  index;
   float                  peak_val;
   double                 mean_val[ 2 ];
   double                 sigma_val[ 2 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Find the index of the maximum matrix value
   ========================================================================== */
   IREGPP_GCPE_FindMaximum ( matrix, &index, &peak_val, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the shifts
   ========================================================================== */
   Shift->row = (double)((INTx4)(index / NCol));
   Shift->col = (double)(index % NCol);

/* ==========================================================================
   Check the shifts range
   ========================================================================== */
   Shift->row = ( Shift->row > ( (double)(NRow) / 2. ) ) ?
      ( (double)NRow - Shift->row ) / fact_row : - Shift->row / fact_row;
   Shift->col = ( Shift->col > ( (double)(NCol) / 2. ) ) ?
      ( (double)NCol - Shift->col ) / fact_col : - Shift->col / fact_col;

/* ==========================================================================
   Evaluate the averaged value of the interpolated cross correlation matrix
   ========================================================================== */
   MATHIP_VECT_Mean ( matrix, mean_val, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the sigma value of the interpolated cross correlation matrix
   ========================================================================== */
   MATHIP_VECT_Sigma ( matrix, (INTx4)1, sigma_val, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the quality flag
   ========================================================================== */
   if ( ( mean_val[ 0 ] != (double)0 ) && ( sigma_val[ 0 ] != (double)0 ) ) {
      *QualityFlag = peak_val / (float)(mean_val[ 0 ]);
   }
   else {
      *QualityFlag = (float)0;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_Shifts */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CrossCorrInterp

        $TYPE         PROCEDURE

        $INPUT        cross_corr : cross correlation matrix
                      NRowInp    : number of rows of the cross correlation
                                   matrix
                      NColInp    : number of columns of the cross correlation
                                   matrix
                      NRowOut    : number of rows of the output interpolated
                                   matrix
                      NColOut    : number of columns of the output interpolated
                                   matrix

        $MODIFIED     NONE

        $OUTPUT       int_corr   : interpolated matrix

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the interpolated cross
                      correlation matrix via zero padding and makes its inverse
                      FFT

        $WARNING      NONE

        $PDL          - Evaluates the number of output elements
                      - Makes matrix zero padding
                      - Evaluates the inverse FFT of the interpolated matrix
                      - Evaluates its modulus

   $EH
   ========================================================================== */

void IREGPP_GCPE_CrossCorrInterp
                        (/*IN    */ MATHIT_array         cross_corr,
                         /*IN    */ INTx4                NRowInp,
                         /*IN    */ INTx4                NColInp,
                         /*IN    */ INTx4                NRowOut,
                         /*IN    */ INTx4                NColOut,
                         /*   OUT*/ MATHIT_array        *int_corr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_CrossCorrInterp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx1                  fft_flag = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Zero padd the cross correlation
   ========================================================================== */
   IREGPP_GCPE_ZeroPadding ( cross_corr, NRowInp, NColInp, NRowOut, NColOut,
                             int_corr, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Make the inverse of the FFT
   ========================================================================== */
   MATHIP_DFFT_2D ( *int_corr, NRowOut, NColOut, fft_flag, int_corr,
                    status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the array modulus
   ========================================================================== */
   IREGPP_GCPE_ArrayModulEval ( int_corr->nelem, int_corr, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_CrossCorrInterp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_RCRotate

        $TYPE         PROCEDURE

        $INPUT        Angle : the rotation angle in radians

        $MODIFIED     RC    : vector in row, col coordinates rotated

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure rotate the vector in row, col coordinates
                      by the rotation angle <Angle>

        $WARNING      NONE

        $PDL          - Rotates the row coordinate
                      - Rotates the column coordinate

   $EH
   ========================================================================== */

void IREGPP_GCPE_RCRotate
                        (/*IN    */ double               Angle,
                         /*IN OUT*/ MATHIT_RC           *RC,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_RCRotate";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Rotate the coordinates vector
   ========================================================================== */
   RC->row = RC->col * sin ( Angle ) + RC->row * cos ( Angle );
   RC->col = RC->col * cos ( Angle ) - RC->row * sin ( Angle );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_RCRotate */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_StabilityTest

        $TYPE         PROCEDURE

        $INPUT        sla_io     : descriptor of the slave file
                      sla_imanum : slave ID number
                      slave      : matrix to fill with the slave image cell
                      DataType   : slave image data type
                      RotAngle   : rotation angle in radians
                      centre     : coordinates of the centre of the slave cell
                                   to extract
                      master_fft : FFT of the absolute value of the master cell
                                   to correlate with the slave

        $MODIFIED     NONE

        $OUTPUT       ok_test    : flag indicating if the test has been passed
                                   ( TRUE ) or not

        $GLOBAL       IREGPV_coarse_cell_dim_row     : cell dimensions
                      IREGPV_coarse_cell_dim_col     : cell dimensions
                      IREGPV_max_coarse_shift : maximum allowable shift

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes a test on the evaluated shift
                      coordinates between master and slave cells of the two
                      image passed

        $WARNING      NONE

        $PDL          - Zeroes the slave cell matrix
                      - Extracts the slave cell
                      - Sets the test flag to FALSE
                      - If the cell is all inside the image
                            - Evaluates the shifts
                            - Compensate the rotation
                               - If the absolute values of the shifts in the two
                              directions are lesser then the maximum allowable
                              value
                                  - Sets the test flag to TRUE
                            - End If
                      - End If

   $EH
   ========================================================================== */

void IREGPP_GCPE_StabilityTest
                        (/*IN    */ GIOSIT_io           *sla_io,
                         /*IN    */ INTx1                sla_imanum,
                         /*IN    */ float              **slave,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ double               RotAngle,
                         /*IN    */ MATHIT_RC            centre,
                         /*IN    */ MATHIT_array         master_fft,
                         /*   OUT*/ LDEFIT_boolean      *ok_test,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_StabilityTest";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx1                  valid_flag = 0;
   float                  filler = 0;
   float                  q;
   MATHIT_RC              shift;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Zero the slave cell
   ========================================================================== */
   IREGPP_GCPE_FillImaCell ( (UINTx4)IREGPV_coarse_cell_dim_row,
                             (UINTx4)IREGPV_coarse_cell_dim_col, DataType,
                             filler,
                             (void **)slave, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Extract the (rotated) slave cell
   ========================================================================== */
   IREGPP_GCPE_CellExtractor ( sla_io, centre, IREGPV_coarse_cell_dim_row,
                               IREGPV_coarse_cell_dim_col, sla_imanum,
                               filler, - RotAngle, &valid_flag,
                               slave, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Set the flag
   ========================================================================== */
   *ok_test = FALSE;

/* ==========================================================================
   Check the validity flag of the slave cell extraction
   ========================================================================== */
   if ( valid_flag == 1 ) {

/* ==========================================================================
   Evaluate the shifts between the master and slave cell
   ========================================================================== */
      IREGPP_GCPE_ShiftEvaluation ( master_fft, (void **)slave, DataType,
                                    &shift, &q, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Compensate the shifts for the rotation angle
   ========================================================================== */
      IREGPP_GCPE_RCRotate ( RotAngle, &shift, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

#ifdef __TRACE__
   fprintf ( stdout, " stab shift = ( %f, %f )", shift.row, shift.col );
#endif
/* ==========================================================================
   Test the shifts
   ========================================================================== */
      if ( ( ABS ( shift.row ) < IREGPV_max_coarse_shift ) &&
           ( ABS ( shift.col ) < IREGPV_max_coarse_shift ) ) {

/* ==========================================================================
   Set the test flag to ok
   ========================================================================== */
         *ok_test = TRUE;
      }
   }

#ifdef __TRACE__
   fprintf ( stdout, " stab flag = %d", *ok_test );
#endif
error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_StabilityTest */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ArraysAllocation

        $TYPE         PROCEDURE

        $INPUT        inp_io     : input file descriptor array
                      mas_imanum : master image ID number
                      NRowInp    : master and slave number of rows
                      NColInp    : master and slave number of columns

        $MODIFIED     RotAngle   : pointer to the array that will store the
                                   rotation angles
                      master     : pointer to the master matrix that will
                                   store the master image cell
                      slave      : pointer to the slave matrix that will
                                   store the slave image cell

        $OUTPUT       NONE

        $GLOBAL       IREGIV_ima_num      : the number of opened images

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure allocates the rotation angles array and
                      the master and slave cells

        $WARNING      NONE

        $PDL          - Allocates the rotation angles array
                      - Allocates the master image cell
                      - Allocates the slave image cell

   $EH
   ========================================================================== */

void IREGPP_GCPE_ArraysAllocation
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ INTx1                mas_imanum,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN OUT*/ double             **RotAngle,
                         /*IN OUT*/ float             ***master,
                         /*IN OUT*/ float             ***slave,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_ArraysAllocation";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Allocate the array of rotation angles
   ========================================================================== */
   if ( ( *RotAngle = (double *)MEMSIP_alloc ( (size_t)(IREGIV_ima_num *
                                              sizeof (double)) ) ) ==
        (double *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the array of rotation angles" );
   }
   memset ( (void *)(*RotAngle), '\0', (size_t)(IREGIV_ima_num *
            sizeof (double)) );

/* ==========================================================================
   Allocate the master and slave cells
   ========================================================================== */

   /* master image cell allocation */
   if ( ( (*master) = (float **)MEMSIP_alloc ( (size_t)(NRowInp *
                                           sizeof (float *)) ) ) ==
        (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the master cell" );
   }
   for ( row=0; row<NRowInp; row++ ) {
      (*master)[ row ] = (float *)NULL;
      if ( ( (*master)[ row ] = (float *)MEMSIP_alloc ( (size_t)
                             (NColInp *
                             inp_io[ mas_imanum ].val.tif.bpar.sampleperpixel *
                             sizeof (float)) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "for the master cell" );
      }
   }

   /* slave image cell allocation */
   if ( ( (*slave) = (float **)MEMSIP_alloc ( (size_t)(NRowInp *
                                           sizeof (float *)) ) ) ==
        (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the slave cell" );
   }
   for ( row=0; row<NRowInp; row++ ) {
      (*slave)[ row ] = (float *)NULL;
      if ( ( (*slave)[ row ] = (float *)MEMSIP_alloc ( (size_t)
                            (NColInp *
                            inp_io[ mas_imanum ].val.tif.bpar.sampleperpixel *
                            sizeof (float)) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "for the slave cell" );
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_ArraysAllocation */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SmoothIma2float

        $TYPE         PROCEDURE

        $INPUT        InpIma : input image cell
                      NRow   : number of rows of the input image cell
                      NCol   : number of columns of the input image cell
                      Width  : width of the moving box

        $MODIFIED     NONE

        $OUTPUT       OutIma : output image cell

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the smooth as a blocking
                      average of an image cell of type 2 float

        $WARNING      NONE

        $PDL          - Evaluates the value of the scaling factor for the
                        average
                      - Loop over the image rows with step equals to the moving
                        box width
                            - Loop over the image columns with step equals to
                              the moving box width
                                  - Zeroes the output image elements
                                  - Loop over the rows of the moving box
                                        - Points to the top left pixel of the
                                          image in the current box
                                        - Loop over the columns of the box
                                              - Fills the output image elements
                                                with the sum of them in the box
                                        - End Loop
                                  - End Loop
                                  - Rescales the sum of the box with the factor
                                    to give the average value
                                  - Increments the output columns counter
                            - End Loop
                            - Increments the output rows counter
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_GCPE_SmoothIma2float
                        (/*IN    */ float             **InpIma,
                         /*IN    */ UINTx4              NRow,
                         /*IN    */ UINTx4              NCol,
                         /*IN    */ UINTx4              Width,
                         /*   OUT*/ float             **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_SmoothIma2float";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   REGISTER INTx4         row;
   REGISTER INTx4         col;
   REGISTER INTx4         out_row = 0;
   REGISTER INTx4         out_col = 0;
   REGISTER INTx4         dc;
   REGISTER INTx2         kr;
   REGISTER INTx2         kc;
   REGISTER float        *p = (float *)NULL;
   REGISTER float         K;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the scale factor
   ========================================================================== */
   K = (float)(1. / POW ( Width, 2. ));

/* ==========================================================================
   Smooth the image cell
   ========================================================================== */
   for ( row=0; row<=(NRow-Width); row+=Width ) {
      out_col = 0;
      for ( col=0; col<=(NCol-Width); col+=Width ) {
      
         dc = 2 * out_col;
         OutIma[ out_row ][ dc ] = 0.;
         OutIma[ out_row ][ dc + 1 ] = 0.;
         for ( kr=0; kr<Width; kr++ ) {
            p = &InpIma[ row + kr ][ 2 * col ] - 1;
            for ( kc=0; kc<Width; kc++ ) {
               OutIma[ out_row ][ dc ] += *++p;
               OutIma[ out_row ][ dc + 1 ] += *++p;
            }
         }
         OutIma[ out_row ][ dc ] *= K;
         OutIma[ out_row ][ dc + 1 ] *= K;
         out_col++;
      }
      out_row++;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_SmoothIma2float */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SmoothImafloat

        $TYPE         PROCEDURE

        $INPUT        InpIma : input image cell
                      NRow   : number of rows of the input image cell
                      NCol   : number of columns of the input image cell
                      Width  : width of the moving box

        $MODIFIED     NONE

        $OUTPUT       OutIma : output image cell

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the smooth as a blocking
                      average of an image cell of type float

        $WARNING      NONE

        $PDL          - Evaluates the value of the scaling factor for the
                        average
                      - Loop over the image rows with step equals to the moving
                        box width
                            - Loop over the image columns with step equals to
                              the moving box width
                                  - Zeroes the output image elements
                                  - Loop over the rows of the moving box
                                        - Points to the top left pixel of the
                                          image in the current box
                                        - Loop over the columns of the box
                                              - Fills the output image elements
                                                with the sum of them in the box
                                        - End Loop
                                  - End Loop
                                  - Rescales the sum of the box with the factor
                                    to give the average value
                                  - Increments the output columns counter
                            - End Loop
                            - Increments the output rows counter
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_GCPE_SmoothImafloat
                        (/*IN    */ float             **InpIma,
                         /*IN    */ UINTx4              NRow,
                         /*IN    */ UINTx4              NCol,
                         /*IN    */ UINTx4              Width,
                         /*   OUT*/ float             **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_SmoothImafloat";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   REGISTER INTx4         row;
   REGISTER INTx4         col;
   REGISTER INTx4         out_row = 0;
   REGISTER INTx4         out_col = 0;
   REGISTER INTx4         dc;
   REGISTER INTx2         kr;
   REGISTER INTx2         kc;
   REGISTER float        *p = (float *)NULL;
   REGISTER float         K;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the scale factor
   ========================================================================== */
   K = (float)(1. / POW ( Width, 2. ));

/* ==========================================================================
   Smooth the image cell
   ========================================================================== */
   for ( row=0; row<=(NRow-Width); row+=Width ) {
      out_col = 0;
      for ( col=0; col<=(NCol-Width); col+=Width ) {
      
         OutIma[ out_row ][ out_col ] = 0.;
         for ( kr=0; kr<Width; kr++ ) {
            p = &InpIma[ row + kr ][ col ] - 1;
            for ( kc=0; kc<Width; kc++ ) {
               OutIma[ out_row ][ out_col ] += *++p;
            }
         }
         OutIma[ out_row ][ out_col ] *= K;
         out_col++;
      }
      out_row++;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_SmoothImafloat */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPF_GCPE_Coherfloat

        $TYPE         FUNCTION

        $INPUT        x    : the array of shift values

        $MODIFIED     NONE

        $OUTPUT       cohe : the value of 1 minus the coherence for the given
                             two image cells

        $GLOBAL       IREGPV_coher : the structure with the matrix and variables
                                     used in the coherence evaluation

        $RET_STATUS   NONE

        $DESCRIPTION  This function evaluates the quantity 1 minus the averaged
                      coherence on two master and slave cells with the second
                      one shifted by two shift values

        $WARNING      NONE

        $PDL          - Shifts the slave cell
                      - Resets the slave cell eliminating the borders
                      - Evaluates the covariance matrix between master and
                        slave cell
                      - Evaluates the variance of the master cell
                      - Evaluates the variance of the slave cell
                      - Smooths the covariance
                      - Evaluates the coherence numerator
                      - Smooths the master variance
                      - Smooths the slave variance
                      - Evaluates the coherence denominator
                      - Evaluates the output matrix dimensions
                      - Evaluates the averaged value of the coherence
                      - Returns 1 minus the coherence

   $EH
   ========================================================================== */

double IREGPF_GCPE_Coherfloat
                        (/*IN    */ double              *x)
{
   const ERRSIT_proc_name routine_name = "IREGPF_GCPE_Coherfloat";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;
   INTx4                  NRow;
   INTx4                  NCol;
   double                 coher = (double)0;
   MATHIT_RC              shift;

/* ==========================================================================
   Default initialization
   ========================================================================== */
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Copy the shift
   ========================================================================== */
   shift.row = x[ 1 ];
   shift.col = x[ 2 ];

/* ==========================================================================
   Shift the slave matrix
   ========================================================================== */
   MATHIP_INTR_FFTConstShift ( IREGPV_coher.init_nrow, IREGPV_coher.init_ncol,
                               IREGPV_coher.data_type,
                               (void **)IREGPV_coher.init_slap, shift,
                               (void **)IREGPV_coher.curr_slap,
                               &log_status_code );
   ERRSIM_on_err_goto_exit ( log_status_code );

/* ==========================================================================
   Point the reduced matrix
   ========================================================================== */
   for ( row=0; row<IREGPV_coher.nrow; row++ ) {
      IREGPV_coher.masp[ row ] =
         &(IREGPV_coher.init_masp[ IREGPD_coher_bord + row ][
         IREGPD_coher_bord ]);
      IREGPV_coher.slap[ row ] =
         &(IREGPV_coher.curr_slap[ IREGPD_coher_bord + row ][
         IREGPD_coher_bord ]);
   }

/* ==========================================================================
   Evaluate the covariance matrix
   ========================================================================== */
   for ( row=0; row<IREGPV_coher.nrow; row++ ) {
      for ( col=0; col<IREGPV_coher.ncol; col++ ) {
         (IREGPV_coher.v1v2)[ row ][ col ] =
            (IREGPV_coher.masp)[ row ][ col ] *
            (IREGPV_coher.slap)[ row ][ col ];
      }
   }

/* ==========================================================================
   Smooth the covariance
   ========================================================================== */
   IREGPP_GCPE_SmoothImafloat ( IREGPV_coher.v1v2, IREGPV_coher.nrow,
                                IREGPV_coher.ncol, IREGPV_coher_wsiz,
                                IREGPV_coher.sv1v2, &log_status_code );

/* ==========================================================================
   Evaluate the variance of the master
   ========================================================================== */
   for ( row=0; row<IREGPV_coher.nrow; row++ ) {
      for ( col=0; col<IREGPV_coher.ncol; col++ ) {
         (IREGPV_coher.v1v1)[ row ][ col ] =
            (IREGPV_coher.masp)[ row ][ col ] *
            (IREGPV_coher.masp)[ row ][ col ];
      }
   }

/* ==========================================================================
   Evaluate the variance of the slave
   ========================================================================== */
   for ( row=0; row<IREGPV_coher.nrow; row++ ) {
      for ( col=0; col<IREGPV_coher.ncol; col++ ) {
         (IREGPV_coher.v2v2)[ row ][ col ] =
            (IREGPV_coher.slap)[ row ][ col ] *
            (IREGPV_coher.slap)[ row ][ col ];
      }
   }

/* ==========================================================================
   Evaluate the final dimensions
   ========================================================================== */
   NRow = (INTx4)(( IREGPV_coher.nrow - IREGPV_coher_wsiz ) /
      IREGPV_coher_wsiz) + 1;
   NCol = (INTx4)(( IREGPV_coher.ncol - IREGPV_coher_wsiz ) /
      IREGPV_coher_wsiz) + 1;

/* ==========================================================================
   Evaluate the coherence numerator
   ========================================================================== */
   for ( row=0; row<NRow; row++ ) {
      for ( col=0; col<NCol; col++ ) {
         (IREGPV_coher.cnum)[ row ][ col ] = (float)
         (ABS ( (IREGPV_coher.sv1v2)[ row ][ col ] ));
      }
   }

/* ==========================================================================
   Smooth the master covariance
   ========================================================================== */
   IREGPP_GCPE_SmoothImafloat ( IREGPV_coher.v1v1, IREGPV_coher.nrow,
                                IREGPV_coher.ncol, IREGPV_coher_wsiz,
                                IREGPV_coher.sv1v1, &log_status_code );

/* ==========================================================================
   Smooth the slave covariance
   ========================================================================== */
   IREGPP_GCPE_SmoothImafloat ( IREGPV_coher.v2v2, IREGPV_coher.nrow,
                                IREGPV_coher.ncol, IREGPV_coher_wsiz,
                                IREGPV_coher.sv2v2, &log_status_code );

/* ==========================================================================
   Evaluate the coherence denominator
   ========================================================================== */
   for ( row=0; row<NRow; row++ ) {
      for ( col=0; col<NCol; col++ ) {
         (IREGPV_coher.cden)[ row ][ col ] = (float)
            (sqrt ( (IREGPV_coher.sv1v1)[ row ][ col ] *
                    (IREGPV_coher.sv2v2)[ row ][ col ] ));
      }
   }

/* ==========================================================================
   Evaluate the average coherence value
   ========================================================================== */
   for ( row=0; row<NRow; row++ ) {
      for ( col=0; col<NCol; col++ ) {
         if ( (IREGPV_coher.cden)[ row ][ col ] != (float)0 ) {
            coher += (IREGPV_coher.cnum)[ row ][ col ] /
               (IREGPV_coher.cden)[ row ][ col ];
         }
      }
   }

   /* rescale for the square of the number of elements */
   coher *= 1. / (double)(NRow * NCol);

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, log_status_code, 
                          &log_status_code );

/* ==========================================================================
   Return the coherence
   ========================================================================== */
   return ( (double)1 - coher );

}/* IREGPF_GCPE_Coherfloat */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPF_GCPE_Coher2float

        $TYPE         FUNCTION

        $INPUT        x    : the array of shift values

        $MODIFIED     NONE

        $OUTPUT       cohe : the value of 1 minus the coherence for the given
                             two image cells

        $GLOBAL       IREGPV_coher : the structure with the matrix and variables
                                     used in the coherence evaluation

        $RET_STATUS   NONE

        $DESCRIPTION  This function evaluates the quantity 1 minus the averaged
                      coherence on two master and slave cells with the second
                      one shifted by two shift values

        $WARNING      NONE

        $PDL          - Shifts the slave cell
                      - Resets the slave cell eliminating the borders
                      - Evaluates the covariance matrix between master and
                        slave cell
                      - Evaluates the variance of the master cell
                      - Evaluates the variance of the slave cell
                      - Smooths the covariance
                      - Evaluates the coherence numerator
                      - Smooths the master variance
                      - Smooths the slave variance
                      - Evaluates the coherence denominator
                      - Evaluates the output matrix dimensions
                      - Evaluates the averaged value of the coherence
                      - Returns 1 minus the coherence value

   $EH
   ========================================================================== */

double IREGPF_GCPE_Coher2float
                        (/*IN    */ double              *x)
{
   const ERRSIT_proc_name routine_name = "IREGPF_GCPE_Coher2float";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;
   INTx4                  dc;
   INTx4                  NRow;
   INTx4                  NCol;
   double                 coher = (double)0;
   MATHIT_RC              shift;

/* ==========================================================================
   Default initialization
   ========================================================================== */
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Copy the shifts
   ========================================================================== */
   shift.row = x[ 1 ];
   shift.col = x[ 2 ];

/* ==========================================================================
   Shift the slave matrix
   ========================================================================== */
   MATHIP_INTR_FFTConstShift ( IREGPV_coher.init_nrow, IREGPV_coher.init_ncol,
                               IREGPV_coher.data_type,
                               (void **)IREGPV_coher.init_slap, shift, 
                               (void **)IREGPV_coher.curr_slap,
                               &log_status_code );
   ERRSIM_on_err_goto_exit ( log_status_code );

/* ==========================================================================
   Point the reduced matrix
   ========================================================================== */
   for ( row=0; row<IREGPV_coher.nrow; row++ ) {
      IREGPV_coher.masp[ row ] =
         &(IREGPV_coher.init_masp[ IREGPD_coher_bord + row ][
         2 * IREGPD_coher_bord ]);
      IREGPV_coher.slap[ row ] =
         &(IREGPV_coher.curr_slap[ IREGPD_coher_bord + row ][
         2 * IREGPD_coher_bord ]);
   }

/* ==========================================================================
   Evaluate the covariance matrix
   ========================================================================== */
   for ( row=0; row<IREGPV_coher.nrow; row++ ) {
      for ( col=0; col<IREGPV_coher.ncol; col++ ) {
         dc = 2 * col;
         (IREGPV_coher.v1v2)[ row ][ dc ] =
            (IREGPV_coher.masp)[ row ][ dc ] *
            (IREGPV_coher.slap)[ row ][ dc ] +
            (IREGPV_coher.masp)[ row ][ dc + 1 ] *
            (IREGPV_coher.slap)[ row ][ dc + 1 ];
         (IREGPV_coher.v1v2)[ row ][ dc + 1 ] =
            (IREGPV_coher.masp)[ row ][ dc + 1 ] *
            (IREGPV_coher.slap)[ row ][ dc ] -
            (IREGPV_coher.masp)[ row ][ dc ] *
            (IREGPV_coher.slap)[ row ][ dc + 1 ];
      }
   }

/* ==========================================================================
   Smooth the covariance
   ========================================================================== */
   IREGPP_GCPE_SmoothIma2float ( IREGPV_coher.v1v2, IREGPV_coher.nrow,
                                 IREGPV_coher.ncol, IREGPV_coher_wsiz,
                                 IREGPV_coher.sv1v2, &log_status_code );

/* ==========================================================================
   Evaluate the variance of the master
   ========================================================================== */
   for ( row=0; row<IREGPV_coher.nrow; row++ ) {
      for ( col=0; col<IREGPV_coher.ncol; col++ ) {
         dc = 2 * col;
         (IREGPV_coher.v1v1)[ row ][ col ] =
            (IREGPV_coher.masp)[ row ][ dc ] *
            (IREGPV_coher.masp)[ row ][ dc ] +
            (IREGPV_coher.masp)[ row ][ dc + 1 ] *
            (IREGPV_coher.masp)[ row ][ dc + 1 ];
      }
   }

/* ==========================================================================
   Evaluate the variance of the slave
   ========================================================================== */
   for ( row=0; row<IREGPV_coher.nrow; row++ ) {
      for ( col=0; col<IREGPV_coher.ncol; col++ ) {
         dc = 2 * col;
         (IREGPV_coher.v2v2)[ row ][ col ] =
            (IREGPV_coher.slap)[ row ][ dc ] *
            (IREGPV_coher.slap)[ row ][ dc ] +
            (IREGPV_coher.slap)[ row ][ dc + 1 ] *
            (IREGPV_coher.slap)[ row ][ dc + 1 ];
      }
   }

/* ==========================================================================
   Evaluate the final dimensions
   ========================================================================== */
   NRow = (INTx4)(( IREGPV_coher.nrow - IREGPV_coher_wsiz ) /
      IREGPV_coher_wsiz) + 1;
   NCol = (INTx4)(( IREGPV_coher.ncol - IREGPV_coher_wsiz ) /
      IREGPV_coher_wsiz) + 1;

/* ==========================================================================
   Evaluate the coherence numerator
   ========================================================================== */
   for ( row=0; row<NRow; row++ ) {
      for ( col=0; col<NCol; col++ ) {
         dc = 2 * col;
         (IREGPV_coher.cnum)[ row ][ col ] = (float)
            sqrt ( ( POW ( (IREGPV_coher.sv1v2)[ row ][ dc ], 2. ) +
                     POW ( (IREGPV_coher.sv1v2)[ row ][ dc + 1 ], 2. ) ) );
      }
   }

/* ==========================================================================
   Smooth the master covariance
   ========================================================================== */
   IREGPP_GCPE_SmoothImafloat ( IREGPV_coher.v1v1, IREGPV_coher.nrow,
                                IREGPV_coher.ncol, IREGPV_coher_wsiz,
                                IREGPV_coher.sv1v1, &log_status_code );

/* ==========================================================================
   Smooth the slave covariance
   ========================================================================== */
   IREGPP_GCPE_SmoothImafloat ( IREGPV_coher.v2v2, IREGPV_coher.nrow,
                                IREGPV_coher.ncol, IREGPV_coher_wsiz,
                                IREGPV_coher.sv2v2, &log_status_code );

/* ==========================================================================
   Evaluate the coherence denominator
   ========================================================================== */
   for ( row=0; row<NRow; row++ ) {
      for ( col=0; col<NCol; col++ ) {
         (IREGPV_coher.cden)[ row ][ col ] = (float)
            (sqrt ( (IREGPV_coher.sv1v1)[ row ][ col ] *
                    (IREGPV_coher.sv2v2)[ row ][ col ] ));
      }
   }

/* ==========================================================================
   Evaluate the average coherence value
   ========================================================================== */
   for ( row=0; row<NRow; row++ ) {
      for ( col=0; col<NCol; col++ ) {
         if ( (IREGPV_coher.cden)[ row ][ col ] != (float)0 ) {
            coher += (IREGPV_coher.cnum)[ row ][ col ] /
               (IREGPV_coher.cden)[ row ][ col ];
         }
      }
   }

   /* rescale for the square of the number of elements */
   coher *= 1. / (double)(NRow * NCol);
#ifdef __BLABLABLA__
   fprintf ( stdout, "\n shifts: %g %g coher: %g", shift.row, shift.col,
             coher );
#endif

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, log_status_code, 
                          &log_status_code );

/* ==========================================================================
   Return the coherence
   ========================================================================== */
   return ( (double)1 - coher );

}/* IREGPF_GCPE_Coher2float */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_InitFineReg

        $TYPE         PROCEDURE

        $INPUT        DataType : images data type

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_coher             : structure for the coherence
                                                 maximization
                      IREGPV_fine_cell_dim_row : cell dimension in the row
                                                 direction
                      IREGPV_fine_cell_dim_col : cell dimension in the column
                                                 direction

        $RET_STATUS   ERRSID_IREG_low_cell_dim
                      ERRSID_IREG_data_type_not_allow
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure initializes the structure that contains
                      the matrices and variables for the GCP(s) fine
                      registration

        $WARNING      THE MASTER AND SLAVE CELLS MUST BE OD float TYPE AND
                      WITH DIMENSIONS DEFINED BY THAT FOR THE FINE REGISTRATION
                      (<IREGPV_fine_cell_dim_row> and
                      <IREGPV_fine_cell_dim_col>)

        $PDL          - Checks the cells dimensions
                      - Switch over the data type
                            - Sets the data type structure element
                      - End Switch
                      - Sets the initial number of rows and columns
                      - Sets the middle master and slave dimensions
                      - Evaluates the final dimensions
                      - Allocates the initial master matrix
                      - Allocates the initial slave matrix
                      - Allocates the middle master matrix array
                      - Allocates the middle slave matrix array
                      - Allocates the covariance matrix
                      - Allocates the master variance matrix
                      - Allocates the slave variance matrix
                      - Allocates the smoothed covariance matrix
                      - Allocates the smoothed master variance matrix
                      - Allocates the smoothed slave variance matrix
                      - Allocates the numerator matrix
                      - Allocates the denominator matrix

   $EH
   ========================================================================== */

void IREGPP_GCPE_InitFineReg
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_InitFineReg";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;
   INTx1                  sam_pix;
   INTx4                  nrow_out;
   INTx4                  ncol_out;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the cells dimensions
   ========================================================================== */
   if ( ( ( IREGPV_fine_cell_dim_row - 2 * IREGPD_coher_bord ) <=
          (INTx4)IREGPD_min_cell_dim ) ||
        ( ( IREGPV_fine_cell_dim_row - 2 * IREGPD_coher_bord ) <=
          (INTx4)IREGPV_coher_wsiz ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_low_cell_dim,
                         "in the row direction" );
   }
   if ( ( ( IREGPV_fine_cell_dim_col - 2 * IREGPD_coher_bord ) <=
          (INTx4)IREGPD_min_cell_dim ) ||
        ( ( IREGPV_fine_cell_dim_col - 2 * IREGPD_coher_bord ) <=
          (INTx4)IREGPV_coher_wsiz ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_low_cell_dim,
                         "in the column direction" );
   }

/* ==========================================================================
   Set the sample per pixel
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_float:
         sam_pix = 1;
         IREGPV_coher.data_type = LDEFIE_dt_float;
      break;
      case LDEFIE_dt_2_float:
         sam_pix = 2;
         IREGPV_coher.data_type = LDEFIE_dt_2_float;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                            "in the fine registration process" );
   }

/* ==========================================================================
   Set the initial master and slave cell dimensions, ...
   ========================================================================== */
   IREGPV_coher.init_nrow = (INTx2)IREGPV_fine_cell_dim_row;
   IREGPV_coher.init_ncol = (INTx2)IREGPV_fine_cell_dim_col;

/* ==========================================================================
   ... the middle of them, ...
   ========================================================================== */
   IREGPV_coher.nrow = IREGPV_coher.init_nrow - 2 * IREGPD_coher_bord;
   IREGPV_coher.ncol = IREGPV_coher.init_ncol - 2 * IREGPD_coher_bord;

/* ==========================================================================
   ... and the final
   ========================================================================== */
   nrow_out = (INTx4)(( IREGPV_coher.nrow - IREGPV_coher_wsiz ) /
      IREGPV_coher_wsiz) + 1;
   ncol_out = (INTx4)(( IREGPV_coher.ncol - IREGPV_coher_wsiz ) /
      IREGPV_coher_wsiz) + 1;

/* ==========================================================================
   Allocate the current slave cell
   ========================================================================== */
   IREGPV_coher.curr_slap = (float **)NULL;
   if ( ( IREGPV_coher.curr_slap = (float **)MEMSIP_alloc ( (size_t)
                                                       (IREGPV_coher.init_nrow *
                                                       sizeof (float *)) ) ) ==
        (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the current slave image cell" );
   }
   for ( row=0; row<IREGPV_coher.init_nrow; row++ ) {
      IREGPV_coher.curr_slap[ row ] = (float *)NULL;
      if ( ( IREGPV_coher.curr_slap[ row ] = (float *)MEMSIP_alloc ( (size_t)
                                                       (IREGPV_coher.init_ncol *
                                                       sam_pix *
                                                       sizeof (float)) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the current slave image cell" );
      }
   }

/* ==========================================================================
   Allocate the middle master cell
   ========================================================================== */
   IREGPV_coher.masp = (float **)NULL;
   if ( ( IREGPV_coher.masp = (float **)MEMSIP_alloc ( (size_t)
                                                      (IREGPV_coher.nrow *
                                                      sizeof (float*)) ) ) ==
        (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the middle master image cell" );
   }

/* ==========================================================================
   Allocate the middle slave cell
   ========================================================================== */
   IREGPV_coher.slap = (float **)NULL;
   if ( ( IREGPV_coher.slap = (float **)MEMSIP_alloc ( (size_t)
                                                      (IREGPV_coher.nrow *
                                                      sizeof (float *)) ) ) ==
        (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the middle master image cell" );
   }

/* ==========================================================================
   Allocate the covariance matrix
   ========================================================================== */
   IREGPV_coher.v1v2 = (float **)NULL;
   if ( ( IREGPV_coher.v1v2 = (float **)MEMSIP_alloc ( (size_t)
                                                        (IREGPV_coher.nrow *
                                                        sizeof (float *)) ) ) ==
        (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the covariance matrix" );
   }
   for ( row=0; row<IREGPV_coher.nrow; row++ ) {
      IREGPV_coher.v1v2[ row ] = (float *)NULL;
      if ( ( IREGPV_coher.v1v2[ row ] = (float *)MEMSIP_alloc ( (size_t)
                                                          (IREGPV_coher.ncol *
                                                          sam_pix *
                                                          sizeof (float)) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the covariance matrix" );
      }
   }

/* ==========================================================================
   Allocate the master variance matrix
   ========================================================================== */
   IREGPV_coher.v1v1 = (float **)NULL;
   if ( ( IREGPV_coher.v1v1 = (float **)MEMSIP_alloc ( (size_t)
                                                        (IREGPV_coher.nrow *
                                                        sizeof (float *)) ) ) ==
        (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the master variance matrix" );
   }
   for ( row=0; row<IREGPV_coher.nrow; row++ ) {
      IREGPV_coher.v1v1[ row ] = (float *)NULL;
      if ( ( IREGPV_coher.v1v1[ row ] = (float *)MEMSIP_alloc ( (size_t)
                                                          (IREGPV_coher.ncol *
                                                          sizeof (float)) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the master variance matrix" );
      }
   }

/* ==========================================================================
   Allocate the slave variance matrix
   ========================================================================== */
   IREGPV_coher.v2v2 = (float **)NULL;
   if ( ( IREGPV_coher.v2v2 = (float **)MEMSIP_alloc ( (size_t)
                                                        (IREGPV_coher.nrow *
                                                        sizeof (float *)) ) ) ==
        (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the slave variance matrix" );
   }
   for ( row=0; row<IREGPV_coher.nrow; row++ ) {
      IREGPV_coher.v2v2[ row ] = (float *)NULL;
      if ( ( IREGPV_coher.v2v2[ row ] = (float *)MEMSIP_alloc ( (size_t)
                                                          (IREGPV_coher.ncol *
                                                          sizeof (float)) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the slave variance matrix" );
      }
   }

/* ==========================================================================
   Allocate the smoothed covariance matrix
   ========================================================================== */
   IREGPV_coher.sv1v2 = (float **)NULL;
   if ( ( IREGPV_coher.sv1v2 = (float **)MEMSIP_alloc ( (size_t)(nrow_out *
                                                        sizeof (float *)) ) ) ==
        (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the smoothed covariance" );
   }
   for ( row=0; row<nrow_out; row++ ) {
      IREGPV_coher.sv1v2[ row ] = (float *)NULL;
      if ( ( IREGPV_coher.sv1v2[ row ] = (float *)MEMSIP_alloc ( (size_t)
                                                          (ncol_out * sam_pix *
                                                          sizeof (float)) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the smoothed covariance" );
      }
   }

/* ==========================================================================
   Allocate the smoothed master variance matrix
   ========================================================================== */
   IREGPV_coher.sv1v1 = (float **)NULL;
   if ( ( IREGPV_coher.sv1v1 = (float **)MEMSIP_alloc ( (size_t)(nrow_out *
                                                        sizeof (float *)) ) ) ==
         (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the smoothed master variance matrix" );
   }
   for ( row=0; row<nrow_out; row++ ) {
      IREGPV_coher.sv1v1[ row ] = (float *)NULL;
      if ( ( IREGPV_coher.sv1v1[ row ] = (float *)MEMSIP_alloc ( (size_t)
                                                          (ncol_out *
                                                          sizeof (float)) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the smoothed master variance matrix" );
      }
   }

/* ==========================================================================
   Allocate the slave smoothed variance matrix
   ========================================================================== */
   IREGPV_coher.sv2v2 = (float **)NULL;
   if ( ( IREGPV_coher.sv2v2 = (float **)MEMSIP_alloc ( (size_t)(nrow_out *
                                                        sizeof (float *)) ) ) ==
         (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the smoothed slave variance matrix" );
   }
   for ( row=0; row<nrow_out; row++ ) {
      IREGPV_coher.sv2v2[ row ] = (float *)NULL;
      if ( ( IREGPV_coher.sv2v2[ row ] = (float *)MEMSIP_alloc ( (size_t)
                                                         (ncol_out *
                                                          sizeof (float)) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the smoothed slave variance matrix" );
      }
   }

/* ==========================================================================
   Allocate the coherence numerator matrix
   ========================================================================== */
   IREGPV_coher.cnum = (float **)NULL;
   if ( ( IREGPV_coher.cnum = (float **)MEMSIP_alloc ( (size_t)(nrow_out *
                                                        sizeof (float *)) ) ) ==
         (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the numerator matrix" );
   }
   for ( row=0; row<nrow_out; row++ ) {
      IREGPV_coher.cnum[ row ] = (float *)NULL;
      if ( ( IREGPV_coher.cnum[ row ] = (float *)MEMSIP_alloc ( (size_t)
                                                          (ncol_out *
                                                          sizeof (float)) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the numerator matrix" );
      }
   }

/* ==========================================================================
   Allocate the denominator matrix
   ========================================================================== */
   IREGPV_coher.cden = (float **)NULL;
   if ( ( IREGPV_coher.cden = (float **)MEMSIP_alloc ( (size_t)(nrow_out *
                                                        sizeof (float *)) ) ) ==
         (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the denomerator matrix" );
   }
   for ( row=0; row<nrow_out; row++ ) {
      IREGPV_coher.cden[ row ] = (float *)NULL;
      if ( ( IREGPV_coher.cden[ row ] = (float *)MEMSIP_alloc ( (size_t)
                                                          (ncol_out *
                                                          sizeof (float)) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the denominator matrix" );
      }
   }

/* ==========================================================================
   Allocate the ancillary matrices for the amoeba
   ========================================================================== */
   IREGPV_coher.p = (double *)NULL;
   if ( ( IREGPV_coher.p = (double *)MEMSIP_alloc ( (size_t)
                                                    (( IREGPD_coher_ndim + 1 ) *
                                                    IREGPD_coher_ndim *
                                                    sizeof (double)) ) ) ==
        (double *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the ancillary matrix for amoeba" );
   }
   IREGPV_coher.y = (double *)NULL;
   if ( ( IREGPV_coher.y = (double *)MEMSIP_alloc ( (size_t)
                                                    (( IREGPD_coher_ndim + 1 ) *
                                                    sizeof (double)) ) ) ==
        (double *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "in the ancillary matrix for amoeba" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_InitFineReg */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CloseFineReg

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_coher : the structure containing the fine
                                     registration INFO

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure closes the fine registration process
                      freeing all the allocated memories

        $WARNING      NONE

        $PDL          - Evaluates the rows and columns dimensions of the final
                        matrices
                      - Frees the middle master and slave arrays of pointers
                      - Frees the covariance matrix
                      - Frees the master and slave variance matrices
                      - Frees the smoothed covariance matrix
                      - Frees the smoothed master and slave variances
                      - Frees the numerator and denominator matrices

   $EH
   ========================================================================== */

void IREGPP_GCPE_CloseFineReg
                        (/*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_CloseFineReg";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  nrow_out;
   INTx4                  ncol_out;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the final dimensions
   ========================================================================== */
   nrow_out = (INTx4)(( IREGPV_coher.nrow - IREGPV_coher_wsiz ) /
      IREGPV_coher_wsiz) + 1;
   ncol_out = (INTx4)(( IREGPV_coher.ncol - IREGPV_coher_wsiz ) /
      IREGPV_coher_wsiz) + 1;

/* ==========================================================================
   Free the current slave cell
   ========================================================================== */
   if ( IREGPV_coher.curr_slap != (float **)NULL ) {
      for ( row=0; row<IREGPV_coher.init_nrow; row++ ) {
         MEMSIP_free ( (void **)&(IREGPV_coher.curr_slap[ row ]) );
      }
      MEMSIP_free ( (void **)&IREGPV_coher.curr_slap );
   }

/* ==========================================================================
   Free the master and slave middle cells ...
   ========================================================================== */
   MEMSIP_free ( (void **)&IREGPV_coher.masp );
   MEMSIP_free ( (void **)&IREGPV_coher.slap );

/* ==========================================================================
   ... the covariance matrix ...
   ========================================================================== */
   if ( IREGPV_coher.v1v2 != (float **)NULL ) {
      for ( row=0; row<IREGPV_coher.nrow; row++ ) {
         MEMSIP_free ( (void **)&(IREGPV_coher.v1v2[ row ]) );
      }
      MEMSIP_free ( (void **)&IREGPV_coher.v1v2 );
   }

/* ==========================================================================
   ... the master and slave variance ...
   ========================================================================== */
   if ( IREGPV_coher.v1v1 != (float **)NULL ) {
      for ( row=0; row<IREGPV_coher.nrow; row++ ) {
         MEMSIP_free ( (void **)&(IREGPV_coher.v1v1[ row ]) );
      }
      MEMSIP_free ( (void **)&IREGPV_coher.v1v1 );
   }
   if ( IREGPV_coher.v2v2 != (float **)NULL ) {
      for ( row=0; row<IREGPV_coher.nrow; row++ ) {
         MEMSIP_free ( (void **)&(IREGPV_coher.v2v2[ row ]) );
      }
      MEMSIP_free ( (void **)&IREGPV_coher.v2v2 );
   }

/* ==========================================================================
   ... the smoothed covariance matrix ...
   ========================================================================== */
   if ( IREGPV_coher.sv1v2 != (float **)NULL ) {
      for ( row=0; row<nrow_out; row++ ) {
         MEMSIP_free ( (void **)&(IREGPV_coher.sv1v2[ row ]) );
      }
      MEMSIP_free ( (void **)&IREGPV_coher.sv1v2 );
   }

/* ==========================================================================
   ... the smoothed master and slave variance matrix ...
   ========================================================================== */
   if ( IREGPV_coher.sv1v1 != (float **)NULL ) {
      for ( row=0; row<nrow_out; row++ ) {
         MEMSIP_free ( (void **)&(IREGPV_coher.sv1v1[ row ]) );
      }
      MEMSIP_free ( (void **)&IREGPV_coher.sv1v1 );
   }
   if ( IREGPV_coher.sv2v2 != (float **)NULL ) {
      for ( row=0; row<nrow_out; row++ ) {
         MEMSIP_free ( (void **)&(IREGPV_coher.sv2v2[ row ]) );
      }
      MEMSIP_free ( (void **)&IREGPV_coher.sv2v2 );
   }

/* ==========================================================================
   ... the coherence numerator matrix, ...
   ========================================================================== */
   if ( IREGPV_coher.cnum != (float **)NULL ) {
      for ( row=0; row<nrow_out; row++ ) {
         MEMSIP_free ( (void **)&(IREGPV_coher.cnum[ row ]) );
      }
      MEMSIP_free ( (void **)&IREGPV_coher.cnum );
   }

/* ==========================================================================
   ... the denominator ...
   ========================================================================== */
   if ( IREGPV_coher.cden != (float **)NULL ) {
      for ( row=0; row<nrow_out; row++ ) {
         MEMSIP_free ( (void **)&(IREGPV_coher.cden[ row ]) );
      }
      MEMSIP_free ( (void **)&IREGPV_coher.cden );
   }

/* ==========================================================================
   ... and the ancillary matrices to amoeba
   ========================================================================== */
   MEMSIP_free ( (void **)&IREGPV_coher.p );
   MEMSIP_free ( (void **)&IREGPV_coher.y );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_CloseFineReg */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CoherMaxim

        $TYPE         PROCEDURE

        $INPUT        master     : master image cell
                      slave      : slave image cell
                      DataType   : data size

        $MODIFIED     NONE

        $OUTPUT       eval_shift : shifts values that maximize the coherence
                                   between the two cells

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure evaluates the shifts values in the rows
                      and columns directions that maximize the coherence
                      between the two images cells

        $WARNING      THE INIIALIZATION PROCEDURE MUST BE CALLED YET WHEN THIS
                      ONE IS CALLED

        $PDL          - Points the initial master structure pointer to the
                        master matrix pointer
                      - Points the initial slave structure pointer to the
                        slave matrix pointer
                      - Fills the initial shifts values ( one more then the
                        problems dimensions )
                      - Fills with these values the ancillary matrix <p>
                      - Fills the ancillary array <y> with the values of the
                        function to maximize in the initial shifts values
                      - Evaluates the shifts that maximize the function of
                        coherence

   $EH
   ========================================================================== */

void IREGPP_GCPE_CoherMaxim
                        (/*IN    */ float              **master,
                         /*IN    */ float              **slave,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_RC           *eval_shift,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_CoherMaxim";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;
   MATHIT_RC              shift[ IREGPD_coher_ndim + 1 ];
   INTx4                  nfunk = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Point the initial master and slave matrices
   ========================================================================== */
   IREGPV_coher.init_masp = master;
   IREGPV_coher.init_slap = slave;

/* ==========================================================================
   Fill the ancillary matrix
   ========================================================================== */
   for ( row=0; row<( IREGPD_coher_ndim + 1 ); row++ ) {
      IREGPV_coher.p[ row * IREGPD_coher_ndim + 0 ] =
         IREGPC_coher_shift[ row ][ 0 ];
      IREGPV_coher.p[ row * IREGPD_coher_ndim + 1 ] =
         IREGPC_coher_shift[ row ][ 1 ];
   }

/* ==========================================================================
   Fill the ancillary array with the function in the starting simplex
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_float:
         for ( row=0; row<( IREGPD_coher_ndim + 1 ); row++ ) {
            IREGPV_coher.y[ row ] = IREGPF_GCPE_Coherfloat (
            (double *)(IREGPC_coher_shift[ row ] - 1) );
         }

/* ==========================================================================
   Maximize the coherence
   ========================================================================== */
         nfunk = 0;
         MATHIP_FMIN_amoeba ( IREGPD_coher_ndim, IREGPV_coher_ftol,
                              IREGPV_coher_vtol, IREGPF_GCPE_Coherfloat,
                              IREGPV_coher.p, IREGPV_coher.y, &nfunk,
                              status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case LDEFIE_dt_2_float:
         for ( row=0; row<( IREGPD_coher_ndim + 1 ); row++ ) {
            IREGPV_coher.y[ row ] = IREGPF_GCPE_Coher2float(
            (double *)(IREGPC_coher_shift[ row ] - 1) );
         }

/* ==========================================================================
   Maximize the coherence
   ========================================================================== */
         nfunk = 0;
         MATHIP_FMIN_amoeba ( IREGPD_coher_ndim, IREGPV_coher_ftol,
                              IREGPV_coher_vtol, IREGPF_GCPE_Coher2float,
                              IREGPV_coher.p, IREGPV_coher.y, &nfunk,
                              status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                            "in the coherence maximization procedure" );
   }

#ifdef __TRACE__
   fprintf ( stdout, "\n p matrix" );
   for ( row=0; row<( IREGPD_coher_ndim + 1 ); row ++ ) {
      fprintf ( stdout, "\n" );
      for ( col=0; col<IREGPD_coher_ndim; col++ ) {
         fprintf ( stdout, " p[%d][%d]=%g", row, col,
                   IREGPV_coher.p[ row * IREGPD_coher_ndim + col ] );
      }
   }
#endif
/* ==========================================================================
   Set the shifts in the rigth variables
   ========================================================================== */
   eval_shift->row = 0;
   eval_shift->col = 0;
   for ( row=0; row<( IREGPD_coher_ndim + 1 ); row ++ ) {
      eval_shift->row += IREGPV_coher.p[ row * IREGPD_coher_ndim ];
      eval_shift->col += IREGPV_coher.p[ row * IREGPD_coher_ndim + 1 ];
   }
   eval_shift->row /= (double)(IREGPD_coher_ndim + 1);
   eval_shift->col /= (double)(IREGPD_coher_ndim + 1);

/* ==========================================================================
   Change sign to the shifts
   ========================================================================== */
   eval_shift->row = - eval_shift->row;
   eval_shift->col = - eval_shift->col;

#ifdef __TRACE__
   fprintf ( stdout, "\n Number of iterations: %d", nfunk );
#endif

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_CoherMaxim */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FineRegistrator

        $TYPE         PROCEDURE

        $INPUT        inp_io : array with the descriptors of the images

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGIV_ima_num           : number of images
                      IREGPV_gcp               : structure containing the GCP
                                                 INFO
                      IREGPV_fine_cell_dim_row : cell dimension in the rows
                                                 direction
                      IREGPV_fine_cell_dim_col : cell dimension in the columns
                                                 direction

        $RET_STATUS   ERRSID_IREG_ima_num_inv

        $DESCRIPTION  This procedure is the driver of the GCP(s) fine
                      registration that evaluates the shifts between the GCP(s)
                      in the master image and each of the slaves using the
                      coherence maximization

        $WARNING      NONE

        $PDL          - Checks the number of images opened
                      - Allocates the array for the rotation angle
                      - Allocates the necessary memories for the master and
                        slave cells matrix storage
                      - If the image is a real one
                            - Loop over the opened slaves images
                                  - Evaluates the rotation angle between the
                                    master and the current slave image
                            - End Loop
                      - Else
                            - Sets the rotation angle to zero
                      - End If
                      - Evaluates the number of total GCPs
                      - Sets the image data type
                      - Loop over the GCP(s)
                            - If the validity flag of the master GCP is TRUE
                                  - Extracts the master cell
                                  - Loop over the slave(s) image(s)
                                        - If the validity flag of the GCP in
                                          the slave is TRUE
                                              - Extracts the slave cell at the
                                                given centre coordinates
                                              - If the cell is all inside
                                                the slave image
                                                    - Evaluates the shifts
                                                      in row and col
                                                      directions between the
                                                      two cells
                                                    - Rotates the shifts for
                                                      the rotation angle to
                                                      compensate the cell
                                                      rotation
                                                    - Updates the centre
                                                      coordinates by the
                                                      compensated shifts
                                              - Else
                                                    - Sets in the slave GCP(s)
                                                      INFO structure the
                                                      validity flag to FALSE
                                              - End If
                                        - End If
                                  - End Loop
                            - End If
                      - End Loop

   $EH
   ========================================================================== */
void IREGPP_GCPE_FineRegistrator
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_FineRegistrator";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double                *RotAngle = (double *)NULL;
   LDEFIT_data_type       DataType = LDEFIE_dt_undef;
   LDEFIT_data_type       float_dt = LDEFIE_dt_undef;
   float                **master = (float **)NULL;
   float                **slave = (float **)NULL;
   MATHIT_RC              shift;
   INTx1                  mas_imanum = 0;
   INTx1                  mas_gridnum = 0;
   INTx4                  Ngcp;
   INTx4                  gcp_i;
   INTx4                  ima;
   INTx4                  row;
   float                  filler = 0;
   INTx1                  valid_flag = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the number of opened image
   ========================================================================== */
   if ( ( IREGIV_ima_num < 2 ) || ( IREGIV_ima_num > IREGPD_max_img ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_ima_num_inv, "" );
   }

/* ==========================================================================
   Allocate the array of rotation angles and the master and slave cells
   ========================================================================== */
   IREGPP_GCPE_ArraysAllocation ( inp_io, mas_imanum, IREGPV_fine_cell_dim_row,
                                  IREGPV_fine_cell_dim_col, &RotAngle, &master,
                                  &slave, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Copy the GCP number
   ========================================================================== */
   Ngcp = IREGPV_gcp[ mas_gridnum ].n_gcp;

/* ==========================================================================
   Evaluate the rotation angle of the slave(s)
   ========================================================================== */
   if ( inp_io[ mas_imanum ].val.tif.bpar.sampleperpixel == 1 ) {
      float_dt = LDEFIE_dt_float;
      for ( ima=1; ima<IREGIV_ima_num; ima++ ) {
         IREGPP_GCPE_RotAngleEval ( mas_imanum, (INTx1)ima, &RotAngle[ ima ],
                                    status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }
   else {
      float_dt = LDEFIE_dt_2_float;
      memset ( (void *)RotAngle, '\0', (size_t)(IREGIV_ima_num *
               sizeof (double)) );
   }

/* ==========================================================================
   Initialize the fine registration procedure
   ========================================================================== */
   IREGPP_GCPE_InitFineReg ( float_dt, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Set the data type
   ========================================================================== */
   IREGPP_GCPE_SetDataType ( inp_io[ mas_imanum ], &DataType, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Print out
   ========================================================================== */
#ifndef __TRACE__
   fprintf ( stdout, "\n\n\n Fine Registration started ... \n\n\n" );
#endif

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) Ngcp*(IREGIV_ima_num-1), &log_status_code );

/* ==========================================================================
   Check for the shifts between the images
   ========================================================================== */
   for ( gcp_i=0; gcp_i<Ngcp; gcp_i++ ) {

/* ==========================================================================
   Check the validity flag for the master GCP
   ========================================================================== */
      if ( IREGPV_gcp[ mas_gridnum ].gcp_arr[ gcp_i ].valid ) {

/* ==========================================================================
   Extract the master cell
   ========================================================================== */
         IREGPP_GCPE_CellExtractor ( &inp_io[ mas_imanum ],
                                     IREGPV_gcp[ mas_gridnum ].gcp_arr[
                                     gcp_i ].coor, IREGPV_fine_cell_dim_row,
                                     IREGPV_fine_cell_dim_col, mas_imanum,
                                     filler, (double)0, &valid_flag,
                                     master, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Loop over the slave(s)
   ========================================================================== */
         for ( ima=1; ima<IREGIV_ima_num; ima++ ) {

/* ==========================================================================
   Print out
   ========================================================================== */
            SRVSIP_trace_comp ( &log_status_code );

/* ==========================================================================
   Check the validity flag for the slave GCP
   ========================================================================== */
            if ( IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].valid ) {

/* ==========================================================================
   Approximate the slave coordinates
   ========================================================================== */
               IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.row = (double)
                  ROUND ( IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.row );
               IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.col = (double)
                  ROUND ( IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.col );

/* ==========================================================================
   Extract the (rotated) slave cell
   ========================================================================== */
               valid_flag = 0;
               IREGPP_GCPE_CellExtractor ( &inp_io[ ima ],
                                           IREGPV_gcp[ ima ].gcp_arr[
                                           gcp_i ].coor,
                                           IREGPV_fine_cell_dim_row,
                                           IREGPV_fine_cell_dim_col, ima,
                                           filler,
                                           - RotAngle[ ima ], &valid_flag,
                                           slave, status_code );
               ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the validity flag of the slave cell extraction
   ========================================================================== */
               if ( valid_flag == 1 ) {

/* ==========================================================================
   Evaluate the fine shifts between the master and slave cell
   ========================================================================== */
                  IREGPP_GCPE_CoherMaxim ( master, slave, float_dt, &shift,
                                           status_code );
                  ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Compensate the shifts for the rotation angle
   ========================================================================== */
                  if ( inp_io[ mas_gridnum ].val.tif.bpar.sampleperpixel == 1 )
                  {
                     IREGPP_GCPE_RCRotate ( RotAngle[ ima ], &shift,
                                            status_code );
                     ERRSIM_on_err_goto_exit ( *status_code );
                  }

/* ==========================================================================
   Check the allowability of the shifts
   ========================================================================== */
#ifdef __TRACE__
   fprintf ( stdout, "\n GCP #%d, master coor = ( %f, %f )", gcp_i + 1,
             IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor.row,
             IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor.col );
   fprintf ( stdout, "\n eval shift = ( %f, %f )\n", shift.row, shift.col );
#endif
                  if ( ( ABS ( shift.row ) < IREGPD_max_fine_shift ) &&
                       ( ABS ( shift.col ) < IREGPD_max_fine_shift ) ) {

/* ==========================================================================
   Refine the GCP coordinates with the shifts
   ========================================================================== */
                     IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.row += shift.row;
                     IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.col += shift.col;

/* ==========================================================================
   Printout
   ========================================================================== */
#ifndef __TRACE__
/*
                     fprintf ( stdout, "\r The GCPs registered are the %3d",
                               ROUND(((float)(gcp_i + 1) /
                               IREGPV_gcp[ mas_gridnum ].n_gcp) *  100) );
                     fprintf ( stdout, " %% of the total" );
*/
#else
   fprintf ( stdout, " Evaluated Fine shifts: %g %g", shift.row, shift.col );
#endif
                  }
                  else {

/* ==========================================================================
   Set the invalidity of the GCP on that slave
   ========================================================================== */
                     IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].valid = FALSE;
                  }
               }
               else {

/* ==========================================================================
   Set invalid the GCP for the slave
   ========================================================================== */
                  IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].valid = FALSE;
               }
            }
         }
      }
      else {
/* ==========================================================================
   Print out over the slave(s) to reach 100%
   ========================================================================== */
         for ( ima=1; ima<IREGIV_ima_num; ima++ ) {
            SRVSIP_trace_comp ( &log_status_code );
         }
      }
   }

/* ==========================================================================
   Print out
   ========================================================================== */
   fprintf ( stdout, "\n\n Fine Registration ended\n" );

error_exit:;

/* ==========================================================================
   Close the fine registration procedure
   ========================================================================== */
   IREGPP_GCPE_CloseFineReg ( status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&RotAngle );

   if ( master != (float **)NULL ) {
      for ( row=0; row<IREGPV_fine_cell_dim_row; row++ ) {
         MEMSIP_free ( (void **)&(master[ row ]) );
      }
      MEMSIP_free ( (void **)&master );
   }

   if ( slave != (float **)NULL ) {
      for ( row=0; row<IREGPV_fine_cell_dim_row; row++ ) {
         MEMSIP_free ( (void **)&(slave[ row ]) );
      }
      MEMSIP_free ( (void **)&slave );
   }

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_FineRegistrator */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ReadGCPs

        $TYPE         PROCEDURE

        $INPUT        TLRow        : row coordinate of the top left corner of
                                     the AoI in which the registrator must act
                      TLCol        : column coordinate of the top left corner
                                     of the AoI in which the registrator must
                                     act
                      BRRow        : row coordinate of the bottom right corner
                                     of the AoI in which the registrator must
                                     act
                      BRCol        : column coordinate of the bottom right
                                     corner of the AoI in which the registrator
                                     must act
                      gcp_filename : GCP file name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_gcp   : GCP INFO structure

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure read the master GCPs from an external
                      file

        $WARNING      NONE

        $PDL          - Opens the input file
                      - Gets the first file line
                      - Reads the first element of the line
                      - Fills the structure
                      - Reads the second element
                      - Checks if the point is in the fixed AoI
                      - While of the other lines
                            - Gets the line
                            - Read the first element of the line
                            - Fills the structure
                            - Read the second element of the line
                      - End While
                      - Close the input file

   $EH
   ========================================================================== */

void IREGPP_GCPE_ReadGCPs
                        (/*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                BRRow,
                         /*IN    */ INTx4                BRCol,
                         /*IN    */ char                *gcp_filename,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_GCPE_ReadGCPs";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   FILE                  *finp = (FILE *)NULL;
   char                   str[ LDEFID_char_num ] = "";
   MATHIT_RC              coor;
   INTx4                  gcp_count = -1;
   UINTx1                 mas_gnum = 0;
   char                  *p = (char *)NULL;
   INTx4                  NRow;
   INTx4                  NCol;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Set the number of rows and columns
   ========================================================================== */
   NRow = BRRow - TLRow;
   NCol = BRCol - TLCol;

/* ==========================================================================
   Open the GCPs file
   ========================================================================== */
   FILSIP_open ( gcp_filename, "r", 0, &finp, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Read the first line
   ========================================================================== */
   if ( fgets ( str, (INTx4)LDEFID_char_num, finp ) == NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_no_elem_GCP,
                         gcp_filename );
   }

/* ==========================================================================
   Interpretate the first line
   ========================================================================== */
   if ( ( p = strtok ( str, ", " ) ) == NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_read_GCP_file,
                         gcp_filename );
   }

/* ==========================================================================
   Read the first element of the first row
   ========================================================================== */
   if ( sscanf ( p, "%lf", &coor.row ) != 1 ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_read_GCP_file,
                         gcp_filename );
   }
   else {

/* ==========================================================================
   Fill the structure
   ========================================================================== */
      IREGPV_gcp[ mas_gnum ].gcp_arr[ ++gcp_count ].coor.row = coor.row;

/* ==========================================================================
   Read the second element
   ========================================================================== */
      if ( ( p = strtok ( '\0', ", " ) ) == NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_read_GCP_file,
                            gcp_filename );
      }
      else {
         if ( sscanf ( p, "%lf", &coor.col ) != 1 ) {
            ERRSIM_set_error ( status_code, ERRSID_IREG_err_read_GCP_file,
                               gcp_filename );
         }
         else {

/* ==========================================================================
   Fill the structure
   ========================================================================== */
            IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp_count ].coor.col = coor.col;

/* ==========================================================================
   Check if the corners are in the AoI
   ========================================================================== */
            if ( ( ( coor.row >= TLRow ) && ( coor.row <= BRRow ) ) &&
                 ( ( coor.col >= TLCol ) && ( coor.col <= BRCol ) ) ) {

/* ==========================================================================
   Put it valid
   ========================================================================== */
               IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp_count ].valid = TRUE;
            }
            else {
               IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp_count ].valid = FALSE;
            }
         }
      }
   }

/* ==========================================================================
   Go on the other rows ... see comment above
   ========================================================================== */
   while ( fgets ( str, (INTx4)LDEFID_char_num, finp ) != NULL ) {
      if ( ( p = strtok ( str, ", " ) ) == NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_read_GCP_file,
                            gcp_filename );
      }
      if ( sscanf ( p, "%lf", &coor.row ) != 1 ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_read_GCP_file,
                            gcp_filename );
      }
      else {
         IREGPV_gcp[ mas_gnum ].gcp_arr[ ++gcp_count ].coor.row = coor.row;
         if ( ( p = strtok ( '\0', ", " ) ) == NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_IREG_err_read_GCP_file,
                               gcp_filename );
         }
         else {
            if ( sscanf ( p, "%lf", &coor.col ) != 1 ) {
               ERRSIM_set_error ( status_code, ERRSID_IREG_err_read_GCP_file,
                                  gcp_filename );
            }
            else {
               IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp_count ].coor.col = coor.col;
               if ( ( ( coor.row >= TLRow ) && ( coor.row <= BRRow ) ) &&
                    ( ( coor.col >= TLCol ) && ( coor.col <= BRCol ) ) ) {
                  IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp_count ].valid = TRUE;
               }
               else {
                  IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp_count ].valid = FALSE;
               }
            }
         }
      }
   }

/* ==========================================================================
   Fill the number of GCP field
   ========================================================================== */
   IREGPV_gcp[ mas_gnum ].n_gcp = gcp_count + 1;

#ifdef __TRACE__
   fprintf ( stdout, "\n Number of GCPs read = %d", 
             IREGPV_gcp[ mas_gnum ].n_gcp );
   for ( gcp_count=0; gcp_count<IREGPV_gcp[ mas_gnum ].n_gcp; gcp_count++ ) {
      fprintf ( stdout, "\n GCP #%d coor = ( %f, %f )", gcp_count,
                IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp_count ].coor.row,
                IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp_count ].coor.row );
   }
#endif
error_exit:;

/* ==========================================================================
   Close the input file
   ========================================================================== */
   FILSIP_close ( &finp, status_code );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_GCPE_ReadGCPs */

#ifdef __EXAM__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGIP_GCPE_

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void IREGIP_GCPE_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGIP_GCPE_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGIP_GCPE_ */
#endif
