/* ==========================================================================
   $MODULE_HEADER

      $NAME              GIOS_LIBS

      $FUNCTION          General IO services

      $ROUTINE           GIOSIP_init
                         GIOSIP_open_io
                         GIOSIP_close_io
                         GIOSIP_open_line
                         GIOSIP_read_block
                         GIOSIP_read_line
                         GIOSIP_write_line
                         GIOSIP_close_line

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       08-OCT-97     AN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */


#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include DEVS_INTF_H
#include FILS_INTF_H
#include BUFS_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include GIOS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_init

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Set the global structure

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void GIOSIP_init
                       ( /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "GIOSIP_init";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Init TIFS and BUFS services
   ========================================================================== */
   TIFSIP_init_filedata( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   BUFSIP_init_buffers( status_code );
   ERRSIM_on_err_goto_exit( *status_code );


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* GIOSIP_init */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_open_io

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     io   :   structure containing IO info

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_GIOS_not_supported_io

        $DESCRIPTION  This routine open an IO

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void GIOSIP_open_io
                       ( /*IN OUT*/ GIOSIT_io           *io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "GIOSIP_open_io";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code);

/* ==========================================================================
   Switch according to the IO type
   ========================================================================== */
   switch( io->type ) {
      case GIOSIE_buffer:
/* ==========================================================================
   Set spp and bps WRT the data type
   ========================================================================== */
         io->dt = io->val.buff.DataType;
         switch ( io->val.buff.DataType ) {
            case LDEFIE_dt_UINTx1:
               /* BYTE */
               io->spp = 1;
               io->bps = 8;
               break;
            case LDEFIE_dt_UINTx2:
               /* INT */
               io->spp = 1;
               io->bps = 16;
               break;
            case LDEFIE_dt_float:
               /* FLOAT */
               io->spp = 1;
               io->bps = 32;
               break;
            case LDEFIE_dt_2_float:
               /* COMPLEX */
               io->spp = 2;
               io->bps = 32;
               break;
            default:
               ERRSIM_set_error ( status_code, ERRSID_BUFS_not_allow_data_type, "" );
         }
         BUFSIP_open_buffer( io->val.buff.Buffer,
                             io->val.buff.NRows,
                             io->val.buff.NColumns,
                             io->val.buff.DataType,
                             io->mode,
                            &(io->chan),
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_tif:
         if( io->mode == 'r' ) {
            TIFSIP_open_tiff( io->val.tif.name,
                              io->mode,
                              (INTx4 *) &(io->chan),
                              status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            TIFSIP_get_imgnum( (INTx4) io->chan,
                              &(io->val.tif.nimg),
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            TIFSIP_get_blockinfo( (INTx4) io->chan,
                                  io->img,
                                 &(io->val.tif.bpar),
                                  status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            TIFSIP_get_parnum( (INTx4) io->chan,
                               io->img,
                              &(io->val.tif.npar),
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         else if( io->mode == 'w' ) {
            TIFSIP_set_imgnum( io->val.tif.name,
                               io->val.tif.nimg,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            if( io->val.tif.standard == TRUE ) {
               io->val.tif.npar = 
                  io->val.tif.npar - TIFSID_minus_nbpar_std_tif;
            }
            TIFSIP_set_parnum( io->val.tif.name,
                               io->img,
                               io->val.tif.npar,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            if( io->val.tif.standard == TRUE ) {
               io->val.tif.bpar.columnsperblock = 
                  io->val.tif.bpar.imagewidth;
               io->val.tif.bpar.rowsperblock = 1;
            }
            TIFSIP_set_blockinfo( io->val.tif.name,
                                  io->img,
                                 &(io->val.tif.bpar),
                                  status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            TIFSIP_open_tiff( io->val.tif.name,
                              io->mode,
                              (INTx4 *) &(io->chan),
                              status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            if( io->val.tif.standard == TRUE ) {
               TIFSIP_set_tif( io->chan,
                               io->img,
                              status_code );
               ERRSIM_on_err_goto_exit( *status_code );
            }

            TIFSIP_store_blockinfo((INTx4) io->chan,
                                    io->img,
                                    status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
         else {
            ERRSIM_set_error ( status_code,
                               ERRSID_GIOS_not_supported_io,
                               "tif mode" );
         }

         io->spp = io->val.tif.bpar.sampleperpixel;
         io->bps = io->val.tif.bpar.bitspersample[0];
         io->spf = io->val.tif.bpar.sampleformat[0];

         switch( io->spp ) {
            case 1:
               switch( io->bps ) {
                  case 8:
                     io->dt = LDEFIE_dt_UINTx1;
                     break;
                  case 16:
                     io->dt = LDEFIE_dt_UINTx2;
                     break;
                  case 32:
                     io->dt = LDEFIE_dt_float;
                     break;
                  default:
                     ERRSIM_set_error( status_code, 
                                       ERRSID_GIOS_not_supported_dt,
                                       "TIFF bitspersample");
               }
               break;
            case 2:
               switch( io->bps ) {
                  case 8:
                     io->dt = LDEFIE_dt_2_UINTx1;
                     break;
                  case 16:
                     io->dt = LDEFIE_dt_2_INTx2;
                     break;
                  case 32:
                     io->dt = LDEFIE_dt_2_float;
                     break;
                  default:
                     ERRSIM_set_error( status_code,
                                       ERRSID_GIOS_not_supported_dt,
                                       "TIFF bitspersample");
               }
               break;
            case 3:
               io->dt = LDEFIE_dt_undef;
               break;
            default:
               ERRSIM_set_error( status_code,
                                 ERRSID_GIOS_not_supported_dt,
                                 "TIFF samplesperpixel");
         }
         break;

      case GIOSIE_file:
         if( io->mode == 'r' ) {
            FILSIP_open( io->val.fil.fname,
                         "rb",
                         0,
                        &(io->val.fil.fp),
                         status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            io->val.fil.curr_start_line = -1;
            io->val.fil.curr_end_line = -1;
         }
         else if( io->mode == 'w' ) {
            FILSIP_open( io->val.fil.fname,
                         "wb",
                         io->val.fil.size,
                        &(io->val.fil.fp),
                         status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         else {
            ERRSIM_set_error ( status_code, 
                               ERRSID_GIOS_not_supported_io,
                               "file" );
         }

         break;

      case GIOSIE_device:
         if( io->mode != 'r' ) {
            ERRSIM_set_error ( status_code, 
                               ERRSID_GIOS_not_supported_io,
                               "write on file" );
         }

         DEVSIP_open_read( io->val.exa.media,
                           (INTx4 *) &(io->chan),
                           status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         DEVSIP_mount( io->val.exa.media,
                       (INTx4) io->chan,
                       status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         io->val.exa.curr_start_line = -1;
         io->val.exa.curr_end_line = -1;
         break;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* GIOSIP_open_io */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_close_io

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     io   :   structure containing IO info

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine close an IO.

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void GIOSIP_close_io
                       ( /*IN OUT*/ GIOSIT_io           *io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "GIOSIP_close_io";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code);

/* ==========================================================================
   Switch according to the IO type
   ========================================================================== */
   switch( io->type ) {
      case GIOSIE_buffer:
         BUFSIP_close_buffer( io->chan,
               status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_tif:
         TIFSIP_close_tiff( (INTx4) io->chan,
                            status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_file:
         FILSIP_close( &(io->val.fil.fp),
                          status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         MEMSIP_free( (void **) &(io->val.fil.curr_buff) );
         break;

      case GIOSIE_device:
         DEVSIP_dismount( io->val.exa.media,
                          (INTx4) io->chan,
                          status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         DEVSIP_close( (INTx4 *) &(io->chan),
                       status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         MEMSIP_free( (void **) &(io->val.exa.curr_buff) );
         break;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* GIOSIP_close_io */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_open_line

        $TYPE         PROCEDURE

        $INPUT        io          : io descriptor
            direction   : 'x' or 'y'
            samplestart : first sample in line
            sampleend   : last sample in line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   

        $DESCRIPTION  This procedure opens the reading or the writing of a line.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void GIOSIP_open_line
                       (/*IN    */ GIOSIT_io           *io,
                        /*IN    */ char                 direction,
                        /*IN    */ UINTx4               samplestart,
                        /*IN    */ UINTx4               sampleend,
                        /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "GIOSIP_open_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code);

/* ==========================================================================
   Switch according to the IO type
   ========================================================================== */
   switch( io->type ) {
      case GIOSIE_buffer:
         BUFSIP_open_line( io->chan,
                           direction,
                           samplestart,
                           sampleend,
                           status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_tif:
         TIFSIP_open_line( (INTx4) io->chan,
                           io->img,
                           direction,
                           samplestart,
                           sampleend,
                           status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_file:
         break;

      case GIOSIE_device:
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* GIOSIP_open_line */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_read_block

        $TYPE         PROCEDURE

        $INPUT        io         : io descriptor
                      firstline  : first line to be read
            lastline   : last line to read

        $MODIFIED     NONE

        $OUTPUT       buff       : double pointer to the output block

        $GLOBAL       GIOSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_GIOS_bad_dimensions
                 ERRSID_GIOS_err_no_block
                      ERRSID_GIOS_not_allow_data_type

        $DESCRIPTION  This procedure reads a block of lines from memory buffers.

        $WARNING      NONE

   $EH
   ========================================================================== */
void GIOSIP_read_block
                      ( /*IN    */ GIOSIT_io           *io,
                        /*IN    */ UINTx4               firstline,
                        /*IN    */ UINTx4               lastline,
                        /*IN    */ INTx4                data_size,
                        /*IN    */ DATA_TYPEIT          outtype,
                        /*   OUT*/ void               **buff,
                        /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "GIOSIP_read_block";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i;

#ifdef __TRACE__
   static UINTx4          tot_lines=0;
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check input
   ========================================================================== */
   if( firstline > lastline ) {
      ERRSIM_set_error( status_code, 
                        ERRSID_GIOS_err_line,
                        "io->val.exa.curr_buff" );
   }

/* ==========================================================================
   Switch according to the IO type
   ========================================================================== */
   switch( io->type ) {
      case GIOSIE_buffer:
         BUFSIP_read_block( io->chan,
                            firstline,
                            lastline,
                            buff,
                            status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_tif:
         TIFSIP_read_block( (INTx4) io->chan,
                            io->img,
                            firstline,
                            lastline,
                            outtype,
                            buff,
             status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_file:

#ifdef __TRACE__
fprintf(stderr,"Debug: ----------------------------------------------------\n");
fprintf(stderr, "Debug: firstline = %0d lastline = %0d data_size = %0d\n", 
   firstline, lastline, data_size);
fprintf(stderr, "Debug: curr_start_line = %0d curr_end_line = %0d\n",
   io->val.fil.curr_start_line, io->val.fil.curr_end_line );
#endif

         if( (io->val.fil.curr_start_line == -1) &&
             (io->val.fil.curr_end_line == -1) ) {

#ifdef __TRACE__
            fprintf( stderr, "Debug: A) start\n");
#endif

            io->val.fil.curr_start_line = (INTx4) firstline;
            io->val.fil.curr_end_line = (INTx4) lastline;

            if( (io->val.fil.curr_buff = 
                 (void **) MEMSIP_alloc( (size_t) (lastline-firstline+1) *
                                         sizeof(void *))) ==
                (void **) NULL ) {
               ERRSIM_set_error( status_code, 
                                 ERRSID_GIOS_err_mem_alloc, 
                                 "io->val.fil.curr_buff" );
            }
            for( i=0; i<(lastline-firstline+1); i++ ) {
               io->val.fil.curr_buff[ i ] = (void *) NULL;
               if( (io->val.fil.curr_buff[ i ] = 
                    (void *) MEMSIP_alloc( (size_t) data_size ) ) ==
                    (void *) NULL) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_GIOS_err_mem_alloc, 
                                    "io->val.fil.curr_buff" );
               }
#ifdef __TRACE__
               fprintf( stderr, "Debug: A) curr_buff[ %0d ] at %0d\n", i,
                           io->val.fil.curr_buff[ i ] );
#endif
            }

#ifdef __TRACE__
            fprintf( stderr, "Debug: A) reading block %d\n", 
                     lastline-firstline+1);
#endif

            FILSIP_read_block(io->val.fil.fp,
                              data_size,
                              lastline - firstline + 1,
                              buff,
                              status_code);
            ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
            tot_lines += lastline-firstline+1;
#endif

            for( i=0; i<(lastline-firstline+1); i++ ) {
               memcpy( io->val.fil.curr_buff[ i ],
                       buff[ i ],
                       (size_t) data_size );
            }
            io->val.fil.curr_start_line = (INTx4) firstline;
            io->val.fil.curr_end_line = (INTx4) lastline;

         }
         else if( firstline > io->val.fil.curr_end_line ) {

            if( (lastline - firstline) != 
                (io->val.fil.curr_end_line - io->val.fil.curr_start_line) ) {
               for( i=0; i<(lastline-firstline+1); i++ ) {
                  MEMSIP_free( (void **) &( io->val.fil.curr_buff[ i ] ) );
               }
               MEMSIP_free( (void **) &( io->val.fil.curr_buff ) );
               if( (io->val.fil.curr_buff =
                    (void **) MEMSIP_alloc( (size_t) (lastline-firstline+1) *
                                            sizeof(void *))) ==
                   (void **) NULL ) {
                  ERRSIM_set_error( status_code,
                                    ERRSID_GIOS_err_mem_alloc,
                                    "io->val.fil.curr_buff" );
               }
               for( i=0; i<(lastline-firstline+1); i++ ) {
                  io->val.fil.curr_buff[ i ] = (void *) NULL;
                  if( (io->val.fil.curr_buff[ i ] =
                       (void *) MEMSIP_alloc( (size_t) data_size ) )
                       == (void *) NULL) {
                     ERRSIM_set_error( status_code,
                                       ERRSID_GIOS_err_mem_alloc,
                                       "io->val.fil.curr_buff" );
                  }
               }
            }

#ifdef __TRACE__
            fprintf( stderr, "Debug: B) skip = %0d\n", 
                     firstline-io->val.fil.curr_end_line-1);
#endif
            for( i=0; i<(firstline-io->val.fil.curr_end_line-1); i++) {
               FILSIF_read( io->val.fil.fp,
                            data_size,
                            io->val.fil.curr_buff[ 0 ],
                            status_code );
               ERRSIM_on_err_goto_exit( *status_code );
            }

#ifdef __TRACE__
            tot_lines += firstline-io->val.fil.curr_end_line-1;
#endif

#ifdef __TRACE__
            fprintf( stderr, "Debug: B) reading block %d\n", 
                     lastline-firstline+1);
#endif
            FILSIP_read_block( io->val.fil.fp,
                               data_size,
                               lastline - firstline + 1,
                               buff,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
            tot_lines += lastline-firstline+1;
#endif

            for( i=0; i<(lastline-firstline+1); i++ ) {
               memcpy( io->val.fil.curr_buff[ i ],
                       buff[ i ],
                       (size_t) data_size );
            }
            io->val.fil.curr_start_line = (INTx4) firstline;
            io->val.fil.curr_end_line = (INTx4) lastline;


         }
         else if( firstline <= io->val.fil.curr_end_line ) {
            UINTx4 curr_size = io->val.fil.curr_end_line - io->val.fil.curr_start_line + 1;
            UINTx4 new_size = lastline - firstline + 1;
 
#ifdef __TRACE__
            fprintf( stderr, "Debug: C) curr_size = %0d new_size = %0d\n",
                     curr_size, new_size );
#endif

            for( i=0; i<(io->val.fil.curr_end_line-firstline+1); i++ ) {
#ifdef __OLD__
               memcpy( io->val.fil.curr_buff[ i ],
                       io->val.fil.curr_buff[ i + 
                                              firstline -
                                              io->val.fil.curr_start_line ], 
                       data_size );
#endif
               memcpy( buff[ i ],
                       io->val.fil.curr_buff[ i + 
                                              firstline -
                                              io->val.fil.curr_start_line ], 
                       data_size );
#ifdef __TRACE__
               fprintf( stderr, "Debug: C) Copy from %0d to %0d\n", 
                           i + firstline - io->val.fil.curr_start_line, i );
#endif
            } 

            if( new_size < curr_size ) {
               for( i=0; i<(curr_size-new_size); i++ ) {
                  MEMSIP_free( (void **) &( io->val.fil.curr_buff[ i + new_size ] ) );
               }
               if( (io->val.fil.curr_buff = 
                    (void **) MEMSIP_realloc( (void *) io->val.fil.curr_buff, new_size * sizeof(void *))) ==
                   (void **) NULL ) {
                  ERRSIM_set_error( status_code,
                                    ERRSID_GIOS_err_mem_alloc,
                                    "io->val.fil.curr_buff" );
               }
            }
            else if ( new_size > curr_size ) {
               if( (io->val.fil.curr_buff = 
                    (void **) MEMSIP_realloc( (void *) io->val.fil.curr_buff, new_size * sizeof(void *))) ==
                   (void **) NULL ) {
                  ERRSIM_set_error( status_code,
                                    ERRSID_GIOS_err_mem_alloc,
                                    "io->val.fil.curr_buff" );
               }
               for( i=0; i<(new_size-curr_size); i++ ) {
                  if( (io->val.fil.curr_buff[ i + curr_size ] =
                       (void *) MEMSIP_alloc( (size_t) data_size ) ) ==
                      (void *) NULL) {
                     ERRSIM_set_error( status_code,
                                       ERRSID_GIOS_err_mem_alloc,
                                       "io->val.fil.curr_buff" );
                  }
               }
            }


#ifdef __TRACE__
            fprintf( stderr, "Debug: C) lastline - io->val.fil.curr_end_line = %0d\n\
                              io->val.fil.curr_end_line - firstline + 1 = %0d\n",
                     lastline - io->val.fil.curr_end_line,
                     io->val.fil.curr_end_line - firstline + 1 );
#endif

            FILSIP_read_block( io->val.fil.fp,
                               data_size,
                               lastline - io->val.fil.curr_end_line,
                              &(buff[ io->val.fil.curr_end_line - 
                                      firstline + 1 ]),
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
            tot_lines += lastline - io->val.fil.curr_end_line;
#endif

#ifdef __OLD__
            for( i=io->val.fil.curr_end_line - firstline + 1; 
                 i<lastline - firstline + 1; i++ ) {
               memcpy( io->val.fil.curr_buff[ i ],
                       buff[ i ],
                       (size_t) data_size );
            }
#endif
            for( i=0; i<(lastline-firstline+1); i++ ) {
               memcpy( io->val.fil.curr_buff[ i ],
                       buff[ i ],
                       (size_t) data_size );
            }
            io->val.fil.curr_start_line = (INTx4) firstline;
            io->val.fil.curr_end_line = (INTx4) lastline;

         }
#ifdef __TRACE__
         fprintf( stderr, "Debug: tot_lines = %0d\n", tot_lines);

fprintf(stderr,"Debug: ----------------------------------------------------\n");
fprintf(stderr,"Debug: firstline = %0d lastline = %0d data_size = %0d\n", 
   firstline, lastline, data_size);
fprintf( stderr, "Debug: curr_start_line = %0d curr_end_line = %0d\n",
   io->val.fil.curr_start_line, io->val.fil.curr_end_line );
#endif

         break;

      case GIOSIE_device:

#ifdef __TRACE__
fprintf(stderr,"Debug: ----------------------------------------------------\n");
fprintf(stderr,"Debug: firstline = %0d lastline = %0d data_size = %0d\n", 
   firstline, lastline, data_size);
fprintf(stderr, "Debug: curr_start_line = %0d curr_end_line = %0d\n",
   io->val.exa.curr_start_line, io->val.exa.curr_end_line );
#endif

         if( (io->val.exa.curr_start_line == -1) &&
             (io->val.exa.curr_end_line == -1) ) {

#ifdef __TRACE__
            fprintf( stderr, "Debug: A) start\n");
#endif

            io->val.exa.curr_start_line = (INTx4) firstline;
            io->val.exa.curr_end_line = (INTx4) lastline;

            if( (io->val.exa.curr_buff = 
                 (void **) MEMSIP_alloc( (size_t) (lastline-firstline+1) *
                                         sizeof(void *))) ==
                (void **) NULL ) {
               ERRSIM_set_error( status_code, 
                                 ERRSID_GIOS_err_mem_alloc, 
                                 "io->val.exa.curr_buff" );
            }
            for( i=0; i<(lastline-firstline+1); i++ ) {
               io->val.exa.curr_buff[ i ] = (void *) NULL;
               if( (io->val.exa.curr_buff[ i ] = 
                    (void *) MEMSIP_alloc( (size_t) data_size ) ) ==
                    (void *) NULL) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_GIOS_err_mem_alloc, 
                                    "io->val.exa.curr_buff" );
               }
#ifdef __TRACE__
               fprintf( stderr, "Debug: A) curr_buff[ %0d ] at %0d\n", i,
                           io->val.exa.curr_buff[ i ] );
#endif
            }

#ifdef __TRACE__
            fprintf( stderr, "Debug: A) reading block %d\n", 
                     lastline-firstline+1);
#endif

            DEVSIP_read_block( (INTx4) io->chan,
                               data_size,
                               lastline-firstline+1,
                               buff,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
            tot_lines += lastline-firstline+1;
#endif

            for( i=0; i<(lastline-firstline+1); i++ ) {
               memcpy( io->val.exa.curr_buff[ i ],
                       buff[ i ],
                       (size_t) data_size );
            }
            io->val.exa.curr_start_line = (INTx4) firstline;
            io->val.exa.curr_end_line = (INTx4) lastline;

         }
         else if( firstline > io->val.exa.curr_end_line ) {

            if( (lastline - firstline) != 
                (io->val.exa.curr_end_line - io->val.exa.curr_start_line) ) {
               for( i=0; i<(lastline-firstline+1); i++ ) {
                  MEMSIP_free( (void **) &( io->val.exa.curr_buff[ i ] ) );
               }
               MEMSIP_free( (void **) &( io->val.exa.curr_buff ) );
               if( (io->val.exa.curr_buff =
                    (void **) MEMSIP_alloc( (size_t) (lastline-firstline+1) *
                                            sizeof(void *))) ==
                   (void **) NULL ) {
                  ERRSIM_set_error( status_code,
                                    ERRSID_GIOS_err_mem_alloc,
                                    "io->val.exa.curr_buff" );
               }
               for( i=0; i<(lastline-firstline+1); i++ ) {
                  io->val.exa.curr_buff[ i ] = (void *) NULL;
                  if( (io->val.exa.curr_buff[ i ] =
                       (void *) MEMSIP_alloc( (size_t) data_size ) )
                       == (void *) NULL) {
                     ERRSIM_set_error( status_code,
                                       ERRSID_GIOS_err_mem_alloc,
                                       "io->val.exa.curr_buff" );
                  }
               }
            }

#ifdef __TRACE__
            fprintf( stderr, "Debug: B) skip = %0d\n", 
                     firstline-io->val.exa.curr_end_line-1);
#endif
            for( i=0; i<(firstline-io->val.exa.curr_end_line-1); i++) {
               DEVSIF_read( (INTx4) io->chan,
                            data_size,
                            io->val.exa.curr_buff[ 0 ],
                            status_code );
               ERRSIM_on_err_goto_exit( *status_code );
            }

#ifdef __TRACE__
            tot_lines += firstline-io->val.exa.curr_end_line-1;
#endif

#ifdef __TRACE__
            fprintf( stderr, "Debug: B) reading block %d\n", 
                     lastline-firstline+1);
#endif
            DEVSIP_read_block( (INTx4) io->chan,
                               data_size,
                               lastline-firstline+1,
                               buff,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
            tot_lines += lastline-firstline+1;
#endif

            for( i=0; i<(lastline-firstline+1); i++ ) {
               memcpy( io->val.exa.curr_buff[ i ],
                       buff[ i ],
                       (size_t) data_size );
            }
            io->val.exa.curr_start_line = (INTx4) firstline;
            io->val.exa.curr_end_line = (INTx4) lastline;


         }
         else if( firstline <= io->val.exa.curr_end_line ) {
            UINTx4 curr_size = io->val.exa.curr_end_line - io->val.exa.curr_start_line + 1;
            UINTx4 new_size = lastline - firstline + 1;
 
#ifdef __TRACE__
            fprintf( stderr, "Debug: C) curr_size = %0d new_size = %0d\n",
                     curr_size, new_size );
#endif

            for( i=0; i<(io->val.exa.curr_end_line-firstline+1); i++ ) {
               memcpy( buff[ i ],
                       io->val.exa.curr_buff[ i + 
                                              firstline -
                                              io->val.exa.curr_start_line ], 
                       data_size );
#ifdef __TRACE__
               fprintf( stderr, "Debug: C) Copy from %0d to %0d\n", 
                           i + firstline - io->val.exa.curr_start_line, i );
#endif
            } 

            if( new_size < curr_size ) {
               for( i=0; i<(curr_size-new_size); i++ ) {
                  MEMSIP_free( (void **) &( io->val.exa.curr_buff[ i + new_size ] ) );
               }
               if( (io->val.exa.curr_buff = 
                    (void **) MEMSIP_realloc( (void *) io->val.exa.curr_buff, new_size * sizeof(void *))) ==
                   (void **) NULL ) {
                  ERRSIM_set_error( status_code,
                                    ERRSID_GIOS_err_mem_alloc,
                                    "io->val.exa.curr_buff" );
               }
            }
            else if ( new_size > curr_size ) {
               if( (io->val.exa.curr_buff = 
                    (void **) MEMSIP_realloc( (void *) io->val.exa.curr_buff, new_size * sizeof(void *))) ==
                   (void **) NULL ) {
                  ERRSIM_set_error( status_code,
                                    ERRSID_GIOS_err_mem_alloc,
                                    "io->val.exa.curr_buff" );
               }
               for( i=0; i<(new_size-curr_size); i++ ) {
                  if( (io->val.exa.curr_buff[ i + curr_size ] =
                       (void *) MEMSIP_alloc( (size_t) data_size ) ) ==
                      (void *) NULL) {
                     ERRSIM_set_error( status_code,
                                       ERRSID_GIOS_err_mem_alloc,
                                       "io->val.exa.curr_buff" );
                  }
               }
            }


#ifdef __TRACE__
            fprintf( stderr, "Debug: C) lastline - io->val.exa.curr_end_line = %0d\n\
                              io->val.exa.curr_end_line - firstline + 1 = %0d\n",
                     lastline - io->val.exa.curr_end_line,
                     io->val.exa.curr_end_line - firstline + 1 );
#endif

            DEVSIP_read_block( (INTx4) io->chan,
                               data_size,
                               lastline - io->val.exa.curr_end_line,
                              &(buff[ io->val.exa.curr_end_line - 
                                      firstline + 1 ]),
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
            tot_lines += lastline - io->val.exa.curr_end_line;
#endif

            for( i=0; i<(lastline-firstline+1); i++ ) {
               memcpy( io->val.exa.curr_buff[ i ],
                       buff[ i ],
                       (size_t) data_size );
            }
            io->val.exa.curr_start_line = (INTx4) firstline;
            io->val.exa.curr_end_line = (INTx4) lastline;

         }
#ifdef __TRACE__
         fprintf( stderr, "Debug: tot_lines = %0d\n", tot_lines);
#endif
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* GIOSIP_read_block */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_read_line

        $TYPE         PROCEDURE

        $INPUT        io         : io descriptor
                      linenumber : line to be read
                      datasize   : size of record for devices

        $MODIFIED     NONE

        $OUTPUT       bufout     : address of pointer to void buffer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure reads a line (next line for devices).

        $WARNING      NONE

   $EH
   ========================================================================== */
void GIOSIP_read_line
                      ( /*IN    */ GIOSIT_io           *io,
                        /*IN    */ UINTx4               linenumber,
                        /*IN    */ INTx4                data_size,
                        /*   OUT*/ void               **bufout,
                        /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "GIOSIP_read_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Switch according to the IO type
   ========================================================================== */
   switch( io->type ) {
      case GIOSIE_buffer:
         BUFSIP_read_line( io->chan,
                           linenumber,
                           bufout,
                           status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_tif:
         TIFSIP_read_line( (INTx4) io->chan,
                           io->img,
                           linenumber,
                           bufout,
                           status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_file:
         FILSIF_read( io->val.fil.fp,
                      data_size,
                     *bufout,
                      status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_device:
         DEVSIF_read( (INTx4) io->chan,
                      data_size,
                     *bufout,
                      status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* GIOSIP_read_line */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_write_line

        $TYPE         PROCEDURE

        $INPUT        io         : io descriptor
                      linenumber : line to be written
                      bufin      : pointer to void buffer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure writes a line.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void GIOSIP_write_line ( /*IN    */ GIOSIT_io           *io,
                         /*IN    */ UINTx4               linenumber,
                         /*   OUT*/ void                *bufin,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "GIOSIP_write_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);
      
/* ==========================================================================
   Switch according to the IO type
   ========================================================================== */
   switch( io->type ) {
      case GIOSIE_buffer:
         BUFSIP_write_line( io->chan,
                            linenumber,
                            bufin,
                            status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_tif:
         TIFSIP_write_line( (INTx4) io->chan,
                            io->img,
                            linenumber,
                            bufin,
                            status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_file:
         ERRSIM_set_error ( status_code, 
                            ERRSID_GIOS_not_supported_io,
                            "write on device" );

      case GIOSIE_device:
         ERRSIM_set_error ( status_code, 
                            ERRSID_GIOS_not_supported_io,
                            "write on device" );

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* GIOSIP_write_line */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_close_line

        $TYPE         PROCEDURE

        $INPUT        io          : io descriptor

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       GIOSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure close the reading or writing of a line on
                      buffers.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void GIOSIP_close_line
                       ( /*IN    */ GIOSIT_io           *io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "GIOSIP_close_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Switch according to the IO type
   ========================================================================== */
   switch( io->type ) {
      case GIOSIE_buffer:
         BUFSIP_close_line( io->chan,
                            status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         break;

      case GIOSIE_tif:
         TIFSIP_close_line( (INTx4) io->chan,
                            io->img,
                            status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case GIOSIE_file:
         break;

      case GIOSIE_device:
         break;

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* GIOSIP_close_line */

#ifdef __SUBS__

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_LIBS_

        $TYPE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void GIOSIP_LIBS_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "GIOSIP_LIBS_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* GIOSIP_LIBS_ */
#endif
