/* ==========================================================================
   $MODULE_HEADER

      $NAME              IREG_COHE

      $FUNCTION          This module contains the procedures for the task
                         COHERENCE IMAGE GENERATION

      $ROUTINE           IREGIP_COHE_OverlapAndSave
                         IREGPP_COHE_AllocImages
                         IREGPP_COHE_CoreFunc
                         IREGPP_COHE_FillVal
                         IREGPP_COHE_MoveCol
                         IREGPP_COHE_MoveRow

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       23-MAR-98     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>
#include <math.h>
#include <string.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include SRVS_INTF_H
#include MATH_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include OVLS_INTF_H
#include IREG_INTF_H
#include IREG_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGIP_COHE_OverlapAndSave

        $TYPE         PROCEDURE

        $INPUT        inp_io    : array of descriptors of the input files
                      out_io    : pointer to the descriptor of the output file
                      TLRow     : row coordinate of the top left images corner
                      TLCol     : column coordinate of the top left images
                                  corner
                      NRow      : number of rows of the input and of the output
                                  images
                      NCol      : number of columns of the input and of the
                                  output images
                      WinSize   : window sizes for the coherence evaluation

        $MODIFIED     NONE

        $OUTPUT       The output file is filled

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_ima_not_comp
                      ERRSID_IREG_null_ima_dim
                      ERRSID_IREG_kernel_dim_high

        $DESCRIPTION  This procedure fills the coherence image starting from
                      two co-registered ones. The evaluation has step 1 and
                      a window size user defined

        $WARNING      NONE

        $PDL          - Checks the input parameters
                      - Evaluates the reading window row size regarding to the
                        allowable memory on the machine
                      - Allocates the input images blocks and the output image
                        array
                      - Opens the lines for the input and the output files
                      - Sets the utility variables and counters
                      - Zeroes the output array
                      - Loop over the rows for the first half window size of
                        the output image
                            - Writes the empty lines border in the output
                              image
                            - Updates the writing row counter
                      - End Loop
                      - While the window can be read from the file
                            - Reads the input images blocks
                            - Calls the core function
                            - Updates the starting counter
                      - End While
                      - If it is possible read a number of rows greather then
                        the window size
                            - Reads the input images blocks
                            - Calls the core function
                      - End If
                      - Zeroes the output array
                      - Loop over the rows for the last half window size of
                        the output image
                            - Writes the empty lines border in the output
                              image
                            - Updates the writing row counter
                      - End Loop
                      - Closes the lines for the input and the output files
                      - Frees the allocated memories

   $EH
   ========================================================================== */

void IREGIP_COHE_OverlapAndSave
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               NRow,
                         /*IN    */ UINTx4               NCol,
                         /*IN    */ UINTx4               RowWinSize,
                         /*IN    */ UINTx4               ColWinSize,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGIP_COHE_OverlapAndSave";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   LDEFIT_boolean         openf_flag[ 3 ] = { FALSE, FALSE, FALSE };
   size_t                 elem_size;
   DATA_TYPEIT            inp_type;
   UINTx1                 ref_ima = 0;
   UINTx2                 NInpImages = 2;
   UINTx2                 ima;
   UINTx2                 halfWin;
   UINTx4                 RReadDim;
   UINTx4                 row;
   UINTx4                 RStartR;
   UINTx4                 RStartW;
   UINTx4                 AllocRowNum;
   INTx4                  data_size = 0;
   float               ***InpIma = (float ***)NULL;
   float                 *OutIma = (float *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the input images consistency
   ========================================================================== */
   if ( ( inp_io[ 1 ].spp != inp_io[ 0 ].spp ) ||
        ( inp_io[ 1 ].bps != inp_io[ 0 ].bps ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_ima_not_comp, "" );
   }

/* ==========================================================================
   Check the numbers of rows and columns
   ========================================================================== */
   if ( ( NRow == 0 ) || ( NCol == 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_ima_dim, "" );
   }

/* ==========================================================================
   Check the window size
   ========================================================================== */
   if ( ( RowWinSize > NRow ) || ( ColWinSize > NCol ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_kernel_dim_high, "" );
   }

/* ==========================================================================
   Evaluate the rows reading dimensions
   ========================================================================== */
   OVLSIP_CheckMemory ( inp_io, (UINTx4)NInpImages, out_io, 1, NCol, NCol,
                        &RReadDim, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the reading block dimension
   ========================================================================== */
   if ( RReadDim > NRow ) {
      RReadDim = NRow;
   }

/* ==========================================================================
   Check the reading dimensions consistency
   ========================================================================== */
   if ( RReadDim < RowWinSize ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_kernel_dim_high, "" );
   }

/* ==========================================================================
   Allocate the input images
   ========================================================================== */
   AllocRowNum = RReadDim;
   IREGPP_COHE_AllocImages ( inp_io[ ref_ima ].dt, NInpImages, RReadDim, NCol,
                             &InpIma, &OutIma, &inp_type, &elem_size,
                             status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Opening the reading mode for the input files
   ========================================================================== */
   for ( ima=0; ima<NInpImages; ima++ ) {
      GIOSIP_open_line ( &inp_io[ ima ], 'x', TLCol, TLCol + NCol - 1,
                         status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      openf_flag[ ima ] = TRUE;
   }

/* ==========================================================================
   Open the write mode for the output file
   ========================================================================== */
   GIOSIP_open_line ( out_io, 'x', 0, NCol - 1, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   openf_flag[ NInpImages ] = TRUE;

/* ==========================================================================
   Evaluate the border dimensions
   ========================================================================== */
   halfWin = (UINTx2)(RowWinSize / 2);

/* ==========================================================================
   Set the reading rows counter
   ========================================================================== */
   RStartR = TLRow;
   RStartW = 0;

/* ==========================================================================
   Zero the array
   ========================================================================== */
   memset ( (void *)OutIma, '\0', (size_t)(NCol * elem_size) );

/* ==========================================================================
   Fill the upper image bord
   ========================================================================== */
   for ( row=0; row<halfWin; row++ ) {
      GIOSIP_write_line ( out_io, RStartW, (void *)OutIma, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      RStartW++;
   }

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) NRow, &log_status_code );

/* ==========================================================================
   Begin the loop
   ========================================================================== */
   while ( ( RStartR + RReadDim ) <= ( TLRow + NRow ) ) {
#ifdef __TRACE__
   fprintf ( stdout, "\n --- Trace ---- " );
   fprintf ( stdout, "\n RReadDim = %d\n", RReadDim );
#endif

/* ==========================================================================
   Read the input blocks
   ========================================================================== */
      for ( ima=0; ima<NInpImages; ima++ ) {
         GIOSIP_read_block ( &inp_io[ ima ], RStartR, RStartR + RReadDim - 1,
                             data_size, inp_type, (void **)InpIma[ ima ],
                             status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }

/* ==========================================================================
   Call the core function
   ========================================================================== */
      IREGPP_COHE_CoreFunc ( inp_io[ ref_ima ].dt, RReadDim, NCol, RowWinSize,
                             ColWinSize, InpIma, out_io, OutIma, &RStartW,
                             status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Update the starting row
   ========================================================================== */
      RStartR += RReadDim - RowWinSize + 1;
   }

/* ==========================================================================
   Last rows ... see comments above
   ========================================================================== */
   if ( ( TLRow + NRow - RStartR ) >= RowWinSize ) {
      RReadDim = (UINTx4)(TLRow + NRow - RStartR);
#ifdef __TRACE__
   fprintf ( stdout, "\n --- Trace ---- " );
   fprintf ( stdout, "\n RReadDim = %d\n", RReadDim );
#endif
      for ( ima=0; ima<NInpImages; ima++ ) {
         GIOSIP_read_block ( &inp_io[ ima ], RStartR, RStartR + RReadDim - 1,
                             data_size, inp_type, (void **)InpIma[ ima ],
                             status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
      IREGPP_COHE_CoreFunc ( inp_io[ ref_ima ].dt, RReadDim, NCol, RowWinSize,
                             ColWinSize, InpIma, out_io, OutIma, &RStartW,
                             status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Zero the array
   ========================================================================== */
   memset ( (void *)OutIma, '\0', (size_t)(NCol * elem_size) );

/* ==========================================================================
   Fill the lower image bord
   ========================================================================== */
   for ( row=RStartW; row<NRow; row++ ) {
      GIOSIP_write_line ( out_io, row, (void *)OutIma, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

/* ==========================================================================
   Close the opened line modes for the TIFFs files
   ========================================================================== */
   for ( ima=0; ima<NInpImages; ima++ ) {
      if ( openf_flag[ ima ] ) {
         GIOSIP_close_line ( &inp_io[ ima ], &log_status_code );
         ERRSIM_on_err_goto_exit ( log_status_code );
      }
   }
   if ( openf_flag[ NInpImages ] ) {
      GIOSIP_close_line ( out_io, &log_status_code );
      ERRSIM_on_err_goto_exit ( log_status_code );
   }

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   if ( InpIma != (float ***)NULL ) {
      for ( ima=0; ima<NInpImages; ima++ ) {
         for ( row=0; row<AllocRowNum; row++ ) {
            MEMSIP_free ( (void **)&InpIma[ ima ][ row ] );
         }
         MEMSIP_free ( (void **)&InpIma[ ima ] );
      }
   }
   MEMSIP_free ( (void **)&InpIma );

   MEMSIP_free ( (void **)&OutIma );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGIP_COHE_OverlapAndSave */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_COHE_AllocImages

        $TYPE         PROCEDURE

        $INPUT        DataType  : image data type
                      NImages   : number of input images
                      NRow      : number of rows of the image blocks
                      NCol      : number of columns of the image blocks

        $MODIFIED     NONE

        $OUTPUT       InpIma    : array of input images blocks
                      OutIma    : array of output image
                      inp_type  : input data type for read block procedures
                      elem_size : element size of the images

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_null_ima_dim
                      ERRSID_OVLS_err_mem_alloc

        $DESCRIPTION  This procedure allocates the array of input image blocks
                      for the Overlap And Save algorithm

        $WARNING      NONE

        $PDL          - Checks the input parameters
                      - Switch over the data types
                            - Defines the element size
                      - End Switch
                      - Allocates the blocks of images

   $EH
   ========================================================================== */
void IREGPP_COHE_AllocImages
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ UINTx4               NImages,
                         /*IN    */ UINTx4               NRow,
                         /*IN    */ UINTx4               NCol,
                         /*   OUT*/ float            ****InpIma,
                         /*   OUT*/ float              **OutIma,
                         /*   OUT*/ DATA_TYPEIT         *inp_type,
                         /*   OUT*/ size_t              *elem_size,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_COHE_AllocImages";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 ima;
   UINTx4                 row;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the number of images
   ========================================================================== */
   if ( ( NImages == 0 ) || ( NImages > MAX_FILES ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_ima_num_inv, "" );
   }

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
   if ( ( NRow == 0 ) || ( NCol == 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_ima_dim, "" );
   }

/* ==========================================================================
   Set the element size
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx1:
         *elem_size = sizeof (UINTx1);
         *inp_type = DATA_TYPE_UINTx1;
      break;
      case LDEFIE_dt_UINTx2:
         *elem_size = sizeof (UINTx2);
         *inp_type = DATA_TYPE_UINTx2;
      break;
      case LDEFIE_dt_float: 
         *elem_size = sizeof (float);
         *inp_type = DATA_TYPE_float;
      break;
      case LDEFIE_dt_2_UINTx1:
         *elem_size = (size_t)(2 * sizeof (UINTx1));
         *inp_type = DATA_TYPE_UINTx1;
      break;
      case LDEFIE_dt_2_INTx2:
         *elem_size = (size_t)(2 * sizeof (INTx2));
         *inp_type = DATA_TYPE_INTx2;
      break;
      case LDEFIE_dt_2_float:
         *elem_size = (size_t)(2 * sizeof (float));
         *inp_type = DATA_TYPE_float;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_OVLS_data_type_not_allow, "" );
   }

/* ==========================================================================
   Allocate the input block images
   ========================================================================== */
   if ( ( *InpIma = (float ***)MEMSIP_alloc ( (size_t)(NImages *
                                             sizeof (float **)) ) ) ==
        (float ***)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_OVLS_err_mem_alloc, "" );
   }
   for ( ima=0; ima<NImages; ima++ ) {
      ( *InpIma )[ ima ] = (float **)NULL;
      if ( ( ( *InpIma )[ ima ] = (float **)MEMSIP_alloc ( (size_t)(NRow *
                                                      sizeof (float *)) ) ) ==
           (float **)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_OVLS_err_mem_alloc, "" );
      }
      for ( row=0; row<NRow; row++ ) {
         if ( ( ( *InpIma )[ ima ][ row ] = (float *)MEMSIP_alloc ( (size_t)
                                                  (NCol * ( *elem_size )) ) ) ==
              (float *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }
      }
   }

/* ==========================================================================
   Allocate the output image array
   ========================================================================== */
   if ( ( *OutIma = (float *)MEMSIP_alloc ( (size_t)(NCol *
                                            ( *elem_size )) ) ) ==
        (float *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_OVLS_err_mem_alloc, "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_COHE_AllocImages */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_COHE_CoreFunc

        $TYPE         PROCEDURE

        $INPUT        DataType   : input image data type
                      NRow       : number of rows of the block
                      NCol       : number of columns of the block
                      RowWinSize : coherence window dimension
                      ColWinSize : coherence window dimension
                      WinSize    : coherence window dimension
                      InpIma     : input image block
                      inp_io     : array of input file descriptors
                      out_io     : pointer to the output file descriptor
                      OutIma     : array to store a row of the output
                                   image

        $MODIFIED     RowW       : counter to the current writing row

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_null_win_size
                      ERRSID_IREG_kernel_dim_high

        $DESCRIPTION  This procedure evaluates the coherence of two co-
                      registered images moving a window with a unitary step
                      and sizes user defined

        $WARNING      NONE

        $PDL          - Checks the input parameters
                      - While the window is inside the image block in the rows
                        direction
                            - If the row is even
                                  - Set the starting column of the moving window
                                    at zero
                                  - While the window is inside the image block
                                    in the columns direction
                                        - If it's the first window in the block
                                              - Evaluates the covariance and the
                                                variances of the window
                                        - Else If the current window is at the
                                          left block margin
                                              - Evaluates the covariance and the
                                                variances with the new row above
                                                the window and taking off the
                                                old first row of it
                                        - Else
                                              - Evaluates the covariance and the
                                                variances with the new column on
                                                the right of the current window
                                                position and takes off the old
                                                column on the left of it
                                        - End If
                                        - Evaluate the coherence for that window
                                          position
                                        - Increments the columns counter
                                  - End While
                                  - Write the output image row in the output
                                    file
                                  - Increments the output row counter
                            - Else
                                  - Set the starting column of the moving window
                                    at the last decremented by the window size
                                    in the column direction
                                  - While the window is inside the image block
                                    in the columns direction
                                        - If it's the first window in the block
                                              - Evaluates the covariance and the
                                                variances with the new row above
                                                the window and taking off the
                                                old first row of it
                                        - Else
                                              - Evaluates the covariance and the
                                                variances with the new column on
                                                the left of the current window
                                                position and takes off the old
                                                column on the right of it
                                        - End If
                                        - Evaluate the coherence for that window
                                          position
                                        - Decrements the columns counter
                                  - End While
                                  - Write the output image row in the output
                                    file
                                  - Increments the output row counter
                            - End If
                            - Increments the input images rows counter
                      - End While

   $EH
   ========================================================================== */

void IREGPP_COHE_CoreFunc
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ UINTx4               NRow,
                         /*IN    */ UINTx4               NCol,
                         /*IN    */ UINTx4               RowWinSize,
                         /*IN    */ UINTx4               ColWinSize,
                         /*IN    */ float             ***InpIma,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ float               *OutIma,
                         /*IN OUT*/ UINTx4              *RowW,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_COHE_CoreFunc";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double                 cov[ 2 ];
   double                 var1;
   double                 var2;
   UINTx4                 h;
   INTx2                  row;
   INTx2                  col;
   INTx4                  rs;
   INTx4                  cs;
   double                 sqrtarg;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the window size
   ========================================================================== */
   if ( ( RowWinSize == 0 ) || ( ColWinSize == 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_win_size, "" );
   }

/* ==========================================================================
   Check the block sizes
   ========================================================================== */
   if ( ( NRow < RowWinSize ) || ( NCol < ColWinSize ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_kernel_dim_high, "" );
   }

/* ==========================================================================
   Evaluate the semi dimensions
   ========================================================================== */
   h = (UINTx4)(ColWinSize / 2);

/* ==========================================================================
   Start the moving window action
   ========================================================================== */
   rs = 0;
   while ( ( rs + RowWinSize ) <= NRow ) {

/* ==========================================================================
   Print out
   ========================================================================== */
      SRVSIP_trace_comp ( &log_status_code );

/* ==========================================================================
   Evaluate the columns loop direction
   ========================================================================== */
      if ( !( rs % 2 ) ) {

/* ==========================================================================
   From left to right columns loop
   ========================================================================== */
         cs = 0;
         while ( ( cs + ColWinSize ) <= NCol ) {
            if ( ( rs == 0 ) && ( cs == 0 ) ) {

/* ==========================================================================
   Fill the first block
   ========================================================================== */
               IREGPP_COHE_FillVal ( DataType, RowWinSize, ColWinSize,
                                     rs, cs, InpIma[ 0 ], InpIma[ 1 ], cov,
                                     &var1, &var2, status_code );
               ERRSIM_on_err_goto_exit ( *status_code );
            }
            else if ( ( rs != 0 ) && ( cs == 0 ) ) {

/* ==========================================================================
   Move from old position to new one row above
   ========================================================================== */
               IREGPP_COHE_MoveRow ( DataType, ColWinSize,
                                     rs + RowWinSize - 1, rs - 1, cs,
                                     InpIma[ 0 ], InpIma[ 1 ], cov, &var1,
                                     &var2, status_code );
               ERRSIM_on_err_goto_exit ( *status_code );
            }
            else {

/* ==========================================================================
   Move from old position to one column right
   ========================================================================== */
               IREGPP_COHE_MoveCol ( DataType, RowWinSize, rs,
                                     cs - 1 + ColWinSize, cs - 1, InpIma[ 0 ],
                                     InpIma[ 1 ], cov, &var1, &var2,
                                     status_code );
               ERRSIM_on_err_goto_exit ( *status_code );
            }

/* ==========================================================================
   Evaluate the coherence
   ========================================================================== */
            switch ( DataType ) {
               case LDEFIE_dt_float:
                  sqrtarg = var1 * var2;
                  if ( sqrtarg <= (double)0 ) {
                     if ( ABS ( sqrtarg ) < IREGPD_sqrt_tol ) {
                        OutIma[ cs + h ] = 0.;
                     }
                     else {
                        ERRSIM_set_error ( status_code, ERRSID_IREG_math_err,
                                           "sqrt domain error" );
                     }
                  }
                  else {
                     OutIma[ cs + h ] = (float)(ABS ( cov[ 0 ] ) /
                        sqrt ( sqrtarg ));
                  }
               break;
               case LDEFIE_dt_2_float:
                  sqrtarg = var1 * var2;
                  if ( sqrtarg <= (double)0 ) {
                     if ( ABS ( sqrtarg ) < IREGPD_sqrt_tol ) {
                        OutIma[ cs + h ] = 0.;
                     }
                     else {
                        ERRSIM_set_error ( status_code, ERRSID_IREG_math_err,
                                           "sqrt domain error" );
                     }
                  }
                  else {
                     OutIma[ cs + h ] = (float)(sqrt ( cov[ 0 ] * cov[ 0 ] +
                        cov[ 1 ] * cov[ 1 ] ) / sqrt ( sqrtarg ));
                  }
               break;
            }

/* ==========================================================================
   Increments the column counter
   ========================================================================== */
            cs++;
         }

/* ==========================================================================
   Write the row in the output file
   ========================================================================== */
         GIOSIP_write_line ( out_io, *RowW, (void *)OutIma, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Increment the writing row
   ========================================================================== */
         ( *RowW ) ++;
      }
      else {

/* ==========================================================================
   From right to left columns loop
   ========================================================================== */
         cs = NCol - ColWinSize;
         while ( cs >= 0 ) {

/* ==========================================================================
   Start reading the image buffer
   ========================================================================== */
            if ( cs == ( NCol - ColWinSize ) ) {

/* ==========================================================================
   Move the last column block one row above
   ========================================================================== */
               IREGPP_COHE_MoveRow ( DataType, ColWinSize,
                                     rs + RowWinSize - 1, rs - 1, cs,
                                     InpIma[ 0 ], InpIma[ 1 ], cov, &var1,
                                     &var2, status_code );
               ERRSIM_on_err_goto_exit ( *status_code );
            }
            else {

/* ==========================================================================
   Move the image block one column left
   ========================================================================== */
               IREGPP_COHE_MoveCol ( DataType, RowWinSize, rs, cs,
                                     cs + ColWinSize, InpIma[ 0 ], InpIma[ 1 ],
                                     cov, &var1, &var2, status_code );
               ERRSIM_on_err_goto_exit ( *status_code );
            }

/* ==========================================================================
   Write the row in the output file
   ========================================================================== */
            switch ( DataType ) {
               case LDEFIE_dt_float:
                  sqrtarg = var1 * var2;
                  if ( sqrtarg <= (double)0 ) {
                     if ( ABS ( sqrtarg ) < IREGPD_sqrt_tol ) {
                        OutIma[ cs + h ] = 0.;
                     }
                     else {
                        ERRSIM_set_error ( status_code, ERRSID_IREG_math_err,
                                           "sqrt domain error" );
                     }
                  }
                  else {
                     OutIma[ cs + h ] = (float)(ABS ( cov[ 0 ] ) /
                        sqrt ( sqrtarg ));
                  }
               break;
               case LDEFIE_dt_2_float:
                  sqrtarg = var1 * var2;
                  if ( sqrtarg <= (double)0 ) {
                     if ( ABS ( sqrtarg ) < IREGPD_sqrt_tol ) {
                        OutIma[ cs + h ] = 0.;
                     }
                     else {
                        ERRSIM_set_error ( status_code, ERRSID_IREG_math_err,
                                           "sqrt domain error" );
                     }
                  }
                  else {
                     OutIma[ cs + h ] = (float)(sqrt ( cov[ 0 ] * cov[ 0 ] +
                        cov[ 1 ] * cov[ 1 ] ) / sqrt ( sqrtarg ));
                  }
               break;
            }

/* ==========================================================================
   Decrement the current column
   ========================================================================== */
            cs --;
         }

/* ==========================================================================
   Write the row in the output file
   ========================================================================== */
         GIOSIP_write_line ( out_io, *RowW, (void *)OutIma, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Increment the writing row
   ========================================================================== */
         ( *RowW ) ++;
      }

/* ==========================================================================
   Increment the current row
   ========================================================================== */
      rs ++;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_COHE_CoreFunc */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_COHE_FillVal

        $TYPE         PROCEDURE

        $INPUT        DataType : image data type
                      NRow     : window size in the row direction
                      NCol     : window size in the column direction
                      StartRow : starting row
                      StartCol : starting column
                      InpIma1  : first image to multiply
                      InpIma2  : second image to multiply

        $MODIFIED     NONE

        $OUTPUT       cov      : current covariance value to modify
                      var1     : current variance value of the first image
                                 to modify
                      var2     : current variance value of the second image
                                 to modify

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure fills the values of the covariance of
                      to images and their variances

        $WARNING      NONE

        $PDL          - Switches over the data types
                            - Loop over the rows
                                  - Loop over the columns
                                        - Fills the covariance value
                                        - Fills the variance of the first
                                          image
                                        - Fills the variance of the second
                                          image
                                  - End Loop
                            - End Loop
                      - End Switch

   $EH
   ========================================================================== */

void IREGPP_COHE_FillVal
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ UINTx4               NRow,
                         /*IN    */ UINTx4               NCol,
                         /*IN    */ UINTx4               StartRow,
                         /*IN    */ UINTx4               StartCol,
                         /*IN    */ float              **InpIma1,
                         /*IN    */ float              **InpIma2,
                         /*IN OUT*/ double              *cov,
                         /*IN OUT*/ double              *var1,
                         /*IN OUT*/ double              *var2,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_COHE_FillVal";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 row;
   UINTx4                 col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Switch over the various data type
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_float:
         for ( row=0, *cov=*var1=*var2=0.; row<NRow; row++ ) {
            for ( col=0; col<NCol; col++ ) {

/* ==========================================================================
   Fill the covariance of the real images
   ========================================================================== */
               *cov += (double)InpIma1[ StartRow + row ][ StartCol + col ] *
                  (double)InpIma2[ StartRow + row ][ StartCol + col ];

/* ==========================================================================
   Fill their variances
   ========================================================================== */
               *var1 += (double)InpIma1[ StartRow + row ][ StartCol + col ] *
                  (double)InpIma1[ StartRow + row ][ StartCol + col ];
               *var2 += (double)InpIma2[ StartRow + row ][ StartCol + col ] *
                  (double)InpIma2[ StartRow + row ][ StartCol + col ];
            }
         }
      break;
      case LDEFIE_dt_2_float: {

/* ==========================================================================
   Complex images. See comments above ...
   ========================================================================== */
         cov[ 0 ] = cov[ 1 ] = 0.;
         *var1 = *var2 = 0.;
         for ( row=0; row<NRow; row++ ) {
            for ( col=0; col<NCol; col++ ) {
               cov[ 0 ] +=
                  (double)InpIma1[ StartRow + row ][ ( StartCol + col ) * 2 ] *
                  (double)InpIma2[ StartRow + row ][ ( StartCol + col ) * 2 ] +
                  (double)InpIma1[ StartRow + row ][ ( StartCol + col ) * 2 + 1] *
                  (double)InpIma2[ StartRow + row ][ ( StartCol + col ) * 2 + 1 ];
               cov[ 1 ] +=
                  (double)InpIma1[ StartRow + row ][ ( StartCol + col ) * 2 + 1] *
                  (double)InpIma2[ StartRow + row ][ ( StartCol + col ) * 2 ] -
                  (double)InpIma1[ StartRow + row ][ ( StartCol + col ) * 2 ] *
                  (double)InpIma2[ StartRow + row ][ ( StartCol + col ) * 2 + 1 ];
               *var1 +=
                  (double)InpIma1[ StartRow + row ][ ( StartCol + col ) * 2 ] *
                  (double)InpIma1[ StartRow + row ][ ( StartCol + col ) * 2 ] +
                  (double)InpIma1[ StartRow + row ][ ( StartCol + col ) * 2 + 1] *
                  (double)InpIma1[ StartRow + row ][ ( StartCol + col ) * 2 + 1 ];
               *var2 +=
                  (double)InpIma2[ StartRow + row ][ ( StartCol + col ) * 2 ] *
                  (double)InpIma2[ StartRow + row ][ ( StartCol + col ) * 2 ] +
                  (double)InpIma2[ StartRow + row ][ ( StartCol + col ) * 2 + 1] *
                  (double)InpIma2[ StartRow + row ][ ( StartCol + col ) * 2 + 1 ];
            }
         }
      }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                            "for the coherence evaluation" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_COHE_FillVal */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_COHE_MoveCol

        $TYPE         PROCEDURE

        $INPUT        DataType : image data type
                      Kr       : window size in the row direction
                      RStart   : starting row
                      COn      : column to add
                      COff     : column to exclude
                      InpIma1  : first image to multiply
                      InpIma2  : second image to multiply

        $MODIFIED     cov      : current covariance value to modify
                      var1     : current variance value of the first image
                                 to modify
                      var2     : current variance value of the second image
                                 to modify

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure updates the current value of the
                      covariance of two images windows and their variances
                      taking off the vaue at the given column and taking on the
                      other indicated

        $WARNING      NONE

        $PDL          - Switches over the data types
                            - Subtracts the old row from the covariance
                            - Sums the new one
                            - Subtracts the old row from the first image
                              variance
                            - Sums the new one
                            - Subtracts the old row from the second image
                              variance
                            - Sums the new one
                      - End Switch

   $EH
   ========================================================================== */

void IREGPP_COHE_MoveCol
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               RStart,
                         /*IN    */ UINTx4               COn,
                         /*IN    */ UINTx4               COff,
                         /*IN    */ float              **InpIma1,
                         /*IN    */ float              **InpIma2,
                         /*IN OUT*/ double               *cov,
                         /*IN OUT*/ double               *var1,
                         /*IN OUT*/ double               *var2,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_COHE_MoveCol";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Switch over the various data type
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_float:

/* ==========================================================================
   Updates the real images covariance
   ========================================================================== */
         for ( row=0; row<Kr; row++ ) {
            cov[ 0 ] -= (double)InpIma1[ RStart + row ][ COff ] *
               (double)InpIma2[ RStart + row ][ COff ];
            cov[ 0 ] += (double)InpIma1[ RStart + row ][ COn ] *
               (double)InpIma2[ RStart + row ][ COn ];

/* ==========================================================================
   First image variance
   ========================================================================== */
            *var1 -= (double)InpIma1[ RStart + row ][ COff ] *
               (double)InpIma1[ RStart + row ][ COff ];
            *var1 += (double)InpIma1[ RStart + row ][ COn ] *
               (double)InpIma1[ RStart + row ][ COn ];

/* ==========================================================================
   Second image variance
   ========================================================================== */
            *var2 -= (double)InpIma2[ RStart + row ][ COff ] *
               (double)InpIma2[ RStart + row ][ COff ];
            *var2 += (double)InpIma2[ RStart + row ][ COn ] *
               (double)InpIma2[ RStart + row ][ COn ];
         }
      break;
      case LDEFIE_dt_2_float:

/* ==========================================================================
   Complex images. See comments above ...
   ========================================================================== */
         for ( row=0; row<Kr; row++ ) {
            cov[ 0 ] -=
               (double)InpIma1[ RStart + row ][ ( COff ) * 2 ] *
               (double)InpIma2[ RStart + row ][ ( COff ) * 2 ] +
               (double)InpIma1[ RStart + row ][ ( COff ) * 2 + 1 ] *
               (double)InpIma2[ RStart + row ][ ( COff ) * 2 + 1 ];
            cov[ 1 ] -=
               (double)InpIma1[ RStart + row ][ ( COff ) * 2 + 1 ] *
               (double)InpIma2[ RStart + row ][ ( COff ) * 2 ] -
               (double)InpIma1[ RStart + row ][ ( COff ) * 2 ] *
               (double)InpIma2[ RStart + row ][ ( COff ) * 2 + 1 ];
            cov[ 0 ] +=
               (double)InpIma1[ RStart + row ][ ( COn ) * 2 ] *
               (double)InpIma2[ RStart + row ][ ( COn ) * 2 ] +
               (double)InpIma1[ RStart + row ][ ( COn ) * 2 + 1 ] *
               (double)InpIma2[ RStart + row ][ ( COn ) * 2 + 1 ];
            cov[ 1 ] +=
               (double)InpIma1[ RStart + row ][ ( COn ) * 2 + 1 ] *
               (double)InpIma2[ RStart + row ][ ( COn ) * 2 ] -
               (double)InpIma1[ RStart + row ][ ( COn ) * 2 ] *
               (double)InpIma2[ RStart + row ][ ( COn ) * 2 + 1 ];
            *var1 -=
               (double)InpIma1[ RStart + row ][ ( COff ) * 2 ] *
               (double)InpIma1[ RStart + row ][ ( COff ) * 2 ] +
               (double)InpIma1[ RStart + row ][ ( COff ) * 2 + 1 ] *
               (double)InpIma1[ RStart + row ][ ( COff ) * 2 + 1 ];
            *var1 +=
               (double)InpIma1[ RStart + row ][ ( COn ) * 2 ] *
               (double)InpIma1[ RStart + row ][ ( COn ) * 2 ] +
               (double)InpIma1[ RStart + row ][ ( COn ) * 2 + 1 ] *
               (double)InpIma1[ RStart + row ][ ( COn ) * 2 + 1 ];
            *var2 -=
               (double)InpIma2[ RStart + row ][ ( COff ) * 2 ] *
               (double)InpIma2[ RStart + row ][ ( COff ) * 2 ] +
               (double)InpIma2[ RStart + row ][ ( COff ) * 2 + 1 ] *
               (double)InpIma2[ RStart + row ][ ( COff ) * 2 + 1 ];
            *var2 +=
               (double)InpIma2[ RStart + row ][ ( COn ) * 2 ] *
               (double)InpIma2[ RStart + row ][ ( COn ) * 2 ] +
               (double)InpIma2[ RStart + row ][ ( COn ) * 2 + 1 ] *
               (double)InpIma2[ RStart + row ][ ( COn ) * 2 + 1 ];
         }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                            "for the coherence evaluation" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_COHE_MoveCol */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_COHE_MoveRow

        $TYPE         PROCEDURE

        $INPUT        DataType : image data type
                      Kc       : window size in the column direction
                      ROn      : row to add
                      ROff     : row to exclude
                      CStart   : starting col
                      InpIma1  : first image to multiply
                      InpIma2  : second image to multiply

        $MODIFIED     cov      : current covariance value to modify
                      var1     : current variance value of the first image
                                 to modify
                      var2     : current variance value of the second image
                                 to modify

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure updates the current value of the
                      covariance of two images windows and their variances
                      taking off the vaue at the given row and taking on the
                      other indicated

        $WARNING      NONE

        $PDL          - Switches over the data types
                            - Subtracts the old column from the covariance
                            - Sums the new one
                            - Subtracts the old column from the first image
                              variance
                            - Sums the new one
                            - Subtracts the old column from the second image
                              variance
                            - Sums the new one
                      - End Switch

   $EH
   ========================================================================== */

void IREGPP_COHE_MoveRow
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ UINTx4               ROn,
                         /*IN    */ UINTx4               ROff,
                         /*IN    */ UINTx4               CStart,
                         /*IN    */ float              **InpIma1,
                         /*IN    */ float              **InpIma2,
                         /*IN OUT*/ double               *cov,
                         /*IN OUT*/ double               *var1,
                         /*IN OUT*/ double               *var2,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_COHE_MoveRow";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Switches over the data type
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_float:

/* ==========================================================================
   Updates the real images covariance
   ========================================================================== */
         for ( col=0; col<Kc; col++ ) {
            cov[ 0 ] -= (double)InpIma1[ ROff ][ CStart + col ] *
               (double)InpIma2[ ROff ][ CStart + col ];
            cov[ 0 ] += (double)InpIma1[ ROn ][ CStart + col ] *
               (double)InpIma2[ ROn ][ CStart + col ];

/* ==========================================================================
   First image variance
   ========================================================================== */
            *var1 -= (double)InpIma1[ ROff ][ CStart + col ] *
               (double)InpIma1[ ROff ][ CStart + col ];
            *var1 += (double)InpIma1[ ROn ][ CStart + col ] *
               (double)InpIma1[ ROn ][ CStart + col ];

/* ==========================================================================
   Second image variance
   ========================================================================== */
            *var2 -= (double)(double)InpIma2[ ROff ][ CStart + col ] *
               (double)InpIma2[ ROff ][ CStart + col ];
            *var2 += (double)InpIma2[ ROn ][ CStart + col ] *
               (double)InpIma2[ ROn ][ CStart + col ];
         }
      break;
      case LDEFIE_dt_2_float:

/* ==========================================================================
   Complex images. See comments above ...
   ========================================================================== */
         for ( col=0; col<Kc; col++ ) {
            cov[ 0 ] -=
               (double)InpIma1[ ROff ][ ( CStart + col ) * 2 ] *
               (double)InpIma2[ ROff ][ ( CStart + col ) * 2 ] +
               (double)InpIma1[ ROff ][ ( CStart + col ) * 2 + 1 ] *
               (double)InpIma2[ ROff ][ ( CStart + col ) * 2 + 1 ];
            cov[ 1 ] -=
               (double)InpIma1[ ROff ][ ( CStart + col ) * 2 + 1 ] *
               (double)InpIma2[ ROff ][ ( CStart + col ) * 2 ] -
               (double)InpIma1[ ROff ][ ( CStart + col ) * 2 ] *
               (double)InpIma2[ ROff ][ ( CStart + col ) * 2 + 1 ];
            cov[ 0 ] +=
               (double)InpIma1[ ROn ][ ( CStart + col ) * 2 ] *
               (double)InpIma2[ ROn ][ ( CStart + col ) * 2 ] +
               (double)InpIma1[ ROn ][ ( CStart + col ) * 2 + 1 ] *
               (double)InpIma2[ ROn ][ ( CStart + col ) * 2 + 1 ];
            cov[ 1 ] +=
               (double)InpIma1[ ROn ][ ( CStart + col ) * 2 + 1 ] *
               (double)InpIma2[ ROn ][ ( CStart + col ) * 2 ] -
               (double)InpIma1[ ROn ][ ( CStart + col ) * 2 ] *
               (double)InpIma2[ ROn ][ ( CStart + col ) * 2 + 1 ];
            *var1 -=
               (double)InpIma1[ ROff ][ ( CStart + col ) * 2 ] *
               (double)InpIma1[ ROff ][ ( CStart + col ) * 2 ] +
               (double)InpIma1[ ROff ][ ( CStart + col ) * 2 + 1 ] *
               (double)InpIma1[ ROff ][ ( CStart + col ) * 2 + 1 ];
            *var1 +=
               (double)InpIma1[ ROn ][ ( CStart + col ) * 2 ] *
               (double)InpIma1[ ROn ][ ( CStart + col ) * 2 ] +
               (double)InpIma1[ ROn ][ ( CStart + col ) * 2 + 1 ] *
               (double)InpIma1[ ROn ][ ( CStart + col ) * 2 + 1 ];
            *var2 -=
               (double)InpIma2[ ROff ][ ( CStart + col ) * 2 ] *
               (double)InpIma2[ ROff ][ ( CStart + col ) * 2 ] +
               (double)InpIma2[ ROff ][ ( CStart + col ) * 2 + 1 ] *
               (double)InpIma2[ ROff ][ ( CStart + col ) * 2 + 1 ];
            *var2 +=
               (double)InpIma2[ ROn ][ ( CStart + col ) * 2 ] *
               (double)InpIma2[ ROn ][ ( CStart + col ) * 2 ] +
               (double)InpIma2[ ROn ][ ( CStart + col ) * 2 + 1 ] *
               (double)InpIma2[ ROn ][ ( CStart + col ) * 2 + 1 ];
         }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                            "for the coherence evaluation" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_COHE_MoveRow */

#ifdef __EXAM__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGIP_COHE_

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void IREGIP_COHE_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGIP_COHE_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGIP_COHE_ */
#endif
