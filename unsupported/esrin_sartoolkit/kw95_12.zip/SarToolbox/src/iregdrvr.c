/* ==========================================================================
   $MODULE_HEADER

      $NAME              IREG_DRVR

      $FUNCTION          This module contains the procedure to drive the
                         image co-registration

      $ROUTINE           IREGIP_DRVR_Registrator

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       07-MAR-98     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include FILS_INTF_H
#include IANN_INTF_H
#include IREG_INTF_H
#include IREG_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGIP_DRVR_Registrator

        $TYPE         PROCEDURE

        $INPUT        inp_io               : array with the input files
                                             descriptors
                      out_fnames           : array with the output files
                                             names
                      NImages              : number of images
                      NGCPRow              : number of GCP in the rows direction
                      NGCPCol              : number of GCP in the columns
                                             direction
                      GCPFileName          : name of the ASCII file with the
                                             master GCPs written ( optional )
                                             for GCP overriding
                      ResidFileName        : name of the file that will contain
                                             the GCPs residual
                      row_coarse_cell_size : cell size in the rows direction for
                                             the coarse registration
                      col_coarse_cell_size : cell size in the columns direction
                                             for the coarse registration
                      int_fact_row         : interpolation factor in the rows
                                             direction for the coarse
                                             registration
                      int_fact_col         : interpolation factor in the columns
                                             direction for the coarse
                                             registration
                      row_fine_cell_size   : cell size in the rows direction for
                                             the fine registration
                      col_fine_cell_size   : cell size in the columns direction
                                             for the fine registration
                      coher_wsiz           : window size for the coherence
                                             evaluation in the fine registration
                      coher_ftol           : tolerance for the function value
                                             in the iteratively evaluation of
                                             the coherence
                      coher_vtol           : tolerance for the coordinates
                                             values in the iteratively
                                             evaluation of the coherence
                      degree               : flag indicating the degree of the
                                             warp matrices
                      OverMode             : flag indicating the overlapping
                                             mode to determinate the output
                                             layover
                      IntRowWinSize        : interpolation window size in the
                                             rows direction
                      IntColWinSize        : interpolation window size in the
                                             columns direction
                      InterpMode           : flag indicating the interpolation
                                             mode
                      BaselineFileName     : name of the file that will contain
                                             the baseline evaluated info
                      SincWidth            : sinc elements
                      InterpPrec           : interpolation table length
                      CubConvCoeff         : coefficient of the cubic
                                             convolution function
                      CoarseMaxTol         : tolerance value for the coarse
                                             registration stability test
                      maxPointRMS          : maximum residual value for GCPs
                                             editing

        $MODIFIED     TLRow                : top left row coordinate of the
                                             input AoI
                      TLCol                : top left column coordinate of
                                             the input AoI
                      BRRow                : bottom right row coordinate of
                                             the input AoI
                      BRCol                : bottom right column coordinate
                                             of the input AoI

        $OUTPUT       out_io               : array with the output files
                                             descriptors

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This is the driver procedure for the image co-registrator

        $WARNING      THE OUTPUT IMAGES ARE OPENED IN THIS PROCEDURE BUT MUST
                      BE CLOSED OUT OF IT TO ALLOW THE TAG UPDATING AND WRITING

        $PDL          - Initializes the GCPs evaluation procedures
                      - Evaluates the GCPs on the images
                      - Initializes the warp matrices
                      - Evaluates the warp matrices
                      - If the overlapping mode have been set
                            - Evaluates the output layover WRT the overlapping
                              mode selected
                      - Else
                            - Copies the input corners into the output ones
                      - End If
                      - Interpolates the input images into the output layout
                        and writes them in the output files
                      - Opens the baselines file
                      - Evaluates the baselines
                      - Closes the baselines file
                      - Closes the warp related structures
                      - Closes all the GCPs structures INFO

   $EH
   ========================================================================== */

void IREGIP_DRVR_Registrator
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ FILSIT_file_name    *out_fnames,
                         /*IN    */ INTx4                NImages,
                         /*IN    */ INTx4                NGCPRow,
                         /*IN    */ INTx4                NGCPCol,
                         /*IN    */ char                *GCPFileName,
                         /*IN    */ char                *ResidFileName,
                         /*IN    */ INTx4                row_coarse_cell_size,
                         /*IN    */ INTx4                col_coarse_cell_size,
                         /*IN    */ float                int_fact_row,
                         /*IN    */ float                int_fact_col,
                         /*IN    */ INTx4                row_fine_cell_size,
                         /*IN    */ INTx4                col_fine_cell_size,
                         /*IN    */ INTx2                coher_wsiz,
                         /*IN    */ double               coher_ftol,
                         /*IN    */ double               coher_vtol,
                         /*IN    */ UINTx1               degree,
                         /*IN    */ UINTx1               OverMode,
                         /*IN    */ INTx4                IntRowWinSize,
                         /*IN    */ INTx4                IntColWinSize,
                         /*IN    */ UINTx1               InterpMode,
                         /*IN    */ FILSIT_file_name     BaselineFileName,
                         /*IN    */ INTx4                SincWidth,
                         /*IN    */ INTx4                InterpPrec,
                         /*IN    */ float                CubConvCoeff,
                         /*IN    */ float                CoarseMaxTol,
                         /*IN    */ float                maxPointRMS,
                         /*IN OUT*/ INTx4               *TLRow,
                         /*IN OUT*/ INTx4               *TLCol,
                         /*IN OUT*/ INTx4               *BRRow,
                         /*IN OUT*/ INTx4               *BRCol,
                         /*   OUT*/ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGIP_DRVR_Registrator";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 mas_imanum = 0;
   UINTx1                *sla_imanum = (UINTx1 *)NULL;
   INTx4                  OutTLRow;
   INTx4                  OutTLCol;
   INTx4                  OutBRRow;
   INTx4                  OutBRCol;
   INTx4                  NOutRow;
   INTx4                  NOutCol;
   INTx4                  ima;
   IREGPT_warp_deg        WarpDeg;
   IREGPT_over_mode       OMode;
   IREGPT_inter_mode      IMode;
   UINTx2                 npar;
   FILE                  *bas_fp = (FILE *)NULL;
   FILE                  *res_fp = (FILE *)NULL;

/* ==========================================================================
   Default initialization
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Allocate the necessary memory
   ========================================================================== */
   if ( ( sla_imanum = (UINTx1 *)MEMSIP_alloc ( (size_t)(NImages *
                                                sizeof (UINTx1)) ) ) ==
        (UINTx1 *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the slave image IDs array" );
   }

/* ==========================================================================
   Check the interpolation window dimensions
   ========================================================================== */
   if ( ( IntRowWinSize <= 0 ) || ( IntColWinSize <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_neg_val,
                         "of the interpolation window sizes" );
   }

/* ==========================================================================
   Set the global variables for the windows dimensions
   ========================================================================== */
   IREGPV_int_win_row_size = IntRowWinSize;
   IREGPV_int_win_col_size = IntColWinSize;

/* ==========================================================================
   Set the warp degree
   ========================================================================== */
   switch ( degree ) {
      case 1:
         WarpDeg = IREGPE_wd_one;
      break;
      case 2:
         WarpDeg = IREGPE_wd_one_half;
      break;
      case 3:
         WarpDeg = IREGPE_wd_two;
      break;
      case 4:
         WarpDeg = IREGPE_wd_three;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_warp_deg_not_allow, "" );
   }

/* ==========================================================================
   Set the overlapping mode
   ========================================================================== */
   switch ( OverMode ) {
      case 0:
         OMode = IREGPE_om_undef;
      break;
      case 1:
         OMode = IREGPE_om_min;
      break;
      case 2:
         OMode = IREGPE_om_max;
      break;
      case 3:
         OMode = IREGPE_om_master;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_over_mode_not_allow, "" );
   }

/* ==========================================================================
   Set the interpolation mode
   ========================================================================== */
   switch ( InterpMode ) {
      case 1:
         IMode = IREGPE_im_nn;
      break;
      case 2:
         IMode = IREGPE_im_bil;
      break;
      case 3:
         IMode = IREGPE_im_cc;
      break;
      case 4:
         IMode = IREGPE_im_fftshift;
      break;
      case 5:
         IMode = IREGPE_im_sinc;
      break;
      case 6:
         IMode = IREGPE_im_ccfftshift;
      break;
      case 7:
         IMode = IREGPE_im_sincfftshift;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_inter_not_def, "" );
   }

/* ==========================================================================
   Set the mathematical interpolation variables
   ========================================================================== */
   MATHIV_sinc_elem = SincWidth;
   MATHIV_CCTableLength = InterpPrec;
   MATHIV_SincTableLength = InterpPrec;
   MATHIV_cubi_conv_coeff = CubConvCoeff;

/* ==========================================================================
   Check them
   ========================================================================== */
   if ( MATHIV_sinc_elem < 2 ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_few_sinc_elem, "" );
   }
   if ( MATHIV_CCTableLength < 1 ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_table_length, "" );
   }


/* ==========================================================================
   Set the value of the coarse shift tolerance
   ========================================================================== */
   IREGPV_max_coarse_shift = CoarseMaxTol;

/* ==========================================================================
   Check it
   ========================================================================== */
   if ( IREGPV_max_coarse_shift <= 0. ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_neg_val,
                         "for the stability test tolerance" );
   }

/* ==========================================================================
   Set the value of the maximum RMS point value for GCPs editing
   ========================================================================== */
   IREGPV_max_point_RMS = maxPointRMS;

/* ==========================================================================
   Check it
   ========================================================================== */
   if ( IREGPV_max_point_RMS <= 0. ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_neg_val,
                         "for the point RMS editing tolerance" );
   }

/* ==========================================================================
   Log printing
   ========================================================================== */
   fprintf ( stdout, "\n\nDoing the GCP registration\n" );

/* ==========================================================================
   Initialize the GCPs creation
   ========================================================================== */
   IREGPP_GCPE_Init ( NGCPRow, NGCPCol,
                      row_coarse_cell_size, col_coarse_cell_size,
                      int_fact_row, int_fact_col,
                      row_fine_cell_size, col_fine_cell_size,
                      coher_wsiz, coher_ftol, coher_vtol, NImages, GCPFileName,
                      status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Register the GCPs
   ========================================================================== */
   IREGPP_GCPE_GCPRegistrator ( *TLRow, *TLCol, *BRRow, *BRCol, inp_io,
                                GCPFileName, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Log printing
   ========================================================================== */
   fprintf ( stdout, "\n\nDoing the Warp evaluation\n" );

/* ==========================================================================
   Initialize the Warp evaluation
   ========================================================================== */
   IREGPP_WAEV_InitWarp ( WarpDeg, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Warp matrices evaluation
   ========================================================================== */
   IREGPP_WAEV_Warp ( NImages, WarpDeg, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Open the residual output file
   ========================================================================== */
   if ( ResidFileName != (char *)NULL ) {
      FILSIP_open ( ResidFileName, "w", 0, &res_fp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the residuals
   ========================================================================== */
      IREGPP_WAEV_WriteResid ( NImages, WarpDeg, res_fp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Close the residual file
   ========================================================================== */
      FILSIP_close ( &res_fp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Check the warp goodness
   ========================================================================== */
   for ( ima=1; ima<NImages; ima++ ) {
      IREGPP_WAEV_WarpCheck ( (UINTx1)ima, (IREGPT_warp_deg) degree, 
         status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Log printing
   ========================================================================== */
   fprintf ( stdout, "\n\nDoing the images interpolation and re-writing\n" );

/* ==========================================================================
   Check the AoI
   ========================================================================== */
   if ( OMode != IREGPE_om_undef ) {

/* ==========================================================================
   Evaluate the output layover
   ========================================================================== */
      IREGPP_LAYO_CornersEval ( OMode, &OutTLRow, &OutTLCol, &OutBRRow,
                                &OutBRCol, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }
   else {

/* ==========================================================================
   Copy the output area from input
   ========================================================================== */
      OutTLRow = *TLRow;
      OutTLCol = *TLCol;
      OutBRRow = *BRRow;
      OutBRCol = *BRCol;
   }

/* ==========================================================================
   Evaluate the number of rows and columns
   ========================================================================== */
   NOutRow = OutBRRow - OutTLRow + 1;
   NOutCol = OutBRCol - OutTLCol + 1;

/* ==========================================================================
   Fill the slave images IDs array
   ========================================================================== */
   for ( ima=0; ima<NImages-1; ima++ ) {
      sla_imanum[ ima ] = (UINTx1)(ima + 1);
   }

/* ==========================================================================
   Check if the baseline can be evaluated
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ mas_imanum ].MapProjectionType !=
          IANNIE_proj_UTM ) &&
        ( IANNIV_ImageAnnot[ mas_imanum ].MapProjectionType !=
          IANNIE_proj_UPS ) ) {

/* ==========================================================================
   Open the baseline file name
   ========================================================================== */
      FILSIP_open ( BaselineFileName, "w", 0, &bas_fp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the baseline
   ========================================================================== */
      IREGPP_BSLN_BaselineEval ( mas_imanum, sla_imanum, OutTLRow, OutTLCol,
                                 NOutRow, NOutCol, NImages, 
                                 (IREGPT_warp_deg) degree, bas_fp,
                                 status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Close the baseline file
   ========================================================================== */
      FILSIP_close ( &bas_fp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Set the number of parameters
   ========================================================================== */
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Opens the output files
   ========================================================================== */
   for ( ima=0; ima<NImages; ima++ ) {

/* ==========================================================================
   Fill the basic parameter structure of the output files
   ========================================================================== */
      TIFSIM_bpar_init ( out_io[ ima ].val.tif.bpar );
      out_io[ ima ].val.tif.bpar.imagelength = NOutRow;
      out_io[ ima ].val.tif.bpar.imagewidth = NOutCol;
      out_io[ ima ].val.tif.bpar.sampleperpixel =
         inp_io[ mas_imanum ].val.tif.bpar.sampleperpixel;
      out_io[ ima ].val.tif.bpar.bitspersample[ 0 ] = 32;
      out_io[ ima ].val.tif.bpar.sampleformat[ 0 ] = TIFSID_float;
      out_io[ ima ].val.tif.bpar.disposition = 'x';

/* ==========================================================================
   Open the  output files
   ========================================================================== */
      out_io[ ima ].type = GIOSIE_tif;
      out_io[ ima ].mode = 'w';
      strcpy ( out_io[ ima ].val.tif.name, out_fnames[ ima ] );
      out_io[ ima ].val.tif.nimg = 1;
      out_io[ ima ].val.tif.npar = npar;
      out_io[ ima ].img = 0;
      GIOSIP_open_io ( &out_io[ ima ], status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Interpolate and re-write the output images
   ========================================================================== */
   IREGPP_WRIM_InterpolateImages ( inp_io, NImages, OutTLRow, OutTLCol,
                                   OutBRRow, OutBRCol,
                                   IntRowWinSize, IntColWinSize,
                                   IMode, out_io, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Update the corners
   ========================================================================== */
   *TLRow = OutTLRow;
   *TLCol = OutTLCol;
   *BRRow = OutBRRow;
   *BRCol = OutBRCol;

error_exit:;

/* ==========================================================================
   Close the Warp stuff
   ========================================================================== */
   IREGPP_WAEV_CloseWarp ( &log_status_code );
   ERRSIM_on_err_goto_exit ( log_status_code );

/* ==========================================================================
   Close the GCPs stuff
   ========================================================================== */
   IREGPP_GCPE_Close ( &log_status_code );
   ERRSIM_on_err_goto_exit ( log_status_code );

/* ==========================================================================
   Free the allocated memory
   ========================================================================== */
   MEMSIP_free ( (void **)&sla_imanum );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGIP_DRVR_Registrator */
