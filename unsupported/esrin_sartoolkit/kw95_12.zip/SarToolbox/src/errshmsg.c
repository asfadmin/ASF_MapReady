/* ==========================================================================
   $MODULE_HEADER

      $NAME              ERRS_HMSG

      $FUNCTION          

      $ROUTINE           ERRS_HMSG

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       29-SEP-95     DD       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdlib.h>
#include <string.h>

#include "libname.h"
#include ERRS_INTF_H
#include ERRS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

static void trace_in( ERRSIT_flag   process_flag )
{                                                        
   ERRSIT_status log_status_code;                   
 
   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);
   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);


}                                                        

static void trace_out( ERRSIT_flag   process_flag )
{                                                        
   ERRSIT_status log_status_code;                   

   ERRSIP_HPEL_trace_proc_err_log(" ",&log_status_code);
   ERRSIP_HPEL_trace_proc_err_log("OUTPUT PARAMETER:", &log_status_code);

}                           

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ERRSIP_HMSG_error_message

        $TYPE         PROCEDURE

        $INPUT        routine_name   : current routine
                      status_code    : current status_code
                      message        : custom message: can be NULL
                      error_line     : module line number.
                      process_flag   : process flag

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Write Log Messages

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void ERRSIP_HMSG_error_message
                        (/*IN    */ const ERRSIT_proc_name routine_name,
                         /*IN    */ ERRSIT_status          status_code,
                         /*IN    */ char                  *message,
                         /*IN    */ INTx4                  error_line,
                         /*IN    */ ERRSIT_flag            process_flag )
{
   ERRSIT_status          log_status_code;
   ERRSIT_status          package_code;
   ERRSIT_status          error_code;
   char                  *str;
   char                   alloc_str = 'N';
   char                   msg[ 132 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   log_status_code = ERRSID_normal;

   
   package_code = (status_code & 0xFFFF0000) >> 16;
   error_code   = status_code & 0x0000FFFF;
  
   if ( message != (char *) NULL) 
   {
      str = malloc( strlen( ERRSIV_HERR_vector_message[package_code][error_code]
			  ) + 2 + strlen( message ) + 1 + 22 );
      if( str == (char *) NULL ) {
	 str = ERRSIV_HERR_vector_message[package_code][error_code];
      }
      else {
         alloc_str = 'Y';
	 sprintf( str, "line %d. ", error_line );
	 strcat( str, ERRSIV_HERR_vector_message[package_code][error_code] );
	 if( strcmp( message, "") ) {
	    strcat( str, ": " );
	    strcat( str, message );
	    strcat( str, "." );
	 }
      }
   }
   else {
      str = ERRSIV_HERR_vector_message[package_code][error_code];
   }

   ERRSIP_WPEL_write(  routine_name,
                       str,
                      &log_status_code );

#ifdef __TRACE__
      printf("\nPackage %0d\nError %0d\nAlloc_str=%c\n", 
         package_code, error_code, alloc_str );
      printf("\nERRSIV_dump_error %0d\nprocess_flag=%d\nflag=%d\n",
         ERRSIV_dump_error, process_flag, ERRSIM_message_on_monitor( process_flag ) );
#endif
   if( (ERRSIV_dump_error == 1) && 
       ERRSIM_message_on_monitor( process_flag ) )
   {
#ifdef __VMS__
      fprintf( stdout, "\n%s %s\n", routine_name,  str);
#else
      if( alloc_str == 'Y' ) {
         sprintf( str, "%s. ", ERRSIV_routine_stack[ 0 ] );
         strcat( str, ERRSIV_HERR_vector_message[package_code][error_code] );
         if( strcmp( message, "") ) {
            strcat( str, ": " );
            strcat( str, message );
            strcat( str, "." );
         }
      }
      fprintf( stdout, "\n%s\n", str);
#endif
   }

error_exit:;

   if( alloc_str == 'Y' ) {
      free((void *) str);
   }

}/* ERRSIP_HMSG_error_message */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ERRSIF_HMSG_register_error_msgs

        $TYPE         function

        $INPUT        message_array      : Package error messages array.

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
INTx4 ERRSIF_HMSG_register_error_msgs
                        ( /*IN    */ char         **message_array )
{
   char                  *str;
   INTx4                  pckg_code;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   if( ERRSIV_HERR_vector_message == NULL) {
      str = malloc( sizeof( ERRSIV_HERR_vector_message ) );
   }
   else {
      str = realloc( ERRSIV_HERR_vector_message, 
                     ( ERRSIV_vector_message_entry_no + 1 ) *
					  sizeof( ERRSIV_HERR_vector_message ));
   }

   if( str == NULL ) {
      pckg_code = 0;
   }
   else {
      ERRSIV_HERR_vector_message = (char***)str;

      ERRSIV_HERR_vector_message[ERRSIV_vector_message_entry_no] =message_array;

      pckg_code = ERRSIV_vector_message_entry_no << 16;
      ERRSIV_vector_message_entry_no++;
   }


   return pckg_code;


error_exit:;

   return 0;

}/* ERRSIF_HMSG_register_error_msgs */

