/* ==========================================================================
   $MODULE_HEADER

      $NAME              ERRS_IDLI

      $FUNCTION          ERRSIP_IDLI_error_message

      $ROUTINE           ERRS_IDLI

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       07-FEB-98     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */


#include "libname.h"

#include ERRS_INTF_H
#include ERRS_PGLB_H
#if defined(__HAVEIDL__)
#include IDLI_INTF_H
#endif

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ERRSIP_IDLI_error_message

        $TYPE         PROCEDURE

        $INPUT        routine_name   : current routine
                      status_code    : current status_code
                      message        : custom message: can be NULL
                      error_line     : module line number.
                      process_flag   : process flag

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Write Log Messages on IDL interface

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void ERRSIP_IDLI_error_message
                        (/*IN    */ const ERRSIT_proc_name routine_name,
                         /*IN    */ ERRSIT_status          status_code,
                         /*IN    */ char                  *message,
                         /*IN    */ INTx4                  error_line,
                         /*IN    */ ERRSIT_flag            process_flag )
{
   ERRSIT_status          log_status_code;
   ERRSIT_status          package_code;
   ERRSIT_status          error_code;
   char                  *str;
   char                   alloc_str = 'N';
   char                   msg[ 132 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   log_status_code = ERRSID_normal;

   
   package_code = (status_code & 0xFFFF0000) >> 16;
   error_code   = status_code & 0x0000FFFF;
  
   if ( message != (char *) NULL) 
   {
      str = malloc( strlen( ERRSIV_HERR_vector_message[package_code][error_code]
			  ) + 2 + strlen( message ) + 1 + 22 );
      if( str == (char *) NULL ) {
	 str = ERRSIV_HERR_vector_message[package_code][error_code];
      }
      else {
         alloc_str = 'Y';
	 sprintf( str, "line %d. ", error_line );
	 strcat( str, ERRSIV_HERR_vector_message[package_code][error_code] );
	 if( strcmp( message, "") ) {
	    strcat( str, ": " );
	    strcat( str, message );
	    strcat( str, "." );
	 }
      }
   }
   else {
      str = ERRSIV_HERR_vector_message[package_code][error_code];
   }

   ERRSIP_WPEL_write(  routine_name,
                       str,
                      &log_status_code );

   if( (ERRSIV_dump_error == 1) && 
       ERRSIM_message_on_monitor( process_flag ) )
   {
#ifdef __TRACE__
      printf("\nPackage %0d\nError %0d", package_code, error_code );
#endif

#ifdef __VMS__
      sprintf( msg, "%s %s", routine_name,  str);
#else
      sprintf( msg, "%s. ", ERRSIV_routine_stack[ 0 ] );
      strcat( msg, ERRSIV_HERR_vector_message[package_code][error_code] );
      if( strcmp( message, "") ) {
         strcat( msg, ": " );
         strcat( msg, message );
         strcat( msg, "." );
      }
#endif
#if defined(__HAVEIDL__)
      IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, " " );
      IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, msg );
      IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, " " );
#endif

   }

error_exit:;

   if( alloc_str == 'Y' ) {
      free((void *) str);
   }

}/* ERRSIP_IDLI_error_message */
