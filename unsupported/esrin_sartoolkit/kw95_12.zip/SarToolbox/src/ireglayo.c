/* ==========================================================================
   $MODULE_HEADER

      $NAME              IREG_LAYO

      $FUNCTION          This module contains the procedures to evaluate the
                         output layover of the co-registered images

      $ROUTINE           IREGPP_LAYO_MaxOverlap
                         IREGPP_LAYO_MasterOverlap
                         IREGPP_LAYO_MinOverlap
                         IREGPP_LAYO_FillBorderArray
                         IREGPP_LAYO_Slave2MasterContour
                         IREGPP_LAYO_MaxSlaveCorners
                         IREGPP_LAYO_MinSlaveCorners
                         IREGPP_LAYO_CornersEval

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       17-FEB-98     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <math.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include COOR_INTF_H
#include IREG_INTF_H
#include IREG_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_MaxOverlap

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       TLRow : row coordinate of the top left output corner
                      TLCol : column coordinate of the top left output corner
                      BRRow : row coordinate of the bottom right output corner
                      BRCol : column coordinate of the bottom left output
                              corner

        $GLOBAL       IREGIV_ima_num   : number of images to co-register

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the top left and bottom right
                      corners coordinates of the largest square containing all
                      the images to co-register evaluated in the master
                      reference system of coordinates

        $WARNING      NONE

        $PDL          - Allocates some useful variables
                      - Fills the array with the corners of each images with the
                        master image corners
                      - Loop over the slaves
                            - Evaluates the number of points covering the
                              image border
                            - Re-allocates the borders array
                            - Fills the borders array
                            - Transforms the borders points from the slave to
                              the master coordinates system
                            - Search the minima and the maxima values of
                              coordinates
                      - End Loop
                      - Search the minima and the maxima values of coordinates
                        among all the images corners
                      - Fills the output variables

   $EH
   ========================================================================== */

void IREGPP_LAYO_MaxOverlap
                        (/*   OUT*/ INTx4               *TLRow,
                         /*   OUT*/ INTx4               *TLCol,
                         /*   OUT*/ INTx4               *BRRow,
                         /*   OUT*/ INTx4               *BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_LAYO_MaxOverlap";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 mas_imanum = 0;
   INTx2                  ima;
   INTx2                  ncorn = 4;
   MATHIT_RC            **vert = (MATHIT_RC **)NULL;
   MATHIT_RC             *bord = (MATHIT_RC *)NULL;
   INTx4                  NPoints;
   INTx4                  poi;
   INTx4                  i;
   MATHIT_RC              corn[ 4 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Allocate the array with the corners
   ========================================================================== */
   if ( ( vert = (MATHIT_RC **)MEMSIP_alloc ( (size_t)(IREGIV_ima_num *
                                              sizeof (MATHIT_RC *)) ) ) ==
        (MATHIT_RC **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the corners array" );
   }
   for ( ima=0; ima<IREGIV_ima_num; ima++ ) {
      if ( ( vert[ ima ] = (MATHIT_RC *)MEMSIP_alloc ( (size_t)(ncorn *
                                                       sizeof (MATHIT_RC)) ) )==
           (MATHIT_RC *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "for the corners array" );
      }
   }

/* ==========================================================================
   Fill the corners for the master image
   ========================================================================== */

   /* top left corner */
   vert[ mas_imanum ][ 0 ].row = (double)0;
   vert[ mas_imanum ][ 0 ].col = (double)0;

   /* top right corner */
   vert[ mas_imanum ][ 1 ].row = (double)0;
   vert[ mas_imanum ][ 1 ].col = (double)
      (IANNIV_ImageAnnot[ mas_imanum ].ImageWidth - 1);

   /* bottom right corner */
   vert[ mas_imanum ][ 2 ].row = (double)
      (IANNIV_ImageAnnot[ mas_imanum ].ImageLength - 1);
   vert[ mas_imanum ][ 2 ].col = (double)
      (IANNIV_ImageAnnot[ mas_imanum ].ImageWidth - 1);

   /* bottom left corner */
   vert[ mas_imanum ][ 3 ].row = (double)
      (IANNIV_ImageAnnot[ mas_imanum ].ImageLength - 1);
   vert[ mas_imanum ][ 3 ].col = (double)0;

/* ==========================================================================
   Loop over the slaves
   ========================================================================== */
   for ( ima=1; ima<IREGIV_ima_num; ima++ ) {

/* ==========================================================================
   Count the number of points to describe the slave border
   ========================================================================== */
      NPoints = 0;
      if ( IANNIV_ImageAnnot[ ima ].ImageLength <= IREGPD_sla_bord_step ) {
         NPoints = 2 * ( IANNIV_ImageAnnot[ ima ].ImageLength - 1 );
      }
      else {
         NPoints = 2 *
            ( (INTx4)( ( IANNIV_ImageAnnot[ ima ].ImageLength - 2 ) /
            IREGPD_sla_bord_step) + 1 );
      }
      if ( IANNIV_ImageAnnot[ ima ].ImageWidth <= IREGPD_sla_bord_step ) {
         NPoints += 2 * ( IANNIV_ImageAnnot[ ima ].ImageWidth - 1 );
      }
      else {
         NPoints += 2 *
            ( (INTx4)( ( IANNIV_ImageAnnot[ ima ].ImageWidth - 2 ) /
            IREGPD_sla_bord_step) + 1 );
      }

/* ==========================================================================
   Allocate the border array
   ========================================================================== */
      if ( ( bord = (MATHIT_RC *)MEMSIP_realloc ( (void *)bord, (size_t)
                                                  (NPoints *
                                                  sizeof (MATHIT_RC)) ) ) ==
           (MATHIT_RC *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "for the border array" );
      }

/* ==========================================================================
   Fill the border array
   ========================================================================== */
      IREGPP_LAYO_FillBorderArray ( NPoints,
                                    IANNIV_ImageAnnot[ ima ].ImageLength,
                                    IANNIV_ImageAnnot[ ima ].ImageWidth,
                                    IREGPD_sla_bord_step, bord, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Transform the slave coordinates in the master reference system
   ========================================================================== */
      for ( poi=0; poi<NPoints; poi++ ) {
         IREGPP_WAEV_Sla2Mas ( bord[ poi ], IREGPV_warp_deg, ima, &bord[ poi ],
                               status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }

/* ==========================================================================
   Search the minimum of the minima coordinates among the rows and the columns
   and the maximum among the maxima coordinates
   ========================================================================== */
      IREGPP_LAYO_MaxSlaveCorners ( NPoints, bord, vert[ ima ], status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Re-allocate the border array
   ========================================================================== */
   if ( ( bord = (MATHIT_RC *)MEMSIP_realloc ( (void *)bord, (size_t)
                                               (( IREGIV_ima_num * ncorn ) *
                                               sizeof (MATHIT_RC)) ) ) ==
        (MATHIT_RC *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the border array" );
   }

/* ==========================================================================
   Find the maximum overlap corners
   ========================================================================== */
   for ( ima=0, i=0; ima<IREGIV_ima_num; ima++ ) {
      for ( poi=0; poi<ncorn; poi++ ) {
         bord[ i++ ] = vert[ ima ][ poi ];
      }
   }

   /* evaluate the total corners */
   IREGPP_LAYO_MaxSlaveCorners ( i, bord, corn, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the output variables
   ========================================================================== */
   *TLRow = (INTx4)(floor ( corn[ 0 ].row ));
   *TLCol = (INTx4)(floor ( corn[ 0 ].col ));
   *BRRow = (INTx4)(ceil ( corn[ 2 ].row ));
   *BRCol = (INTx4)(ceil ( corn[ 2 ].col ));

error_exit:;

/* ==========================================================================
   Free the left memories
   ========================================================================== */
   MEMSIP_free ( (void **)&bord );

   if ( vert != (MATHIT_RC **)NULL ) {
      for ( ima=0; ima<IREGIV_ima_num; ima++ ) {
         MEMSIP_free ( (void **)&vert[ ima ] );
      }
      MEMSIP_free ( (void **)&vert );
   }

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_LAYO_MaxOverlap */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_MasterOverlap

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       TLRow : row coordinate of the top left output corner
                      TLCol : column coordinate of the top left output corner
                      BRRow : row coordinate of the bottom right output corner
                      BRCol : column coordinate of the bottom left output
                              corner

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the top left and bottom right
                      corners coordinates of the master image as the output
                      layout corners

        $WARNING      NONE

        $PDL          - Fills the output variables with the master corners

   $EH
   ========================================================================== */

void IREGPP_LAYO_MasterOverlap
                        (/*   OUT*/ INTx4               *TLRow,
                         /*   OUT*/ INTx4               *TLCol,
                         /*   OUT*/ INTx4               *BRRow,
                         /*   OUT*/ INTx4               *BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_LAYO_MasterOverlap";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 mas_imanum = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Copy the master borders into the output variables
   ========================================================================== */
   *TLRow = 0;
   *TLCol = 0;
   *BRRow = IANNIV_ImageAnnot[ mas_imanum ].ImageLength - 1;
   *BRCol = IANNIV_ImageAnnot[ mas_imanum ].ImageWidth - 1;

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_LAYO_MasterOverlap */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGIP_LAYO_

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void IREGPP_LAYO_MinOverlap
                        (/*IN OUT*/ INTx4               *TLRow,
                         /*IN OUT*/ INTx4               *TLCol,
                         /*IN OUT*/ INTx4               *BRRow,
                         /*IN OUT*/ INTx4               *BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_LAYO_MinOverlap";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   MATHIT_RC             *min_bord = (MATHIT_RC *)NULL;
   MATHIT_RC             *bord = (MATHIT_RC *)NULL;
   MATHIT_RC             *tmp = (MATHIT_RC *)NULL;
   MATHIT_RC              corn[ 4 ];
   INTx4                  in_out;
   INTx4                  NPoints[ IREGID_MaxImaNum ];
   INTx4                  TotNPoints = 0;
   INTx4                  bord_step = IREGPD_sla_bord_step;
   INTx4                  N;
   INTx4                  ima;
   INTx4                  poi;
   INTx4                  i;
   INTx4                  j;
   INTx4                  src_str;
   INTx4                  trg_str;
   INTx4                  counter;
   INTx4                  index[ IREGID_MaxImaNum ][ IREGID_MaxImaNum - 1 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Fill the index array
   ========================================================================== */
   for ( ima=0; ima<IREGIV_ima_num; ima++ ) {
      i = 0;
      src_str = ima + 1;
      while ( src_str < IREGIV_ima_num ) {
         index[ ima ][ i ] = src_str;
         i++;
         src_str++;
      }
      j = 0;
      while ( i < ( IREGIV_ima_num - 1 ) ) {
         index[ ima ][ i ] = j;
         i++;
         j++;
      }
   }

/* ==========================================================================
   Evaluate the number of bord points
   ========================================================================== */
   TotNPoints = IREGPD_Max_Vertex + 1;
   while ( TotNPoints > IREGPD_Max_Vertex ) {

/* ==========================================================================
   Evaluate the reduction factor of the step
   ========================================================================== */
      bord_step *= (float)IREGPD_Max_Vertex / TotNPoints;
      for ( ima=0, TotNPoints=0; ima<IREGIV_ima_num; ima++ ) {
         NPoints[ ima ] = 0;
         if ( IANNIV_ImageAnnot[ ima ].ImageLength <= bord_step ) {
            NPoints[ ima ] = 2 * ( IANNIV_ImageAnnot[ ima ].ImageLength - 1 );
         }
         else {
            NPoints[ ima ] = 2 *
               ( (INTx4)(( IANNIV_ImageAnnot[ ima ].ImageLength - 2 ) /
               bord_step) + 1 );
         }
         if ( IANNIV_ImageAnnot[ ima ].ImageWidth <= bord_step ) {
            NPoints[ ima ] += 2 *
               ( (INTx4)(( IANNIV_ImageAnnot[ ima ].ImageWidth - 2 ) /
               bord_step) + 1 );
         }
         else {
            NPoints[ ima ] += 2 *
               ( (INTx4)( ( IANNIV_ImageAnnot[ ima ].ImageWidth - 2 ) /
               bord_step) + 1 );
         }
         TotNPoints += NPoints[ ima ];
      }
   }

/* ==========================================================================
   Allocate the border arrays
   ========================================================================== */
   if ( ( min_bord = (MATHIT_RC *)MEMSIP_realloc ( (void *)min_bord, (size_t)
                                               (TotNPoints *
                                               sizeof (MATHIT_RC)) ) ) ==
        (MATHIT_RC *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the border array" );
   }
   if ( ( bord = (MATHIT_RC *)MEMSIP_realloc ( (void *)bord, (size_t)
                                               (TotNPoints *
                                               sizeof (MATHIT_RC)) ) ) ==
        (MATHIT_RC *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the border array" );
   }

/* ==========================================================================
   Fill the border array with the master points ...
   ========================================================================== */
   IREGPP_LAYO_FillBorderArray ( NPoints[ 0 ],
                                 IANNIV_ImageAnnot[ 0 ].ImageLength,
                                 IANNIV_ImageAnnot[ 0 ].ImageWidth,
                                 bord_step, bord, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   ... and for the slaves
   ========================================================================== */
   for ( ima=1; ima<IREGIV_ima_num; ima++ ) {
      src_str = ima * NPoints[ ima - 1 ];
      IREGPP_LAYO_FillBorderArray ( NPoints[ ima ],
                                    IANNIV_ImageAnnot[ ima ].ImageLength,
                                    IANNIV_ImageAnnot[ ima ].ImageWidth,
                                    bord_step,
                                    &bord[ src_str ], status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Transform the slave coordinates into the master reference system
   ========================================================================== */
      for ( poi=0; poi<NPoints[ ima ]; poi++ ) {
         IREGPP_WAEV_Sla2Mas ( bord[ src_str + poi ], IREGPV_warp_deg, ima,
                               &bord[ src_str + poi ], status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

/* ==========================================================================
   Look for the common area
   ========================================================================== */
   for ( ima=0, TotNPoints=0; ima<IREGIV_ima_num; ima++ ) {

/* ==========================================================================
   Set the starting index of the source image in the border array
   ========================================================================== */
      if ( ima == 0 ) {
         src_str = 0;
      }
      else {
         src_str = ima * NPoints[ ima - 1 ];
      }

/* ==========================================================================
   Reallocate the temporary borders array ...
   ========================================================================== */
      if ( ( tmp = (MATHIT_RC *)MEMSIP_realloc ( (void *)tmp, (size_t)
                                                  (NPoints[ ima ] *
                                                  sizeof (MATHIT_RC)) ) ) ==
           (MATHIT_RC *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "for the border array" );
      }
 
/* ==========================================================================
   Fill the temporary array with source image borders points
   ========================================================================== */
      memcpy ( (void *)tmp, (const void *)&bord[ src_str ],
               (size_t)(NPoints[ ima ] * sizeof (MATHIT_RC)) );

/* ==========================================================================
   Loop over the other images
   ========================================================================== */
      for ( i=0, N=NPoints[ ima ]; i<IREGIV_ima_num-1; i++ ) {

/* ==========================================================================
   Set the index of the target image in the border array
   ========================================================================== */
         j = index[ ima ][ i ];
         if ( j == 0 ) {
            trg_str = 0;
         }
         else {
            trg_str = j * NPoints[ j - 1 ];
         }

/* ==========================================================================
   Loop over the valid points
   ========================================================================== */
         for ( poi=0, counter=0; poi<N; poi++ ) {

/* ==========================================================================
   Check if the point is inside the second image
   ========================================================================== */
            COORIP_AOIX_CheckPointInAoID ( (UINTx4)NPoints[ j ],
                                           &bord[ trg_str ], &tmp[ poi ],
                                           &in_out, status_code );
            ERRSIM_on_err_goto_exit ( *status_code );
            if ( in_out >= 0 ) {
               memcpy ( (void *)&tmp[ counter++ ], (const void *)&tmp[ poi ],
                        sizeof (MATHIT_RC) );
            }
         }
         N = counter;
      }

/* ==========================================================================
   Fill the global array
   ========================================================================== */
      if ( N > 0 ) {
         memcpy ( (void *)&min_bord[ TotNPoints ], (const void *)tmp,
                  (size_t)(N * sizeof (MATHIT_RC)) );
         TotNPoints += N;
      }
   }

/* ==========================================================================
   Find the maximum overlap among the common areas
   ========================================================================== */
   if ( TotNPoints > 1 ) {
      IREGPP_LAYO_MaxSlaveCorners ( TotNPoints, min_bord, corn, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }
   else {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_dimensions,
                         "in output" );
   }

/* ==========================================================================
   Fill the output variables
   ========================================================================== */
   *TLRow = (INTx4)(floor ( corn[ 0 ].row ));
   *TLCol = (INTx4)(floor ( corn[ 0 ].col ));
   *BRRow = (INTx4)(ceil ( corn[ 2 ].row ));
   *BRCol = (INTx4)(ceil ( corn[ 2 ].col ));

error_exit:;

/* ==========================================================================
   Free the left memories
   ========================================================================== */
   MEMSIP_free ( (void **)&min_bord );
   MEMSIP_free ( (void **)&bord );
   MEMSIP_free ( (void **)&tmp );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_LAYO_MinOverlap */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_FillBorderArray

        $TYPE         PROCEDURE

        $INPUT        Np    : dimension of the array
                      NRow  : number of rows of the image
                      NCol  : number of columns of the image
                      Step  : step of the points

        $MODIFIED     NONE

        $OUTPUT       array : array to fill with the points on the border
                              of the image

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluate an array of points covering
                      the image border

        $WARNING      NONE

        $PDL          - Checks the inputs parameters
                      - Zeroes the array
                      - While the point has a column coordinate inside the
                        top image border
                            - Fill the column coordinate of the current
                              point
                            - Increments the counter
                      - End while
                      - While the point has a row coordinate inside the
                        left image border
                            - Fill the row coordinate of the current point
                            - Fill its column coordinate
                            - Increments the counter
                      - End while
                      - While the point has a column coordinate inside the
                        bottom image border
                            - Fill the row coordinate of the current point
                            - Fill its column coordinate
                            - Increments the counter
                      - End while
                      - While the point has a row coordinate inside the
                        right image border
                            - Fill the row coordinate of the current point
                            - Increments the counter
                      - End while

   $EH
   ========================================================================== */

void IREGPP_LAYO_FillBorderArray
                        (/*IN    */ INTx4                Np,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ INTx4                Step,
                         /*   OUT*/ MATHIT_RC           *array,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_LAYO_FillBorderArray";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  tot_count = 0;
   INTx4                  count = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the number of points
   ========================================================================== */
   if ( Np < 4 ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_insuff_n_points, "" );
   }

/* ==========================================================================
   Check the input rows and columns image dimensions
   ========================================================================== */
   if ( ( NRow < 1 ) || ( NCol < 1 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_null_dimensions, "" );
   }

/* ==========================================================================
   Zero it
   ========================================================================== */
   memset ( (void *)array, '\0', (size_t)(Np * sizeof (MATHIT_RC)) );

/* ==========================================================================
   First border from Top Left to Top Right
   ========================================================================== */
   if ( NCol <= Step ) {
      while ( ( tot_count < ( NCol - 1 ) ) && ( tot_count < Np ) ) {
         array[ tot_count ].col = (double)tot_count;
         tot_count++;
      }
   }
   else {
      while ( ( (INTx4)(tot_count * Step) < ( NCol - 1 ) ) && ( tot_count < Np ) ) {
         array[ tot_count ].col = (double)(tot_count * Step);
         tot_count++;
      }
   }

/* ==========================================================================
   Second border from Top Right to Bottom Right
   ========================================================================== */
   if ( NRow <= Step ) {
      while ( ( count < ( NRow - 1 ) ) && ( tot_count < Np ) ) {
         array[ tot_count ].row = (double)count;
         array[ tot_count++ ].col = (double)(NCol - 1);
         count++;
      }
   }
   else {
      while ( ( (INTx4)(count * Step) < ( NRow - 1 ) ) && ( tot_count < Np ) ) {
         array[ tot_count ].row = (double)(count * Step);
         array[ tot_count++ ].col = (double)(NCol - 1);
         count++;
      }
   }

/* ==========================================================================
   Third border from Bottom Right to Bottom Left
   ========================================================================== */
   count = 0;
   if ( NCol <= Step ) {
      while ( ( ( NCol - 1 - count ) > 0 ) && ( tot_count < Np ) ) {
         array[ tot_count ].row = (double)(NRow - 1);
         array[ tot_count++ ].col = (double)(NCol - 1 - count);
         count++;
      }
   }
   else {
      while ( ( ( NCol - 1 - (INTx4)(count * Step) ) > 0 ) &&
              ( tot_count < Np ) ) {
         array[ tot_count ].row = (double)(NRow - 1);
         array[ tot_count++ ].col = (double)(NCol - 1 - (INTx4)(count * Step));
         count++;
      }
   }

/* ==========================================================================
   Fourth border from Bottom Left to Top Left
   ========================================================================== */
   count = 0;
   if ( NRow <= Step )  {
      while ( ( ( NRow - 1 - count ) > 0 ) && ( tot_count < Np ) ) {
         array[ tot_count++ ].row = (double)(NRow - 1 - count);
         count++;
      }
   }
   else {
      while ( ( ( NRow - 1 - (INTx4)(count * Step) ) > 0 ) &&
              ( tot_count < Np ) ) {
         array[ tot_count++ ].row = (double)(NRow - 1 - (INTx4)(count * Step));
         count++;
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_LAYO_FillBorderArray */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_Slave2MasterContour

        $TYPE         PROCEDURE

        $INPUT        sla_gnum : ID of the slave
                      Np       : number of points to transform

        $MODIFIED     arr      : array of points to be transformed. In output
                                 it contains the transformed points

        $OUTPUT       NONE

        $GLOBAL       IREGPV_warp_deg : chosed warp degree

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_insuff_n_points

        $DESCRIPTION  This procedure applies the warp transformation to a
                      set of slave points coordinates and converts them into
                      master referred coordinates

        $WARNING      NONE

        $PDL          - Checks the slave image num
                      - Checks the number of points
                      - Loop over the points to convert
                            - Converts the point from slave to master
                              reference system coordinates
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_LAYO_Slave2MasterContour
                        (/*IN    */ UINTx1               sla_gnum,
                         /*IN    */ INTx4                Np,
                         /*IN OUT*/ MATHIT_RC           *arr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_LAYO_Slave2MasterContour";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  poi;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the slave imanum
   ========================================================================== */
   if ( ( sla_gnum < 1 ) || ( sla_gnum > IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out, "" );
   }

/* ==========================================================================
   Check on the number of points
   ========================================================================== */
   if ( Np < 4 ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_insuff_n_points, "" );
   }

/* ==========================================================================
   Loop over the contour points
   ========================================================================== */
   for ( poi=0; poi<Np; poi++ ) {

/* ==========================================================================
   From slave to master reference system
   ========================================================================== */
      IREGPP_WAEV_Sla2Mas ( arr[ poi ], IREGPV_warp_deg, sla_gnum,
                            &arr[ poi ], status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_LAYO_Slave2MasterContour */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_MaxSlaveCorners

        $TYPE         PROCEDURE

        $INPUT        Np   : number of points of the array
                      arr  : array of points

        $MODIFIED     NONE

        $OUTPUT       corn : array with the image extreems

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure finds the maximum and the minimum among
                      the coordinates of an array and fills an output array
                      with the four vertices of the square surrounding the
                      array points

        $WARNING      NONE

        $PDL          - Loop over the array points
                            - Fills the minimum value for the rows with the
                              minimum between the row point coordinate and
                              the minimum value stored before
                            - Fills the minimum value for the columns with
                              the minimum between the row point coordinate
                              and the minimum value stored before
                            - Fills the maximum value for the rows with the
                              maximum between the row point coordinate and
                              the maximum value stored before
                            - Fills the maximum value for the columns with
                              the maximum between the row point coordinate
                              and the maximum value stored before
                      - End Loop
                      - Fills the output array with the values of the
                        coordinates of the corners of the square surrounding
                        the array curve of points

   $EH
   ========================================================================== */

void IREGPP_LAYO_MaxSlaveCorners
                        (/*IN    */ INTx4                Np,
                         /*IN    */ MATHIT_RC           *arr,
                         /*   OUT*/ MATHIT_RC           *corn,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_LAYO_MaxSlaveCorners";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  poi;
   MATHIT_RC              min_rc =  { 1.e+38, 1.e+38 };
   MATHIT_RC              max_rc =  { -1.e+38, -1.e+38 };

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Search the minimum coordinates among the rows
   ========================================================================== */
   for ( poi=0; poi<Np; poi++ ) {

      /* minimum ... */
      if ( arr[ poi ].row < min_rc.row ) {
         min_rc.row = arr[ poi ].row;
      }
      if ( arr[ poi ].col < min_rc.col ) {
         min_rc.col = arr[ poi ].col;
      }

      /* ... and maximum */
      if ( arr[ poi ].row > max_rc.row ) {
         max_rc.row = arr[ poi ].row;
      }
      if ( arr[ poi ].col > max_rc.col ) {
         max_rc.col = arr[ poi ].col;
      }
   }

/* ==========================================================================
   Fill the corners for the slave
   ========================================================================== */
   /* top left corner */
   corn[ 0 ].row = min_rc.row;
   corn[ 0 ].col = min_rc.col;

   /* top right corner */
   corn[ 1 ].row = min_rc.row;
   corn[ 1 ].col = max_rc.col;

   /* bottom right corner */
   corn[ 2 ].row = max_rc.row;
   corn[ 2 ].col = max_rc.col;

   /* bottom left */
   corn[ 3 ].row = max_rc.row;
   corn[ 3 ].col = min_rc.col;

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_LAYO_MaxSlaveCorners */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_MinSlaveCorners

        $TYPE         PROCEDURE

        $INPUT        Np      : number of points of the array
                      arr     : array of points
                      in_flag : array with the information about the inner
                                points

        $MODIFIED     NONE

        $OUTPUT       corn    : array with the image extreems

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure finds the maximum and the minimum among
                      the coordinates of a set of points of an array and fills
                      an output array with the four vertices of the square
                      surrounding the set of array points

        $WARNING      NONE

        $PDL          - Loop over the array points
                            - If the point is a inner point
                                  - Fills the minimum value for the rows with the
                                    minimum between the row point coordinate and
                                    the minimum value stored before
                                  - Fills the minimum value for the columns with
                                    the minimum between the row point coordinate
                                    and the minimum value stored before
                                  - Fills the maximum value for the rows with the
                                    maximum between the row point coordinate and
                                    the maximum value stored before
                                  - Fills the maximum value for the columns with
                                    the maximum between the row point coordinate
                                    and the maximum value stored before
                            - End If
                      - End Loop
                      - Fills the output array with the values of the
                        coordinates of the corners of the square surrounding
                        the array curve of points

   $EH
   ========================================================================== */

void IREGPP_LAYO_MinSlaveCorners
                        (/*IN    */ INTx4                Np,
                         /*IN    */ MATHIT_RC           *arr,
                         /*IN    */ LDEFIT_boolean      *in_flag,
                         /*   OUT*/ MATHIT_RC           *corn,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_LAYO_MinSlaveCorners";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  poi;
   MATHIT_RC              min_rc =  { 1.e+38, 1.e+38 };
   MATHIT_RC              max_rc =  { -1.e+38, -1.e+38 };

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Search the minimum coordinates among the rows
   ========================================================================== */
   for ( poi=0; poi<Np; poi++ ) {

/* ==========================================================================
   Check if the point is a inner one
   ========================================================================== */
      if ( in_flag[ poi ] ) {

         /* minimum ... */
         if ( arr[ poi ].row < min_rc.row ) {
            min_rc.row = arr[ poi ].row;
         }
         if ( arr[ poi ].col < min_rc.col ) {
            min_rc.col = arr[ poi ].col;
         }

         /* ... and maximum */
         if ( arr[ poi ].row > max_rc.row ) {
            max_rc.row = arr[ poi ].row;
         }
         if ( arr[ poi ].col > max_rc.col ) {
            max_rc.col = arr[ poi ].col;
         }
      }
   }

/* ==========================================================================
   Fill the corners for the slave
   ========================================================================== */

   /* top left corner */
   corn[ 0 ].row = min_rc.row;
   corn[ 0 ].col = min_rc.col;

   /* top right corner */
   corn[ 1 ].row = min_rc.row;
   corn[ 1 ].col = max_rc.col;

   /* bottom right corner */
   corn[ 2 ].row = max_rc.row;
   corn[ 2 ].col = max_rc.col;

   /* bottom left */
   corn[ 3 ].row = max_rc.row;
   corn[ 3 ].col = min_rc.col;

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_LAYO_MinSlaveCorners */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_CornersEval

        $TYPE         PROCEDURE

        $INPUT        mode  : overlap mode

        $MODIFIED     NONE

        $OUTPUT       TLRow : top left row coordinate in the master
                              reference system
                      TLCol : top left column coordinate in the master
                              reference system
                      BRRow : bottom right row coordinate in the master
                              reference system
                      BRCol : bottom right column coordinate in the master
                              reference system

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_over_mode_undef

        $DESCRIPTION  This procedure evaluates the corners of the layout of
                      the co-registered images

        $WARNING      NONE

        $PDL          - Switches over the different mode
                            - Sets the index for the function to call
                      - End Switch
                      - Calls the right function

   $EH
   ========================================================================== */

void IREGPP_LAYO_CornersEval
                        (/*IN    */ IREGPT_over_mode     mode,
                         /*   OUT*/ INTx4               *TLRow,
                         /*   OUT*/ INTx4               *TLCol,
                         /*   OUT*/ INTx4               *BRRow,
                         /*   OUT*/ INTx4               *BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_LAYO_CornersEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 fun;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Set the index
   ========================================================================== */
   switch ( mode ) {
      case IREGPE_om_min:
         fun = 0;
      break;
      case IREGPE_om_max:
         fun = 1;
      break;
      case IREGPE_om_master:
         fun = 2;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_over_mode_undef, "" );
   }

/* ==========================================================================
   Call the appropriate procedure
   ========================================================================== */
   ( *IREGPC_over_func[ fun ] )
      ( TLRow, TLCol, BRRow, BRCol, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_LAYO_CornersEval */

#ifdef __EXAM__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGIP_LAYO_

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void IREGIP_LAYO_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGIP_LAYO_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGIP_LAYO_ */
#endif
