/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_STAT

      $FUNCTION          This module contains the task procedure for
			 the Sar Toolbox STATISTICAL TOOL

      $ROUTINE           STBXPP_STAT_global
			 STBXPP_STAT_local
			 STBXPP_STAT_pca

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       22-AUG-97     AG       Initial Release
           SCR # 21   17-DEC-97     AG       Changed computation of
                                             SubImageTopLeftRow and
                                             SubImageTopLeftCol in output image
                                             annotation of STBXPP_STAT_local

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */


#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include SRVS_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include IANN_INTF_H
#include COOR_INTF_H
#include STAT_INTF_H
#include STBX_INTF_H
#include STBX_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_STAT_global

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the GLOBAL STATISTIC task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
		      - Open the input file
                      - Get the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
		      - Call STATIP_GLOB_stat routine
                      - Close input file
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_STAT_global
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_STAT_global";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILSIT_file_name        inImage, outFile;
   FILSIT_file_name        inImageName, outFileName;
   FILE                   *fp = (FILE *) NULL;
   float                   class_min, class_max;
   INTx4                   class_no;
   LDEFIT_boolean          real_aoi;

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   float                   mean, sddv, cfvr;
   UINTx4                 *classes;
   float                  *classes_norm;
   float                  *classes_limit;
   float                   min, max;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 5 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy( task.parm[ 0 ].name, STBXPD_input_image );
   task.parm[ 0 ].type = FIISIE_tt_string;
   task.parm[ 0 ].size = sizeof( FILSIT_file_name );
   task.parm[ 0 ].mandatory = TRUE;
   task.parm[ 0 ].vector = FALSE;
   task.parm[ 0 ].value = (void *) inImageName;

   strcpy( task.parm[ 1 ].name, STBXPD_output_file );
   task.parm[ 1 ].type = FIISIE_tt_string;
   task.parm[ 1 ].size = sizeof( FILSIT_file_name );
   task.parm[ 1 ].mandatory = TRUE;
   task.parm[ 1 ].vector = FALSE;
   task.parm[ 1 ].value = (void *) outFileName;

   strcpy( task.parm[ 2 ].name, STBXPD_class_min_val);
   task.parm[ 2 ].type = FIISIE_tt_float;
   task.parm[ 2 ].size = sizeof( float );
   task.parm[ 2 ].mandatory = TRUE;
   task.parm[ 2 ].vector = FALSE;
   task.parm[ 2 ].value = (void *) &class_min;

   strcpy( task.parm[ 3 ].name, STBXPD_class_max_val);
   task.parm[ 3 ].type = FIISIE_tt_float;
   task.parm[ 3 ].size = sizeof( float );
   task.parm[ 3 ].mandatory = TRUE;
   task.parm[ 3 ].vector = FALSE;
   task.parm[ 3 ].value = (void *) &class_max;

   strcpy( task.parm[ 4 ].name, STBXPD_class_no);
   task.parm[ 4 ].type = FIISIE_tt_int;
   task.parm[ 4 ].size = sizeof( INTx4 );
   task.parm[ 4 ].mandatory = TRUE;
   task.parm[ 4 ].vector = FALSE;
   task.parm[ 4 ].value = (void *) &class_no;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read command line parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   printf( "%s : %s\n", STBXPD_input_image, inImageName);
   printf( "%s : %s\n", STBXPD_output_file, outFileName);
   printf( "%s : %f\n", STBXPD_class_min_val, class_min);
   printf( "%s : %f\n", STBXPD_class_max_val, class_max);
   printf( "%s : %d\n", STBXPD_class_no, class_no);
#endif

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input image and output report files
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outFileName,
                         task_name,
                         LDEFIE_dt_undef,
                         outFile,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check other parameters
   ========================================================================== */
   if( class_no <= 0 ) {
      ERRSIM_set_error( status_code,
	 	        ERRSID_STBX_parm_not_negative,
			task.parm[ 4 ].name );
   }

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outFile, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outFile, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   If the image has more than 1 sampleperpixel exit
   ========================================================================== */
   if( inp_io.spp >1 ) {
      ERRSIM_set_error( status_code,
		        ERRSID_STBX_inv_prod_type,
			"complex image" );
   }

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_STAT_GLOB, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Alloc output vectors
   ========================================================================== */
   classes = (UINTx4 *) MEMSIP_alloc( (class_no+2) * sizeof(UINTx4) );
   if( classes == (UINTx4 *) NULL ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STAT_err_mem_alloc,
                        "classes" );
   }
   classes_norm = (float *) MEMSIP_alloc( (class_no+2) * sizeof(float) );
   if( classes_norm == (float *) NULL ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STAT_err_mem_alloc,
                        "classes_norm" );
   }
   classes_limit = (float *) MEMSIP_alloc( (class_no+2) * sizeof(float) );
   if( classes_limit == (float *) NULL ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STAT_err_mem_alloc,
                        "classes_limit" );
   }

/* ==========================================================================
   Compute nrow_inp/ncol_inp of source image
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   STATIP_GLOB_stat(&inp_io,
		     inp_ima_num,
		     TLRow,
		     TLCol,
		     nrow_inp,
		     ncol_inp,
		     vertex_no,
		     vertex,
		     class_min,
		     class_max,
		     (UINTx4) class_no,
                    &min,
                    &max,
		    &mean,
		    &sddv,
		    &cfvr,
                     classes,
                     classes_norm,
                     classes_limit,
		     status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open out report file
   ========================================================================== */
   FILSIP_open( outFile, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Write values to report file
   ========================================================================== */
   fprintf(fp, "\nMean = %f\n", mean );
   fprintf(fp, "Standard Deviation = %f\n", sddv );
   fprintf(fp, "Coefficient of variation = %f\n", cfvr );
   fprintf(fp, "Min = %f\n", min );
   fprintf(fp, "Max = %f\n", max );
   for( i=0; i<class_no+1; i++ ) {
      fprintf(fp, "Class %0d #%0d %0f (less than %0f)\n", i, classes[ i ],
         classes_norm[ i ], classes_limit[ i ] );
   }
   i = class_no+1;
   fprintf(fp, "Class %0d #%0d %0f (greater than %0f)\n", i, classes[ i ],
      classes_norm[ i ], classes_limit[ i ] );

/* ==========================================================================
   Close report file
   ========================================================================== */
   FILSIP_close( &fp, &log_status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );
   MEMSIP_free( (void **) &classes );
   MEMSIP_free( (void **) &classes_norm );
   MEMSIP_free( (void **) &classes_limit );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      FILSIP_delete( outFile, &log_status_code );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_STAT_global */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_STAT_local

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the LOCAL STATISTIC task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call STATIP_LOCA_stat routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_STAT_local
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_STAT_local";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImage, outImage;
   FILSIT_file_name        inImageName, outImageName;
   LDEFIT_boolean          real_aoi;
   float                   outImageRatio[ 2 ];
   UINTx4                  ipar, winSizesParNo, 
                           winIncrementsParNo, outImageRatioParNo;
   char                    err_msg[ 256 ];

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io, out_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   char                    outImageType[ 6 ];
   float                   fill_val = 0.0;
   INTx4                   win_sizes[ 2 ];
   double                  win_increments[ 2 ];
   STATIT_image_type       imageType;
   LDEFIT_boolean          out_open = FALSE;
   char			   imat[ 3 ][ 12 ] = {
			      " Local Mean", " Local Sddv", " Local Cfvr"
			   };

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            out_ima_num = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 7 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) outImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image_type );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( outImageType );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) outImageType;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_window_sizes);
   task.parm[ ipar ].type = FIISIE_tt_int;
   task.parm[ ipar ].size = sizeof( INTx4 );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value = (void *) win_sizes;
   winSizesParNo = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_window_increments);
   task.parm[ ipar ].type = FIISIE_tt_double;
   task.parm[ ipar ].size = sizeof( double );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value = (void *) win_increments;
   winIncrementsParNo = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_filler_value);
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &fill_val;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image_ratio );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value = (void *) outImageRatio;
   outImageRatioParNo = ipar;
   
/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   printf( "%s : %s\n", STBXPD_input_image, inImageName);
   printf( "%s : %s\n", STBXPD_output_image, outImageName);
   printf( "%s : %s\n", STBXPD_output_image_type, outImageType);
   printf( "%s : ", STBXPD_window_sizes);
   for( i=0; i<task.parm[ winSizesParNo ].number; i++) printf("%d ", win_sizes[ i ]);
   printf("\n");
   printf( "%s : ", STBXPD_window_increments);
   for( i=0; i<task.parm[ winIncrementsParNo ].number; i++) printf("%lf ", win_increments[ i ]);
   printf("\n");
   printf( "%s : %f\n", STBXPD_filler_value, fill_val);
   printf( "%s : ", STBXPD_output_image_ratio );
   for( i=0; i<task.parm[ outImageRatioParNo ].number; i++ ) {
      printf("%f ", outImageRatio[ i ]);
   }
   printf("\n");
#endif

/* ==========================================================================
   Check that at least one of Window Steps and Output Image Ratio has been
   specfied
   ========================================================================== */
   if( ( !task.parm[ winIncrementsParNo ].founded ) &&
       ( !task.parm[ outImageRatioParNo ].founded ) ) {
      sprintf( err_msg, "%s or %s", STBXPD_window_increments,
         STBXPD_output_image_ratio );
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_defined, err_msg );
   }

   if( ( task.parm[ winIncrementsParNo ].founded ) &&
       ( task.parm[ outImageRatioParNo ].founded ) ) {
      sprintf( err_msg, "%s and %s both defined", STBXPD_window_increments,
         STBXPD_output_image_ratio );
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, err_msg );
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );

/* ==========================================================================
   Select output image type
   ========================================================================== */
   if( !strcmp( outImageType, STBXPD_output_image_type_mean ) ) {
      imageType = STATIE_image_mean;
   }
   else if( !strcmp( outImageType, STBXPD_output_image_type_sddv ) ) {
      imageType = STATIE_image_sddv;
   }
   else if( !strcmp( outImageType, STBXPD_output_image_type_cfvr ) ) {
      imageType = STATIE_image_cfvr;
   }
   else {
      ERRSIM_set_error( status_code,
			ERRSID_STBX_parm_not_defined,
			task.parm[ 2 ].name );
   }

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameter inImageName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   If the image has more than 1 sampleperpixel exit
   ========================================================================== */
   if( inp_io.spp>1 ) {
      ERRSIM_set_error( status_code,
		        ERRSID_STBX_inv_prod_type,
			"complex image" );
   }

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_STAT_LOCA, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute nrow_inp/ncol_inp of source image
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

#ifdef __TRACE__
   fprintf( stdout, "TLRow = %0d\n", TLRow );
   fprintf( stdout, "TLCol = %0d\n", TLCol );
   fprintf( stdout, "BRRow = %0d\n", BRRow );
   fprintf( stdout, "BRCol = %0d\n", BRCol );
   fprintf( stdout, "nrow_inp = %0d\n", nrow_inp);
   fprintf( stdout, "ncol_inp = %0d\n", ncol_inp);
   for(i=0; i<vertex_no; i++) {
      fprintf( stdout, "vertex[ %0d ].row = %f\n", i, vertex[ i ].row );
      fprintf( stdout, "vertex[ %0d ].col = %f\n", i, vertex[ i ].col );
   }
#endif

/* ==========================================================================
   Compute nrow_out/ncol_out of out image
   ========================================================================== */
   if( task.parm[ winIncrementsParNo ].founded ) {

      if( win_sizes[ 0 ] <= 0 ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_negative,
                           task.parm[ winSizesParNo ].name );
      }
      if( win_increments[ 0 ] <= 0.0 ) {
         ERRSIM_set_error( status_code,
   			ERRSID_STBX_parm_not_negative,
   			task.parm[ 4 ].name );
      }
      if( nrow_inp < win_sizes[ 0 ] ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            "Row window size greater or equal that number of input rows" );
      }
      nrow_out = SRVSIM_out( nrow_inp, win_sizes[ 0 ], win_increments[ 0 ] );
      if( ( task.parm[ winSizesParNo ].number > 1 ) &&
          ( task.parm[ winIncrementsParNo ].number > 1 ) ) {
         if( win_sizes[ 1 ] <= 0 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_negative,
                              task.parm[ winSizesParNo ].name );
         }
         if( win_increments[ 1 ] <= 0.0 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_negative,
                              task.parm[ winIncrementsParNo ].name );
         }
         if( ncol_inp < win_sizes[ 1 ] ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
               "Column window size greater or equal that number of input columns");
         }
         ncol_out = SRVSIM_out( ncol_inp, win_sizes[ 1 ], win_increments[ 1 ] );
      }
      else {
         if( task.parm[ winSizesParNo ].number <= 1 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_defined,
                              task.parm[ winSizesParNo ].name );
         }
         if( task.parm[ winIncrementsParNo ].number <= 1 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_defined,
                              task.parm[ winIncrementsParNo ].name );
         }
      }

   }
   else if( task.parm[ outImageRatioParNo ].founded ) {

      if( win_sizes[ 0 ] <= 0 ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_negative,
                           task.parm[ winSizesParNo ].name );
      }

      if( outImageRatio[ 0 ] <= 0.0 ) {
         ERRSIM_set_error( status_code,
   			ERRSID_STBX_parm_not_negative,
   			task.parm[ outImageRatioParNo ].name );
      }

      if( nrow_inp < win_sizes[ 0 ] ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            "Row window size greater or equal that number of input rows" );
      }
      nrow_out = (UINTx4) ROUND(((float) nrow_inp) * outImageRatio[ 0 ]);
      win_increments[ 0 ] = SRVSIM_step( nrow_inp, win_sizes[ 0 ], nrow_out );

      if( ( task.parm[ outImageRatioParNo ].number > 1 ) &&
          ( task.parm[ winSizesParNo ].number > 1 ) ) {
         if( win_sizes[ 1 ] <= 0 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_negative,
                              task.parm[ winSizesParNo ].name );
         }
         if( outImageRatio[ 1 ] <= 0.0 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_negative,
                              task.parm[ winIncrementsParNo ].name );
         }
         if( ncol_inp < win_sizes[ 1 ] ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
               "Column window size greater or equal that number of input columns");
         }
         ncol_out = (UINTx4) ROUND(((float) ncol_inp) * outImageRatio[ 1 ]);
         win_increments[ 1 ] = SRVSIM_step( ncol_inp, win_sizes[ 1 ], ncol_out );
      }
      else {
         if( task.parm[ winSizesParNo ].number <= 1 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_defined,
                              task.parm[ winSizesParNo ].name );
         }
         if( task.parm[ outImageRatioParNo ].number <= 1 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_defined,
                              task.parm[ winIncrementsParNo ].name );
         }
      }
#ifdef __TRACE__
   fprintf( stdout, "row_step = %0f\n", win_increments[ 0 ] );
   fprintf( stdout, "col_step = %0f\n", win_increments[ 1 ] );
#endif
   }


#ifdef __TRACE__
   fprintf( stdout, "nrow_out = %0d\n", nrow_out);
   fprintf( stdout, "ncol_out = %0d\n", ncol_out);
#endif

/* ==========================================================================
   Build full name of output image
   ========================================================================== */
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         ((inp_io.val.tif.bpar.sampleperpixel == 1) ?
                          LDEFIE_dt_float : LDEFIE_dt_2_float),
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters outImageName
   ========================================================================== */
   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = inp_io.val.tif.bpar.sampleperpixel;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   if ( out_io.val.tif.bpar.sampleperpixel == 2 ) {
      out_io.val.tif.bpar.bitspersample[1] = 
                                out_io.val.tif.bpar.bitspersample[0];
      out_io.val.tif.bpar.sampleformat[1] = TIFSID_float;
   }
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   STATIP_LOCA_stat(&inp_io,
		     inp_ima_num,
		     TLRow,
		     TLCol,
		     nrow_inp,
		     ncol_inp,
		     vertex_no,
		     vertex,
		     win_sizes,
		     win_increments,
		     fill_val,
		    &out_io,
                     nrow_out,
                     ncol_out,
		     imageType,
		     status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Spacing section
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].LineSpacing_m *=
      (float)win_increments[ 0 ];
   IANNIV_ImageAnnot[ out_ima_num ].PixelSpacing_m *=
      (float)win_increments[ 1 ];

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND((TLRow + (float)(win_sizes[ 0 ] - 1)/2.0) / 
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND((TLCol + (float)(win_sizes[ 1 ] - 1)/2.0) / 
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Scale factors
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].YScalingFactor /=
      (float)win_increments[ 0 ];
   IANNIV_ImageAnnot[ out_ima_num ].XScalingFactor /=
      (float)win_increments[ 1 ];

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   switch ( imageType ) {
      case STATIE_image_mean:
	 IANNIP_PUTP_UpdateProcHistory( out_ima_num,
					task.name,
					imat[ 0 ],
					status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
      break;
      case STATIE_image_sddv:
	 IANNIP_PUTP_UpdateProcHistory( out_ima_num,
					task.name,
					imat[ 1 ],
					status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
      break;
      case STATIE_image_cfvr:
	 IANNIP_PUTP_UpdateProcHistory( out_ima_num,
					task.name,
					imat[ 2 ],
					status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
      break;
   }

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_STAT_local */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_STAT_pca

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid
                      ERRSID_STBX_not_poly_aoi

        $DESCRIPTION  This routine executes the PRINCIPAL COMPONENT ANALYSIS 
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Open input files getting the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Exit for non rectangular AOI
                      - Compute nrow_inp/ncol_inp of input images
		      - Set nrow_out/ncol_out of output image to 
                        nrow_inp/ncol_inp
                      - Initialize output files TIFF parameters
                      - Open output files
                      - Call STATIP_PCAN_pca routine
		      - Update the processing history of output files
                      - Set the image annotations of the output files
                      - Close output and input files
                      - Delete input files, if requested

   $EH
   ========================================================================== */
void STBXPP_STAT_pca
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_STAT_pca";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImages[ STBXPD_num_pca_img ],
                           pcaOutImages[ STBXPD_num_pca_img ];
   FILSIT_file_name        inImagesName[ STBXPD_num_pca_img ],
                           pcaOutImagesName[ STBXPD_num_pca_img ];

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   LDEFIT_boolean          real_aoi;
   UINTx2                  npar = 0;
   GIOSIT_io               inp_io[ STBXPD_num_pca_img ];
   GIOSIT_io               out_io[ STBXPD_num_pca_img ];

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   LDEFIT_boolean          outs_open[ STBXPD_num_pca_img ];

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   UINTx1                  inp_ima_nums[ STBXPD_num_pca_img ];
   UINTx1                  out_ima_nums[ STBXPD_num_pca_img ];
   char                    SceneRefNum[ LDEFID_char_line ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy( task.parm[ 0 ].name, STBXPD_input_images );
   task.parm[ 0 ].type = FIISIE_tt_string;
   task.parm[ 0 ].size = sizeof( FILSIT_file_name );
   task.parm[ 0 ].mandatory = TRUE;
   task.parm[ 0 ].vector = TRUE;
   task.parm[ 0 ].max_number = STBXPD_num_pca_img;
   task.parm[ 0 ].value = (void *) inImagesName;

   strcpy( task.parm[ 1 ].name, STBXPD_pca_output_images );
   task.parm[ 1 ].type = FIISIE_tt_string;
   task.parm[ 1 ].size = sizeof( FILSIT_file_name );
   task.parm[ 1 ].mandatory = TRUE;
   task.parm[ 1 ].vector = TRUE;
   task.parm[ 1 ].max_number = STBXPD_num_pca_img;
   task.parm[ 1 ].value = (void *) pcaOutImagesName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   printf( "%s : ", STBXPD_input_images );
   for( i=0; i<task.parm[ 0 ].number; i++) printf("%s ", inImagesName[ i ]);
   printf("\n");
   printf( "%s : ", STBXPD_pca_output_images );
   for( i=0; i<task.parm[ 1 ].number; i++) 
      printf("%s ", pcaOutImagesName[ i ]);
   printf("\n");
#endif

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input images
   ========================================================================== */
   for( i=0; i<task.parm[ 0 ].number; i++) {
      sprintf( inImages[ i ], "%s%s", LDEFIV_inp_dir, inImagesName[ i ] );
   }

/* ==========================================================================
   Check other parameters
   ========================================================================== */
   if( task.parm[ 0 ].number< STBXPD_num_pca_img ) {
      ERRSIM_set_error( status_code,
			ERRSID_STBX_parm_invalid,
			task.parm[ 0 ].name );
   }
   for( i=0; i<STBXPD_num_pca_img; i++ ) {
      inp_ima_nums[ i ] = i;
   }

   if( task.parm[ 1 ].number< STBXPD_num_pca_img ) {
      ERRSIM_set_error( status_code,
			ERRSID_STBX_parm_invalid,
			task.parm[ 1 ].name );
   }

   for( i=0; i<STBXPD_num_pca_img; i++ ) {
      out_ima_nums[ i ] = STBXPD_num_pca_img + i;
      outs_open[ i ] = FALSE;
   }

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImages
   ========================================================================== */
   for( i=0; i<STBXPD_num_pca_img; i++) {
      FILSIP_open( inImages[ i ], "r", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      FILSIP_close( &fp, &log_status_code );
   }

/* ==========================================================================
   Open the input files
   ========================================================================== */
   for( i=0; i<STBXPD_num_pca_img; i++ ) {

/* ==========================================================================
   Open the image i
   ========================================================================== */
      inp_io[ i ].type = GIOSIE_tif;
      inp_io[ i ].mode = 'r';
      strcpy( inp_io[ i ].val.tif.name, inImages[ i ] );
      inp_io[ i ].img = 0;
      GIOSIP_open_io( &(inp_io[ i ]),
                       status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   If the image i has more than 1 sampleperpixel exit
   ========================================================================== */
      if( inp_io[ i ].val.tif.bpar.sampleperpixel>1 ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_STBX_parm_invalid,
			   "sampleperpixel of input images" );
      }

/* ==========================================================================
   Get the image annotations for i
   ========================================================================== */
      IANNIP_GETP_ImageAnnot( inp_io[ i ].chan, inp_io[ i ].img, 
                              inp_ima_nums[ i ], IANNID_STAT_PCA, 
                              inp_io[ i ].val.tif.bpar, status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Check if the image dimensions are the same
   ========================================================================== */
   for( i=1; i<STBXPD_num_pca_img; i++ ) {
      if( ( inp_io[ i ].val.tif.bpar.imagelength != 
            inp_io[ 0 ].val.tif.bpar.imagelength ) ||
	  ( inp_io[ i ].val.tif.bpar.imagewidth != 
            inp_io[ 0 ].val.tif.bpar.imagewidth) ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_STBX_parm_invalid,
			   "different dimensions of input images" );
      }
   }

/* ==========================================================================
   Build full name of output images
   ========================================================================== */
   for( i=0; i<task.parm[ 1 ].number; i++) {
      STBXPP_bld_file_name( pcaOutImagesName[ i ],
			    task_name,
                            ((inp_io[ 0 ].val.tif.bpar.sampleperpixel == 1) ?
                             LDEFIE_dt_float : LDEFIE_dt_2_float),
			    pcaOutImages[ i ],
			    status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Check on the input parameters pcaOutImages
   ========================================================================== */
   for( i=0; i<STBXPD_num_pca_img; i++) {
      FILSIP_open( pcaOutImages[ i ], "w", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      FILSIP_close( &fp, &log_status_code );

      FILSIP_delete( pcaOutImages[ i ], &log_status_code );
   }

/* ==========================================================================
   Read AOI coordinates from INI file
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_nums[ 0 ],
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check if the AOI is a rectangular one
   ========================================================================== */
   if( real_aoi == TRUE ) {
      ERRSIM_set_error( status_code,
			ERRSID_STBX_not_poly_aoi,
			task.name );
   }

/* ==========================================================================
   Compute nrow_inp/ncol_inp of source image
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

/* ==========================================================================
   Set nrow_out/ncol_out of out image to nrow_inp/ncol_inp
   ========================================================================== */
   nrow_out = nrow_inp;
   ncol_out = ncol_inp;

/* ==========================================================================
   For each output image j
   ========================================================================== */
   for( j=0; j<STBXPD_num_pca_img; j++ ) {

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
      TIFSIM_bpar_init( out_io[ j ].val.tif.bpar );

/* ==========================================================================
   Initialize the output file
   ========================================================================== */
      out_io[ j ].val.tif.bpar.imagelength = nrow_out;
      out_io[ j ].val.tif.bpar.imagewidth = ncol_out;
      out_io[ j ].val.tif.bpar.sampleperpixel = 
                                inp_io[ 0 ].val.tif.bpar.sampleperpixel;
      out_io[ j ].val.tif.bpar.bitspersample[0] = 
                                (UINTx2)(sizeof(float)*LDEFID_byte_size);
      out_io[ j ].val.tif.bpar.sampleformat[0] = TIFSID_float;
      if ( out_io[ j ].val.tif.bpar.sampleperpixel == 2 ) {
	 out_io[ j ].val.tif.bpar.bitspersample[ out_ima_nums[ j ] ] = 
                                out_io[ j ].val.tif.bpar.bitspersample[0];
	 out_io[ j ].val.tif.bpar.sampleformat[ out_ima_nums[ j ] ] = 
                                TIFSID_float;
      }
      out_io[ j ].val.tif.bpar.disposition = 'x';
      npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open the output file
   ========================================================================== */
      out_io[ j ].type = GIOSIE_tif;
      out_io[ j ].mode = 'w';
      strcpy( out_io[ j ].val.tif.name, pcaOutImages[ j ] );
      out_io[ j ].val.tif.nimg = 1;
      out_io[ j ].val.tif.npar = npar;
      out_io[ j ].img = 0;
      GIOSIP_open_io( &(out_io[ j ]),
                       status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      outs_open[ j ] = TRUE;

   }

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   STATIP_PCAN_pca( &(inp_io[ 0 ]),
		    &(inp_io[ 1 ]),
	 	     inp_ima_nums[ 0 ],
		     inp_ima_nums[ 1 ],
		     TLRow,
		     TLCol,
		     nrow_inp,
		     ncol_inp,
		    &(out_io[ 0 ]),
		    &(out_io[ 1 ]),
		     nrow_out,
		     ncol_out,
		     status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the Scene Reference Number with that of the two
   ========================================================================== */
   memset( SceneRefNum, '\0', LDEFID_char_line );
   sprintf( SceneRefNum, "Sources: %s -- %s",
	    IANNIV_ImageAnnot[ inp_ima_nums[ 0 ] ].SceneReferenceNumbers,
	    IANNIV_ImageAnnot[ inp_ima_nums[ 1 ] ].SceneReferenceNumbers );

/* ==========================================================================
   For each output images i
   ========================================================================== */
   for( i=0; i<STBXPD_num_pca_img; i++ ) {

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
      IANNIP_GETP_CopyAnnot( inp_ima_nums[ 0 ], out_ima_nums[ i ], 
         status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
      switch ( out_io[ i ].val.tif.bpar.sampleperpixel ) {
	 case 1:
	    IANNIV_ImageAnnot[ out_ima_nums[ i ] ].BitsPerSample[0] = 
				   out_io[ i ].val.tif.bpar.bitspersample[0];
	    IANNIV_ImageAnnot[ out_ima_nums[ i ] ].SampleFormat[0] =
				   out_io[ i ].val.tif.bpar.sampleformat[0];
	 break;
	 case 2:
	    IANNIV_ImageAnnot[ out_ima_nums[ i ] ].BitsPerSample[0] = 
				   out_io[ i ].val.tif.bpar.bitspersample[0];
	    IANNIV_ImageAnnot[ out_ima_nums[ i ] ].BitsPerSample[1] = 
				   out_io[ i ].val.tif.bpar.bitspersample[1];
	    IANNIV_ImageAnnot[ out_ima_nums[ i ] ].SampleFormat[0] = 
				   out_io[ i ].val.tif.bpar.sampleformat[0];
	    IANNIV_ImageAnnot[ out_ima_nums[ i ] ].SampleFormat[1] = 
				   out_io[ i ].val.tif.bpar.sampleformat[1];
	 break;
      }

/* ==========================================================================
   Scene Reference Numbers of the sources
   ========================================================================== */
   sprintf( IANNIV_ImageAnnot[ out_ima_nums[ i ] ].SceneReferenceNumbers,
	    "%s", SceneRefNum );

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_nums[ i ] ].SubImageTopLeftRow =
      /* current offset */
      (INTx4) (TLRow / IANNIV_ImageAnnot[ inp_ima_nums[ i ] ].YScalingFactor) +
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_nums[ i ] ].SubImageTopLeftRow;

   IANNIV_ImageAnnot[ out_ima_nums[ i ] ].SubImageTopLeftCol =
      /* current offset */
      (INTx4) (TLCol / IANNIV_ImageAnnot[ inp_ima_nums[ i ] ].XScalingFactor) +
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_nums[ i ] ].SubImageTopLeftCol;

/* ==========================================================================
   Update coordinates of each output image
   ========================================================================== */
      STBXPP_update_coordinates( out_ima_nums[ i ],
                                 status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
      IANNIP_PUTP_UpdateProcHistory( out_ima_nums[ i ],
				     task.name, "",
				     status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
      IANNIP_PUTP_ImageAnnot(  out_io[ i ].chan,
			       out_io[ i ].img,
			       out_ima_nums[ i ],
			       status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
      GIOSIP_close_io( &(out_io[ i ]), status_code);
      ERRSIM_on_err_goto_exit( *status_code );

   }

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   for( i=0; i<STBXPD_num_pca_img; i++ ) {
      GIOSIP_close_io( &(inp_io[ i ]), status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      for( i=0; i<STBXPD_num_pca_img; i++ ) {
	 FILSIP_delete( inImages[ i ], &log_status_code );
      }
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output files, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      for( i=0; i<STBXPD_num_pca_img; i++ ) {
         if( outs_open[ i ] ) {
            GIOSIP_close_io( &(out_io[ i ]), &log_status_code);
         }
         FILSIP_delete( pcaOutImages[ i ], &log_status_code );
      }
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_STAT_pca */
