/* ==========================================================================
   $MODULE_HEADER

      $NAME              SRVS_LIBS

      $FUNCTION          SERVICE module

      $ROUTINE           SRVSIP_avail_memory
                         SRVSIP_trace_comp

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       28-AUG-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include FIIS_INTF_H
#include FILS_INTF_H
#include SRVS_INTF_H
#include SRVS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SRVSIP_avail_memory

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       avail_memsiz  :  amount of available memory

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This function returns the amount of available memory
                      in Kb as a user setting minus the size allocated via
                      MEMSIP_alloc

        $WARNING      NONE

        $PDL          - Get the user setting of initial free memory
                      - Get the amount of allocated memory
		      - Compute the amount of free memory as the user setting 
                        of initial free memory minus the amount of allocated 
			memory and a threshold

   $EH
   ========================================================================== */
void SRVSIP_avail_memory
                        (/*   OUT*/ UINTx4              *avail_memsize,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "SRVSIP_avail_memory";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   FIISIT_parm            mem_param;
   char                   section[ 40 ];
   FILSIT_file_name       cfg_file;
   INTx4                  avail_memsiz;
   INTx4                  tot_memsiz;
   UINTx4                 alloc_memsiz;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set avail to 0
   ========================================================================== */
   *avail_memsize = 0;

/* ==========================================================================
   Get the user setting of initial free memory
   ========================================================================== */
   strcpy( mem_param.name, SRVSPD_system_memory );
   mem_param.type = FIISIE_tt_int;
   mem_param.size = sizeof( INTx4 );
   mem_param.mandatory = TRUE;
   mem_param.vector = FALSE;
   mem_param.value = (void *) &tot_memsiz;

   sprintf( section, SRVSPD_system);
   sprintf( cfg_file, "%s%s", LDEFIV_cfg_dir, LDEFIV_system_file );
   
   FIISIP_GETS_get_info( cfg_file,
                         section,
                         0, /* unknown section number */
                        &mem_param,
                         status_code );
   if( *status_code != STC( ERRSID_normal ) ) {
      ERRSIM_set_error( status_code,
                        ERRSID_SRVS_uncomput_mem_avail,
                        "" );
   }

/* ==========================================================================
   Transform in bytes
   ========================================================================== */
   tot_memsiz *= 1024;

/* ==========================================================================
   Get the amount of allocated memory
   ========================================================================== */
   MEMSIP_size( &alloc_memsiz );

/* ==========================================================================
   Compute the amount of free memory as the user setting of initial free 
   memory minus the amount of allocated memory and a threshold
   ========================================================================== */
   if( alloc_memsiz > tot_memsiz ) {
      *avail_memsize = 0;
      ERRSIM_set_error( status_code,
                        ERRSID_SRVS_not_mem_avail,
                        "" );
   }
   else {
      avail_memsiz = (INTx4) ((tot_memsiz - alloc_memsiz)/1024);
      *avail_memsize  = (INTx4) ((float) avail_memsiz * SRVSPD_system_memory_thresh);
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SRVSIP_avail_memory */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SRVSIP_trace_comp

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This function is used to give a glance of the computation
                      running

        $WARNING      NONE

        $PDL          - If the modulus of sum for const is zero prints a point
                      - Flush the buffer

   $EH
   ========================================================================== */
void SRVSIP_trace_comp
                        (/*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "SRVSIP_trace_comp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  constant, k, reach;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set constant variable for printing
   ========================================================================== */
#if defined __MC68K__ || defined __POWERPC__
    constant = 5;
#else
    constant = 4;
#endif

/* ==========================================================================
   Increment the total count
   ========================================================================== */
   SRVSPV_sum++;

   if( SRVSPV_target_comp == 0 ) {

/* ==========================================================================
   If the modulus of sum for const is zero prints a point
   ========================================================================== */
#if defined __MC68K__ || defined __POWERPC__

      if( (SRVSPV_sum % constant) == 0 ) {
         fprintf( stdout, ".");
         fflush( stdout );
      }

#else

/* ==========================================================================
   Manage -\|/ rounding symbols
   ========================================================================== */
      if( (SRVSPV_sum % constant) == 0 ) {
         fprintf( stdout, "\r-");
      }
      else if( (SRVSPV_sum % constant) == 1 ) {
         fprintf( stdout, "\r\\");
      }
      else if( (SRVSPV_sum % constant) == 2 ) {
         fprintf( stdout, "\r|");
      }
      else if( (SRVSPV_sum % constant) == 3 ) {
         fprintf( stdout, "\r/");
      }
      fflush( stdout );

#endif
   }
   else {
      float complet;

/* ==========================================================================
   If the modulus of sum for const is zero prints a point
   ========================================================================== */
#if defined __MC68K__ || defined __POWERPC__

      if( (SRVSPV_sum % constant) == 0 ) {
         fprintf( stdout, ".");
         fflush( stdout );
      }

#else

/* ==========================================================================
   Manage -\|/ rounding symbols
   ========================================================================== */
      if( (SRVSPV_sum % constant) == 0 ) {
         fprintf( stdout, "\r-");
      }
      else if( (SRVSPV_sum % constant) == 1 ) {
         fprintf( stdout, "\r\\");
      }
      else if( (SRVSPV_sum % constant) == 2 ) {
         fprintf( stdout, "\r|");
      }
      else if( (SRVSPV_sum % constant) == 3 ) {
         fprintf( stdout, "\r/");
      }
      fflush( stdout );

#endif

      complet = (float)((double)SRVSPV_sum/(double)SRVSPV_target_comp * 100.0);

#ifdef __TRACE__
      fprintf( stdout,"sum=%0d perc=%0d complet=%f target=%0d\n", 
         SRVSPV_sum, SRVSPV_perc, complet, SRVSPV_target_comp );
#endif

      if( complet > (float) SRVSPV_perc) {

         if( (complet - (float) SRVSPV_perc) >
             ((float)(SRVSPV_perc+SRVSPD_count_step) - complet) ) {
            reach = (INTx4) ((complet - (float) SRVSPV_perc)/SRVSPD_count_step);
            reach--;
#ifdef __TRACE__
            fprintf( stdout, "reach = %0d\n", reach );
#endif
            for( k=0; k<reach; k++ ) {
#if defined __MC68K__ || defined __POWERPC__
               fprintf( stdout, " %0d%% completed.\n", SRVSPV_perc );
#else
#ifdef __TRACE__
               fprintf( stdout, "\n %0d%% completed. \n", SRVSPV_perc );
#else
               fprintf( stdout, " %0d%% completed. \r", SRVSPV_perc );
#endif
#endif
               SRVSPV_perc += SRVSPD_count_step;
            }
         }

#if defined __MC68K__ || defined __POWERPC__
         fprintf( stdout, " %0d%% completed.\n", SRVSPV_perc );
#else
#ifdef __TRACE__
         fprintf( stdout, "\n %0d%% completed. \n", SRVSPV_perc );
#else
         fprintf( stdout, " %0d%% completed. \r", SRVSPV_perc );
#endif
#endif
         SRVSPV_perc += SRVSPD_count_step;
      }


   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SRVSIP_trace_comp */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SRVSIP_set_comp

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This function is used to set the target value of 
                      computation

        $WARNING      NONE

        $PDL          NONE

   $EH
   ========================================================================== */
void SRVSIP_set_comp    (/*IN    */ INTx4                target_value,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "SRVSIP_set_comp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set the completion target value
   ========================================================================== */
   SRVSPV_sum = 0;
   SRVSPV_perc = SRVSPD_count_step;
   SRVSPV_target_comp = target_value;

#ifdef __TRACE__
   fprintf( stdout,"sum=%0d perc=%0d target=%0d\n\n", 
      SRVSPV_sum, SRVSPV_perc, SRVSPV_target_comp );
#endif

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SRVSIP_set_comp */
