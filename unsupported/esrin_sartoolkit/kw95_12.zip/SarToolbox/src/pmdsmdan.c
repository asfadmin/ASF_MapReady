/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_MDAN

      $FUNCTION          PMDSIP_MDAN_AddRecord
                         PMDSIP_MDAN_AddFile
                         PMDSIP_MDAN_AddVolume
                         PMDSIP_MDAN_ReadProductRecord
                         PMDSIP_MDAN_CompareProduct

      $ROUTINE           PMDSIP_MDAN_MediaAnalysis
                         PMDSIP_MDAN_ReadTape
                         PMDSIP_MDAN_CreateMCR


   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       11-NOV-97     DDN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include DEVS_INTF_H
#include SRVS_INTF_H
#include PMDS_INTF_H
#include PMDS_PGLB_H

/* ==========================================================================
                      LOCAL DEFINE DECLARATION SECTION
   ========================================================================== */
#define PMDSLD_MDAN_max_best        3
#define PMDSLD_MDAN_max_best_score  (double) 1.e38

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

#ifdef gino

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_

        $TYPE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_MDAN_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_MDAN_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSIP_MDAN_ */

#endif


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_MediaAnalysis

        $TYPE

        $INPUT        input_media_path : source product media
                      media_type       : product media type
                      num_of_vol       : number of volume(s)
                      db_file_name_p   : product(s) data base file name


        $MODIFIED     NONE

        $OUTPUT       mcr_file_name_p  : media content report file name

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_MDAN_MediaAnalysis
                        (/*IN    */ char                *input_media_path,
                         /*IN    */ DEVSIT_media_type    media_type,
                         /*IN    */ INTx4                num_of_vol,
                         /*IN    */ char                *db_file_name_p,
                         /*   OUT*/ char                *mcr_file_name_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_MDAN_MediaAnalysis";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   PMDSPT_VolDataList        *vol = (PMDSPT_VolDataList *) NULL; 
                                          /* structure including volume data */
   PMDSPT_VolDataList        *db_vols = (PMDSPT_VolDataList *) NULL;
                                          /* structure including data base
                                             volume data */
   INTx4                      count_db_vols;
                                          /* number of found data base 
                                             volume data */
   char                       msg[512];   /* temporary message buffer */
   INTx4                      ivol;       /* convenient loop variable */
   INTx4                      status;     /* returned status */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

#ifdef __TRACE__

fprintf(stderr,"Debug: input_media_path = <%s>\n", input_media_path);
fprintf(stderr,"Debug:       media_type = <%d>\n", media_type);
fprintf(stderr,"Debug:       num_of_vol = <%d>\n", num_of_vol);
fprintf(stderr,"Debug:   db_file_name_p = <%s>\n", db_file_name_p);
fprintf(stderr,"Debug:  mcr_file_name_p = <%s>\n", mcr_file_name_p);

#endif

/* ==========================================================================
   Allocate vol
   ========================================================================== */
   if( (vol = (PMDSPT_VolDataList *) 
                MEMSIP_alloc( (size_t) sizeof(PMDSPT_VolDataList) )) ==
       ((PMDSPT_VolDataList *) NULL) ) {
     ERRSIM_set_error( status_code, ERRSID_PMDS_err_mem_alloc,
        "vol" );
   }

/* ==========================================================================
   Initialize volume data
   ========================================================================== */
   memset(vol, '\0', sizeof(PMDSPT_VolDataList));

/* ==========================================================================
   Read data from tape
   ========================================================================== */
   for(ivol = 0; ivol < num_of_vol; ivol++)
   {
      PMDSIP_MDAN_ReadTape(input_media_path, vol, status_code);
      ERRSIM_on_err_goto_exit(*status_code);
   }

/* ==========================================================================
   Read product record and check ...
   ========================================================================== */
   status = PMDSIP_MDAN_ReadProductRecord (db_file_name_p, vol, 
               &db_vols, &count_db_vols );

   if(status == -1)
   {
      sprintf(msg, "Error reading <%s> DB file", db_file_name_p);
      ERRSIM_set_error(status_code, ERRSID_PMDS_error_reading_file, msg);
   }

/* ==========================================================================
   Write MCR file
   ========================================================================== */
   PMDSIP_MDAN_CreateMCR( db_vols, count_db_vols, vol, mcr_file_name_p, 
       status_code);
   ERRSIM_on_err_goto_exit(*status_code);

error_exit:;
/* ==========================================================================
   Freeze memory
   ========================================================================== */
   MEMSIP_free((void **) &db_vols );
   MEMSIP_free((void **) &vol );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSIP_MDAN_MediaAnalysis */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_ReadProductRecord

        $TYPE

        $INPUT        db_file_name_p : product(s) data base file name
                      vol_p          : volume data list

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

INTx4 PMDSIP_MDAN_ReadProductRecord
                        (/*IN    */ char                *db_file_name_p,
                         /*IN    */ PMDSPT_VolDataList  *vol_p,
                         /*   OUT*/ PMDSPT_VolDataList **db_vols_p,
                         /*   OUT*/ INTx4               *count_db_vols_p )
{
/* ==========================================================================
   Local variables
   ========================================================================== */
   PMDSPT_FileData            file_data; /* temporary file data structure */
   PMDSPT_RecordData          record_data; /* temporary record data structure */
   FILE                      *fp;  /* pointer to the db file */
   INTx4                      ichar; /* convenient loop variable */
   INTx4                      found; /* convenient loop variable */
   char                       line[256]; /* file line buffer */

/* ==========================================================================
   Open DB file
   ========================================================================== */
   if((fp = fopen(db_file_name_p, "r")) == NULL)
   {
      return(-1);
   }

/* ==========================================================================
   Loop onto records
   ========================================================================== */
   found = 0;
   *count_db_vols_p = 0;

   while((fgets(line, sizeof(line), fp)) != NULL)
   {
/* ==========================================================================
      Cut carriage return (if any)
   ========================================================================== */
      for(ichar = (strlen(line) - 1); ichar >= 0; ichar--)
      {
         if(line[ichar] == '\n')
         {
            line[ichar] = '\0';
            break;
         }
      }
/* ==========================================================================
      Check record starting
   ========================================================================== */
      if((strstr(line, "[")) && (strstr(line, "]")))
      {
/* ==========================================================================
         Compare previous record with data tape and if found return OK
   ========================================================================== */
         if(found == 1)
         {
            PMDSIP_MDAN_CompareProduct( &((*db_vols_p)[ *count_db_vols_p - 1]), 
               vol_p);
         }

/* ==========================================================================
         Increment *count_db_vols_p
   ========================================================================== */
         (*count_db_vols_p)++;

/* ==========================================================================
         Realloc db_vols_p structure
   ========================================================================== */
         if( (*db_vols_p = (PMDSPT_VolDataList *) 
                     MEMSIP_realloc( *db_vols_p, 
                        (*count_db_vols_p) * (size_t) sizeof(PMDSPT_VolDataList))
             ) ==
             ((PMDSPT_VolDataList *) NULL) ) {
            return( -1 );
         }

/* ==========================================================================
         Continue to reda record(s) from data base file
   ========================================================================== */
         memset( &((*db_vols_p)[(*count_db_vols_p) - 1]), '\0', 
            sizeof(PMDSPT_VolDataList));
         strncpy(((*db_vols_p)[(*count_db_vols_p) - 1]).product, 
            (line + 1), (strlen(line + 1) - 1));
         found = 1;

      }

/* ==========================================================================
      Set data just if product has been found
   ========================================================================== */
      if(found == 1)
      {
/* ==========================================================================
         Check the line label
   ========================================================================== */
         if((strncmp(line, "SENSOR:", strlen("SENSOR:"))) == 0)
         {
            if((sscanf(line + strlen("SENSOR:"), "%s", 
                   ((*db_vols_p)[(*count_db_vols_p) - 1]).sensor)) != 1)
            {
               fclose(fp);
               return(-1);
            }
         }
         else if((strncmp(line, "FORMAT:", strlen("FORMAT:"))) == 0)
         {
            if((sscanf(line + strlen("FORMAT:"), "%s", 
                   ((*db_vols_p)[(*count_db_vols_p) - 1]).format)) != 1)
            {
               fclose(fp);
               return(-1);
            }
         }
         else if((strncmp(line, "SOURCE:", strlen("SOURCE:"))) == 0)
         {
            if((sscanf(line + strlen("SOURCE:"), "%s", 
                   ((*db_vols_p)[(*count_db_vols_p) - 1]).source)) != 1)
            {
               fclose(fp);
               return(-1);
            }
         }
         else if((strncmp(line, "VOLUME:", strlen("VOLUME:"))) == 0)
         {
            if((PMDSIP_MDAN_AddVolume(NULL, 
                   &((*db_vols_p)[(*count_db_vols_p) - 1]))) != 1)
            {
               fclose(fp);
               return(-1);
            }
         }
         else if((strncmp(line, "FILE:", strlen("FILE:"))) == 0)
         {
            if((sscanf(line + strlen("FILE:"), "%d %s",
               &(file_data.fileNum), file_data.necessary)) == 2)
            {
               if((PMDSIP_MDAN_AddFile(&file_data,
                  &(((*db_vols_p)[(*count_db_vols_p) - 1]).list[((*db_vols_p)[(*count_db_vols_p) - 1]).num - 1].file))) != 1)
               {
                  fclose(fp);
                  return(-1);
               }
            }
         }
         else if((strncmp(line, "RECORD:", strlen("RECORD:"))) == 0)
         {
            if((sscanf(line + strlen("RECORD:"), "%d %d %s",
               &(record_data.recNum), &(record_data.size),
               record_data.necessary)) == 3)
            {
               if((PMDSIP_MDAN_AddRecord(&record_data,
                  &(((*db_vols_p)[(*count_db_vols_p) - 1]).list[((*db_vols_p)[(*count_db_vols_p) - 1]).num - 1].file.
                  list[((*db_vols_p)[(*count_db_vols_p) - 1]).list[((*db_vols_p)[(*count_db_vols_p) - 1]).num - 1].file.num - 1].
                  rec))) != 1)
               {
                  fclose(fp);
                  return(-1);
               }
            }
         }
      }
   }
/* ==========================================================================
   Close DB file
   ========================================================================== */
   fclose(fp);

/* ==========================================================================
   Compare last record with data tape and if found return OK
   ========================================================================== */
   if(found == 1)
   {
      PMDSIP_MDAN_CompareProduct( &((*db_vols_p)[ *count_db_vols_p - 1]), 
         vol_p);
   }

/* ==========================================================================
   Return
   ========================================================================== */
   return(0);

}/* PMDSIP_MDAN_ReadProductRecord */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_ReadTape

        $TYPE

        $INPUT        input_media_path : source product media


        $MODIFIED     NONE

        $OUTPUT       vol_p            : list of volume data found into the tape

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_MDAN_ReadTape
                        (/*IN    */ char                *input_media_path,
                         /*   OUT*/ PMDSPT_VolDataList  *vol_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_MDAN_ReadTape";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   INTx4           tape_fd;         /* tape file pointer */
   char            *buf = NULL;     /* input/output buffer */
   INTx4           file_number;     /* number of read files */
   INTx4           transfer_size;   /* block size used for i/o */
   INTx4           record_length;   /* number of bytes actually read */
   INTx4           old_record_length; /* number of bytes read in previous rec.*/
   INTx4           file_begin;      /* new file flag */
   INTx4           done;            /* loop on records flag */
   INTx4           type_number;     /* record index in loop */
   INTx4           rec_number;      /* record index in loop */
   INTx4           rec_length;      /* record index in loop */
   INTx4           key_press;
   PMDSPT_FileData file_data;       /* temporary file data structure */
   PMDSPT_RecordData record_data;   /* temporary record data structure */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
      Wait for the user's ok
   ========================================================================== */
   fprintf(stdout,
            "Insert volume on %s\nPress <Enter> to continue ...\n",
            input_media_path);

   fflush( stdin );
   key_press = 0;
   while(key_press == 0)
   {
      key_press = getchar();
   }

/* ==========================================================================
   Open tape descriptor
   ========================================================================== */
   DEVSIP_open_read(  input_media_path,
                     &tape_fd,
                      status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Mount the tape
   ========================================================================== */
   DEVSIP_mount( input_media_path,
                 tape_fd,
                 status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set transfer size
   ========================================================================== */
   transfer_size = DEVSID_max_read_size;
   buf = (char *) MEMSIP_alloc((size_t)(transfer_size * sizeof(char)));
   if(buf == (char *) NULL)
   {
      ERRSIM_set_error(status_code,
                       ERRSID_PMDS_alloc_memory,
                       "Cannot read data from tape !");
   }

/* ==========================================================================
   Add a new volume to the tape data in memory
   ========================================================================== */
   if((PMDSIP_MDAN_AddVolume(NULL, vol_p)) != 1)
   {
      DEVSIP_dismount( input_media_path,
                       tape_fd,
                       status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      DEVSIP_close( &tape_fd,
                     status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Loop on records
   ========================================================================== */
   file_number = 0;
   file_begin  = 1;
   done        = 0;
   while(!done)
   {

      SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

/* ==========================================================================
   Read a record
   ========================================================================== */
      record_length = DEVSIF_read( tape_fd, 
                                   transfer_size,
                                   (void *) buf,
                                  &log_status_code );
/* ==========================================================================
   Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if( record_length < 0)
      {
         done = 1;
         continue;
      }

/* ==========================================================================
      Case of end of file
   ========================================================================== */
      if(record_length == 0)
      {
/* ==========================================================================
         Case of end of tape
   ========================================================================== */
         if(file_begin)
         {
            done = 1;
         }
         else
         {
/* ==========================================================================
            Print statistics about last record type
   ========================================================================== */
            fprintf(stderr,"rec_number = %5d", rec_number);
            fprintf(stderr,"\t\trec_length = %5d\n", rec_length);

            record_data.recNum = rec_number;
            record_data.size   = rec_length;
            strcpy(record_data.necessary, "Y");
            if((PMDSIP_MDAN_AddRecord(&record_data,
               &(vol_p->list[vol_p->num - 1].file.
               list[vol_p->list[vol_p->num - 1].file.num - 1].rec))) != 1)
            {
               DEVSIP_dismount( input_media_path,
                                tape_fd,
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );

               DEVSIP_close( &tape_fd,
                              status_code );
               ERRSIM_on_err_goto_exit( *status_code );
            }
/* ==========================================================================
            End of current file
   ========================================================================== */
            file_begin = 1;
         }
      }
      else
      {
/* ==========================================================================
         Case of new file
   ========================================================================== */
         if(file_begin)
         {
            file_number = file_number + 1;
            file_begin  = 0;

            fprintf(stderr, "\nFILE %d : \n", file_number);

/* ==========================================================================
            Add a new file into the list
   ========================================================================== */
            file_data.fileNum = file_number;
            strcpy(file_data.necessary, "Y");
            if((PMDSIP_MDAN_AddFile(&file_data,
               &(vol_p->list[vol_p->num - 1].file))) != 1)
            {
               DEVSIP_dismount( input_media_path,
                                tape_fd,
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );

               DEVSIP_close( &tape_fd,
                              status_code );
               ERRSIM_on_err_goto_exit( *status_code );
            }
/* ==========================================================================
            Reset type number
   ========================================================================== */
            type_number       = 0;
            old_record_length = -1;
         }
/* ==========================================================================
         Analyse record length continuity
   ========================================================================== */
         if(record_length != old_record_length)
         {
/* ==========================================================================
            Print statistics about last record type
   ========================================================================== */
            if(type_number > 0)
            {

               fprintf(stderr,"rec_number = %5d", rec_number);
               fprintf(stderr,"\t\trec_length = %5d\n", rec_length);

/* ==========================================================================
               Add a new record into the list
   ========================================================================== */
               record_data.recNum = rec_number;
               record_data.size   = rec_length;
               strcpy(record_data.necessary, "Y");
               if((PMDSIP_MDAN_AddRecord(&record_data,
                  &(vol_p->list[vol_p->num - 1].file.
                  list[vol_p->list[vol_p->num - 1].file.num - 1].rec))) != 1)
               {
                  DEVSIP_dismount( input_media_path,
                                   tape_fd,
                                   status_code );
                  ERRSIM_on_err_goto_exit( *status_code );

                  DEVSIP_close( &tape_fd,
                                 status_code );
                  ERRSIM_on_err_goto_exit( *status_code );
               }
            }
/* ==========================================================================
            Update statistics
   ========================================================================== */
            type_number++;
            rec_number        = 1;
            rec_length        = record_length;
            old_record_length = record_length;
         }
         else
         {
            rec_number++;
         }
      }  /* record length == 0 */
   }  /* read records */

/* ==========================================================================
   Close tape
   ========================================================================== */
   DEVSIP_dismount( input_media_path,
                    tape_fd,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   DEVSIP_close( &tape_fd,
                  status_code );
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   MEMSIP_free((void **) &buf);

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSIP_MDAN_ReadTape */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_AddRecord

        $TYPE

        $INPUT        record_data : record data found reading tape


        $MODIFIED     NONE

        $OUTPUT       rec_p       : record data list

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

INTx4 PMDSIP_MDAN_AddRecord
                        (/*IN    */ PMDSPT_RecordData     *record_data,
                         /*   OUT*/ PMDSPT_RecordDataList *rec_p)
{

/* ==========================================================================
   Add one more item to the list counter
   ========================================================================== */
   rec_p->num++;
   if((rec_p->num <= 0) || (rec_p->num > PMDSPD_max_rec_num))
      return(-1);

   rec_p->list[rec_p->num - 1].recNum = record_data->recNum;
   rec_p->list[rec_p->num - 1].size   = record_data->size;
   strcpy(rec_p->list[rec_p->num - 1].necessary, record_data->necessary);

/* ==========================================================================
   Return
   ========================================================================== */
   return(1);

}/* PMDSIP_MDAN_AddRecord */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_AddFile

        $TYPE

        $INPUT        file_data : file data found reading tape


        $MODIFIED     NONE

        $OUTPUT       file_p    : file data list

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

INTx4 PMDSIP_MDAN_AddFile
                        (/*IN    */ PMDSPT_FileData     *file_data,
                         /*   OUT*/ PMDSPT_FileDataList *file_p)
{

/* ==========================================================================
   Add one more item to the list counter
   ========================================================================== */
   file_p->num++;
   if((file_p->num <= 0) || (file_p->num > PMDSPD_max_file_num))
      return(-1);

   file_p->list[file_p->num - 1].fileNum = file_data->fileNum;
   file_p->list[file_p->num - 1].size    = file_data->size;
   strcpy(file_p->list[file_p->num - 1].necessary, file_data->necessary);
   file_p->list[file_p->num - 1].rec.num = 0;

/* ==========================================================================
   Return
   ========================================================================== */
   return(1);

}/* PMDSIP_MDAN_AddFile */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_AddVolume

        $TYPE

        $INPUT        vol_data : volume data found reading tape


        $MODIFIED     NONE

        $OUTPUT       vol_p    : volume data list

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

INTx4 PMDSIP_MDAN_AddVolume
                        (/*IN    */ PMDSPT_VolData      *vol_data,
                         /*   OUT*/ PMDSPT_VolDataList  *vol_p)
{

/* ==========================================================================
   Add one more item to the list counter
   ========================================================================== */
   vol_p->num++;
   if((vol_p->num <= 0) && (vol_p->num > PMDSPD_max_vol_num))
      return(-1);

   vol_p->list[vol_p->num - 1].volNum = vol_p->num;
   memset(vol_p->list[vol_p->num - 1].cfgName, '\0',
      sizeof(vol_p->list[vol_p->num - 1].cfgName));
   vol_p->list[vol_p->num - 1].file.num = 0;

/* ==========================================================================
   Return
   ========================================================================== */
   return(1);

}/* PMDSIP_MDAN_AddVolume */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_CompareProduct

        $TYPE

        $INPUT        db_record : product(s) data base record
                      vol_p     : volume data list


        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_MDAN_CompareProduct
                        (/*IN    */ PMDSPT_VolDataList  *db_record,
                         /*IN    */ PMDSPT_VolDataList  *vol_p)
{
/* ==========================================================================
   Local variables
   ========================================================================== */
   INTx4            ivol;               /* convenient loop variable */
   INTx4            ifile;              /* convenient loop variable */
   INTx4            irec;               /* convenient loop variable */

#ifdef __TRACE__
   fprintf( stderr, "%s %s\n", db_record->product, db_record->source );
#endif

/* ==========================================================================
   Check (same number of volume(s))
   ========================================================================== */
   if(db_record->num != vol_p->num)
   {
      db_record->score = -1.0;
      return;
   }

/* ==========================================================================
   Compute score
   ========================================================================== */
   for(ivol = 0, db_record->score = 0.0; ivol < db_record->num; ivol++) {

      for(ifile = 0; 
          ifile < MAX(db_record->list[ivol].file.num, 
                      vol_p->list[ivol].file.num); 
          ifile++) {

         for(irec = 0;
             irec < MAX(db_record->list[ivol].file.list[ifile].rec.num,
                        vol_p->list[ivol].file.list[ifile].rec.num);
             irec++) {

            if( db_record->list[ivol].file.list[ifile].rec.list[irec].recNum >
                1000 ) {
               if( db_record->score > 0 ) {
                  db_record->score = -1.0;
                  break;
               }
            }

            db_record->score += (float) 
               POW((
               (db_record->list[ivol].file.list[ifile].rec.list[irec].recNum * 
                db_record->list[ivol].file.list[ifile].rec.list[irec].size) -
               (vol_p->list[ivol].file.list[ifile].rec.list[irec].recNum *
                vol_p->list[ivol].file.list[ifile].rec.list[irec].size)),
                   2.0);

#ifdef __TRACE__
            fprintf( stderr, "ivol=%0d ifile=%0d irec=%0d score=%f\n", 
               ivol, ifile, irec, db_record->score );
#endif

         }
         if( db_record->score == -1.0 ) {
            break;
         }

      }
      if( db_record->score == -1.0 ) {
         break;
      }

   }

#ifdef __OLD__
/* ==========================================================================
   Loop onto the volume number
   ========================================================================== */
   for(ivol = 0; ivol < db_record->num; ivol++)
   {
/* ==========================================================================
      Check (same number of file(s))
   ========================================================================== */
      if(db_record->list[ivol].file.num != vol_p->list[ivol].file.num)
      {
         db_record->score = -1.0;
         return;
      }
/* ==========================================================================
      Loop onto the file number
   ========================================================================== */
      for(ifile = 0; ifile < db_record->list[ivol].file.num; ifile++)
      {
/* ==========================================================================
         Check (same number of record(s))
   ========================================================================== */
         if(db_record->list[ivol].file.list[ifile].rec.num !=
            vol_p->list[ivol].file.list[ifile].rec.num)
         {
            db_record->score = -1.0;
            return;
         }
/* ==========================================================================
         Loop onto the record number
   ========================================================================== */
         for(irec = 0;
            irec < db_record->list[ivol].file.list[ifile].rec.num; irec++)
         {
/* ==========================================================================
            Check (same record size for each one)
   ========================================================================== */
            if(ifile == 2)
            {
               if((db_record->list[ivol].file.list[ifile].rec.list[irec].size <
                  (vol_p->list[ivol].file.list[ifile].rec.list[irec].size - 200)) ||
                  (db_record->list[ivol].file.list[ifile].rec.list[irec].size >
                  (vol_p->list[ivol].file.list[ifile].rec.list[irec].
                     size + 200)))
               {
                  db_record->score = -1.0;
                  return;
               }
            }
            else
            {
               if(db_record->list[ivol].file.list[ifile].rec.list[irec].size !=
                  vol_p->list[ivol].file.list[ifile].rec.list[irec].size)
               {
                  db_record->score = -1.0;
                  return;
               }
            }
/* ==========================================================================
            Check (same record number for each type)
   ========================================================================== */
            if(ifile == 2)
            {
               if((db_record->list[ivol].file.list[ifile].rec.list[irec].
                     recNum <
                  (vol_p->list[ivol].file.list[ifile].rec.list[irec].
                     recNum - 200))                                           ||
                  (db_record->list[ivol].file.list[ifile].rec.list[irec].
                     recNum >
                  (vol_p->list[ivol].file.list[ifile].rec.list[irec].
                     recNum + 200)))
               {
                  db_record->score = -1.0;
                  return;
               }
            }
            else
            {
               if(db_record->list[ivol].file.list[ifile].rec.list[irec].recNum
                  != vol_p->list[ivol].file.list[ifile].rec.list[irec].recNum)
               {
                  db_record->score = -1.0;
                  return;
               }
            }
         }
      }
   }

/* ==========================================================================
   If code has arrived here maybe there is full compatibility betweew data
   strcpy(vol_p->product, db_record->product);
   strcpy(vol_p->sensor, db_record->sensor);
   strcpy(vol_p->format, db_record->format);
   strcpy(vol_p->source, db_record->source);
   ========================================================================== */

/* ==========================================================================
   Set ok
   ========================================================================== */
   db_record->score = 1.0;
#endif

}/* PMDSIP_MDAN_CompareProduct */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_CreateMCR

        $TYPE

        $INPUT        vol_p           : volume data list


        $MODIFIED     NONE

        $OUTPUT       mcr_file_name_p : media content report file name

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_MDAN_CreateMCR
                        (/*IN    */ PMDSPT_VolDataList  *db_vols_p,
                         /*IN    */ INTx4                count_db_vols,
                         /*IN    */ PMDSPT_VolDataList  *vol_p,
                         /*   OUT*/ char                *mcr_file_name_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_MDAN_CreateMCR";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   FILE             *fp;                /* pointer to the db file */
   INTx4            ichar;              /* convenient loop variable */
   INTx4            best[ PMDSLD_MDAN_max_best ];
   double           best_score[ PMDSLD_MDAN_max_best ];
                                        /* best vector index */
   INTx4            ibest;              /* convenient loop variable */
   INTx4            ibestmax;           /* convenient loop variable */
   INTx4            itemp;              /* convenient loop variable */
   INTx4            idbvol;             /* convenient loop variable */
   INTx4            ivol;               /* convenient loop variable */
   INTx4            ifile;              /* convenient loop variable */
   INTx4            irec;               /* convenient loop variable */
   LDEFIT_boolean   ifound;             /* convenient boolean variable */
   INTx4            product_type;       /* product type id */
   char             product_type_str[256]; /* product type name */
   INTx4            status = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

#ifdef __TRACE__
/* ==========================================================================
   Trace
   ========================================================================== */
   fprintf( stderr, "\n");
   for( idbvol=0; idbvol<count_db_vols; idbvol++ ) {
      fprintf( stderr, "score[%0d]=%f\n", idbvol, db_vols_p[ idbvol ].score);
   }
#endif

/* ==========================================================================
   Open MCR file
   ========================================================================== */
   if((fp = fopen(mcr_file_name_p, "w")) == NULL)
   {
      ERRSIM_set_error(status_code, ERRSID_PMDS_error_create_file, "");
   }

/* ==========================================================================
   Write on MCR file
   ========================================================================== */
   fprintf(fp, "-----------------------------------------------------------\n");

/* ==========================================================================
   Loop on db results
   ========================================================================== */
   for( ibestmax=0, idbvol=0; idbvol<count_db_vols; idbvol++ ) {
      if( db_vols_p[ idbvol ].score != -1.0 ) {
         ibestmax++;
      }
   }
   for( ibest=0; ibest<MIN(PMDSLD_MDAN_max_best, ibestmax); ibest++ ) {
      for( idbvol=0, 
           best_score[ ibest ] = PMDSLD_MDAN_max_best_score;
           idbvol<count_db_vols;
           idbvol++ ) {
         for( ifound = FALSE, itemp=0; itemp<ibest; itemp++ ) {
            if( idbvol == best[ itemp ] ) {
               ifound = TRUE;
               break;
            }
         }
         if( !ifound && (db_vols_p[ idbvol ].score != -1.0) ) {
            status = 1;
            if( db_vols_p[ idbvol ].score < best_score[ ibest ] ) {
               best_score[ ibest ] = db_vols_p[ idbvol ].score;
               best[ ibest ] = idbvol;
            }
         }
      }
#ifdef __TRACE__
      fprintf( stderr, "%d %d\n", ibest, best[ ibest ] );
#endif
   }

#ifdef __TRACE__
   for( ibest=0; ibest<MIN(PMDSLD_MDAN_max_best, ibestmax); ibest++ ) {
      fprintf( stderr, "%d %f\n", best[ ibest ], best_score[ ibest ] );
   }
#endif

   if( status == 0 )
   {
      fprintf(fp, "FORMAT DATA NOT RECOGNIZED !\n");
      fprintf(fp, "-----------------------------------------------------------\n");
   }
   else {
      for( ibest=0; ibest<MIN(PMDSLD_MDAN_max_best, ibestmax); ibest++ ) {
      
#ifdef __TRACE__
         fprintf( stderr, "%0d\n", best[ ibest ] );
#endif

/* ==========================================================================
         Get the right product type
   ========================================================================== */
         strcpy(product_type_str, db_vols_p[ best[ ibest ] ].product);

         for(ichar = 0; ichar < strlen(db_vols_p[ best[ ibest ] ].product); 
             ichar++)
            product_type_str[ichar] = toupper(db_vols_p[ best[ ibest ] ].product[ichar]);

         if((strcmp(product_type_str, "RAW")) == 0)
	    product_type = (INTx4)PMDSIE_raw_prod;
	 else if((strcmp(product_type_str, "SLC")) == 0)
	    product_type = (INTx4)PMDSIE_slc_prod;
	 else if((strcmp(product_type_str, "SLI")) == 0)
	    product_type = (INTx4)PMDSIE_slci_prod;
	 else if((strcmp(product_type_str, "PRI")) == 0)
	    product_type = (INTx4)PMDSIE_pri_prod;
	 else if((strcmp(product_type_str, "GEC")) == 0)
	    product_type = (INTx4)PMDSIE_gec_prod;
	 else if((strcmp(product_type_str, "GTC")) == 0)
	    product_type = (INTx4)PMDSIE_gtc_prod;
	 else
	    product_type = -1;

/* ==========================================================================
      Write data onto the MCR file
   ========================================================================== */
#ifdef __TRACE__
	 fprintf(fp, "Score               = %f\n",
            best_score[ ibest ] );
#endif
	 fprintf(fp, "Number of Volume(s) = %d\n",
            db_vols_p[ best[ ibest ] ].num);
	 fprintf(fp, "Product Type        = %s\n",  
            db_vols_p[ best[ ibest ] ].product);
	 fprintf(fp, "Sensor Id           = %s\n",
            db_vols_p[ best[ ibest ] ].sensor);
	 fprintf(fp, "Data Format         = %s\n",
            db_vols_p[ best[ ibest ] ].format);
	 fprintf(fp, "Source Id           = %s\n",
            db_vols_p[ best[ ibest ] ].source);
         fprintf(fp, 
            "-----------------------------------------------------------\n");
      }
   }

/* ==========================================================================
   Write to MCR
   ========================================================================== */
   fprintf(fp, "Number of Volume(s) = %d\n", vol_p->num);
   fprintf(fp, "-----------------------------------------------------------\n");

/* ==========================================================================
   Loop onto the volume number
   ========================================================================== */
   for(ivol = 0; ivol < vol_p->num; ivol++)
   {
      fprintf(fp, "VOLUME: %d\n", (ivol + 1));
/* ==========================================================================
      Loop onto the file number
   ========================================================================== */
      for(ifile = 0; ifile < vol_p->list[ivol].file.num; ifile++)
      {
         fprintf(fp, "\n");
         fprintf(fp, "FILE: %-2d  Number of Record(s)    Record Size\n",
            (ifile + 1));
/* ==========================================================================
         Loop onto the record number
   ========================================================================== */
         for(irec = 0;
            irec < vol_p->list[ivol].file.list[ifile].rec.num; irec++)
         {
            fprintf(fp, "RECORD:    %18d   %12d\n",
               vol_p->list[ivol].file.list[ifile].rec.list[irec].recNum,
               vol_p->list[ivol].file.list[ifile].rec.list[irec].size);
         }
      }
   fprintf(fp, "-----------------------------------------------------------\n");
   }

/* ==========================================================================
   Close MCR file
   ========================================================================== */
   fclose(fp);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSIP_MDAN_CreateMCR */
