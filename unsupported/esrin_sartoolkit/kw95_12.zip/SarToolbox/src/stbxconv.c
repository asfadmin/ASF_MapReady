/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_CONV

      $FUNCTION          This module contains the task procedure for
			             the Sar Toolbox CONVERSION TOOL

      $ROUTINE           STBXPP_CONV_amp2pow
                         STBXPP_CONV_pow2amp
                         STBXPP_CONV_complex2amp
                         STBXPP_CONV_gaincvs 
                         STBXPP_CONV_int2float
                         STBXPP_CONV_tiffgen
                         STBXPP_CONV_bilgen
                         STBXPP_CONV_ancdata
                         STBXPP_CONV_dumpannot
                         STBXPP_CONV_impraster
                         STBXPP_CONV_lin2db

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       21-OCT-97     RZ       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <stdlib.h>
#ifdef __UNIX__
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#endif

#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include IANN_INTF_H
#include COOR_INTF_H
#include CONV_INTF_H
#include STBX_INTF_H
#include STBX_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_amp2pow

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the AMPLITUDE TO POWER conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_amp2pow routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_CONV_amp2pow
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CONV_amp2pow";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImage, outImage;
   FILSIT_file_name        inImageName, outImageName;
   LDEFIT_boolean          real_aoi;

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io, out_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   LDEFIT_boolean          out_open = FALSE;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            out_ima_num = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy( task.parm[ 0 ].name, STBXPD_input_image );
   task.parm[ 0 ].type = FIISIE_tt_string;
   task.parm[ 0 ].size = sizeof( FILSIT_file_name );
   task.parm[ 0 ].mandatory = TRUE;
   task.parm[ 0 ].vector = FALSE;
   task.parm[ 0 ].value = (void *) inImageName;

   strcpy( task.parm[ 1 ].name, STBXPD_output_image );
   task.parm[ 1 ].type = FIISIE_tt_string;
   task.parm[ 1 ].size = sizeof( FILSIT_file_name );
   task.parm[ 1 ].mandatory = TRUE;
   task.parm[ 1 ].vector = FALSE;
   task.parm[ 1 ].value = (void *) outImageName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   printf( "%s : %s\n", STBXPD_input_image, inImageName);
   printf( "%s : %s\n", STBXPD_output_image, outImageName);
#endif

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input and output image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_float,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_CONV_AMPW, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute nrow_inp/ncol_inp and nrow_out/ncol_out of source image
   ========================================================================== */
   nrow_out = nrow_inp = BRRow - TLRow + 1;
   ncol_out = ncol_inp = BRCol - TLCol + 1;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_amp2pow( &inp_io,
                    inp_ima_num,
                    TLRow,
                    TLCol,
                    nrow_inp,
                    ncol_inp,
                   &out_io,
                    out_ima_num,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set pixel type
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].PixelType = IANNIE_pixt_power;

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND(TLRow / 
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND(TLCol/ 
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
				  task.name, 
                                  "",
			          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CONV_amp2pow */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_pow2amp

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the POWER TO AMPLITUDE conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_pow2amp routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_CONV_pow2amp
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CONV_pow2amp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImage, outImage;
   FILSIT_file_name        inImageName, outImageName;
   LDEFIT_boolean          real_aoi;

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io, out_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   LDEFIT_boolean          out_open = FALSE;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            out_ima_num = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy( task.parm[ 0 ].name, STBXPD_input_image );
   task.parm[ 0 ].type = FIISIE_tt_string;
   task.parm[ 0 ].size = sizeof( FILSIT_file_name );
   task.parm[ 0 ].mandatory = TRUE;
   task.parm[ 0 ].vector = FALSE;
   task.parm[ 0 ].value = (void *) inImageName;

   strcpy( task.parm[ 1 ].name, STBXPD_output_image );
   task.parm[ 1 ].type = FIISIE_tt_string;
   task.parm[ 1 ].size = sizeof( FILSIT_file_name );
   task.parm[ 1 ].mandatory = TRUE;
   task.parm[ 1 ].vector = FALSE;
   task.parm[ 1 ].value = (void *) outImageName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   printf( "%s : %s\n", STBXPD_input_image, inImageName);
   printf( "%s : %s\n", STBXPD_output_image, outImageName);
#endif

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input and output image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_float,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   If the image has more than 1 sampleperpixel exit
   ========================================================================== */
   if( inp_io.spp>1 ) {
      ERRSIM_set_error( status_code,
		        ERRSID_STBX_inv_prod_type,
			"complex image" );
   }

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_CONV_PWAM, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute nrow_inp/ncol_inp and nrow_out/ncol_out of source image
   ========================================================================== */
   nrow_out = nrow_inp = BRRow - TLRow + 1;
   ncol_out = ncol_inp = BRCol - TLCol + 1;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_pow2amp( &inp_io,
                    inp_ima_num,
                    TLRow,
                    TLCol,
                    nrow_inp,
                    ncol_inp,
                   &out_io,
                    out_ima_num,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set pixel type
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].PixelType = IANNIE_pixt_amplitude;

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND(TLRow/ 
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND(TLCol/ 
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
				  task.name, 
                                  "",
			          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CONV_pow2amp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_complex2amp

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the COMPEX TO AMPLITUDE conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_complex2amp routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_CONV_complex2amp
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CONV_complex2amp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImage, outImage;
   FILSIT_file_name        inImageName, outImageName;
   LDEFIT_boolean          real_aoi;

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io, out_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   LDEFIT_boolean          out_open = FALSE;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            out_ima_num = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy( task.parm[ 0 ].name, STBXPD_input_image );
   task.parm[ 0 ].type = FIISIE_tt_string;
   task.parm[ 0 ].size = sizeof( FILSIT_file_name );
   task.parm[ 0 ].mandatory = TRUE;
   task.parm[ 0 ].vector = FALSE;
   task.parm[ 0 ].value = (void *) inImageName;

   strcpy( task.parm[ 1 ].name, STBXPD_output_image );
   task.parm[ 1 ].type = FIISIE_tt_string;
   task.parm[ 1 ].size = sizeof( FILSIT_file_name );
   task.parm[ 1 ].mandatory = TRUE;
   task.parm[ 1 ].vector = FALSE;
   task.parm[ 1 ].value = (void *) outImageName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   printf( "%s : %s\n", STBXPD_input_image, inImageName);
   printf( "%s : %s\n", STBXPD_output_image, outImageName);
#endif

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input and output image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_float,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   If the image has not 2 sampleperpixel exit
   ========================================================================== */
   if( inp_io.spp != 2 ) {
      ERRSIM_set_error( status_code,
		        ERRSID_STBX_inv_prod_type,
			"should be a complex image" );
   }

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_CONV_CAMP, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute nrow_inp/ncol_inp and nrow_out/ncol_out of source image
   ========================================================================== */
   nrow_out = nrow_inp = BRRow - TLRow + 1;
   ncol_out = ncol_inp = BRCol - TLCol + 1;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_complex2amp( &inp_io,
                        inp_ima_num,
                        TLRow,
                        TLCol,
                        nrow_inp,
                        ncol_inp,
                       &out_io,
                        out_ima_num,
                        status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set pixel type
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].PixelType = IANNIE_pixt_amplitude;

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND(TLRow/ 
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND(TLCol/ 
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
				  task.name, 
                                  "",
			          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CONV_complex2amp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_gaincvs

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the GAIN conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_gaincvs routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_CONV_gaincvs
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CONV_gaincvs";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j, ipar;
   INTx4                   userLutParNo, maxPercParNo, minPercParNo,
                           noBlackParNo, scaleFactParNo;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImage, outImage, userLut;
   FILSIT_file_name        inImageName, outImageName;
   LDEFIT_boolean          real_aoi, noBlackFound, prop1, prop2, prop3;
   float                   minPerc, maxPerc, noBlack;
   float                   scaleFact;
   char                    err_msg[ 256 ];

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io, out_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   LDEFIT_boolean          out_open = FALSE;
   STBXPT_gaincvs_type     convType;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            out_ima_num = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 7 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) outImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_user_lut );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) userLut;
   userLutParNo = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_min_perc );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &minPerc;
   minPercParNo = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_max_perc );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &maxPerc;
   maxPercParNo = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_no_black );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &noBlack;
   noBlackParNo = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_scale_factor );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &scaleFact;
   scaleFactParNo = ipar;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check input parameters
   ========================================================================== */
   prop1 = task.parm[ userLutParNo ].founded;
   prop2 = ( ( (task.parm[ minPercParNo ].founded == TRUE) &&
               (task.parm[ maxPercParNo ].founded == TRUE) ) ? TRUE : FALSE );
   prop3 = task.parm[ scaleFactParNo ].founded;

   if ( (prop1 == FALSE) && (prop2 == FALSE) && (prop3 == FALSE) ) {
      sprintf( err_msg, "%s or %s and %s or %s", 
         STBXPD_user_lut,
         STBXPD_min_perc, STBXPD_max_perc, 
         STBXPD_scale_factor );
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_defined, err_msg );
   }

   convType = STBXPE_gaincvs_none;
   if( (prop1 == TRUE) && (prop2 == FALSE) && (prop3 == FALSE) ) {
      convType = STBXPE_gaincvs_lut;
   }
   else if( (prop2 == TRUE) && (prop1 == FALSE) && (prop3 == FALSE) ) {
      if( (minPerc < 0) || (minPerc > 100.0) ) {
         sprintf( err_msg, "%s should be between 0 and 100.0", STBXPD_min_perc);
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, err_msg );
      }
      if( (maxPerc < 0) || (maxPerc > 100.0) ) {
         sprintf( err_msg, "%s should be between 0 and 100.0", STBXPD_max_perc);
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, err_msg );
      }
      if( minPerc >= maxPerc ) {
         sprintf( err_msg, "%s should be less than %s", STBXPD_min_perc,
            STBXPD_max_perc );
      }
      noBlackFound = task.parm[ noBlackParNo ].founded;
      convType = STBXPE_gaincvs_std;
   }
   else if( (prop3 == TRUE) && (prop1 == FALSE) && (prop2 == FALSE) ) {
      if( scaleFact == 0.0 ) {
         sprintf( err_msg, "%s should not be 0.0", STBXPD_scale_factor );
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, err_msg );
      }
      convType = STBXPE_gaincvs_scf;
   }
   else {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, 
         "Unable to start convertion" );
   }


/* ==========================================================================
   Build full name of input and output image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_UINTx1,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   If the image has more than 1 sampleperpixel exit
   ========================================================================== */
   if( inp_io.spp>1 ) {
      ERRSIM_set_error( status_code,
		        ERRSID_STBX_inv_prod_type,
			"complex image" );
   }

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_CONV_GCVS, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute nrow_inp/ncol_inp and nrow_out/ncol_out of source image
   ========================================================================== */
   nrow_out = nrow_inp = BRRow - TLRow + 1;
   ncol_out = ncol_inp = BRCol - TLCol + 1;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(UINTx1)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_uintdata;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   switch( convType ) {
      case STBXPE_gaincvs_std:
         CONVIP_gaincvs( &inp_io,
                          inp_ima_num,
                          TLRow,
                          TLCol,
                          nrow_inp,
                          ncol_inp,
                          minPerc,
                          maxPerc,
                          noBlackFound,
                          noBlack,
                         &out_io,
                          out_ima_num,
                          status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case STBXPE_gaincvs_lut:
         CONVIP_ugaincvs( &inp_io,
                          inp_ima_num,
                          TLRow,
                          TLCol,
                          nrow_inp,
                          ncol_inp,
                          userLut,
                         &out_io,
                          out_ima_num,
                          status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;

      case STBXPE_gaincvs_scf:
         CONVIP_sgaincvs( &inp_io,
                          inp_ima_num,
                          TLRow,
                          TLCol,
                          nrow_inp,
                          ncol_inp,
                          scaleFact,
                         &out_io,
                          out_ima_num,
                          status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         break;
   }

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set pixel type
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].PixelType = IANNIE_pixt_amplitude;

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND(TLRow/ 
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND(TLCol/ 
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
				  task.name, 
                                  "",
			          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CONV_gaincvs */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_int2float

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the INTEGER TO FLOAT conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_int2float routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_CONV_int2float
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CONV_int2float";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImage, outImage;
   FILSIT_file_name        inImageName, outImageName;
   LDEFIT_boolean          real_aoi;

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io, out_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   LDEFIT_boolean          out_open = FALSE;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            out_ima_num = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy( task.parm[ 0 ].name, STBXPD_input_image );
   task.parm[ 0 ].type = FIISIE_tt_string;
   task.parm[ 0 ].size = sizeof( FILSIT_file_name );
   task.parm[ 0 ].mandatory = TRUE;
   task.parm[ 0 ].vector = FALSE;
   task.parm[ 0 ].value = (void *) inImageName;

   strcpy( task.parm[ 1 ].name, STBXPD_output_image );
   task.parm[ 1 ].type = FIISIE_tt_string;
   task.parm[ 1 ].size = sizeof( FILSIT_file_name );
   task.parm[ 1 ].mandatory = TRUE;
   task.parm[ 1 ].vector = FALSE;
   task.parm[ 1 ].value = (void *) outImageName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   printf( "%s : %s\n", STBXPD_input_image, inImageName);
   printf( "%s : %s\n", STBXPD_output_image, outImageName);
#endif

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input and output image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_float,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_CONV_PFLT, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute nrow_inp/ncol_inp and nrow_out/ncol_out of source image
   ========================================================================== */
   nrow_out = nrow_inp = BRRow - TLRow + 1;
   ncol_out = ncol_inp = BRCol - TLCol + 1;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = inp_io.val.tif.bpar.sampleperpixel;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_int2float( &inp_io,
                      inp_ima_num,
                      TLRow,
                      TLCol,
                      nrow_inp,
                      ncol_inp,
                     &out_io,
                      out_ima_num,
                      status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set pixel type
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].PixelType = IANNIE_pixt_amplitude;

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND(TLRow/ 
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND(TLCol/ 
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
				  task.name, 
                                  "",
			          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CONV_int2float */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_bilgen

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the BIL generation conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_bilgen routine
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_CONV_bilgen
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CONV_bilgen";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImages[ STBXPD_num_bgen_img ], outImage;
   FILSIT_file_name        inImagesName[ STBXPD_num_bgen_img ], outImageName,
                           outImageErm;
   LDEFIT_boolean          real_aoi;

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io[ STBXPD_num_bgen_img ], out_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx1                  inImagesNo;
   LDEFIT_boolean          out_open = FALSE;
   char                    err_msg[ 256 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy( task.parm[ 0 ].name, STBXPD_input_images );
   task.parm[ 0 ].type = FIISIE_tt_string;
   task.parm[ 0 ].size = sizeof( FILSIT_file_name );
   task.parm[ 0 ].mandatory = TRUE;
   task.parm[ 0 ].vector = TRUE;
   task.parm[ 0 ].max_number = STBXPD_num_bgen_img;
   task.parm[ 0 ].value = (void *) inImagesName;

   strcpy( task.parm[ 1 ].name, STBXPD_output_image );
   task.parm[ 1 ].type = FIISIE_tt_string;
   task.parm[ 1 ].size = sizeof( FILSIT_file_name );
   task.parm[ 1 ].mandatory = TRUE;
   task.parm[ 1 ].vector = FALSE;
   task.parm[ 1 ].value = (void *) outImageName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check parameter
   ========================================================================== */
   if( (task.parm[ 0 ].number < 1) ||
       (task.parm[ 0 ].number > STBXPD_num_bgen_img) ) {
      ERRSIM_set_error( status_code,
			ERRSID_STBX_parm_invalid,
			task.parm[ 0 ].name );
   }
   inImagesNo = (UINTx1) task.parm[ 0 ].number;


/* ==========================================================================
   Build full name of input and output image
   ========================================================================== */
   for( i=0; i<task.parm[ 0 ].number; i++) {
      sprintf( inImages[ i ], "%s%s", LDEFIV_inp_dir, inImagesName[ i ] );
   }
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_undef,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   sprintf( outImageErm, "%s%s.ers", LDEFIV_out_dir, outImageName );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   for( i=0; i<inImagesNo; i++ ) {
      FILSIP_open( inImages[ i ], "r", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      FILSIP_close( &fp, &log_status_code );
   }
   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

   FILSIP_open( outImageErm, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImageErm, &log_status_code );

/* ==========================================================================
   Open the TIFF input files
   ========================================================================== */
   for( i=0; i<inImagesNo; i++ ) {
      inp_io[ i ].type = GIOSIE_tif;
      inp_io[ i ].mode = 'r';
      strcpy( inp_io[ i ].val.tif.name, inImages[ i ]);
      inp_io[ i ].img = 0;
      GIOSIP_open_io( &(inp_io[ i ]),
                       status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      if( i > 0 ) {
/* ==========================================================================
   Check dimensions
   ========================================================================== */
         if( (inp_io[ i ].val.tif.bpar.imagewidth != 
                 inp_io[ 0 ].val.tif.bpar.imagewidth) &&
             (inp_io[ i ].val.tif.bpar.imagelength !=
                 inp_io[ 0 ].val.tif.bpar.imagelength ) ) {
            sprintf( err_msg, "%s has different size from %s image", 
               inImages[ i ], inImages[ 0 ] );
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_invalid,
                              err_msg );
         }
/* ==========================================================================
   Check type
   ========================================================================== */
         if( inp_io[ i ].dt != inp_io[ 0 ].dt ) {
            sprintf( err_msg, "%s has different type from %s image", 
               inImages[ i ], inImages[ 0 ] );
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_invalid,
                              err_msg );
         }

      }

   }

/* ==========================================================================
   Set output BIL file
   ========================================================================== */
   out_io.type = GIOSIE_file;
   out_io.mode = 'w';
   out_io.val.fil.size = 0;
   strcpy( out_io.val.fil.fname, outImage);

/* ==========================================================================
   Compute output image size in Kb
   ========================================================================== */
   for( i=0; i<inImagesNo; i++ ) {
      out_io.val.fil.size += 
         (inp_io[ i ].val.tif.bpar.imagewidth * 
          inp_io[ i ].val.tif.bpar.imagelength *
          inp_io[ i ].spp * (inp_io[ i ].bps/8) );
   }
   out_io.val.fil.size /= 1024;

/* ==========================================================================
   Open output BIL file
   ========================================================================== */
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_bilgen(  inp_io,
                   inImagesNo,
                  &out_io,
                   outImageErm,
                   status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   for( i=0; i<inImagesNo; i++ ) {
      GIOSIP_close_io( &(inp_io[ i ]), status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      for( i=0; i<inImagesNo; i++ ) {
         FILSIP_delete( inImages[ i ], &log_status_code );
      }
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CONV_bilgen */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_tiffgen

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the TIF generation conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_tiffgen routine
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_CONV_tiffgen
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CONV_tiffgen";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImages[ STBXPD_num_tgen_img ], outImage;
   FILSIT_file_name        inImagesName[ STBXPD_num_tgen_img ], outImageName;
   LDEFIT_boolean          real_aoi;

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io[ STBXPD_num_tgen_img ], out_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx1                  inImagesNo;
   LDEFIT_boolean          out_open = FALSE;
   char                    err_msg[ 256 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy( task.parm[ 0 ].name, STBXPD_input_images );
   task.parm[ 0 ].type = FIISIE_tt_string;
   task.parm[ 0 ].size = sizeof( FILSIT_file_name );
   task.parm[ 0 ].mandatory = TRUE;
   task.parm[ 0 ].vector = TRUE;
   task.parm[ 0 ].max_number = STBXPD_num_tgen_img;
   task.parm[ 0 ].value = (void *) inImagesName;

   strcpy( task.parm[ 1 ].name, STBXPD_output_image );
   task.parm[ 1 ].type = FIISIE_tt_string;
   task.parm[ 1 ].size = sizeof( FILSIT_file_name );
   task.parm[ 1 ].mandatory = TRUE;
   task.parm[ 1 ].vector = FALSE;
   task.parm[ 1 ].value = (void *) outImageName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check parameter
   ========================================================================== */
   if( (task.parm[ 0 ].number != 1) &&
       (task.parm[ 0 ].number != STBXPD_num_tgen_img) ) {
      ERRSIM_set_error( status_code,
			ERRSID_STBX_parm_invalid,
			task.parm[ 0 ].name );
   }
   inImagesNo = (UINTx1) task.parm[ 0 ].number;


/* ==========================================================================
   Build full name of input and output image
   ========================================================================== */
   for( i=0; i<task.parm[ 0 ].number; i++) {
      sprintf( inImages[ i ], "%s%s", LDEFIV_inp_dir, inImagesName[ i ] );
   }
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_undef,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   for( i=0; i<inImagesNo; i++ ) {
      FILSIP_open( inImages[ i ], "r", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      FILSIP_close( &fp, &log_status_code );
   }
   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input files
   ========================================================================== */
   for( i=0; i<inImagesNo; i++ ) {
      inp_io[ i ].type = GIOSIE_tif;
      inp_io[ i ].mode = 'r';
      strcpy( inp_io[ i ].val.tif.name, inImages[ i ]);
      inp_io[ i ].img = 0;
      GIOSIP_open_io( &(inp_io[ i ]),
                       status_code);
      ERRSIM_on_err_goto_exit( *status_code );
      if( inp_io[ i ].val.tif.bpar.sampleperpixel > 1 ) {
         sprintf( err_msg, "sampleperpixel of %s input image", inImages[ i ] );
	 ERRSIM_set_error( status_code,
			   ERRSID_STBX_parm_invalid,
			   err_msg );
      }
      if( inp_io[ i ].val.tif.bpar.bitspersample[ 0 ] != 8 ) {
         sprintf( err_msg, "bitpersample of %s input image", inImages[ i ] );
	 ERRSIM_set_error( status_code,
			   ERRSID_STBX_parm_invalid,
			   err_msg );
      }

/* ==========================================================================
   Check dimensions
   ========================================================================== */
      if( i > 0 ) {
         if( (inp_io[ i ].val.tif.bpar.imagewidth != 
                 inp_io[ 0 ].val.tif.bpar.imagewidth) &&
             (inp_io[ i ].val.tif.bpar.imagelength !=
                 inp_io[ 0 ].val.tif.bpar.imagelength ) ) {
            sprintf( err_msg, "%s has different size from %s image", 
               inImages[ i ], inImages[ 0 ] );
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_invalid,
                              err_msg );
         }
      }

   }

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = inp_io[ 0 ].val.tif.bpar.imagelength;
   out_io.val.tif.bpar.imagewidth = inp_io[ 0 ].val.tif.bpar.imagewidth;
   out_io.val.tif.bpar.sampleperpixel = (UINTx2) inImagesNo;
   if( inImagesNo == 1 ) {
      out_io.val.tif.bpar.photometricinterpretation = (UINTx2) 1;
   }
   else {
      out_io.val.tif.bpar.photometricinterpretation = (UINTx2) 2;
   }
   for( i=0; i<inImagesNo; i++ ) {
      out_io.val.tif.bpar.bitspersample[ i ] =
             (UINTx2)(sizeof(UINTx1)*LDEFID_byte_size);
   }
   for( i=0; i<inImagesNo; i++ ) {
      out_io.val.tif.bpar.sampleformat[ i ] = TIFSID_uintdata;
   }
   npar = TIFSID_nbpar;

/* ==========================================================================
   Open output STANDARD TIFF file
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.standard = TRUE;
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_tiffgen(  inp_io,
                    inImagesNo,
                   &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   for( i=0; i<inImagesNo; i++ ) {
      GIOSIP_close_io( &(inp_io[ i ]), status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      for( i=0; i<inImagesNo; i++ ) {
         FILSIP_delete( inImages[ i ], &log_status_code );
      }
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CONV_tiffgen */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_dumpannot

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the AMPLITUDE TO POWER conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
		      - Call CONVIP_dumpannot routine
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_CONV_dumpannot
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CONV_dumpannot";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImage, outFile;
   FILSIT_file_name        inImageName, outFileName;

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy( task.parm[ 0 ].name, STBXPD_input_image );
   task.parm[ 0 ].type = FIISIE_tt_string;
   task.parm[ 0 ].size = sizeof( FILSIT_file_name );
   task.parm[ 0 ].mandatory = TRUE;
   task.parm[ 0 ].vector = FALSE;
   task.parm[ 0 ].value = (void *) inImageName;

   strcpy( task.parm[ 1 ].name, STBXPD_output_file );
   task.parm[ 1 ].type = FIISIE_tt_string;
   task.parm[ 1 ].size = sizeof( FILSIT_file_name );
   task.parm[ 1 ].mandatory = TRUE;
   task.parm[ 1 ].vector = FALSE;
   task.parm[ 1 ].value = (void *) outFileName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input and output image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outFileName,
                         task_name,
                         LDEFIE_dt_undef,
                         outFile,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outFile, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outFile, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_dumpannot( &inp_io,
                      outFile,
                      status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the input file
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CONV_dumpannot */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_impraster

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the INTEGER TO FLOAT conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_impraster routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_CONV_impraster
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CONV_impraster";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   ichar, i, j, ipar, iparNumRows, iparNumCols,
                           iparMediaTypeTxt, iparMediaFileSkip;
   INTx4                   fileSize, mediaFileSkip;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImage, outImage;
   FILSIT_file_name        inImageName, outImageName;
   LDEFIT_boolean          real_aoi;
   char                    msg[ 132 ];

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io, out_io;
   UINTx2                  npar = 0;
   LDEFIT_boolean          out_open = FALSE;
   UINTx2                  sampleperpixel;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   char                    dataType[ 30 ];
   char                    mediaTypeTxt[ 30 ];
   INTx4                   cellSize;
   INTx4                   fileHeadBytes = 0, lineHeadBytes = 0, recLength, 
                           numRows, numCols;
   char                    swapBytes = 'N';
   CONVIT_raster_data_type rasterDataType;
   GIOSIT_type             mediaType;
   INTx4                   key_press;
   const UINTx1            out_ima_num = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 11 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_input_media_type );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( mediaTypeTxt );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) mediaTypeTxt;
   iparMediaTypeTxt = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_media_file_skip );
   task.parm[ ipar ].type = FIISIE_tt_int;
   task.parm[ ipar ].size = sizeof( INTx4 );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &mediaFileSkip;
   iparMediaFileSkip = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_data_type );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( dataType );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) dataType;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_file_head_bytes );
   task.parm[ ipar ].type = FIISIE_tt_int;
   task.parm[ ipar ].size = sizeof( INTx4 );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &fileHeadBytes;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_line_head_bytes );
   task.parm[ ipar ].type = FIISIE_tt_int;
   task.parm[ ipar ].size = sizeof( INTx4 );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &lineHeadBytes;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_image_record_length );
   task.parm[ ipar ].type = FIISIE_tt_int;
   task.parm[ ipar ].size = sizeof( INTx4 );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &recLength;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_number_of_rows );
   task.parm[ ipar ].type = FIISIE_tt_int;
   task.parm[ ipar ].size = sizeof( INTx4 );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &numRows;
   iparNumRows = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_number_of_cols );
   task.parm[ ipar ].type = FIISIE_tt_int;
   task.parm[ ipar ].size = sizeof( INTx4 );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &numCols;
   iparNumCols = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) outImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_swap_bytes );
   task.parm[ ipar ].type = FIISIE_tt_char;
   task.parm[ ipar ].size = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &swapBytes;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   ipar = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ ipar ].name, STBXPD_input_dir );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) LDEFIV_inp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_dir );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( LDEFIV_out_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) LDEFIV_out_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_temporary_dir );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) LDEFIV_temp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_delete_input_image );
   task.parm[ ipar ].type = FIISIE_tt_char;
   task.parm[ ipar ].size = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Init IANNIV_ImageAnnot of output image
   ========================================================================== */
   memset( (void *) &(IANNIV_ImageAnnot[ out_ima_num ]), 0,
           (size_t) sizeof( IANNIT_ImageAnnot ) );

/* ==========================================================================
   Build mediaType
   ========================================================================== */
   if( task.parm[ iparMediaTypeTxt ].founded == FALSE ) {
      mediaType = GIOSIE_file;
   }
   else {
      for(ichar = 0; ichar < strlen(mediaTypeTxt); ichar++)
         mediaTypeTxt[ichar] = toupper(mediaTypeTxt[ichar]);

      if((strcmp(mediaTypeTxt, "DISK")) == 0)
         mediaType = GIOSIE_file;
      else if((strcmp(mediaTypeTxt, "CDROM")) == 0)
         mediaType = GIOSIE_file;
      else if((strcmp(mediaTypeTxt, "TAPE")) == 0)
         mediaType = GIOSIE_device;
   }

/* ==========================================================================
   Build full name of input and output image
   ========================================================================== */
   if ( mediaType == GIOSIE_file ) {
      sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   }
   else {
      strcpy( inImage, inImageName );
      if( task.parm[ iparMediaFileSkip ].founded == FALSE ) {
         mediaFileSkip = 0;
      }
      else {
         if( mediaFileSkip < 0 ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
               task.parm[ iparMediaFileSkip ].name );
         }
      }

   }

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   if ( mediaType == GIOSIE_file ) {
      FILSIP_open( inImage, "r", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Go until to the end of file to get its size
   ========================================================================== */
      fseek( fp, (INTx8) 0, SEEK_END );
      fileSize = ftell( fp ) + 1;

/* ==========================================================================
   Automatically compute number of rows as all the file
   ========================================================================== */
      if( recLength <= 0 ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
            STBXPD_image_record_length );
      }

      if( task.parm[ iparNumRows ].founded == FALSE ) {

         numRows = (fileSize - fileHeadBytes)/recLength;

      }
      else {

         if( numRows <= 0 ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
               STBXPD_number_of_rows );
         }
         if( numRows > ((fileSize - fileHeadBytes)/recLength) ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
               STBXPD_number_of_rows );
         }

      }
      FILSIP_close( &fp, &log_status_code );
   }
   else {
      if( task.parm[ iparNumRows ].founded == FALSE ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ iparNumRows ].name );
      }
   }

/* ==========================================================================
   Check input parameters
   ========================================================================== */
   if( lineHeadBytes < 0 ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
         STBXPD_line_head_bytes );
   }
   if( lineHeadBytes >= recLength ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            "Line Header Byte can't be greater or equal than Record Length" );
   }
   if( fileHeadBytes < 0 ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
         STBXPD_file_head_bytes );
   }

/* ==========================================================================
   
   ========================================================================== */
   if ( mediaType == GIOSIE_device ) {
      fprintf(stdout,
            "Insert volume on %s\nPress <Enter> to continue ...\n",
            inImage );

      fflush( stdin );
      key_press = 0;
      while(key_press == 0)
      {
         key_press = getchar();
      }
   }

/* ==========================================================================
   Open the input 
   ========================================================================== */
   inp_io.type = mediaType;
   inp_io.mode = 'r';
   strcpy( inp_io.val.fil.fname, inImage);
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set CONVIP_impraster init
   ========================================================================== */
   if( !strcmp( dataType, STBXPD_data_type_2i ) ) {
      rasterDataType = CONVIE_raster_2i;
      sampleperpixel = 1;
      IANNIV_ImageAnnot[ out_ima_num ].MapProjectionType = IANNIE_proj_ground;
      cellSize = 2;
   }
   else if ( !strcmp( dataType, STBXPD_data_type_complex2i ) ) {
      rasterDataType = CONVIE_raster_complex2i;
      IANNIV_ImageAnnot[ out_ima_num ].MapProjectionType = IANNIE_proj_slant;
      sampleperpixel = 2;
      cellSize = 4;
   }
   else {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, 
         STBXPD_data_type );
   }
   
/* ==========================================================================
   Automatically compute number of columns
   ========================================================================== */
   if( task.parm[ iparNumCols ].founded == FALSE ) {
      numCols = (recLength - lineHeadBytes)/cellSize;      
      sprintf( msg, "Considered %0d columns", numCols );
      ERRSIM_print_warning( msg );
   }
   else {
      if( numCols <= 0 ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
            STBXPD_number_of_cols );
      }

      if( numCols > ((recLength - lineHeadBytes)/cellSize) ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            STBXPD_number_of_cols );
      }
   }

   if ( mediaType == GIOSIE_file ) {
      if( (fileHeadBytes + (numRows * (numCols*cellSize + lineHeadBytes))) > 
          fileSize ) {
         sprintf( msg, "EOF encountered with %s, %s, %s and %s parameter values",
            STBXPD_number_of_rows, STBXPD_number_of_cols,
            STBXPD_file_head_bytes, STBXPD_line_head_bytes );
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            msg );
      }

      if( task.parm[ iparNumRows ].founded == FALSE ) {
         sprintf( msg, "Considered %0d rows", numRows );
         ERRSIM_print_warning( msg );
      }
   }

/* ==========================================================================
   Build output image name
   ========================================================================== */
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         (( sampleperpixel == 1 ) ?
                          LDEFIE_dt_float : LDEFIE_dt_2_float),
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check if the output file can be open
   ========================================================================== */
   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = numRows;
   out_io.val.tif.bpar.imagewidth = numCols;
   out_io.val.tif.bpar.sampleperpixel = sampleperpixel;

   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;

   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_impraster( &inp_io,
                      mediaFileSkip,
                      fileHeadBytes,
                      lineHeadBytes,
                      recLength,
                      numRows,
                      numCols,
                      rasterDataType,
                      toupper(swapBytes),
                     &out_io,
                      status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set Scaling Factor as full
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].XScalingFactor = 1.0;
   IANNIV_ImageAnnot[ out_ima_num ].YScalingFactor = 1.0;
   
/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
				  task.name, 
                                  "",
			          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      if ( mediaType == GIOSIE_file ) {
         FILSIP_delete( inImage, &log_status_code );
      }
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CONV_impraster */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_lin2db

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the LINEAR TO DB conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_lin2db routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_CONV_lin2db
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CONV_lin2db";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImage, outImage;
   FILSIT_file_name        inImageName, outImageName;
   LDEFIT_boolean          real_aoi;

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io, out_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   LDEFIT_boolean          out_open = FALSE;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            out_ima_num = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy( task.parm[ 0 ].name, STBXPD_input_image );
   task.parm[ 0 ].type = FIISIE_tt_string;
   task.parm[ 0 ].size = sizeof( FILSIT_file_name );
   task.parm[ 0 ].mandatory = TRUE;
   task.parm[ 0 ].vector = FALSE;
   task.parm[ 0 ].value = (void *) inImageName;

   strcpy( task.parm[ 1 ].name, STBXPD_output_image );
   task.parm[ 1 ].type = FIISIE_tt_string;
   task.parm[ 1 ].size = sizeof( FILSIT_file_name );
   task.parm[ 1 ].mandatory = TRUE;
   task.parm[ 1 ].vector = FALSE;
   task.parm[ 1 ].value = (void *) outImageName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   printf( "%s : %s\n", STBXPD_input_image, inImageName);
   printf( "%s : %s\n", STBXPD_output_image, outImageName);
#endif

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input and output image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_float,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   If the image has more than 1 sampleperpixel exit
   ========================================================================== */
   if( inp_io.spp>1 ) {
      ERRSIM_set_error( status_code,
		        ERRSID_STBX_inv_prod_type,
			"input image is complex" );
   }

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_CONV_LIDB, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check pixel type 
   ========================================================================== */
   if( IANNIV_ImageAnnot[ inp_ima_num ].PixelType == IANNIE_pixt_complex ) {
      ERRSIM_set_error( status_code,
		        ERRSID_STBX_inv_prod_type,
			"input image is complex" );
   }

/* ==========================================================================
   Warning on image scale
   ========================================================================== */
   if( IANNIV_ImageAnnot[ inp_ima_num ].ImageScale == IANNIE_iscale_db ) {
      ERRSIM_set_error( status_code,
		        ERRSID_STBX_inv_prod_type,
			"input image is already in DB" );
   }

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute nrow_inp/ncol_inp and nrow_out/ncol_out of source image
   ========================================================================== */
   nrow_out = nrow_inp = BRRow - TLRow + 1;
   ncol_out = ncol_inp = BRCol - TLCol + 1;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_lin2db( &inp_io,
                   inp_ima_num,
                   TLRow,
                   TLCol,
                   nrow_inp,
                   ncol_inp,
                  &out_io,
                   out_ima_num,
                   status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set image scale
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageScale = IANNIE_iscale_db;

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND(TLRow / 
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND(TLCol/ 
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
				  task.name, 
                                  "",
			          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CONV_lin2db */

