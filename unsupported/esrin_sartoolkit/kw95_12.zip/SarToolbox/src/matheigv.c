/* ==========================================================================
   $MODULE_HEADER

      $NAME              MATH_EIGV

      $FUNCTION          This module contains the routines for the computation
                         of the eigenvalues and eigenvectors of a real symmetric
                         matrix. They are masks to use the Numerical Recipes
                         routines tred2 and tqli

      $ROUTINE           MATHIP_EIGV_tred
                         MATHIP_EIGV_tqli

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       14-APR-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */


#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_NREC_H
#include MATH_INTF_H
#include MATH_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_EIGV_tred

        $TYPE         PROCEDURE

        $INPUT        n : number of rows and columns of the matrix to transform

        $MODIFIED     a : a[n][n] is the matrix we want to transform. In output
                          it returns the orthogonal matrix transformed by the
                          Householder transformation.

        $OUTPUT       d : an array d[n] with the diagonals elements of the
                          output tridiagonal matrix
                      e : an array e[n] with the off-diagonal elements of the
                          output matrix, with e[0]=1

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_err_mem_alloc

        $DESCRIPTION  This procedure set the one-offset parameters to be used
                      by the Numerical Recipes routine tred2 that makes an
                      Householder transformation of the given n times n real
                      symmetric matrix

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_EIGV_tred
                        (/*IN    */ INTx4                n,
                         /*IN OUT*/ double             **a,
                         /*   OUT*/ double              *d,
                         /*   OUT*/ double              *e,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_EIGV_tred";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;
   INTx4                  status;
   double               **aa = (double **) NULL;
   double               **aa_save;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);


/* ==========================================================================
   Error variable initialization
   ========================================================================== */
   status          = 0;

/* ==========================================================================
   Creates the one-offset matrix for the Num. Rec. routine tre2
   ========================================================================== */
   aa = (double **)MEMSIP_alloc( (size_t)(n*sizeof(double *) ) );
   if( aa == (double **) NULL )
   {
      ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");
   }

   aa_save = aa;

   aa -= 1;
   for( i=1; i <= n; i++ ) {
      aa[i]=a[i-1];
      aa[i] -= 1;
   }

/* ==========================================================================
   Calls the procedure tred2
   ========================================================================== */
   dtred2(aa, n, d-1, e-1, &status);

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free( (void **) &aa_save );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_EIGV_tred */











/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_EIGV_tqli

        $TYPE         PROCEDURE

        $INPUT        n : number of rows and columns of the matrix z

        $MODIFIED     d : an array d[n] with in input the diagonals elements of
                          the tridiagonal matrix given in output. It returns the
                          eigenvalues of z

                      e : an array e[n] with in input the off-diagonal elements,
                          with e[0] arbitrary, of the output matrix. The input
                          vector in output is destroid

                      z : the tridiagonal matrix z[n][n] obtained by tred2
                          previously called. It returns the eigenvectors

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_num_err
                      ERRSID_MATH_err_mem_alloc

        $DESCRIPTION  This procedure set the one-offset parameters to be used
                      by the Numerical Recipes routine tqli that evaluates the
                      eigenvalues and the eigenvectors of the given matrix

        $WARNING      The matrix to process must be obtained by a previous call
                      to the routine MATHIP_EIGV_tred

        $PDL

   $EH
   ========================================================================== */

void MATHIP_EIGV_tqli
                        (/*IN    */ INTx4                n,
                         /*IN OUT*/ double              *d,
                         /*IN OUT*/ double              *e,
                         /*IN OUT*/ double             **z,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_EIGV_tqli";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i,status;
   double               **zz = (double **) NULL;
   double               **zz_save;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

/* ==========================================================================
   Error variable initialization
   ========================================================================== */
   status          = 0;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Creates the one-offset matrix for the Num. Rec. routine tqli
   ========================================================================== */
   zz=(double **) MEMSIP_alloc((size_t) (n*sizeof(double *)));
   if (zz == (double **) NULL)
      ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");

   zz_save = zz;
   zz -= 1;
   for (i=1;i<=n;i++) {
      zz[i]=z[i-1];
      zz[i] -= 1;
   }

/* ==========================================================================
   Calls the procedure tqli
   ========================================================================== */
   dtqli(d-1,e-1,n,zz,&status);
   if (status) {
      if (status == 2)                /* memory allocation error */
         ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");

      /* too many iterations */
      ERRSIM_set_error(status_code,ERRSID_MATH_num_err,"Too many iterations");
   }

error_exit:;

/* ==========================================================================
   Free memories
   ========================================================================== */
   MEMSIP_free( (void **) &zz_save );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_EIGV_tqli */
