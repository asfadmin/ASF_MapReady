/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_CALI

      $FUNCTION          IMAGE CALIBRATION tool

      $ROUTINE           STBXPP_CALI_Backscattering
                         STBXPP_CALI_Gamma
                         STBXPP_CALI_AdcSaturation

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       18-MAR-98     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */


#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include SRVS_INTF_H
#include IANN_INTF_H
#include COOR_INTF_H
#include CONV_INTF_H
#include STAT_INTF_H
#include ICAL_INTF_H
#include STBX_INTF_H
#include STBX_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CALI_Backscattering

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the IMAGE BACKSCATTERING tasks

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call image backscattering routine

   $EH
   ========================================================================== */
void STBXPP_CALI_Backscattering 
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CALI_Backscattering";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   ipar;
   INTx4                   jpar;
   FILE                   *fp;
   INTx4                   iparApLut, iparRslLut, 
                           iparCcLut, iparRpLut,
                           iparOutimaScale, iparApFileName, iparCalibConst,
                           iparRefReplicaPower, iparRefChirpAverage,
                           iparAdcLut, iparAdcLutFileName;
   FIISIT_parm_name        tmpParmName;
   FILSIT_file_name        inImageName, inImage, 
                           outImageName, outImage, adcLutFile;
   FILSIT_file_name        apFileName, adcLutFileName;
   LDEFIT_boolean          useApFileName;
   char                    outImageScaleStr[ 20 ];
   IANNIT_ImageScale       outImageScale = IANNIE_iscale_linear;
   char                    apLut[ 20 ], rslLut[ 20 ], 
                           ccLut[ 20 ], rpLut[ 20 ], adcLut[ 20 ];
   ICALIT_lut_direct       apLutDirect = ICALIE_lut_none, 
                           rslLutDirect = ICALIE_lut_none, 
                           ccLutDirect = ICALIE_lut_none, 
                           rpLutDirect = ICALIE_lut_none,
                           adcLutDirect = ICALIE_lut_none;
   float                   calibConst;
   LDEFIT_boolean          useCalibConst;
   LDEFIT_boolean          oneLut = FALSE;
   float                   refReplicaPower[ 2 ], refChirpAverage[ 2 ];
   char                    msg[ 132 ];

   GIOSIT_io               inp_io, out_io, adc_io;
   UINTx1                  inp_ima_num = 0;
   UINTx1                  out_ima_num = 1;
   UINTx1                  adc_ima_num = 1;
   LDEFIT_boolean          out_open = FALSE;
   UINTx4                  TLRow , TLCol, BRRow, BRCol, nrow_inp , ncol_inp;
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   LDEFIT_boolean          real_aoi;
   UINTx4                  npar;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 13 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL )
   {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image_scale );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( outImageScaleStr );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outImageScaleStr;
   iparOutimaScale = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_antenna_pattern_lut );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( apLut );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) apLut;
   iparApLut = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_antenna_pattern_file  );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( apFileName );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) apFileName;
   iparApFileName = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_range_spread_loss_lut );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( rslLut );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) rslLut;
   iparRslLut = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_calib_const_lut );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( ccLut );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) ccLut;
   iparCcLut = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_user_calibration_constant );
   task.parm[ ipar ].type       = FIISIE_tt_float;
   task.parm[ ipar ].size       = sizeof( float );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) &calibConst;
   iparCalibConst = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_replica_power_lut );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( rpLut );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) rpLut;
   iparRpLut = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_refer_replica_power );
   task.parm[ ipar ].type       = FIISIE_tt_float;
   task.parm[ ipar ].size       = sizeof( float );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value      = (void *) refReplicaPower;
   iparRefReplicaPower = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_refer_chirp_average );
   task.parm[ ipar ].type       = FIISIE_tt_float;
   task.parm[ ipar ].size       = sizeof( float );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value      = (void *) refChirpAverage;
   iparRefChirpAverage = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_adc_satur_correct );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( adcLut );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) adcLut;
   iparAdcLut = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_adc_satur_correct_file );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( adcLutFileName );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) adcLutFileName;
   iparAdcLutFileName = ipar;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   ipar = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ ipar ].name, STBXPD_input_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_inp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_inp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_out_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_out_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_temporary_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_temp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_temp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_delete_input_image );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      FIISIP_GETS_get_info(argv[2],
                           task.name,
                           section_no,
                           &(task.parm[ipar]),
                           status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for(ipar = 3; ipar < argc; ipar += 2)
   {
      if(argv[ipar][0] == STBXPD_prefix_line_arg)
      {
         sprintf(tmpParmName, "%s", &(argv[ipar][1]));
         for(jpar = 0; jpar < task.parmNo; jpar++)
         {
            if(!strcmp(tmpParmName, task.parm[jpar].name))
            {
               STBXPP_set_par((void *) argv[ipar + 1],
                                &(task.parm[jpar]),
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               break;
            }
         }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      if((!task.parm[ipar].founded ) && (task.parm[ipar].mandatory))
      {
#ifdef __TRACE__
         printf("Param %s not defined\n", task.parm[ipar].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ipar].name);
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set input value to the algorithm
   ========================================================================== */
   if( task.parm[ iparOutimaScale ].founded ) {
      if( !strcmp( outImageScaleStr, STBXPD_linear_scale ) ) {
         outImageScale = IANNIE_iscale_linear;
      }
      else if( !strcmp( outImageScaleStr, STBXPD_db_scale ) ) {
         outImageScale = IANNIE_iscale_db;
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            task.parm[ iparOutimaScale ].name );
      }
   }
   else {
      outImageScale = IANNIE_iscale_linear;
   }

   if( task.parm[ iparApLut ].founded ) {
      if( !strcmp( apLut, STBXPD_lut_apply ) ) {
         apLutDirect = ICALIE_lut_apply;
      }
      else if( !strcmp( apLut, STBXPD_lut_remove ) ) {
         apLutDirect = ICALIE_lut_remove;
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            task.parm[ iparApLut ].name );
      }
      oneLut = TRUE;
      if( task.parm[ iparApFileName ].founded ) {
         useApFileName = TRUE;
      }
      else {
         useApFileName = FALSE;         
      }
   }
   else {
      apLutDirect = ICALIE_lut_none;
   }

   if( task.parm[ iparRslLut ].founded ) {
      if( !strcmp( rslLut, STBXPD_lut_apply ) ) {
         rslLutDirect = ICALIE_lut_apply;
      }
      else if( !strcmp( rslLut, STBXPD_lut_remove ) ) {
         rslLutDirect = ICALIE_lut_remove;
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            task.parm[ iparRslLut ].name );
      }
      oneLut = TRUE;
   }
   else {
      rslLutDirect = ICALIE_lut_none;
   }

   if( task.parm[ iparCcLut ].founded ) {
      if( !strcmp( ccLut, STBXPD_lut_apply ) ) {
         ccLutDirect = ICALIE_lut_apply;
      }
      else if( !strcmp( ccLut, STBXPD_lut_remove ) ) {
         ccLutDirect = ICALIE_lut_remove;
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            task.parm[ iparCcLut ].name );
      }
      oneLut = TRUE;
   }
   else {
      ccLutDirect = ICALIE_lut_none;
   }

   if( task.parm[ iparCalibConst ].founded ) {
      useCalibConst = TRUE;
      if( ( calibConst < 1.e+4 ) || ( calibConst > 2.e+6 ) ) {
         sprintf( msg, "%s has invalid value", 
            task.parm[ iparCalibConst ].name );
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
             msg );
      }
   }
   else {
      useCalibConst = FALSE;
   }

   if( task.parm[ iparRpLut ].founded ) {
      if( !strcmp( rpLut, STBXPD_lut_apply ) ) {
         rpLutDirect = ICALIE_lut_apply;
      }
      else if( !strcmp( rpLut, STBXPD_lut_remove ) ) {
         rpLutDirect = ICALIE_lut_remove;
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            task.parm[ iparRpLut ].name );
      }
      oneLut = TRUE;

      if( task.parm[ iparRefReplicaPower ].founded == FALSE ) {
         sprintf( msg, "%s LUT needs %s", STBXPD_replica_power_lut, 
            STBXPD_refer_replica_power );
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
             msg );
      }
      else {

         if( task.parm[ iparRefReplicaPower ].number < 2 ) {
            sprintf( msg, "%s needs 2 value for ERS1/ERS2",
               STBXPD_refer_replica_power );
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }
         if( ( refReplicaPower[ 0 ] < 1.e+5 ) ||
             ( refReplicaPower[ 0 ] > 3.e+5 ) ) {
            sprintf( msg, "%s first value (ERS1)", STBXPD_refer_replica_power );
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }
         if( ( refReplicaPower[ 1 ] < 1.e+5 ) ||
             ( refReplicaPower[ 1 ] > 3.e+5 ) ) {
            sprintf( msg, "%s second value (ERS2)", 
               STBXPD_refer_replica_power );
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }

      }

      if( task.parm[ iparRefChirpAverage ].founded == FALSE ) {
         sprintf( msg, "%s LUT needs %s", STBXPD_replica_power_lut, 
            STBXPD_refer_chirp_average );
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
             msg );
      }
      else {

         if( task.parm[ iparRefChirpAverage ].number < 2 ) {
            sprintf( msg, "%s needs 2 value for ERS1/ERS2",
               STBXPD_refer_chirp_average );
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }
         if( ( refChirpAverage[ 0 ] < 1.e+5 ) ||
             ( refChirpAverage[ 0 ] > 3.e+5 ) ) {
            sprintf( msg, "%s first value (ERS1)", STBXPD_refer_chirp_average );
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }
         if( ( refChirpAverage[ 1 ] < 1.e+5 ) ||
             ( refChirpAverage[ 1 ] > 3.e+5 ) ) {
            sprintf( msg, "%s second value (ERS2)", 
               STBXPD_refer_chirp_average);
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }

      }

   }
   else {
      rpLutDirect = ICALIE_lut_none;
   }

   if( task.parm[ iparAdcLut ].founded ) {
      if( !strcmp( adcLut, STBXPD_lut_apply ) ) {
         adcLutDirect = ICALIE_lut_apply;
         if( task.parm[ iparAdcLutFileName ].founded == FALSE ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_defined,
               task.parm[ iparAdcLutFileName ].name );
         }
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            task.parm[ iparAdcLut ].name );
      }
      oneLut = TRUE;
   }
   else {
      adcLutDirect = ICALIE_lut_none;
   }

   if( oneLut == FALSE ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
         "No LUT application/removal defined" );
   }

/* ==========================================================================
   Build full name of input and output file
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_float,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_ICAL_BSCA, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check product type
   ========================================================================== */
   if( (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS1_PRI)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS1_SLC)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS1_SLCI)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS2_PRI)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS2_SLC)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS2_SLCI)
     ) {
      sprintf( msg, " %s is not a PRI|SLC|SLCI image", inImage );
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_prod_type, msg );
   }

/* ==========================================================================
   Check that input image is a power type
   ========================================================================== */
   if( IANNIV_ImageAnnot[ inp_ima_num ].PixelType != IANNIE_pixt_power ) {
      sprintf( msg, " %s is not a power image", inImage );
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_prod_type, msg );
   }

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute nrow_inp/ncol_inp of source image
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_inp;
   out_io.val.tif.bpar.imagewidth = ncol_inp;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Open adc_io if ADC correction is required
   ========================================================================== */
   if( adcLutDirect == ICALIE_lut_apply ) {

      sprintf( adcLutFile, "%s%s", LDEFIV_inp_dir, adcLutFileName );
/* ==========================================================================
   Open the file
   ========================================================================== */
      adc_io.type = GIOSIE_tif;
      adc_io.mode = 'r';
      strcpy( adc_io.val.tif.name, adcLutFile );
      adc_io.img = 0;
      GIOSIP_open_io( &adc_io,
                       status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get the adc image annotations
   ========================================================================== */
      IANNIP_GETP_ImageAnnot( adc_io.chan, adc_io.img, adc_ima_num, 
         IANNID_ICAL_BADC, adc_io.val.tif.bpar, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

   }

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   ICALIP_IMAG_backscattering( &inp_io,
                                inp_ima_num,
                                TLRow, TLCol, nrow_inp, ncol_inp,
                                apLutDirect, /* antenna pattern lut direction */
                                apFileName, useApFileName, /* antenna pattern file name */
                                rslLutDirect, /* range spreading loss lut direction */
                                ccLutDirect, /* calibration constant lut direction */
                                calibConst, useCalibConst, /* user defined calibration constant */
                                rpLutDirect, /* replica power lut direction */
                                refReplicaPower, refChirpAverage,
                                adcLutDirect, &adc_io, adc_ima_num,
                               &out_io,
                                outImageScale,
                                status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update calibration tags of out_ima_num annotation
   ========================================================================== */
   if( apLutDirect == ICALIE_lut_apply ) {
      IANNIV_ImageAnnot[ out_ima_num ].AntennaPatternCorrectionFlag = TRUE;
   }
   else if( apLutDirect == ICALIE_lut_remove ) {
      IANNIV_ImageAnnot[ out_ima_num ].AntennaPatternCorrectionFlag = FALSE;
   }
   if( rslLutDirect == ICALIE_lut_apply ) {
      IANNIV_ImageAnnot[ out_ima_num ].RangeSpreadingLossCompensationFlag = TRUE;
   }
   else if( rslLutDirect == ICALIE_lut_remove ) {
      IANNIV_ImageAnnot[ out_ima_num ].RangeSpreadingLossCompensationFlag = FALSE;
   }
   if( ccLutDirect == ICALIE_lut_apply ) {
      IANNIV_ImageAnnot[ out_ima_num ].CalibrationConstantApplicationFlag = TRUE;
   }
   else if( ccLutDirect == ICALIE_lut_remove ) {
      IANNIV_ImageAnnot[ out_ima_num ].CalibrationConstantApplicationFlag = FALSE;
   }
   if( rpLutDirect == ICALIE_lut_apply ) {
      IANNIV_ImageAnnot[ out_ima_num ].ReplicaPowerCompensationFlag = TRUE;
   }
   else if( rpLutDirect == ICALIE_lut_remove ) {
      IANNIV_ImageAnnot[ out_ima_num ].ReplicaPowerCompensationFlag = FALSE;
   }
   if( outImageScale == IANNIE_iscale_linear ) {
      IANNIV_ImageAnnot[ out_ima_num ].ImageScale = IANNIE_iscale_linear;
   }
   else if( outImageScale == IANNIE_iscale_db ) {
      IANNIV_ImageAnnot[ out_ima_num ].ImageScale = IANNIE_iscale_db;
   }


/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow +=
      /* current offset */
      ROUND( ((float) TLRow / 
              IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor) );

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol +=
      /* current offset */
      ROUND( ((float) TLCol/ 
              IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor) );

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
				  task.name, 
                                  "",
			          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if((LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y'))
   {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

/* ==========================================================================
   Delete output file(s), if an error occured (if any)
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) )
   {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CALI_Backscattering */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CALI_Gamma

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the GAMMA IMAGE tasks

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call gamma image task

   $EH
   ========================================================================== */
void STBXPP_CALI_Gamma
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CALI_Gamma";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   ipar;
   INTx4                   jpar;
   FILE                   *fp;
   FIISIT_parm_name        tmpParmName;
   FILSIT_file_name        inImageName, inImage, outImageName, outImage;
   char                    outImageScaleStr[ 20 ];
   INTx4                   iparOutimaScale;
   IANNIT_ImageScale       outImageScale = IANNIE_iscale_linear;
   char                    msg[ 132 ];

   GIOSIT_io               inp_io, out_io;
   UINTx1                  inp_ima_num = 0;
   UINTx1                  out_ima_num = 1;
   LDEFIT_boolean          out_open = FALSE;
   UINTx4                  TLRow , TLCol, BRRow, BRCol, nrow_inp , ncol_inp;
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   LDEFIT_boolean          real_aoi;
   UINTx4                  npar;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 3 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL )
   {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image_scale );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( outImageScaleStr );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outImageScaleStr;
   iparOutimaScale = ipar;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   ipar = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ ipar ].name, STBXPD_input_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_inp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_inp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_out_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_out_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_temporary_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_temp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_temp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_delete_input_image );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      FIISIP_GETS_get_info(argv[2],
                           task.name,
                           section_no,
                           &(task.parm[ipar]),
                           status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for(ipar = 3; ipar < argc; ipar += 2)
   {
      if(argv[ipar][0] == STBXPD_prefix_line_arg)
      {
         sprintf(tmpParmName, "%s", &(argv[ipar][1]));
         for(jpar = 0; jpar < task.parmNo; jpar++)
         {
            if(!strcmp(tmpParmName, task.parm[jpar].name))
            {
               STBXPP_set_par((void *) argv[ipar + 1],
                                &(task.parm[jpar]),
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               break;
            }
         }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      if((!task.parm[ipar].founded ) && (task.parm[ipar].mandatory))
      {
#ifdef __TRACE__
         printf("Param %s not defined\n", task.parm[ipar].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ipar].name);
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set input value to the algorithm
   ========================================================================== */
   if( task.parm[ iparOutimaScale ].founded ) {
      if( !strcmp( outImageScaleStr, STBXPD_linear_scale ) ) {
         outImageScale = IANNIE_iscale_linear;
      }
      else if( !strcmp( outImageScaleStr, STBXPD_db_scale ) ) {
         outImageScale = IANNIE_iscale_db;
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            task.parm[ iparOutimaScale ].name );
      }
   }
   else {
      outImageScale = IANNIE_iscale_linear;
   }

/* ==========================================================================
   Build full name of input and output file
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_float,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_ICAL_GAMM, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check product type
   ========================================================================== */
   if( (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS1_PRI)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS1_SLC)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS1_SLCI)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS2_PRI)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS2_SLC)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS2_SLCI)
     ) {
      sprintf( msg, " %s is not a PRI|SLC|SLCI image", inImage );
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_prod_type, msg );
   }

/* ==========================================================================
   Check that input image is a power type
   ========================================================================== */
   if( IANNIV_ImageAnnot[ inp_ima_num ].PixelType != IANNIE_pixt_power ) {
      sprintf( msg, " %s is not a power image", inImage );
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_prod_type, msg );
   }

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute nrow_inp/ncol_inp of source image
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_inp;
   out_io.val.tif.bpar.imagewidth = ncol_inp;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   ICALIP_IMAG_gamma( &inp_io,
                       inp_ima_num,
                       TLRow, TLCol, nrow_inp, ncol_inp,
                      &out_io,
                       outImageScale,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update calibration tags of out_ima_num annotation
   ========================================================================== */
   if( outImageScale == IANNIE_iscale_linear ) {
      IANNIV_ImageAnnot[ out_ima_num ].ImageScale = IANNIE_iscale_linear;
   }
   else if( outImageScale == IANNIE_iscale_db ) {
      IANNIV_ImageAnnot[ out_ima_num ].ImageScale = IANNIE_iscale_db;
   }

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow +=
      /* current offset */
      ROUND( ((float) TLRow / 
              IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor) );

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol +=
      /* current offset */
      ROUND( ((float) TLCol/ 
              IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor) );

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
				  task.name, 
                                  "",
			          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if((LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y'))
   {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

/* ==========================================================================
   Delete output file(s), if an error occured (if any)
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) )
   {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CALI_Gamma */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CALI_AdcSaturation

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the ADC SATURATION CORRECTION task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call image adc saturation routine

   $EH
   ========================================================================== */
void STBXPP_CALI_AdcSaturation
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_CALI_AdcSaturation";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   ipar;
   INTx4                   jpar;
   INTx4                   iparCalibConst, iparRmsWinSize, 
                           iparSmoothWinSize, iparPriSmoothWinSize,
                           iparSlcSmoothWinSize, iparApFileName,
                           iparRefReplicaPower, iparRefChirpAverage;
   ICALIT_lut_direct       apLutDirect = ICALIE_lut_none,
                           rslLutDirect = ICALIE_lut_none,
                           rpLutDirect = ICALIE_lut_none;
   FILSIT_file_name        apFileName;
   LDEFIT_boolean          useApFileName;
   float                   refReplicaPower[ 2 ], refChirpAverage[ 2 ];

   FILE                   *fp;
   FIISIT_parm_name        tmpParmName;
   FILSIT_file_name        inImageName, inImage, outImageName, outImage;
   FILSIT_file_name        rmsImage, bscImage, ampImage, smtImage;
   float                   calibConst;
   LDEFIT_boolean          useCalibConst;
   char                    msg[ 132 ];

   GIOSIT_io               inp_io, out_io;
   UINTx1                  inp_ima_num = 0;
   UINTx1                  out_ima_num = 1;
   LDEFIT_boolean          rms_out_open = FALSE,
                           bsc_out_open = FALSE,
                           amp_out_open = FALSE,
                           smt_out_open = FALSE,
                           out_open = FALSE;
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow , TLCol, nrow_inp, ncol_inp, 
                           nrow_out_rms, ncol_out_rms,
                           nrow_out, ncol_out;
   UINTx4                  npar;
   char                    smoothWinSizeStr[ 40 ];
   double                  rmsWinStep[ 2 ],
                           smoothWinStep[ 2 ];
   double                  reduct_row, reduct_col;
   INTx4                   rmsWinSize[ 2 ], 
                           smoothWinSize[ 2 ],
                           priSmoothWinSize[ 2 ],
                           slcSmoothWinSize[ 2 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 9 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL )
   {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_rms_window_size );
   task.parm[ ipar ].type       = FIISIE_tt_int;
   task.parm[ ipar ].size       = sizeof( INTx4 );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value      = (void *) rmsWinSize;
   iparRmsWinSize = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_pri_smooth_window_size );
   task.parm[ ipar ].type       = FIISIE_tt_int;
   task.parm[ ipar ].size       = sizeof( INTx4 );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value      = (void *) priSmoothWinSize;
   iparPriSmoothWinSize = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_slc_smooth_window_size );
   task.parm[ ipar ].type       = FIISIE_tt_int;
   task.parm[ ipar ].size       = sizeof( INTx4 );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value      = (void *) slcSmoothWinSize;
   iparSlcSmoothWinSize = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_user_calibration_constant );
   task.parm[ ipar ].type       = FIISIE_tt_float;
   task.parm[ ipar ].size       = sizeof( float );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) &calibConst;
   iparCalibConst = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_antenna_pattern_file  );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( apFileName );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) apFileName;
   iparApFileName = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_refer_replica_power );
   task.parm[ ipar ].type       = FIISIE_tt_float;
   task.parm[ ipar ].size       = sizeof( float );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value      = (void *) refReplicaPower;
   iparRefReplicaPower = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_refer_chirp_average );
   task.parm[ ipar ].type       = FIISIE_tt_float;
   task.parm[ ipar ].size       = sizeof( float );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value      = (void *) refChirpAverage;
   iparRefChirpAverage = ipar;


/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   ipar = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ ipar ].name, STBXPD_input_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_inp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_inp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_out_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_out_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_temporary_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_temp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_temp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_delete_input_image );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      FIISIP_GETS_get_info(argv[2],
                           task.name,
                           section_no,
                           &(task.parm[ipar]),
                           status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for(ipar = 3; ipar < argc; ipar += 2)
   {
      if(argv[ipar][0] == STBXPD_prefix_line_arg)
      {
         sprintf(tmpParmName, "%s", &(argv[ipar][1]));
         for(jpar = 0; jpar < task.parmNo; jpar++)
         {
            if(!strcmp(tmpParmName, task.parm[jpar].name))
            {
               STBXPP_set_par((void *) argv[ipar + 1],
                                &(task.parm[jpar]),
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               break;
            }
         }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      if((!task.parm[ipar].founded ) && (task.parm[ipar].mandatory))
      {
#ifdef __TRACE__
         printf("Param %s not defined\n", task.parm[ipar].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ipar].name);
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set input value to the algorithm
   ========================================================================== */
   if( task.parm[ iparCalibConst ].founded ) {
      useCalibConst = TRUE;
      if( ( calibConst < 1.e+4 ) || ( calibConst > 2.e+6 ) ) {
         sprintf( msg, "%s has invalid value", 
            task.parm[ iparCalibConst ].name );
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
             msg );
      }
   }
   else {
      useCalibConst = FALSE;
   }

/* ==========================================================================
   Build full name of input and output file
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_float,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_ICAL_SATC, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check product type
   ========================================================================== */
   if( (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS1_PRI)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS1_SLC)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS1_SLCI)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS2_PRI)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS2_SLC)
    && (IANNIV_ImageAnnot[ inp_ima_num ].ProductType != IANNIE_prod_ERS2_SLCI)
     ) {
      sprintf( msg, " %s is not a PRI|SLC|SLCI image", inImage );
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_prod_type, msg );
   }

/* ==========================================================================
   Check that input image is a power type
   ========================================================================== */
   if( IANNIV_ImageAnnot[ inp_ima_num ].PixelType != IANNIE_pixt_power ) {
      sprintf( msg, " %s is not a power image", inImage );
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_prod_type, msg );
   }

/* ==========================================================================
   Set TLRow, TLCol, nrow_inp, ncol_inp to the whole image
   ========================================================================== */
   TLRow = 0; TLCol = 0; 
   nrow_inp = inp_io.val.tif.bpar.imagelength;
   ncol_inp = inp_io.val.tif.bpar.imagewidth;

/* ==========================================================================
   Compute nrow_out_rms/ncol_out_rms and nrow_out/ncol_out 
   ========================================================================== */
   if( rmsWinSize[ 0 ] <= 0 ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
         STBXPD_rms_window_size );
   }
   if( nrow_inp < rmsWinSize[ 0 ] ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, 
         STBXPD_rms_window_size );
   }
   rmsWinStep[ 0 ] = (double) rmsWinSize[ 0 ];
   nrow_out_rms = SRVSIM_out( nrow_inp, rmsWinSize[ 0 ], rmsWinStep[ 0 ] );

   if( task.parm[ iparRmsWinSize ].number > 1 ) {

      if( rmsWinSize[ 1 ] <= 0 ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
            STBXPD_rms_window_size );
      }
      if( ncol_inp < rmsWinSize[ 1 ] ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, 
            STBXPD_rms_window_size );
      }
      rmsWinStep[ 1 ] = (double) rmsWinSize[ 1 ];
      ncol_out_rms = SRVSIM_out( ncol_inp, rmsWinSize[ 1 ], rmsWinStep[ 1 ] );

   }
   else {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
         STBXPD_rms_window_size );
   }

/* ==========================================================================
   Select smoothWinSize according to the product type
   ========================================================================== */
   switch( IANNIV_ImageAnnot[ inp_ima_num ].ProductType ) {
      case IANNIE_prod_ERS1_SLC:
      case IANNIE_prod_ERS1_SLCI:
      case IANNIE_prod_ERS2_SLC:
      case IANNIE_prod_ERS2_SLCI:
         if( !task.parm[ iparSlcSmoothWinSize ].founded ) {
            slcSmoothWinSize[ 0 ] = 630;
            slcSmoothWinSize[ 1 ] = 1280;
            task.parm[ iparSlcSmoothWinSize ].number = 2;
         }
         if( slcSmoothWinSize[ 0 ] <= 0 ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
               STBXPD_slc_smooth_window_size );
         }
         if( slcSmoothWinSize[ 0 ] < rmsWinSize[ 0 ] ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
               STBXPD_slc_smooth_window_size );
         }
         else {
            smoothWinSize[ 0 ] = ROUND(((float) slcSmoothWinSize[ 0 ]) / 
                                       ((float) rmsWinSize[ 0 ]) );
         }

         if( slcSmoothWinSize[ 1 ] <= 0 ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
               STBXPD_slc_smooth_window_size );
         }
         if( slcSmoothWinSize[ 1 ] < rmsWinSize[ 1 ] ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
               STBXPD_slc_smooth_window_size );
         }
         else {
            smoothWinSize[ 1 ] = ROUND(((float) slcSmoothWinSize[ 1 ]) / 
                                       ((float) rmsWinSize[ 1 ]) );
         }
         strcpy( smoothWinSizeStr, STBXPD_slc_smooth_window_size );
         iparSmoothWinSize = iparSlcSmoothWinSize;
         break;

      case IANNIE_prod_ERS1_PRI:
      case IANNIE_prod_ERS2_PRI:
         if( !task.parm[ iparPriSmoothWinSize ].founded ) {
            priSmoothWinSize[ 0 ] = 400;
            priSmoothWinSize[ 1 ] = 1200;
            task.parm[ iparPriSmoothWinSize ].number = 2;
         }
         if( priSmoothWinSize[ 0 ] <= 0 ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
               STBXPD_pri_smooth_window_size );
         }
         if( priSmoothWinSize[ 0 ] < rmsWinSize[ 0 ] ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
               STBXPD_pri_smooth_window_size );
         }
         else {
            smoothWinSize[ 0 ] = ROUND(((float) priSmoothWinSize[ 0 ]) / 
                                       ((float) rmsWinSize[ 0 ]) );
         }

         if( priSmoothWinSize[ 1 ] <= 0 ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
               STBXPD_pri_smooth_window_size );
         }
         if( priSmoothWinSize[ 1 ] < rmsWinSize[ 1 ] ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
               STBXPD_pri_smooth_window_size );
         }
         else {
            smoothWinSize[ 1 ] = ROUND(((float) priSmoothWinSize[ 1 ]) / 
                                       ((float) rmsWinSize[ 1 ]) );
         }

         strcpy( smoothWinSizeStr, STBXPD_pri_smooth_window_size );
         iparSmoothWinSize = iparPriSmoothWinSize;
         break;
   }


/* ==========================================================================
   Recompute nrow_out/ncol_out 
   ========================================================================== */
   if( smoothWinSize[ 0 ] <= 0 ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
         smoothWinSizeStr );
   }
   if( nrow_out_rms < smoothWinSize[ 0 ] ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, 
         "Input Image Row Size" );
   }
   smoothWinStep[ 0 ] = (double) 1.0;
   nrow_out = SRVSIM_out( nrow_out_rms, smoothWinSize[ 0 ], smoothWinStep[ 0 ]);

   if( task.parm[ iparSmoothWinSize ].number > 1 ) {

      if( smoothWinSize[ 1 ] <= 0 ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
            smoothWinSizeStr );
      }
      if( ncol_out_rms < smoothWinSize[ 1 ] ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, 
            "Input Image Column Size" );
      }
      smoothWinStep[ 1 ] = (double) 1.0;
      ncol_out = SRVSIM_out( ncol_out_rms, smoothWinSize[ 1 ], smoothWinStep[ 1 ] );

   }
   else {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
         STBXPD_rms_window_size );
   }

#ifdef __TRACE__
   fprintf( stderr, "nrow_inp = %0d ncol_inp = %0d nrow_out_rms = %0d\
ncol_out_rms = %0d nrow_out = %0d ncol_out = %0d\n",
      nrow_inp, ncol_inp, nrow_out_rms, ncol_out_rms, nrow_out, ncol_out );
#endif
/* ==========================================================================
   Check refReplicaPower and refChirpAverage input paramter
   ========================================================================== */
   if( IANNIV_ImageAnnot[ inp_ima_num ].ReplicaPowerCompensationFlag == 
       FALSE ) {
      if( task.parm[ iparRefReplicaPower ].founded == FALSE ) {
         refReplicaPower[ 0 ] = 205229.0;
         refReplicaPower[ 1 ] = 156000.0;
      }
      else {
         if( task.parm[ iparRefReplicaPower ].number < 2 ) {
            sprintf( msg, "%s needs 2 value for ERS1/ERS2",
               STBXPD_refer_replica_power );
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }
         if( ( refReplicaPower[ 0 ] < 1.e+5 ) ||
             ( refReplicaPower[ 0 ] > 3.e+5 ) ) {
            sprintf( msg, "%s first value (ERS1)", STBXPD_refer_replica_power );
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }
         if( ( refReplicaPower[ 1 ] < 1.e+5 ) ||
             ( refReplicaPower[ 1 ] > 3.e+5 ) ) {
            sprintf( msg, "%s second value (ERS2)", 
               STBXPD_refer_replica_power );
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }

      }

      if( task.parm[ iparRefChirpAverage ].founded == FALSE ) {
         refChirpAverage[ 0 ] = 267200.0;
         refChirpAverage[ 1 ] = 201060.0;
      }
      else {

         if( task.parm[ iparRefChirpAverage ].number < 2 ) {
            sprintf( msg, "%s needs 2 value for ERS1/ERS2",
               STBXPD_refer_chirp_average );
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }
         if( ( refChirpAverage[ 0 ] < 1.e+5 ) ||
             ( refChirpAverage[ 0 ] > 3.e+5 ) ) {
            sprintf( msg, "%s first value (ERS1)", STBXPD_refer_chirp_average );
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }
         if( ( refChirpAverage[ 1 ] < 1.e+5 ) ||
             ( refChirpAverage[ 1 ] > 3.e+5 ) ) {
            sprintf( msg, "%s second value (ERS2)", 
               STBXPD_refer_chirp_average);
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
                msg );
         }

      }
   }

/* ==========================================================================
   Generate a temporary file name for RMS output image file
   ========================================================================== */
   LDEFIP_UTIL_gen_tmp_name( rmsImage,
                             status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Initialize the basic parameters structure for RMS output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out_rms;
   out_io.val.tif.bpar.imagewidth = ncol_out_rms;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, rmsImage );
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   rms_out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   fprintf( stdout, "\n ... RMS pass ...\n" );
   STATIP_LOCA_stat(&inp_io,
                     inp_ima_num,
                     TLRow,
                     TLCol,
                     nrow_inp,
                     ncol_inp,
                     vertex_no,
                     vertex,
                     rmsWinSize,
                     rmsWinStep,
                     0.0,
                    &out_io,
                     nrow_out_rms,
                     ncol_out_rms,
                     STATIE_image_mean,
                     status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   rms_out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update annotation of input image due to STATIP_LOCA_stat call
   ========================================================================== */
   IANNIV_ImageAnnot[ inp_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ inp_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ inp_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ inp_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ inp_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ inp_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ inp_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

#ifdef __OLD__

/* ==========================================================================
   Compute reduction factor
   ========================================================================== */
   reduct_row = ((double) (nrow_out_rms - 1))/((double) (nrow_inp - 1));
   reduct_col = ((double) (ncol_out_rms - 1))/((double) (ncol_inp - 1));

/* ==========================================================================
   Spacing section
   ========================================================================== */
   IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m /=
      (float)reduct_row;
   IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m /=
      (float)reduct_col;

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +=
      /* current offset */
      ROUND( ((float) TLRow / 
              IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor) );

   IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +=
      /* current offset */
      ROUND( ((float) TLCol / 
              IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor) );

/* ==========================================================================
   Scale factors
   ========================================================================== */
   IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor *=
      (float)reduct_row;
   IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor *=
      (float)reduct_col;

#else

/* ==========================================================================
   Spacing section
   ========================================================================== */
   IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m *=
      (float)rmsWinStep[ 0 ];
   IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m *=
      (float)rmsWinStep[ 1 ];

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND((TLRow + (float)(rmsWinSize[ 0 ] - 1)/2.0) / 
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND((TLCol + (float)(rmsWinSize[ 1 ] - 1)/2.0) / 
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Transient values
   ========================================================================== */
   IANNIV_ImageAnnot[ inp_ima_num ].RowTransient +=
      ROUND(((float)(rmsWinSize[ 0 ] - 1)/2.0) /
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);      
   IANNIV_ImageAnnot[ inp_ima_num ].ColTransient +=
      ROUND(((float)(rmsWinSize[ 1 ] - 1)/2.0) /
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Scale factors
   ========================================================================== */
   IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor /=
      (float)rmsWinStep[ 0 ];
   IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor /=
      (float)rmsWinStep[ 1 ];

#endif

/* ==========================================================================
   Open the rmsImage TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, rmsImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set nrow_inp, ncol_inp
   ========================================================================== */
   TLRow = 0; TLCol = 0;
   nrow_inp = nrow_out_rms;
   ncol_inp = ncol_out_rms;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out_rms;
   out_io.val.tif.bpar.imagewidth = ncol_out_rms;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Generate a temporary file name for RMS output image file
   ========================================================================== */
   LDEFIP_UTIL_gen_tmp_name( bscImage,
                             status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, bscImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   bsc_out_open = TRUE;

   apLutDirect = 
      IANNIV_ImageAnnot[ inp_ima_num ].AntennaPatternCorrectionFlag ? 
         ICALIE_lut_remove : ICALIE_lut_none;
   useApFileName = FALSE;
   if( apLutDirect == ICALIE_lut_remove ) {
      if( task.parm[ iparApFileName ].founded ) {
         useApFileName = TRUE;
      }
   }

   rslLutDirect = 
      IANNIV_ImageAnnot[ inp_ima_num ].RangeSpreadingLossCompensationFlag ?
         ICALIE_lut_remove : ICALIE_lut_none;

   rpLutDirect = 
      (IANNIV_ImageAnnot[ inp_ima_num ].ReplicaPowerCompensationFlag == 
       FALSE ) ? ICALIE_lut_apply : ICALIE_lut_none;

/* ==========================================================================
   Call ICALIP_IMAG_backscattering
   ========================================================================== */
   fprintf( stdout, "\n ... Backscattering pass ...\n" );
   ICALIP_IMAG_backscattering( &inp_io,
                                inp_ima_num,
                                TLRow, TLCol, nrow_inp, ncol_inp,
                                apLutDirect, /* antenna pattern lut direction */
                                apFileName, useApFileName, /* antenna pattern file name */
                                rslLutDirect, /* range spreading loss lut direction */
                                ICALIE_lut_none, /* calibration constant lut direction */
                                0.0, FALSE, /* user defined calibration constant */
                                rpLutDirect, /* replica power lut direction */
                                refReplicaPower, refChirpAverage,
                                ICALIE_lut_none, (GIOSIT_io *) NULL, (UINTx1) 0,
                               &out_io,
                                IANNIE_iscale_linear,
                                status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   bsc_out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the tags due to ICALIP_IMAG_backscattering
   ========================================================================== */
   if( apLutDirect == ICALIE_lut_remove ) {
      IANNIV_ImageAnnot[ inp_ima_num ].AntennaPatternCorrectionFlag = FALSE;
   }
   if( rslLutDirect == ICALIE_lut_remove ) {
      IANNIV_ImageAnnot[ inp_ima_num ].RangeSpreadingLossCompensationFlag =
         FALSE;
   }
   if( rpLutDirect == ICALIE_lut_apply ) {
      IANNIV_ImageAnnot[ inp_ima_num ].ReplicaPowerCompensationFlag = TRUE;
   }

/* ==========================================================================
   Delete the input 
   ========================================================================== */
   FILSIP_delete( rmsImage, &log_status_code );

/* ==========================================================================
   Open the bscImage TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, bscImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set nrow_inp, ncol_inp
   ========================================================================== */
   TLRow = 0; TLCol = 0;
   nrow_inp = nrow_out_rms;
   ncol_inp = ncol_out_rms;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out_rms;
   out_io.val.tif.bpar.imagewidth = ncol_out_rms;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Generate a temporary file name for RMS output image file
   ========================================================================== */
   LDEFIP_UTIL_gen_tmp_name( ampImage,
                             status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, ampImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   amp_out_open = TRUE;

/* ==========================================================================
   Call CONVIP_pow2amp
   ========================================================================== */
   fprintf( stdout, "\n ... Power to Amplitude pass ...\n" );
   CONVIP_pow2amp( &inp_io,
                    inp_ima_num,
                    TLRow,
                    TLCol,
                    nrow_inp,
                    ncol_inp,
                   &out_io,
                    out_ima_num,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   amp_out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete the input 
   ========================================================================== */
   FILSIP_delete( bscImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, ampImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set nrow_inp, ncol_inp
   ========================================================================== */
   TLRow = 0; TLCol = 0;
   nrow_inp = nrow_out_rms;
   ncol_inp = ncol_out_rms;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Generate a temporary file name for RMS output image file
   ========================================================================== */
   LDEFIP_UTIL_gen_tmp_name( smtImage,
                             status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, smtImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   smt_out_open = TRUE;

/* ==========================================================================
   Call STATIP_LOCA_stat to obtain smoothing
   ========================================================================== */
   fprintf( stdout, "\n ... Smoothing pass ...\n" );
   STATIP_LOCA_stat(&inp_io,
                     inp_ima_num,
                     TLRow,
                     TLCol,
                     nrow_inp,
                     ncol_inp,
                     vertex_no,
                     vertex,
                     smoothWinSize,
                     smoothWinStep,
                     0.0,
                    &out_io,
                     nrow_out,
                     ncol_out,
                     STATIE_image_mean,
                     status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   smt_out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete the input 
   ========================================================================== */
   FILSIP_delete( ampImage, &log_status_code );

/* ==========================================================================
   Open the smtImage TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, smtImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set nrow_inp, ncol_inp
   ========================================================================== */
   TLRow = 0; TLCol = 0;
   nrow_inp = nrow_out;
   ncol_inp = ncol_out;

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call ADC computation
   ========================================================================== */
   fprintf( stdout, "\n ... ADC pass ...\n" );
   ICALIP_IMAG_adc_saturation( &inp_io,
                                inp_ima_num,
                                TLRow,
                                TLCol,
                                nrow_inp,
                                ncol_inp,
                                calibConst, 
                                useCalibConst,
                               &out_io,
                                status_code );
   ERRSIM_on_err_goto_exit( *status_code );
                                
/* ==========================================================================
   Set output annotations
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update annotation of input image due to STATIP_LOCA_stat call
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

#ifdef __OLD__

/* ==========================================================================
   Compute reduction factor
   ========================================================================== */
   reduct_row = ((double) (nrow_out - 1))/((double) (nrow_out_rms - 1));
   reduct_col = ((double) (ncol_out - 1))/((double) (ncol_out_rms - 1));

/* ==========================================================================
   Spacing section
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].LineSpacing_m /=
      (float)reduct_row;
   IANNIV_ImageAnnot[ out_ima_num ].PixelSpacing_m /=
      (float)reduct_col;

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow +=
      /* current offset */
      ROUND( ((float) TLRow / 
              IANNIV_ImageAnnot[ out_ima_num ].YScalingFactor) );

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol +=
      /* current offset */
      ROUND( ((float) TLCol / 
              IANNIV_ImageAnnot[ out_ima_num ].XScalingFactor) );

/* ==========================================================================
   Scale factors
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].YScalingFactor *=
      (float)reduct_row;
   IANNIV_ImageAnnot[ out_ima_num ].XScalingFactor *=
      (float)reduct_col;

#else

/* ==========================================================================
   Spacing section
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].LineSpacing_m *=
      (float)smoothWinStep[ 0 ];
   IANNIV_ImageAnnot[ out_ima_num ].PixelSpacing_m *=
      (float)smoothWinStep[ 1 ];

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND((TLRow + (float)(smoothWinSize[ 0 ] - 1)/2.0) / 
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND((TLCol + (float)(smoothWinSize[ 1 ] - 1)/2.0) / 
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Transient values
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].RowTransient +=
      ROUND(((float)(smoothWinSize[ 0 ] - 1)/2.0) /
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);      
   IANNIV_ImageAnnot[ out_ima_num ].ColTransient +=
      ROUND(((float)(smoothWinSize[ 1 ] - 1)/2.0) /
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Scale factors
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].YScalingFactor /=
      (float)smoothWinStep[ 0 ];
   IANNIV_ImageAnnot[ out_ima_num ].XScalingFactor /=
      (float)smoothWinStep[ 1 ];

#endif

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
				  task.name, 
                                  "",
			          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete the input 
   ========================================================================== */
   FILSIP_delete( smtImage, &log_status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if((LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y'))
   {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

/* ==========================================================================
   Delete output file(s), if an error occured (if any)
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) )
   {
      if( rms_out_open || bsc_out_open || amp_out_open || 
          smt_out_open || out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      ERRSIV_dump_error = 0;
      FILSIP_delete( rmsImage, &log_status_code );
      FILSIP_delete( bscImage, &log_status_code );
      FILSIP_delete( ampImage, &log_status_code );
      FILSIP_delete( smtImage, &log_status_code );
      FILSIP_delete( outImage, &log_status_code );
      ERRSIV_dump_error = 1;
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_CALI_AdcSaturation */
