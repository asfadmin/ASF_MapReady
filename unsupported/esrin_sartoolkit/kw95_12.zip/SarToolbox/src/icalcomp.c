/* ==========================================================================
   $MODULE_HEADER

      $NAME              ICAL_COMP

      $FUNCTION          Calibration computation

      $ROUTINE           ICALPP_COMP_info
                         ICALPP_COMP_lut_pass
                         ICALPP_COMP_load_pattern
                         ICALPP_COMP_adc_comp
                         ICALPP_COMP_adc_lut_row
                         ICALPP_COMP_adc_lut_row_index

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       16-MAR-98     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include SRVS_INTF_H
#include GIOS_INTF_H
#include IANN_INTF_H
#include COOR_INTF_H
#include ICAL_INTF_H
#include ICAL_PGLB_H

/* ==========================================================================
                       LOCAL DEFINE DECLARATION SECTION
   ========================================================================== */
#define ICALLD_overflow_float  1.0e+30
#define ICALLD_underflow_float 1.0e-30

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_info            

        $TYPE         PROCEDURE

        $INPUT        imanum     : number identifing the image annotation
                      TLRow      : the row image coordinate of the AoI
                      TLCol      : the column image coordinate of the AoI
                      nrow_inp   : number of rows of the AoI
                      ncol_inp   : number of columns of the AoI

        $MODIFIED     NONE

        $OUTPUT       look_angle      : array of look angle values
                      incidence_angle : array of incidence angle values
                      slant_range     : array of slant range values

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute the look angle, the incidence angle
                      and the slant range values at TLCol ... TLCol+ncol_inp

        $WARNING      NONE

        $PDL          - Allocates the array to fill
                      - Initializes the coordinates conversions stuff
                      - Evaluates the arrays of slant range, incidence and
                        look angle

   $EH
   ========================================================================== */
void ICALPP_COMP_info
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*   OUT*/ float              **look_angle,
                         /*   OUT*/ float              **incidence_angle,
                         /*   OUT*/ float              **slant_range,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_COMP_info";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Allocate look_angle, incidence_angle and slant_range vectors
   ========================================================================== */
   if( (*look_angle = (float *) MEMSIP_alloc( ncol_inp * sizeof(float) )) ==
       (float *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc, 
         "*look_angle" );
   }
   if( (*incidence_angle = (float *) MEMSIP_alloc( ncol_inp * sizeof(float) )) ==
       (float *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc, 
         "*incidence_angle" );
   }
   if( (*slant_range = (float *) MEMSIP_alloc( ncol_inp * sizeof(float) )) ==
       (float *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc, 
         "*slant_range" );
   }

/* ==========================================================================
   Initialize the coordinates conversions
   ========================================================================== */
   COORIP_CONV_Init ( imanum, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the slant range and the incidence and look angles
   ========================================================================== */
   COORIP_CONV_RangeAndAnglesEval ( imanum, TLRow, TLCol, nrow_inp, ncol_inp,
                                    *look_angle, *incidence_angle, *slant_range,
                                    status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_COMP_info */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_lut_pass

        $TYPE         PROCEDURE

        $INPUT        inp_io     : input image description
                      inp_ima_num
                                 : number identifing the input image annotations
                      TLRow      : the row image coordinate in the full
                                   reference frame of the image
                      TLCol      : the column image coordinate in the full
                                   reference frame of the image
                      nrow       : number of rows of the image
                      ncol       : number of columns of the image
                      out_io     : output image description
                      out_ima_scale
                                 : linear or dB scale
                      lut        : array of lut values
                      adc_lut_direction
                                 : apply or none ADC lut
                      adc_io     : adc lut description
                      adc_ima_num: adc lut annotation index

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute an output image as a LUT pass on the
                      input image

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void ICALPP_COMP_lut_pass
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ IANNIT_ImageScale    out_ima_scale,
                         /*IN    */ double              *lut,
                         /*IN    */ ICALIT_lut_direct    adc_lut_direction,
                         /*IN    */ GIOSIT_io           *adc_io,
                         /*IN    */ UINTx1               adc_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_COMP_lut_pass";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, column;
   IANNIT_ImageScale      inp_ima_scale;
   float                 *imgline = (void *) NULL;
   float                 *outline;
   double                 tmp_double;
   double                *adc_lut;
   UINTx4                 adc_TLCol, adc_ncol;
   UINTx4                *adc_lut_row_index;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow > IANNIV_ImageAnnot[ inp_ima_num ].ImageLength ) ||
        ( TLCol + ncol > IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth ) ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_start_stop_col_err, "" );
   }

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
   if( (outline = (float *) MEMSIP_alloc( (size_t) ncol *
                                                   sizeof(float) )) ==
       (float *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc, "outline" );
   }

/* ==========================================================================
   Allocate vector for ADC lut
   ========================================================================== */
   if( (adc_lut = 
           (double *) MEMSIP_alloc( (size_t) ncol * sizeof(double) ) ) ==
       (double *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc,
         "adc_lut" );
   }
   if( (adc_lut_row_index = 
           (UINTx4 *) MEMSIP_alloc( (size_t) ncol * sizeof(UINTx4) ) ) ==
       (UINTx4 *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc,
         "adc_lut_row_index" );
   }

/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol - 1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   If there is an ADC compensation, open line in adc_io
   ========================================================================== */
   if( adc_lut_direction == ICALIE_lut_apply ) {
      UINTx4    full_tlcol, full_trcol, full_ncol, adc_TRCol;
      UINTx4    real_full_adc_tlcol, real_full_adc_trcol;
      UINTx4    full_adc_tlcol, full_adc_trcol;

      full_tlcol = (UINTx4)
         ROUND( ((float) TLCol / 
                 IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor) ) +
         IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol;
      full_trcol =  (UINTx4)
         ROUND( ((float) (TLCol + ncol - 1) /
                 IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor) ) + 
         IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol;

      full_ncol = full_trcol - full_tlcol + 1;


      full_adc_tlcol =
         IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol -
         IANNIV_ImageAnnot[ adc_ima_num ].ColTransient;

      real_full_adc_tlcol =
         IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol;

      real_full_adc_trcol =  (UINTx4)
         ROUND( ((float) (IANNIV_ImageAnnot[ adc_ima_num ].ImageWidth - 1) /
                 IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) ) + 
         IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol;

      full_adc_trcol =
         real_full_adc_trcol + 
         IANNIV_ImageAnnot[ adc_ima_num ].ColTransient - 
         1;

      if( full_tlcol < full_adc_tlcol ) {
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut,
            "coorners coordinates outside the ADC compensation image" );
      }
      else if( (full_tlcol >= full_adc_tlcol) &&
               (full_tlcol <  real_full_adc_tlcol) ) {
         adc_TLCol = 0;
      }
      else if( (full_tlcol >= real_full_adc_tlcol) &&
               (full_tlcol <= real_full_adc_trcol) ) {
         adc_TLCol = (UINTx4)
            ROUND( ((float) (full_tlcol - 
                             IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol) *
                    IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) );
      }
      else if( (full_tlcol >  real_full_adc_trcol) &&
               (full_tlcol <= full_adc_trcol) ) {
         adc_TLCol = (UINTx4)
            ROUND( ((float) (real_full_adc_trcol - 
                             IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol) *
                    IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) );
      }
      else  {
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut,
            "coorners coordinates outside the ADC compensation image" );
      }

      if( full_trcol < full_adc_tlcol ) {
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut,
            "coorners coordinates outside the ADC compensation image" );
      }
      else if( (full_trcol >= full_adc_tlcol) &&
               (full_trcol <  real_full_adc_tlcol) ) {
         adc_TRCol = 0;
      }
      else if( (full_trcol >= real_full_adc_tlcol) &&
               (full_trcol <= real_full_adc_trcol) ) {
         adc_TRCol = (UINTx4)
            ROUND( ((float) (full_trcol - 
                             IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol) *
                    IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) );
      }
      else if( (full_trcol >  real_full_adc_trcol) &&
               (full_trcol <= full_adc_trcol) ) {
         adc_TRCol = (UINTx4)
            ROUND( ((float) (real_full_adc_trcol - 
                             IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol) *
                    IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) );
      }
      else  {
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut,
            "coorners coordinates outside the ADC compensation image" );
      }

      adc_ncol  = adc_TRCol - adc_TLCol + 1;

#ifdef __TRACE1__
      fprintf( stderr, "TLCol=%0d ncol=%0d\n", TLCol, ncol );
      fprintf( stderr, "full_tlcol=%0d full_trcol=%0d full_ncol=%0d\n", 
         full_tlcol, full_trcol, full_ncol );
      fprintf( stderr, "adc_TLCol=%0d adc_TRCol = %0d adc_ncol=%0d\n", 
         adc_TLCol, adc_TRCol, adc_ncol );
#endif

      GIOSIP_open_line( adc_io, 'x', adc_TLCol, 
         adc_TLCol + adc_ncol - 1, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

   }

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol - 1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set variable for image scale
   ========================================================================== */
   inp_ima_scale = IANNIV_ImageAnnot[ inp_ima_num ].ImageScale;

/* ==========================================================================
   Switch according to input image type
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_float:
/* ==========================================================================
   Compute the index LUT used by ICALPP_COMP_adc_lut_row
   ========================================================================== */
         if( adc_lut_direction == ICALIE_lut_apply ) {
            ICALPP_COMP_adc_lut_row_index( TLCol,
                                           ncol,
                                           adc_ima_num,
                                           inp_ima_num,
                                           adc_lut_row_index,
                                           status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
 
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {

            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, (void *) &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   If there is an ADC lut, compute adc_lut for that row
   ========================================================================== */
            ICALPP_COMP_adc_lut_row( row,
                                     ncol,
                                     adc_lut_direction,
                                     adc_io,
                                     adc_ima_num,
                                     inp_ima_num,
                                     adc_lut_row_index,
                                     adc_lut,
                                     status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute lut pass
   ========================================================================== */
            if( out_ima_scale == IANNIE_iscale_db ) {

               if( inp_ima_scale == IANNIE_iscale_db ) {
                  for( column=0; column<ncol; column++ ) {

                     tmp_double = POW( 10.0, (imgline[ column ]/10.0) );

                     if( ( tmp_double = 
                            ( tmp_double * lut[ column ] *
                              adc_lut[ column ] ) ) < 
                         ICALLD_underflow_float ) {
                        outline[ column ] = - ICALLD_overflow_float;
                     }
                     else {
                        outline[ column ] = (float)
                           ( 10.0 * log10(tmp_double) );
                     }
                  }
               }
               else {
                  for( column=0; column<ncol; column++ ) {

                     if( ( tmp_double = ((double)imgline[ column ] * 
                              lut[ column ] *  adc_lut[ column ])) < 
                         ICALLD_underflow_float ) {
                        outline[ column ] = - ICALLD_overflow_float;
                     }
                     else {
                        outline[ column ] = (float)
                           ( 10.0 * log10(tmp_double) );
                     }
                  }
               }
            }
            else {

               if( inp_ima_scale == IANNIE_iscale_db ) {
                  for( column=0; column<ncol; column++ ) {
                     outline[ column ] = 
                        (float) (POW( 10.0, (imgline[ column ]/10.0) ) * 
                                 lut[ column ] * adc_lut[ column ]);
                  }
               }
               else {
                  for( column=0; column<ncol; column++ ) {
                     outline[ column ] = imgline[ column ] * lut[ column ] *
                        adc_lut[ column ];
                  }
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;


      default:
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_data_type, 
            "inp_io->dt" );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the read mode of the ADC image
   ========================================================================== */
   if( adc_lut_direction == ICALIE_lut_apply ) {
      GIOSIP_close_line( adc_io, status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &outline );
   MEMSIP_free( (void **) &adc_lut );
   MEMSIP_free( (void **) &adc_lut_row_index );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_COMP_lut_pass */

/* ==========================================================================


   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_load_pattern

        $TYPE         PROCEDURE

        $INPUT        pattern_file
                                  : file containing the pattern values

        $MODIFIED     NONE

        $OUTPUT       pattern     : pattern vector
                      pattern_no  : number of element into the pattern vector

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine loads the pattern_file
                      into the pattern vector

        $WARNING      NONE

   $EH
   ========================================================================== */
void ICALPP_COMP_load_pattern
                        (/*IN    */ char                *pattern_file,
                         /*   OUT*/ ICALPT_pattern     **pattern,
                         /*   OUT*/ UINTx4              *pattern_no,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_COMP_load_pattern";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i;
   void                  *line;
   GIOSIT_io              pat_io;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Open input TIFF antenna pattern file
   ========================================================================== */
   pat_io.type = GIOSIE_tif;
   pat_io.mode = 'r';
   strcpy( pat_io.val.tif.name, pattern_file);
   pat_io.img = 0;
   GIOSIP_open_io( &pat_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set *pattern_no as image length
   ========================================================================== */
   *pattern_no = pat_io.val.tif.bpar.imagelength;

/* ==========================================================================
   Alloc *pattern vector
   ========================================================================== */
   if( ( *pattern = (ICALPT_pattern *)
                  MEMSIP_alloc( (size_t) *pattern_no *
                                          sizeof(ICALPT_pattern) ) ) ==
       (ICALPT_pattern *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc,
         "*pattern" );
   }

/* ==========================================================================
   Open line for load antenna pattern values
   ========================================================================== */
   GIOSIP_open_line( &pat_io, 'x', 0, 1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read antenna pattern values
   ========================================================================== */
   for( i=0; i<(*pattern_no); i++ ) {
      GIOSIP_read_line( &pat_io, i, 0, &line, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      (*pattern)[ i ].value = ((float *) line)[ 0 ];
      (*pattern)[ i ].patt = ((float *) line)[ 1 ];
   }

/* ==========================================================================
   Close line
   ========================================================================== */
   GIOSIP_close_line( &pat_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close file
   ========================================================================== */
   GIOSIP_close_io( &pat_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_COMP_load_pattern */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALLF_COMP_pattern

        $TYPE         FUNCTION

        $INPUT        value       : value to be interpolated
                      antenna_pattern
                                  : antenna pattern vector

        $MODIFIED     NONE

        $OUTPUT       NONE 

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute the interpolation of value into the
                      pattern vector and return 10^(V/10.0) 

        $WARNING      NONE

   $EH
   ========================================================================== */
double ICALLF_COMP_pattern
                        (/*IN    */ float                value,
                         /*IN    */ ICALPT_pattern      *pattern,
                         /*IN    */ UINTx4               pattern_no,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALLF_COMP_pattern";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   double                 lut_value = 1.0;
   double                 pattern_value;
   UINTx4                 i, ivalue1;
   INTx4                  ivalue2;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Search ivalue1, ivalue2 such that 
   pattern[ ivalue1 ] <= value <= pattern[ ivalue2 ]
   ========================================================================== */
   for( ivalue2=-1, i=0; 
        ( (i<pattern_no) &&
          (ivalue2 == -1) ); 
        i++ ) {
      if( pattern[ i ].value > value ) {
         ivalue2 = i;
      }
   }

/* ==========================================================================
   Check saturation to higher ...
   ========================================================================== */
   if( ivalue2 == -1 ) {

      pattern_value = pattern[ pattern_no-1 ].patt;

   }
/* ==========================================================================
   ... and lower
   ========================================================================== */
   else if( ivalue2 == 0 ) {

      pattern_value = pattern[ 0 ].patt;

   }
   else {

      ivalue1 = ivalue2 - 1;

/* ==========================================================================
   Execute the interpolation of value between [value1, value2]
   ========================================================================== */
      pattern_value = 
                  pattern[ ivalue1 ].patt +
                  ( (pattern[ ivalue2 ].patt - 
                     pattern[ ivalue1 ].patt)/
                    (pattern[ ivalue2 ].value - 
                     pattern[ ivalue1 ].value) * 
                    (value - pattern[ ivalue1 ].value) );

   
   }

/* ==========================================================================
   Scale to linear
   ========================================================================== */
   lut_value = POW( 10.0, pattern_value/10.0 );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return( lut_value );

}/* ICALLF_COMP_pattern */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_adc_comp

        $TYPE         PROCEDURE

        $INPUT        inp_io     : input image description
                      inp_ima_num
                                 : number identifing the input image annotations
                      TLRow      : the row image coordinate in the full
                                   reference frame of the image
                      TLCol      : the column image coordinate in the full
                                   reference frame of the image
                      nrow       : number of rows of the image
                      ncol       : number of columns of the image
                      calib_const: calibration constant
                      adc_correct_lut
                                 : ADC Correction lut
                      adc_correct_lut_no
                                 : number of pattern in the adc_correct_lut
                      out_io     : output image description

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute the ADC LUT image 

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void ICALPP_COMP_adc_comp
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ float                calib_const,
                         /*IN    */ ICALPT_pattern      *adc_correct_lut,
                         /*IN    */ UINTx4               adc_correct_lut_no,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_COMP_adc_comp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, column;
   void                  *imgline = (void *) NULL;
   float                 *outline;
   double                 tmpDouble;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow > IANNIV_ImageAnnot[ inp_ima_num ].ImageLength ) ||
        ( TLCol + ncol > IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth ) ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_start_stop_col_err, "" );
   }

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
   if( (outline = (float *) MEMSIP_alloc( (size_t) ncol *
                                                   sizeof(float) )) ==
       (float *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc, "outline" );
   }

/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol - 1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol - 1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Switch according to input image type
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_float:
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {

            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute lut pass
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {

               if( ((float *) imgline)[ column ] < ICALLD_underflow_float ) {
                           outline[ column ] = - ICALLD_overflow_float;
               }
               else {
                  tmpDouble = 
                     (20.0 * log10((double) (((float *) imgline)[ column ]))) -
                     (10.0 * log10((double) calib_const));

                  outline[ column ] = ICALLF_COMP_pattern( tmpDouble, adc_correct_lut,
                                         adc_correct_lut_no, status_code );
                  ERRSIM_on_err_goto_exit( *status_code );

               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;


      default:
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_data_type, 
            "inp_io->dt" );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &outline );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_COMP_adc_comp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_adc_lut_row_index

        $TYPE         PROCEDURE

        $INPUT        start_col  : index of starting column
                      ncol       : number of columns of the image
                      adc_ima_num
                                 : number identifing the ADC image annotations
                      inp_ima_num
                                 : number identifing the input image annotations

        $MODIFIED     NONE

        $OUTPUT       adc_lut_row_index
                                 : computed ADC lut row index

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute the ADC lut row index used by
                      ICALPP_COMP_adc_lut_row

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void ICALPP_COMP_adc_lut_row_index
                        (/*IN    */ UINTx4               start_col,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ UINTx1               adc_ima_num,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ UINTx4              *adc_lut_row_index,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_COMP_adc_lut_row_index";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 column, full_col, full_start_col,
                          adc_col, adc_start_col;
   UINTx4                 real_full_adc_tlcol, real_full_adc_trcol;
   UINTx4                 full_adc_tlcol, full_adc_trcol;


/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

#ifdef __TRACE1__
   fprintf( stderr, "column ADC Lut\n" );
#endif

   full_start_col = (UINTx4)
      ROUND( ((float) start_col / 
              IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor) ) +
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol;

   full_adc_tlcol =
      IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol -
      IANNIV_ImageAnnot[ adc_ima_num ].ColTransient;

   real_full_adc_tlcol =
      IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol;

   real_full_adc_trcol =  (UINTx4)
      ROUND( ((float) (IANNIV_ImageAnnot[ adc_ima_num ].ImageWidth - 1) /
              IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) ) + 
      IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol;

   full_adc_trcol =
      real_full_adc_trcol + 
      IANNIV_ImageAnnot[ adc_ima_num ].ColTransient -
      1;

   if( full_start_col < full_adc_tlcol ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut,
	 "coorners coordinates outside the ADC compensation image" );
   }
   else if( (full_start_col >= full_adc_tlcol) &&
	    (full_start_col <  real_full_adc_tlcol) ) {
      adc_start_col = 0;
   }
   else if( (full_start_col >= real_full_adc_tlcol) &&
	    (full_start_col <= real_full_adc_trcol) ) {
      adc_start_col = (UINTx4)
	 ROUND( ((float) (full_start_col - 
			  IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol) *
		 IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) );
   }
   else if( (full_start_col >  real_full_adc_trcol) &&
	    (full_start_col <= full_adc_trcol) ) {
      adc_start_col = (UINTx4)
	 ROUND( ((float) (real_full_adc_trcol - 
			  IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol) *
		 IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) );
   }
   else  {
      ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut,
	 "coorners coordinates outside the ADC compensation image" );
   }

#ifdef __TRACE1__
   fprintf( stderr,
      "start_col = %0d -> full_start_col = %0d -> adc_start_col = %0d\n",
      start_col, full_start_col, adc_start_col );
#endif

   for( column=0; column<ncol; column++ ) {

      full_col = (UINTx4)
         ROUND( ((float) (column+start_col) /
                 IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor) ) +
         IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol;

      if( full_col < full_adc_tlcol ) {
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut,
            "coorners coordinates outside the ADC compensation image" );
      }
      else if( (full_col >= full_adc_tlcol) &&
               (full_col <  real_full_adc_tlcol) ) {
         adc_col = 0;
      }
      else if( (full_col >= real_full_adc_tlcol) &&
               (full_col <= real_full_adc_trcol) ) {
         adc_col = (UINTx4)
            ROUND( ((float) (full_col - 
                             IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol) *
                    IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) );
      }
      else if( (full_col >  real_full_adc_trcol) &&
               (full_col <= full_adc_trcol) ) {
         adc_col = (UINTx4)
            ROUND( ((float) (real_full_adc_trcol - 
                             IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol) *
                    IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) );
      }
      else  {
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut,
            "coorners coordinates outside the ADC compensation image" );
      }

      adc_lut_row_index[ column ] = adc_col - adc_start_col;

#ifdef __TRACE1__
      fprintf( stderr, 
         "column = %0d -> full_col = %0d -> adc_col-adc_start_col = %0d\n", 
         column+start_col, full_col, adc_col-adc_start_col);
#endif

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_COMP_adc_lut_row_index */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_adc_lut_row

        $TYPE         PROCEDURE

        $INPUT        row        : number of image row
                      ncol       : number of columns of the image
                      adc_lut_direction
                                 : apply or null ADC lut
                      adc_io     : ADC image description
                      adc_ima_num
                                 : number identifing the ADC image annotations
                      inp_ima_num
                                 : number identifing the input image annotations
                      adc_lut_row_index
                                 : index of ADC lut row

        $MODIFIED     NONE

        $OUTPUT       adc_lut    : computed ADC lut

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute extract the row from and ADC lut

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void ICALPP_COMP_adc_lut_row
                        (/*IN    */ UINTx4               row,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ ICALIT_lut_direct    adc_lut_direction,
                         /*IN    */ GIOSIT_io           *adc_io,
                         /*IN    */ UINTx1               adc_ima_num,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4              *adc_lut_row_index,
                         /*   OUT*/ double              *adc_lut,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_COMP_adc_lut_row";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 column, full_row, adc_row;
   float                 *adc_line;
   UINTx4                 real_full_adc_tlrow, real_full_adc_trrow;
   UINTx4                 full_adc_tlrow, full_adc_trrow;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   If no adc lut is requested exit with neutral values
   ========================================================================== */
   if( adc_lut_direction == ICALIE_lut_none ) {
      for( column=0; column<ncol; column++ ) {
         adc_lut[ column ] = 1.0;
      }
   }
   else {
      full_row = (UINTx4)
         ROUND( ((float) row /
                 IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor) ) +
         IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow;
      

      full_adc_tlrow =
         IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftRow -
         IANNIV_ImageAnnot[ adc_ima_num ].RowTransient;

      real_full_adc_tlrow =
         IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftRow;

      real_full_adc_trrow =  (UINTx4)
         ROUND( ((float) (IANNIV_ImageAnnot[ adc_ima_num ].ImageLength - 1) /
                 IANNIV_ImageAnnot[ adc_ima_num ].YScalingFactor) ) + 
         IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftRow;

      full_adc_trrow =
         real_full_adc_trrow + 
         IANNIV_ImageAnnot[ adc_ima_num ].RowTransient -
         1;

      if( full_row < full_adc_tlrow ) {
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut,
            "coorners coordinates outside the ADC compensation image" );
      }
      else if( (full_row >= full_adc_tlrow) &&
               (full_row <  real_full_adc_tlrow) ) {
         adc_row = 0;
      }
      else if( (full_row >= real_full_adc_tlrow) &&
               (full_row <= real_full_adc_trrow) ) {
         adc_row = (UINTx4)
            ROUND( ((float) (full_row - 
                             IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftRow) *
                    IANNIV_ImageAnnot[ adc_ima_num ].YScalingFactor) );
      }
      else if( (full_row >  real_full_adc_trrow) &&
               (full_row <= full_adc_trrow) ) {
         adc_row = (UINTx4)
            ROUND( ((float) (real_full_adc_trrow - 
                             IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftRow) *
                    IANNIV_ImageAnnot[ adc_ima_num ].YScalingFactor) );
      }
      else  {
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut,
            "coorners coordinates outside the ADC compensation image" );
      }


#ifdef __TRACE1__
      fprintf( stderr, "row = %0d -> full_row=%0d -> adc_row=%0d\n", 
         row, full_row, adc_row);
#endif

      GIOSIP_read_line( adc_io, adc_row, 0, (void *) &adc_line, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      for( column=0; column<ncol; column++ ) {

         adc_lut[ column ] = adc_line[ adc_lut_row_index[ column ] ];

      }

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_COMP_adc_lut_row */
