/* ==========================================================================
   $MODULE_HEADER

      $NAME              MATH_ROOF

      $FUNCTION          This module contains the routines for the numerical
                         resolution of non linear systems of equations. They
                         are masks to use the Numerical Recipes routines.

      $ROUTINE           MATHIP_ROOF_Newton

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       11-APR-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */


#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_NREC_H
#include MATH_INTF_H
#include MATH_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_ROOF_Newton

        $TYPE         PROCEDURE

        $INPUT        ntrial : maximum number of Newton-Raphson steps to improve
                               the root
                      n      : dimensions of the root
                      usrfun : pointer to the user defined function to evaluate
                               the first derivatives of the equations
                      tolx   : tolerance to stop the iteration WRT the summed
                               absolute variables increments
                      tolf   : tolerance to stop the iteration WRT the summed
                               absolute functions values

        $MODIFIED     x      : initial guess x[n] for an n-dimensional root. In
                               output x is the final root

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSIM_MATH_num_err

        $DESCRIPTION  This procedure initializes the variables to pass to the
                      Numerical Recipes's procedure mnewt, that solves
                      numerically a system of non linear equations

        $WARNING      The routine uses an user function defined as void usrfun()
                      that must be declared by the user.

        $PDL

   $EH
   ========================================================================== */

void MATHIP_ROOF_Newton
                        (/*IN    */ INTx4                ntrial,
                         /*IN    */ INTx4                n,
                         /*IN    */ void               (*usrfun)(),
                         /*IN    */ double               tolx,
                         /*IN    */ double               tolf,
                         /*IN OUT*/ double              *x,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_ROOF_Newton";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  status;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

/* ==========================================================================
   Error variable initialization
   ========================================================================== */
   status          = 0;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Calls the Num. Rec. procedure mnewt with the arrays decremented to be
   one-offset
   ========================================================================== */
   dmnewt(ntrial,x-1,n,usrfun,tolx,tolf,&status);
   if (status) {
      if (status == 2)                /* memory allocation error */
         ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");

      /* singular matrix in the LU decomposition */
      ERRSIM_set_error(status_code,ERRSID_MATH_num_err,
                       "Singular matrix in the LUD");
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_ROOF_Newton */
