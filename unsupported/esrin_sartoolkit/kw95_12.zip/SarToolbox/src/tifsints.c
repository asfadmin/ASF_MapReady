/* ==========================================================================
   $MODULE_HEADER

      $NAME              TIFS_INTS

      $FUNCTION          TIFF INTernal Service

      $ROUTINE           

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       07-JAN-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <string.h>
#include <ctype.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include TIFS_INTF_H
#include TIFS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_disp_evaluate

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
		      img: image number

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Calcola a seconda del parametro DISPOSITION come disporre 
                      i blocchi su disco

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSPP_disp_evaluate
			( /*IN    */ INTx4  	      chan,
                          /*IN    */ INTx4            img,
			  /*   OUT*/ ERRSIT_status *status_code)
{
   const ERRSIT_proc_name routine_name = "TIFSPP_disp_evaluate";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4      		  nb;
   UINTx4                 i;
   UINTx4                 j;
   UINTx4                 k;
   UINTx4                 base;
   UINTx4                 nx;
   UINTx4                 ny;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);


   /* i blocchi sono SEMPRE numerati nel vettore blockoffs e blocksize come

         0         1           2                          nx -1
        ------------------------------------------------------------- x
 0     | 0         1           2          ............    nx -1
 1     | nx        nx+1        nx+2       ............    2*nx-1
 2     | 2*nx      2*nx+1      2*nx+2     ............    3*nx-1
       |
       |
       | .......................................................
       | .......................................................
       | .......................................................
       |
       |
  ny-1 | (ny-1)*nx (ny-1)*nx+1 (ny-1)*nx+2  ............  ny*nx-1  
       |
       
       y

   Percio' nel vettore blockoffs o blocksize, l'elemento nx-1 si riferisce
   sempre al blocco */

   /* numero bytes per blocco non compresso */
   nb=TIFSPV_gid[chan].blockcol[img]*TIFSPV_gid[chan].blockrig[img]*
      TIFSPV_gid[chan].sampix[img]*(TIFSPV_gid[chan].bitsam[img][0]/8);

   /* numero di blocchi nella direzione x nell'immagine */
   nx=(TIFSPV_gid[chan].imgcol[img]+TIFSPV_gid[chan].blockcol[img]-1)/
                                                TIFSPV_gid[chan].blockcol[img];

   /* numero di blocchi nella direzione y nell'immagine */
   ny=(TIFSPV_gid[chan].imgrig[img]+TIFSPV_gid[chan].blockrig[img]-1)/
                                                TIFSPV_gid[chan].blockrig[img];

   /* Base e' il primo byte libero su disco dopo blockoffs */
   base=TIFSPV_gid[chan].freeptr; /* primo byte libero attualmente */

   if(TIFSPV_gid[chan].nblock[img]!=1) {    /* nel caso di un blocco blockoffs viene scritto nella ifd */
      base+= 4*TIFSPV_gid[chan].nblock[img]; /* primo byte libero dopo blockoffs */
   }

   switch(tolower(TIFSPV_gid[chan].disp[img])) {

      case 'x': 
      /* Blocchi disposti lungo x.
    
       Nel file i blocchi si presentano per righe:

       0		riga 0
       1
       2
       .
       .
       nx-1

       nx		riga 1
       nx+1
       nx+2
       .
       .
       .
       2*nx-1

       2*nx		riga 2
       2*nx+1
       2*nx+2
       .
       .
       .
       3*nx-1
       
       .
       .
       .
       .
       .
       .
       .
       
       (ny-1)*nx	riga ny-1
       (ny-1)*nx+1
       (ny-1)*nx+2       
       .
       .
       .
       ny*nx-1  */

	 k=0;
	 for(i=0;i<ny;i++) {
	    for(j=0;j<nx;j++) {
	       TIFSPV_gid[chan].blockoffs[img][j+i*nx]=base+k*nb;
	       k++;
	    }
	 }
	 break;

      case 'y': 
      /* Blocchi disposti lungo y.
       
       Nel file i blocchi si presentano per colonne:
       
       0		colonna 0
       nx
       2*nx
       .
       .
       (ny-1)*nx

       1		colonna 1
       nx+1
       2*nx+1
       .
       .
       .
       (ny-1)*nx+1

       2		colonna 2
       nx+2
       2*nx+2
       .
       .
       .
       (ny-1)*nx+2

       .
       .
       .
       .
       .
       .
       .
       
       (ny-1)*nx	colonna nx-1
       (ny-1)*nx+1
       (ny-1)*nx+2
       .
       .
       .
       ny*nx-1  */

	 k=0;
	 for(j=0;j<nx;j++) {
	    for(i=0;i<ny;i++) {
	       TIFSPV_gid[chan].blockoffs[img][j+i*nx]=base+k*nb;
	       k++;
	    }
	 }
	 break;

    /* se non e' specificato nulla c'e' un errore */
      default :
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_no_disp,
			   TIFSPV_gid[chan].name );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSPP_disp_evaluate */





/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPF_get_block

        $TYPE         FUNCTION

        $INPUT        chan: TIFF channel number
                      img: img number
                      block: block number

        $MODIFIED     NONE

        $OUTPUT       buf: pointer to buffer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Legge un blocco da un immagine

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
INTx4 TIFSPF_get_block
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ INTx4                block,
                         /*   OUT*/ void                *buf,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSPF_get_block";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4      		  pixsize; /* size in bytes of pixel */
   UINTx4      		  pixno; /* number of pixel */
   UINTx4      		  size; /* size di ritorno dal decompressore. 
                                   Non usato */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* nessun controllo sul numero di canale  
                        numero di immagine
                        necessita' che sia gia' stata chiamata 
                        la get_blockinfo
			compressione permessa (1 o 5)  */
			  
   if(block>=TIFSPV_gid[chan].nblock[img]) {
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_no_block,
			TIFSPV_gid[chan].name );
   }
   /* posizionamento sul blocco */
   if(fseek(TIFSPV_gid[chan].tf, (INTx8) (*(TIFSPV_gid[chan].blockoffs[img]+block)), 0)){
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_on_fseek,
			TIFSPV_gid[chan].name );
   }

   if(TIFSPV_gid[chan].compression[img]==1) { /* no compresssion */
      pixsize = (TIFSPV_gid[chan].bitsam[img][0]/8);
      if( ( TIFSPV_gid[chan].swap_byte == 1 ) &&
          ( pixsize > 1 ) ) {
	 pixno = *(TIFSPV_gid[chan].blocksize[img]+block)/pixsize;
	 TIFSPF_readandswap(buf, pixsize, pixno,
                            TIFSPV_gid[chan].tf, TIFSPV_gid[chan].swap_byte );
      }
      else {
	 fread(buf,*(TIFSPV_gid[chan].blocksize[img]+block),1,TIFSPV_gid[chan].tf); 
                                                         /* lettura blocco */
      }
      TIFSPV_gid[chan].actptr+= *(TIFSPV_gid[chan].blocksize[img]+block);
   }    
   else if(TIFSPV_gid[chan].compression[img]==5) { /* LZW compresssion */
      fread(TIFSPV_gid[chan].lzwbuf[img],*(TIFSPV_gid[chan].blocksize[img]+block),1,TIFSPV_gid[chan].tf);
#ifdef PLAPLA
    if( TIFSPV_gid[chan].swap_byte == 1 ) {
    }
#endif
      /* decomprime il buffer di ingresso lzwbuf in quello di uscita */
      TIFSPP_LZWdecode( TIFSPV_gid[chan].lzwbuf[img],
                       *(TIFSPV_gid[chan].blocksize[img]+block),
                        buf,
                       &size,
                        status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

   /* aggiornamento prossima posizione libera */
   TIFSPV_gid[chan].actptr= *(TIFSPV_gid[chan].blockoffs[img]+block)+ /* fseek */ 
		     *(TIFSPV_gid[chan].blocksize[img]+block); /* fread */


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   if( *status_code != ERRSID_normal ) {
      return( 1 );
   }
   else {
      return( 0 );
   }

}/* TIFSPF_get_block */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPF_store_block

        $TYPE         FUNCTION

        $INPUT        chan: TIFF channel number
                      img: img number
                      block: block number
                      buf: pointer to buffer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Scrive un blocco in un immagine

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   INTx4 TIFSPF_store_block
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ INTx4                block,
                         /*IN    */ void                *buf,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSPF_store_block";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 nb,cmprsize;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* nessun controllo sul numero di canale  
                        numero di immagine
                        necessita' che sia gia' stata chiamata 
                        la set_blockinfo
			compressione permessa (1 o 5)  */

   if(block>=TIFSPV_gid[chan].nblock[img]) {
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_no_block,
                        TIFSPV_gid[chan].name );
   }

   /* Se non c'e' compressione la posizione su cui salvare il blocco e la sua
      dimensione e' fissata. Fai un seek su tale posizione e salva */
   if(TIFSPV_gid[chan].compression[img]==1) {
      /* Posizionamento sul blocco */
      /* Per sfruttare bene la cache, fai il seek solo se il file pointer non e'
	 gia' nella posizione giusta */
      if(TIFSPV_gid[chan].actptr!=TIFSPV_gid[chan].blockoffs[img][block]) {
	 if(fseek(TIFSPV_gid[chan].tf, 
                  (INTx8)(TIFSPV_gid[chan].blockoffs[img][block]), 0)) {
	    ERRSIM_set_error( status_code,
			      ERRSID_TIFS_err_on_fseek,
			      TIFSPV_gid[chan].name );
         }
	 TIFSPV_gid[chan].actptr=TIFSPV_gid[chan].blockoffs[img][block];      
      }
      /* scrittura blocco */
      if( fwrite(buf,TIFSPV_gid[chan].blocksize[img][block],
                 1,TIFSPV_gid[chan].tf) < 1 ) {
         ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
            TIFSPV_gid[chan].name );
      }

      TIFSPV_gid[chan].actptr+=TIFSPV_gid[chan].blocksize[img][block];
   }

   /* Se c'e' compressione bisogna memorizzare la dimensione del blocco nel 
      parametro blocksize e l'offset nel parametro blockoffset, fare un seek
      alla zona libera e poi salvare. I vettori di blocksize e blockoffset
      saranno salvati al close */

   else if(TIFSPV_gid[chan].compression[img]==5) { /* LZW compresssion */

      /* numero di bytes del blocco non compresso */
      nb=TIFSPV_gid[chan].blockcol[img]*TIFSPV_gid[chan].blockrig[img]*
	 TIFSPV_gid[chan].sampix[img]*(TIFSPV_gid[chan].bitsam[img][0]/8);

      /* comprime il buffer di ingresso in quello di uscita lzwbuf */
      TIFSPP_LZWencode( buf,
                        nb,
                        TIFSPV_gid[chan].lzwbuf[img],
                       &cmprsize,
		        status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      /* memorizza come size quello del blocco compresso (variabile da blocco 
         a blocco */
      *(TIFSPV_gid[chan].blocksize[img]+block)=cmprsize;

      /* memorizzazione offset */
      *(TIFSPV_gid[chan].blockoffs[img]+block)=TIFSPV_gid[chan].freeptr;

      /* posizionamento sul prossimo byte libero */
      if( fseek(TIFSPV_gid[chan].tf, (INTx8)(TIFSPV_gid[chan].freeptr), 0) ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_on_fseek,
			   TIFSPV_gid[chan].name );
      }

      /* scrittura blocco */
      if( fwrite(TIFSPV_gid[chan].lzwbuf[img], *(TIFSPV_gid[chan].blocksize[img]+block),
                 1,TIFSPV_gid[chan].tf) < 1 ) {
         ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
            TIFSPV_gid[chan].name );
      }

      TIFSPV_gid[chan].actptr=TIFSPV_gid[chan].freeptr+ *(TIFSPV_gid[chan].blocksize[img]+block);

      /* aggiornamento prossima posizione libera */
      TIFSPV_gid[chan].freeptr+= *(TIFSPV_gid[chan].blocksize[img]+block);

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   if( *status_code != ERRSID_normal ) {
      return( 1 );
   }
   else {
      return( 0 );
   }

}/* TIFSPF_store_block */

 

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_ifd_reorder

        $TYPE         FUNCTION

        $INPUT        img: image number

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Riordinatore della ifd: tag riordinati in senso 
		      ascendente

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSPP_ifd_reorder
                        (/*IN    */ INTx4                chan,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSPP_ifd_reorder";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4		  img,j,base,imin;
   UINTx2        	  min,tag;
   UINTx1       	  ifd[12];
   UINTx2                 npar_actw; /* number of tags written effectively; can be less 
                                    than TIFSPV_gid[chan].npar[img] if less tags are 
                                    stored respect the number specified with set_parnum;
                                    used for TTFF files in write mode only */


/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   modified 23.09.97 by EL to avoid that in a TTFF file in write mode, are
   stored tags set to zero, when the number of tag effectilvely written is
   less that the number of parameters specified with set_parnum
   ========================================================================== */

   for(img=0;img<TIFSPV_gid[chan].nimg;img++) {
      npar_actw=TIFSPV_gid[chan].ifd[img]; /* this is the true number of stored tags */
      for(base=0;base<npar_actw-1;base++) {
	 min=65535;  
	 for(j=base;j<npar_actw;j++) {
	    tag= *(UINTx2 *)(TIFSPV_gid[chan].imgpar[img]+j*12);
	    if(tag<min) {
	       min=tag;
	       imin=j;
	    }
	 }

	 if(imin!=base) { /* swap le due ifd */
	    for(j=0;j<12;j++) ifd[j]= *(TIFSPV_gid[chan].imgpar[img]+base*12+j);
	    for(j=0;j<12;j++) *(TIFSPV_gid[chan].imgpar[img]+base*12+j)=
                                     *(TIFSPV_gid[chan].imgpar[img]+imin*12+j);
	    for(j=0;j<12;j++) *(TIFSPV_gid[chan].imgpar[img]+imin*12+j)=ifd[j];
	 }
      }
   }
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* TIFSPP_ifd_reorder */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_check_tiff

        $TYPE         PROCEDURE

        $INPUT        chan: TIFF open channel

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Controlla che il file sia TIFF e si posiziona sulla 
                      prima IFD

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSPP_check_tiff
			( /*IN    */ INTx4	          chan,
			  /*   OUT*/ ERRSIT_status       *status_code  )
{
   const ERRSIT_proc_name routine_name = "TIFSPP_check_tiff";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx2        	  byte_order,tiff_vers;
   UINTx4      		  ifd_offs;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Read Bytes 0-1
   ========================================================================== */
   fread(&byte_order, sizeof(UINTx2),1,TIFSPV_gid[chan].tf);

   if(byte_order==18761) {
#ifdef __SWAP__
      TIFSPV_gid[chan].swap_byte = 1;
#else
      TIFSPV_gid[chan].swap_byte = 0;
#endif
   }
   else if( byte_order == 19789 ) {
#ifdef __SWAP__
      TIFSPV_gid[chan].swap_byte = 0;
#else
      TIFSPV_gid[chan].swap_byte = 1;
#endif
   }
   else
   {
      TIFSPV_gid[chan].used=0; /* frees the channel 'cause is not really used */ 
      ERRSIM_set_error( status_code,
		        ERRSID_TIFS_err_not_tif,
                        "");
   }

   TIFSPF_readandswap((void *) &tiff_vers, sizeof(UINTx2), 1, 
                      TIFSPV_gid[chan].tf, TIFSPV_gid[chan].swap_byte);
   TIFSPF_readandswap((void *) &ifd_offs, sizeof(UINTx4), 1,
                      TIFSPV_gid[chan].tf, TIFSPV_gid[chan].swap_byte);

   if( tiff_vers != 42 ) {
      TIFSPV_gid[chan].used=0; /* frees the channel 'cause is not really used */ 
      ERRSIM_set_error( status_code,
		        ERRSID_TIFS_err_not_tif,
                        "");
   }

   if( fseek(TIFSPV_gid[chan].tf, (INTx8) ifd_offs, 0) ) {
      TIFSPV_gid[chan].used=0; /* frees the channel 'cause is not really used */ 
      ERRSIM_set_error( status_code,
		        ERRSID_TIFS_err_on_fseek,
                        "");
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* TIFSPP_check_tiff */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_find_chan

        $TYPE	      PROCEDURE

        $INPUT        namefile: TIFF open file name

        $MODIFIED     NONE

        $OUTPUT       chan: TIFF open channel

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Trova il canale relativo ad un file specificato dal nome 

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSPP_find_chan	( /*IN    */ char                *namefile,
                          /*   OUT*/ INTx4	         *chan,
			  /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSPP_find_chan";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
   for(*chan=0;*chan<MAX_FILES;(*chan)++) {
      /* solo se il nome corrisponde ed il file e' in uso */
      if((!strcmp(TIFSPV_gid[*chan].name,namefile))&&(TIFSPV_gid[*chan].used==1)) break;
   }
   if(*chan==MAX_FILES) {
      ERRSIM_set_error( status_code,
		        ERRSID_TIFS_err_isn_opn_tif,
                        namefile );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* TIFSPP_find_chan */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPF_readandswap

        $TYPE         FUNCTION

        $INPUT        size: size of pointer
                      nitems: number of size pointer
		      stream: poiter to FILE

        $MODIFIED     NONE

        $OUTPUT       ptr: pointer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Same as fread

        $WARNING      NONE

   $EH
   ========================================================================== */
INTx4 TIFSPF_readandswap ( /*   OUT*/ void          *ptr,
                           /*IN    */ INTx4          size,
                           /*IN    */ INTx4          nitems,
                           /*IN    */ FILE          *stream,
                           /*IN    */ char           swap_byte )
{
   INTx4                  k,tmpret;
   char                  *tmpptr;
   char                   tmp;

   if( swap_byte == 0) {
      return( fread((char *) ptr,size,nitems,stream) );
   }
   else {
      tmpret = fread((char *) ptr,size,nitems,stream); 
      tmpptr = (char *) ptr;

      for(k=0; k<tmpret; k++, tmpptr+=size ) {
         if( size == 1 ) {
	    /* do nothing */
         }
	 else if( size == 2 ) {
	    tmp = ((char *) tmpptr)[ 0 ];
	    ((char *) tmpptr)[ 0 ] = ((char *) tmpptr)[ 1 ];
	    ((char *) tmpptr)[ 1 ] = tmp;
	 }
	 else if( size == 4 ) {
	    tmp = ((char *) tmpptr)[ 0 ];
	    ((char *) tmpptr)[ 0 ] = ((char *) tmpptr)[ 3 ];
	    ((char *) tmpptr)[ 3 ] = tmp;

	    tmp = ((char *) tmpptr)[ 1 ];
	    ((char *) tmpptr)[ 1 ] = ((char *) tmpptr)[ 2 ];
	    ((char *) tmpptr)[ 2 ] = tmp;
	 }
	 else if( size == 8 ) {
	    tmp = ((char *) tmpptr)[ 0 ];
	    ((char *) tmpptr)[ 0 ] = ((char *) tmpptr)[ 3 ];
	    ((char *) tmpptr)[ 3 ] = tmp;

	    tmp = ((char *) tmpptr)[ 1 ];
	    ((char *) tmpptr)[ 1 ] = ((char *) tmpptr)[ 2 ];
	    ((char *) tmpptr)[ 2 ] = tmp;

	    tmp = ((char *) tmpptr)[ 4 ];
	    ((char *) tmpptr)[ 4 ] = ((char *) tmpptr)[ 7 ];
	    ((char *) tmpptr)[ 7 ] = tmp;

	    tmp = ((char *) tmpptr)[ 5 ];
	    ((char *) tmpptr)[ 5 ] = ((char *) tmpptr)[ 6 ];
	    ((char *) tmpptr)[ 6 ] = tmp;
	 }
         else {
	    fprintf( stdout, "\n\nCannot swap size = %d\n", size);
         }
      }
      return( tmpret );
   }

}/* TIFSPF_readandswap */
