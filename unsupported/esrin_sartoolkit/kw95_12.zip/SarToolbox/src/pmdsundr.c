/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_UNDR

      $FUNCTION          

      $ROUTINE           PMDSPP_UNDR_ConvCoreConstKern

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       01-OCT-97     DDN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#ifdef __UNIX__
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#endif
#include <string.h>
#include <ctype.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include TIFS_INTF_H
#include IANN_INTF_H
#include GIOS_INTF_H
#include SRVS_INTF_H
#include OVLS_INTF_H
#include PMDS_INTF_H
#include PMDS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
 
   $ROUTINE_HEADER
 
        $NAME         PMDSPP_UNDR_ConvCoreConstKern
 
        $TYPE         PROCEDURE
 
        $INPUT        nrow_inp      : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
                      RStartR       : start row in the input image reference
                                      system of the image block passed at the
                                      current procedure
                      StepR         : step size in the rows direction
                      StepC         : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern          : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr            : rows' kernel size
                      Kc            : columns' kernel size
                      InpIma        : pointer to the pointer to the input image
                                      block
                      RStartW       : start row to write the output image
                      RStopW        : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan      : channel of the output TIFF image
                      out_img       : image number of the output TIFF image
                      fill_val      : float value of initial skip in line
 
        $MODIFIED     NONE
 
        $OUTPUT       The output file is written
 
        $GLOBAL       NONE
 
        $RET_STATUS   ERRSID_PMDS_kernel_dim_high
                      ERRSID_PMDS_bad_steps
                      ERRSID_PMDS_bad_write_size
                      ERRSID_PMDS_err_mem_alloc
                      ERRSID_PMDS_not_under_allow
 
        $DESCRIPTION  This procedure convolves the constant kernel given in
                      input with the image block also given and writes the
                      output in the file passed by its channel and img parameter
 
        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.
 
        $PDL          - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
                                        - Sum the window element
                                        - Fill the output vector rescaling it
                                          by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch
 
   $EH
   ========================================================================== */
 
void PMDSPP_UNDR_ConvCoreConstKern
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_UNDR_ConvCoreConstKern";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;
 
/* ==========================================================================
   Utility variables
   ========================================================================== */
   void                 **IntInpIma = (void **) NULL;
   UINTx4                 rs;
   UINTx4                 cs;
   UINTx4                 RStart;
   UINTx4                 CStart;
   float                 *OutIma = (float *)NULL;
   float                  k;
   float                  val;
   REGISTER UINTx2        i;
   REGISTER UINTx2        j;
   REGISTER float         OutPoint;
   REGISTER UINTx1       *p_uintx1 = (UINTx1 *)NULL;
   REGISTER INTx2        *p_intx2 = (INTx2 *)NULL;
   INTx2                  p1_intx2;
   INTx2                  p2_intx2;
   REGISTER UINTx2       *p_uintx2 = (UINTx2 *)NULL;
   REGISTER float        *p_float = (float *)NULL;
   INTx4                  skip, bytes_data_size;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );
 
   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);
 
/* ==========================================================================
   Check the kernel sizes consistency
   ========================================================================== */
   if ( ( Kr > nrow_inp ) || ( Kc > ncol_inp ) )
      ERRSIM_set_error( status_code, ERRSID_PMDS_kernel_dim_high, "" );
 
/* ==========================================================================
   Check the steps values
   ========================================================================== */
   if((StepR < 1.) || (StepC < 1.))
      ERRSIM_set_error(status_code, ERRSID_PMDS_bad_steps, "");
 
/* ==========================================================================
   Check the writing counters
   ========================================================================== */
   if(RStartW > RStopW)
      ERRSIM_set_error(status_code, ERRSID_PMDS_bad_write_size, "");
 
/* ==========================================================================
   Get initial bytes skip from fill_val variable
   ========================================================================== */
   skip = (INTx4) fill_val;
   IntInpIma = (void **) MEMSIP_alloc( nrow_inp * sizeof(void *) );
   if( IntInpIma == (void **) NULL )
   {
      ERRSIM_set_error( status_code, ERRSID_PMDS_err_mem_alloc, "" );
   }
   switch(inp_data_type)
   {
      case LDEFIE_dt_UINTx1:
         bytes_data_size = ncol_inp;
         break;
      case LDEFIE_dt_2_INTx2:
         bytes_data_size = 2* ncol_inp * 2;
         break;
      case LDEFIE_dt_UINTx2:
         bytes_data_size = ncol_inp * 2;
         break;
   }

   for( rs=0; rs<nrow_inp; rs++)
   {
      IntInpIma[ rs ] = (((UINTx1 **) InpIma)[ rs ]) + skip;
      PMDSPP_AdjustImageLine( IntInpIma[ rs ],
                              bytes_data_size,
                              PMDSPV_prod_data_type );
   }

/* ==========================================================================
   Copy the kernel value in a variable
   ========================================================================== */
   k = Kern[0][0];
 
/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
   if((OutIma = (float *)
      MEMSIP_alloc((size_t)(ncol_out * sizeof(float)))) == (float *)NULL)
   {
      ERRSIM_set_error(status_code, ERRSID_PMDS_err_mem_alloc, "");
   }

/* ==========================================================================
   Switch the various input types
   ========================================================================== */
   switch(inp_data_type)
   {
      case LDEFIE_dt_UINTx1:
/* ==========================================================================
         Start the moving windowing
   ========================================================================== */
         for(rs = RStartW; rs <= RStopW; rs++)
         {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
            Rows' step loop
   ========================================================================== */
            for(cs = 0; cs < ncol_out; cs++)
            {
/* ==========================================================================
               Columns' step loop
   ========================================================================== */
               RStart = (UINTx4) ROUND(rs * StepR) - RStartR;
               CStart = (UINTx4) ROUND(cs * StepC);
/* ==========================================================================
               Convolution core
   ========================================================================== */
               OutPoint = 0.;
               for(i = 0; i < Kr; i++)
               {
                  /* point to the beginning of the matrices rows */
                  p_uintx1 = &((UINTx1 **)IntInpIma)[RStart + i][CStart] - 1;
 
                  /* internal convolution loop */
                  for(j = 0; j < Kc; j++)
                     OutPoint += (float)*++p_uintx1;
               }
/* ==========================================================================
               Fill the output vector
   ========================================================================== */
               OutIma[cs] = OutPoint * k;
            }
/* ==========================================================================
            Write the output line
   ========================================================================== */
            GIOSIP_write_line(out_io, rs, (void *)OutIma, status_code);
            ERRSIM_on_err_goto_exit(*status_code);
         }
         break;
      case LDEFIE_dt_2_INTx2:
/* ==========================================================================
         Start the moving windowing
   ========================================================================== */
         for(rs = RStartW; rs <= RStopW; rs++)
         {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
            Rows' step loop
   ========================================================================== */
            for(cs = 0; cs < ncol_out; cs++)
            {
/* ==========================================================================
               Columns' step loop
   ========================================================================== */
               RStart = (UINTx4) ROUND(rs * StepR) - RStartR;
               CStart = (UINTx4) ROUND(cs * StepC);

/* ==========================================================================
               Convolution core
   ========================================================================== */
               OutPoint = 0.;
               for(i = 0; i < Kr; i++)
               {
                  /* point to the beginning of the matrices rows */
                  p_intx2 = &((INTx2 **)IntInpIma)[RStart + i][CStart * 2] - 1;
 
                  for(j = 0; j < Kc; j++)
                  {
                     /* internal convolution loop */
                     p_intx2++;
                     p1_intx2 = *p_intx2;
                     p_intx2++;
                     p2_intx2 = *p_intx2;

                     val = (float)(sqrt((double)(p1_intx2 * p1_intx2) +
                                        (double)(p2_intx2 * p2_intx2)));
                     OutPoint += val;
                  }
               }
/* ==========================================================================
               Fill the output vector
   ========================================================================== */
               OutIma[cs] = OutPoint * k;
            }
/* ==========================================================================
            Write the output line
   ========================================================================== */
            GIOSIP_write_line(out_io, rs, (void *)OutIma, status_code);
            ERRSIM_on_err_goto_exit(*status_code);
         }
         break;
      case LDEFIE_dt_UINTx2:
/* ==========================================================================
         Start the moving windowing (PRI)
   ========================================================================== */
         for(rs = RStartW; rs <= RStopW; rs++)
         {

            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
            Rows' step loop
   ========================================================================== */
            for(cs = 0; cs < ncol_out; cs++)
            {

/* ==========================================================================
               Columns' step loop
   ========================================================================== */
               RStart = (UINTx4) ROUND(rs * StepR) - RStartR;
               CStart = (UINTx4) ROUND(cs * StepC);
/* ==========================================================================
               Convolution core
   ========================================================================== */
               OutPoint = 0.;
               for(i = 0; i < Kr; i++)
               {
                  /* point to the beginning of the matrices rows */
                  p_uintx2 = &((UINTx2 **)IntInpIma)[RStart + i][CStart] - 1;
 
                  /* internal convolution loop */
                  for(j = 0; j < Kc; j++)
                     OutPoint += (float)(*++p_uintx2);
               }
/* ==========================================================================
               Fill the output vector
   ========================================================================== */
               OutIma[cs] = OutPoint * k;
            }
/* ==========================================================================
            Write the output line
   ========================================================================== */
            GIOSIP_write_line(out_io, rs, (void *)OutIma, status_code);
            ERRSIM_on_err_goto_exit(*status_code);

         }
         break;
      default:
         ERRSIM_set_error(status_code, ERRSID_PMDS_not_under_allow, "");
   }
 
error_exit:;
 
/* ==========================================================================
   Free the output vector memory
   ========================================================================== */
   MEMSIP_free((void **)(&OutIma));
   MEMSIP_free((void **)(&IntInpIma));
 
   ERRSIM_close_routine( routine_name,
                         &process_flag,
                         *status_code,
                         &log_status_code);
 
 
}/* PMDSPP_UNDR_ConvCoreConstKern */
 
 
