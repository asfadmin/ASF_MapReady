/* ==========================================================================
   $MODULE_HEADER

      $NAME              MATH_STYP

      $FUNCTION          This module has all the routines that do operations
                         between the super types defined expressely for STBX

      $ROUTINE           MATHIP_STYP_RCSum
                         MATHIP_STYP_RCSubt
                         MATHIP_STYP_RCScalProd
                         MATHIP_STYP_RCModu
                         MATHIP_STYP_RCVers
                         MATHIP_STYP_XYZSum
                         MATHIP_STYP_XYZSubt
                         MATHIP_STYP_XYZScalProd
                         MATHIP_STYP_XYZCrosProd
                         MATHIP_STYP_XYZModu
                         MATHIP_STYP_XYZVers
                         MATHIP_STYP_CSum
                         MATHIP_STYP_CSubt
                         MATHIP_STYP_CProd
                         MATHIP_STYP_CConstMult
                         MATHIP_STYP_CConj
                         MATHIP_STYP_CModu
                         MATHIP_STYP_CReal
                         MATHIP_STYP_CImag
                         MATHIP_STYP_CPhase
                         MATHIP_STYP_CExp
 
   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       22-APR-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <math.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include MATH_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_RCSum

        $TYPE         PROCEDURE

        $INPUT        a:    the first row,column vector to sum
                      b:    the second row,column vector to sum

        $MODIFIED     NONE

        $OUTPUT       c:    the row,column vector sum of the two given in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure sums together two image coordinates
                      vectors

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_RCSum
                        (/*IN    */ MATHIT_RC           a,
                         /*IN    */ MATHIT_RC           b,
                         /*   OUT*/ MATHIT_RC          *c,
                         /*   OUT*/ ERRSIT_status      *status_code)
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_RCSum";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Sum the vectors
   ========================================================================== */
   c->row = a.row + b.row;
   c->col = a.col + b.col;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_RCSum */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_RCSubt

        $TYPE         PROCEDURE

        $INPUT        a:    the first row,column vector to subtract
                      b:    the second row,column vector to subtract

        $MODIFIED     NONE

        $OUTPUT       c:    the row,column vector difference of the two given
                            in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure subtracts together two image coordinates
                      vectors

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_RCSubt
                        (/*IN    */ MATHIT_RC           a,
                         /*IN    */ MATHIT_RC           b,
                         /*   OUT*/ MATHIT_RC          *c,
                         /*   OUT*/ ERRSIT_status      *status_code)
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_RCSubt";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Subtract the vectors
   ========================================================================== */
   c->row = a.row - b.row;
   c->col = a.col - b.col;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_RCSubt */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_RCScalProd

        $TYPE         PROCEDURE

        $INPUT        a:    the first vector of the scalar product
                      b:    the second vector of the scalar product

        $MODIFIED     NONE

        $OUTPUT       c:    the scalar product of the two vectors given
                            in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure do the scalar product of two image
                      vectors given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_RCScalProd
                        (/*IN    */ MATHIT_RC            a,
                         /*IN    */ MATHIT_RC            b,
                         /*   OUT*/ double              *c,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_RCScalProd";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Sum the elements products
   ========================================================================== */
   *(c) = a.row*b.row + a.col*b.col;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_RCScalProd */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_RCModu

        $TYPE         PROCEDURE

        $INPUT        a:    the image vector of which the modulus is nedeed

        $MODIFIED     NONE

        $OUTPUT       modu: the vector modulus

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the modulus of the image vector
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_RCModu
                        (/*IN    */ MATHIT_RC            a,
                         /*   OUT*/ double              *modu,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_RCModu";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Modulus evaluation
   ========================================================================== */
   *(modu) = sqrt( POW( a.row, 2.) + POW( a.col, 2.) );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_RCModu */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_RCVers

        $TYPE         PROCEDURE

        $INPUT        a:    the vector of which the versor is needed

        $MODIFIED     NONE

        $OUTPUT       v:    the versor of a

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_modu

        $DESCRIPTION  This procedure evaluates the versor of the image vector
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_RCVers
                        (/*IN    */ MATHIT_RC            a,
                         /*   OUT*/ MATHIT_RC           *v,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_RCVers";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   double                 modu;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Evaluate the modulus
   ========================================================================== */
   MATHIP_STYP_RCModu( a, &modu, status_code);

   /* error check */
   if ( modu == 0.) {

      /* return the versor zeroed */
      v->row = 0.;
      v->col = 0.;

      /* error managing */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_modu,"");
   }

/* ==========================================================================
   Evaluate the versor
   ========================================================================== */
   v->row = a.row / modu;
   v->col = a.col / modu;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_RCVers */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZSum

        $TYPE         PROCEDURE

        $INPUT        a:    the first cartesian vector to sum
                      b:    the second cartesian vector to sum

        $MODIFIED     NONE

        $OUTPUT       c:    the cartesian vector sum of the two given in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure sums together two cartesian coordinates
                      vectors

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_XYZSum
                        (/*IN    */ MATHIT_XYZ           a,
                         /*IN    */ MATHIT_XYZ           b,
                         /*   OUT*/ MATHIT_XYZ          *c,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_XYZSum";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Sum the vectors
   ========================================================================== */
   c->x = a.x + b.x;
   c->y = a.y + b.y;
   c->z = a.z + b.z;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_XYZSum */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZSubt

        $TYPE         PROCEDURE

        $INPUT        a:    the first cartesian vector to subtract
                      b:    the second cartesian vector to subtract

        $MODIFIED     NONE

        $OUTPUT       c:    the cartesian vector difference of the two given
                            in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure subtracts together two cartesian
                      coordinates vectors

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_XYZSubt
                        (/*IN    */ MATHIT_XYZ           a,
                         /*IN    */ MATHIT_XYZ           b,
                         /*   OUT*/ MATHIT_XYZ          *c,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_XYZSubt";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Subtract the vectors
   ========================================================================== */
   c->x = a.x - b.x;
   c->y = a.y - b.y;
   c->z = a.z - b.z;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_XYZSubt */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZScalProd

        $TYPE         PROCEDURE

        $INPUT        a:    the first vector of the scalar product
                      b:    the second vector of the scalar product

        $MODIFIED     NONE

        $OUTPUT       c:    the scalar product of the two vectors given
                            in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure do the scalar product of two cartesian
                      vectors given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_XYZScalProd
                        (/*IN    */ MATHIT_XYZ           a,
                         /*IN    */ MATHIT_XYZ           b,
                         /*   OUT*/ double              *c,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_XYZScalProd";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Sum the elements products
   ========================================================================== */
   *(c) = a.x*b.x + a.y*b.y + a.z*b.z;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_XYZScalProd */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZCrosProd

        $TYPE         PROCEDURE

        $INPUT        a:    the first cartesian vector of the cross product
                      b:    the second cartesian vector of the cross product

        $MODIFIED     NONE

        $OUTPUT       c:    the cross product of the two vectors passed in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure do the cartesian cross product of two
                      vectors

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_XYZCrosProd
                        (/*IN    */ MATHIT_XYZ           a,
                         /*IN    */ MATHIT_XYZ           b,
                         /*   OUT*/ MATHIT_XYZ          *c,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_XYZCrosProd";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Cross product
   ========================================================================== */
   c->x = a.y*b.z - a.z*b.y;
   c->y = -a.x*b.z + a.z*b.x;
   c->z = a.x*b.y - a.y*b.x;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_XYZCrosProd */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZModu

        $TYPE         PROCEDURE

        $INPUT        a:    the cartesian vector of which the modulus is nedeed

        $MODIFIED     NONE

        $OUTPUT       modu: the vector modulus

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the modulus of the cartesian
                      vector given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_XYZModu
                        (/*IN    */ MATHIT_XYZ           a,
                         /*   OUT*/ double              *modu,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_XYZModu";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Modulus evaluation
   ========================================================================== */
   *(modu) = sqrt( POW( a.x, 2.) + POW( a.y, 2.) + POW( a.z, 2.));

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_XYZModu */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZVers

        $TYPE         PROCEDURE

        $INPUT        a:    the cartesian vector of which the versor is needed

        $MODIFIED     NONE

        $OUTPUT       v:    the versor of the vector a

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_modu

        $DESCRIPTION  This procedure evaluates the versor of the input given
                      cartesian vector

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_XYZVers
                        (/*IN    */ MATHIT_XYZ           a,
                         /*   OUT*/ MATHIT_XYZ          *v,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_XYZVers";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   double                 modu;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Evaluate the vector modulus
   ========================================================================== */
   MATHIP_STYP_XYZModu( a, &modu, status_code);

   /* error check */
   if ( modu == 0.) {

      /* return the versor zeroed */
      v->x = 0.;
      v->y = 0.;
      v->z = 0.;

      /* error managing */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_modu,"");
   }

/* ==========================================================================
   Evaluate the versor
   ========================================================================== */
   v->x = a.x / modu;
   v->y = a.y / modu;
   v->z = a.z / modu;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_XYZVers */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CSum

        $TYPE         PROCEDURE

        $INPUT        z1    : the first complex number to sum
                      z2    : the second complex number to sum

        $MODIFIED     NONE

        $OUTPUT       zout  : the sum of the two complex numbers

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine evaluate the sum of two complex numbers

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_CSum
                        (/*IN    */ MATHIT_complex       z1,
                         /*IN    */ MATHIT_complex       z2,
                         /*   OUT*/ MATHIT_complex      *zout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_CSum";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Sum the complex numbers
   ========================================================================== */
   zout->rea = z1.rea + z2.rea;
   zout->ima = z1.ima + z2.ima;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_CSum */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CSubt

        $TYPE         PROCEDURE

        $INPUT        z1    : the first complex number of the subtraction
                      z2    : the complex number to subtract

        $MODIFIED     NONE

        $OUTPUT       zout  : the difference of the two complex numbers

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine evaluate the difference of two complex
                      numbers

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_CSubt
                        (/*IN    */ MATHIT_complex       z1,
                         /*IN    */ MATHIT_complex       z2,
                         /*   OUT*/ MATHIT_complex      *zout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_CSubt";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Subtract the complex numbers
   ========================================================================== */
   zout->rea = z1.rea - z2.rea;
   zout->ima = z1.ima - z2.ima;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_CSubt */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CProd

        $TYPE         PROCEDURE

        $INPUT        z1    : the first complex number to multiply
                      z2    : the second complex number to multiply

        $MODIFIED     NONE

        $OUTPUT       zout  : the complex number product of the two given in
                              input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the complex product of two
                      complex numbers

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_CProd
                        (/*IN    */ MATHIT_complex       z1,
                         /*IN    */ MATHIT_complex       z2,
                         /*   OUT*/ MATHIT_complex      *zout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_CProd";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Evaluates the complex product
   ========================================================================== */
   zout->rea = z1.rea*z2.rea - z1.ima*z2.ima;
   zout->ima = z1.rea*z2.ima + z1.ima*z2.rea;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_CProd */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CConstMult

        $TYPE         PROCEDURE

        $INPUT        c	    : the constant that must multiply the complex number
                      z	    : the complex number to rescale

        $MODIFIED     NONE

        $OUTPUT       zout  : the complex number rescaled

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure rescale a complex number by a constant
                      scalar value passed in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_CConstMult
                        (/*IN    */ double               c,
                         /*IN    */ MATHIT_complex       z,
                         /*   OUT*/ MATHIT_complex      *zout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_CConstMult";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Rescale the complex number
   ========================================================================== */
   zout->rea = z.rea*c;
   zout->ima = z.ima*c;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_CConstMult */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CConj

        $TYPE         PROCEDURE

        $INPUT        zinp  : the complex number to conjugate

        $MODIFIED     NONE

        $OUTPUT       zout  : the complex number conjugate of the input one

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the complex conjugate of the
                      input compelx number

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_CConj
                        (/*IN    */ MATHIT_complex       zinp,
                         /*   OUT*/ MATHIT_complex      *zout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_CConj";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Evaluate the complex conjugate of the complex number
   ========================================================================== */
   zout->rea = zinp.rea;
   zout->ima = -zinp.ima;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_CConj */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CModu

        $TYPE         PROCEDURE

        $INPUT        zinp  : the complex number of which the modulus must be
                              computated

        $MODIFIED     NONE

        $OUTPUT       modu  : the complex modulus of the complex number given 
                              in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the modulus of the complex number
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_CModu
                        (/*IN    */ MATHIT_complex       zinp,
                         /*   OUT*/ double              *modu,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_CModu";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Evaluate the modulus
   ========================================================================== */
   *(modu) = sqrt( POW(zinp.rea,2.) + POW(zinp.ima,2.) );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_CModu */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CPhase

        $TYPE         PROCEDURE

        $INPUT        z	    : the complex number of which the phase must be
                              extracted

        $MODIFIED     NONE

        $OUTPUT       phase : the phase of the complex number, that is the
                              arctangent of the real / imaginary ratio of z
                              in the range   - pi , pi

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluate the argument of the complex
                      number given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_CPhase
                        (/*IN    */ MATHIT_complex       z,
                         /*   OUT*/ double              *phase,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_CPhase";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Evaluate the arctangent
   ========================================================================== */
   *(phase) = atan2(z.ima,z.rea);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_STYP_CPhase */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CExp

        $TYPE         PROCEDURE

        $INPUT        phase : the phase of the complex number in radians

        $MODIFIED     NONE

        $OUTPUT       z     : the complex number to fill

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the complex number <z> with the
                      complex exponential evaluated at the given phase <phase>

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_STYP_CExp
                        (/*IN    */ double               phase,
                         /*   OUT*/ MATHIT_complex      *z,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_STYP_CExp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Evaluate the complex number with the phase given in input
   ========================================================================== */
   z->rea = cos ( phase );
   z->ima = sin ( phase );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_STYP_CExp */
