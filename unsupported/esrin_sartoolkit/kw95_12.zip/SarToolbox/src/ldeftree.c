/* ==========================================================================
   $MODULE_HEADER

      $NAME              LDEF_TREE

      $FUNCTION          Handle balanced and tree

      $ROUTINE           LDEFIP_TREE_append_unbtree
                         LDEFIF_TREE_search_minimum
                         LDEFIP_TREE_unbtree_to_btree
                         LDEFIP_TREE_delete_btree_node
                         LDEFIP_TREE_destroy_tree

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       18-FEB-94     DD       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "libname.h"
#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include LDEF_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */
static void trace_in( ERRSIT_flag   process_flag,
                      void         *record,
                      float         key )
{
   ERRSIT_status log_status_code;
   char          tmp_char[256];

   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);


   sprintf( tmp_char,"    record = %d", record );
   ERRSIP_HPEL_trace_proc_err_log( tmp_char, &log_status_code);

   sprintf( tmp_char,"    key = %f", key );
   ERRSIP_HPEL_trace_proc_err_log( tmp_char, &log_status_code);



   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);
}

static void trace_out( ERRSIT_flag       process_flag,
                       LDEFIT_tree_node *root_pointer )
{
   ERRSIT_status log_status_code;
   char          tmp_char[256];

   ERRSIP_HPEL_trace_proc_err_log(" ",&log_status_code);
   ERRSIP_HPEL_trace_proc_err_log("OUTPUT PARAMETER:", &log_status_code);


   sprintf( tmp_char,"   root_pointer" );
   LDEFIP_IDMP_tree_node( tmp_char,
                          root_pointer,
                          ERRSIM_verbose( process_flag),
                          9 );
}

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_TREE_append_unbtree

        $DESCRIPTION  Append a record to an unbalanced tree.
                      If the key of the node to add is less tha the current
                      node key, the new node is added on the left, on the right
                      otherwise.

        $TYPE         Procedure

        $INPUT        record     : pointer to the record struct
                      key        : key used to order the tree

        $MODIFIED     root_node  : pointer to the unbalanced root pointer

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_LDEF_err_no_mem_allocated

        $WARNING      The input recored is used to constitude the node,
                      no copy is made. 
                      Don't delete or free the input record.

        $PDL

   $EH
   ========================================================================== */
void LDEFIP_TREE_append_unbtree
                        (/*IN    */ void             *record,
                         /*IN    */ float             key,
                         /*IN OUT*/ LDEFIT_tree_node *(*root_pointer),
                         /*   OUT*/ ERRSIT_status    *status_code )
{
   const ERRSIT_proc_name routine_name = "LDEFIP_TREE_append_unbtree";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   LDEFIT_tree_node *p;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in( process_flag, record, key );
   }

/* ==========================================================================
   unbalanced tree creation
   ========================================================================== */
   if ( *root_pointer != NULL )
   {
      if(  key < (*root_pointer)->key )
      {
         LDEFIP_TREE_append_unbtree
                        (  record,
                           key,
                          &(*root_pointer)->left,
                           status_code );
         if (*status_code != ERRSID_normal)
         {
            goto error_exit;
         }
      }
      else
      {
         LDEFIP_TREE_append_unbtree
                        (  record,
                           key,
                          &(*root_pointer)->right,
                           status_code );
         if (*status_code != ERRSID_normal)
         {
            goto error_exit;
         }
      }
   }
   else /* if( *root_pointer == NULL ) */
   {
      /* allocate space for the node */
      *root_pointer = MEMSIP_alloc( sizeof( LDEFIT_tree_node ) );
      if ( *root_pointer == NULL )
      {
         ERRSIM_set_error( status_code,
                           ERRSID_LDEF_no_mem_allocated,
                           "" );
      }

      /* the root point to the record */
      (*root_pointer)->record = record;

      /* set the key */
      (*root_pointer)->key = key;

      /* set the left and right pointer */
      ((*root_pointer)->left ) = NULL;
      ((*root_pointer)->right) = NULL;

   }

   if( ERRSIM_out_parms( process_flag ))
   {
      trace_out( process_flag, *root_pointer );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* LDEF_TREE_ */

/* ==========================================================================
                  TRACE_IN TRACE_OUT ROUTINE SECTION
  ========================================================================== */
static void trace_in_1( ERRSIT_flag        process_flag,
                        LDEFIT_tree_node  *root_pointer )
{
   ERRSIT_status log_status_code;
   char          tmp_char[256];

   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);


   sprintf( tmp_char,"   root_pointer" );
   LDEFIP_IDMP_tree_node( tmp_char,
                          root_pointer,
                          ERRSIM_verbose( process_flag),
                          9 );


   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);
}

static void trace_out_1( ERRSIT_flag         process_flag,
                         LDEFIT_tree_node  **return_value )
{
   ERRSIT_status log_status_code;
   char          tmp_char[256];

   ERRSIP_HPEL_trace_proc_err_log(" ",&log_status_code);
   ERRSIP_HPEL_trace_proc_err_log("OUTPUT PARAMETER:", &log_status_code);


   sprintf( tmp_char,"    return_value( address ) = %u", return_value );
   ERRSIP_HPEL_trace_proc_err_log( tmp_char, &log_status_code);

   sprintf( tmp_char,"    return_value" );
   LDEFIP_IDMP_tree_node(  tmp_char,
                          *return_value,
                           ERRSIM_verbose( process_flag),
                           9 );
}

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIF_TREE_search_minimum

        $DESCRIPTION  This procedure scan a tree to search the node that
                      contain the key with minimum value.

        $TYPE         Function

        $INPUT        root_pointer : pointer to the unbtree root
                      element_no       : number of element that constitute the
                                         unbalanced tree.

        $MODIFIED     NONE

        $OUTPUT       Pointer to the added node, the root on the first call.

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      If the number of element in the unbalanced tree is
                      less than the input element_no value the process will 
                      crash.

        $PDL

   $EH
   ========================================================================== */
   LDEFIT_tree_node **LDEFIF_TREE_search_minimum
                                 (/*IN   */ LDEFIT_tree_node *(*root_pointer) )
{
   const ERRSIT_proc_name routine_name = "LDEFIF_TREE_search_minimum";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

   LDEFIT_tree_node      *root;
   LDEFIT_tree_node     **return_value;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in_1( process_flag, *root_pointer );
   }

/* ==========================================================================
   scan tree
   ========================================================================== */

   if ( (*root_pointer) != NULL )
   {
      if ( (*root_pointer)->left != NULL )
      {
         root = *root_pointer;

         /* read the left subtree */
         return_value = LDEFIF_TREE_search_minimum( &(root->left) );
         goto error_exit;
      }
   }

   return_value = root_pointer;

error_exit:;

   if( ERRSIM_out_parms( process_flag ))
   {
      trace_out_1( process_flag, return_value );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                           status_code, 
                          &log_status_code );

   return (return_value);

}/* LDEF_TREE_ */

/* ==========================================================================
                  TRACE_IN TRACE_OUT ROUTINE SECTION
  ========================================================================== */
static void trace_in_2( ERRSIT_flag         process_flag,
                        LDEFIT_tree_node   *unb_root_pointer,
                        INTx4               element_no )
{
   ERRSIT_status log_status_code;
   char          tmp_char[256];

   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);

   if ( unb_root_pointer != NULL )
   {
      sprintf( tmp_char,"    unb_root_pointer" );
      LDEFIP_IDMP_tree_node( tmp_char,
                             unb_root_pointer,
                             ERRSIM_verbose( process_flag),
                             9 );
   }
   else
   {
      sprintf( tmp_char,"    *unb_root_pointer = %d",  unb_root_pointer );
      ERRSIP_HPEL_trace_proc_err_log( tmp_char, &log_status_code);
   }

   sprintf( tmp_char,"    element_no = %d", element_no );
   ERRSIP_HPEL_trace_proc_err_log( tmp_char, &log_status_code);


   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);
}

static void trace_out_2( ERRSIT_flag          process_flag,
                         LDEFIT_tree_node    *added_node )
{
   ERRSIT_status log_status_code;
   char          tmp_char[256];

   ERRSIP_HPEL_trace_proc_err_log(" ",&log_status_code);
   ERRSIP_HPEL_trace_proc_err_log("OUTPUT PARAMETER:", &log_status_code);


   sprintf( tmp_char,"   added_node = %u", added_node );
   ERRSIP_HPEL_trace_proc_err_log( tmp_char, &log_status_code);
}

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_TREE_unbtree_to_btree

        $DESCRIPTION  This routine create a balanced tree from an unbalanced
                      ordered tree.
                      The unbalanced tree is scanned to get the maximum element.
                      Note that the unbalanced tree must be ordered with
                      less key on the left and greather key on the right.
                      To create the ordered unbalanced tree the 
                      LDEFIP_TREE_append_unbtree can be used.
                      There are not new created nodes for btree creation:
                      the unbalanced tree nodes are used.

        $TYPE         Procedure

        $INPUT        element_no       : number of element that constitute the
                                         unbalanced tree.

        $MODIFIED     unb_root_pointer : pointer to pointer to the unbtree root.
                                         At the return the pointer to the 
                                         unbtree root will be NULL.

        $OUTPUT       added_node       : pointer to the Pointer to the added 
                                         node, the root on the first call.

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      If the number of element in the unbalanced tree is
                      less than the input element_no value the process will 
                      crash.

        $PDL

   $EH
   ========================================================================== */
   void LDEFIP_TREE_unbtree_to_btree
                              (/*IN OUT*/ LDEFIT_tree_node *(*unb_root_pointer),
                               /*IN    */ INTx4             element_no,
                               /*   OUT*/ LDEFIT_tree_node *(*added_node), 
                               /*   OUT*/ ERRSIT_status    *status_code )
{
   const ERRSIT_proc_name routine_name = "LDEFIP_TREE_unbtree_to_btree";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   LDEFIT_tree_node *(*min_pointer);
   INTx4               left_no;
   INTx4               right_no;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in_2( process_flag, *unb_root_pointer, element_no );
   }

/* ==========================================================================
   Create the btree
   ========================================================================== */
   if ( element_no == 0 )
   {
     *added_node = NULL;
   }
   else
   {
      /*Calculate the left number of node to append dividing 
        (element_no-1) by 2*/
      left_no = ( element_no - 1 ) >> 1;

      /* calculate the right number of node to append */
      right_no = ( element_no - 1 ) - left_no;

      *added_node = MEMSIP_alloc( sizeof(LDEFIT_tree_node));
      if( *added_node == NULL )
      {
         ERRSIM_set_error( status_code,
                           ERRSID_LDEF_no_mem_allocated,
                           "" );
      }

      /* create the left subtree */
      LDEFIP_TREE_unbtree_to_btree( unb_root_pointer,
                                    left_no,
                                    &((*added_node)->left),
                                    status_code);
      if (*status_code != ERRSID_normal)
      {
         ERRSIP_WPEL_write
               (  routine_name,
                  "Error creating a balanced tree from an unbalanced one.",
                 &log_status_code );
         goto error_exit;
      }

      /* the current node is the last */
      min_pointer = LDEFIF_TREE_search_minimum( unb_root_pointer );
      
      (*added_node)->key    = (*min_pointer)->key;
      (*added_node)->record = (*min_pointer)->record;

      LDEFIP_TREE_delete_btree_node( min_pointer, status_code );
      if (*status_code != ERRSID_normal)
      {
         goto error_exit;
      }

      /* create the right subtree */
      LDEFIP_TREE_unbtree_to_btree( unb_root_pointer,
                                    right_no,
                                    &((*added_node)->right),
                                    status_code);
      if (*status_code != ERRSID_normal)
      {
         ERRSIP_WPEL_write
               (  routine_name,
                  "Error creating a balanced tree from an unbalanced one.",
                 &log_status_code );
         goto error_exit;
      }

   }

   if( ERRSIM_out_parms( process_flag ))
   {
      trace_out_2( process_flag, *added_node );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );    
}/* LDEF_TREE_ */

/* ==========================================================================
                  TRACE_IN TRACE_OUT ROUTINE SECTION
  ========================================================================== */
static void trace_in_3( ERRSIT_flag       process_flag,
                        LDEFIT_tree_node *root_pointer)
{
   ERRSIT_status log_status_code;
   char          tmp_char[256];

   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);


   if ( root_pointer != NULL )
   {
      sprintf( tmp_char,"    root_pointer" );
      LDEFIP_IDMP_tree_node( tmp_char,
                             root_pointer,
                             ERRSIM_verbose( process_flag),
                             9 );
   }
   else
   {
      sprintf( tmp_char,"   root_pointer( address ) = %u", root_pointer );
      ERRSIP_HPEL_trace_proc_err_log( tmp_char, &log_status_code);
   }

   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);
}

static void trace_out_3( ERRSIT_flag   process_flag )
{
   ERRSIT_status log_status_code;

   ERRSIP_HPEL_trace_proc_err_log(" ",&log_status_code);
   ERRSIP_HPEL_trace_proc_err_log("NO OUTPUT PARAMETER:", &log_status_code);

}

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_TREE_delete_btree_node

        $DESCRIPTION  This procedure delete a node from a balanced 
                      tree.

        $TYPE         Procedure

        $INPUT        root_pointer      : pointer to the pointer of the node
                                          to delete.
                                          This is the pointer to the left or 
                                          right pointer of the node to delete;
                                          it isn't an external pointer.

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      root_pointer is the pointer to the left or right pointer
                      of the node to delete; it isn't an external pointer.

        $PDL

   $EH
   ========================================================================== */
   void LDEFIP_TREE_delete_btree_node
                     ( /*IN    */ LDEFIT_tree_node *(*root_pointer),
                       /*   OUT*/ ERRSIT_status    *status_code )
{
   const ERRSIT_proc_name routine_name = "LDEFIP_TREE_delete_btree_node";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   LDEFIT_tree_node  *to_delete = (LDEFIT_tree_node *) NULL;
   LDEFIT_tree_node  *to_move = (LDEFIT_tree_node *) NULL;
   LDEFIT_tree_node **to_move_pointer = (LDEFIT_tree_node **) NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in_3( process_flag, *root_pointer );
   }
/* ==========================================================================
   delete node
   ========================================================================== */
   if ( *root_pointer != NULL )
   {
      /* *root_pointer is the address of the node to delete.
          The node to delete exist                 */

      /* to_delete is the address of the node to delete. */
      to_delete = *root_pointer;

      if ( to_delete->right == NULL)
      {
         /* the deleting node has only the left part
            and the root will point to it */
         *root_pointer = to_delete->left;

         MEMSIP_free( (void **)(&to_delete) );
      }
      else if( to_delete->left == NULL)
      {
         /* the deleting node has only the right part
            and the root will point to it */
         *root_pointer = to_delete->right;

         MEMSIP_free( (void **)(&to_delete) );

      }
      else /* if( to_delete->left != NULL) and ( to_delete->left != NULL) */
      {
         /* search the node with maximum value;
            is the the right node whithout right node */

         /* initialize the pointer to the pointer of the node to move */
         to_move_pointer = &(to_move->left);
         while ( ( (*to_move_pointer)->right != NULL) )
         {

            /* set the pointer to the value of pointer to the node to move */
            to_move_pointer = &( (*to_move_pointer)->right );

         }/* end while ( ( *to_move_pointer->right) */

         to_move = *to_move_pointer;

         /* move the left subtree to the right of the root
            of the node to move */
         *to_move_pointer =  to_move->left;

         to_delete->record = to_move->record;
         to_delete->key    = to_move->key;

         MEMSIP_free( (void **)(&to_move) );

      }/* endif( to_delete->left != NULL) and ( to_delete->left != NULL) */
   }

   if( ERRSIM_out_parms( process_flag ))
   {
      trace_out_3( process_flag );
   }
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* LDEF_TREE_ */

/* ==========================================================================
                  TRACE_IN TRACE_OUT ROUTINE SECTION
  ========================================================================== */
static void trace_in_4( ERRSIT_flag       process_flag,
                        LDEFIT_tree_node *root )
{
   ERRSIT_status log_status_code;
   char          tmp_char[256];

   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);


   if ( root != NULL )
   {
      sprintf( tmp_char,"    root" );
      LDEFIP_IDMP_tree_node( tmp_char,
                             root,
                             ERRSIM_verbose( process_flag),
                             9 );
   }
   else
   {
      sprintf( tmp_char,"   root ( address ) = %u", root );
      ERRSIP_HPEL_trace_proc_err_log( tmp_char, &log_status_code);
   }


   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);
}

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_TREE_destroy_tree

        $DESCRIPTION  Create the ers1 balanced tree with the frame info as node.

        $TYPE         Procedure

        $INPUT        root    : pointer to the pointer to the tree root

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   void LDEFIP_TREE_destroy_tree( /*IN    */ LDEFIT_tree_node *(*root),
                                  /*   OUT*/ ERRSIT_status *status_code )
{
   const ERRSIT_proc_name     routine_name = "LDEFIP_TREE_destroy_tree";
   ERRSIT_status              log_status_code;
   ERRSIT_flag                process_flag;


/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in_4( process_flag, *root );
   }

/* ==========================================================================
   Scan and delete the tre
   ========================================================================== */
   if ( *root != NULL )
   {
      LDEFIP_TREE_destroy_tree( &(*root)->left,  status_code );
      LDEFIP_TREE_destroy_tree( &(*root)->right, status_code );

      if( (*root)->record != NULL )
      {
         MEMSIP_free( &((*root)->record) );
      }

      MEMSIP_free( (void **)root );
      *root = NULL;

   }/* end if ( root != NULL ) */

   if( ERRSIM_out_parms( process_flag ))
   {
      trace_out_3( process_flag );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

}/* LDEFIP_TREE_destroy_tree */
