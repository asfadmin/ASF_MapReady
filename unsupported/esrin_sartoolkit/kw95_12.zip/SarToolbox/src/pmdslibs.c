/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_LIBS

      $FUNCTION          Product Media Deformatting exported Services

      $ROUTINE           PMDSIP_Deformat

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       07-FEB-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <ctype.h>

#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include FILS_INTF_H
#include DEVS_INTF_H
#include GIOS_INTF_H
#include TIFS_INTF_H
#include IANN_TAGS_H
#include IANN_INTF_H
#include PMDS_INTF_H
#include PMDS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_Deformat

        $TYPE              PROCEDURE

        $INPUT        input_media_path       : source product media
                      media_type             : product media type
                      product_type           : product type
                      sensor_id              : sensor id
                      data_format            : data format (ceos/mph-sph)
                      source                 : i-paf, ...
                      mode                   : deformat, create annotation, ...
                      num_of_vol             : number of volume(s)
                      start_row              : top corner value
                      start_col              : left corner value
                      end_row                : bottom corner value
                      end_col                : right corner value
                      ql_width               : width of the output quick look
                      ql_height              : height of the output quick look
                      win_width              : width of the window to be used
                      win_height             : height of the window to be used
                      tif_ann_file           : tif annotation file name
                      output_file            : output file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void PMDSIP_Deformat    (/*IN    */ char                *input_media_path,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ DEVSIT_media_type    media_type,
                         /*IN    */ PMDSIT_product_type  product_type,
                         /*IN    */ INTx4                sensor_id,
                         /*IN    */ char                *data_format,
                         /*IN    */ char                *source,
                         /*IN    */ PMDSIT_deformat_mode mode,
                         /*IN    */ INTx4                num_of_vol,
                         /*IN    */ char                 ack_mount_flag,
                         /*IN    */ char                 dismount_flag,
                         /*IN    */ INTx4                start_row,
                         /*IN    */ INTx4                start_col,
                         /*IN    */ INTx4                end_row,
                         /*IN    */ INTx4                end_col,
                         /*IN    */ INTx4                ql_width,
                         /*IN    */ INTx4                ql_height,
                         /*IN    */ UINTx4               win_width,
                         /*IN    */ UINTx4               win_height,
                         /*IN    */ char                *tif_ann_file,
                         /*IN    */ char                *output_file,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_Deformat";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   FILE                  *fpCfg;
   FILE                  *fp;
   INTx4                  tifChannel;
   INTx4                  fl_num;
   INTx4                  nb_files;
   INTx4                  ivol;
   INTx4                  curr_vol;
   INTx4                  volume_id;
   INTx4                  key_press;
   INTx4                  ichar;
   INTx4                  itag;
   INTx4                  ibit;
   INTx4                  scene_id;
   INTx4                  nimg;
   UINTx2                 npar;
   TIFSIT_par             param;
   TIFSIT_basicpar        bpar;
   PMDSPT_log_vol         prodLogVol[ PMDSPD_max_log_vol_item ];
   char                   product_type_str[256];
   char                   cur_file_name[ 256 ];
   char                   cfg_body_name[ 256 ];
   char                   cfg_file[ 256 ];
   char                   title[256];
   char                   note1[256];
   char                   note2[256];
   char                   sensor_str[256];
   char                   data_format_str[256];
   char                   date_time[256];
   char                   gr_sr_pol_degree_txt[256];
   char                   proc_history_txt[512];
   char                   time_stamp[ 40 ];
   INTx4                  gr_sr_pol_degree;
   INTx4                  bitspersample;
   char                   tmp_buf[256];
   char                   vol_name[256];
   int                    bytes_read;
   char                  *buffer;
   LDEFIT_boolean         image_completed = FALSE;
   LDEFIT_boolean         exist_tag;
   FILSIT_file_name       temp_tif_ann_file;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Init library
   ========================================================================== */
   PMDSPP_InitLibrary( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the product type
   ========================================================================== */
   PMDSPV_product_type = product_type;

/* ==========================================================================
   Set the media type and name
   ========================================================================== */
   PMDSPV_input.media_type = media_type;
   strcpy( PMDSPV_input.name, input_media_path );

/* ==========================================================================
   Alloc memory for buffer to be used to read from input file
   ========================================================================== */
   if((buffer = (char *) MEMSIP_alloc(65535)) == NULL)
   {
      ERRSIM_set_error(status_code, ERRSID_PMDS_alloc_cfg_field, "");
   }

/* ==========================================================================
   Initialize tiff field data list
   ========================================================================== */
   PMDSPV_TiffList.list = NULL;
   PMDSPV_TiffList.num  = 0;

/* ==========================================================================
   Get the current product type
   ========================================================================== */
   if(product_type == PMDSIE_raw_prod)
      strcpy(product_type_str, "RAW");
   else if(product_type == PMDSIE_slc_prod)
       strcpy(product_type_str, "SLC");
   else if(product_type == PMDSIE_slci_prod)
       strcpy(product_type_str, "SLI");
   else if(product_type == PMDSIE_pri_prod)
       strcpy(product_type_str, "PRI");
   else if(product_type == PMDSIE_gec_prod)
       strcpy(product_type_str, "GEC");
   else if(product_type == PMDSIE_gtc_prod)
      strcpy(product_type_str, "GTC");
   else 
     strcpy(product_type_str, "UNK");
  
/* ==========================================================================
   Set file(s) name(s) into lower case (if any)
   ========================================================================== */
   strcpy(tmp_buf, product_type_str);
   for(ichar = 0; ichar < strlen(product_type_str); ichar++)
   {
      product_type_str[ichar] = tolower(tmp_buf[ichar]);
   }

/* ==========================================================================
   Set file(s) name(s) into lower case (if any)
   ========================================================================== */
   strcpy(tmp_buf, data_format);
   for(ichar = 0; ichar < strlen(data_format); ichar++)
   {
      data_format[ichar] = tolower(tmp_buf[ichar]);
   }

/* ==========================================================================
   Set file(s) name(s) into lower case (if any)
   ========================================================================== */
   strcpy(tmp_buf, source );
   for(ichar = 0; ichar < strlen(source); ichar++)
   {
      source[ichar] = tolower(tmp_buf[ichar]);
   }

/* ==========================================================================
   Create cfg_file body name without extension
   ========================================================================== */
   sprintf(cfg_body_name, "%s%s%0d%s%s", LDEFIV_cfg_dir,
                                         product_type_str,
                                         sensor_id,
                                         data_format,
                                         source);

/* ==========================================================================
   Check temporary dir when extracting quick look
   ========================================================================== */
   if( mode == PMDSIE_QuickLookMode )
   {

      LDEFIP_UTIL_gen_tmp_name( temp_tif_ann_file, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      FILSIP_open( temp_tif_ann_file, "w", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      FILSIP_close( &fp, &log_status_code );

      FILSIP_delete( temp_tif_ann_file, &log_status_code );

   }

/* ==========================================================================
   Create annotation test file and write data in
   ========================================================================== */
   if( mode == PMDSIE_HeaderDecodeMode )
   {

/* ==========================================================================
   Set sensor_str and data_format_str
   ========================================================================== */
      if(sensor_id == 1)
         strcpy(sensor_str, "ERS-1");
      else
         strcpy(sensor_str, "ERS-2");

      if(((strcmp(data_format, "c")) == 0) ||
         ((strcmp(data_format, "C")) == 0))
         strcpy(data_format_str, "CEOS");
      else
         strcpy(data_format_str, "MPH-SPH");

/* ==========================================================================
   Check if a temp file for header analysis when MPH-SPH can be generated
   ========================================================================== */
      if( !strcmp( data_format_str, "MPH-SPH" ) ) {

         LDEFIP_UTIL_gen_tmp_name( temp_tif_ann_file, status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         FILSIP_open( temp_tif_ann_file, "w", 0, &fp, status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         FILSIP_close( &fp, &log_status_code );

         FILSIP_delete( temp_tif_ann_file, &log_status_code );

      }

/* ==========================================================================
      Get current date and time
   ========================================================================== */
      ERRSIF_LODT_out_date(date_time);

/* ==========================================================================
      Create annotation file name
   ========================================================================== */
      strcpy(title,
         "Sar Toolbox - ESA / Telespazio - ANNOTATION LIST");
      strcpy(note1, "==================================================");
      strcat(note1, "==================================================");
      strcat(note1, "==================================================");
      strcpy(note2, "--------------------------------------------------");
      strcat(note2, "--------------------------------------------------");
      strcat(note2, "--------------------------------------------------");

      PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameOpen,
                             PMDSPE_ANNF_FileNameType,
                             NULL,
                             (void*)output_file,
                             status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                             PMDSPE_ANNF_DataType,
                             NULL,
                             (void*)note1,
                             status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                             PMDSPE_ANNF_DataType,
                             NULL,
                             (void*)title,
                             status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                             PMDSPE_ANNF_DataType,
                             NULL,
                             (void*)note1,
                             status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                             PMDSPE_ANNF_DataType,
                             "Processing time............: ",
                             (void*)date_time,
                             status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                             PMDSPE_ANNF_DataType,
                             "Product type...............: ",
                             (void*)product_type_str,
                             status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                             PMDSPE_ANNF_DataType,
                             "Source.....................: ",
                             (void*)sensor_str,
                             status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                             PMDSPE_ANNF_DataType,
                             "Data format................: ",
                             (void*)data_format_str,
                             status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                             PMDSPE_ANNF_DataType,
                             "Facility id................: ",
                             (void*)source,
                             status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                             PMDSPE_ANNF_DataType,
                             "Format descriptor record...: ",
                             (void*)cfg_body_name,
                             status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                             PMDSPE_ANNF_DataType,
                             NULL,
                             (void*)note2,
                             status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   
   }

/* ==========================================================================
   If it is a cdrom try to get the current scene id
   ========================================================================== */
   scene_id = 0;
   if(PMDSPV_input.media_type == DEVSIE_mt_cdrom)
   {
      for(ichar = (strlen(input_media_path) - 1); ichar >= 0; ichar--)
      {
         if(isdigit(input_media_path[ichar]))
         {
            scene_id = (INTx4)(input_media_path[ichar]);
            break;
         }
      }
   }

/* ==========================================================================
   Loop on number of volumes (tapes) in order to manage multi volumes
   ========================================================================== */
   for(ivol = 0; ivol < num_of_vol && !image_completed; ivol++)
   {

      volume_id = ivol + 1;

      if( (num_of_vol > 1) ||
          ( (num_of_vol == 1) && (toupper(ack_mount_flag) == 'Y')) ) {

/* ==========================================================================
      Wait for the user's ok
   ========================================================================== */
         fprintf(stdout,
            "Insert volume %d of %d on %s\nPress <Enter> to continue ...\n",
            (ivol + 1), num_of_vol, input_media_path);

         fflush( stdin );
         key_press = 0;
         while(key_press == 0)
         {
            key_press = getchar();
         }

      }

/* ==========================================================================
      Create cfg_file name according to the current volume
   ========================================================================== */
      if(num_of_vol > 1)
      {
         if(ivol == 0)
         {
            sprintf(cfg_file, "%s.%s", cfg_body_name, "cff");
            curr_vol = PMDSPD_first_vol;
         }
         else if(ivol == (num_of_vol - 1))
         {
            sprintf(cfg_file, "%s.%s", cfg_body_name, "cfl");
            curr_vol = PMDSPD_last_vol;
         }
         else
         {
            sprintf(cfg_file, "%s.%s", cfg_body_name, "cfc");
            curr_vol = PMDSPD_center_vol;
         }
      }
      else
      {
         sprintf(cfg_file, "%s.%s", cfg_body_name, "cfs"); 
         curr_vol = PMDSPD_single_vol;
      }

#ifdef __TRACE__
      fprintf(stderr,"Debug: Current cfg file = <%s>\n", cfg_file);
#endif

/* ==========================================================================
      Open cfg_file
   ========================================================================== */
      FILSIP_open( cfg_file, "r", 0, &fpCfg, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Read GLOBAL VAR SECTION from cfg_file
   ========================================================================== */
      PMDSPP_ReadGlobalVar( fpCfg,
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Read LOGICAL VOLUME STRUCTURE from cfg_file
   ========================================================================== */
      nb_files = PMDSPF_ReadLogVolStru( fpCfg,
                                        prodLogVol,
                                        status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( PMDSPV_input.media_type == DEVSIE_mt_exa )
      {
/* ==========================================================================
         Open descriptor to product input device 
   ========================================================================== */
         DEVSIP_open_read( PMDSPV_input.name,
                          &PMDSPV_input.media_pointer.exa,
                          status_code );
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
         Mount the tape
   ========================================================================== */
         DEVSIP_mount( PMDSPV_input.name,
                       PMDSPV_input.media_pointer.exa,
                       status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }

/* ==========================================================================
      For each file
   ========================================================================== */
      for (fl_num = 0; fl_num < nb_files && !image_completed; fl_num++)
      {

         fprintf( stdout,
            "\nFile no. %0d Code %s\n", fl_num+1, prodLogVol[fl_num].file_code);

#ifdef __DAVID__
         if((((strcmp(prodLogVol[fl_num].file_code, "NUL")) == 0)            ||
             ((strcmp(prodLogVol[fl_num].file_code, "nul")) == 0))            &&
            (mode == PMDSIE_QuickLookMode))
         {
            prodLogVol[fl_num].presence_type = PMDSPE_none_pres;
         }
#endif

/* ==========================================================================
         Check if the current file is present
   ========================================================================== */
         if( prodLogVol[fl_num].presence_type != PMDSPE_none_pres )
         {

/* ==========================================================================
            Set file number
   ========================================================================== */
            PMDSPV_gm.cur_file_num = fl_num + 1;

/* ==========================================================================
            Seek section in cfg_file
   ========================================================================== */
            PMDSPP_SeekCfgFile( fpCfg,
                             prodLogVol[fl_num].file_code,
                             status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
            Build f.name using LOGICAL VOLUME STRUCTURE and PMDS_input_filepath
   ========================================================================== */
            if(PMDSPV_input.media_type == DEVSIE_mt_file)
            {
               sprintf(cur_file_name, "%s%s%d.%s0", input_media_path,
                  product_type_str, volume_id, prodLogVol[fl_num].file_code);

/* ==========================================================================
               Convert file name into lower case
   ========================================================================== */
               strcpy(tmp_buf, cur_file_name);
               for(ichar = 0; ichar < strlen(cur_file_name); ichar++)
               {
                  cur_file_name[ichar] = tolower(tmp_buf[ichar]);
               }
            }
            else if(PMDSPV_input.media_type == DEVSIE_mt_cdrom)
            {
               if(((strcmp(prodLogVol[fl_num].file_code, "VDF")) == 0)        ||
                  ((strcmp(prodLogVol[fl_num].file_code, "vdf")) == 0))
               {
                  sprintf(cur_file_name, "%s%s%c", input_media_path,
                     "VDF_DAT.00", scene_id);
               }
               else if(((strcmp(prodLogVol[fl_num].file_code, "LDR")) == 0)   ||
                  ((strcmp(prodLogVol[fl_num].file_code, "ldr")) == 0))
               {
                  sprintf(cur_file_name, "%s%s%c", input_media_path,
                     "LEA_01.00", scene_id);
               }
               else if(((strcmp(prodLogVol[fl_num].file_code, "IMG")) == 0)   ||
                  ((strcmp(prodLogVol[fl_num].file_code, "img")) == 0))
               {
                  sprintf(cur_file_name, "%s%s%c", input_media_path,
                     "DAT_01.00", scene_id);
               }
               else if(((strcmp(prodLogVol[fl_num].file_code, "NUL")) == 0)   ||
                  ((strcmp(prodLogVol[fl_num].file_code, "nul")) == 0))
               {
                  sprintf(cur_file_name, "%s%s%c", input_media_path,
                     "NUL_DAT.00", scene_id);
               }
            }

            if((PMDSPV_input.media_type == DEVSIE_mt_file)                    ||
               (PMDSPV_input.media_type == DEVSIE_mt_cdrom))
            {
/* ==========================================================================
               Open File
   ========================================================================== */
               fprintf(stdout, "\nFile %s\n", cur_file_name );
               FILSIP_open( cur_file_name, 
                            "rb", 
                            0,
                            &PMDSPV_input.media_pointer.fp,
                            status_code );
               ERRSIM_on_err_goto_exit( *status_code );
            }

/* ==========================================================================
            Write annotation file
   ========================================================================== */
            if( mode == PMDSIE_HeaderDecodeMode )
            {
               sprintf(vol_name, "%s - %s", prodLogVol[fl_num].file_code,
                  prodLogVol[fl_num].file);
               PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                                      PMDSPE_ANNF_DataType,
                                      "File name..................: ",
                                      (void*)vol_name,
                                      status_code);
               ERRSIM_on_err_goto_exit( *status_code );
            }

/* ==========================================================================
            Call PMDSPP_DeformatFile to deformat File
   ========================================================================== */
            PMDSPP_DeformatFile ( 
               cur_file_name,
               inp_ima_num,
               out_ima_num,
               PMDSPF_VolumeType( prodLogVol[fl_num].file_code ),
               mode,
               fpCfg,
               curr_vol,
               start_row,
               start_col,
               end_row,
               end_col,
               ql_width,
               ql_height,
               win_width,
               win_height,
               tif_ann_file,
               output_file,
              &image_completed,
               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            if((PMDSPV_input.media_type == DEVSIE_mt_file)                    ||
               (PMDSPV_input.media_type == DEVSIE_mt_cdrom))
            {
/* ==========================================================================
               Close File
   ========================================================================== */
               FILSIP_close( &PMDSPV_input.media_pointer.fp,
                              status_code );
               ERRSIM_on_err_goto_exit( *status_code );
            }
            else if( PMDSPV_input.media_type == DEVSIE_mt_exa )
            {
/* =========================================================================
               Skip EOF record
   ========================================================================== */
               bytes_read = DEVSIF_read( PMDSPV_input.media_pointer.exa,
                                         DEVSID_max_read_size,
                                         (void *) buffer,
                                         status_code );
               ERRSIM_on_err_write_and_exit( *status_code,
                  "The product media does not match the format description file" );
            }

         } /* end if( prodLogVol[fl_num].presence_type != PMDSPE_none_pres ) */

#ifdef __VMSBHOO__
/* ==========================================================================
         Skip a byte on VMS files (end of record)
   ========================================================================== */
         if( (PMDSPV_input.media_type == DEVSIE_mt_file) ||
             (PMDSPV_input.media_type == DEVSIE_mt_cdrom))
         {
            INTx4 tmp;
            char  msg[ 512 ];
            tmp = FILSIF_read(PMDSPV_input.media_pointer.fp,
                              1,
                              msg,
                              status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
#endif
      }

      if( PMDSPV_input.media_type == DEVSIE_mt_exa )
      {
         if( (num_of_vol > 1) ||
             ( (num_of_vol == 1) && (toupper(dismount_flag) == 'Y')) ) {
/* ==========================================================================
         Dismount the tape
   ========================================================================== */
            DEVSIP_dismount( PMDSPV_input.name,
                             PMDSPV_input.media_pointer.exa,
                             status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
         else {
            ERRSIM_print_warning( "Tape not dismounted!" );
         }

/* ==========================================================================
         Close descriptor to input device 
   ========================================================================== */
         DEVSIP_close( &PMDSPV_input.media_pointer.exa,
                        status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }

/* ==========================================================================
      Close cfg_file
   ========================================================================== */
      FILSIP_close( &fpCfg,
                     status_code );
      ERRSIM_on_err_goto_exit( *status_code );

   } /* end of loop onto the number of volumes (in case of multi-volumes) */


#ifdef __TRACE__
/* ==========================================================================
      Close annotation file
   ========================================================================== */
   if( mode == PMDSIE_HeaderDecodeMode )
   {
      PMDSIP_ANNF_SetAnnFile( PMDSPE_ANNF_FileNameClose,
                              PMDSPE_ANNF_FileNameType,
                              NULL,
                              (void*)output_file,
                              status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }
#endif

   if( (mode == PMDSIE_HeaderDecodeMode) &&
       (tif_ann_file != (char *) NULL) ) {

/* ==========================================================================
   Create annotation tiff file and set the right image size
   ========================================================================== */
      TIFSIM_bpar_init( bpar );

      bpar.imagewidth    = 0;
      bpar.imagelength   = 0;

      bpar.sampleperpixel = PMDSPV_prod_image.sample_per_pix;

      bitspersample = PMDSPV_prod_image.bits_per_sample;

      if(bpar.sampleperpixel == 1)
       bpar.sampleformat[0] = 1;
      else
       bpar.sampleformat[0] = 2;
       for(ibit = 0; ibit < bpar.sampleperpixel; ibit++)
       {
	  bpar.bitspersample[ibit] = bitspersample;
       }

/* ==========================================================================
   Compute GR_SR_POL_DEGREE tag
   ========================================================================== */
       gr_sr_pol_degree = 3;
       sprintf(gr_sr_pol_degree_txt, "%d", gr_sr_pol_degree);
       PMDSPP_TFDM_AddTiffField( "gr_sr_pol_degree",
  			         gr_sr_pol_degree_txt,
				&PMDSPV_TiffList,
				 status_code);
       ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Add DATA_FORMAT, SOURCE_ID and NUMBER_OF_VOLUMES tag
   ========================================================================== */
       strcpy( tmp_buf, data_format_str );
       for( ichar=0; ichar<strlen(tmp_buf); ichar++ ) {
          tmp_buf[ ichar ] = tolower( tmp_buf[ ichar ] );
       }

       PMDSPP_TFDM_AddTiffField( "data_format",
                                  tmp_buf,
                                 &PMDSPV_TiffList,
				  status_code);
      ERRSIM_on_err_goto_exit( *status_code );

#ifdef __PLAPLA__
       for( ichar=0; ichar<strlen(source); ichar++ ) {
          source[ ichar ] = tolower( source[ ichar ] );
       }
#endif
       sprintf( tmp_buf, "%s", source );
       PMDSPP_TFDM_AddTiffField( "source_id",
                                  tmp_buf,
                                 &PMDSPV_TiffList,
				  status_code);
      ERRSIM_on_err_goto_exit( *status_code );

       sprintf( tmp_buf, "%0d", num_of_vol );
       PMDSPP_TFDM_AddTiffField( "number_of_volumes",
                                  tmp_buf,
                                 &PMDSPV_TiffList,
				  status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Add PROC_HISTORY
   ========================================================================== */
       sprintf( proc_history_txt, "\nHEADER DECODE %s",
          ERRSIF_LODT_out_date( time_stamp ) );
       PMDSPP_TFDM_AddTiffField( "proc_history",
                                 proc_history_txt,
				&PMDSPV_TiffList,
				 status_code);
       ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check ANTENNA_ELEVATION_GAIN_FLAG and SPREAD_LOSS_COMP_FLAG
   ========================================================================== */
       for(exist_tag = FALSE, itag = 0; itag < PMDSPV_TiffList.num; itag++)
       {
          if( PMDSPV_TiffList.list[itag].tag == ANTENNA_ELEVATION_GAIN_FLAG )
          {
             exist_tag = TRUE;
             break;
          }

       }
       if( !exist_tag ) {
          sprintf( tmp_buf, "0" );
          PMDSPP_TFDM_AddTiffField( "antenna_elevation_gain_flag",
     			            tmp_buf,
				   &PMDSPV_TiffList,
				    status_code);
          ERRSIM_on_err_goto_exit( *status_code );
      }

      for(exist_tag = FALSE, itag = 0; itag < PMDSPV_TiffList.num; itag++)
      {
         if( PMDSPV_TiffList.list[itag].tag == SPREAD_LOSS_COMP_FLAG )
         {
            exist_tag = TRUE;
            break;
         }

      }
      if( !exist_tag ) {
         sprintf( tmp_buf, "0" );
         PMDSPP_TFDM_AddTiffField(  "spread_loss_comp_flag",
                                    tmp_buf,
                                   &PMDSPV_TiffList,
                                    status_code);
         ERRSIM_on_err_goto_exit( *status_code );
      }

/* ==========================================================================
   Change log_vol_id according to product_type - sensor_id user inputs
   ========================================================================== */
      switch( product_type ) {
         case PMDSIE_raw_prod:
            if( sensor_id == 1) {
               sprintf( tmp_buf, "ERS1.SAR.RAW" );
            }
            else {
               sprintf( tmp_buf, "ERS2.SAR.RAW" );
            }
            break;
         case PMDSIE_slc_prod:
            if( sensor_id == 1) {
               sprintf( tmp_buf, "ERS1.SAR.SLC" );
            }
            else {
               sprintf( tmp_buf, "ERS2.SAR.SLC" );
            }
            break;
         case PMDSIE_slci_prod:
            if( sensor_id == 1) {
               sprintf( tmp_buf, "ERS1.SAR.SLCI" );
            }
            else {
               sprintf( tmp_buf, "ERS2.SAR.SLCI" );
            }
            break;
         case PMDSIE_pri_prod:
            if( sensor_id == 1) {
               sprintf( tmp_buf, "ERS1.SAR.PRI" );
            }
            else {
               sprintf( tmp_buf, "ERS2.SAR.PRI" );
            }
            break;
         case PMDSIE_gec_prod:
            if( sensor_id == 1) {
               sprintf( tmp_buf, "ERS1.SAR.GEC" );
            }
            else {
               sprintf( tmp_buf, "ERS2.SAR.GEC" );
            }
            break;
         case PMDSIE_gtc_prod:
            if( sensor_id == 1) {
               sprintf( tmp_buf, "ERS1.SAR.GTC" );
            }
            else {
               sprintf( tmp_buf, "ERS2.SAR.GTC" );
            }
            break;
      }

      for(exist_tag = FALSE, itag = 0; itag < PMDSPV_TiffList.num; itag++)
      {
         if( PMDSPV_TiffList.list[itag].tag == LOG_VOL_ID )
         {
            exist_tag = TRUE;
            break;
         }

      }
      if( !exist_tag ) {
         PMDSPP_TFDM_AddTiffField( "log_vol_id",
                                   tmp_buf,
                                  &PMDSPV_TiffList,
                                   status_code);
         ERRSIM_on_err_goto_exit( *status_code );
      }
      else {
         sprintf( PMDSPV_TiffList.list[itag].value , "%s", tmp_buf );
      }
                
/* ==========================================================================
   Set total parameters number
   ========================================================================== */
       npar = TIFSID_nbpar + PMDSPV_TiffList.num;

/* ==========================================================================
   Generate a temp file for header analysis out file when MPH-SPH
   ========================================================================== */
       if( !strcmp( data_format_str, "MPH-SPH" ) ) {
          LDEFIP_UTIL_gen_tmp_name( temp_tif_ann_file, status_code );
          ERRSIM_on_err_goto_exit( *status_code );
       }
       else {
          strcpy( temp_tif_ann_file, tif_ann_file );
       }

/* ==========================================================================
   Set the number of images found in the file
   ========================================================================== */
       TIFSIP_set_imgnum(temp_tif_ann_file, 1, status_code);
       ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the number of total parameters for each image
   ========================================================================== */
       TIFSIP_set_parnum(temp_tif_ann_file, 0, npar, status_code);
       ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute internal parameters
   ========================================================================== */
       TIFSIP_set_blockinfo(temp_tif_ann_file, 0, &bpar, status_code);
       ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open tiff file - returns file handle (tifChannel)
   ========================================================================== */
       TIFSIP_open_tiff(temp_tif_ann_file, 'w', &tifChannel, status_code);
       ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Writing of basic parameters and internal data
   ========================================================================== */
       TIFSIP_store_blockinfo( tifChannel, 0, status_code);
       ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Writing parameters
   ========================================================================== */
       for(itag = 0; itag < PMDSPV_TiffList.num; itag++)
       {
	  param.tag = PMDSPV_TiffList.list[itag].tag;
	  param.type = PMDSPV_TiffList.list[itag].type;
	  param.val = (void *)(PMDSPV_TiffList.list[itag].value);
	  param.length = strlen(PMDSPV_TiffList.list[itag].value) + 1;
	  TIFSIP_store_par(tifChannel, 0, &param, status_code);
	  ERRSIM_on_err_goto_exit( *status_code );
       }

/* ==========================================================================
   Close tiff file
   ========================================================================== */
      TIFSIP_close_tiff( tifChannel, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Reopen tiff file in update mode - returns file handle (tifChannel)
   ========================================================================== */
      TIFSIP_open_tiff(temp_tif_ann_file, 'u', &tifChannel, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute internal parameters
   ========================================================================== */
      TIFSIP_get_blockinfo(tifChannel, 0, &bpar, status_code);
      ERRSIM_on_err_goto_exit( *status_code );


/* ==========================================================================
   Update image width and height
   ========================================================================== */
      param.tag = IMAGE_WIDTH;
      param.type = TYPE_UINT;
      param.val = (void *) &(PMDSPV_prod_image.image_width);
      param.length = 1;
      TIFSIP_store_par(tifChannel, 0, &param, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      param.tag = IMAGE_LENGTH;
      param.type = TYPE_UINT;
      param.val = (void *) &(PMDSPV_prod_image.image_height);
      param.length = 1;
      TIFSIP_store_par(tifChannel, 0, &param, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update antenna pattern and range spreading loss correction flag according
   to the product type
   ========================================================================== */
      switch( product_type ) {
         case PMDSIE_raw_prod:
         case PMDSIE_slc_prod:
         case PMDSIE_slci_prod:
            sprintf( tmp_buf, "0" );
            break;

         case PMDSIE_pri_prod:
         case PMDSIE_gec_prod:
         case PMDSIE_gtc_prod:
            sprintf( tmp_buf, "1" );
            break;
      }

      param.tag = ANTENNA_ELEVATION_GAIN_FLAG;
      param.type = TYPE_ASCII;
      param.val = (void *) tmp_buf;
      param.length = strlen( tmp_buf ) + 1;
      TIFSIP_store_par(tifChannel, 0, &param, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      param.tag = SPREAD_LOSS_COMP_FLAG;
      param.type = TYPE_ASCII;
      param.val = (void *) tmp_buf;
      param.length = strlen( tmp_buf ) + 1;
      TIFSIP_store_par(tifChannel, 0, &param, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close tiff file
   ========================================================================== */
      TIFSIP_close_tiff( tifChannel, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Open tif_ann_file
   ========================================================================== */
      if( !strcmp( data_format_str, "MPH-SPH" ) ) {

/* ==========================================================================
   Open temp tiff file - returns file handle (tifChannel)
   ========================================================================== */
         TIFSIP_open_tiff(temp_tif_ann_file, 'r', &tifChannel, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get image num
   ========================================================================== */
         TIFSIP_get_imgnum( tifChannel, &nimg, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get basic par
   ========================================================================== */
         TIFSIP_get_blockinfo( tifChannel, 0, &bpar, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
         IANNIP_MPHP_GetAnnotations( tifChannel, 0, inp_ima_num,
                                     bpar, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close temp_tif_ann_file and delete it
   ========================================================================== */
         TIFSIP_close_tiff( tifChannel, status_code);
         ERRSIM_on_err_goto_exit( *status_code );
         FILSIP_delete( temp_tif_ann_file, &log_status_code );

/* ==========================================================================
   Set the number of images found in the file
   ========================================================================== */
         TIFSIP_set_imgnum( tif_ann_file, 1, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set new npar of tif_ann_file
   ========================================================================== */
         npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Set the number of total parameters for each image
   ========================================================================== */
         TIFSIP_set_parnum( tif_ann_file, 0, npar, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set dummy imagewidth and imagelenght
   ========================================================================== */
         bpar.imagewidth = 0; 
         bpar.imagelength = 0;

/* ==========================================================================
   Compute internal parameters
   ========================================================================== */
         TIFSIP_set_blockinfo( tif_ann_file, 0, &bpar, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open tiff file - returns file handle (tifChannel)
   ========================================================================== */
         TIFSIP_open_tiff( tif_ann_file, 'w', &tifChannel, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Writing of basic parameters and internal data
   ========================================================================== */
         TIFSIP_store_blockinfo( tifChannel, 0, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

         IANNIP_MPHP_PutAnnotations(  tifChannel, 0, inp_ima_num,
                                      status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close tiff file
   ========================================================================== */
         TIFSIP_close_tiff( tifChannel, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Reopen tiff file in update mode - returns file handle (tifChannel)
   ========================================================================== */
         TIFSIP_open_tiff( tif_ann_file, 'u', &tifChannel, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute internal parameters
   ========================================================================== */
         TIFSIP_get_blockinfo(tifChannel, 0, &bpar, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set real value of imagewidth and imagelength
   ========================================================================== */
         param.tag = IMAGE_WIDTH;
         param.type = TYPE_UINT;
         param.val = (void *) &PMDSPV_prod_image.image_width;
         param.length = 1;
         TIFSIP_store_par(tifChannel, 0, &param, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

         param.tag = IMAGE_LENGTH;
         param.type = TYPE_UINT;
         param.val = (void *) &PMDSPV_prod_image.image_height;
         param.length = 1;
         TIFSIP_store_par(tifChannel, 0, &param, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close tiff file
   ========================================================================== */
         TIFSIP_close_tiff( tifChannel, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

      }

/* ==========================================================================
   Free tag in memory
   ========================================================================== */
      PMDSPP_TFDM_FreeTiffField ( &PMDSPV_TiffList, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

   }

error_exit:;

/* ==========================================================================
      Close annotation file
   ========================================================================== */
   if( mode == PMDSIE_HeaderDecodeMode )
   {
      PMDSIP_ANNF_SetAnnFile( PMDSPE_ANNF_FileNameClose,
                              PMDSPE_ANNF_FileNameType,
                              NULL,
                              (void*)output_file,
                              status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Free allocated memory
   ========================================================================== */
   MEMSIP_free((void **) &buffer);

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSIP_Deformat */
