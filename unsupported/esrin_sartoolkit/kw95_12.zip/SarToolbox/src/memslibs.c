/* ==========================================================================
   $MODULE_HEADER

      $NAME              MEMS_LIBS

      $FUNCTION          Memory management module

      $ROUTINE           MEMSIP_dump
                         MEMSIP_alloc
                         MEMSIP_realloc
                         MEMSIP_free
                         MEMSIP_free_all
                         MEMSIP_size

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       04-FEB-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>

#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include MEMS_PGLB_H

/* ==========================================================================
                      LOCAL ROUTINE DECLARATION SECTION
   ========================================================================== */
static void printPointers( MEMSPT_pointer *p )
{
   while( p != NULL ) {
      fprintf(stdout, "%d\t%s\t%d\t%u\t%d\n", p, p->routine, p->pointer, 
                                                 p->memsiz, p->next);
      p = p->next;
   }
   fprintf(stdout,"end\n\n");
}   

static INTx4 addPointer( void *pVoid, size_t nbyte)
{
   MEMSPT_pointer **p;

   p = &MEMSPV_pointers;
   while( (*p) != (MEMSPT_pointer *) NULL ) {
      p = &((*p)->next);
   } 

   (*p) = (MEMSPT_pointer *) malloc( sizeof( MEMSPT_pointer ) );
   if( (*p) != (MEMSPT_pointer *) NULL ) {
      (*p)->routine = (char *) 
           malloc( strlen ( ERRSIV_routine_stack[ ERRSIV_level ] ) + 1);
      if( (*p)->routine != (char *) NULL ) {
         strcpy( (*p)->routine, ERRSIV_routine_stack[ ERRSIV_level ] );
         (*p)->memsiz = nbyte;
         (*p)->pointer = pVoid;
         (*p)->next = (MEMSPT_pointer *) NULL;
      }
      else {
         return( -1 );
      }
   }
   else {
      return( -1 );
   }
   return( 1 );
}

static INTx4 updatePointer( MEMSPT_pointer *p, void *pVoid,
                            void *pOld, size_t nbyte)
{

   if( p == NULL ) {
      return( -1 );
   } 
   while( p!= (MEMSPT_pointer *) NULL ) {
      if( p->pointer == pOld ){
         p->pointer = pVoid;
         p->memsiz  = nbyte;
         break;
      }
      p = p->next;
   }

   return( 1 );
}

static void deletePointer( void *pVoid, UINTx1 *flag )
{
   MEMSPT_pointer  **p;
   MEMSPT_pointer   *tmpPointer;

   *flag = 1;
   p = &MEMSPV_pointers;

   while( ((*p) != (MEMSPT_pointer *) NULL) && (*flag == 1) ) {
   
      if( (*p)->pointer == pVoid ) {
         tmpPointer = (*p);
         (*p) = (*p)->next;
         tmpPointer->next = (MEMSPT_pointer *) NULL;
         free( tmpPointer->routine );
         tmpPointer->routine = (char *) NULL;
         free( tmpPointer );
         tmpPointer = (MEMSPT_pointer *) NULL;
         *flag = 0;
      }   
      else {
         p = &((*p)->next);
      }
   }

   if( *flag == 1 ) {
#ifdef __VMSTEST__
      fprintf( stdout, "\n\nPointer %d to be deleted not found\n", pVoid );
#endif
   }

}

static void deleteAllPointers()
{
   MEMSPT_pointer  **p;
   MEMSPT_pointer   *tmpPointer;

   p = &MEMSPV_pointers;

   while( ((*p) != (MEMSPT_pointer *) NULL) ) {

      tmpPointer = (*p)->next;

      free( (*p)->routine );
      (*p)->routine = (char *) NULL;
      free( (*p) );
      (*p) = (MEMSPT_pointer *) NULL;

      *p = tmpPointer;
   }

}

static void memorySize( MEMSPT_pointer *p, UINTx4 *totSize )
{

   while( p != NULL ) {
      *totSize += (((UINTx4) p->memsiz) + ((UINTx4) sizeof( ERRSIT_proc_name )) +
                   ((UINTx4) sizeof( void * )) + ((UINTx4) sizeof( size_t )) + 
                   ((UINTx4) sizeof( MEMSPT_pointer * ) ));
      p = p->next;
   }

}   

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_dump

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine print on stdout the actual status of memory.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void MEMSIP_dump   ( )
{

/* ==========================================================================
   Print all saved pointer
   ========================================================================== */
   fprintf(stdout,"\n");
   printPointers( MEMSPV_pointers );

error_exit:;

}/* MEMSIP_dump */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_alloc

        $TYPE         FUNCTION

        $INPUT        size of pointer to be allocated

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine manages the allocation of buffer memory.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void *MEMSIP_alloc     ( /*IN    */ size_t	         size )
{
   void		         *pVoid;

/* ==========================================================================
   To avoid problems ...
   ========================================================================== */
   if( size == 0 ) {
      size = 1;
   }

/* ==========================================================================
   Allocate Memory
   ========================================================================== */
   pVoid = malloc( size );
   if( pVoid == (void *) NULL) {
      goto error_exit;
   }

#ifdef __TRACE__
   printf("Alloc %d size=%0d\n", pVoid, size);
#endif

/* ==========================================================================
   Save pointer
   ========================================================================== */
   if( addPointer( pVoid, size ) == -1 ) {
      return((void *) NULL);
   }

#ifdef __TRACE__
   printPointers( MEMSPV_pointers );
#endif

error_exit:;

/* ==========================================================================
   Return Allocated Memory
   ========================================================================== */
   return( pVoid );

}/* MEMSIP_alloc */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_realloc

        $TYPE         FUNCTION

        $INPUT        pVoid     :   pointer to be reallocated
                      size	:   size of pointer to be reallocated

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine manages the reallocation of buffer memory.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void *MEMSIP_realloc     ( /*IN    */ void              *pVoid, 
                           /*IN    */ size_t	         size )
{

/* ==========================================================================
   To avoid problems ...
   ========================================================================== */
   if( size == 0 ) {
      size = 1;
   }

/* ==========================================================================
   Allocate Memory (check if NULL)
   ========================================================================== */
   if( pVoid == (void *) NULL ) {

      pVoid = malloc( size );

      if( pVoid == (void *) NULL) {
         goto error_exit;
      }

#ifdef __TRACE__
      printf("NEW Realloc %d size=%0d\n", pVoid, size);
#endif

/* ==========================================================================
   Save pointer as it is new
   ========================================================================== */
      if( addPointer( pVoid, size ) == -1 ) {
         return((void *) NULL);
      }

   }
   else {
      void  *pOld;
      pOld = pVoid;
      pVoid = realloc( pVoid, size );
      if( pVoid == (void *) NULL) {
         goto error_exit;
      }
#ifdef __TRACE__
      printf("Realloc %d (Old %d) size=%0d\n", pVoid, pOld, size);
#endif
      if( updatePointer( MEMSPV_pointers, pVoid, pOld, size ) == -1 ) {
         return((void *) NULL);
      }
   }

#ifdef __TRACE__
   printPointers( MEMSPV_pointers );
#endif

error_exit:;

/* ==========================================================================
   Return Allocated Memory
   ========================================================================== */
   return( pVoid );

}/* MEMSIP_realloc */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_free

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine manages the deallocation of buffer memory.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void MEMSIP_free       ( /*IN    */ void               **pVoid )
{
   UINTx1 flag = 0;

/* ==========================================================================
   Check pointer
   ========================================================================== */
   if( *pVoid == (void *) NULL) {
      goto error_exit;
   }

/* ==========================================================================
   Delete saved pointer
   ========================================================================== */
   deletePointer( *pVoid, &flag );

/* ==========================================================================
   If the pointer has been found freeze memory and null pointer
   ========================================================================== */
   if( flag == 0 ) {
      free( *pVoid );
#ifdef __TRACE__
      printf("Freezed %d\n", *pVoid);
#endif
      *pVoid = (void *) NULL;
   }

/* ==========================================================================
   Print routine stack.
   ========================================================================== */
#ifdef __VMSTEST__
   if( flag == 1) {
      UINTx4 i;
      for( i=ERRSIV_level; i>0; i-- )
      {
         printf("    %s\n", ERRSIV_routine_stack[ i ] );
      }
      printf("\n");
   }
#endif

#ifdef __TRACE__
   printPointers( MEMSPV_pointers );
#endif

error_exit:;

}/* MEMSIP_free */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_free_all

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine manages the deallocation of buffer memory.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void MEMSIP_free_all   ( )
{

/* ==========================================================================
   Delete all saved pointer
   ========================================================================== */
   deleteAllPointers( );

#ifdef __TRACE__
   printPointers( MEMSPV_pointers );
#endif

error_exit:;

}/* MEMSIP_free */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_size

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       size   : size in bytes of allocated memory

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine returns the amount of allocated
                      memory via MEMSIP_alloc.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void MEMSIP_size         ( /*   OUT*/ UINTx4	        *size )
{


/* ==========================================================================
   Set memory size to 0
   ========================================================================== */
   *size = 0;

/* ==========================================================================
   Compute actual memory size
   ========================================================================== */
   memorySize( MEMSPV_pointers, size );

error_exit:;

}/* MEMSIP_size */
