/* ==========================================================================
   $MODULE_HEADER

      $NAME              IREG_WRIM

      $FUNCTION          This module contains the procedure to interpolate
                         the output images of the co-registrator tool and
                         to write them into the output files

      $ROUTINE           IREGPP_WRIM_InterpolateImages
                         IREGPP_WRIM_InitInterp
                         IREGPP_WRIM_CloseInterp
                         IREGPP_WRIM_CoreInterpolator
                         IREGPP_WRIM_FillPointsArray
                         IREGPP_WRIM_WriteMasterBlock
                         IREGPP_WRIM_MaxOverlap
                         IREGPP_WRIM_Interpolate
                         IREGPP_WRIM_WriteSlave
                         IREGPP_WRIM_CheckMemory

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       24-FEB-98     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <math.h>
#include <string.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include GIOS_INTF_H
#include TIFS_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include IANN_INTF_H
#include SRVS_INTF_H
#include IREG_INTF_H
#include IREG_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_InterpolateImages

        $TYPE         PROCEDURE

        $INPUT        inp_io     : input files descriptors array
                      NImages    : number of input (and output) images
                      TLRow      : top left row coordinate of the AoI to
                                   interpolate
                      TLCol      : top left column coordinate of the AoI to
                                   interpolate
                      BRRow      : bottom right row coordinate of the AoI to
                                   interpolate
                      BRCol      : bottom right column coordinate of the AoI to
                                   interpolate
                      RowWinSize : row block size
                      ColWinSize : column block size
                      InterpMode : interpolation mode

        $MODIFIED     out_io     : output files descriptors array

        $OUTPUT       NONE

        $GLOBAL       IREGPV_inter_bord : cell bord to add to avoid
                                          boreder effect in the interpolation

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_incons_corn
                      ERRSID_IREG_win_too_large
                      ERRSID_IREG_err_mem_alloc
                      ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure interpolates all the input images and
                      writes the output co-registered ones in their output
                      form using the warp matrices evaluated before

        $WARNING      THE GCPS COLLECTION AND THE WARP EVALUATION MUST BE
                      DONE BEFORE THA CALL TO THIS PROCEDURE

        $PDL          - Checks the number of input images
                      - Checks the corners coordinates
                      - Evaluates the number of rows and columns
                      - Checks the window sizes
                      - Allocates the array to store the numbers of slave
                        images IDs
                      - Initializes the interpolation procedures
                      - Evaluates the number of rows and columns of the slave
                        image cell to extract
                      - Sets the image data type
                      - Allocates the grid of points in which to interpolate
                      - Allocates the matrix to store the writing image
                      - Initializes the starting variables to read and write
                      - While the rows left are more then the row window size
                            - While the columns left are more then the column
                              window size
                                  - Interpolates the cell
                                  - Updates the starting variables
                            - End While
                            - If there are left columns
                                  - Evaluates the column size for the window
                                  - Interpolates the cell
                            - End If
                            - Updates the starting variables
                      - End While
                      - If there are left rows
                            - Evaluates the row size for the window
                            - While the columns left are more then the column
                              window size
                                  - Interpolates the cell
                                  - Updates the starting variables
                            - End While
                            - If there are left columns
                                  - Evaluates the column size for the window
                                  - Interpolates the cell
                            - End If
                            - Interpolates the cell
                      - End If
                      - Frees the allocated memories

   $EH
   ========================================================================== */

void IREGPP_WRIM_InterpolateImages
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ INTx4                NImages,
                         /*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                BRRow,
                         /*IN    */ INTx4                BRCol,
                         /*IN    */ INTx4                RowWinSize,
                         /*IN    */ INTx4                ColWinSize,
                         /*IN    */ IREGPT_inter_mode    InterpMode,
                         /*IN OUT*/ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WRIM_InterpolateImages";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  NRow;
   INTx4                  NCol;
   INTx4                  SNRow;
   INTx4                  SNCol;
   INTx4                  RStartR;
   INTx4                  CStartR;
   INTx4                  RStartW = 0;
   INTx4                  CStartW = 0;
   INTx4                  LastNRow;
   INTx4                  LastNCol;
   INTx4                  row;
   UINTx4                 RReadSize;
   UINTx1                *sla_imanum = (UINTx1 *)NULL;
   MATHIT_RC_float      **points = (MATHIT_RC_float **)NULL;
   MATHIT_RC_float      **ref_points = (MATHIT_RC_float **)NULL;
   size_t                 elem_size;
   float                **ImageWrite = (float **)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the number of opened images in input and output
   ========================================================================== */
   if ( NImages < 2 ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_ima_num_inv,
                         "for the co-registration" );
   }

/* ==========================================================================
   Check the corners
   ========================================================================== */
   if ( ( TLRow >= BRRow ) || ( TLCol >= BRCol ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_incons_corn, "" );
   }

/* ==========================================================================
   Evaluate the number of rows and columns
   ========================================================================== */
   NRow = BRRow - TLRow + 1;
   NCol = BRCol - TLCol + 1;

/* ==========================================================================
   Evaluate the maximum number of rows readeable
   ========================================================================== */
   IREGPP_WRIM_CheckMemory ( inp_io, &RReadSize, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the machine memory
   ========================================================================== */
   if ( (UINTx4)(RReadSize * RReadSize) < (UINTx4)(RowWinSize * ColWinSize) ) {
      RowWinSize = RReadSize;
      ColWinSize = RReadSize;
   }

/* ==========================================================================
   Check the window sizes
   ========================================================================== */
   if ( RowWinSize > NRow ) {
      RowWinSize = NRow;
   }
   if ( ColWinSize > NCol ) {
      ColWinSize = NCol;
   }

/* ==========================================================================
   Allocate the vector of slave image number for the interpolation
   ========================================================================== */
   if ( ( sla_imanum = (UINTx1 *)MEMSIP_alloc ( (size_t)(( NImages - 1 ) *
                                                sizeof (UINTx1)) ) ) ==
        (UINTx1 *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the slave image numbers array" );
   }

/* ==========================================================================
   Call the interpolation initialization
   ========================================================================== */
   IREGPP_WRIM_InitInterp ( InterpMode, sla_imanum, NImages, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate enlarged images cells dimensions
   ========================================================================== */
   SNRow = RowWinSize + 2 * IREGPV_inter_bord;
   SNCol = ColWinSize + 2 * IREGPV_inter_bord;

/* ==========================================================================
   Set the data type for reading from files
   ========================================================================== */
   switch ( inp_io[ 0 ].dt ) {
      case LDEFIE_dt_UINTx2:
         elem_size = sizeof (float);
      break;
      case LDEFIE_dt_2_INTx2:
         elem_size = 2 * sizeof (float);
      break;
      case LDEFIE_dt_float:
         elem_size = sizeof (float);
      break;
      case LDEFIE_dt_2_float:
         elem_size = 2 * sizeof (float);
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                            "" );
   }

/* ==========================================================================
   Allocate the array for point storage
   ========================================================================== */
   if ( ( points = (MATHIT_RC_float **)MEMSIP_alloc ( (size_t)(RowWinSize *
                                              sizeof (MATHIT_RC_float *)) ) ) ==
        (MATHIT_RC_float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the points storing array" );
   }
   points[ 0 ] = (MATHIT_RC_float *)NULL;
   if ( ( points[ 0 ] = (MATHIT_RC_float *)MEMSIP_alloc ( (size_t)(RowWinSize *
                                                           ColWinSize *
                                                sizeof (MATHIT_RC_float)) ) ) ==
        (MATHIT_RC_float *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the points storing array" );
   }
   for ( row=1; row<RowWinSize; row++ ) {
      points[ row ] = &(points[ 0 ][ row * ColWinSize ]); 
   }

   if ( ( ref_points = (MATHIT_RC_float **)MEMSIP_alloc ( (size_t)(RowWinSize *
                                              sizeof (MATHIT_RC_float *)) ) ) ==
        (MATHIT_RC_float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the ref_points storing array" );
   }
   ref_points[ 0 ] = (MATHIT_RC_float *)NULL;
   if ( ( ref_points[ 0 ] = (MATHIT_RC_float *)MEMSIP_alloc ( (size_t)
                                                              (RowWinSize *
                                                              ColWinSize *
                                                sizeof (MATHIT_RC_float)) ) ) ==
        (MATHIT_RC_float *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the ref_points storing array" );
   }
   for ( row=1; row<RowWinSize; row++ ) {
      ref_points[ row ] = &(ref_points[ 0 ][ row * ColWinSize ]); 
   }

/* ==========================================================================
   Allocate the writing image matrix
   ========================================================================== */
   if ( ( ImageWrite = (float **)MEMSIP_alloc ( (size_t)(RowWinSize *
                                          sizeof (float *)) ) ) ==
        (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the image block" );
   }
   for ( row=0; row<RowWinSize; row++ ) {
      ImageWrite[ row ] = (float *)NULL;
      if ( ( ImageWrite[ row ] = (float *)MEMSIP_alloc ( (size_t)(ColWinSize *
                                                         elem_size) ) ) ==
           (float *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "for the image block" );
      }
   }

/* ==========================================================================
   Set the starting indices
   ========================================================================== */
   RStartR = TLRow;
   CStartR = TLCol;

/* ==========================================================================
   Print out
   ========================================================================== */
#ifndef __TRACE__
   fprintf ( stdout, "\n\n\n Image Interpolation started ... \n\n\n" );
#endif

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) ROUND((float) NRow/(float) RowWinSize)*
                            ROUND((float) NCol/(float) ColWinSize)*
                            (NImages-1), 
                    &log_status_code );

/* ==========================================================================
   Loop over the rows blocks
   ========================================================================== */
   while ( ( RStartR + RowWinSize ) <= ( TLRow + NRow ) ) {

/* ==========================================================================
   Print out
   ========================================================================== */
#ifndef __TRACE__
/*
      if ( RStartR != TLRow ) {
         fprintf ( stdout, "\r The images have been written at the %3d ",
                   ROUND ( ( (float)(RStartR - TLRow) / NRow ) * 100 ) );
         fprintf ( stdout, "%% of the total" );
      }
*/
#endif

/* ==========================================================================
   Loop over the columns blocks
   ========================================================================== */
      while ( ( CStartR + ColWinSize ) <= ( TLCol + NCol ) ) {

/* ==========================================================================
   Call the core function
   ========================================================================== */
         IREGPP_WRIM_CoreInterpolator ( RStartR, CStartR, RowWinSize,
                                        ColWinSize, RStartW, CStartW, inp_io,
                                        out_io, NImages, InterpMode, elem_size,
                                        points, ref_points, ImageWrite,
                                        status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Update the starting column
   ========================================================================== */
         CStartR += ColWinSize;
         CStartW += ColWinSize;
      }

/* ==========================================================================
   Last columns block
   ========================================================================== */
      if ( ( ( TLCol + NCol ) - CStartR ) > 0 ) {

/* ==========================================================================
   Evaluate the remaining columns
   ========================================================================== */
         LastNCol = ( TLCol + NCol ) - CStartR;

#ifdef __TRACE__
   fprintf ( stderr, "\n\n RStartR: %d CStartR: %d", RStartR, CStartR );
   fprintf ( stderr, "\n RStartW: %d CStartW: %d", RStartW, CStartW );
#endif
/* ==========================================================================
   Call the core function
   ========================================================================== */
         IREGPP_WRIM_CoreInterpolator ( RStartR, CStartR, RowWinSize,
                                        LastNCol, RStartW, CStartW, inp_io,
                                        out_io, NImages, InterpMode, elem_size,
                                        points, ref_points, ImageWrite,
                                        status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }

/* ==========================================================================
   Update the starting row
   ========================================================================== */
      RStartR += RowWinSize;
      RStartW += RowWinSize;

/* ==========================================================================
   Reset the starting columns
   ========================================================================== */
      CStartR = TLCol;
      CStartW = 0;
   }

/* ==========================================================================
   Last rows block
   ========================================================================== */
   if ( ( ( TLRow + NRow ) - RStartR ) > 0 ) {

/* ==========================================================================
   Evaluate the remaining rows
   ========================================================================== */
      LastNRow = ( TLRow + NRow ) - RStartR;

/* ==========================================================================
   Print out
   ========================================================================== */
#ifndef __TRACE__
/*
      fprintf ( stdout, "\r The images have been written at the %3d ",
                ROUND ( ( (float)(RStartR + LastNRow - TLRow) / NRow ) * 100 ) );
      fprintf ( stdout, "%% of the total" );
*/
#endif

/* ==========================================================================
   Loop over the columns blocks ... see comment above
   ========================================================================== */
      while ( ( CStartR + ColWinSize ) <= ( TLCol + NCol ) ) {
#ifdef __TRACE__
   fprintf ( stderr, "\n\n RStartR: %d CStartR: %d", RStartR, CStartR );
   fprintf ( stderr, "\n RStartW: %d CStartW: %d", RStartW, CStartW );
#endif
         IREGPP_WRIM_CoreInterpolator ( RStartR, CStartR, LastNRow,
                                        ColWinSize, RStartW, CStartW, inp_io,
                                        out_io, NImages, InterpMode, elem_size,
                                        points, ref_points, ImageWrite,
                                        status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         CStartR += ColWinSize;
         CStartW += ColWinSize;
      }
      if ( ( ( TLCol + NCol ) - CStartR ) > 0 ) {
         LastNCol = ( TLCol + NCol ) - CStartR;
#ifdef __TRACE__
   fprintf ( stderr, "\n\n RStartR: %d CStartR: %d", RStartR, CStartR );
   fprintf ( stderr, "\n RStartW: %d CStartW: %d", RStartW, CStartW );
#endif
         IREGPP_WRIM_CoreInterpolator ( RStartR, CStartR, LastNRow,
                                        LastNCol, RStartW, CStartW, inp_io,
                                        out_io, NImages, InterpMode, elem_size,
                                        points, ref_points, ImageWrite,
                                        status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

/* ==========================================================================
   Print out
   ========================================================================== */
#ifndef __TRACE__
   fprintf ( stdout, "\n\n\n Image Interpolation ended\n" );
#endif

error_exit:;

/* ==========================================================================
   Close the interpolation stuff
   ========================================================================== */
   IREGPP_WRIM_CloseInterp ( InterpMode, NImages - 1, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&sla_imanum );

   if ( points != (MATHIT_RC_float **)NULL ) {
      MEMSIP_free ( (void **)&points[ 0 ] );
   }
   MEMSIP_free ( (void **)&points );

   if ( ref_points != (MATHIT_RC_float **)NULL ) {
      MEMSIP_free ( (void **)&ref_points[ 0 ] );
   }
   MEMSIP_free ( (void **)&ref_points );

   if ( ImageWrite != (float **)NULL ) {
      for ( row=0; row<RowWinSize; row++ ) {
         MEMSIP_free ( (void **)&ImageWrite[ row ] );
      }
   }
   MEMSIP_free ( (void **)&ImageWrite );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WRIM_InterpolateImages */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_InitInterp

        $TYPE         PROCEDURE

        $INPUT        mode       : interpolation mode
                      sla_inum   : vector with the image number of the slaves
                      NImages    : number of images to interpolate

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_inter_bord :     bord to add to the interpolating
                                              images
                      MATHID_cubi_conv_elem : number of elements of the
                                              cubic convolution interpolator
                      MATHPV_sinc_elem      : number of elements of the sinc
                                              interpolator

        $RET_STATUS   ERRSID_IREG_err_mem_alloc
                      ERRSID_IREG_inter_not_def

        $DESCRIPTION  This procedure initializes the interpolation procedures

        $WARNING      THE IMAGE ANNOTATIONS MUST BE READ BEFORE CALLING THE
                      PROCEDURE

        $PDL          - Switch over the interpolation modes
                            - Set the image borders
                            - If the Case is Cubic Convolution interpolation
                                  - The initialization of the cubic convolution
                                    interpolator must be called
                            - Break
                            - If the Case is Sinc interpolation
                                  - Loop over the images on which the
                                    interpolation can be done
                                        - The doppler frequency at centre image is
                                          evaluated
                                  - End Loop
                                  - The sinc tables are evaluated
                            - Break
                      - End Switch

   $EH
   ========================================================================== */

void IREGPP_WRIM_InitInterp
                        (/*IN    */ IREGPT_inter_mode    mode,
                         /*IN    */ UINTx1              *sla_inum,
                         /*IN    */ INTx4                NImages,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WRIM_InitInterp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  ima;
   float                 *freq = (float *)NULL;
   UINTx1                 mas_imanum = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image numbers
   ========================================================================== */
   if ( ( NImages < 1 ) || ( NImages >= IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out, "" );
   }

   for ( ima=0; ima<NImages-1; ima++ ) {
      sla_inum[ ima ] = (UINTx1)ima;
   }

/* ==========================================================================
   Switch over the interpolations mode
   ========================================================================== */
   switch ( mode ) {
      case IREGPE_im_nn:

/* ==========================================================================
   Set the interpolation bord
   ========================================================================== */
         IREGPV_inter_bord = 1;
      break;
      case IREGPE_im_bil:

/* ==========================================================================
   Set the interpolation bord
   ========================================================================== */
         IREGPV_inter_bord = 1;
      break;
      case IREGPE_im_cc:

/* ==========================================================================
   Set the interpolation bord
   ========================================================================== */
         IREGPV_inter_bord = (INTx4)(MATHID_cubi_conv_elem / 2) + 1;

/* ==========================================================================
   Call interpolation initialization
   ========================================================================== */
         MATHIP_INTR_CubiConvInit ( status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case IREGPE_im_fftshift:

/* ==========================================================================
   Set the interpolation bord
   ========================================================================== */
         IREGPV_inter_bord = 5;

/* ==========================================================================
   Set the mathematical error flag to FALSE
   ========================================================================== */
         MATHIV_err_flag = FALSE;
      break;
      case IREGPE_im_sinc: {
         INTx4                  ima;
         INTx4                  centre;
         UINTx1                 sla_annum;

/* ==========================================================================
   Set the interpolation bord
   ========================================================================== */
         IREGPV_inter_bord = (INTx4)(MATHIV_sinc_elem / 2) + 1;

/* ==========================================================================
   Allocate the doppler frequency vector
   ========================================================================== */
         if ( ( freq = (float *)MEMSIP_alloc ( (size_t)(( NImages - 1) *
                                                  sizeof (float)) )) ==
              (float *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                               "for the frequency array" );
         }

/* ==========================================================================
   Fill the vector
   ========================================================================== */
         if ( IANNIV_ImageAnnot[ mas_imanum ].SamplePerPixel == 1 ) {

/* ==========================================================================
   Real images
   ========================================================================== */
            memset ( (void *)freq, '\0', (size_t)(( NImages - 1 ) *
                     sizeof (double)) );
         }
         else {

/* ==========================================================================
   Complex images
   Loop over the slave images
   ========================================================================== */
            for ( ima=0; ima<NImages-1; ima++ ) {

/* ==========================================================================
   Set the image annotation number for the slave
   ========================================================================== */
               sla_annum = sla_inum[ ima ] + 1;

/* ==========================================================================
   Set the zone in which to read the frequency
   ========================================================================== */
               centre = (INTx4)
                  (IANNIV_ImageAnnot[ sla_annum ].SubImageTopLeftCol +
                  ( IANNIV_ImageAnnot[ sla_annum ].ImageWidth / 2 ));
               
/* ==========================================================================
   Evaluate the vector of doppler centroid frequency
   ========================================================================== */
               IANNIP_GETP_DoppCentFreqEval ( sla_annum, centre, centre,
                                              &freq[ ima ], status_code );
               ERRSIM_on_err_goto_exit ( *status_code );
            }
         }

/* ==========================================================================
   Initialize the sinc interpolation
   ========================================================================== */
         MATHIP_INTR_SincInit ( freq, NImages - 1, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
      break;
      case IREGPE_im_ccfftshift:

/* ==========================================================================
   Set the interpolation bord
   ========================================================================== */
         IREGPV_inter_bord =
            ( ( (INTx4)(MATHID_cubi_conv_elem / 2) + 1 ) > 5 ) ?
            ( (INTx4)(MATHID_cubi_conv_elem / 2) + 1 ) :
            5;

/* ==========================================================================
   Call interpolation initialization
   ========================================================================== */
         MATHIP_INTR_CubiConvInit ( status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Set the mathematical error flag to FALSE
   ========================================================================== */
         MATHIV_err_flag = FALSE;
      break;
      case IREGPE_im_sincfftshift: {
         INTx4                  ima;
         INTx4                  centre;
         UINTx1                 sla_annum;

/* ==========================================================================
   Set the interpolation bord
   ========================================================================== */
         IREGPV_inter_bord =
            ( ( (INTx4)(MATHIV_sinc_elem / 2) + 1 ) > 5 ) ?
            ( (INTx4)(MATHIV_sinc_elem / 2) + 1 ) :
            5;

/* ==========================================================================
   Allocate the doppler frequency vector
   ========================================================================== */
         if ( ( freq = (float *)MEMSIP_alloc ( (size_t)((NImages - 1) *
                                                  sizeof (float)) )) ==
              (float *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                               "for the frequency array" );
         }

/* ==========================================================================
   Fill the vector
   ========================================================================== */
         if ( IANNIV_ImageAnnot[ mas_imanum ].SamplePerPixel == 1 ) {

/* ==========================================================================
   Real images
   ========================================================================== */
            memset ( (void *)freq, '\0', (size_t)(( NImages - 1 ) *
                     sizeof (double)) );
         }
         else {

/* ==========================================================================
   Complex images
   Loop over the slave images
   ========================================================================== */
            for ( ima=0; ima<NImages-1; ima++ ) {

/* ==========================================================================
   Set the image annotation number for the slave
   ========================================================================== */
               sla_annum = sla_inum[ ima ] + 1;

/* ==========================================================================
   Set the zone in which to read the frequency
   ========================================================================== */
               centre = (INTx4)
                  (IANNIV_ImageAnnot[ sla_annum ].SubImageTopLeftCol +
                  ( IANNIV_ImageAnnot[ sla_annum ].ImageWidth / 2 ));
               
/* ==========================================================================
   Evaluate the vector of doppler centroid frequency
   ========================================================================== */
               IANNIP_GETP_DoppCentFreqEval ( sla_inum[ ima ], centre, centre,
                                              &freq[ ima ], status_code );
               ERRSIM_on_err_goto_exit ( *status_code );
            }
         }

/* ==========================================================================
   Initialize the sinc interpolation
   ========================================================================== */
         MATHIP_INTR_SincInit ( freq, NImages - 1, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Set the mathematical error flag to FALSE
   ========================================================================== */
         MATHIV_err_flag = FALSE;
      }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_inter_not_def, "" );
   }

error_exit:;

/* ==========================================================================
   Free the allocated array
   ========================================================================== */
   MEMSIP_free ( (void **)&freq );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WRIM_InitInterp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_CloseInterp

        $TYPE         PROCEDURE

        $INPUT        NImages : number of images that could be opened
                                simultaneously

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGID_MaxImaNum : maximum number of opened images

        $RET_STATUS   ERRSID_IREG_image_number_out

        $DESCRIPTION  This procedure closes all the co-registrator stuff

        $WARNING      NONE

        $PDL          - Checks the number od slaves
                      - Switch over the differents modes of interpolation

   $EH
   ========================================================================== */

void IREGPP_WRIM_CloseInterp
                        (/*IN    */ IREGPT_inter_mode    mode,
                         /*IN    */ INTx4                NImages,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WRIM_CloseInterp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( ( NImages < 1 ) || ( NImages >= IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out, "" );
   }

/* ==========================================================================
   Set the mathematical error flag to TRUE
   ========================================================================== */
   MATHIV_err_flag = TRUE;

/* ==========================================================================
   Switch over the interpolation modes
   ========================================================================== */
   switch ( mode ) {
      case IREGPE_im_cc:
      case IREGPE_im_ccfftshift:
         MATHIP_INTR_CubiConvClose ( status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case IREGPE_im_sinc:
      case IREGPE_im_sincfftshift:
         MATHIP_INTR_SincClose ( NImages, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WRIM_CloseInterp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_CoreInterpolator

        $TYPE         PROCEDURE

        $INPUT        RStartR    : starting row to read from the master file
                      CStartR    : starting column to read from the master file
                      NRow       : number of rows to read
                      NCol       : number of columns to read
                      RStartW    : starting row to write in the master file
                      CStartW    : starting column to write in the master file
                      inp_io     : array of input files descriptors
                      out_io     : array of output files descriptors
                      NImages    : number of input images
                      mode       : interpolation mode
                      elem_size  : size of one image element

        $MODIFIED     points     : array to store the points in which to
                                   interpolate
                      ref_points : array to store the points in which to
                                   interpolate
                      ImageWrite : matrix in which to store the output image

        $OUTPUT       NONE

        $GLOBAL       IREGPV_warp_deg
                      IREGPV_inter_bord

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure is the core of the blocking interpolation
                      procedure of the master image

        $WARNING      THE WARP MATRICES MUST BE EVALUATED AND THE GLOBAL
                      VARIABLES WITH THEM MUST BE FILLED BEFORE CALLING THE
                      INTERPOLATION PROCEDURES

        $PDL          - Fills the array of points in the master block
                      - Evaluates the total number of points
                      - Re-writes the master block
                      - Loop over the slave images
                            - Converts the points coordinates from the master
                              reference system to the slave referece system
                            - Finds the maximum overlap zone in the slave
                              reference system
                            - Evaluates the number of rows and columns of the
                              slave image cell
                            - Evaluates the centre of the image cell
                            - Enlarges the slave image cell borders
                            - Re-evaluates the Top Left coordinates of the cell
                            - Allocates the image matrix in which to store the
                              slave cell
                            - Extracts the slave cell
                            - Re-scale the points in the cell
                            - Interpolates the slave cell
                            - Writes the slave cell in its file
                            - Frees the allocated memories for the image read
                              slave cell
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_WRIM_CoreInterpolator
                        (/*IN    */ INTx4                RStartR,
                         /*IN    */ INTx4                CStartR,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ INTx4                RStartW,
                         /*IN    */ INTx4                CStartW,
                         /*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ INTx4                NImages,
                         /*IN    */ IREGPT_inter_mode    mode,
                         /*IN    */ size_t               elem_size,
                         /*IN OUT*/ MATHIT_RC_float    **points,
                         /*IN OUT*/ MATHIT_RC_float    **ref_points,
                         /*IN OUT*/ float              **ImageWrite,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WRIM_CoreInterpolator";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;
   INTx4                  ima;
   INTx4                  STLRow;
   INTx4                  STLCol;
   INTx4                  SBRRow;
   INTx4                  SBRCol;
   INTx4                  SlaveNRow;
   INTx4                  SlaveNCol;
   INTx4                  MaxNRowCol;
   MATHIT_RC              corn[ 4 ];
   MATHIT_RC              centre;
   float                  filler = 0;
   float                **ImageRead = (float **)NULL;
   UINTx1                 mas_imanum = 0;
   INTx1                  valid;
   LDEFIT_data_type       DataType = LDEFIE_dt_undef;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Find the data type after the extraction ( always floating point )
   ========================================================================== */
   DataType = ( inp_io[ mas_imanum ].val.tif.bpar.sampleperpixel == 1 ) ?
      LDEFIE_dt_float : LDEFIE_dt_2_float;

/* ==========================================================================
   Reset the points arrays for eventually NCol changes
   ========================================================================== */
   for ( row=1; row<NRow; row++ ) {
      points[ row ] = &(points[ 0 ][ row * NCol ]);
      ref_points[ row ] = &(ref_points[ 0 ][ row * NCol ]);
   }

/* ==========================================================================
   Fill the point array
   ========================================================================== */
   IREGPP_WRIM_FillPointsArray ( RStartR, CStartR, NRow, NCol, points,
                                 status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   
/* ==========================================================================
   Re-write the master image block
   ========================================================================== */
   IREGPP_WRIM_WriteMasterBlock ( &inp_io[ mas_imanum ], RStartR, CStartR,
                                  RStartW, CStartW, NRow, NCol, ImageWrite,
                                  &out_io[ mas_imanum ], status_code );
   ERRSIM_on_err_goto_exit ( *status_code );   

/* ==========================================================================
   Slaves loop
   ========================================================================== */
   for ( ima=1; ima<NImages; ima++ ) {

/* ==========================================================================
   Convert the master points into slave
   ========================================================================== */
      IREGPP_WAEV_VectMas2Sla ( points, NRow, NCol, IREGPV_warp_deg, ima,
                                ref_points, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Find the maximum overlap square
   ========================================================================== */
      IREGPP_WRIM_MaxOverlap ( NRow, NCol, ref_points, &STLRow, &STLCol,
                               &SBRRow, &SBRCol, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the number of rows and columns
   ========================================================================== */
      SlaveNRow = SBRRow - STLRow + 1;
      SlaveNCol = SBRCol - STLCol + 1;

/* ==========================================================================
   Evaluate the cell centre
   ========================================================================== */
      centre.row = (double)STLRow + ( (double)SlaveNRow ) / 2;
      centre.col = (double)STLCol + ( (double)SlaveNCol ) / 2;

/* ==========================================================================
   Ensure the output for the constant shift interpolator
   ========================================================================== */
      if ( SlaveNRow < NRow ) {
         SlaveNRow = NRow;
      }
      if ( SlaveNCol < NCol ) {
         SlaveNCol = NCol;
      }

/* ==========================================================================
   Enlarge the cell for the interpolation
   ========================================================================== */
      SlaveNRow += 2 * IREGPV_inter_bord;
      SlaveNCol += 2 * IREGPV_inter_bord;

/* ==========================================================================
   Fix the top left coordinates
   ========================================================================== */
      STLRow -= IREGPV_inter_bord;
      STLCol -= IREGPV_inter_bord;

/* ==========================================================================
   Evaluate the maximum allowed value for the image cell sizes
   ========================================================================== */
      MaxNRowCol = ( IREGPV_int_win_row_size > IREGPV_int_win_col_size ) ?
         IREGPV_int_win_row_size * sqrt ( 2. ) :
         IREGPV_int_win_col_size * sqrt ( 2. );
      MaxNRowCol += MaxNRowCol * IREGPD_enlarge_fact;

/* ==========================================================================
   Check the image sizes
   ========================================================================== */
      if ( ( SlaveNRow > MaxNRowCol ) || ( SlaveNCol > MaxNRowCol ) ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_ima_size_too_large,
                            "" );
      }

/* ==========================================================================
   Allocate the reading image matrix
   ========================================================================== */
#ifdef __TRACE__
   fprintf ( stderr, "\n ------ trace message ------\n" );
   fprintf ( stderr, "\n SlaveNRow: %d SlaveNCol: %d", SlaveNRow, SlaveNCol );
#endif
      if ( ( ImageRead = (float **)MEMSIP_alloc ( (size_t)(SlaveNRow *
                                                    sizeof (float *)) ) ) ==
           (float **)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "for the image block" );
      }
      for ( row=0; row<SlaveNRow; row++ ) {
         ImageRead[ row ] = (float *)NULL;
         if ( ( ImageRead[ row ] = (float *)MEMSIP_alloc ( (size_t)(SlaveNCol *
                                                      elem_size) ) ) ==
              (float *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                               "for the image block" );
         }
      }

/* ==========================================================================
   Extract the slave cell
   ========================================================================== */
      IREGPP_GCPE_CellExtractor ( &inp_io[ ima ], centre, (UINTx4)SlaveNRow,
                                  (UINTx4)SlaveNCol, (INTx1)ima,
                                  filler, (double)0,
                                  &valid, ImageRead, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Print out
   ========================================================================== */
      SRVSIP_trace_comp ( &log_status_code );

/* ==========================================================================
   Check if the image is partially internally to the image
   ========================================================================== */
      if ( valid != - 1 ) {

/* ==========================================================================
   Re-scale the points coordinates WRT the top left cell coordinates
   ========================================================================== */
         for ( row=0; row<NRow; row++ ) {
            for ( col=0; col<NCol; col++ ) {
               ref_points[ row ][ col ].row -= (float)STLRow;
               ref_points[ row ][ col ].col -= (float)STLCol;
            }
         }

/* ==========================================================================
   Interpolate the slave cell
   ========================================================================== */
         IREGPP_WRIM_Interpolate ( (UINTx1)ima, mode, ImageRead, SlaveNRow,
                                   SlaveNCol, ref_points, NRow, NCol, DataType,
                                   filler, ImageWrite, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
      else {

/* ==========================================================================
   Zero the write image block
   ========================================================================== */
         for ( row=0; row<NRow; row++ ) {
            memset ( (void *)ImageWrite[ row ], '\0',
                     (size_t)(NCol * elem_size) );
         }
      }

/* ==========================================================================
   Write the slave block
   ========================================================================== */
      IREGPP_WRIM_WriteSlave ( RStartW, CStartW, NRow, NCol, ImageWrite,
                               &out_io[ ima ], status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
      if ( ImageRead != (float **)NULL ) {
         for ( row=0; row<SlaveNRow; row++ ) {
            MEMSIP_free ( (void **)&ImageRead[ row ] );
         }
         MEMSIP_free ( (void **)&ImageRead );
      }
   }

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   if ( ImageRead != (float **)NULL ) {
      for ( row=0; row<SlaveNRow; row++ ) {
         MEMSIP_free ( (void **)&ImageRead[ row ] );
      }
   }
   MEMSIP_free ( (void **)&ImageRead );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WRIM_CoreInterpolator */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_FillPointsArray

        $TYPE         PROCEDURE

        $INPUT        TLRow : top left row coordinate of the master block
                      TLCol : top left column coordinate of the master block
                      NRow  : number of rows of the block
                      NCol  : number of columns of the block

        $MODIFIED     NONE

        $OUTPUT       array : array of points coordinates describing the pixels
                              of the master block

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills an array of points coordinates with
                      the pixels master block coordinates

        $WARNING      NONE

        $PDL          - Loop over the rows
                            - Loop over the columns
                                  - Fills the row pixel coordinate
                                  - Fills the column pixel coordinate
                            - End Loop
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_WRIM_FillPointsArray
                        (/*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*   OUT*/ MATHIT_RC_float    **array,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WRIM_FillPointsArray";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Fill the point array
   ========================================================================== */
   for ( row=0; row<NRow; row++ ) {
      for ( col=0; col<NCol; col++ ) {
         array[ row ][ col ].row = (float)(TLRow + row);
         array[ row ][ col ].col = (float)(TLCol + col);
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WRIM_FillPointsArray */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_WriteMasterBlock

        $TYPE         PROCEDURE

        $INPUT        inp_io     : input master file descriptor
                      RStartR    : starting row to read the master cell
                      CStartR    : starting column to read the master cell
                      RStartW    : starting row to write the master cell
                      CStartW    : starting column to write the master cell
                      NRow       : number of rows to write
                      NCol       : number of columns to write

        $MODIFIED     NONE

        $OUTPUT       ImageWrite : image matrix in which to store the output
                                   master cell
                      out_io     : output master file descriptor

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure write the master cell into the output file
                      in the new reference system

        $WARNING      NONE

        $PDL          - Evaluates the cell centre coordinates
                      - Extracts the master cell
                      - Opens the output master file writing mode
                            - Loop over the block rows
                                  - Writes the master image line
                            - End Loop
                      - Closes the output master file writing mode

   $EH
   ========================================================================== */

void IREGPP_WRIM_WriteMasterBlock
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ INTx4                RStartR,
                         /*IN    */ INTx4                CStartR,
                         /*IN    */ INTx4                RStartW,
                         /*IN    */ INTx4                CStartW,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN OUT*/ float              **ImageWrite,
                         /*IN OUT*/ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WRIM_WriteMasterBlock";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 mas_imanum = 0;
   MATHIT_RC              centre;
   float                  filler  = 0;
   INTx4                  row;
   INTx1                  valid;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the cell centre
   ========================================================================== */
   centre.row = (double)(RStartR + (INTx4)(NRow / 2));
   centre.col = (double)(CStartR + (INTx4)(NCol / 2));

/* ==========================================================================
   Extract the master cell
   ========================================================================== */
   IREGPP_GCPE_CellExtractor ( inp_io, centre, NRow, NCol, mas_imanum,
                               filler, (double)0, &valid,
                               ImageWrite, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Open the master writing image mode
   ========================================================================== */
   GIOSIP_open_line ( out_io, 'x', CStartW, CStartW + NCol - 1, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Write the master block
   ========================================================================== */
   for ( row=0; row<NRow; row++ ) {
      GIOSIP_write_line ( out_io, RStartW + row, (void *)(ImageWrite[ row ]),
			  status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Close the master writing mode
   ========================================================================== */
   GIOSIP_close_line ( out_io, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WRIM_WriteMasterBlock */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_MaxOverlap

        $TYPE         PROCEDURE

        $INPUT        NRow   : number of rows of the grid
                      NCol   : number of columns of the grid
                      points : array of points

        $MODIFIED     NONE

        $OUTPUT       TLRow  : top left row coordinate of the square
                      TLCol  : top left column coordinate of the square
                      BRRow  : bottom right row coordinate of the square
                      BRCol  : bottom right column coordinate of the square

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the top left and bottom right
                      corners of the square surrounding the set of points
                      coordinates

        $WARNING      NONE

        $PDL          - Loop over the number of grid rows
                            - Loop over the number of columns of the grid
                                  - Finds the minima and the maxima of the
                                    points of the grid
                            - End Loop
                      - End Loop
                      - Fills the output square coordinates

   $EH
   ========================================================================== */

void IREGPP_WRIM_MaxOverlap
                        (/*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ MATHIT_RC_float    **arr,
                         /*   OUT*/ INTx4               *TLRow,
                         /*   OUT*/ INTx4               *TLCol,
                         /*   OUT*/ INTx4               *BRRow,
                         /*   OUT*/ INTx4               *BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WRIM_MaxOverlap";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;
   MATHIT_RC_float        min_rc =  { 1.e+38, 1.e+38 };
   MATHIT_RC_float        max_rc =  { -1.e+38, -1.e+38 };

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Search the minimum coordinates among the rows
   ========================================================================== */
   for ( row=0; row<NRow; row++ ) {
      for ( col=0; col<NCol; col++ ) {

         /* minimum ... */
         if ( arr[ row ][ col ].row < min_rc.row ) {
            min_rc.row = arr[ row ][ col ].row;
         }
         if ( arr[ row ][ col ].col < min_rc.col ) {
            min_rc.col = arr[ row ][ col ].col;
         }

         /* ... and maximum */
         if ( arr[ row ][ col ].row > max_rc.row ) {
            max_rc.row = arr[ row ][ col ].row;
         }
         if ( arr[ row ][ col ].col > max_rc.col ) {
            max_rc.col = arr[ row ][ col ].col;
         }
      }
   }

/* ==========================================================================
   Set the slave cell top left coordinates
   ========================================================================== */
   *TLRow = (INTx4)(floor ( min_rc.row ));
   *TLCol = (INTx4)(floor ( min_rc.col ));
   *BRRow = (INTx4)(ceil ( max_rc.row ));
   *BRCol = (INTx4)(ceil ( max_rc.col ));

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WRIM_MaxOverlap */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_Interpolate

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      mode       : interpolation mode
                      ImageRead  : image read
                      NRowInp    : number of rows of the read image
                      NColInp    : number of columns of the read image
                      points     : matrix of points in which to interpolate
                      NRowOut    : number of rows of the matrix of points
                      NColOut    : number of columns of the matrix of points
                      DataType   : data type of the image
                      filler     : value with which to fill the out regions

        $MODIFIED     NONE

        $OUTPUT       ImageWrite : output image

        $GLOBAL       IREGPV_inter_bord

        $RET_STATUS   ERRSID_IREG_data_type_not_allow
                      ERRSID_IREG_err_mem_alloc
                      ERRSID_IREG_inter_not_def

        $DESCRIPTION  This procedure interpolates the input image block on the
                      given matrix of points in the selected mode

        $WARNING      NONE

        $PDL          - Switch over the interpolation modes
                            - Interpolates the image
                            - In the case of global constant FFT shift
                                  - Evaluates the constant shift value as the
                                    fractional part of the central point shift
                                  - Interpoaltes the image block
                                  - Copies the image block without the added
                                    borders in a float ( or 2 float ) image
                                    block
                            - Break
                            - In the case of FFT shift column by column
                                  - Allocates the vector of shifts
                                  - Zeroes its elements
                                  - Fills it with the fractional part of the
                                    shift column by column
                                  - Interpoaltes the image block
                                  - Copies the image block without the added
                                    borders in a float ( or 2 float ) image
                                    block
                            - Break
                      - End Switch

   $EH
   ========================================================================== */

void IREGPP_WRIM_Interpolate
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ IREGPT_inter_mode    mode,
                         /*IN    */ float              **ImageRead,
                         /*IN    */ INTx4                NRowInp,
                         /*IN    */ INTx4                NColInp,
                         /*IN    */ MATHIT_RC_float    **points,
                         /*IN    */ INTx4                NRowOut,
                         /*IN    */ INTx4                NColOut,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ float                filler,
                         /*   OUT*/ float              **ImageWrite,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WRIM_Interpolate";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   switch over the interpolation modes
   ========================================================================== */
   switch ( mode ) {
      case IREGPE_im_nn:

/* ==========================================================================
   Nearest Neighbour
   ========================================================================== */
         MATHIP_INTR_NearestNeighbor ( (void **)ImageRead, NRowInp, NColInp,
                                       points, NRowOut, NColOut, &filler,
                                       DataType, (void **)ImageWrite,
                                       status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case IREGPE_im_bil:

/* ==========================================================================
   Bilinear
   ========================================================================== */
         MATHIP_INTR_Bilinear ( (void **)ImageRead, NRowInp, NColInp, points,
                                NRowOut, NColOut, filler, DataType,
                                (void **)ImageWrite, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case IREGPE_im_cc:

/* ==========================================================================
   Cubic Convolution
   ========================================================================== */
         MATHIP_INTR_CubicConvolution ( (void **)ImageRead, NRowInp, NColInp,
                                        points, NRowOut, NColOut, filler,
                                        DataType, (void **)ImageWrite,
                                        status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case IREGPE_im_fftshift: {
         MATHIT_RC              shift;
         INTx4                  row_half_g;
         INTx4                  col_half_g;
         INTx4                  r;
         INTx4                  c;

/* ==========================================================================
   Evaluate the shift at middle grid
   ========================================================================== */
         row_half_g = (INTx4)(NRowOut / 2);
         col_half_g = (INTx4)(NColOut / 2);
         shift.row = - (double)points[ row_half_g ][ col_half_g ].row + (double)
            (row_half_g + IREGPV_inter_bord);
         shift.col = - (double)points[ row_half_g ][ col_half_g ].col + (double)
            (col_half_g + IREGPV_inter_bord);

/* ==========================================================================
   FFT Constant Shift
   ========================================================================== */
         MATHIP_INTR_FFTConstShift ( NRowInp, NColInp, DataType,
                                     (void **)ImageRead, shift,
                                     (void **)ImageRead, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Copy the image read into the written one
   ========================================================================== */
         switch ( DataType ) {
            case LDEFIE_dt_float:
               for ( r=0; r<NRowOut; r++ ) {
                  for ( c=0; c<NColOut; c++ ) {
                     ImageWrite[ r ][ c ] =
                        ImageRead[ r + IREGPV_inter_bord ][
                                   c + IREGPV_inter_bord ];
                  }
               }
            break;
            case LDEFIE_dt_2_float:
               for ( r=0; r<NRowOut; r++ ) {
                  for ( c=0; c<NColOut; c++ ) {
                     ImageWrite[ r ][ 2 * c ] =
                        ImageRead[ r + IREGPV_inter_bord ][
                                   2 * ( c + IREGPV_inter_bord ) ];
                     ImageWrite[ r ][ 2 * c + 1 ] =
                        ImageRead[ r + IREGPV_inter_bord ][
                                   2 * ( c + IREGPV_inter_bord ) + 1 ];
                  }
               }
            break;
            default:
               ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                                  "for the FFT constant shift interpolation" );
         }
      }
      break;
      case IREGPE_im_sinc:

/* ==========================================================================
   Sinc
   ========================================================================== */
         MATHIP_INTR_Sinc ( (UINTx1)(imanum - 1), (void **)ImageRead, NRowInp,
                            NColInp, points, NRowOut, NColOut, filler, DataType,
                            (void **)ImageWrite, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case IREGPE_im_ccfftshift: {
         float                 *col_shift = (float *)NULL;
         INTx4                  r;
         INTx4                  c;
         INTx4                  row_half_g;

/* ==========================================================================
   Column by column FFT Shift
   Allocate the vector of the shifts
   ========================================================================== */
         if ( ( col_shift = (float *)MEMSIP_alloc ( (size_t)(NColInp *
                                                    sizeof (float)) ) ) ==
              (float *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                               "for the vector of shifts" );
         }

/* ==========================================================================
   Zero the vector
   ========================================================================== */
         memset ( (void *)col_shift, '\0',
                  (size_t)(NColInp * sizeof (float)) );

/* ==========================================================================
   Fill the col_shift vector
   ========================================================================== */
         row_half_g = (INTx4)(NRowOut / 2);
         for ( c=0; c<NColOut; c++ ) {
            col_shift[ c + IREGPV_inter_bord ] =
            - points[ row_half_g ][ c ].row + (float)
            (row_half_g + IREGPV_inter_bord);
         }

/* ==========================================================================
   Interpolate the image
   ========================================================================== */
         MATHIP_INTR_ImageColShift ( NRowInp, NColInp, col_shift, DataType,
                                     (void **)ImageRead, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Reset the shift in the rows
   ========================================================================== */
         for ( r=0; r<NRowOut; r++ ) {
            for ( c=0; c<NColOut; c++ ) {
                points[ r ][ c ].row = floor ( points[ r ][ c ].row );
            }
         }

/* ==========================================================================
   Cubic Convolution
   ========================================================================== */
         MATHIP_INTR_CubicConvolution ( (void **)ImageRead, NRowInp, NColInp,
                                        points, NRowOut, NColOut, filler,
                                        DataType, (void **)ImageWrite,
                                        status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Free the allocated vector
   ========================================================================== */
         MEMSIP_free ( (void **)&col_shift );
      }
      break;
      case IREGPE_im_sincfftshift: {
         float                 *col_shift = (float *)NULL;
         INTx4                  r;
         INTx4                  c;
         INTx4                  row_half_g;

/* ==========================================================================
   Column by column FFT Shift
   Allocate the vector of the shifts
   ========================================================================== */
         if ( ( col_shift = (float *)MEMSIP_alloc ( (size_t)(NColInp *
                                                    sizeof (float)) ) ) ==
              (float *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                               "for the vector of shifts" );
         }

/* ==========================================================================
   Zero the vector
   ========================================================================== */
         memset ( (void *)col_shift, '\0',
                  (size_t)(NColInp * sizeof (float)) );

/* ==========================================================================
   Fill the col_shift vector
   ========================================================================== */
         row_half_g = (INTx4)(NRowOut / 2);
         for ( c=0; c<NColOut; c++ ) {
            col_shift[ c + IREGPV_inter_bord ] =
            - points[ row_half_g ][ c ].row + (float)
            (row_half_g + IREGPV_inter_bord);
         }

/* ==========================================================================
   Interpolate the image
   ========================================================================== */
         MATHIP_INTR_ImageColShift ( NRowInp, NColInp, col_shift, DataType,
                                     (void **)ImageRead, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Reset the shift in the rows
   ========================================================================== */
         for ( r=0; r<NRowOut; r++ ) {
            for ( c=0; c<NColOut; c++ ) {
                points[ r ][ c ].row = floor ( points[ r ][ c ].row );
            }
         }

/* ==========================================================================
   Sinc
   ========================================================================== */
         MATHIP_INTR_Sinc ( (UINTx1)(imanum - 1), (void **)ImageRead, NRowInp,
                            NColInp, points, NRowOut, NColOut, filler, DataType,
                            (void **)ImageWrite, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Free the allocated vector
   ========================================================================== */
         MEMSIP_free ( (void **)&col_shift );
      }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_inter_not_def, "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WRIM_Interpolate */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_WriteSlave

        $TYPE         PROCEDURE

        $INPUT        RStartW    : starting row to write in the file
                      CStartW    : starting column to write in the file
                      NRow       : number of rows to write
                      NCol       : number of columns to write

        $MODIFIED     ImageWrite : image to write in the file
                      out_io     : output file descriptor

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure write in the output file a block of image

        $WARNING      NONE

        $PDL          - Opens the writing mode for the output file
                      - Loop over the image rows
                            - Writes the slave line
                      - End Loop
                      - Closes the writing mode for the output file

   $EH
   ========================================================================== */

void IREGPP_WRIM_WriteSlave
                        (/*IN    */ INTx4                RStartW,
                         /*IN    */ INTx4                CStartW,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN OUT*/ float              **ImageWrite,
                         /*IN OUT*/ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WRIM_WriteSlave";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Open the output slave file in writing mode
   ========================================================================== */
   GIOSIP_open_line ( out_io, 'x', CStartW, CStartW + NCol - 1, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Write the image
   ========================================================================== */
   for ( row=0; row<NRow; row++ ) {
      GIOSIP_write_line ( out_io, RStartW + row, (void *)(ImageWrite[ row ]),
                          status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Close the slave writing mode
   ========================================================================== */
   GIOSIP_close_line ( out_io, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WRIM_WriteSlave */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_CheckMemory

        $TYPE         PROCEDURE

        $INPUT        inp_io     : array of tiff files descriptors

        $MODIFIED     NONE

        $OUTPUT       SquareSize : size of the square that can be allocated

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure evaluates the size of the square block
                      of image that can be interpolated without memory crash

        $WARNING      NONE

        $PDL          - Evaluates the available memory
                      - Evaluates the necessary memory as function of the size
                      - Evaluates the maximum square size

   $EH
   ========================================================================== */

void IREGPP_WRIM_CheckMemory
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*   OUT*/ UINTx4              *SquareSize,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WRIM_CheckMemory";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 avail_mem;
   UINTx4                 needed_mem;
   UINTx4                 read_mem;
   UINTx1                 ref = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the rows reading dimensions
   ========================================================================== */
   SRVSIP_avail_memory ( &avail_mem, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Consider the reading slave image maximum sizes ...
   ========================================================================== */
   read_mem = ( IREGPV_int_win_row_size > IREGPV_int_win_col_size ) ?
      IREGPV_int_win_row_size * sqrt ( 2. ) * ( 1 + IREGPD_enlarge_fact) :
      IREGPV_int_win_col_size * sqrt ( 2. ) * ( 1 + IREGPD_enlarge_fact);
   read_mem *= read_mem * sizeof (float);

/* ==========================================================================
   ... the reading one ...
   ========================================================================== */
   needed_mem = sizeof (float);

/* ==========================================================================
   ... switch over the various image types ...
   ========================================================================== */
   switch ( inp_io[ ref ].dt ) {
      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_float:
      break;
      case LDEFIE_dt_2_INTx2:
      case LDEFIE_dt_2_float:

/* ==========================================================================
   ... to consider the complex form
   ========================================================================== */
         needed_mem *= 2;
         read_mem *= 2;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_data_type_not_allow,
                            "" );
   }

/* ==========================================================================
   Consider the grids of points
   ========================================================================== */
   needed_mem += 2 * sizeof (MATHIT_RC_float);

/* ==========================================================================
   Evaluate the size of the square
   ========================================================================== */
   *SquareSize = sqrt ( (double)( avail_mem - read_mem ) / needed_mem );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WRIM_CheckMemory */

#ifdef __EXAM__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGIP_WRIM_

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure ...

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void IREGIP_WRIM_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGIP_WRIM_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGIP_WRIM_ */
#endif
