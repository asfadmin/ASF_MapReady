/* ==========================================================================
   $MODULE_HEADER

      $NAME              FILS_LIBS

      $FUNCTION          File Libray exported services

      $ROUTINE           FILSIP_open
                         FILSIF_read
                         FILSIF_read_block
                         FILSIF_write
                         FILSIP_close
                         FILSIP_sizequota

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       21-MAR-97     AG       Initial Release
            N/A       06-JUN-97     MC       Added FILSIF_write

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#ifdef __UNIX__
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ustat.h>
#include <errno.h>
#endif

#if defined(__MC68K__) || defined(__POWERPC__)
#include <files.h>
#include <unistd.h>
#endif

#ifdef __DOS__
#include <dos.h>
#endif

#ifdef __WIN95__
#include <stdarg.h>
#ifdef __CODEWARRIOR__
typedef int WINBOOL;
#else
#include <Windows32/Base.h>
#include <Windows32/Defines.h>
#include <Windows32/Structures.h>
#include <Windows32/Functions.h>
#endif
#endif

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include FILS_INTF_H
#include FILS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIP_open

      $TYPE         Procedure

      $INPUT        file_name    :  name of the file to be open
                    mode         :  opening mode
                    size	 :  required size in Kb or zero if the size
                                    cannot be predicted

      $MODIFIED     NONE

      $OUTPUT       fp            : pointer to the file

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure open a file and return a pointer to it. 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
void FILSIP_open        (/*IN    */ FILSIT_file_name     file_name,
                         /*IN    */ char                *mode,
                         /*IN    */ UINTx4               size,
                         /*   OUT*/ FILE               **fp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "FILSIP_open";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 avail_size;
   char                   err_msg[ 132 ];
#ifdef __VMS__
   char                   vms_rop[ 8 ];
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check input
   ========================================================================== */
   if( file_name == (char *) NULL ) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_open,
                        "No file specified" );
   }

   if( mode == (char *) NULL ) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_open,
                        "No mode specified" );
   }

/* ==========================================================================
   Check sizequota if open in write and requested size is not 0
   ========================================================================== */
   if( (mode[0] == 'w') && ( size != 0 ) ) {
      FILSIP_sizequota(  file_name,
                        &avail_size,
                         status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( size > avail_size ) {
         sprintf(err_msg, "No available disk space (req %0d, avail %0d)",
                          size, avail_size ); 
	 ERRSIM_set_error( status_code,
			   ERRSID_FILS_err_open,
			   err_msg );
      }
   }

/* ==========================================================================
   Open file
   ========================================================================== */
   if (mode[0] == 'r') {
#ifdef __VMS__
      if ( mode[1] != '+' ) {
         strcpy( vms_rop, "rop=RAH" );
      }
      else {
          strcpy( vms_rop, "rop=WBH" );
      }
#endif
      *fp = fopen( file_name, mode
#ifdef __VMS__
                ,"mbc=127","mbf=2",vms_rop
#endif
                 );
   }
   else if( (mode[0] == 'a') || (mode[0] == 'w') ) {
#ifdef __VMS__
      strcpy( vms_rop, "rop=WBH" );
#endif
      *fp = fopen( file_name, mode
#ifdef __VMS__
                ,"mbc=127","mbf=2",vms_rop
#endif
                 );
   }
   else {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_open,
                        "Unmanaged open mode" );
   }


/* ==========================================================================
   Check for error
   ========================================================================== */
   if( *fp == (FILE *) NULL ) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_open,
                        file_name );
   }


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* FILSIP_open */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIF_read

      $TYPE         Procedure

      $INPUT        fp           :  pointer to the file to be read
                    data_size    :  size of the buffer to be read

      $MODIFIED     data_ptr     :  pointer where store the bytes read

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure read from an open file and store the 
                    data_size bytes in the data_ptr. Returns the effective
                    number of bytes read. 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
INTx4 FILSIF_read       (/*IN    */ FILE                *fp,
                         /*IN    */ INTx4                data_size,
                         /*IN OUT*/ void                *data_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "FILSIF_read";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  bytes_read = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check input
   ========================================================================== */
   if( fp == (FILE *) NULL ) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_read,
                        "No file pointer specified" );
   }

/* ==========================================================================
   Read from file
   ========================================================================== */
   bytes_read = fread( data_ptr, 1, data_size, fp );

/* ==========================================================================
   Check from error
   ========================================================================== */
   if( bytes_read == 0 ) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_read,
                        "EOF found" );
   }
   else if (bytes_read < 0) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_read,
                        "Access denied" );
   }
   else if (bytes_read < data_size) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_read,
                        "Not enough data" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return( bytes_read );

}/* FILSIF_read */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIF_read_block

      $TYPE         Procedure

      $INPUT        descriptor   :  pointer to the media to be read
                    data_size    :  size of the buffer to be read
                    no_lines     :  number of lines

      $MODIFIED     data_ptr     :  pointer where store the bytes read

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure read a set lines from an open media and
                    store the data_size bytes in the data_ptr.

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
void FILSIP_read_block  (/*IN    */ FILE                *fp,
                         /*IN    */ INTx4                data_size,
                         /*IN    */ INTx4                no_lines,
                         /*IN OUT*/ void               **data_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "FILSIP_read_block";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  bytes_read = 0;
   INTx4                  line;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   
   for ( line=0; line<no_lines; line++ ) {

/* ==========================================================================
   Read the line
   ========================================================================== */
      bytes_read = FILSIF_read( fp,
                                data_size,
                                data_ptr[ line ],
                                status_code );
      ERRSIM_on_err_goto_exit( *status_code );

   }
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* FILSIP_read_block */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIP_delete

      $TYPE         Procedure

      $INPUT        file_name    :  name of the file to be removed

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure deletes a file. 

      $WARNING      NONE

   $EH
   ========================================================================== */
void FILSIP_delete
                        (/*IN    */ FILSIT_file_name     file_name,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "FILSIP_delete";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check input
   ========================================================================== */
   if( file_name == (char *) NULL ) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_delete,
                        "No file specified" );
   }

/* ==========================================================================
   Deletes the file
   ========================================================================== */
#ifdef __VMS__
   remove( file_name );
#endif
#ifdef __UNIX__
   unlink( file_name );
#endif
#if defined(__MC68K__) || defined(__POWERPC__)
   remove( file_name );
#endif
#ifdef __WIN95__
   remove( file_name );
#endif
#ifdef __DOS__
   unlink( file_name );
#endif


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* FILSIP_delete */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIF_write

      $TYPE         Procedure

      $INPUT        fp           :  pointer to the file to be write
                    data_size    :  size of the buffer to be write
                    data_ptr     :  pointer to the data to store
 
      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure write into an open file data_size bytes 
                    from the data_ptr. Returns the effective number of bytes 
                    write. 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
INTx4 FILSIF_write      (/*IN    */ FILE                *fp,
                         /*IN    */ INTx4                data_size,
                         /*IN    */ void                *data_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "FILSIF_write";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  bytes_write = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check input
   ========================================================================== */
   if( fp == (FILE *) NULL ) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_write,
                        "No file pointer specified" );
   }

/* ==========================================================================
   Write to file
   ========================================================================== */
   bytes_write = fwrite( data_ptr, 1, data_size, fp );

/* ==========================================================================
   Check from error
   ========================================================================== */
   if( bytes_write < data_size ) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_write,
                        "No more space on device" );
   }
   else if (bytes_write < 0) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_err_write,
                        "Not open or write protected file" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return( bytes_write );

}/* FILSIF_write */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIP_close

      $TYPE         Procedure

      $INPUT        NONE

      $MODIFIED     fp            : pointer to the file

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure close a file and null the pointer to it. 

      $WARNING      NONE

   $EH
   ========================================================================== */
void FILSIP_close       (/*IN OUT*/ FILE               **fp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "FILSIP_close";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Close the file
   ========================================================================== */
   fclose( *fp );

/* ==========================================================================
   Null the pointer
   ========================================================================== */
   *fp = (FILE *) NULL;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* FILSIP_close */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         FILSIP_sizequota

        $TYPE         PROCEDURE

        $INPUT        filename        : a file or a direcory name

        $MODIFIED     NONE

        $OUTPUT       avail_diskspace  : amount of available space on the
			 		 file system where the file or the
			 		 directory is placed on

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_FILS_uncomput_sizequota

        $DESCRIPTION  This function returns the amount of available memory
                      in Kb on the file system where the file or the directory
		      passed in input is placed on.

        $WARNING      NONE

        $PDL          - UNIX: Use stat and ustat to find out the available
                              disk space
                      - DOS: Use _dos_getdiskfree to find out the available
                             disk space

   $EH
   ========================================================================== */
void FILSIP_sizequota
                        (/*IN    */ char                *filename,
                         /*   OUT*/ UINTx4              *avail_diskspace,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "FILSIP_sizequota";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                   msg[ 256 ];

#if defined(__MC68K__) || defined(__POWERPC__)
   char                   disk[ 256 ];
   char                   cwd[ 256 ];
   char                  *possep;
   char                   volName[ 256 ];
   short                  drvNum;
   short                  maxDrvNum = 20;
   short                  vRefNum;
   long                   freeBytes;   
#endif

#ifdef __UNIX__
   struct stat            bufStat;
   struct ustat           bufUStat;
   char                  *possep;
   char                   iname[ 256 ];
#endif

#ifdef __DOS__
   struct diskfree_t      free;
   char                   drive;
   const char             drive_a = 'a';
   unsigned char          uc_drive;
   unsigned               disk;
#endif

#ifdef  __WIN95__
   char                   drive;
   LPCSTR                 lpRootPathName;
   char                   strDrive[ 80 ];
   DWORD                  sectorsPerCluster;
   DWORD                  bytesPerSector;
   DWORD                  numberOfFreeClusters;
   DWORD                  totalNumberOfClusters;
   WINBOOL                boolStatusCode;
   DWORD                  dwordStatusCode;
   DWORD                  nBufferLength = 80;
   LPSTR                  lpBuffer;
   char                  *pcColon;
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set avail_diskspace to an initial value
   ========================================================================== */
   *avail_diskspace = UINTx4_MAX;

/* ==========================================================================
   MAC code
   ========================================================================== */
#if defined(__MC68K__) || defined(__POWERPC__)

   if( filename[ 0 ] == ':' ) {
      getcwd( cwd, 256 );
#ifdef __TRACE__
      printf("cwd = %s\n\n", cwd );
#endif
      strcpy( disk, cwd );
      possep = strchr( disk, ':' );
      if( possep != NULL ) {
         *possep = '\0';
      }
   }
   else {
      strcpy( disk, filename );
      possep = strchr( disk, ':' );
      if( possep != NULL ) {
         *possep = '\0';
      }
   }

   for( drvNum=0; ((drvNum<maxDrvNum) && strcmp(volName, disk)); drvNum++ ) {
      getvinfo( drvNum, volName, &vRefNum, &freeBytes);
   }
   if( drvNum < maxDrvNum ) {
      *avail_diskspace = freeBytes/1024;
   }
   else {
      sprintf( msg, "Size quota cannot be computed for %s",
         filename );
      ERRSIM_print_warning( msg );
   }
#endif

/* ==========================================================================
   UNIX code
   ========================================================================== */
#ifdef __UNIX__

/* ==========================================================================
   Test if the file does not exists
   ========================================================================== */
   if( (access( filename, F_OK ) == -1) &&
       (errno == ENOENT) ) {
      /* get parent directory or set it to "./" */
      strcpy( iname, filename );
      if( (possep = strrchr( iname, '/' )) != NULL ) {
         *possep = '\0';
         if( !strcmp( iname, "" ) ) {
            strcpy( iname, "./" );
         }
      }
      else {
         strcpy( iname, "./" );
      }
   }
   else {
      strcpy( iname, filename );
   }

/* ==========================================================================
   Get stat of filename
   ========================================================================== */
   if( stat( iname, &bufStat ) ) {
      sprintf( msg, "Size quota cannot be computed for %s (errno = %0d)",
         iname, errno );
      ERRSIM_print_warning( msg );
   }
   else {
/* ==========================================================================
   Get ustat of filename
   ========================================================================== */
      if( ustat( bufStat.st_dev, &bufUStat ) ) {
         sprintf( msg, "Size quota cannot be computed for %s (errno = %0d)",
            iname, errno );
         ERRSIM_print_warning( msg );
      }
      else {
         *avail_diskspace = bufUStat.f_tfree;
      }
   }

#endif

/* ==========================================================================
   DOS code
   ========================================================================== */
#ifdef __DOS__
   if( filename[ 1 ] == ':' ) {
      drive = tolower( filename[ 0 ] );
      uc_drive = drive - drive_a + 1;
   }
   else {
      _dos_getdrive(&disk);
      drive = tolower( disk + 'A' - 1 );
      uc_drive = drive - drive_a + 1;
   }

   if (_dos_getdiskfree(uc_drive, &free) != 0) {
      ERRSIM_set_error( status_code,
                        ERRSID_FILS_uncomput_sizequota,
                        "_dos_getdiskfree()" );
  }

   *avail_diskspace = ( (UINTx4) free.avail_clusters *
                        (UINTx4) free.bytes_per_sector *
                        (UINTx4) free.sectors_per_cluster )/1024;

#endif

/* ==========================================================================
   WIN95 code
   ========================================================================== */
#ifdef __WIN95__

   if( filename[ 1 ] == ':' ) {
      lpRootPathName = (LPCSTR) strDrive;
      drive = filename[ 0 ];
      sprintf( strDrive, "%c:\\", drive );
      dwordStatusCode = 1;
   }
   else {
      lpBuffer =(LPSTR) strDrive;
      lpRootPathName = (LPCSTR) strDrive;
      dwordStatusCode = GetCurrentDirectory( nBufferLength, lpBuffer );

#ifdef __TRACE__
      fprintf( stderr, "<%d>\n\n", dwordStatusCode);
      fprintf( stderr, "<%s>\n\n", lpRootPathName);
#endif

      if( (pcColon = strchr( strDrive, ':' )) ==
          (char *) NULL ) {
         dwordStatusCode = 0;
      }
      else {
         *(pcColon+1) = '\0';
         strcat( strDrive, "\\" );
      }
   }

   if( dwordStatusCode == 0 ) {
      sprintf( msg, "Size quota cannot be computed for %s",
         filename );
      ERRSIM_print_warning( msg );
   }
   else {
#ifdef __TRACE__
      fprintf( stderr, "<%s>\n\n", lpRootPathName);
#endif

      boolStatusCode = GetDiskFreeSpace(  lpRootPathName,
                                         &sectorsPerCluster,
                                         &bytesPerSector,
                                         &numberOfFreeClusters,
                                         &totalNumberOfClusters );

      if( boolStatusCode == 0 ) {
         sprintf( msg, "Size quota cannot be computed for %s",
            filename );
         ERRSIM_print_warning( msg );
      }
      else {

#ifdef __TRACE__
         fprintf( stderr, "<%ul %ul %ul %ul %ul>\n\n", boolStatusCode,
            numberOfFreeClusters, bytesPerSector, sectorsPerCluster,
            totalNumberOfClusters );
#endif

         *avail_diskspace = ( (UINTx4) ( numberOfFreeClusters *
                                         bytesPerSector *
                                         sectorsPerCluster ) ) / 1024;
#ifdef __TRACE__
         fprintf( stderr, "avail=%0d\n\n\n\n", *avail_diskspace);
#endif

      }

   }

#endif

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* FILSIP_sizequota */

