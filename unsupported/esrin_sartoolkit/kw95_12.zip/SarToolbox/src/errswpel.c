/* ==========================================================================
   $MODULE_HEADER

      $NAME          ERRS_WPEL

      $FUNCTION      Write a string to the process error log

      $ROUTINE       ERRSIP_WPEL_write
		     ERRSIP_WPEL_dump_stack

      $HISTORY

            SCR NO.      DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       23-SEP-92     DD       Initial Release

    $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <string.h>

#include "libname.h"
#include ERRS_INTF_H
#include ERRS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_WPEL_write

      $FUNCTION     Write a string to the process error log

      $INPUT        routine_name           : Name of calling routine
                    string                 : Input string

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid;

      $RET_STATUS   ERRSID_err_file_write_error

      $DESCRIPTION  This procedure inserts a new line into the process 
                    error log.

      $WARNING      NONE

   $EH
   ========================================================================== */
void ERRSIP_WPEL_write  ( /*IN    */ const ERRSIT_proc_name proc_name,
                          /*   OUT*/ char                  *string,
                          /*   OUT*/ ERRSIT_status         *status_code )
{

   const ERRSIT_proc_name routine_name = "ERRSIP_WPEL_write";
   const INTx4  block_size = 65;

   INTx4        block_no;
   INTx4        i;

   char         date_time[25];
   char        *last_char;
   char         saved_char;

   *status_code = ERRSID_normal;

   if (( ERRSPV_proc_err_log_fid != NULL ) &&
       ( strlen( string ) > 0 ))
   {
   
      fprintf(ERRSPV_proc_err_log_fid,"    %s", proc_name );

/* ==========================================================================
   Fill with blank the process name string.
   ========================================================================== */
      for( i=strlen(proc_name); i<sizeof(ERRSIT_proc_name); i++ )
      {   
         fprintf(ERRSPV_proc_err_log_fid," ");
      }

/* ==========================================================================
   Get current date and write it to the process error log.
   ========================================================================== */
      fprintf(ERRSPV_proc_err_log_fid,"%s : ", ERRSIF_LODT_out_date(date_time) );

/* ==========================================================================
   Format the output if the output strig legth is greather than the block size
   ========================================================================== */
      if ( strlen(string) > block_size )
      {
         i = 1;

         /* Calculate the block number to write */
         block_no = strlen(string)/block_size;

         /* Replace with '\0', save last char content of current block to write */
         saved_char = string[ block_size*i ];
         string[ block_size*i ] = '\0';

         /* Print the current block */
         fprintf( ERRSPV_proc_err_log_fid, "%s\n", &string[block_size*(i-1)] );

         /* Replace the last char of the current block with original content */
         string[ block_size*i ] = saved_char;

         /* Repeat the previous operation until the last block */
         for ( i = 2; i <= block_no; i++)
         {
            saved_char = string[ block_size*i ];
            string[ block_size*i ] = '\0';
            fprintf( ERRSPV_proc_err_log_fid,"%s",
             "                                                               ");
            fprintf(  ERRSPV_proc_err_log_fid, "%s\n", 
                     &string[ block_size*(i-1) ] );
            string[ block_size*i ] = saved_char;
         }

         /* Repeat the previous operation for the remaind */
         if ( strlen(string) > block_size * block_no )
         {
            fprintf(ERRSPV_proc_err_log_fid, "%s",
             "                                                               ");
            fprintf(  ERRSPV_proc_err_log_fid, "%s\n", 
                     &string[ block_size*(i-1) ] );
         }
      }
      else /* if (strlen(string) <= block_size)*/
      {
         fprintf( ERRSPV_proc_err_log_fid, "%s\n", string );
      } /* endelse ( strlen(string) <= block_size ) */

      fflush( ERRSPV_proc_err_log_fid );

   } /* if ERRSPV_proc_err_log_fid != NULL */ 

error_exit:;

} /* ERRSIP_WPEL_write */ 

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_WPEL_dump_stack

      $FUNCTION     Write stack routine on PEL

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid;

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure prints the actual stack of calls

      $WARNING      NONE

   $EH
   ========================================================================== */
void ERRSIP_WPEL_dump_stack
                        ( /*OUT   */ ERRSIT_status         *status_code )
{

   const ERRSIT_proc_name routine_name = "ERRSIP_WPEL_dump_stack";

   INTx4    i;


   *status_code = ERRSID_normal;

   if ( ERRSPV_proc_err_log_fid != NULL )
   {

/* ==========================================================================
   Print routine stack.
   ========================================================================== */
      for( i=ERRSIV_level-1; i>=0; i-- )
      {
	 fprintf(ERRSPV_proc_err_log_fid,
		     "    %s\n", ERRSIV_routine_stack[ i ] );
      }

      fprintf(ERRSPV_proc_err_log_fid,"\n");
      fflush( ERRSPV_proc_err_log_fid );

   } /* if ERRSPV_proc_err_log_fid != NULL */ 

error_exit:;

} /* ERRSIP_WPEL_dump_stack */ 
