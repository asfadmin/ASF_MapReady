/* ==========================================================================
   $MODULE_HEADER

      $NAME              ICAL_GLUT

      $FUNCTION          Image Calibration LUT Generation routines

      $ROUTINE           ICALPP_GLUT_antenna_pattern
                         ICALPP_GLUT_range_spreading_loss
                         ICALPP_GLUT_calibration_constant
                         ICALPP_GLUT_replica_power
                         ICALPP_GLUT_gamma_image

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       14-MAR-98     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <math.h>

#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include IANN_INTF_H
#include ICAL_INTF_H
#include ICAL_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_GLUT_antenna_pattern

        $TYPE         PROCEDURE

        $INPUT        look_angle  : vector of look angle values
                      look_angle_no
                                  : number of elements of look_angle vector
                      in_boresight_angle
                                  : user supplied boresight angle value
                      use_bore_angle
                                  : TRUE if boresight_angle has to override the
                                    related annotation
                      inp_ima_num : annotation index in IANNIV_ImageAnnot
                      antenna_pattern_file
                                  : file containing the antenna pattern values
                      application_type
                                  : ICALIT_lut_direct enumerated value

        $MODIFIED     NONE

        $OUTPUT       antenna_pattern_lut
                                  : antenna pattern look-up table

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is used to generate the antenna pattern LUT

        $WARNING      NONE

        $PDL          - Load antenna_pattern_file into antenna_pattern vector
                      - Generate direct LUT if application_type is 
                        ICALIE_lut_apply and the AntennaPatternCorrectionFlag 
                        annotation is FALSE or inverse LUT if application_type 
                        is ICALIE_lut_remove and AntennaPatternCorrectionFlag 
                        annotation is TRUE

   $EH
   ========================================================================== */
void ICALPP_GLUT_antenna_pattern
                        (/*IN    */ float               *look_angle,
                         /*IN    */ UINTx4               look_angle_no,
                         /*IN    */ float                in_boresight_angle,
                         /*IN    */ LDEFIT_boolean       use_bore_angle,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ char                *antenna_pattern_file,
                         /*IN    */ ICALIT_lut_direct    application_type,
                         /*   OUT*/ double              *antenna_pattern_lut,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_GLUT_antenna_pattern";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i;
   ICALPT_pattern        *antenna_pattern;
   UINTx4                 antenna_pattern_no;
   float                  ref_boresight_angle;
   IANNIT_AnnotState      state = IANNIE_state_ok;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check inp_ima_num
   ========================================================================== */
   if( inp_ima_num >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_imanum_not_allow, "");
   }

/* ==========================================================================
   Set ref_boresight_angle
   ========================================================================== */
   if( use_bore_angle == TRUE ) {
      ref_boresight_angle = in_boresight_angle;
   }
   else {
/* ==========================================================================
   Look for ANTENNA_BORESIGHT state                       
   ========================================================================== */
      IANNIP_GETP_AnnotState( inp_ima_num,
                              (UINTx4) ANTENNA_BORESIGHT,
                             &state,
                              status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( state == IANNIE_state_ok ) {
         ref_boresight_angle =
            IANNIV_ImageAnnot[ inp_ima_num ].BoresightAngle_deg;
      }
   }

/* ==========================================================================
   Evaluate LUT if the state is OK
   ========================================================================== */
   if( state == IANNIE_state_ok ) {

/* ==========================================================================
   Load antenna_pattern_file into antenna_pattern vector
   ========================================================================== */
      ICALPP_COMP_load_pattern( antenna_pattern_file, 
                               &antenna_pattern,
                               &antenna_pattern_no,
                                status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check the application_type and compute the LUT
   ========================================================================== */
      if( application_type == ICALIE_lut_apply ) {
         if( IANNIV_ImageAnnot[ inp_ima_num ].AntennaPatternCorrectionFlag == TRUE ) {
            ERRSIM_print_warning( "Antenna Pattern Correction already applied" );
         }
         for( i=0; i<look_angle_no; i++ ) {
            antenna_pattern_lut[ i ] = 
               ( 1.0 / ICALLF_COMP_pattern( look_angle[ i ] - ref_boresight_angle,
                          antenna_pattern, antenna_pattern_no, status_code ) );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      else if( application_type == ICALIE_lut_remove ) {
         if( IANNIV_ImageAnnot[ inp_ima_num ].AntennaPatternCorrectionFlag == FALSE ) {
            ERRSIM_print_warning( "Antenna Pattern Correction already removed" );
         }
         for( i=0; i<look_angle_no; i++ ) {
            antenna_pattern_lut[ i ] = 
               ICALLF_COMP_pattern( look_angle[ i ] - ref_boresight_angle,
                   antenna_pattern, antenna_pattern_no, status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
   }
   else {
      ERRSIM_print_warning( "Antenna Pattern Compensation LUT not evaluable" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_GLUT_antenna_pattern */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_GLUT_range_spread_loss

        $TYPE         PROCEDURE

        $INPUT        slant_range : vector of slant range values
                      slant_range_no
                                  : number of elements of slant_range vector
                      in_ref_slant_range      
                                  : user slant range reference values
                      use_ref_sl  : TRUE if slant range reference values has
                                    to be used
                      inp_ima_num : annotation index in IANNIV_ImageAnnot
                      application_type
                                  : ICALIT_lut_direct enumerated value

        $MODIFIED     NONE

        $OUTPUT       range_spread_loss_lut
                                  : range spreading looss look-up table

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is used to generate the range spreading
                      loss LUT

        $WARNING      NONE

        $PDL          - Generate direct LUT if the application_type is 
                        ICALIE_lut_apply and 
                        RangeSpreadingLossCompensationFlag annotation
                        is FALSE or inverse LUT if the application_type is
                        ICALIE_lut_remove and 
                        RangeSpreadingLossCompensationFlag annotation
                        is TRUE

   $EH
   ========================================================================== */
void ICALPP_GLUT_range_spread_loss
                        (/*IN    */ float               *slant_range,
                         /*IN    */ UINTx4               slant_range_no,
                         /*IN    */ float                in_ref_slant_range,
                         /*IN    */ LDEFIT_boolean       use_ref_sl,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ ICALIT_lut_direct    application_type,
                         /*   OUT*/ double              *range_spread_loss_lut,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_GLUT_range_spread_loss";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i;
   float                  reference_slant_range;
   IANNIT_AnnotState      state = IANNIE_state_ok;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check inp_ima_num
   ========================================================================== */
   if( inp_ima_num >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_imanum_not_allow, "");
   }

/* ==========================================================================
   Set reference_slant_range 
   ========================================================================== */
   if( use_ref_sl == TRUE ) {
      reference_slant_range = in_ref_slant_range;
   }
   else {
/* ==========================================================================
   Look for NORMALISATION_REF_RANGE
   ========================================================================== */
      IANNIP_GETP_AnnotState( inp_ima_num,
                              (UINTx4) NORMALISATION_REF_RANGE,
                             &state,
                              status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( state == IANNIE_state_ok ) {
         reference_slant_range =
            IANNIV_ImageAnnot[ inp_ima_num ].ReferenceSlantRange_m;
      }
   }
/* ==========================================================================
   Evaluate LUT if the state is OK
   ========================================================================== */
   if( state == IANNIE_state_ok ) {

/* ==========================================================================
   Check the application_type and compute the LUT
   ========================================================================== */
      if( application_type == ICALIE_lut_apply ) {
         if( IANNIV_ImageAnnot[ inp_ima_num ].RangeSpreadingLossCompensationFlag == TRUE ) {
            ERRSIM_print_warning( "Range Spreading Loss Correction already applied" );
         }
         for( i=0; i<slant_range_no; i++ ) {
            range_spread_loss_lut[ i ] = 
               POW(slant_range[i], 3.0) / POW(reference_slant_range, 3.0);
         }
      }
      else if( application_type == ICALIE_lut_remove ) {
         if( IANNIV_ImageAnnot[ inp_ima_num ].RangeSpreadingLossCompensationFlag == FALSE ) {
            ERRSIM_print_warning( "Range Spreading Loss Correction already removed" );
         }
         for( i=0; i<slant_range_no; i++ ) {
            range_spread_loss_lut[ i ] = 
               POW(reference_slant_range, 3.0) / POW(slant_range[i], 3.0);
         }
      }
   }
   else {
      ERRSIM_print_warning( "Range Spreading Loss Compensation LUT not evaluable" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_GLUT_range_spread_loss */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_GLUT_calib_const

        $TYPE         PROCEDURE

        $INPUT        incid_angle : vector of incidence angle values
                      incid_angle_no
                                  : number of elements of incid_angle vector
                      ref_incid_angle
                                  : reference incidence angle
                      in_calib_const
                                  : user calibration constant value
                      use_calib_const
                                  : TRUE if user calibration constant value has
                                    to be used
                      inp_ima_num : annotation index in IANNIV_ImageAnnot
                      application_type
                                  : ICALIT_lut_direct enumerated value

        $MODIFIED     NONE

        $OUTPUT       calib_const_lut
                                  : calibration constant look-up table

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is used to generate the calibration
                      constant LUT

        $WARNING      NONE

        $PDL          - Generate direct LUT if the application_type is 
                        ICALIE_lut_apply and 
                        CalibrationConstantApplicationFlag annotation
                        is FALSE or inverse LUT if the application_type is
                        ICALIE_lut_remove and 
                        CalibrationConstantApplicationFlag annotation is TRUE

   $EH
   ========================================================================== */
void ICALPP_GLUT_calib_const
                        (/*IN    */ float               *incid_angle,
                         /*IN    */ UINTx4               incid_angle_no,
                         /*IN    */ float                ref_incid_angle,
                         /*IN    */ float                in_calib_const,
                         /*IN    */ LDEFIT_boolean       use_calib_const,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ ICALIT_lut_direct    application_type,
                         /*   OUT*/ double              *calib_const_lut,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_GLUT_calib_const";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i;
   float                  calibration_constant;
   IANNIT_AnnotState      state = IANNIE_state_ok;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check inp_ima_num
   ========================================================================== */
   if( inp_ima_num >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_imanum_not_allow, "");
   }

/* ==========================================================================
   Set calibration_constant value
   ========================================================================== */
   if( use_calib_const == TRUE ) {
      calibration_constant = in_calib_const;
   }
   else {
/* ==========================================================================
   Look for ABSOLUTE_CALIB_K state                       
   ========================================================================== */
      IANNIP_GETP_AnnotState( inp_ima_num,
                              (UINTx4) ABSOLUTE_CALIB_K,
                             &state,
                              status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( state == IANNIE_state_ok ) {
         calibration_constant =
            IANNIV_ImageAnnot[ inp_ima_num ].CalibrationConstant;
      }
   }

/* ==========================================================================
   Evaluate LUT if the state is OK
   ========================================================================== */
   if( state == IANNIE_state_ok ) {

/* ==========================================================================
   Check the application_type and compute the LUT
   ========================================================================== */
      if( application_type == ICALIE_lut_apply ) {
         if( IANNIV_ImageAnnot[ inp_ima_num ].CalibrationConstantApplicationFlag == TRUE ) {
            ERRSIM_print_warning( "Calibration Constant Correction already applied" );
         }
         for( i=0; i<incid_angle_no; i++ ) {
            calib_const_lut[ i ] = 
               ( sin((double) incid_angle[ i ] * DEGTORAD) /
                 ((double) calibration_constant*
                  sin((double) ref_incid_angle * DEGTORAD)) );
         }
      }
      else if( application_type == ICALIE_lut_remove ) {
         if( IANNIV_ImageAnnot[ inp_ima_num ].CalibrationConstantApplicationFlag == FALSE ) {
            ERRSIM_print_warning( "Calibration Constant Correction already removed" );
         }
         for( i=0; i<incid_angle_no; i++ ) {
            calib_const_lut[ i ] = 
               ( ( calibration_constant*
                   sin((double) ref_incid_angle * DEGTORAD)) /
                 sin((double) incid_angle[ i ] * DEGTORAD) );
         }
      }
   }
   else {
      ERRSIM_print_warning( "Calibration Constant LUT not evaluable" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_GLUT_calib_const */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_GLUT_replica_power

        $TYPE         PROCEDURE

        $INPUT        ref_replica_power
                                  : reference replica power value
                      ref_chirp_average
                                  : reference chirp average density value
                      replica_power_lut_no
                                  : size of replica_power_lut vector
                      inp_ima_num : annotation index in IANNIV_ImageAnnot
                      application_type
                                  : ICALIT_lut_direct enumerated value

        $MODIFIED     NONE

        $OUTPUT       replica_power_lut
                                  : replica power look-up table

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is used to generate the replica power LUT

        $WARNING      NONE

        $PDL          - Generate direct LUT if the application_type is 
                        ICALIE_lut_apply and ReplicaPowerCompensationFlag 
                        annotation is FALSE or inverse LUT if the 
                        application_type is ICALIE_lut_remove and 
                        ReplicaPowerCompensationFlagannotation is TRUE

   $EH
   ========================================================================== */
void ICALPP_GLUT_replica_power
                        (/*IN    */ float                ref_replica_power,
                         /*IN    */ float                ref_chirp_average,
                         /*IN    */ UINTx4               replica_power_lut_no,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ ICALIT_lut_direct    application_type,
                         /*   OUT*/ double              *replica_power_lut,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_GLUT_replica_power";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i;
   LDEFIT_boolean         use_product_replica_power = TRUE;
   LDEFIT_boolean         use_chirp_average_density = TRUE;
   IANNIT_AnnotState      state;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check inp_ima_num
   ========================================================================== */
   if( inp_ima_num >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_imanum_not_allow, "");
   }

/* ==========================================================================
   Look for REPLICA_POWER tag
   ========================================================================== */
   IANNIP_GETP_AnnotState( inp_ima_num,
                           (UINTx4) REPLICA_POWER,
                          &state,
                           status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( state != IANNIE_state_ok ) {
      use_product_replica_power = FALSE;
   }

/* ==========================================================================
   Look for CHIRP_AVERAGE_DENSITY state                       
   ========================================================================== */
   IANNIP_GETP_AnnotState( inp_ima_num,
                           (UINTx4) CHIRP_AVERAGE_DENSITY,
                          &state,
                           status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( state != IANNIE_state_ok ) {
      use_chirp_average_density = FALSE;
   }

/* ==========================================================================
   Check the application_type and compute the LUT
   ========================================================================== */
   if( use_product_replica_power ) {
      if( application_type == ICALIE_lut_apply ) {
         if( IANNIV_ImageAnnot[ inp_ima_num ].ReplicaPowerCompensationFlag == TRUE ) {
            ERRSIM_print_warning( "Replica Power Compensation already applied" );
         }
         for( i=0; i<replica_power_lut_no; i++ ) {
            replica_power_lut[ i ] = 
               IANNIV_ImageAnnot[ inp_ima_num ].ProductReplicaPower /
               ref_replica_power;
         }
      }
      else if( application_type == ICALIE_lut_remove ) {
         if( IANNIV_ImageAnnot[ inp_ima_num ].ReplicaPowerCompensationFlag == FALSE ) {
            ERRSIM_print_warning( "Replica Power Compensation already removed" );
         }
         for( i=0; i<replica_power_lut_no; i++ ) {
            replica_power_lut[ i ] = 
               ref_replica_power /
               IANNIV_ImageAnnot[ inp_ima_num ].ProductReplicaPower;
         }
      }
   }
   else {
      if( use_chirp_average_density ) {
         if( application_type == ICALIE_lut_apply ) {
            if( IANNIV_ImageAnnot[ inp_ima_num ].ReplicaPowerCompensationFlag == TRUE ) {
               ERRSIM_print_warning( "Replica Power Compensation already applied" );
            }
            for( i=0; i<replica_power_lut_no; i++ ) {
               replica_power_lut[ i ] = 
                  IANNIV_ImageAnnot[ inp_ima_num ].ChirpAverageDensity /
                  ref_chirp_average;
            }
         }
         else if( application_type == ICALIE_lut_remove ) {
            if( IANNIV_ImageAnnot[ inp_ima_num ].ReplicaPowerCompensationFlag == FALSE ) {
               ERRSIM_print_warning( "Replica Power Compensation already removed" );
            }
            for( i=0; i<replica_power_lut_no; i++ ) {
               replica_power_lut[ i ] = 
                  ref_chirp_average / 
                  IANNIV_ImageAnnot[ inp_ima_num ].ChirpAverageDensity;
            }
         }
      }
      else {
         ERRSIM_print_warning( "Replica Power LUT not evaluable" );
      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_GLUT_replica_power */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_GLUT_gamma_image

        $TYPE         PROCEDURE

        $INPUT        incid_angle : vector of incidence angle values
                      incid_angle_no
                                  : number of elements of incid_angle vector
                      inp_ima_num : annotation index in IANNIV_ImageAnnot

        $MODIFIED     NONE

        $OUTPUT       gamma_image_lut
                                  : gamma image look-up table

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is used to generate the gamma image
                      direct LUT

        $WARNING      NONE

        $PDL          - Generate direct LUT 

   $EH
   ========================================================================== */
void ICALPP_GLUT_gamma_image
                        (/*IN    */ float               *incid_angle,
                         /*IN    */ UINTx4               incid_angle_no,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ double              *gamma_image_lut,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_GLUT_gamma_image";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check inp_ima_num
   ========================================================================== */
   if( inp_ima_num >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_imanum_not_allow, "");
   }

   for( i=0; i<incid_angle_no; i++ ) {
      gamma_image_lut[ i ] = 
               1.0 / cos((double) incid_angle[ i ] * DEGTORAD);
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_GLUT_gamma_image */

#ifdef __PLAPLA__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_GLUT_

        $TYPE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void ICALPP_GLUT_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALPP_GLUT_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALPP_GLUT_ */
#endif
