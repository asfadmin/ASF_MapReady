/* This is needed to terminate the list of inport stuff */
    asm(".section .idata$3\n" ".long 0,0,0,0, 0,0,0,0");
