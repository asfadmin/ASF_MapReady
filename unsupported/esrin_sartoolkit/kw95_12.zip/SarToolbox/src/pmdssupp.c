/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_SUPP

      $FUNCTION          

      $ROUTINE           PMDSIP_SUPP_SetSupportData

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       08-OCT-97     DDN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <stdlib.h>

#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include IANN_TAGS_H
#include TIFS_INTF_H
#include PMDS_INTF_H
#include PMDS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_SUPP_SetSupportData

        $TYPE

        $INPUT        support_file     : support ingestion data file
                      tif_output_file  : output file name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_SUPP_SetSupportData
                        (/*IN    */ char                *support_file,
                         /*   OUT*/ char                *tif_output_file,
                         /*   OUT*/ ERRSIT_status       *status_code)
{
   const ERRSIT_proc_name routine_name = "PMDSIP_SUPP_SetSupportData";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   TIFSIT_basicpar  out_bpar;           /* output file basic parameters       */
   TIFSIT_par       param;              /* parameter structure                */
   INTx4            out_channel;        /* output file channel                */
   INTx4            itag;               /* convenient loop variable           */
   INTx4            nimage = 1;         /* image number                       */
   INTx4            iimage = 0;         /* current image index                */
   UINTx2           npar;               /* num of parameters to be put        */
   UINTx2           npar_user;          /* number of user parameters          */
   PMDSPT_TiffList  tiff_data;          /* tiff data list                     */
   int              ichar;              /* convenient loop variable           */
   int              iline;              /* convenient loop variable           */
   FILE             *fp = NULL;         /* product file pointer               */
   char             line[256];          /* buffer containing file line        */
   char             tag_name[256];      /* tag name into the support file     */
   char             tag_delimiter[256]; /* delimiter of fields into support f.*/
   char             tag_value[256];     /* tag value into the support file    */
   char             *value_p;           /* temporary pointer                  */
   float            value_1;            /* current first image sample         */
   float            value_2;            /* current second image sample        */
   float            *img_data_p =  (float *) NULL;
                                        /* virtual image pointer              */
   INTx4            img_data_num = 0;   /* virtual image length               */
   char             proc_history_txt[512];
   char             time_stamp[ 40 ];
   char             msg[ 256 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Initialize tiff field data list
   ========================================================================== */
   tiff_data.list = NULL;
   tiff_data.num  = 0;

/* ==========================================================================
   Open support data file in input
   ========================================================================== */
   FILSIP_open( support_file, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Loop on input file lines   
   ========================================================================== */
   while((fgets(line, sizeof(line), fp)) != NULL)
   {
      if( line[0] != '!') /* check comments */
      {
         for(ichar = strlen(line); ichar >= 0; ichar--)
         {
            if(line[ichar] == '\n')
               line[ichar] = '\0';
         }
         if(((sscanf(line, "%s %s", tag_name, tag_delimiter)) == 2) &&
            ((strstr(line, ":")) != NULL))
         {
            if((value_p = strstr(line, ":")) != NULL)
            {
               if(value_p + 1 != '\0')
               {
                  strcpy(tag_value, (value_p + 1));
               }
               PMDSPP_TFDM_AddTiffField(tag_name, tag_value, &tiff_data,
                  status_code);
               ERRSIM_on_err_goto_exit(*status_code);
            }
         }
         else if((sscanf(line, "%f %f", &value_1, &value_2)) == 2)
         {
            img_data_num += 2;
            if((img_data_p = (float *)MEMSIP_realloc((float *)img_data_p,
               (size_t)(img_data_num * sizeof(float)))) == NULL)
            {
               ERRSIM_set_error(status_code, ERRSID_PMDS_alloc_memory, "");
            }

            img_data_p[img_data_num - 2] = value_1;
            img_data_p[img_data_num - 1] = value_2;
         }
         else {
            sprintf( msg, "Line <%s> ignored", line );
            ERRSIM_print_warning( msg );
         }
      }
   }
/* ==========================================================================
   Close input file
   ========================================================================== */
   FILSIP_close( &fp, &log_status_code );

/* ==========================================================================
   Add PROC_HISTORY
   ========================================================================== */
   sprintf( proc_history_txt, "\nSUPPORT DATA  %s",
      ERRSIF_LODT_out_date( time_stamp ) );
   PMDSPP_TFDM_AddTiffField(  "proc_history",
                              proc_history_txt,
                             &tiff_data,
                              status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Init basic parameter
   ========================================================================== */
   TIFSIM_bpar_init(out_bpar);

/* ==========================================================================
   Reset image size
   ========================================================================== */
   out_bpar.imagewidth       = 2;
   out_bpar.imagelength      = img_data_num / 2;
   out_bpar.sampleperpixel   = 1;
   out_bpar.sampleformat[0]  = TIFSID_float;
   out_bpar.bitspersample[0] = 32;

/* ==========================================================================
   Set total parameters number
   ========================================================================== */
   npar_user   = tiff_data.num;         /* user parameters                    */
   npar = TIFSID_nbpar + npar_user;


#ifdef __TRACE__

fprintf(stderr,"Debug:  support data file = <%s>\n", support_file);
fprintf(stderr,"Debug:    user parameters = <%d>\n", npar_user);
fprintf(stderr,"Debug:   total parameters = <%d>\n", npar);
fprintf(stderr,"Debug:   output tiff file = <%s>\n", tif_output_file);

#endif

/* ==========================================================================
   Set the number of images found in the file
   ========================================================================== */
   TIFSIP_set_imgnum(tif_output_file, nimage, status_code);
   ERRSIM_on_err_goto_exit(*status_code);

/* ==========================================================================
   Set the number of total parameters for each image
   ========================================================================== */
   TIFSIP_set_parnum(tif_output_file, iimage, npar, status_code);
   ERRSIM_on_err_goto_exit(*status_code);

/* ==========================================================================
   Compute internal parameters
   ========================================================================== */
   TIFSIP_set_blockinfo(tif_output_file, iimage, &out_bpar, status_code);
   ERRSIM_on_err_goto_exit(*status_code);

/* ==========================================================================
   Open output tiff file - returns file handle (channel)
   ========================================================================== */
   TIFSIP_open_tiff(tif_output_file, 'w', &out_channel, status_code);
   ERRSIM_on_err_goto_exit(*status_code);

/* ==========================================================================
   Writing of basic parameters and internal data
   ========================================================================== */
   TIFSIP_store_blockinfo(out_channel, iimage, status_code);
   ERRSIM_on_err_goto_exit(*status_code);

/* ==========================================================================
   Writing parameters
   ========================================================================== */
   for(itag = 0; itag < npar_user; itag++)
   {
      param.tag    = tiff_data.list[itag].tag;
      param.type   = tiff_data.list[itag].type;
      param.val    = (void *)(tiff_data.list[itag].value);
      param.length = strlen(tiff_data.list[itag].value) + 1;

      TIFSIP_store_par(out_channel, iimage, &param, status_code);
      ERRSIM_on_err_goto_exit(*status_code);
   }

/* ==========================================================================
   Opening of image write mode
   ========================================================================== */
   TIFSIP_open_line(out_channel, iimage, 'x', 0, (out_bpar.imagewidth - 1),
      status_code);
   ERRSIM_on_err_goto_exit(*status_code);

/* ==========================================================================
   Loop onto the file line(s)
   ========================================================================== */
   for(iline = 0; iline < out_bpar.imagelength; iline++)
   {
/* ==========================================================================
      Write line into input file
   ========================================================================== */
      TIFSIP_write_line(out_channel, iimage, iline,
         (void *)(img_data_p + (iline * out_bpar.imagewidth)), status_code);
      ERRSIM_on_err_goto_exit(*status_code);
 
   }

/* ==========================================================================
   Close write mode for input and output files
   ========================================================================== */
   TIFSIP_close_line(out_channel, iimage, status_code);
   ERRSIM_on_err_goto_exit(*status_code);
 
/* ==========================================================================
   Close output tiff file
   ========================================================================== */
   TIFSIP_close_tiff(out_channel, status_code);
   ERRSIM_on_err_goto_exit(*status_code);

error_exit:;

/* ==========================================================================
   Check open file in case of error
   ========================================================================== */
   if(fp != (FILE *) NULL) {
      FILSIP_close( &fp, &log_status_code );
   }
/* ==========================================================================
   Free tiff data list in memory
   ========================================================================== */
   PMDSPP_TFDM_FreeTiffField (&tiff_data, status_code);

/* ==========================================================================
   Free virtual image pointer
   ========================================================================== */
   MEMSIP_free((void **) &img_data_p);

   ERRSIM_close_routine(  routine_name,
                         &process_flag,
                         *status_code, 
                         &log_status_code);


}/* PMDSIP_SUPP_SetSupportData */
