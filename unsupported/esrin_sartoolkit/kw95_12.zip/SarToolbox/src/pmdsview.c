/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_VIEW

      $FUNCTION          

      $ROUTINE           PMDS_VIEW_CreatePreviewFile

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       08-OCT-97     DDN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <stdlib.h>

#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include TIFS_INTF_H
#include IANN_TAGS_H
#include IANN_INTF_H
#include PMDS_INTF_H
#include PMDS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_VIEW_CreatePreviewFile

        $TYPE

        $INPUT        tif_input_file   : input file name
                      start_col        : starting column
                      start_row        : starting row
                      end_col          : end column
                      end_row          : end row
                      tif_output_file  : output file name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_VIEW_CreatePreviewFile
                        (/*IN    */ char                *tif_input_file,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ INTx4                start_col,
                         /*IN    */ INTx4                start_row,
                         /*IN    */ INTx4                end_col,
                         /*IN    */ INTx4                end_row,
                         /*IN OUT*/ char                *tif_output_file,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_VIEW_CreatePreviewFile";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   TIFSIT_basicpar  in_bpar;     /* input file basic parameters */
   TIFSIT_par       param;       /* parameter structure */
   INTx4            in_channel;  /* input file channel */
   void            *imgline;     /* image line buffer */
   INTx4            iline;       /* convenient loop variable */
   INTx4            nimage;      /* image number */
   INTx4            iimage = 0;  /* current image index */
   UINTx2           npar;        /* number of parameters to be pu in the file */
   UINTx2           out_npar;    /* number of parameters to be pu in the file */
   char             param_buf[500]; /* temporary value buffer */
   GIOSIT_io        out_io; /* handle for output image */
   INTx4            SubImageTopLeftRow, SubImageTopLeftCol;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Open read file
   ========================================================================== */
   TIFSIP_open_tiff( tif_input_file, 'r', &in_channel, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_imgnum( in_channel, &nimage, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_blockinfo( in_channel, iimage, &in_bpar, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_parnum( in_channel, iimage, &npar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check that it is a byte image
   ========================================================================== */
   if( (in_bpar.sampleperpixel !=1) ||
       (in_bpar.bitspersample[0] !=8) ||
       (in_bpar.sampleformat[0] != TIFSID_uintdata) ) {
      ERRSIM_set_error( status_code, ERRSID_PMDS_error_not_allowed,
         "input image should be a byte image" );
   }
  
/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = end_row - start_row + 1;
   out_io.val.tif.bpar.imagewidth = end_col - start_col + 1;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.photometricinterpretation = (UINTx2) 1;
   out_io.val.tif.bpar.bitspersample[ 0 ] =
             (UINTx2)(sizeof(UINTx1)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[ 0 ] = TIFSID_uintdata;
   out_npar = TIFSID_nbpar + 2;

/* ==========================================================================
   Open output STANDARD TIFF file
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, tif_output_file );
   out_io.val.tif.standard = TRUE;
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = out_npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Subimage coordinates tag (for DEBUG purpose)
   ========================================================================== */
   SubImageTopLeftRow =
      (INTx4) (start_row / IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor) +
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow;

   SubImageTopLeftCol =
      (INTx4) (start_col / IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor) +
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol;

   memset( (void *) &param, 0, sizeof( TIFSIT_par ) );   
   param.tag = SUBIMG_TOP_LEFT_ROW;
   sprintf(param_buf, "%d", SubImageTopLeftRow);
   param.val  = (void *)param_buf;
   param.length = strlen(param_buf) + 1;
   TIFSIP_store_par(out_io.chan, out_io.img, &param, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   memset( (void *) &param, 0, sizeof( TIFSIT_par ) );   
   param.tag = SUBIMG_TOP_LEFT_COL;
   sprintf(param_buf, "%d", SubImageTopLeftCol);
   param.val  = (void *)param_buf;
   param.length = strlen(param_buf) + 1;
   TIFSIP_store_par(out_io.chan, out_io.img, &param, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open the read mode of the input file
   ========================================================================== */
   TIFSIP_open_line( in_channel, iimage, 'x', start_col, end_col,
      status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Opening of image write mode
   ========================================================================== */
   GIOSIP_open_line( &out_io, 'x', 0, (out_io.val.tif.bpar.imagewidth - 1),
      status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Loop onto the file line(s)
   ========================================================================== */
   for(iline = 0; iline < out_io.val.tif.bpar.imagelength; iline++)
   {
/* ==========================================================================
      Read line from input file
   ========================================================================== */
      TIFSIP_read_line(in_channel, iimage, iline + start_row, &imgline,
         status_code);
      ERRSIM_on_err_goto_exit( *status_code );
/* ==========================================================================
      Write line into input file
   ========================================================================== */
      GIOSIP_write_line( &out_io, iline, imgline, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
      fprintf(stderr, "Lines written = %d/%d\r",
         iline, out_io.val.tif.bpar.imagelength);
#endif

   }

#ifdef __TRACE__
   fprintf(stderr, "Lines written = %d/%d\n", 
      iline, out_io.val.tif.bpar.imagelength);
   fprintf(stderr, 
      "----------------------------------------------------------\n");
#endif

/* ==========================================================================
   Update the new parameters in the output file
   ========================================================================== */


/* ==========================================================================
   Close write mode for input and output files
   ========================================================================== */
   TIFSIP_close_line( in_channel, iimage, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   GIOSIP_close_line( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close input tiff file
   ========================================================================== */
   TIFSIP_close_tiff( in_channel, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close output tiff file
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSIP_VIEW_CreatePreviewFile */

