/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_SPKF

      $FUNCTION          This module contains the task procedure for
			 the Sar Toolbox SPECKLE FILTERING

      $ROUTINE           STBXPP_SPKF_filter

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       22-AUG-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */


#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include IANN_INTF_H
#include COOR_INTF_H
#include SPKF_INTF_H
#include STBX_INTF_H
#include STBX_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_SPKF_filter

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the SPECKLE FILTERING task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call SPKFIP_filter routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_SPKF_filter
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_SPKF_filter";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j, ipar;
   INTx4                   edge_th_parnum, line_th_parnum, 
                           look_no_parnum, mask_file_parnum;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        maskFile;
   float                   pfa, look_no;
   FILSIT_file_name        inImage, outImage;
   FILSIT_file_name        inImageName, outImageName;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   char                    err_msg[ 256 ];

/* ==========================================================================
   IO Variables
   ========================================================================== */
   GIOSIT_io               inp_io, out_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   INTx4                   win_sizes[ 2 ];
   LDEFIT_boolean          out_open = FALSE;
   LDEFIT_boolean          real_aoi;
   float                   line_th, edge_th, scatter_th;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            out_ima_num = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Init input parameters and global vars corresponding to, if any 
   ========================================================================== */
   look_no = 0.0;
   edge_th = 0.0;
   line_th = 0.0;
   sprintf( maskFile, "" );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 9 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) outImageName;
   
   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_mask_file_name );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( maskFile );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) maskFile;
   mask_file_parnum = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_window_sizes);
   task.parm[ ipar ].type = FIISIE_tt_int;
   task.parm[ ipar ].size = sizeof( INTx4 );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value = (void *) win_sizes;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_pfa );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &pfa;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_look_no );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &look_no;
   look_no_parnum = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_edge_threshold );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &edge_th;
   edge_th_parnum = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_line_threshold );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &line_th;
   line_th_parnum = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_scatter_threshold );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &scatter_th;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   printf( "%s : %s\n", STBXPD_input_image, inImageName);
   printf( "%s : %s\n", STBXPD_output_image, outImageName);
   printf( "%s : %s\n", STBXPD_mask_file_name, maskFile);
   printf( "%s : ", STBXPD_window_sizes);
   for( i=0; i<task.parm[ 3 ].number; i++) printf("%d ", win_sizes[ i ]);
   printf("\n");
   printf( "%s : %f\n", STBXPD_pfa, pfa);
   printf( "%s : %f\n", STBXPD_look_no, look_no);
   printf( "%s : %f\n", STBXPD_edge_threshold, edge_th);
   printf( "%s : %f\n", STBXPD_line_threshold, line_th);
   printf( "%s : %f\n", STBXPD_scatter_threshold, scatter_th);

   printf( "m=%d e=%d l=%d\n", task.parm[ mask_file_parnum ].founded,
                         task.parm[ edge_th_parnum ].founded,
                         task.parm[ line_th_parnum ].founded );
#endif

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check input thresholds
   ========================================================================== */
   if( (task.parm[ mask_file_parnum ].founded == TRUE) &&
       ( (task.parm[ edge_th_parnum ].founded == FALSE) ||
         (task.parm[ line_th_parnum ].founded == FALSE) ) ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
         "Edge and line threshold mandatory for a user mask file");
   }

   if( pfa <= 0 ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
         STBXPD_pfa );
   }

   if( (task.parm[ edge_th_parnum ].founded == TRUE) &&
       ( ( edge_th <= 0.0 ) ||
         ( edge_th >  1.0 ) ) ) {
      ERRSIM_set_error( status_code, 
                        ERRSID_STBX_parm_invalid,
                        STBXPD_edge_threshold );
   }
   if( (task.parm[ line_th_parnum ].founded == TRUE) &&
       ( ( line_th <= 0.0 ) ||
         ( line_th >  1.0 ) ) ) {
      ERRSIM_set_error( status_code, 
                        ERRSID_STBX_parm_invalid,
                        STBXPD_line_threshold );
   }
   if( ( scatter_th <= 0.0 ) ||
       ( scatter_th >  1.0 ) ) {
      ERRSIM_set_error( status_code, 
                        ERRSID_STBX_parm_invalid,
                        STBXPD_scatter_threshold );
   }

/* ==========================================================================
   Build full name of input and output image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_float,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImageName and outFileName
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);

/* ==========================================================================
   Check input type
   ========================================================================== */
   if( inp_io.dt != LDEFIE_dt_float ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_prod_type, inImage );
   }

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_SPKF_SPKF, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check that input image is a power type
   ========================================================================== */
   if( IANNIV_ImageAnnot[ inp_ima_num ].PixelType != IANNIE_pixt_power ) {
      sprintf( err_msg, " %s is not a power image", inImage );
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_prod_type, err_msg );
   }

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Polygonal AOI are not accepted
   ========================================================================== */
   if( real_aoi == TRUE ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_not_poly_aoi,
                        task.name );
   }

/* ==========================================================================
   Compute nrow_inp/ncol_inp of source image
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

/* ==========================================================================
   Compute nrow_out/ncol_out of out image
   ========================================================================== */
   if( win_sizes[ 0 ] <= 0 ) {
      ERRSIM_set_error( status_code,
			ERRSID_STBX_parm_not_negative,
			task.parm[ 3 ].name );
   }
   if( (win_sizes[ 0 ]/2) == 0 ) {
       ERRSIM_set_error( status_code, 
                         ERRSID_STBX_parm_is_even,
                         task.parm[ 3 ].name );
   }
   if( nrow_inp < win_sizes[ 0 ] ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
         "Row window size greater or equal that number of input rows" );
   }
   nrow_out = nrow_inp -  win_sizes[ 0 ] + 1;

   if( task.parm[ 3 ].number > 1 ) {
      if( win_sizes[ 1 ] <= 0 ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_STBX_parm_not_negative,
			   task.parm[ 3 ].name );
      }
      if( (win_sizes[ 1 ]/2) == 0 ) {
	  ERRSIM_set_error( status_code, 
			    ERRSID_STBX_parm_is_even,
			    task.parm[ 3 ].name );
      }
      if( ncol_inp < win_sizes[ 1 ] ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            "Column window size greater or equal that number of input columns");
      }
      ncol_out = ncol_inp -  win_sizes[ 1 ] + 1;
   }
   else {
      ERRSIM_set_error( status_code,
			ERRSID_STBX_parm_not_defined,
			task.parm[ 3 ].name );
   }

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[0] = 
             (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Change the annotation look number if one is supplied from the user
   ========================================================================== */
   if( task.parm[ look_no_parnum ].founded == TRUE ) {
      IANNIV_ImageAnnot[ inp_ima_num ].LooksNumber = look_no;
   }

   if( IANNIV_ImageAnnot[ inp_ima_num ].LooksNumber == 0.0 ) {
      ERRSIM_set_error( status_code,
                        ((task.parm[ look_no_parnum ].founded == TRUE) ? 
                         ERRSID_STBX_inv_inp_param : 
                         ERRSID_STBX_parm_invalid ),
                        ((task.parm[ look_no_parnum ].founded == TRUE) ? 
                         "Input Number of Look equal to 0": 
                         "Annotation Number of Look equal to 0") );
   }

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   SPKFIP_filter( &inp_io,
                   inp_ima_num,
		   TLRow,
		   TLCol,
		   nrow_inp,
		   ncol_inp,
		   win_sizes,
		   maskFile,
                   pfa,
                   edge_th,
                   line_th,
                   scatter_th,
		  &out_io,
                   nrow_out,
                   ncol_out,
	 	   status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Nullify the output look number
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].LooksNumber = 0.0;

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND((TLRow + (float)(win_sizes[ 0 ] - 1)/2.0) / 
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND((TLCol + (float)(win_sizes[ 1 ] - 1)/2.0) / 
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
				  task.name,
				  "",
				  status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_SPKF_filter */
