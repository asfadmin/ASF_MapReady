/* ==========================================================================
   $MODULE_HEADER

      $NAME              STAT_GLOB

      $FUNCTION          This module contains the procedure to execute
			 the GLOBAL STATISTIC analysis of an image

      $ROUTINE           STATIP_GLOB_stat

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       29-JUL-97     AG       Initial Release
          SCR #4      26-NOV-97     AG       Check args of sqrt and cfvr 
                                             computation

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <math.h>

#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include FILS_INTF_H
#include GIOS_INTF_H
#include SRVS_INTF_H
#include COOR_INTF_H
#include IANN_INTF_H
#include STAT_INTF_H
#include STAT_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STATIP_GLOB_stat

      $TYPE	    PROCEDURE

      $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                    imanum    : number identifing the image inside the tool
                    TLRow     : the row image coordinate in the full
                                reference frame of the image
                    TLCol     : the column image coordinate in the full
                                reference frame of the image
                    nrow_inp  : number of rows of the image
                    ncol_inp  : number of columns of the images
		    vertex_no : number of the vertex of an AOI, if any 
                                (0, otherwise)
                    vertex    : array of vertex coordinates
		    class_min : minimun class value for the histogram
		    class_max : maximum class value for the histogram
		    class_no  : number of class between class_min - class_max
                    min       : min value
                    max       : max value
                    mean      : mean value
                    sddv      : standard deviation value
                    cfvr      : coeffiecient of variation
                    out_class : histogram of (class_no + 2) values
                    out_class_norm
                              : normalized histogram of (class_no + 2) values
                    out_class_limit
                              : histogram limits of (class_no + 2) values

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       IANNIV_ImageAnnot
                              : the structure with the image annotations

      $RET_STATUS   ERRSID_STAT_start_stop_coord_err
                    ERRSID_STAT_range_error
		    ERRSID_STAT_data_type_not_allow
		    ERRSID_STAT_err_mem_alloc

      $DESCRIPTION  This procedure executes the GLOBAL STATISTICS of an image
                    creating a report containg Mean, Standard Deviation,
                    Coefficient of Variation and Histogram values

      $WARNING      The input file shall be already opened.

      $PDL	    - Compute E[X], E[X^2], E[X^4] and C class vector
                      keeping in account the AOI (when defined) 
                    - Output Mean, Standard Deviation, Coefficient of Variation 
                      and Histogram values

   $EH
   ========================================================================== */
void STATIP_GLOB_stat
                       ( /*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4               vertex_no,
			 /*IN    */ MATHIT_RC           *vertex,
			 /*IN    */ float                class_min,
			 /*IN    */ float                class_max,
                         /*IN    */ UINTx4               class_no,
                         /*   OUT*/ float               *min,
                         /*   OUT*/ float               *max,
			 /*   OUT*/ float               *mean, 
                         /*   OUT*/ float               *sddv, 
                         /*   OUT*/ float               *cfvr,
                         /*   OUT*/ UINTx4              *out_class,
                         /*   OUT*/ float               *out_class_norm,
                         /*   OUT*/ float               *out_class_limit,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STATIP_GLOB_stat";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 row;              /* rows counter */
   UINTx4                 col;              /* cols counter */
   UINTx4                 below_min, above_max;
   MATHIT_array           imgline, templine, outline, outline2, outline4, mask;
   double                 doubleTmp, sum, sum2, sum4, no_sample, dblMean;
   UINTx4                *classes, tot_samples;
   UINTx1                 filler = (UINTx1) 1;
   double                 inv_class_range, minus_class_min;
   double                 sqrtarg;
#ifdef __TRACE__
   UINTx4                 check_sum;
#endif
   FILE                  *fp = (FILE *) NULL;
   char                   errmsg[ 132 ];
   float                  curr_min, curr_max;

/* ==========================================================================
   AOI variables
   ========================================================================== */
   MATHIT_RC              point;
   INTx4                  in_out;
   UINTx4                 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_STAT_imanum_not_allow, "");
   }

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow_inp > IANNIV_ImageAnnot[ imanum ].ImageLength ) ||
        ( TLCol + ncol_inp > IANNIV_ImageAnnot[ imanum ].ImageWidth ) ) {
      ERRSIM_set_error( status_code, ERRSID_STAT_start_stop_coord_err, "" );
   }

#ifdef __TRACE__
   printf("TL: %0d %0d BR: %0d %0d\n", TLRow, TLCol, TLRow + nrow_inp - 1, 
                               TLCol + ncol_inp - 1);
#endif
/* ==========================================================================
   Check the histogram parameters
   ========================================================================== */
   if( class_no <= 0 ) {
      ERRSIM_set_error( status_code, ERRSID_STAT_range_error, "class_no");
   }

   if( class_max <= class_min ) {
      ERRSIM_set_error(
           status_code, 
           ERRSID_STAT_range_error, 
           "Class Max parameter value should be greater than Class Min" );
   }

/* ==========================================================================
   Array initialization
   ========================================================================== */
   MATHIM_init_array( imgline );
   MATHIM_init_array( templine );
   MATHIM_init_array( outline );
   MATHIM_init_array( outline2 );
   MATHIM_init_array( outline4 );
   MATHIM_init_array( mask );

/* ==========================================================================
   Open the read mode for the input file
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol_inp - 1,
                     status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set array imgline nelem
   ========================================================================== */
   imgline.nelem = ncol_inp;

/* ==========================================================================
   Make mask and outline arrays and set array imgline type
   ========================================================================== */
   switch ( inp_io->spp ) {
      case 1:
/* ==========================================================================
   Real data
   ========================================================================== */
	 switch( inp_io->bps ) {
	    case 8:
               imgline.atype = MATHIE_uchar;
	       break;
	    case 16:
               imgline.atype = MATHIE_uintx2;
	       break;
	    case 32: 
               imgline.atype = MATHIE_float;
	       break;
	    default:
	       ERRSIM_set_error( status_code, ERRSID_STAT_data_type_not_allow,
		  "");
	 }
	 break;
      default:
	 ERRSIM_set_error( status_code, ERRSID_STAT_data_type_not_allow,
	    "");
   }

/* ==========================================================================
   Make the other arrays
   ========================================================================== */
   MATHIP_VECT_Make( ncol_inp, MATHIE_float, 
		    &outline, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   MATHIP_VECT_Make( ncol_inp, MATHIE_float, 
		    &outline2, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   MATHIP_VECT_Make( ncol_inp, MATHIE_float,
		    &outline4, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   MATHIP_VECT_Make( ncol_inp, MATHIE_uchar, 
		    &mask, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Initialize classes vector
   ========================================================================== */
   classes = (UINTx4 *) MEMSIP_alloc( (class_no+2) * sizeof(UINTx4) );
   if( classes == (UINTx4 *) NULL ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STAT_err_mem_alloc,
                        "classes" );
   }

/* ==========================================================================
   Zeroes stores
   ========================================================================== */
   sum = 0.0;
   sum2 = 0.0;
   sum4 = 0.0;
   no_sample = 0.0;
   below_min = 0;
   above_max = 0;
   for( i=0; i<class_no; i++ ) {
      classes[ i ] = 0;
   }

/* ==========================================================================
   Evaluate inv_class_range (1/binsize)
   ========================================================================== */
   inv_class_range = 1.0/((class_max - class_min)/(float)class_no);
   minus_class_min = 0.0 - class_min;

/* ==========================================================================
   Set an initial value for min and max
   ========================================================================== */
   *min = (float)  1.e+38;
   *max = (float) -1.e+38;

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow_inp, &log_status_code );

/* ==========================================================================
   Read the image by rows
   ========================================================================== */
   for( row=TLRow; row<TLRow+nrow_inp; row++ ) {

      SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Create a templine vector of the same type of the input line
   ========================================================================== */
      MATHIP_VECT_Make( ncol_inp, imgline.atype,
		       &templine, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the mask and the outlines to zero
   ========================================================================== */
      MATHIP_VECT_SetZero( &mask, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      MATHIP_VECT_SetZero( &outline, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      MATHIP_VECT_SetZero( &outline2, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      MATHIP_VECT_SetZero( &outline4, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute the mask for this row
   ========================================================================== */
      if( vertex_no == 0  ) {
/* ==========================================================================
   Get all the whole line
   ========================================================================== */
         MATHIP_VECT_FillConst( (void *) &filler, &mask, status_code );
         ERRSIM_on_err_goto_exit( *status_code );

      }
      else {
/* ==========================================================================
   Check each point on the line against the AOI
   ========================================================================== */
         point.row = (double) row;
         for( col=TLCol; col<TLCol+ncol_inp; col++ ) {
	    point.col = (double) col;
	    COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point, &in_out,
					 status_code );
	    if( in_out >= 0 ) {
		(*((UINTx1 *) mask.ap + (col-TLCol))) = (UINTx1) 1;
            }
         }
      }

/* ==========================================================================
   Count the sample of this line
   ========================================================================== */
      if( vertex_no == 0  ) {
	 no_sample += (double) ncol_inp;
      }
      else {
	 MATHIP_VECT_Total( mask, &doubleTmp, status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
	 no_sample += doubleTmp;
      }

/* ==========================================================================
   Read the row
   ========================================================================== */
      GIOSIP_read_line( inp_io, row, 0, &(imgline.ap), status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Copy the imgline
   ========================================================================== */
      MATHIP_VECT_Copy(  imgline,
                        &templine,
			 status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Convert the line to float
   ========================================================================== */
      MATHIP_VECT_ToFloat( &templine,
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE1__
      printf("\n");
      for (i=0;i<templine.nelem;i++) printf("%f ",*( (float *)templine.ap+i));
      printf("\n");
#endif

/* ==========================================================================
   Compute (pixel-class_min)/((class_max-class_min+1)/class_no)
   ========================================================================== */
      MATHIP_VECT_ConstAdd(  minus_class_min,
			     templine,
			    &templine,
                             status_code );
      ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE1__
      printf("After MATHIP_VECT_ConstAdd\n");
      for (i=0;i<templine.nelem;i++) printf("%f ",*( (float *)templine.ap+i));
      printf("\n");
#endif

      MATHIP_VECT_ConstMult(  inv_class_range,
 	                      templine,
                             &templine,
                              status_code );
      ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE1__
      printf("After MATHIP_VECT_ConstMult\n");
      for (i=0;i<templine.nelem;i++) printf("%f ",*( (float *)templine.ap+i));
      printf("\n");
#endif

/* ==========================================================================
   Convert to INTx4
   ========================================================================== */
      MATHIP_VECT_ToIntFloor( &templine,
                               status_code );
      ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE1__
      printf("After MATHIP_VECT_ToIntFloor\n");
      for (i=0;i<templine.nelem;i++) printf("%d ",*( (INTx4 *)templine.ap+i));
      printf("\n");
#endif

/* ==========================================================================
   Count classes as
      below_min++,                  if templine[ i ] < 0
      above_max++,                  if templine[ i ] > class_no
      classes[ templine[i] ]++,	    elsewhere
   ========================================================================== */
#ifdef __TRACE1__
      printf("Mask: ");
#endif
      for( col=0; col<ncol_inp; col++ ) {
#ifdef __TRACE1__
         printf("%0d ", *((UINTx1 *) mask.ap + col) );
#endif
         if( (*((UINTx1 *) mask.ap + col)) == (UINTx1) 1) {
            if( (*( (INTx4 *)templine.ap+col)) < 0 ) {
	       below_min++;
            }
	    else if( (*( (INTx4 *)templine.ap+col)) >= class_no ) {
	       above_max++;
            }
	    else {
	       classes[ *( (INTx4 *)templine.ap+col) ]++;
            }
         }
      }
#ifdef __TRACE1__
      printf("\n");
#endif

/* ==========================================================================
   Compute statistical values
   ========================================================================== */
      MATHIP_VECT_Pow( imgline, (double) 2.0, &outline2, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      MATHIP_VECT_Pow( imgline, (double) 4.0, &outline4, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      MATHIP_VECT_HeterProd( imgline, mask, &outline, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Find the min/max of this line
   ========================================================================== */
      MATHIP_VECT_MinMax( outline, mask, &curr_min, &curr_max, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      if( curr_min < *min ) {
         *min = curr_min;
      }
      if( curr_max > *max ) {
         *max = curr_max;
      }

      MATHIP_VECT_Total( outline, &doubleTmp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      sum += doubleTmp;
#ifdef __TRACE1__
      printf("sum = %0f\n", sum);
#endif

      MATHIP_VECT_HeterProd( outline2, mask, &outline2, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      MATHIP_VECT_Total( outline2, &doubleTmp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      sum2 += doubleTmp;
#ifdef __TRACE1__
      printf("sum2 = %0f\n", sum2);
#endif

      MATHIP_VECT_HeterProd( outline4, mask, &outline4, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      MATHIP_VECT_Total( outline4, &doubleTmp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      sum4 += doubleTmp;
#ifdef __TRACE1__
      printf("sum4 = %0f\n", sum4);
#endif

      MATHIP_VECT_Free( &templine, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );   

#ifdef __TRACE__
   printf("\n%f\t%f\t%f\t%f\n", sum, sum2, sum4, no_sample);
#endif

   dblMean = sum/no_sample;
   *mean = (float) dblMean;

   if( (sum2/no_sample) == ((double) 0.0) ) {
      *sddv = 0.0;
   }
   else {
      sqrtarg = ( (sum2/no_sample) - POW( dblMean, (double)2.0) );
      if( (sqrtarg/(sum2/no_sample)) < (- STATPD_sqrt_epsilon) ) {
         sprintf( errmsg, "sddv sqrtarg = %20.18f", sqrtarg/(sum2/no_sample) );
         ERRSIM_set_error( status_code, ERRSID_STAT_math_exception, errmsg );
      }

      *sddv = (((sqrtarg/(sum2/no_sample)) < ((double) 0.0)) ? 0.0 : ((float) (sqrt( sqrtarg ))));
   }

   if( (sum4/no_sample) == ((double) 0.0) ) {
      ERRSIM_print_warning( "Coefficient of variation not computed" );
      *cfvr = 0.0;
   }
   else {
      sqrtarg = ((sum4/no_sample) - POW( (sum2/no_sample), (double)2.0) );
      if( (sqrtarg/(sum4/no_sample)) < (- STATPD_sqrt_epsilon) ) {
         sprintf( errmsg, "cfvr sqrtarg = %20.18f", sqrtarg/(sum4/no_sample) );
         ERRSIM_set_error( status_code, ERRSID_STAT_math_exception, errmsg );
      }

      if( (sum2/no_sample) == ((double) 0.0) ) {
         ERRSIM_print_warning( "Coefficient of variation not computed" );
         *cfvr = 0.0;
      }
      else {
         *cfvr = (((sqrtarg/(sum4/no_sample)) < ((double) 0.0)) ? 
                      0.0 : 
                      (float) ( sqrt( sqrtarg )  / (sum2/no_sample) ) );
      }
   }

/* ==========================================================================
   Write values to report file
   ========================================================================== */
   out_class[ 0 ] = below_min;
   for( i=0, tot_samples = out_class[ 0 ]; i<class_no; i++ ) {
      out_class[ i+1 ] = classes[ i ];
      tot_samples += out_class[ i+1 ];
   }
   out_class[ class_no+1 ] = above_max;
   tot_samples += out_class[ class_no+1 ];

   if( out_class_norm != (float *) NULL ) {
      for( i=0; i<class_no+2; i++ ) {
         out_class_norm[ i ] = ((float) out_class[ i ])/((float) tot_samples);
      }
   }

   if( out_class_limit != (float *) NULL ) {
      for( i=0; i<class_no+1; i++ ) {
         out_class_limit[ i ] = (((float) i) / inv_class_range) + class_min;
      }
      out_class_limit[ class_no+1 ] = class_max;
   }

#ifdef __TRACE__
   for( check_sum=below_min, i=0; i<class_no; i++ ) {
      check_sum += classes[ i ];
   }
   check_sum += above_max;
   printf("check_sum = %0d\n", check_sum);
#endif

error_exit:;
/* ==========================================================================
   Freeze memory
   ========================================================================== */
   MATHIP_VECT_Free( &mask, &log_status_code );
   MATHIP_VECT_Free( &templine, &log_status_code );
   MATHIP_VECT_Free( &outline, &log_status_code );
   MATHIP_VECT_Free( &outline2, &log_status_code );
   MATHIP_VECT_Free( &outline4, &log_status_code );
   MEMSIP_free((void *) &classes );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STATIP_GLOB_stat */
