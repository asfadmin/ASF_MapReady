/* ==========================================================================
   $MODULE_HEADER

      $NAME              MATH_LIAL

      $FUNCTION          This module contains the routines used to solve
                         linear algebric equations and least square problems.

      $ROUTINE           MATHIP_LIAL_MatrInve
                         MATHIP_LIAL_InveGene
                         MATHIP_LIAL_LLSQEval

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       17-APR-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_NREC_H
#include MATH_INTF_H
#include MATH_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_LIAL_MatrInve

        $TYPE         PROCEDURE

        $INPUT        n	    : square dimension of the matrix to invert

        $MODIFIED     a	    : matrix a[n][n] to invert. In output it will be
                              destroied

        $OUTPUT       am    : inverse matrix am[n][n]

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_num_err

        $DESCRIPTION  This procedure makes the matrix inversion using the LU
                      decomposition

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_LIAL_MatrInve
                        (/*IN    */ INTx4                n,
                         /*IN OUT*/ double             **a,
                         /*   OUT*/ double             **am,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_LIAL_MatrInve";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  status;
   INTx4                 *indx = (INTx4 *)NULL;
   INTx4                  i,j;
   double                 d;
   double                *col = (double *)NULL;
   double               **aa = (double **)NULL;
   void                  *tmp1 = (void *)NULL;
   void                  *tmp2 = (void *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Error variable initialization
   ========================================================================== */
   status = 0;

/* ==========================================================================
   Allocates the index array for the decomposition ...
   ========================================================================== */
   if ( ( indx = (INTx4 *)MEMSIP_alloc ( (size_t)(n * sizeof (INTx4)) ) ) ==
        (INTx4 *)NULL ) {
      ERRSIM_set_error (status_code, ERRSID_MATH_err_mem_alloc, "" );
   }

/* ==========================================================================
   ... and the columns temporary storage array
   ========================================================================== */
   if ( ( col = (double *)MEMSIP_alloc ( (size_t)(n * sizeof (double)) ) ) ==
        (double *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc, "" );
   }

/* ==========================================================================
   Store the pointer value to preserve its content
   ========================================================================== */
   tmp1 = (void *)col;

   /* this is one-offset vector */
   col -= 1;

/* ==========================================================================
   Creates the one-offset matrix for the Num. Rec. routine ludcmp
   ========================================================================== */
   if ( ( aa = (double **)MEMSIP_alloc ( (size_t)(n * sizeof (double *)) ) ) ==
        (double **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc, "" );
   }

/* ==========================================================================
   Store the pointer value to preserve its containt
   ========================================================================== */
   tmp2 = (void *)aa;

   aa -= 1;
   for ( i=1; i<=n; i++ ) {
      aa[ i ] = &a[ i - 1 ][ 0 ];
      aa[ i ] -= 1;
   }

/* ==========================================================================
   Decompose the matrix
   ========================================================================== */
   dludcmp ( aa, n, indx - 1, &d, &status );
   if ( status ) {
      if ( status == 2 )                /* memory allocation error */
         ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc, "" );

      /* singular matrix in the LU decomposition */
      ERRSIM_set_error ( status_code, ERRSID_MATH_num_err,
                         "Singular matrix in the LUD" );
   }

/* ==========================================================================
   Find the inverse by columns
   ========================================================================== */
   for ( j=1; j<=n; j++ ) {
      for ( i=1; i<=n; i++ ) col[ i ] = 0.;
      col[ j ] = 1.;
      dlubksb ( aa, n, indx - 1, col, &status );
      for ( i=1; i<=n; i++ ) am[ i - 1 ][ j - 1 ] = col[ i ];
   }

error_exit:;

/* ==========================================================================
   Free memories
   ========================================================================== */
   MEMSIP_free ( (void **) &indx );
   MEMSIP_free ( (void **)&tmp1 );
   MEMSIP_free ( (void **)&tmp2 );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* MATHIP_LIAL_MatrInve */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_LIAL_InveGene

        $TYPE         PROCEDURE

        $INPUT        n	    : rows dimension of the matrix to invert
                      m	    : column dimension of the matrix to invert
                      a	    : the matrix a[n][m] to inverte

        $MODIFIED     NONE

        $OUTPUT       aig   : the matrix aig[m][m] that contains the inverted
                              matrix

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_err_mem_alloc

        $DESCRIPTION  This procedure creates the so called inverse generalized
                      of a given matrix a[n][m]. The inverse generalized matrix
                      is an aig[m][m] matrix defined as:

                                       T     -1
                               aig = (a  . a )

                      where the apices T stands for transposed, the apices
                      -1 stands for inverse and the symbol . stands for the
                      matrix rows by columns products

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_LIAL_InveGene
                        (/*IN    */ INTx4                n,
                         /*IN    */ INTx4                m,
                         /*IN    */ double             **a,
                         /*   OUT*/ double             **aig,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_LIAL_InveGene";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  i;
   INTx4                  j;
   INTx4                  k;
   double               **ata = (double **)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Allocates the matrix to containe the matrix to invert
   ========================================================================== */
   if ( ( ata = (double **)MEMSIP_alloc ( (size_t)(m * sizeof (double *)) ) ) ==
        (double **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc, "" );
   }
   for ( i=0; i<m; i++ ) {
      if ( ( ata[ i ] = (double *)MEMSIP_alloc ( (size_t)(m *
                                                 sizeof (double)) ) ) ==
           (double *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc, "" );
      }
   }

/* ==========================================================================
   Fills the matrix to invert
   ========================================================================== */
   for ( i=0; i<m; i++ ) {

      /* fills the upper diagonal part of the real symmetric matrix */
      for ( j=i; j<m; j++ ) {
         ata[ i ][ j ] = 0.;         /* zeroes the matrix values */
         for ( k=0; k<n; k++ ) {
            ata[ i ][ j ] += a[ k ][ i ] * a[ k ][ j ];
         }
      }

      /* fills the lower part of the matrix copying the upper values */
      if ( i != m - 1 ) {
         for ( j= ( i + 1 ); j<m; j++ ) {
            ata[ j ][ i ] = ata[ i ][ j ];
         }
      }
   }

/* ==========================================================================
   Invert the matrix ata
   ========================================================================== */
   MATHIP_LIAL_MatrInve ( m, ata, aig, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );      /* Error check */

error_exit:;

/* ==========================================================================
   Free memories
   ========================================================================== */
   if ( ata != (double **)NULL ) {
      for ( i=0; i<m; i++ ) {
         MEMSIP_free ( (void **)&(ata[ i ]) );
      }
      MEMSIP_free( (void **)&ata );
   }

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* MATHIP_LIAL_InveGene */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_LIAL_LLSQEval

        $TYPE	      PROCEDURE

        $INPUT        n	: number of elements of the array y
                      y	: array y[n] with the data known
                      m	: number of parameters to estimate
                      a	: the design matrix of the fitting problem that is
                          a[n][m]

        $MODIFIED     NONE

        $OUTPUT       p	: array p[m] with the estimated parameters

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_insuff_num_of_data
                      ERRSID_MATH_err_mem_alloc

        $DESCRIPTION  This procedure solves the linear least square problem
                      of finding a set of m p[m] parameters giving a set of n
                      equations that are linear functions of the parameters
                      themselves. The knowing data are assumed to have all
                      the same unitary variance and we don't have a priori
                      values. So the problem is of kind:

                                       y = a . p

                      where the symbol . stands for the application of the 
                      matrix a to the vector p. The solution p is given by:
                                     ^     T    -1   T
                                     p = (a . a)  . a  . y

                      where T stands for the transpose of the matrix and -1
                      stands for the inverse operator.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_LIAL_LLSQEval
                        (/*IN    */ INTx4                n,
                         /*IN    */ double              *y,
                         /*IN    */ INTx4                m,
                         /*IN    */ double             **a,
                         /*   OUT*/ double              *p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_LIAL_LLSQEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  i;
   INTx4                  j;
   double               **aig = (double **)NULL;
   double                *aty = (double *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the parameters consistency
   ========================================================================== */
   if ( n < m ) {

      /* insufficient number of data */
      ERRSIM_set_error ( status_code, ERRSID_MATH_insuff_num_of_data, "" );
   }

/* ==========================================================================
   Allocate memories and chek for the errors
   ========================================================================== */
   if ( ( aig = (double **)MEMSIP_alloc ( (size_t)(m * sizeof (double *)) ) ) ==
        (double **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc, "" );
   }

   for ( i=0; i<m; i++ ) {
      if ( ( aig[ i ] = (double *)MEMSIP_alloc ( (size_t)(m *
                                                 sizeof (double)) ) ) ==
           (double *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc, "" );
      }
   }

   if ( ( aty = (double *)MEMSIP_alloc ( (size_t)(m * sizeof (double)) ) ) ==
        (double *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc, "" );
   }

/* ==========================================================================
   Evaluate the generalized inverse of a
   ========================================================================== */
   MATHIP_LIAL_InveGene ( n, m, a, aig, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );      /* Error check */

/* ==========================================================================
   Evaluates the column vector aty: trans(a)*y
   ========================================================================== */
   for ( i=0; i<m; i++ ) {
      aty[ i ] = 0.;
      for ( j=0; j<n; j++ ) {
         aty[ i ] += a[ j ][ i ] * y[ j ];
      }
   }

/* ==========================================================================
   Apply the aig matrix to aty
   ========================================================================== */
   for ( i=0; i<m; i++ ) {
      p[ i ] = 0.;
      for ( j=0; j<m; j++ ) {
         p[ i ] += aig[ i ][ j ] * aty[ j ];
      }
   }

error_exit:;

/* ==========================================================================
   Free the memories
   ========================================================================== */
   if ( aig != (double **)NULL ) {
      for ( i=0; i<m; i++ ) {
         MEMSIP_free ( (void **)&(aig[ i ]) );
      }
      MEMSIP_free ( (void **)&aig );
   }

   MEMSIP_free( (void **)&aty );

   ERRSIM_close_routine( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* MATHIP_LIAL_LLSQEval */
