/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_EUND

      $FUNCTION          ERMAPPER Interface for IMAGE UNDERSAMPLING

      $ROUTINE           stbx_undersam_init
                         stbx_undersam
                         stbx_undersam_final

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       25-FEB-98     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include IRES_INTF_H
#include STBX_INTF_H
#include STBX_PGLB_H

#if defined(__WIN95__) && defined(__CODEWARRIOR__)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

/* ==========================================================================
                      STATIC VARIABLE DECLARATION SECTION
   ========================================================================== */
static float           **Kern;
static UINTx4            Kr, Kc;
static LDEFIT_boolean    const_kern;
static LDEFIT_boolean    error;

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_undersam_init

        $TYPE         PROCEDURE

        $INPUT        nr_rows            : row size of filtering
                      nr_cols            : column size of filtering
                      user_code_params   : additional parameters

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This is the UNDERSAMPLING initialisation function for the
                      ERMAPPER interface. It is called once before any 
                      processing is done.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
EXPORT void stbx_undersam_init
                        (/*IN    */ int                  nr_rows,
                         /*IN    */ int                  nr_cols,
                         /*IN    */ char                *user_code_params )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_RSMP";
#else
   const ERRSIT_proc_class proc_class   = "rsmp";
#endif
   const ERRSIT_proc_name routine_name = "stbx_undersam_init";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   FILSIT_file_name       ini_file;
   FILSIT_file_name       filterFile, filterFileName;
   float                  val;
   UINTx4                 i, j;
   FILE                  *fp;
   char                 **section_name = (char **) NULL;
   UINTx4                 section_no;
   STBXPT_task            task;
   UINTx4                 ipar;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_resampling_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Get ini file
   ========================================================================== */
   if( sscanf( user_code_params, "%s",  ini_file ) == 0 ) {
      ERRSIM_set_error( &status_code, ERRSID_STBX_parm_not_defined,
                         "ini file name" );
   }

/* ==========================================================================
   Extract from INI file all the section included
   ========================================================================== */
   FIISIP_GETS_get_sections(  ini_file,
                             &section_no,
                             &section_name,
                             &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Call the appropriate task procedure corresponding to the first section 
   contained in the INI file, checking if the task name is one of this tool
   ========================================================================== */
   if( strcmp( section_name[ 0 ], STBXPD_image_undersampling ) ) {
      ERRSIM_set_error( &status_code,
                         ERRSID_STBX_section_invalid,
                         section_name[ 0 ] );
   }

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, STBXPD_image_undersampling );
   task.parmNo = 1;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( &status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_filter_name );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( filterFileName );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) filterFileName;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( ipar=0; ipar<task.parmNo; ipar++ ) {
      FIISIP_GETS_get_info( ini_file,
                            task.name,
                            (UINTx4) 1, /* first section */
                           &(task.parm[ ipar ]),
                           &status_code );
      ERRSIM_on_err_goto_exit( status_code );
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( ipar=0; ipar<task.parmNo; ipar++ ) {
      if( ( !task.parm[ ipar ].founded ) && ( task.parm[ ipar ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ ipar ].name);
#endif
         ERRSIM_set_error( &status_code,
                            ERRSID_STBX_parm_not_defined,
                            task.parm[ ipar ].name );
      }
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Check if filter exists in current dir
   ========================================================================== */
   sprintf( filterFile, "%s", filterFileName );
   FILSIP_open( filterFile, "r", 0, &fp, &log_status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

/* ==========================================================================
   If the filter does not exists
   ========================================================================== */
   if( log_status_code != ERRSID_normal ) {

/* ==========================================================================
   Try in the configuration dir
   ========================================================================== */
      sprintf( filterFile, "%s%s", LDEFIV_cfg_dir, filterFileName );
      FILSIP_open( filterFile, "r", 0, &fp, &status_code );
      ERRSIM_on_err_goto_exit( status_code );
      FILSIP_close( &fp, &log_status_code );

   }

/* ==========================================================================
   Read kernel into memory
   ========================================================================== */
   IRESIP_UNDR_ReadFilter(  filterFile,
                           &Kern,
                           &Kr,
                           &Kc,
                           &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Check kernel size against user window size
   ========================================================================== */
   if( (Kr != (UINTx4) nr_rows) || (Kc != (UINTx4) nr_cols) ) {
      ERRSIM_set_error( &status_code, ERRSID_STBX_kernel_inv_dim,
                        "different kernel size in file against user settings" );
   }

/* ==========================================================================
   Check if it is a constant one
   ========================================================================== */
   val = Kern[ 0 ][ 0 ];
   const_kern = TRUE;
   for ( i=0; i<Kr; i++ ) {
      for ( j=0; j<Kc; j++ ) {
	 if ( Kern[ i ][ j ] != val )
	    const_kern = FALSE;
      }
   }

error_exit:;

   if( status_code != STC( ERRSID_normal ) ) {
      error = TRUE;
   }
   else {
      error = FALSE;
   }

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

}/* stbx_undersam_init */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_undersam

        $TYPE         PROCEDURE

        $INPUT        nr_rows            : row size of filtering
                      nr_cols            : column size of filtering
                      array              : matrix of image pixels

        $MODIFIED     NONE

        $OUTPUT       out_value          : computed image value

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This is the UNDERSAMPLING processing function for the
                      ERMAPPER interface. It is called once for each output 
                      value.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
EXPORT double stbx_undersam
                        (/*IN    */ int                  nr_rows,
                         /*IN    */ int                  nr_cols,
                         /*IN    */ double             **array )
{
   const ERRSIT_proc_name routine_name = "stbx_undersam";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double                 out_value;


/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );
/* ==========================================================================
   Check if not error in stbx_undersam_init
   ========================================================================== */
   if( error == FALSE ) {

/* ==========================================================================
      Check type of kernel
   ========================================================================== */
      if( const_kern ) {
         out_value = 
            (double) IRESIF_UNDR_ConstConvol( (void **) array, 
                                              LDEFIE_dt_double, 
                                              0, /* row start */
                                              0, /* col start */
                                              Kern[0][0], Kr, Kc, &status_code );
         ERRSIM_on_err_goto_exit ( status_code );
      }
      else {
         out_value =
            (double) IRESIF_UNDR_Convol( (void **) array, 
                                         LDEFIE_dt_double, 
                                         0, /* row start */
                                         0, /* col start */
                                         Kern, Kr, Kc, &status_code );
         ERRSIM_on_err_goto_exit ( status_code );
      }
   }
   else {
      out_value = array[ nr_rows/2 ][ nr_cols/2 ];
   }


error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   return( out_value );

}/* stbx_undersam */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_undersam_final

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This is the UNDERSAMPLING finalisation function for the
                      ERMAPPER interface. It is called after all processing 
                      has been done.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
EXPORT void stbx_undersam_final
                        ( void )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_RSMP";
#else
   const ERRSIT_proc_class proc_class   = "rsmp";
#endif
   const ERRSIT_proc_name routine_name = "stbx_undersam_final";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );


error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   if ( Kern != (float **)NULL )
      for ( i=0; i<Kr; i++ ) MEMSIP_free( (void *)(&Kern[ i ]) );
   MEMSIP_free( (void *)(&Kern) );


   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

}/* stbx_undersam_final */
