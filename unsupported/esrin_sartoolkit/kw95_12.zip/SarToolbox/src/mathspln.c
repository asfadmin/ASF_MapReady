/* ==========================================================================
   $MODULE_HEADER

      $NAME              MATH_SPLN

      $FUNCTION          This module contains routines about spline 
                         interpolation. They are masks to use the Numerical
                         Recipes routines

      $ROUTINE           MATHIP_SPLN_spline
			 MATHIP_SPLN_splint

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       08-APR-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_NREC_H
#include MATH_INTF_H
#include MATH_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_SPLN_spline

        $TYPE         PROCEDURE

        $INPUT        x	   : array x[n] of ordered abscissa values
                      y	   : array y[n] of values of the function to interpolate
                             evaluated in the abscissa points x
                      n    : number of tabulated function values
                      yp1  : value of the first derivative of the function
                             evaluated in the point x[0],y[0]
                      ypn  : value of the first derivative of the function
                             evaluated in the point x[n-1],y[n-1]

        $MODIFIED     NONE

        $OUTPUT       y2   : array with the second derivatives of the function
                             to interpolate evaluated in the abscissa values
                             x

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_one_point
                      ERRSID_MATH_err_mem_alloc

        $DESCRIPTION  This procedure initializes the variables to be used by
                      the Numerical Recipes' procedure spline, that evaluates
                      the second derivatives of the function to interpolate
                      subsequently

        $WARNING      The tabulated abscissa values must be monotonically
                      incrising, that is x[0] < x[1] < ... < x[n-2] < x[n-1]

        $PDL

   $EH
   ========================================================================== */

void MATHIP_SPLN_spline
                        (/*IN    */ double              *x,
                         /*IN    */ double              *y,
                         /*IN    */ INTx4                n,
                         /*IN    */ double               yp1,
                         /*IN    */ double               ypn,
                         /*   OUT*/ double              *y2, 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_SPLN_spline";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  status;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

/* ==========================================================================
   Error variable initialization
   ========================================================================== */
   status          = 0;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Tests the number of points
   ========================================================================== */
   if ( n < 2 )           /* the number of points must be greather then 1 */
      ERRSIM_set_error(status_code,ERRSID_MATH_one_point," n lesser then 2");

/* ==========================================================================
   Calls the spline routine
   ========================================================================== */
   dspline(x-1,y-1,n,yp1,ypn,y2-1,&status);
   if (status == 2)                /* memory allocation error */
      ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_SPLN_spline */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_SPLN_splint

        $TYPE         PROCEDURE

        $INPUT        xa  : the abscissa values xa[n] of the tabulated function
                            to interpolate
                      ya  : the values ya[n] of the function to interpolate
                            corresponding to the abscissa value xa
                      y2a : the values of the second derivatives of the
                            tabulated function evaluated at the points xa
                      n   : the number of elements of xa
                      x   : the abscissa value at which the function must be
                            interpolated

        $MODIFIED     NONE

        $OUTPUT       y   : the value of the function interpolated at the point
                            x

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_one_point
                      ERRSID_MATH_num_err

        $DESCRIPTION  This procedure initializes the variables to be used by
                      the Numerical Recipes' procedure splint, that interpolates
                      the tabulated function at a given point contained in the
                      range of abscissa values defined

        $WARNING      The tabulated abscissa values must be monotonically
                      incrising, that is x[0] < x[1] < ... < x[n-2] < x[n-1]

        $PDL

   $EH
   ========================================================================== */

void MATHIP_SPLN_splint
                        (/*IN    */ double              *xa,
                         /*IN    */ double              *ya,
                         /*IN    */ double              *y2a,
                         /*IN    */ INTx4                n,
                         /*IN    */ double               x,
                         /*   OUT*/ double              *y,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_SPLN_splint";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  status;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

/* ==========================================================================
   Error variable initialization
   ========================================================================== */
   status          = 0;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Tests the number of points
   ========================================================================== */
   if ( n < 2 )       /* the number of points must be > 1 */
      ERRSIM_set_error(status_code,ERRSID_MATH_one_point,"");

/* ==========================================================================
   Calls the splint routine
   ========================================================================== */
   dsplint(xa-1,ya-1,y2a-1,n,x,y,&status);
   if (status)                                      /* bad abscissa input */
      ERRSIM_set_error(status_code,ERRSID_MATH_num_err,"Bad abscissa input");

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_SPLN_splint */
