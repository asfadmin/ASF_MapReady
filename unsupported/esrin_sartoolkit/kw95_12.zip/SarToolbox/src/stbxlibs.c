/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_LIBS

      $FUNCTION          Library function for SAR Toolbox

      $ROUTINE           STBXPP_set_par
                         STBXPP_bld_file_name
                         STBXPP_get_coordinates
                         STBXPP_open_temp_comp_file
                         STBXPF_task_no
                         STBXPP_set_config
                         STBXPP_global_setting
                         STBXPP_update_coordinates

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       10-MAR-97     AN       Initial Release
            SCR#6     27-NOV-97     GRV      The AoI given by two corners in
                                             geodetic coordinates don't was
                                             used in the right manner
            SCR#7     01-DEC-97     AG       Bug in message when Size coords<2
            SCR#8     01-DEC-97     GRV      The BR coordinates in the case of
                                             centre given in row, col and sizes
                                             in pixel units are bad evaluated
            SCR#9     01-DEC-97     AG       Use tempTLRow(Col) and 
                                             tempBRRow(Col) inside 
                                             STBXPP_get_coordinates
            SCR#11    01-DEC-97     GRV      The checks on the Rect AoI sizes
                                             control if they are greather then
                                             zero

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include FIIS_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include IANN_INTF_H
#include COOR_INTF_H
#include STBX_INTF_H
#include STBX_PGLB_H
#if defined(__MC68K__) || defined(__POWERPC__)
#if defined(__HAVEIDL__)
#include IDLI_INTF_H
#endif
#endif

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_set_par

        $TYPE         PROCEDURE

        $INPUT        value   : value to be set in parm

        $MODIFIED     parm    : parm to be changed

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_type

        $DESCRIPTION  This procedure set the value of a parm according 
                      to its type.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void STBXPP_set_par     (/*IN    */ void                *value,
                         /*IN OUT*/ FIISIT_parm         *parm,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_set_par";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  tmpIntx4;
   float                  tmpFloat;
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check that the value is not NULL and the parameter is not a vector
   ========================================================================== */
   if( ( value != (void *) NULL ) && 
       ( !parm->vector ) ){

/* ==========================================================================
   Set value according to the type of the parm
   ========================================================================== */
      switch( parm->type ) {
	 case FIISIE_tt_string :
	    strcpy( parm->value, (char *) value );
	    parm->founded = TRUE;
	    break;
	 case FIISIE_tt_int :
	    tmpIntx4 = atoi( (char *) value );
	    memcpy( (void *) parm->value, (void *) &tmpIntx4, parm->size );
	    parm->founded = TRUE;
	    break;
	 case FIISIE_tt_float :
	    tmpFloat = atof( (char *) value );
	    memcpy( (void *) parm->value, (void *) &tmpFloat, parm->size );
	    parm->founded = TRUE;
	    break;
	 default:
	    ERRSIM_set_error( status_code, ERRSID_STBX_err_type, parm->name);
      }

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_set_par */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_bld_file_name

        $TYPE         PROCEDURE

        $INPUT        brief_name   : name of file to be built
                      task_name    : task name requesting creation
                      data_type    : data type of the output file

        $MODIFIED     NONR

        $OUTPUT       file_name    : file name with directory and extension

        $GLOBAL       STBXPV_task_file_ext

        $RET_STATUS   ERRSID_STBX_undef_task

        $DESCRIPTION  This procedure set the file name according to the
                      task creating it in the LDEFIV_out_dir

        $WARNING      NONE

        $PDL          - Look for ext in the STBXPV_task_file_ext
                      - Exit if the requested task does not exists
                      - Build full file name specification

   $EH
   ========================================================================== */
void STBXPP_bld_file_name    
                        (/*IN    */ char                *brief_name,
                         /*IN    */ char                *task_name,
                         /*IN    */ LDEFIT_data_type     data_type,
                         /*   OUT*/ char                *file_name,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_bld_file_name";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i;
   char                  *last_point;
   char                   temp_name[ 30 ];
   char                   data_type_chr;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Look for ext in the STBXPV_task_file_ext
   ========================================================================== */
   for( i=0; i<STBXPD_total_task_no; i++ ) {
      if( !strcmp( STBXPV_task_file_ext[ i ].task_name, task_name) ) {
         break;
      }
   }

/* ==========================================================================
   Exit if the requested task does not exists
   ========================================================================== */
   if( i >= STBXPD_total_task_no ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_undef_task,
                        task_name );
   }

/* ==========================================================================
   Save brief_name to temp_name
   ========================================================================== */
   strcpy( temp_name, brief_name );

#ifndef __UNIX__
   last_point = strrchr( temp_name, '.');
   if( last_point != (char *) NULL ) {
      *last_point = '\0';
   }
#endif

/* ==========================================================================
   Select data type extension
   ========================================================================== */
   switch( data_type ) {
      case LDEFIE_dt_undef:
         data_type_chr = 0;
         break;
      case LDEFIE_dt_UINTx1:
         data_type_chr = 'i';
         break;

      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_INTx2:
         data_type_chr = 's';
         break;

      case LDEFIE_dt_float:
         data_type_chr = 'f';
         break;
      case LDEFIE_dt_2_INTx2:
         data_type_chr = 't';
         break;
      case LDEFIE_dt_2_float:
         data_type_chr = 'c';
         break;
      case LDEFIE_dt_2_UINTx1:
         data_type_chr = 'r';
         break;

      case LDEFIE_dt_UINTx4:
      case LDEFIE_dt_INTx4:
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_par_type_not_all, "" );
   }

/* ==========================================================================
   Build full file name specification
   ========================================================================== */
   if( strcmp( STBXPV_task_file_ext[ i ].ext, "" ) ) {
      if( data_type_chr == 0 ) {
         sprintf( file_name, "%s%s.%s", LDEFIV_out_dir, temp_name, 
            STBXPV_task_file_ext[ i ].ext );
      }
      else {
         sprintf( file_name, "%s%s.%s%c", LDEFIV_out_dir, temp_name, 
            STBXPV_task_file_ext[ i ].ext, data_type_chr );
      }
   }
   else {
      sprintf( file_name, "%s%s", LDEFIV_out_dir, temp_name );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_bld_file_name */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_get_coordinates

        $TYPE         PROCEDURE

        $INPUT        ini_file	    : name of ini file to be read
                      section	    : section where to read
                      imanum	    : image number for annotation

        $MODIFIED     NONE

        $OUTPUT       TLRow	    : row top left coorner in 
                                      ROWCOL coordinates
                      TLCol         : column top left coorner in 
                                      ROWCOL coordinates
		      BRRow	    : row bottom right coorner in
                                      ROWCOL coordinates
                      BRCol         : column bottom right coorner in
                                      ROWCOL coordinates
                      vertex_no     : number of vertex of an area of interest
                      vertex	    : vertex of an area of interest in
				      ROWCOL coordinates
                      real_aoi      : TRUE when AOI is explicitly defined

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_parm_invalid
	              ERRSID_STBX_parm_not_defined

        $DESCRIPTION  This procedure read from an INI file the parameters
		      related to the area of interest and using the image
		      annotation transform it to TL-BR coorners. 

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void STBXPP_get_coordinates
                        (/*IN    */ char		*ini_file,
                         /*IN    */ char                *section,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ UINTx1               imanum,
                         /*   OUT*/ UINTx4              *TLRow,
                         /*   OUT*/ UINTx4              *TLCol,
                         /*   OUT*/ UINTx4              *BRRow,
                         /*   OUT*/ UINTx4              *BRCol,
                         /*   OUT*/ UINTx4              *vertex_no,
			 /*   OUT*/ MATHIT_RC          **vertex,
                         /*   OUT*/ LDEFIT_boolean      *real_aoi,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_get_coordinates";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   FIISIT_parm             tmpParm;
   char			   tmpString[ 256 ];
   LDEFIT_boolean          coorSysLatLon;
   LDEFIT_boolean          sizeUnitPixel;
   INTx4                   tmpINTx4Vector1[ 2 ];
   double                  tmpDoubleVector1[ 2 ];
   INTx4                   tmpINTx4Vector2[ 2 ];
   double                  tmpDoubleVector2[ 2 ];
   INTx4                   tmpINTx4Vector[ STBXPD_max_vertex ];
   double                  tmpDoubleVector[ STBXPD_max_vertex ];
   INTx4                   tmpINTx4;
   UINTx4		   i;
   MATHIT_RC               corners[ 2 ];
   INTx4                   tempTLRow, tempTLCol, tempBRRow, tempBRCol;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set real AOI to FALSE
   ========================================================================== */
   *real_aoi = FALSE;

/* ==========================================================================
   Set default TLRow, TLCol, BRRow and BRCol default values (ALL THE IMAGE)
   ========================================================================== */
   tempTLRow = 0;
   tempTLCol = 0;
   tempBRRow = IANNIV_ImageAnnot[ imanum ].ImageLength - 1;
   tempBRCol = IANNIV_ImageAnnot[ imanum ].ImageWidth - 1;

/* ==========================================================================
   Look for "Coordinate System" parameter
   ========================================================================== */
   strcpy( tmpParm.name, STBXPD_coordinate_system );
   tmpParm.type = FIISIE_tt_string;
   tmpParm.size = sizeof( tmpString );
   tmpParm.vector = FALSE;
   tmpParm.value = (void *) &(tmpString[ 0 ]);

   FIISIP_GETS_get_info( ini_file,
                         section,
                         section_no,
                        &tmpParm,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( tmpParm.founded ) {
      if( !(strcmp( tmpString, STBXPD_row_col )) ) {
         coorSysLatLon = FALSE;
      }
      else if( !(strcmp( tmpString, STBXPD_lat_lon )) ) {
         coorSysLatLon = TRUE;

/* ==========================================================================
   Init coordinate conversion for LATLON coordinates
   ========================================================================== */
         COORIP_CONV_Init( imanum,
                           status_code );
         if( *status_code != STC( ERRSID_normal ) ) {
            *status_code = ERRSID_normal;
            ERRSIM_print_warning( "Getting the whole image" );
            goto out;
         }
      }
      else {
	 ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_invalid, 
                           STBXPD_coordinate_system );
      }
   }
   else {
      coorSysLatLon = FALSE;
   }

/* ==========================================================================
   Look for TL-BR couple
   ========================================================================== */
   strcpy( tmpParm.name, STBXPD_top_left_corner);
   tmpParm.type = ( coorSysLatLon ? FIISIE_tt_double : FIISIE_tt_int );
   tmpParm.size = ( coorSysLatLon ? sizeof( double ) : sizeof( INTx4 ) );
   tmpParm.vector = TRUE;
   tmpParm.max_number = 2;
   if( coorSysLatLon ) {
      tmpParm.value = (void *) tmpDoubleVector1;
   }
   else {
      tmpParm.value = (void *) tmpINTx4Vector1;
   }

   FIISIP_GETS_get_info( ini_file,
			 section,
                         section_no,
			&tmpParm,
			 status_code );
   ERRSIM_on_err_goto_exit( *status_code );


   if( tmpParm.founded ) {

/* ==========================================================================
   Check if the number of coordinates is sufficient
   ========================================================================== */
      if( tmpParm.number < 2) {
	 ERRSIM_set_error( status_code,
			   ERRSID_STBX_parm_invalid, 
			   STBXPD_top_left_corner );
      }

/* ==========================================================================
   Found TopLeft corner. Looks for BottomRight
   ========================================================================== */
      strcpy( tmpParm.name, STBXPD_bottom_right_corner);
      tmpParm.type = ( coorSysLatLon ? FIISIE_tt_double : FIISIE_tt_int );
      tmpParm.size = ( coorSysLatLon ? sizeof( double ) : sizeof( INTx4 ) );
      tmpParm.vector = TRUE;
      tmpParm.max_number = 2;
      if( coorSysLatLon ) {
	 tmpParm.value = (void *) tmpDoubleVector2;
      }
      else {
	 tmpParm.value = (void *) tmpINTx4Vector2;
      }

      FIISIP_GETS_get_info( ini_file,
			    section,
                            section_no,
			   &tmpParm,
			    status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( !tmpParm.founded ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_STBX_parm_not_defined, 
			   STBXPD_bottom_right_corner );
      }
      if( tmpParm.founded && tmpParm.number < 2) {
	 ERRSIM_set_error( status_code,
			   ERRSID_STBX_parm_invalid, 
			   STBXPD_bottom_right_corner );
      }

/* ==========================================================================
   Fill Coordinates
   ========================================================================== */
      if( coorSysLatLon ) {

/* ==========================================================================
   ######################   FROM LATLON TL-BR TO ROWCOL TL-BR
   IN: TL tmpDoubleVector1 - BR tmpDoubleVector2
   OUT: tempTLRow, tempTLCol, tempBRRow, tempBRCol
   ========================================================================== */
         MATHIT_LLH llh_in;
         MATHIT_RC  rc_out[ 4 ];
	 MATHIT_RC  rc_TL;
	 MATHIT_RC  rc_BR;
	 INTx4      nVertex = 4;
         INTx4      i;

/* ==========================================================================
   Fill the lat, lon rectangle
   ========================================================================== */

	 /* Top Left corner */
         llh_in.lat = tmpDoubleVector1[ 0 ];
         llh_in.lon = tmpDoubleVector1[ 1 ];
         llh_in.h = (double) 0.0;
         COORIP_CONV_llh_rc( &llh_in,
                              imanum,
                             &(rc_out[ 0 ]),
                              status_code );
         ERRSIM_on_err_goto_exit( *status_code );                     

	 /* Top Right corner */
         llh_in.lat = tmpDoubleVector1[ 0 ];
         llh_in.lon = tmpDoubleVector2[ 1 ];
         llh_in.h = (double) 0.0;
         COORIP_CONV_llh_rc( &llh_in,
                              imanum,
                             &(rc_out[ 1 ]),
                              status_code );
         ERRSIM_on_err_goto_exit( *status_code );                     

	 /* Bottom Right corner */
         llh_in.lat = tmpDoubleVector2[ 0 ];
         llh_in.lon = tmpDoubleVector2[ 1 ];
         llh_in.h = (double) 0.0;
         COORIP_CONV_llh_rc( &llh_in,
                              imanum,
                             &(rc_out[ 2 ]),
                              status_code );
         ERRSIM_on_err_goto_exit( *status_code );                     

	 /* Bottom Left corner */
         llh_in.lat = tmpDoubleVector2[ 0 ];
         llh_in.lon = tmpDoubleVector1[ 1 ];
         llh_in.h = (double) 0.0;
         COORIP_CONV_llh_rc( &llh_in,
                              imanum,
                             &(rc_out[ 3 ]),
                              status_code );
         ERRSIM_on_err_goto_exit( *status_code );                     

/* ==========================================================================
   Check the AoI
   ========================================================================== */
	 COORIP_AOIX_CheckAoI( nVertex, rc_out, status_code );
	 ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Construct the square covering the lat, lon one
   ========================================================================== */
	 COORIP_AOIX_CoverRect( nVertex, rc_out, &rc_TL, &rc_BR, status_code );
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the corners
   ========================================================================== */
	 tempTLRow = (INTx4) rc_TL.row;
	 tempTLCol = (INTx4) rc_TL.col;
	 tempBRRow = (INTx4) rc_BR.row;
	 tempBRCol = (INTx4) rc_BR.col;

/* ==========================================================================
   Create the AoI
   ========================================================================== */
         *vertex_no = nVertex;

/* ==========================================================================
   Allocate the vertices of the AoI
   ========================================================================== */
         if ( ( (*vertex) = (MATHIT_RC *)MEMSIP_alloc ( (size_t)
                                      ((*vertex_no) * sizeof (MATHIT_RC)) ) ) ==
                (MATHIT_RC *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                               "Vertices" );
         }
         for ( i=0; i<(*vertex_no); i++ ) {
            ((*vertex)[ i ]).row = rc_out[ i ].row;
            ((*vertex)[ i ]).col = rc_out[ i ].col;
         }
      }
      else {

/* ==========================================================================
   From TL-BR ROWCOL TO TL-BR ROWCOL
   ========================================================================== */
	 if( tmpINTx4Vector1[ 0 ] < 0 ) {
	    ERRSIM_set_error( status_code,
			      ERRSID_STBX_parm_not_negative, 
			      STBXPD_top_left_corner );
	 }
	 tempTLRow = (INTx4) tmpINTx4Vector1[ 0 ];

	 if( tmpINTx4Vector1[ 1 ] <  0 ) {
	    ERRSIM_set_error( status_code,
			      ERRSID_STBX_parm_not_negative,
			      STBXPD_top_left_corner );
	 }
	 tempTLCol = (INTx4) tmpINTx4Vector1[ 1 ];

	 if( tmpINTx4Vector2[ 0 ] < 0 ) {
	    ERRSIM_set_error( status_code,
			      ERRSID_STBX_parm_not_negative, 
			      STBXPD_bottom_right_corner );
	 }
	 tempBRRow = (INTx4) tmpINTx4Vector2[ 0 ];

	 if( tmpINTx4Vector2[ 1 ] <  0 ) {
	    ERRSIM_set_error( status_code,
			      ERRSID_STBX_parm_not_negative,
			      STBXPD_bottom_right_corner );
	 }
	 tempBRCol = (INTx4) tmpINTx4Vector2[ 1 ];
      }
   }
   else {

/* ==========================================================================
   Look for TR-BL couple
   ========================================================================== */
      strcpy( tmpParm.name, STBXPD_top_right_corner );
      tmpParm.type = ( coorSysLatLon ? FIISIE_tt_double : FIISIE_tt_int );
      tmpParm.size = ( coorSysLatLon ? sizeof( double ) : sizeof( INTx4 ) );
      tmpParm.vector = TRUE;
      tmpParm.max_number = 2;
      if( coorSysLatLon ) {
	 tmpParm.value = (void *) tmpDoubleVector1;
      }
      else {
	 tmpParm.value = (void *) tmpINTx4Vector1;
      }

      FIISIP_GETS_get_info( ini_file,
			    section,
                            section_no,
			   &tmpParm,
			    status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( tmpParm.founded ) {

/* ==========================================================================
   Check if the number of coordinates is sufficient
   ========================================================================== */
	 if( tmpParm.number < 2) {
	    ERRSIM_set_error( status_code,
			      ERRSID_STBX_parm_invalid, 
			      STBXPD_top_right_corner );
	 }

/* ==========================================================================
   Found TopRight coorner. Looks for BottomLeft
   ========================================================================== */
	 strcpy( tmpParm.name, STBXPD_bottom_left_corner );
	 tmpParm.type = ( coorSysLatLon ? FIISIE_tt_double : FIISIE_tt_int );
	 tmpParm.size = ( coorSysLatLon ? sizeof( double ) : sizeof( INTx4 ) );
	 tmpParm.vector = TRUE;
	 tmpParm.max_number = 2;
	 if( coorSysLatLon ) {
	    tmpParm.value = (void *) tmpDoubleVector2;
	 }
	 else {
	    tmpParm.value = (void *) tmpINTx4Vector2;
	 }

	 FIISIP_GETS_get_info( ini_file,
			       section,
                               section_no,
			      &tmpParm,
			       status_code );
	 ERRSIM_on_err_goto_exit( *status_code );

	 if( !tmpParm.founded ) {
	    ERRSIM_set_error( status_code,
			      ERRSID_STBX_parm_not_defined, 
			      STBXPD_bottom_left_corner );
	 }
	 if( tmpParm.founded && tmpParm.number < 2) {
	    ERRSIM_set_error( status_code,
			      ERRSID_STBX_parm_invalid, 
			      STBXPD_bottom_left_corner );
	 }

/* ==========================================================================
   Fill Coordinates
   ========================================================================== */
	 if( coorSysLatLon ) {

/* ==========================================================================
   ######################   FROM LATLON TR-BL TO ROWCOL TL-BR
   IN: TR tmpDoubleVector1 - BL tmpDoubleVector2
   OUT: tempTLRow, tempTLCol, tempBRRow, tempBRCol
   ========================================================================== */
	    MATHIT_LLH llh_in;
	    MATHIT_RC  rc_out[ 4 ];
	    MATHIT_RC  rc_TL;
	    MATHIT_RC  rc_BR;
	    UINTx4     nVertex = 4;
            INTx4      i;

/* ==========================================================================
   Fill the lat, lon rectangle
   ========================================================================== */

	    /* Top Left corner */
	    llh_in.lat = (double) tmpDoubleVector1[ 0 ];
	    llh_in.lon = (double) tmpDoubleVector2[ 1 ];
	    llh_in.h = (double) 0.0;
	    COORIP_CONV_llh_rc( &llh_in,
				 imanum,
				&rc_out[ 0 ],
				 status_code );
	    ERRSIM_on_err_goto_exit( *status_code );

	    /* Top Right corner */
	    llh_in.lat = (double) tmpDoubleVector1[ 0 ];
	    llh_in.lon = (double) tmpDoubleVector1[ 1 ];
	    llh_in.h = (double) 0.0;
	    COORIP_CONV_llh_rc( &llh_in,
                                 imanum,
                                &rc_out[ 1 ],
                                 status_code );
            ERRSIM_on_err_goto_exit( *status_code );

	    /* Bottom Left corner */
	    llh_in.lat = (double) tmpDoubleVector2[ 0 ];
	    llh_in.lon = (double) tmpDoubleVector2[ 1 ];
	    llh_in.h = (double) 0.0;
	    COORIP_CONV_llh_rc( &llh_in,
				 imanum,
				&rc_out[ 2 ],
				 status_code );
	    ERRSIM_on_err_goto_exit( *status_code );                     

	    /* Bottom Right corner */
	    llh_in.lat = (double) tmpDoubleVector2[ 0 ];
	    llh_in.lon = (double) tmpDoubleVector1[ 1 ];
	    llh_in.h = (double) 0.0;
            COORIP_CONV_llh_rc( &llh_in,
                                 imanum,
                                &rc_out[ 3 ],
                                 status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check the AoI
   ========================================================================== */
	    COORIP_AOIX_CheckAoI( nVertex, rc_out, status_code );
	    ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Construct the square covering the lat, lon one
   ========================================================================== */
	    COORIP_AOIX_CoverRect( nVertex, rc_out, &rc_TL, &rc_BR,
				   status_code );
	    ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the corners
   ========================================================================== */
	    tempTLRow = (INTx4) rc_TL.row;
	    tempTLCol = (INTx4) rc_TL.col;
	    tempBRRow = (INTx4) rc_BR.row;
	    tempBRCol = (INTx4) rc_BR.col;

/* ==========================================================================
   Create the AoI
   ========================================================================== */
            *vertex_no = nVertex;

/* ==========================================================================
   Allocate the vertices of the AoI
   ========================================================================== */
            if ( ( (*vertex) = (MATHIT_RC *)MEMSIP_alloc ( (size_t)
                                      ((*vertex_no) * sizeof (MATHIT_RC)) ) ) ==
                   (MATHIT_RC *)NULL ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                                  "Vertices" );
            }
            for ( i=0; i<(*vertex_no); i++ ) {
               ((*vertex)[ i ]).row = rc_out[ i ].row;
               ((*vertex)[ i ]).col = rc_out[ i ].col;
            }
	 }
	 else {

/* ==========================================================================
   From TR-BL ROWCOL TO TL-BR ROWCOL
   ========================================================================== */
	    if( tmpINTx4Vector1[ 0 ] < 0 ) {
	       ERRSIM_set_error( status_code,
				 ERRSID_STBX_parm_not_negative, 
				 STBXPD_top_right_corner );
	    }
	    tempTLRow = (INTx4) tmpINTx4Vector1[ 0 ];

	    if( tmpINTx4Vector1[ 1 ] <  0 ) {
	       ERRSIM_set_error( status_code,
				 ERRSID_STBX_parm_not_negative,
				 STBXPD_top_right_corner );
	    }
	    tempBRCol = (INTx4) tmpINTx4Vector1[ 1 ];

	    if( tmpINTx4Vector2[ 0 ] < 0 ) {
	       ERRSIM_set_error( status_code,
				 ERRSID_STBX_parm_not_negative, 
				 STBXPD_bottom_left_corner );
	    }
	    tempBRRow = (INTx4) tmpINTx4Vector2[ 0 ];

	    if( tmpINTx4Vector2[ 1 ] <  0 ) {
	       ERRSIM_set_error( status_code,
				 ERRSID_STBX_parm_not_negative,
				 STBXPD_bottom_left_corner );
	    }
	    tempTLCol = (INTx4) tmpINTx4Vector2[ 1 ];
	 }
      }
      else {

/* ==========================================================================
   Look for CENTRE-SIZE couple
   ========================================================================== */
	 strcpy( tmpParm.name, STBXPD_centre );
	 tmpParm.type = ( coorSysLatLon ? FIISIE_tt_double : FIISIE_tt_int );
	 tmpParm.size = ( coorSysLatLon ? sizeof( double ) : sizeof( INTx4 ) );
	 tmpParm.vector = TRUE;
	 tmpParm.max_number = 2;
	 if( coorSysLatLon ) {
	    tmpParm.value = (void *) tmpDoubleVector1;
	 }
	 else {
	    tmpParm.value = (void *) tmpINTx4Vector1;
	 }

	 FIISIP_GETS_get_info( ini_file,
			       section,
                               section_no,
			      &tmpParm,
			       status_code );
	 ERRSIM_on_err_goto_exit( *status_code );

	 if( tmpParm.founded ) {

/* ==========================================================================
   Check if the number of coordinates is sufficient
   ========================================================================== */
	    if( tmpParm.number < 2) {
	       ERRSIM_set_error( status_code,
				 ERRSID_STBX_parm_invalid, 
				 STBXPD_centre );
	    }

            if( !coorSysLatLon ) {
               if( tmpINTx4Vector1[ 0 ] < 0 ) {
                  ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
                     STBXPD_centre );
               }
               if( tmpINTx4Vector1[ 1 ] < 0 ) {
                  ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
                     STBXPD_centre );
               }
            }

/* ==========================================================================
   Get Size Unit
   ========================================================================== */
	    strcpy( tmpParm.name, STBXPD_size_unit );
	    tmpParm.type = FIISIE_tt_string;
	    tmpParm.size = sizeof( tmpString );
	    tmpParm.vector = FALSE;
	    tmpParm.value = (void *) &(tmpString[ 0 ]);

	    FIISIP_GETS_get_info( ini_file,
				  section,
                                  section_no,
				 &tmpParm,
				  status_code );
	    ERRSIM_on_err_goto_exit( *status_code );

	    if( tmpParm.founded ) {
	       if( !(strcmp( tmpString, STBXPD_size_unit_km )) ) {
		  sizeUnitPixel = FALSE;
	       }
	       else if( !(strcmp( tmpString, STBXPD_size_unit_pixel )) ) {
		  sizeUnitPixel = TRUE;
	       }
	       else {
		  ERRSIM_set_error( status_code,
				    ERRSID_STBX_parm_invalid, 
				    STBXPD_size_unit );
	       }
	    }
	    else {
	       sizeUnitPixel = TRUE;
	    }

/* ==========================================================================
   Found Centre. Looks for Size.
   ========================================================================== */
	    strcpy( tmpParm.name, STBXPD_size );
	    tmpParm.type = ( sizeUnitPixel ? FIISIE_tt_int : FIISIE_tt_double );
	    tmpParm.size = ( sizeUnitPixel ? sizeof( INTx4 ) :
	       sizeof( double ) );
	    tmpParm.vector = TRUE;
	    tmpParm.max_number = 2;
	    if ( sizeUnitPixel ) {
	       tmpParm.value = (void *) tmpINTx4Vector2;
	    }
	    else {
	       tmpParm.value = (void *) tmpDoubleVector2;
	    }
	    FIISIP_GETS_get_info( ini_file,
				  section,
                                  section_no,
				 &tmpParm,
				  status_code );
	    ERRSIM_on_err_goto_exit( *status_code );

	    if( !tmpParm.founded ) {
	       ERRSIM_set_error( status_code,
				 ERRSID_STBX_parm_not_defined, 
				 STBXPD_size );
	    }

	    if( tmpParm.founded && tmpParm.number < 2) {
	       ERRSIM_set_error( status_code,
				 ERRSID_STBX_parm_invalid, 
				 STBXPD_size );
	    }

/* ==========================================================================
   Fill Coordinates
   ========================================================================== */
	    if( coorSysLatLon ) {
	       if( sizeUnitPixel ) {
		  MATHIT_LLH llh_center;
		  MATHIT_RC  rc_center;

/* ==========================================================================
   ######################   FROM LATLON CENTRE- PIXEL SIZE TO ROWCOL TL-BR
   ========================================================================== */
/* ==========================================================================
   Check the sizes parameters
   ========================================================================== */
		  if( tmpINTx4Vector2[ 0 ] <= 0 ) {
				       ERRSIM_set_error( status_code,
				       ERRSID_STBX_parm_not_negative, 
				       STBXPD_size );
		  }
		  if( tmpINTx4Vector2[ 1 ] <=  0 ) {
		     ERRSIM_set_error( status_code,
				       ERRSID_STBX_parm_not_negative,
				       STBXPD_size );
		  }
		  llh_center.lat = (double) tmpDoubleVector1[ 0 ];
		  llh_center.lon = (double) tmpDoubleVector1[ 1 ];
		  llh_center.h = (double) 0.0;

/* ==========================================================================
   Convert from geodetic to image coordinates
   ========================================================================== */
		  COORIP_CONV_llh_rc( &llh_center, imanum, &rc_center,
				      status_code );
                  ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the corners
   ========================================================================== */
		  tempTLRow = (INTx4)rc_center.row -
		     (UINTx4) ROUND(((float) tmpINTx4Vector2[ 0 ] - 1.0)/ 2);
		  tempTLCol = (INTx4)rc_center.col -
		     (UINTx4) ROUND(((float) tmpINTx4Vector2[ 1 ] - 1.0)/ 2);
                  tempBRRow = tempTLRow + tmpINTx4Vector2[ 0 ] - 1;
		  tempBRCol = tempTLCol + tmpINTx4Vector2[ 1 ] - 1;
	       }
	       else {
		  MATHIT_LLH llh_center;
		  MATHIT_RC  rc_out;
		  INTx4      row_size;
		  INTx4      col_size;

/* ==========================================================================
   ######################   FROM LATLON CENTRE- KM SIZE TO ROWCOL TL-BR
   ========================================================================== */
/* ==========================================================================
   Check the sizes parameters
   ========================================================================== */
		  if( tmpDoubleVector2[ 0 ] <= 0 ) {
				       ERRSIM_set_error( status_code,
				       ERRSID_STBX_parm_not_negative, 
				       STBXPD_size );
		  }
		  if( tmpDoubleVector2[ 1 ] <=  0 ) {
		     ERRSIM_set_error( status_code,
				       ERRSID_STBX_parm_not_negative,
				       STBXPD_size );
		  }
		  llh_center.lat = (double) tmpDoubleVector1[ 0 ];
		  llh_center.lon = (double) tmpDoubleVector1[ 1 ];
		  llh_center.h = (double) 0.0;

/* ==========================================================================
   Convert from geodetic to image coordinates
   ========================================================================== */
		  COORIP_CONV_llh_rc( &llh_center, imanum, &rc_out,
				      status_code );
                  ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Transform the size units from km to pixel
   ========================================================================== */
		  row_size = (INTx4) ROUND(tmpDoubleVector2[ 0 ] * 1.e+03 /
		     IANNIV_ImageAnnot[ imanum ].LineSpacing_m );
		  col_size = (INTx4) ROUND(tmpDoubleVector2[ 1 ] * 1.e+03 /
		     IANNIV_ImageAnnot[ imanum ].PixelSpacing_m );

/* ==========================================================================
   Fill the corners
   ========================================================================== */
		  tempTLRow = (INTx4)rc_out.row - 
                     (UINTx4) ROUND(((float) row_size - 1.0) / 2.);
		  tempTLCol = (INTx4)rc_out.col - 
                     (UINTx4) ROUND(((float) col_size - 1.0) / 2.);
		  tempBRRow = tempTLRow + row_size - 1;
		  tempBRCol = tempTLCol + col_size - 1;

	       }
	    }
	    else {

/* ==========================================================================
   From ROWCOL CENTRE-SIZE TO ROWCOL TL-BR
   ========================================================================== */
	       if( sizeUnitPixel ) {

/* ==========================================================================
   Check the row, column sizes
   ========================================================================== */
		  if( tmpINTx4Vector2[ 0 ] <= 0 ) {
		     ERRSIM_set_error( status_code,
				       ERRSID_STBX_parm_not_negative, 
				       STBXPD_size );
		  }
		  if( tmpINTx4Vector2[ 1 ] <= 0 ) {
		     ERRSIM_set_error( status_code,
				       ERRSID_STBX_parm_not_negative,
				       STBXPD_size );
		  }

/* ==========================================================================
   Fill the corners
   ========================================================================== */
		  tempTLRow = (INTx4)tmpINTx4Vector1[ 0 ] -
		     (INTx4) ROUND(((float) tmpINTx4Vector2[ 0 ] - 1.0) / 2.0);
		  tempTLCol = (INTx4)tmpINTx4Vector1[ 1 ] -
		     (INTx4) ROUND(((float) tmpINTx4Vector2[ 1 ] - 1.0) / 2.0);
		  tempBRRow = tempTLRow + tmpINTx4Vector2[ 0 ] - 1;
		  tempBRCol = tempTLCol + tmpINTx4Vector2[ 1 ] - 1;
	       }
	       else {
		  double     row_size;
                  double     col_size;

/* ==========================================================================
   ######################   FROM ROWCOL CENTRE - KM SIZE TO ROWCOL TL-BR 
   ========================================================================== */
/* ==========================================================================
   Check the sizes parameters
   ========================================================================== */
		  if( tmpDoubleVector2[ 0 ] <= 0 ) {
				       ERRSIM_set_error( status_code,
				       ERRSID_STBX_parm_not_negative, 
				       STBXPD_size );
		  }
		  if( tmpDoubleVector2[ 1 ] <= 0 ) {
		     ERRSIM_set_error( status_code,
				       ERRSID_STBX_parm_not_negative,
				       STBXPD_size );
		  }

/* ==========================================================================
   Transform the size units from km to pixel
   ========================================================================== */
                  row_size = (INTx4) ROUND(tmpDoubleVector2[ 0 ] * 1.e+03 /
                     IANNIV_ImageAnnot[ imanum ].LineSpacing_m );
                  col_size = (INTx4) ROUND(tmpDoubleVector2[ 1 ] * 1.e+03 /
                     IANNIV_ImageAnnot[ imanum ].PixelSpacing_m );

/* ==========================================================================
   Fill the corners
   ========================================================================== */
		  tempTLRow = (INTx4)tmpINTx4Vector1[ 0 ] -
		     (INTx4) ROUND((row_size - 1) / 2.);
                  tempTLCol = (INTx4)tmpINTx4Vector1[ 1 ] -
                     (INTx4) ROUND((col_size - 1) / 2.);
                  tempBRRow = tempTLRow + row_size - 1;
		  tempBRCol = tempTLCol + col_size - 1;
	       }
	    }
	 }
	 else {

/* ==========================================================================
   Look for VERTEXNO-VERTEX couple
   ========================================================================== */
	    strcpy( tmpParm.name, STBXPD_vertex_no );
	    tmpParm.type = FIISIE_tt_int;
	    tmpParm.size = sizeof( INTx4 );
	    tmpParm.vector = FALSE;
            tmpParm.value = (void *) &tmpINTx4;

	    FIISIP_GETS_get_info( ini_file,
				  section,
                                  section_no,
				 &tmpParm,
				  status_code );
	    ERRSIM_on_err_goto_exit( *status_code );

	    if( tmpParm.founded ) {

/* ==========================================================================
   Check if vertex_no is negative
   ========================================================================== */
	       if( tmpINTx4 < 0 ) {
		  ERRSIM_set_error( status_code,
				    ERRSID_STBX_parm_invalid,
                                    STBXPD_vertex_no );
	       }

/* ==========================================================================
   Set out value of vertex_no
   ========================================================================== */
	       *vertex_no = (UINTx4) tmpINTx4;

/* ==========================================================================
   Found Vertexno. Looks for Vertex.
   ========================================================================== */
	       strcpy( tmpParm.name, STBXPD_vertex );
	       tmpParm.type = ( coorSysLatLon ? 
                                   FIISIE_tt_double : FIISIE_tt_int );
	       tmpParm.size = ( coorSysLatLon ? 
                                   sizeof( double ) : sizeof( INTx4 ) );
	       tmpParm.vector = TRUE;
	       tmpParm.max_number = *vertex_no * 2;
	       if( coorSysLatLon ) {
		  tmpParm.value = (void *) tmpDoubleVector;
	       }
	       else {
		  tmpParm.value = (void *) tmpINTx4Vector;
	       }

/* ==========================================================================
   Get vertex
   ========================================================================== */
	       FIISIP_GETS_get_info( ini_file,
				     section,
                                     section_no,
				    &tmpParm,
				     status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       if( !tmpParm.founded ) {
		  ERRSIM_set_error( status_code,
				    ERRSID_STBX_parm_not_defined, 
				    STBXPD_vertex);
	       }
	       if( tmpParm.founded && tmpParm.number < (*vertex_no * 2) ) {
		  ERRSIM_set_error( status_code,
				    ERRSID_STBX_parm_invalid, 
				    STBXPD_vertex );
	       }

/* ==========================================================================
   Allocate memory
   ========================================================================== */
               *vertex = (MATHIT_RC *) MEMSIP_alloc((size_t)
                                    *vertex_no * sizeof( MATHIT_RC ));
               if( *vertex == (MATHIT_RC *) NULL ) {
                  ERRSIM_set_error( status_code,
                                    ERRSID_STBX_err_mem_alloc,
                                    "*vertex" );
               }

/* ==========================================================================
   Fill Coordinates
   ========================================================================== */
	       if( coorSysLatLon ) {

/* ==========================================================================
   ######################   FROM LATLON VERTEX TO ROWCOL TL-BR
   ========================================================================== */
                  MATHIT_LLH     llh_in;
		  MATHIT_RC	 rcTopLeft,rcBottomRight;

		  llh_in.h = (double) 0.0;
		  for( i=0; i<(*vertex_no); i++ ) {
		     llh_in.lat = (double) tmpDoubleVector[ 2*i ];
                     llh_in.lon = (double) tmpDoubleVector[ 2*i + 1 ];
		     COORIP_CONV_llh_rc( &llh_in,
					  imanum,
					 &((*vertex)[i]),
					  status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
		  }

/* ==========================================================================
   Check AOI
   ========================================================================== */
		  COORIP_AOIX_CheckAoI( *vertex_no,
				        *vertex,
				        status_code );
                  if ( *status_code != STC( ERRSID_normal ) ) {
		     ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, 
				       STBXPD_vertex );
		  }

/* ==========================================================================
   Find cover rect of AOI
   ========================================================================== */
		  COORIP_AOIX_CoverRect( *vertex_no, *vertex, &rcTopLeft,
					 &rcBottomRight, status_code );
  	          ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the corners
   ========================================================================== */
		  tempTLRow = (INTx4) rcTopLeft.row;
		  tempTLCol = (INTx4) rcTopLeft.col;
		  tempBRRow = (INTx4) rcBottomRight.row; 
		  tempBRCol = (INTx4) rcBottomRight.col;
	       }
	       else {

/* ==========================================================================
   FROM ROWCOL VERTEX TO ROWCOL TL-BR
   ========================================================================== */
		  MATHIT_RC	 rcTopLeft,rcBottomRight;

		  for( i=0; i<(*vertex_no); i++ ) {
		     if( tmpINTx4Vector[ 2*i ] <  0 ) {
			ERRSIM_set_error( status_code,
					  ERRSID_STBX_parm_not_negative,
					  STBXPD_vertex );
		     }
		     if( tmpINTx4Vector[ 2*i+1 ] <  0 ) {
			ERRSIM_set_error( status_code,
					  ERRSID_STBX_parm_not_negative,
					  STBXPD_vertex );
		     }
		     (*vertex)[ i ].row = (double) tmpINTx4Vector[ 2*i ];
		     (*vertex)[ i ].col = (double) tmpINTx4Vector[ 2*i+1 ];
		  }

/* ==========================================================================
   Check AOI
   ========================================================================== */
		  COORIP_AOIX_CheckAoI( *vertex_no, *vertex, status_code );
		  if ( *status_code != STC( ERRSID_normal ) ) {
		     ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, 
				       STBXPD_vertex );
		  }

/* ==========================================================================
   Set this as real AOI
   ========================================================================== */
                  *real_aoi = TRUE;

/* ==========================================================================
   Find cover rect of AOI
   ========================================================================== */
		  COORIP_AOIX_CoverRect( *vertex_no, *vertex, &rcTopLeft,
					 &rcBottomRight, status_code );
  	          ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the corners
   ========================================================================== */
		  tempTLRow = (INTx4) rcTopLeft.row;
		  tempTLCol = (INTx4) rcTopLeft.col;
		  tempBRRow = (INTx4) rcBottomRight.row; 
		  tempBRCol = (INTx4) rcBottomRight.col;
	       }
            }
            else {
               ERRSIM_print_warning( "No AOI parameters found. Get the whole image" );
            }
         }
      }
   }

/* ==========================================================================
   Check the rectangular window
   ========================================================================== */
   corners[ 0 ].row = (double) (tempTLRow);
   corners[ 0 ].col = (double) (tempTLCol);
   corners[ 1 ].row = (double) (tempBRRow);
   corners[ 1 ].col = (double) (tempBRCol);
   COORIP_AOIX_CheckRect( &corners[ 0 ], &corners[ 1 ], status_code );
   if ( *status_code != STC( ERRSID_normal ) ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_coord_not_cons, "" );
   }

/* ==========================================================================
   Back to output parametes
   ========================================================================== */
   tempTLRow = (INTx4) corners[ 0 ].row;
   tempTLCol = (INTx4) corners[ 0 ].col;
   tempBRRow = (INTx4) corners[ 1 ].row;
   tempBRCol = (INTx4) corners[ 1 ].col;

out:;

/* ==========================================================================
   Check the inner square
   ========================================================================== */
   if ( ( tempBRRow < 0 ) ||
	( tempBRCol < 0 ) ||
	( tempTLRow > IANNIV_ImageAnnot[ imanum ].ImageLength - 1 ) ||
	( tempTLCol > IANNIV_ImageAnnot[ imanum ].ImageWidth - 1 ) ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_coord_not_cons,
                        "AOI outside the image limits" );
   }

/* ==========================================================================
   Take the inner square
   ========================================================================== */
   if ( tempTLRow < 0 ) {
      *TLRow = (UINTx4)0;
   }
   else {
      *TLRow = tempTLRow;
   }
   if ( tempTLCol < 0 ) {
      *TLCol = (UINTx4)0;
   }
   else {
      *TLCol = tempTLCol;
   }
   if ( tempBRRow >= IANNIV_ImageAnnot[ imanum ].ImageLength ) {
      *BRRow = (UINTx4)IANNIV_ImageAnnot[ imanum ].ImageLength - 1;
   }
   else {
      *BRRow = tempBRRow;
   }
   if ( tempBRCol >= IANNIV_ImageAnnot[ imanum ].ImageWidth ) {
      *BRCol = (UINTx4)IANNIV_ImageAnnot[ imanum ].ImageWidth - 1;
   }
   else {
      *BRCol = tempBRCol;
   }

#ifdef __TRACE__
   fprintf( stdout, "TLRow=%0d\nTLCol=%0d\nBRRow=%0d\nBRCol=%0d\n\n",
             *TLRow, *TLCol, *BRRow, *BRCol );
   for( i=0; i<*vertex_no; i++) {
      fprintf( stdout, "v[%0d]=(%f,%f)\n", i, 
                  (*vertex)[ i ].row, (*vertex)[ i ].col );
   }

#endif

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_get_coordinates */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_open_temp_comp_file

        $TYPE         PROCEDURE

        $INPUT        tmp_file	: name of the temporary file to open
                      nrow_inp	: number of rows of the file to open
                      ncol_inp	: number of columns of the file to open
                      disp	: disposition ( faster direction in subsequent
                                  file reading)

        $MODIFIED     NONE

        $OUTPUT       chan      : the TIFF file channel of the opened file
                      bpar	: the structure with the basic parameters info
                                  to store in the temporary TIFF file

        $GLOBAL       LDEFIV_temp_dir	: temporary directory in which put the
                                          file

        $RET_STATUS   ERRSID_STBX_dimens_not_set
                      
        $DESCRIPTION  This procedure opens the temporary TIFF file in which
                      to store a floating point complex data file

        $WARNING      This procedure makes no check about the free space on the 
                      device indicated by the <temp_dir> variable

   $EH
   ========================================================================== */
void STBXPP_open_temp_comp_file
                        (/*IN    */ char                *tmp_file,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ const char           disp,
                         /*   OUT*/ GIOSIT_io           *tmp_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_open_temp_comp_file";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Variables for the temporary file name definition
   ========================================================================== */
   FILE                  *fp = NULL;           /* pointer to the file */

/* ==========================================================================
   Variables for the TIFF file to open
   ========================================================================== */
   INTx4                  img = 0;             /* image ID */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the rows and columns' number
   ========================================================================== */
   if ( nrow_inp == 0 )
      ERRSIM_set_error( status_code, ERRSID_STBX_dimens_not_set,
         " in the row direction");
   if ( ncol_inp == 0 )
      ERRSIM_set_error( status_code, ERRSID_STBX_dimens_not_set,
         " in the column direction");

/* ==========================================================================
   Create the temporary file name in which to store the FFT by rows
   ========================================================================== */
   LDEFIP_UTIL_gen_tmp_name( tmp_file,
                             status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check the filename goodness
   ========================================================================== */
   FILSIP_open( tmp_file, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( tmp_file, &log_status_code );

/* ==========================================================================
   Fill the basic structure for the temporary TIFF file
   ========================================================================== */
   TIFSIM_bpar_init( tmp_io->val.tif.bpar );
   tmp_io->val.tif.bpar.imagelength = nrow_inp;
   tmp_io->val.tif.bpar.imagewidth = ncol_inp;

   /* complex file */
   tmp_io->val.tif.bpar.sampleperpixel = 2;
   tmp_io->val.tif.bpar.bitspersample[ 0 ] = 
                                        LDEFID_byte_size * sizeof( float );
   tmp_io->val.tif.bpar.bitspersample[ 1 ] = 
                                   tmp_io->val.tif.bpar.bitspersample[ 0 ];
   tmp_io->val.tif.bpar.sampleformat[ 0 ] = 
                     tmp_io->val.tif.bpar.sampleformat[ 1 ] = TIFSID_float;

   /* set the faster reading direction */
   tmp_io->val.tif.bpar.disposition = disp;

/* ==========================================================================
   Open output TIFF file
   ========================================================================== */
   tmp_io->type = GIOSIE_tif;
   tmp_io->mode = 'w';
   strcpy( tmp_io->val.tif.name, tmp_file);
   tmp_io->val.tif.nimg = 1;
   tmp_io->val.tif.npar = TIFSID_nbpar; /* basic + 2 */
   tmp_io->img = 0;
   GIOSIP_open_io( tmp_io,
                   status_code );
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_open_temp_comp_file */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPF_task_no

        $TYPE         PROCEDURE

        $INPUT        name    : name of a SAR TOOLBOX task

        $MODIFIED     NONE

        $OUTPUT       task_no : number of a SAR TOOLBOX task

        $GLOBAL       NONE

        $RET_STATUS   

        $DESCRIPTION  This procedure returns the number of a SAR TOOLBOX task
                      given its name. 

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
INTx4 STBXPF_task_no    (/*IN    */ char                *name,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPF_task_no";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Looks for number in STBXPC_toolbox_name
   ========================================================================== */
   for( i=0; i<(STBXPD_total_task_no + 1); i++ ) {
      if( !strcmp( name, STBXPC_toolbox_name[ i ] ) ) {
         break;
      }
   }

/* ==========================================================================
   Check if this task does not exists
   ========================================================================== */
   if( i == (STBXPD_total_task_no + 1) ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_task_not_defined, name );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return( i );

}/* STBXPF_task_no */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_set_config

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       dir     : dir to be set

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure set the value of dir according
                      to STBXPD_cfg_dir

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void STBXPP_set_config  (/*   OUT*/ char                *dir,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_set_config";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

#if defined(__MC68K__) || defined(__POWERPC__)
#if defined(__HAVEIDL__)
   IDL_VPTR                     home_dir_idl;
   char                        *home_dir_idl_var_name = "stbxhome";
   int                          ienter = 0;
#endif
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

#if defined(__UNIX__) || defined(__WIN95__) || defined(__DOS__)

   sprintf( dir, "%s%s%s%s", 
            getenv( ERRSID_stbxhome ), ERRSID_dir_separator, 
            STBXPD_cfg_dir, ERRSID_dir_separator );

#elif defined(__MC68K__) || defined(__POWERPC__)

#if defined(__HAVEIDL__)
   home_dir_idl = IDL_FindNamedVariable( home_dir_idl_var_name, ienter );
   if( (home_dir_idl != (IDL_VPTR) NULL) && (home_dir_idl->type == IDL_TYP_STRING) ) {
      sprintf( dir, "%s%s%s%s", IDL_STRING_STR( &(home_dir_idl->value.str) ),
         ERRSID_dir_separator, STBXPD_cfg_dir, ERRSID_dir_separator );
   }
   else {
      sprintf( dir, "%s%s%s", 
         ERRSID_dir_separator, STBXPD_cfg_dir, ERRSID_dir_separator );
   }

#else
   sprintf( dir, "%s%s%s", 
      ERRSID_dir_separator, STBXPD_cfg_dir, ERRSID_dir_separator );
#endif

#endif


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_set_config */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_global_setting

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the GLOBAL SETTING task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any

   $EH
   ========================================================================== */
void STBXPP_global_setting
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_global_setting";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) STBXPV_inp_dir_val;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) STBXPV_out_dir_val;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) STBXPV_temp_dir_val;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &STBXPV_delete_input_val;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Set global variables, if found
   ========================================================================== */
   if( task.parm[ 0 ].founded ) {
      sprintf( LDEFIV_inp_dir, "%s", STBXPV_inp_dir_val );
   }
   if( task.parm[ 1 ].founded ) {
      sprintf( LDEFIV_out_dir, "%s", STBXPV_out_dir_val );
   }
   if( task.parm[ 2 ].founded ) {
      sprintf( LDEFIV_temp_dir, "%s", STBXPV_temp_dir_val );
   }
   if( task.parm[ 3 ].founded ) {
      LDEFIV_delete_input = STBXPV_delete_input_val;
   }

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_global_setting */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_update_coordinates

        $TYPE         PROCEDURE

        $INPUT        imanum : image annotation index

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure set the value of the coordinates tag

        $WARNING      Please be sure that SubImageTopLeft and ScalingFactor
                      tags have been already updated (if needed)

        $PDL

   $EH
   ========================================================================== */
void STBXPP_update_coordinates
                        (/*IN    */ UINTx1               imanum,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_update_coordinates";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   MATHIT_RC              corner_rc;
   MATHIT_LLH             corner_llh;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Initialize the coordinates conversions
   ========================================================================== */
   COORIP_CONV_Init( (INTx4)imanum, status_code );
   if( *status_code != STC( ERRSID_normal ) ) {
      *status_code = ERRSID_normal;
      ERRSIM_print_warning( "Corners coordinates not evaluable" );
      IANNIV_ImageAnnot[ imanum ].TopLeftLat_deg = 0.0;
      IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg = 0.0;
      IANNIV_ImageAnnot[ imanum ].TopRightLat_deg = 0.0;
      IANNIV_ImageAnnot[ imanum ].TopRightLon_deg = 0.0;
      IANNIV_ImageAnnot[ imanum ].BottomRightLat_deg = 0.0;
      IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg = 0.0;
      IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg = 0.0;
      IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg = 0.0;
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg = 0.0;
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg = 0.0;
      IANNIV_ImageAnnot[ imanum ].TopLeftEast_m = 0.0;
      IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m = 0.0;
   } 
   else {
/* ==========================================================================
   Corners coordinates
   ========================================================================== */
      /* Top Left corner */
      corner_rc.row = (double) 0;
      corner_rc.col = (double) 0;
      COORIP_CONV_rc_llh( &corner_rc,
			  (INTx4)imanum,
			  &corner_llh,
			  status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      IANNIV_ImageAnnot[ imanum ].TopLeftLat_deg = (float) corner_llh.lat;
      IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg = (float) corner_llh.lon;

      /* Top Right corner */
      corner_rc.row = (double) 0;
      corner_rc.col = (double)( IANNIV_ImageAnnot[ imanum ].ImageWidth - 1 );
      COORIP_CONV_rc_llh( &corner_rc,
			  (INTx4)imanum,
			  &corner_llh,
			  status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      IANNIV_ImageAnnot[ imanum ].TopRightLat_deg = (float) corner_llh.lat;
      IANNIV_ImageAnnot[ imanum ].TopRightLon_deg = (float) corner_llh.lon;

      /* Bottom Right corner */
      corner_rc.row = (double)( IANNIV_ImageAnnot[ imanum ].ImageLength - 1 );
      corner_rc.col = (double)( IANNIV_ImageAnnot[ imanum ].ImageWidth - 1 );
      COORIP_CONV_rc_llh( &corner_rc,
			  (INTx4)imanum,
			  &corner_llh,
			  status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      IANNIV_ImageAnnot[ imanum ].BottomRightLat_deg = (float) corner_llh.lat;
      IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg = (float) corner_llh.lon;

      /* Bottom Left corner */
      corner_rc.row = (double)( IANNIV_ImageAnnot[ imanum ].ImageLength - 1 );
      corner_rc.col = (double) 0;
      COORIP_CONV_rc_llh( &corner_rc,
			  (INTx4)imanum,
			  &corner_llh,
			  status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg = (float) corner_llh.lat;
      IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg = (float) corner_llh.lon;

      /* Center point */
      corner_rc.row =
         (((double) IANNIV_ImageAnnot[ imanum ].ImageLength - 1.0 ) / 2.0 );
      corner_rc.col =
         (((double) IANNIV_ImageAnnot[ imanum ].ImageWidth - 1.0 ) / 2.0 );
      COORIP_CONV_rc_llh( &corner_rc,
			  (INTx4)imanum,
			  &corner_llh,
			  status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg = (float)
	 corner_llh.lat;
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg = (float)
	 corner_llh.lon;

/* ==========================================================================
   Geocoded product
   ========================================================================== */
      switch ( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {
	 case IANNIE_proj_UTM:
	 case IANNIE_proj_UPS: {
	    MATHIT_EN	   corner_en;

/* ==========================================================================
   Rescale the top left corner
   ========================================================================== */
            corner_rc.row = (double) 
               (IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow *
                IANNIV_ImageAnnot[ imanum ].YScalingFactor);
	    corner_rc.col = (double) 
               (IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol *
                IANNIV_ImageAnnot[ imanum ].XScalingFactor);

/* ==========================================================================
   Convert the top left corner
   ========================================================================== */
	    COORIP_CONV_rc_en( &corner_rc,
			       (INTx4)imanum,
			       &corner_en,
			       status_code );
	    ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the corresponding tags in the structure
   ========================================================================== */
	    IANNIV_ImageAnnot[ imanum ].TopLeftEast_m = (float)
	       corner_en.east;
	    IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m = (float)
	       corner_en.north;
	 }
      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_update_coordinates */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_check_dirs

        $TYPE         PROCEDURE

        $INPUT        NONE
        
        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine checks the validity of specified input, output and 
                      temporary dirs
                      
        $WARNING      ONLY ON TARGET PLATFORMS

        $PDL          - Check if the ending char of input, output and temporary dir
                        is the separator directory one.
                        
   $EH
   ========================================================================== */
void STBXPP_check_dirs
                        (/*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_check_dirs";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                   dir_sep;
   char                   msg[ 132 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

#ifndef __VMS__
#if defined __MC68K__ || defined __POWERPC__
   dir_sep = ':';
#endif
#if defined __DOS__ || defined __WIN95__
   dir_sep = '\\';
#endif
#ifdef __UNIX__
   dir_sep = '/';
#endif

/* ==========================================================================
   Check input directory
   ========================================================================== */
   if( LDEFIV_inp_dir[ strlen( LDEFIV_inp_dir ) - 1 ] != dir_sep ) {
      sprintf( msg, "\"%s\" directory specified in \"%s\" parameter should be end with \"%c\"",
         LDEFIV_inp_dir, STBXPD_input_dir, dir_sep );
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
         msg );
   }

/* ==========================================================================
   Check output directory
   ========================================================================== */
   if( LDEFIV_out_dir[ strlen( LDEFIV_out_dir ) - 1 ] != dir_sep ) {
      sprintf( msg, "\"%s\" directory specified in \"%s\" parameter should be end with \"%c\"",
         LDEFIV_out_dir, STBXPD_output_dir, dir_sep );
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
         msg );
   }

/* ==========================================================================
   Check temporary directory
   ========================================================================== */
   if( LDEFIV_temp_dir[ strlen( LDEFIV_temp_dir ) - 1 ] != dir_sep ) {
      sprintf( msg, "\"%s\" directory specified in \"%s\" parameter should be end with \"%c\"",
         LDEFIV_temp_dir, STBXPD_temporary_dir, dir_sep );
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
         msg );
   }

#endif

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_check_dirs */
