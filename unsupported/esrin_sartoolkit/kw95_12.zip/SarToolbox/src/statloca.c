/* ==========================================================================
   $MODULE_HEADER

      $NAME              STAT_LOCA

      $FUNCTION          This module contains the procedure to execute
			 the LOCAL STATISTIC analysis of an image

      $ROUTINE           STATIP_LOCA_stat

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       29-JUL-97     AG       Initial Release
            N/A       23-MAR-97     AG       Add for Reqs B10/B18 

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include GIOS_INTF_H
#include OVLS_INTF_H
#include IANN_INTF_H
#include STAT_INTF_H
#include STAT_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STATIP_LOCA_stat

      $TYPE	    PROCEDURE

      $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                    imanum    : number identifing the image inside the tool
                    TLRow     : the row image coordinate in the full
                                reference frame of the image
                    TLCol     : the column image coordinate in the full
                                reference frame of the image
                    nrow_inp  : number of rows of the image
                    ncol_inp  : number of columns of the images
		    vertex_no : number of the vertex of an AOI, if any 
                                (0, otherwise)
                    vertex    : array of vertex coordinates
		    win_sizes : size of the window (row, col)
		    win_increments
		              : step size of the window (row, col)
	            fill_val  : value to be used to fill the image outside
			        the AOI
                    out_io    : structure with the IO basic parameters of the
                                output image
                    nrow_out  : number of rows of the output image block
                    ncol_out  : number of columns of the output image block
                    imageType : type of image to be produced(MEAN, SDDV 
                                or CFVR)

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   ERRSID_STAT_data_type_not_allow
                    ERRSID_STAT_err_mem_alloc

      $DESCRIPTION  This procedure executes the LOCAL STATISTICS of an image
                    creating as output one of MEAN, SDDV or CFVR statistic
                    image

      $WARNING      The input and the output files shall be already opened.

      $PDL          - Select core_func for kernel-image window convolution
                    - Select the data type of the input image
		    - Build kernel
		    - Call Overlap & Save windowing image method

   $EH
   ========================================================================== */
void STATIP_LOCA_stat
                       ( /*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4               vertex_no,
			 /*IN    */ MATHIT_RC           *vertex,
			 /*IN    */ INTx4               *win_sizes,
			 /*IN    */ double              *win_increments,
                         /*IN    */ float                fill_val,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ STATIT_image_type    imageType,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STATIP_LOCA_stat";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   float                **Kern;
   UINTx2                 Kr, Kc, i, j;
   OVLSIT_core_func       core_func;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_STAT_imanum_not_allow, "");
   }

/* ==========================================================================
   Set the convolution core according to the image type to be computed
   ========================================================================== */
   switch ( imageType ) {
      case STATIE_image_mean:
	 core_func = STATPP_KERN_Mean;
	 break;
      case STATIE_image_sddv:
	 core_func = STATPP_KERN_Sddv;
	 break;
      case STATIE_image_cfvr:
	 core_func = STATPP_KERN_Cfvr;
	 break;
      case STATIE_image_copy:
	 core_func = STATPP_KERN_Copy;
	 break;
   }

/* ==========================================================================
   Check the data type of the input image
   ========================================================================== */
   switch ( inp_io->spp ) {
      case 1:
/* ==========================================================================
   Real data
   ========================================================================== */
	 switch( inp_io->bps ) {
	    case 8:
               /* quick look images */
	       break;
	    case 16:
               /* real data ( PRI, GEC, GTC ) */
	       break;
	    case 32:
               /* floating point internal data type */
	       break;
	    default:
	       ERRSIM_set_error(status_code, ERRSID_STAT_data_type_not_allow,
		  "");
	 }
	 break;
      case 2:
/* ==========================================================================
   Complex data
   ========================================================================== */
	 switch( inp_io->bps ) {
            case 8:
               /* RAW */
               break;
	    case 16:
               /* SLC SLCI */
	       break;
	    case 32:
               /* complex floating point internal data type */
	       break;
	    default:
	       ERRSIM_set_error(status_code, ERRSID_STAT_data_type_not_allow,
		  "");
	 }
	 break;
      default:
	 ERRSIM_set_error(status_code, ERRSID_STAT_data_type_not_allow,
	    "");
   }

/* ==========================================================================
   Set the size of kernel and allocate it
   ========================================================================== */
   Kr = (UINTx2) win_sizes[ 0 ];
   Kc = (UINTx2) win_sizes[ 1 ];
   Kern = (float **) MEMSIP_alloc( (size_t)( Kr * sizeof(float *) ) );
   if( Kern == (float **) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STAT_err_mem_alloc, "Kern" );
   }
   for ( i=0; i<Kr; i++ ) {
      Kern[ i ] = (float *) MEMSIP_alloc( (size_t)( Kc * sizeof(float) ) );
      if( Kern[ i ] == (float *) NULL ) {
         ERRSIM_set_error( status_code, ERRSID_STAT_err_mem_alloc, "Kern[i]" );
      }
   }
   for ( i=0; i<Kr; i++ ) {
      for ( j=0; j<Kc; j++ ) {
	 Kern[ i ][ j ] = 1.0/((float) Kr * Kc);
      }
   }

/* ==========================================================================
   Call the OVERLAP & SAVE routine
   ========================================================================== */
   OVLSIP_OverlapAndSave( inp_io, imanum, TLRow, TLCol, 
                          nrow_inp, ncol_inp, vertex_no, vertex,
                          Kern, Kr, Kc, win_increments[ 0 ], 
                          win_increments[ 1 ], out_io, nrow_out,
                          ncol_out, core_func, fill_val, (INTx4) 0, 
                          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze memories
   ========================================================================== */
   if ( Kern != (float **)NULL ) {
      for ( i=0; i<Kr; i++ ) {
         MEMSIP_free( (void *) &(Kern[ i ]) );
      }
      MEMSIP_free( (void *) &Kern );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STATIP_LOCA_stat */
