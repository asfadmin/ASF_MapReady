/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*                                                                           */


/* ==========================================================================
   $MODULE_HEADER

      $NAME              TIFS_XREA

      $FUNCTION          Demo Libreria BTIFF: lettura di una immagine

      $ROUTINE           TIFS_MAIN_main

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       08-JAN-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <string.h>
#include <math.h>
#ifdef __MC68K__
    #include <console.h>
#endif
#ifdef __POWERPC__
    #include <console.h>
#endif


#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include FILS_INTF_H
#include TIFS_INTF_H
#include TIFS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

static void trace_in( INTx4     argc,
                      char   *argv[] )
{                                                        
   ERRSIT_status log_status_code;                   
   char            tmp_str[256];
   INTx4           i;
    
   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);
   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);

   sprintf(tmp_str,"%s%d","argc       : ",argc);
   ERRSIP_HPEL_trace_proc_err_log(tmp_str, &log_status_code);
   for(i = 0; i < argc; i++ )
   {
      sprintf(tmp_str,"argv[%02d] : %s",i,argv[i]);
      ERRSIP_HPEL_trace_proc_err_log(tmp_str, &log_status_code);
   }
}                                                        

/* ==========================================================================

   $ROUTINE_HEADER

        $XREA         TIFS_XREA_main

        $TYPE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

main( INTx4   argc, char *argv[] )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "TIFS_XREA";
#else
   const ERRSIT_proc_class proc_class   = "trea";
#endif
   const ERRSIT_proc_name  routine_name = "TIFS_XREA_main";
   
   ERRSIT_status           log_status_code;
   ERRSIT_status           status_code;
   ERRSIT_flag             process_flag;

  /* Variabili da allocare per accedere ad un file BTIFF                     */

  char namein[80];  /* nome del file contenente l'immagine che verra' letta */
  char nameout[80];
  FILE *fout;

  TIFSIT_par param; /* struttura con cui passare un generico parametro */
  TIFSIT_basicpar bpar; /* struttura contenente i parametri fondamentali */

  INTx4 channel; /* numero di canale restituito dalla funzione che apre il file */
  INTx4 image=0; /* numero identificativo dell'immagine (la prima e' la numero 0) */
  INTx4 nimage=1; /* numero di immagini nel file, in questo caso 1 */


  /* Variabili allocate per una linea dell'immagine                         */
  void *imgline; /* Puntatore usato per accedere alla linea */

  /* Variabili generiche usate dal programma */
  INTx4        i;
  UINTx4       pixel, pixno, pixsize, sample, size;
  UINTx4       column_start, column_stop, row_start, row_stop;
  INTx4        line, line_no;

/* ==========================================================================
   Variables for the block reading
   ========================================================================== */
   UINTx2                **block = NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code      = ERRSID_normal;
   log_status_code  = ERRSID_normal;

   ERRSIP_HPEL_process_init(  proc_class,
                             &log_status_code );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,   
                        &log_status_code);

/* ==========================================================================
 Inizializzation for MAC console.
========================================================================== */ 
#ifdef __MC68K__
	argc=ccommand(&argv);    
#endif
#ifdef __POWERPC__
	argc=ccommand(&argv);    
#endif              

   
   
   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in( argc, argv );
   }

   TIFSIP_init_filedata( &status_code );  
			    /* Inizializza i dati per libreria TIFF */
                            /* Va chiamato solo 1 volta all'inizio   */
   ERRSIM_on_err_goto_exit( status_code );

   /* Lettura dell' immagine */
   if( argc > 1) {
      strcpy( namein, argv[1] );
   }
   else {
      printf("\n \n Enter input file: ");   /* Nome del file che verra' letto */
      scanf("%s", namein);
   }

   /* Apertura del file: restituisce il canale associato                */
   TIFSIP_open_tiff(namein,'r',&channel, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

   /* Legge il numero di immagini presenti nel file                     */
   TIFSIP_get_imgnum(channel,&nimage, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

   /* Legge le informazioni fondamentali e i descrittori interni        */
   TIFSIP_get_blockinfo(channel,image,&bpar, &status_code); 
   ERRSIM_on_err_goto_exit( status_code );

   printf("\n Image Width (pixels) %d",bpar.imagewidth); /* Numero di pixels  */
                                                         /* dell' immagine    */
                                                         /* nella direzione X */

   printf("\n Image Length (pixels) %d",bpar.imagelength);/* Numero di pixels  */
                                                          /* dell' immagine    */
							  /* nella direzione Y */

   printf("\n Tile Width (pixels) %d",bpar.columnsperblock); /* Numero di pixels */
                                                             /* del blocco nella */
                                                             /* direzione X      */

   printf("\n Tile Length (pixels) %d",bpar.rowsperblock); /* Numero di    */
                                                           /* pixels del blocco */
                                                           /* nella direzione Y */

   printf("\n Compression (1=None 5=LZW) %d",bpar.compression); /* Tipo di     */
							        /* compressione dei dati */

#ifdef TIFS_XY
   printf("\n Preferential direction (x-y) %c",bpar.disposition); /* Direzione */
                                                                  /* preferenziale */
#endif

   printf("\n Sample per Pixel %d",bpar.sampleperpixel);  /* Numero di samples */
			  			          /* con cui e'        */
							  /* rappresentato un  */
							  /* pixel. Equivale al*/
							  /* numero di bande   */

   printf("\n Bits per Sample %d",bpar.bitspersample[0]); /* Numero di bits con*/
                                                          /* cui e'            */
                                                          /* rappresentato un  */
                                                          /* sample            */

   printf("\n Sample Format %d",bpar.sampleformat[0]);    /* Tipo di formato */
                                                          /* del dato        */

   printf("\n Photometric interp. %d",bpar.photometricinterpretation);
                                                          /* 1=Grayscale Image */

   printf("\n X Resolution (per print) %f",(float)bpar.xresolution[0]/
                                           (float)bpar.xresolution[1]);
                                                                /* Risoluz    */
                                                                /* in X per la*/
                                                                /* stampa     */

   printf("\n Y Resolution (per print) %f",(float)bpar.yresolution[0]/
                                           (float)bpar.yresolution[1]);
                                                                /* Risoluz    */
                                                                /* in Y per la*/
                                                                /* stampa     */

   printf("\n Resolution units (per print) %d",bpar.resolutionunit);
                                                                /* Unita' in  */
                                                                /* cui e'     */
                                                                /* misurata la*/
                                                                /* risoluzione*/


   /* Ora l'immagine viene letta per linee. E' necessario aprire il modo   */
   /* di lettura, leggere un certo numero di linee, chiudere il modo       */
   /* Queste 3 fasi possono anche essere ripetute piu' volte p.es.         */
   /* suddividendo l'intera immagine in zone e leggendo sequenzialmente le */
   /* varie zone                                                           */
   /* La stessa immagine verra' letta prima lungo X poi lungo Y            */

   /* Apertura del modo di lettura dell' immagine                          */
   /* I parametri da passare sono:                                         */
   /* canale (restituito dalla routine di open file)                       */
   /* numero di immagine                                                   */
   /* direzione di lettura                                                 */
   /* pixel iniziale della linea da leggere                                */
   /* pixel finale della linea da leggere                                  */
   /* In questo caso il primo campione della linea viene letto nel         */
   /*                pixel 0 mentre l'ultimo nella imagewidth-1            */
   /* Dato che si legge lungo X, la posizione in pixel equivale alla       */
   /* colonna della matrice che rappresenta l'immagine                     */

#ifdef __PLAPLA__
   printf("\n \n Lettura immagine lungo X\n");
#endif
   if( argc > 3 ) {
      printf("\n All the Image\n");
      column_start = 0; column_stop = bpar.imagewidth - 1;
      row_start = 0; row_stop = bpar.imagelength - 1;
   }
   else {
      printf("\n Start Column(>=0): ");
      scanf("%d", &column_start);
      if( column_start < 0 ) {
	 column_start = 0;
      }
      printf(" Stop Column(<=%0d): ", bpar.imagewidth-1);
      scanf("%d", &column_stop);
      if( column_stop >= bpar.imagewidth ) {
	 column_stop = bpar.imagewidth - 1;
      }

      printf(" Start Row(>=0): ");
      scanf("%d", &row_start);
      if( row_start < 0 ) {
	 row_start = 0;
      }
      printf(" Stop Row(<=%0d): ", bpar.imagelength-1);
      scanf("%d", &row_stop);
      if( row_stop >= bpar.imagelength ) {
	 row_stop = bpar.imagelength - 1;
      }
   }
   TIFSIP_open_line(channel,image,'x',column_start,column_stop,&status_code);
   ERRSIM_on_err_goto_exit( status_code );

   /* Lettura dell' immagine per linee                                     */
   /* I parametri da passare sono:                                         */
   /* canale (restituito dalla routine di open file)                       */
   /* numero di immagine                                                   */
   /* numero della linea                                                   */
   /* indirizzo del puntatore (convertito in void *) al primo sample del   */
   /* buffer che conterrra' la linea                                       */

   pixsize = (bpar.bitspersample[0]/8)*bpar.sampleperpixel;
   pixno = (column_stop-column_start+1);
   line_no = (row_stop-row_start+1);

   /* Lettura dell' immagine */
   if( argc > 2) {
      strcpy( nameout, argv[2] );
      printf("\n\b Writing to %s(%0dx%0d)", nameout, pixno, line_no);
   }
   else {
      printf("\n\n Enter output file(%0dx%0d): ", 
			 pixno, line_no);   
					    /* Nome del file che verra' scritto */
      scanf("%s", nameout);
   }

   size = (pixno * line_no * pixsize)/1024;
   FILSIP_open( nameout, "wb", size, &fout, &status_code );
   ERRSIM_on_err_goto_exit( status_code );

   for(line=row_start;line<=row_stop;line++) {

      TIFSIP_read_line(channel,image,line,&imgline,&status_code);
      ERRSIM_on_err_goto_exit( status_code );

      fwrite( imgline, pixsize, pixno, fout);

#ifdef __PLAPLA__
      printf("\n");
      for( pixel=0; pixel<(column_stop - column_start + 1); pixel++) {
         for( sample=0; sample<bpar.sampleperpixel; sample++) {
            printf("%d ", pixel*bpar.sampleperpixel+sample);
            switch ( bpar.sampleformat[ 0 ] ){
               case 1:
                  switch( bpar.bitspersample[ 0 ] ){
                     case 8:
                        printf("%d ",
                  ((UINTx1 *) imgline)[ pixel*bpar.sampleperpixel+sample] );
                        break;
                     case 16:
                        printf("%d ",
                  ((UINTx2 *) imgline)[ pixel*bpar.sampleperpixel+sample] );
                        break;
                     case 32:
                        printf("%d ",
                  ((UINTx4 *) imgline)[ pixel*bpar.sampleperpixel+sample] );
                        break;
                  }
                  break;
               case 2:
                  switch( bpar.bitspersample[ 0 ] ){
                     case 8:
                        printf("%d ",
                  ((INTx1 *) imgline)[ pixel*bpar.sampleperpixel+sample] );
                        break;
                     case 16:
                        printf("%d ",
                  ((INTx2 *) imgline)[ pixel*bpar.sampleperpixel+sample] );
                        break;
                     case 32:
                        printf("%d ",
                  ((INTx4 *) imgline)[ pixel*bpar.sampleperpixel+sample] );
                        break;
                  }
                  break;
               case 3:
                  printf("\n Type not allowed");
                  exit( 1 );
               case 4:
                  printf("%f ",
                    ((float *) imgline)[ pixel*bpar.sampleperpixel+sample] );
                  break;
            }
         }
         printf("\n");
      }
#endif


   }

   FILSIP_close( &fout, &status_code );
   ERRSIM_on_err_goto_exit( status_code );

   /* Chiusura della lettura dell'immagine                                 */
   /* I parametri da passare sono:                                         */
   /* canale (restituito dalla routine di open file)                       */
   /* numero di immagine                                                   */
   TIFSIP_close_line(channel,image,&status_code);
   ERRSIM_on_err_goto_exit( status_code );

#ifdef __PLAPLA__
   /* Ora si legge lungo Y quindi la posizione in pixel e'                 */
   /* equivalente alla riga della matrice che rappresenta l'immagine       */
   /* Lettura dell' immagine per linee                                     */
   printf("\n \n Lettura immagine lungo Y\n");
   printf("Start(>=0): "); 
   scanf("%d", &start);
   printf("Stop(<%0d): ", bpar.imagelength);
   scanf("%d", &stop);
 
   /* Apertura del modo di lettura dell' immagine                          */
   TIFSIP_open_line(channel,image,'y',start,stop,&status_code);
   ERRSIM_on_err_goto_exit( status_code );

   pixsize = (bpar.bitspersample[0]/8)*bpar.sampleperpixel;
   pixno = (stop-start+1);

   printf("\n \n Enter output file(%0dx%0d): ", pixno,bpar.imagewidth);   /* Nome del file che verra' scritto */
   scanf("%s",&nameout);

   size = (pixno * line_no * pixsize)/1024;
   FILSIP_open( nameout, "wb", size, &fout, &status_code );
   ERRSIM_on_err_goto_exit( status_code );

   for(line=0;line<bpar.imagewidth;line++) {
      TIFSIP_read_line(channel,image,line,&imgline,&status_code);
      ERRSIM_on_err_goto_exit( status_code );
      switch (bpar.sampleformat[0]) {
         case 1:
            fwrite((UINTx1 *) imgline, pixsize, pixno, fout);
            break;
         case 2:
            fwrite((INTx2 *) imgline, pixsize, pixno, fout);
            break;
         case 3:
            printf("\n Type not allowed");
            exit(1);
         case 4:
            fwrite((float *) imgline, pixsize, pixno, fout);
            break; 
      }
   }

   FILSIP_close( &fout, &status_code );
   ERRSIM_on_err_goto_exit( status_code );

   /* Chiusura della lettura dell'immagine                                 */
   TIFSIP_close_line(channel,image,&status_code);
   ERRSIM_on_err_goto_exit( status_code );
#endif

#ifdef __PLAPLA__
/* ==========================================================================
   Read the block of rows
   ========================================================================== */
   printf( "\n\n Test the read_block by rows");

   pixsize = ( sizeof( UINTx2 ) ) * bpar.sampleperpixel;
   pixno = ( column_stop - column_start + 1 );
   line_no = ( row_stop - row_start + 1 );

   TIFSIP_open_line( channel, image, 'x', column_start, column_stop,
                     &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Allocate the necessary memory
   ========================================================================== */
   if ( ( block = (UINTx2 **)
             MEMSIP_alloc( (size_t)(line_no*sizeof(UINTx2 *) ) ) ) == NULL )
      ERRSIM_set_error( &status_code, ERRSID_TIFS_memory_alloc_failure, "" );

   for ( i=0; i<line_no; i++ ) {
      block[ i ] = NULL;
      if ( ( block[ i ] = (UINTx2 *)
                MEMSIP_alloc( (size_t)(pixno*pixsize ) ) ) == NULL )
         ERRSIM_set_error( &status_code, ERRSID_TIFS_memory_alloc_failure, "" );
   }

   TIFSIP_read_block( channel, image, row_start, row_stop, DATA_TYPE_UINTx2,
                      (void **)block, &status_code );
   ERRSIM_on_err_goto_exit( status_code );

   TIFSIP_close_line( channel, image, &status_code );
   ERRSIM_on_err_goto_exit( status_code );

   printf( "\n\n Enter output file(%0dx%0d): ", pixno, line_no );
   scanf( "%s", &nameout );

   size = (pixno * line_no * pixsize)/1024;
   FILSIP_open( nameout, "wb", size, &fout, &status_code );
   ERRSIM_on_err_goto_exit( status_code );


   for ( line=0; line<line_no; line++ ) {
      fwrite( block[ line ], pixsize, pixno, fout );
   }

   FILSIP_close( &fout, &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Free the allocated memory
   ========================================================================== */
   for ( i=0; i<line_no; i++ ) MEMSIP_free( &(block[ i ]) );
   MEMSIP_free( &block );

/* ==========================================================================
   Read columns blocks
   ========================================================================== */
   printf( "\n\n Test the read_block by columns");

   TIFSIP_open_line( channel, image, 'y', row_start, row_stop,
                     &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Allocate the necessary memory
   ========================================================================== */
   if ( ( block = (UINTx2 **)
             MEMSIP_alloc( (size_t)(line_no*sizeof(UINTx2 *) ) ) ) == NULL )
      ERRSIM_set_error( &status_code, ERRSID_TIFS_memory_alloc_failure, "" );

   for ( i=0; i<line_no; i++ ) {
      block[ i ] = NULL;
      if ( ( block[ i ] = (UINTx2 *)
                MEMSIP_alloc( (size_t)(pixno*pixsize ) ) ) == NULL )
         ERRSIM_set_error( &status_code, ERRSID_TIFS_memory_alloc_failure, "" );
   }

   TIFSIP_read_block( channel, image, column_start, column_stop,
                      DATA_TYPE_UINTx2, (void **)block, &status_code );
   ERRSIM_on_err_goto_exit( status_code );

   TIFSIP_close_line( channel, image, &status_code );
   ERRSIM_on_err_goto_exit( status_code );

   printf( "\n\n Enter output file(%0dx%0d): ", pixno, line_no );
   scanf( "%s", &nameout );

   fout = fopen( nameout, "wb" );

   for ( line=0; line<line_no; line++ ) {
      fwrite( block[ line ], pixsize, pixno, fout );
   }

   FILSIP_close( &fout, &status_code );
   ERRSIM_on_err_goto_exit( status_code );
#endif

   /* Chisura del file                                                     */
   /* Il parametro da passare e':                                          */
   /* canale (restituito dalla routine di open file)                       */
  
   TIFSIP_close_tiff(channel, &status_code);
   ERRSIM_on_err_goto_exit( status_code );
   
error_exit:;

#ifdef __PLAPLA__
/* ==========================================================================
   Free the allocated valiables
   ========================================================================== */
   if ( block != NULL ) {
      for ( i=0; i<line_no; i++ )
         if ( block[ i ] != NULL ) MEMSIP_free( &(block[ i ]) );

      MEMSIP_free( &block );
   }
#endif

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                           status_code, 
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown(  proc_class,
                                 &log_status_code );


}/* TIFS_XREA_main */
