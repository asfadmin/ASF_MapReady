/* ==========================================================================
   $MODULE_HEADER

      $NAME              COOR_CONV

      $FUNCTION		 This module contains the procedures to convert the
			 coordinates from the various coordinates reference
			 systems that are used in SAR Toolbox

      $ROUTINE           COORPP_CONV_EllipsoidInit
			 COORIP_CONV_Init
                         COORIP_CONV_RangeAndAnglesEval
			 COORIP_CONV_SlantRangeEval
                         COORIP_CONV_SatPosition
			 COORPP_CONV_SplineFirstDeriv
			 COORIP_CONV_rc_en
			 COORPP_CONV_en_rc
			 COORPP_CONV_llh_xyz
			 COORPP_CONV_xyz_llh
			 COORPP_CONV_llh_en
			 COORPP_CONV_en_llh
			 COORIP_CONV_rc_xyz
			 COORIP_CONV_xyz_rc
			 COORIP_CONV_rc_llh
			 COORIP_CONV_llh_rc
                         COORPP_CONV_Interpolator
                         COORPP_CONV_FirstDeriv

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       19-JUN-97     MC       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>
#include <math.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include SRVS_INTF_H
#include IANN_INTF_H
#include COOR_INTF_H
#include COOR_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_EllipsoidInit

        $TYPE	      PROCEDURE

        $INPUT        imanum  : number of the image among the other in the
				tool

        $MODIFIED     NONE

        $OUTPUT       NONE
 
        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
						  image annotations
		      COORIV_conv[imanum]	: the structure with all
						  the global variables that
						  the coordinates conversions
						  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow

        $DESCRIPTION  This procedure initializes the variables needed in the
		      coordinates conversions that are function of the
		      ellipsoid semiaxes

        $WARNING      

   $EH
   ========================================================================== */
void COORPP_CONV_EllipsoidInit
			(/*IN    */ INTx4                imanum,
			 /*   OUT*/ ERRSIT_status	*status_code )
{
   const ERRSIT_proc_name routine_name = "COORPP_CONV_EllipsoidInit";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double		  a2;
   double                 b2;
   double                 np;
   double                 np2;
   double                 np3;
   double                 np4;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Evaluate the ellipsoid variables
   ========================================================================== */
   a2 = IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m *
      IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m;
   b2 = IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m *
      IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m;

/* ==========================================================================
   Flatness evaluation
   ========================================================================== */
   COORIV_conv[ imanum ].Flatness =
    (double)( IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m -
	      IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m ) /
    (double)IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m;

/* ==========================================================================
   Eccentricity evaluation
   ========================================================================== */
   COORIV_conv[ imanum ].Eccentricity_2 = ( a2 - b2 ) / a2;
   COORIV_conv[ imanum ].Eccentricity_2p = ( a2 - b2 ) / b2;
   COORIV_conv[ imanum ].Eccentricity_1 = sqrt( COORIV_conv[
      imanum ].Eccentricity_2 );

/* ==========================================================================
   East North coordinates conversions utility variables
   ========================================================================== */
   COORIV_conv[ imanum ].np = COORIV_conv[ imanum ].Flatness /
      ( 2. - COORIV_conv[ imanum ].Flatness );

   np2 = POW( COORIV_conv[ imanum ].np, 2. );
   np3 = POW( COORIV_conv[ imanum ].np, 3. );
   np4 = POW( COORIV_conv[ imanum ].np, 4. );

   COORIV_conv[ imanum ].a0 = 1.0 + ( np2 / 4.0 ) + ( np4 / 64.0 );
   COORIV_conv[ imanum ].a2 = (double)( 3.0 / 2.0 ) *
      ( COORIV_conv[ imanum ].np - np3 / 8.0 );
   COORIV_conv[ imanum ].a4 = (double)( 15.0 / 16.0 ) *
      ( np2 - np4 / 4.0 );
   COORIV_conv[ imanum ].a6 = (double)( 35.0 / 48.0 ) * np3;
   COORIV_conv[ imanum ].a8 = (double)( 315.0 /512.0 ) * np4;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* COORPP_CONV_EllipsoidInit */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_Init

        $TYPE	      PROCEDURE

        $INPUT        imanum  : number of the image among the other in the
                                tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_bad_param_annot

        $DESCRIPTION  This procedure initialize the COORIV_conv[imanum]
		      structure for all the coordinates conversions that could
		      be made on the product <imanum>

        $WARNING      The procedure IANNIP_GETP_GetImageAnnot must be called
		      before to call this

   $EH
   ========================================================================== */
void COORIP_CONV_Init
			(/*IN    */ INTx4                imanum,
			 /*   OUT*/ ERRSIT_status	*status_code )
{
   const ERRSIT_proc_name routine_name = "COORIP_CONV_Init";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   IANNIT_ImageAnnot     *ImgAnno;
   COORIT_conv           *DataConv;
   char                   tag_num[ LDEFID_char_line ] = "";
   UINTx1                 proj_descr = 0;
   UINTx4                 i, j;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Check if imanum has tag for coordinate convertion
   ========================================================================== */
   if( IANNIV_ImageAnnot[ imanum ].MapProjectionType == IANNIE_proj_undef ) {
      ERRSIM_set_error( status_code,
                        ERRSID_COOR_conv_not_allowed,
                        "Map Projection tag not found" );
   }
   else {
      proj_descr = ((UINTx1) IANNIV_ImageAnnot[ imanum ].MapProjectionType) -
                   1;
   }

   for ( j=1;j<=IANNIC_coorconv_necessary_tag[ proj_descr ][ 0 ];j++ ) {

      /* not found tags */
      for ( i=0; ((IANNIV_NotFoundTags[ imanum ][ i ] != 0) || 
                   (i > IANNID_ImageAnnotMaxNumber)); 
            i++ ) {
         if ( IANNIV_NotFoundTags[ imanum ][ i ] ==
              IANNIC_coorconv_necessary_tag[ proj_descr ][ j ] ) {
            sprintf( tag_num, "%u not found",
               IANNIC_coorconv_necessary_tag[ proj_descr ][ j ]);
            ERRSIM_set_error( status_code, ERRSID_COOR_conv_not_allowed,
                              tag_num );
         }
      }

      /* invalid tags */
      for ( i=0; ((IANNIV_InvalidTags[ imanum ][ i ] != 0) || 
                   (i > IANNID_ImageAnnotMaxNumber)); 
            i++ ) {
         if ( IANNIV_InvalidTags[ imanum ][ i ] == 
              IANNIC_coorconv_necessary_tag[ proj_descr ][ j ] ) {
            sprintf( tag_num, "%u invalid", 
               IANNIC_coorconv_necessary_tag[ proj_descr ][ j ]);
            ERRSIM_set_error( status_code, ERRSID_COOR_conv_not_allowed,
                              tag_num );
         }
      }
   }

/* ==========================================================================
   Reset the structure pointers
   ========================================================================== */
   ImgAnno = ( IANNIV_ImageAnnot + imanum );
   DataConv = ( COORIV_conv + imanum );

/* ==========================================================================
   Ellipsoid objects evaluation
   ========================================================================== */
   COORPP_CONV_EllipsoidInit( imanum, status_code );

   switch ( ImgAnno->MapProjectionType ) {
      case IANNIE_proj_ground:
      case IANNIE_proj_slant: {
	 MATHIT_LLH             LLH_in;
	 double                 dt;
	 double                 tStart;
	 double                 d2_0;
	 double                 d2_1;
	 char                   FirstSTVectDate[ 25 ] = "";
	 INTx2                  Hour;
	 INTx2                  Min;
	 float                  Sec;
	 INTx4                  i;

/* ==========================================================================
   Check the time STVect interval
   ========================================================================== */
	 if ( ImgAnno->STVectIntervalTime_sec == 0. )
	    ERRSIM_set_error( status_code, ERRSID_COOR_bad_param_annot,
			      " STVect time interval null" );

/* ==========================================================================
   Timing section
   ========================================================================== */
	 LDEFIP_DATE_JDate( ImgAnno->ZeroDopplerAzimuthFirstLine_UTC,
			    &tStart, status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
	 tStart *= 86400.0;

	 if ( ImgAnno->MapProjectionType == IANNIE_proj_ground ) {

	    /* PRI or real data */
	    DataConv->imaflg = 1;

	    /* equivalent PRF */
	    DataConv->prf = ImgAnno->EquivalentPulseRepetitionFreq_Hz;
	 }
	 else {

            /* SLC or complex data */
	    DataConv->imaflg = 0;
	    DataConv->prf = ImgAnno->PulseRepetitionFreq_Hz;
	 }

/* ==========================================================================
   Evaluate the cartesian coordinates of the central image point
   ========================================================================== */
	 LLH_in.lat = ImgAnno->CentreGeodeticLat_deg;
	 LLH_in.lon = ImgAnno->CentreGeodeticLon_deg;
	 LLH_in.h = 0.0;
	 COORPP_CONV_llh_xyz ( &LLH_in, imanum, &(DataConv->xyz_C),
			       status_code );
	 ERRSIM_on_err_goto_exit( *status_code);

/* ==========================================================================
   Evaluate the first image time WRT the first state vector time
   ========================================================================== */
	 Hour = (INTx2)(IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds / 3600.);
	 Min = (INTx2)(( (float)(IANNIV_ImageAnnot[
	    imanum ].FirstSTVectSeconds / 3600.) - (float)Hour ) * 60);
	 Sec = IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds -
	    (float)(Hour * 3600.) - (float)(Min * 60.);

         if( Sec < 1.e-3 ) {
            Sec = 0.0;
         }

	 /* write the date in a string */
	 sprintf( FirstSTVectDate, "%02d-%3s-%4d %02d:%02d:%06.3f",
		     IANNIV_ImageAnnot[ imanum ].FirstSTVectDay,  /* day */
		     LDEFIC_MonName[ ( IANNIV_ImageAnnot[
			imanum ].FirstSTVectMonth - 1 ) ],        /* month */
		     IANNIV_ImageAnnot[ imanum ].FirstSTVectYear, /* Year */
		     Hour, Min, Sec );

	 /* evaluate the MJD of the date */
	 LDEFIP_DATE_JDate( FirstSTVectDate, &dt, status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
	 dt *= 86400.0;

	 DataConv->dt = tStart-dt;

	 for ( i=0;i<ImgAnno->NStateVectors;i++ )
	   DataConv->ST_time[ i ] = ImgAnno->STVectIntervalTime_sec * i;

/* ==========================================================================
   Compute the second derivative of the STVect position and velocity
   ========================================================================== */
	 /* X STVect */
	 MATHIP_SPLN_spline( DataConv->ST_time, ImgAnno->X_STVec_m,
			     ImgAnno->NStateVectors,
			     ImgAnno->VX_STVec_m_sec[ 0 ],
			     ImgAnno->VX_STVec_m_sec[ImgAnno->NStateVectors-1 ],
                             DataConv->X_STVec_2D, status_code );
	 ERRSIM_on_err_goto_exit( *status_code);

	 /* Y STVect */
	 MATHIP_SPLN_spline( DataConv->ST_time, ImgAnno->Y_STVec_m,
			     ImgAnno->NStateVectors,
	                     ImgAnno->VY_STVec_m_sec[ 0 ],
			     ImgAnno->VY_STVec_m_sec[ImgAnno->NStateVectors-1 ],
			     DataConv->Y_STVec_2D, status_code );
	 ERRSIM_on_err_goto_exit( *status_code);

	 /* Z STVect */
	 MATHIP_SPLN_spline( DataConv->ST_time, ImgAnno->Z_STVec_m,
			     ImgAnno->NStateVectors,
			     ImgAnno->VZ_STVec_m_sec[ 0 ],
			     ImgAnno->VZ_STVec_m_sec[ImgAnno->NStateVectors-1],
			     DataConv->Z_STVec_2D, status_code );
	 ERRSIM_on_err_goto_exit( *status_code);

/* ==========================================================================
   Evaluate the first derivative of the velocity
   ========================================================================== */
	 /* X Velocity STVect */
	 d2_0 = ( ImgAnno->VX_STVec_m_sec[ 1 ] - ImgAnno->VX_STVec_m_sec[ 0 ] )
		 / ImgAnno->STVectIntervalTime_sec;
	 d2_1 = ( ImgAnno->VX_STVec_m_sec[ ImgAnno->NStateVectors - 1 ] -
	    ImgAnno->VX_STVec_m_sec[ ImgAnno->NStateVectors - 2 ] )
		 / ImgAnno->STVectIntervalTime_sec;

	 MATHIP_SPLN_spline ( DataConv->ST_time, ImgAnno->VX_STVec_m_sec,
			      ImgAnno->NStateVectors, d2_0, d2_1,
			      DataConv->VX_STVec_2D, status_code );
	 ERRSIM_on_err_goto_exit( *status_code);

	 /* Y Velocity STVect */
	 d2_0 = ( ImgAnno->VY_STVec_m_sec[ 1 ] - ImgAnno->VY_STVec_m_sec[ 0 ] )
		 / ImgAnno->STVectIntervalTime_sec;
	 d2_1 = ( ImgAnno->VY_STVec_m_sec[ ImgAnno->NStateVectors - 1 ] -
	    ImgAnno->VY_STVec_m_sec[ ImgAnno->NStateVectors - 2 ] )
		 / ImgAnno->STVectIntervalTime_sec;

	 MATHIP_SPLN_spline( DataConv->ST_time, ImgAnno->VY_STVec_m_sec,
			     ImgAnno->NStateVectors, d2_0, d2_1,
			     DataConv->VY_STVec_2D, status_code );
	 ERRSIM_on_err_goto_exit( *status_code);

	 /* Z Velocity STVect */
	 d2_0 = ( ImgAnno->VZ_STVec_m_sec[ 1 ] - ImgAnno->VZ_STVec_m_sec[ 0 ] )
		 / ImgAnno->STVectIntervalTime_sec;
	 d2_1 = ( ImgAnno->VZ_STVec_m_sec[ ImgAnno->NStateVectors - 1 ] -
	    ImgAnno->VZ_STVec_m_sec[ ImgAnno->NStateVectors - 2 ] )
		 / ImgAnno->STVectIntervalTime_sec;

	 MATHIP_SPLN_spline( DataConv->ST_time, ImgAnno->VZ_STVec_m_sec,
			     ImgAnno->NStateVectors, d2_0, d2_1,
			     DataConv->VZ_STVec_2D, status_code );
	 ERRSIM_on_err_goto_exit( *status_code);

      }
      break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* COORIP_CONV_Init */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_RangeAndAnglesEval

        $TYPE	      PROCEDURE

        $INPUT        imanum          : image ID
                      TLRow           : top left row AoI coordinate
                      TLCol           : top left col AoI coordinate
                      NRow            : number of rows of the AoI
                      NCol            : number of columns of the AoI

        $MODIFIED     NONE

        $OUTPUT       look_angle      : array to fill with the columns dependent
                                        look angles
                      incidence_angle : array to fill with the columns dependent
                                        incidence angles
                      slant_range     : array to fill with the columns dependent
                                        slant range
 
        $GLOBAL       IANNIV_ImageAnnot : image annotations INFO structure
                      COORIV_conv       : coordinates conversions structure

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
                      ERRSID_COOR_out_of_range

        $DESCRIPTION  This procedure evaluates the slant range, the incidence
                      angle and the look angle values for the central row of
                      the AoI of the image defined by its ID <imanum>

        $WARNING      THE COORDINATES CONVERSIONS MUST BE INITIALIZED BEFORE

        $PDL          - Evaluates the central row of the image
                      - Evaluates its value in the full frame reference
                        system
                      - Evaluates the time corresponding to the row
                      - Evaluates the spacecraft position at that time
                      - Loop over the columns in the AoI
                            - Evaluates the column coordinate in the full frame 
                              reference system
                            - Evaluates the slant range corresponding to that
                              column
                            - Evaluates the target position
                            - Evaluates the earth radius of curvature
                            - Evaluates the spacecraft position range
                            - Evaluates the incidence angle at the current
                              column
                            - Evaluates the look angle at the current column
                            - Rescale the incidence angle from radians to
                              degrees
                      - End Loop

   $EH
   ========================================================================== */
void COORIP_CONV_RangeAndAnglesEval
			(/*IN    */ UINTx1               imanum,
			 /*IN    */ UINTx4               TLRow,
			 /*IN    */ UINTx4               TLCol,
			 /*IN    */ UINTx4               NRow,
			 /*IN    */ UINTx4               NCol,
                         /*   OUT*/ float               *look_angle,
                         /*   OUT*/ float               *incidence_angle,
                         /*   OUT*/ float               *slant_range,
			 /*   OUT*/ ERRSIT_status	*status_code )
{
   const ERRSIT_proc_name routine_name = "COORIP_CONV_RangeAndAnglesEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   MATHIT_XYZ             Spacecraft;
   MATHIT_XYZ             SpVers;
   MATHIT_XYZ             Target;
   MATHIT_XYZ             SpTa;
   MATHIT_XYZ             norm;
   MATHIT_LLH             p_llh;
   MATHIT_RC              point1;
   MATHIT_RC              point2;
   double                 t;
   double                 acosarg;
   double                 tmpDouble;
   INTx4                  col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image ID
   ========================================================================== */
   if ( imanum > IANNID_NIMAMAX ) {
      ERRSIM_set_error ( status_code, ERRSID_COOR_imanum_not_allow, "" );
   }

/* ==========================================================================
   Check the number of rows and columns
   ========================================================================== */
   if ( NRow > IANNIV_ImageAnnot[ imanum ].ImageLength ) {
      ERRSIM_set_error ( status_code, ERRSID_COOR_out_of_range,
                         "in the row direction" );
   }
   if ( ( NCol == 0 ) || ( NCol > IANNIV_ImageAnnot[ imanum ].ImageWidth ) ) {
            ERRSIM_set_error ( status_code, ERRSID_COOR_out_of_range,
                         "in the column direction" );
   }

/* ==========================================================================
   Evaluate the central row in the image
   ========================================================================== */
   point1.row = (double)TLRow + (double)NRow / 2.;
   point2.row = (double)TLRow + (double)NRow / 2.;

/* ==========================================================================
   Transform it in the full frame image
   ========================================================================== */
   point1.row = IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow +
      point1.row / IANNIV_ImageAnnot[ imanum ].YScalingFactor;

/* ==========================================================================
   Time corresponding to the given row
   ========================================================================== */
   t = COORIV_conv[ imanum ].dt + point1.row / COORIV_conv[ imanum ].prf;

/* ==========================================================================
   Evaluate the spacecraft position
   ========================================================================== */

   /* X state vector */
   COORPP_CONV_Interpolator ( COORIV_conv[ imanum ].ST_time,
                              IANNIV_ImageAnnot[ imanum ].X_STVec_m,
                              IANNIV_ImageAnnot[ imanum ].NStateVectors, t,
                              COORIV_conv[ imanum ].X_STVec_2D,
                              &Spacecraft.x, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* Y state vector */
   COORPP_CONV_Interpolator ( COORIV_conv[ imanum ].ST_time,
                              IANNIV_ImageAnnot[ imanum ].Y_STVec_m,
                              IANNIV_ImageAnnot[ imanum ].NStateVectors, t,
                              COORIV_conv[ imanum ].Y_STVec_2D,
                              &Spacecraft.y, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* Z state vector */
   COORPP_CONV_Interpolator ( COORIV_conv[ imanum ].ST_time,
                              IANNIV_ImageAnnot[ imanum ].Z_STVec_m,
                              IANNIV_ImageAnnot[ imanum ].NStateVectors, t,
                              COORIV_conv[ imanum ].Z_STVec_2D,
                              &Spacecraft.z, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Loop over the columns
   ========================================================================== */
   for ( col=0; col<NCol; col++ ) {

      SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Column in the row
   ========================================================================== */
      point1.col = (double)(TLCol + col);
      point2.col = point1.col;

/* ==========================================================================
   Evaluate the column coordinate in the full frame image
   ========================================================================== */
      point1.col = IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol +
         point1.col / IANNIV_ImageAnnot[ imanum ].XScalingFactor;

/* ==========================================================================
   Evaluate the slant range
   ========================================================================== */
      COORIP_CONV_SlantRangeEval ( point1.col, imanum, &tmpDouble,
                                   status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      slant_range[ col ] = (float) tmpDouble;

/* ==========================================================================
   Evaluate the target position
   ========================================================================== */
      COORIP_CONV_rc_xyz ( &point2, imanum, &Target, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the target position in geodetic coordinates
   ========================================================================== */
      COORPP_CONV_xyz_llh ( &Target, imanum, &p_llh, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the normal to the ellipsoid in the target position
   ========================================================================== */
      p_llh.lat *= DEGTORAD;
      p_llh.lon *= DEGTORAD;
      norm.x = cos ( p_llh.lat ) * cos ( p_llh.lon );
      norm.y = cos ( p_llh.lat ) * sin ( p_llh.lon );
      norm.z = sin ( p_llh.lat );
      MATHIP_STYP_XYZVers ( norm, &norm, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the satellite target versor
   ========================================================================== */
      MATHIP_STYP_XYZSubt ( Spacecraft, Target, &SpTa, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      MATHIP_STYP_XYZVers ( SpTa, &SpTa, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the incidence angle
   ========================================================================== */
      MATHIP_STYP_XYZScalProd ( SpTa, norm, &acosarg, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      incidence_angle[ col ] = (float) (ACOS ( acosarg ) * RADTODEG);

/* ==========================================================================
   Evaluate the spacecraft versor
   ========================================================================== */
      MATHIP_STYP_XYZVers ( Spacecraft, &SpVers, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the look angle
   ========================================================================== */
      MATHIP_STYP_XYZScalProd ( SpTa, SpVers, &acosarg, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      look_angle[ col ] = (float)( ACOS ( acosarg ) * RADTODEG);
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* COORIP_CONV_RangeAndAnglesEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_SlantRange

        $TYPE	      PROCEDURE

        $INPUT        col	 : input column at which the slant range must be
				   evaluate
		      imanum	 : number of the image among the other in the
                                   tool

        $MODIFIED     NONE

        $OUTPUT       SlantRange : slant range at the given column in meters
 
        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_unhandled_projection

        $DESCRIPTION  This procedure evaluates the slant range at a given
		      column

	$PDL	      - Switch between the image type
		            - Evaluate the spacing
			    - Evaluate the actual column
			    - Evaluate the slant range
		      - End switch

   $EH
   ========================================================================== */
void COORIP_CONV_SlantRangeEval
			(/*IN    */ double               col,
			 /*IN    */ INTx4                imanum,
			 /*   OUT*/ double              *SlantRange,
			 /*   OUT*/ ERRSIT_status	*status_code )
{
   const ERRSIT_proc_name routine_name = "COORIP_CONV_SlantRangeEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Switch on the image projection
   ========================================================================== */
   switch ( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {
      case IANNIE_proj_ground: {
	 double                 x;
	 double                 sc;

/* ==========================================================================
   Switch over the different processors
   ========================================================================== */
         switch ( IANNIV_ImageAnnot[ imanum ].ProcessorName ) {
            case IANNIE_sproc_VMP:

/* ==========================================================================
   Evaluate the distance corresponding to the given column
   ========================================================================== */
               x = col * IANNIV_ImageAnnot[ imanum ].PixelSpacing_m *
                  IANNIV_ImageAnnot[ imanum ].XScalingFactor;

/* ==========================================================================
   Interpolate the slant range
   ========================================================================== */
               POLY( x, IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree,
                     IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff, sc );

/* ==========================================================================
   Slant range evaluation
   ========================================================================== */
               *SlantRange = CVEL / 2. *
                  ( IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec +
	            sc / IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz );
            break;
            case IANNIE_sproc_Bangkok:

/* ==========================================================================
   Evaluate the distance corresponding to the given column
   ========================================================================== */
               x = col * IANNIV_ImageAnnot[ imanum ].PixelSpacing_m *
                  IANNIV_ImageAnnot[ imanum ].XScalingFactor;

/* ==========================================================================
   Interpolate the slant range
   ========================================================================== */
               POLY( x, IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree,
                     IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff, sc );

/* ==========================================================================
   Slant range evaluation
   ========================================================================== */
               *SlantRange = sc +
                  CVEL * IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec / 2.;
            break;
            case IANNIE_sproc_ESAR:

/* ==========================================================================
   Rescale the column index
   ========================================================================== */
               x = col * 1.e-03;

/* ==========================================================================
   Interpolate the slant range
   ========================================================================== */
	       POLY( x, IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree,
                     IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff, sc );

/* ==========================================================================
   Slant range evaluation
   ========================================================================== */
               *SlantRange = CVEL /2. *
                  ( IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec +
	            sc / IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz );
            break;
            default:
               ERRSIM_set_error ( status_code, ERRSID_COOR_proc_name_unknown,
                                  "" );
         }
      }
      break;
      case IANNIE_proj_slant:
	 *SlantRange =
	    CVEL * IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec / 2.0 +
	    IANNIV_ImageAnnot[ imanum ].PixelSpacing_m *
	    IANNIV_ImageAnnot[ imanum ].XScalingFactor *     /* rescale the */
							     /* spacing     */
	    col;
      break;
      default:
	 ERRSIM_set_error( status_code, ERRSID_COOR_unhandled_projection, "" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* COORIP_CONV_SlantRangeEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_SatPosition

        $TYPE	      PROCEDURE

        $INPUT        imanum : image ID
                      row    : row coordinates at which to evaluate the
                               satellite position

        $MODIFIED     NONE

        $OUTPUT       XYZ_out : spacecraft position
                      V_out   : spacecraft velocity 

        $GLOBAL       IANNIV_ImageAnnot : image annotations structure INFO
                      COORIV_conv       : coordinates converions INFO

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
                      ERRSID_COOR_bad_param_annot

        $DESCRIPTION  This procedure evaluates the spacecraft position
                      interpolating the annotated state vectors at the time
                      corresponding to the input row coordinate

        $WARNING      THE COORDINATES CONVERSIONS INITIALIZATION MUST BE DONE
                      BEFORE FOR THE IMAGE

        $PDL          - Checks the image ID
                      - Checks the necessary annotations
                      - Re-scale the row coordinate to the full frame image
                      - Evaluate the corresponding time
                      - Interpolates the spacecraft cartesian position
                      - Interpolates the spacecraft cartesian velocity

   $EH
   ========================================================================== */
void COORIP_CONV_SatPosition
			(/*IN    */ UINTx1               imanum,
                         /*IN    */ double               row,
                         /*   OUT*/ MATHIT_XYZ          *XYZ_out,
                         /*   OUT*/ MATHIT_XYZ          *V_out,
			 /*   OUT*/ ERRSIT_status	*status_code )
{
   const ERRSIT_proc_name routine_name = "COORIP_CONV_SatPosition";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double                 t;
   double                 dt;
   double                 tStart;
   double                 d2_0;
   double                 d2_1;
   char                   FirstSTVectDate[ 25 ] = "";
   INTx2                  Hour;
   INTx2                  Min;
   float                  Sec;
   INTx4                  i;
   COORIT_conv            DataConv;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) {
      ERRSIM_set_error ( status_code, ERRSID_COOR_imanum_not_allow, "" );
   }

/* ==========================================================================
   Check the STVects time interval
   ========================================================================== */
   if ( IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec == 0. ) {
      ERRSIM_set_error ( status_code, ERRSID_COOR_bad_param_annot,
                         " STVect time interval null" );
   }

/* ==========================================================================
   Check the number of State Vectors
   ========================================================================== */
   if ( IANNIV_ImageAnnot[ imanum ].NStateVectors < 2 ) {
      ERRSIM_set_error ( status_code, ERRSID_COOR_bad_param_annot,
                         " Insufficient number of State Vectors " );
   }

/* ==========================================================================
   Check the equivalent PRF
   ========================================================================== */
   if ( IANNIV_ImageAnnot[ imanum ].EquivalentPulseRepetitionFreq_Hz == 0. ) {
      ERRSIM_set_error ( status_code, ERRSID_COOR_bad_param_annot,
                         " Equiv. PRF null " );
   }

/* ==========================================================================
   Timing section
   ========================================================================== */
   LDEFIP_DATE_JDate ( IANNIV_ImageAnnot[ imanum
                       ].ZeroDopplerAzimuthFirstLine_UTC, &tStart,
                       status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   tStart *= 86400.0;

/* ==========================================================================
   Evaluate the first image time WRT the first state vector time
   ========================================================================== */
   Hour = (INTx2)(IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds / 3600.);
   Min = (INTx2)(( (float)(
      IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds / 3600.) -
      (float)Hour ) * 60);
   Sec = IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds -
      (float)(Hour * 3600.) - (float)(Min * 60.);

   /* write the date in a string */
   sprintf( FirstSTVectDate, "%02d-%3s-%4d %02d:%02d:%06.3f",
            IANNIV_ImageAnnot[ imanum ].FirstSTVectDay,        /* day */
            LDEFIC_MonName[ ( IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth -
                              1 ) ],                           /* month */
            IANNIV_ImageAnnot[ imanum ].FirstSTVectYear,       /* Year */
            Hour, Min, Sec );

   /* evaluate the MJD of the date */
   LDEFIP_DATE_JDate ( FirstSTVectDate, &dt, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   dt *= 86400.0;

   DataConv.dt = tStart - dt;

   for ( i=0; i<IANNIV_ImageAnnot[ imanum ].NStateVectors; i++ ) {
      DataConv.ST_time[ i ] = IANNIV_ImageAnnot[ imanum
         ].STVectIntervalTime_sec * i;
   }

/* ==========================================================================
   Compute the second derivative of the STVect position and velocity
   ========================================================================== */
   /* X STVect */
   MATHIP_SPLN_spline ( DataConv.ST_time, IANNIV_ImageAnnot[ imanum ].X_STVec_m,
                        IANNIV_ImageAnnot[ imanum ].NStateVectors,
                        IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[ 0 ],
                        IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[
                           IANNIV_ImageAnnot[ imanum ].NStateVectors-1 ],
                        DataConv.X_STVec_2D, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* Y STVect */
   MATHIP_SPLN_spline ( DataConv.ST_time, IANNIV_ImageAnnot[ imanum ].Y_STVec_m,
                        IANNIV_ImageAnnot[ imanum ].NStateVectors,
                        IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[ 0 ],
                        IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[
                           IANNIV_ImageAnnot[ imanum ].NStateVectors - 1 ],
                        DataConv.Y_STVec_2D, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* Z STVect */
   MATHIP_SPLN_spline ( DataConv.ST_time, IANNIV_ImageAnnot[ imanum ].Z_STVec_m,
                        IANNIV_ImageAnnot[ imanum ].NStateVectors,
                        IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[ 0 ],
                        IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[
                           IANNIV_ImageAnnot[ imanum ].NStateVectors - 1 ],
                        DataConv.Z_STVec_2D, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the first derivative of the velocity
   ========================================================================== */
   /* X Velocity STVect */
   d2_0 = ( IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[ 1 ] -
            IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[ 0 ] ) /
          IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec;
   d2_1 = ( IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[
               IANNIV_ImageAnnot[ imanum ].NStateVectors - 1 ] -
	       IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[
                  IANNIV_ImageAnnot[ imanum ].NStateVectors - 2 ] ) /
          IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec;

   MATHIP_SPLN_spline ( DataConv.ST_time,
                        IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec,
                        IANNIV_ImageAnnot[ imanum ].NStateVectors, d2_0, d2_1,
                        DataConv.VX_STVec_2D, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* Y Velocity STVect */
   d2_0 = ( IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[ 1 ] -
            IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[ 0 ] ) /
          IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec;
   d2_1 = ( IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[
               IANNIV_ImageAnnot[ imanum ].NStateVectors - 1 ] -
               IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[
                  IANNIV_ImageAnnot[ imanum ].NStateVectors - 2 ] ) /
          IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec;

   MATHIP_SPLN_spline ( DataConv.ST_time,
                        IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec,
                        IANNIV_ImageAnnot[ imanum ].NStateVectors, d2_0, d2_1,
                        DataConv.VY_STVec_2D, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* Z Velocity STVect */
   d2_0 = ( IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[ 1 ] -
            IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[ 0 ] ) /
          IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec;
   d2_1 = ( IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[
               IANNIV_ImageAnnot[ imanum ].NStateVectors - 1 ] -
               IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[
                  IANNIV_ImageAnnot[ imanum ].NStateVectors - 2 ] ) /
          IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec;

   MATHIP_SPLN_spline ( DataConv.ST_time,
                        IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec,
                        IANNIV_ImageAnnot[ imanum ].NStateVectors, d2_0, d2_1,
                        DataConv.VZ_STVec_2D, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the row coordinate in the full reference frame
   ========================================================================== */
   row = IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow + row /
      IANNIV_ImageAnnot[ imanum ].YScalingFactor;

/* ==========================================================================
   Evaluate the corresponding time
   ========================================================================== */
   t = DataConv.dt + row /
      IANNIV_ImageAnnot[ imanum ].EquivalentPulseRepetitionFreq_Hz;

/* ==========================================================================
   Spacecraft Position evaluation
   ========================================================================== */

   /* X STVect */
   COORPP_CONV_Interpolator ( DataConv.ST_time,
                              IANNIV_ImageAnnot[ imanum ].X_STVec_m,
                              IANNIV_ImageAnnot[ imanum ].NStateVectors, t,
                              DataConv.X_STVec_2D, &XYZ_out->x,
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* Y STVect */
   COORPP_CONV_Interpolator ( DataConv.ST_time,
                              IANNIV_ImageAnnot[ imanum ].Y_STVec_m,
                              IANNIV_ImageAnnot[ imanum ].NStateVectors, t,
                              DataConv.Y_STVec_2D, &XYZ_out->y,
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* Z STVect */
   COORPP_CONV_Interpolator ( DataConv.ST_time,
                              IANNIV_ImageAnnot[ imanum ].Z_STVec_m,
                              IANNIV_ImageAnnot[ imanum ].NStateVectors, t,
                              DataConv.Z_STVec_2D, &XYZ_out->z,
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Spacecraft Velocity evaluation
   ========================================================================== */

   /* VX STVect */
   COORPP_CONV_Interpolator ( DataConv.ST_time,
                              IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec,
                              IANNIV_ImageAnnot[ imanum ].NStateVectors, t,
                              DataConv.VX_STVec_2D, &V_out->x,
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* VY STVect */
   COORPP_CONV_Interpolator ( DataConv.ST_time,
                              IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec,
                              IANNIV_ImageAnnot[ imanum ].NStateVectors, t,
                              DataConv.VY_STVec_2D, &V_out->y,
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* VX STVect */
   COORPP_CONV_Interpolator ( DataConv.ST_time,
                              IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec,
                              IANNIV_ImageAnnot[ imanum ].NStateVectors, t,
                              DataConv.VZ_STVec_2D, &V_out->z,
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* COORIP_CONV_SatPosition */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_SplineFirstDeriv

        $TYPE         PROCEDURE

        $INPUT        x0      : current abscissa point in which to interpolate
		      n	      : number of abscissa and ordinates elements
		      x	      : array of abscissa
		      y	      : array of ordinates
		      y2      : array with the second derivatives coefficients
			        evaluated by the procedures of initialization of
				SPLINE

        $MODIFIED     NONE

        $OUTPUT       FirstD  : value of the first derivative of the polynomial
			        function evaluated at the point <x0>

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_null_interval

        $DESCRIPTION  This procedure evaluates the first derivative of a generic
		      function evaluated with a spline interpolation

        $WARNING      NONE

        $PDL	      - Evaluate the class of the current abscissa value
		      - Evaluate some ancillary variables
		      - Evaluate the First Derivative

   $EH
   ========================================================================== */
void COORPP_CONV_SplineFirstDeriv
			(/*IN    */ double               x0,
			 /*IN    */ INTx4                n,
			 /*IN    */ double              *x,
			 /*IN    */ double              *y,
			 /*IN    */ double              *y2,
			 /*   OUT*/ double              *FirstD,
			 /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "COORPP_CONV_SplineFirstDeriv";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  pos0;
   INTx4                  pos1;
   double                 dh;
   double                 A;
   double                 B;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Initialize the result
   ========================================================================== */
   *FirstD = 0.;

/* ==========================================================================
   Check the class
   ========================================================================== */
   for ( pos1=0; pos1<n; pos1++ )
      if ( x0< *(x + pos1) ) break;

/* ==========================================================================
   Time out of the range
   ========================================================================== */
   if ( ( pos1 == 0 ) || ( pos1 == n ) )
      ERRSIM_set_error( status_code, ERRSID_COOR_value_out_of_abs, "" );

/* ==========================================================================
   Ancillary variables
   ========================================================================== */
   pos0 = pos1 - 1;
   dh = *(x + pos1 ) - *(x + pos0);

/* ==========================================================================
   Check the dh not null value
   ========================================================================== */
   if ( dh == 0. )
      ERRSIM_set_error( status_code, ERRSID_COOR_null_interval, "" );

/* ==========================================================================
   Coefficients of the SPLINE polynomial
   ========================================================================== */
   A = (*(x + pos1) - x0 ) / dh;
   B = ( x0 - *(x + pos0) ) / dh;

/* ==========================================================================
   Evaluate the First Derivative
   ========================================================================== */
   *FirstD = ( - *(y + pos0) + *(y + pos1) -
                (  *(y2 + pos0) * ( 3.0 * A * A - 1.0 )
                - *(y2 + pos1) * ( 3.0 * B * B - 1.0 )
             ) * dh * dh / 6.0 ) / dh;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

}/* COORPP_CONV_SplineFirstDeriv */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_rc_en

        $TYPE         PROCEDURE

        $INPUT        RC_in   : input ( row, col ) coordinates to convert
		      imanum  : image number among the others in the
				program

        $MODIFIED     NONE

        $OUTPUT       EN_out  : output ( east, north ) UTM or UPS coordinates
				in meters

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations

        $RET_STATUS   ERRSID_COOR_imanum_not_allow

        $DESCRIPTION  This procedure converts a point from a image to East-
		      North coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
		      before all the conversions procedures

   $EH
   ========================================================================== */
void COORIP_CONV_rc_en
                        (/*IN    */ MATHIT_RC           *RC_in,
                         /*IN    */ INTx4                imanum,
                         /*   OUT*/ MATHIT_EN           *EN_out,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "COORIP_CONV_rc_en";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;
   
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Evaluate the output
   ========================================================================== */
   EN_out->east = IANNIV_ImageAnnot[ imanum ].TopLeftEast_m +
      ( IANNIV_ImageAnnot[ imanum ].PixelSpacing_m * RC_in->col );
   EN_out->north = IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m -
      ( IANNIV_ImageAnnot[ imanum ].LineSpacing_m * RC_in->row );

error_exit:;

   ERRSIM_close_routine( routine_name,
                         &process_flag,
                         *status_code, 
                         &log_status_code );

}/* COORIP_CONV_rc_en */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_en_rc

        $TYPE	      PROCEDURE

        $INPUT        EN_in   : input ( east, north ) UTM or UPS coordinates
			        in meters
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       RC_out  : output ( row, col ) coordinates in pixel

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
                                                  image annotations

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_bad_param_annot

        $DESCRIPTION  This procedure converts a point from East-North to
		      image coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
void COORPP_CONV_en_rc
                        (/*IN    */ MATHIT_EN           *EN_in,
                         /*IN    */ INTx4                imanum,
                         /*   OUT*/ MATHIT_RC           *RC_out,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "COORPP_CONV_en_rc";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Evaluate the output
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ imanum ].PixelSpacing_m > 0 ) &&
        ( IANNIV_ImageAnnot[ imanum ].LineSpacing_m > 0 ) ) {

      RC_out->col = (EN_in->east - IANNIV_ImageAnnot[ imanum ].TopLeftEast_m )
             /   IANNIV_ImageAnnot[ imanum ].PixelSpacing_m  ;

      RC_out->row = (IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m - EN_in->north)
             /   IANNIV_ImageAnnot[ imanum ].LineSpacing_m ;
   }
   else {
      ERRSIM_set_error( status_code, ERRSID_COOR_bad_param_annot,
			" Pixel ( Line ) spacing null" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* COORPP_CONV_en_rc */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_llh_xyz

        $TYPE	      PROCEDURE

        $INPUT        LLH_in  : input ( lat, lon, h ) geodetic coordinates
			        in degree ( meters )
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       XYZ_out : output cartesian ( x, y, z ) coordinates in
			        meters

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow

        $DESCRIPTION  This procedure converts a point from geodetic to
		      cartesian coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
void COORPP_CONV_llh_xyz
			(/*IN    */ MATHIT_LLH          *LLH_in,
			 /*IN    */ INTx4                imanum,
			 /*   OUT*/ MATHIT_XYZ          *XYZ_out,
		         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "COORPP_CONV_llh_xyz";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double		  Radius;
   double		  lat_rad;
   double                 lon_rad;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Convert the angle from degrees to radiants
   ========================================================================== */
   lat_rad = LLH_in->lat * DEGTORAD;
   lon_rad = LLH_in->lon * DEGTORAD;

/* ==========================================================================
   Evaluate the radius of curvature
   ========================================================================== */
   Radius = IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m / 
      sqrt( 1. - COORIV_conv[ imanum ].Eccentricity_2 * sin(lat_rad) *
	    sin(lat_rad) );

/* ==========================================================================
   Evaluates the output
   ========================================================================== */
   XYZ_out->x = ( Radius + LLH_in->h ) * cos( lat_rad ) * cos( lon_rad );
   XYZ_out->y = ( Radius + LLH_in->h ) * cos( lat_rad ) * sin( lon_rad );
   XYZ_out->z = ( Radius * ( 1. - COORIV_conv[ imanum ].Eccentricity_2 ) +
		  LLH_in->h ) * sin( lat_rad );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* COORPP_CONV_llh_xyz */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_xyz_llh

        $TYPE         PROCEDURE

        $INPUT        XYZ_in  : input cartesian ( x, y, z ) coordinates in
			        meters
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       LLH_out : output ( lat, lon, h ) geodetic coordinates
                                in degree ( meters )

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow

        $DESCRIPTION  This procedure converts a point from cartesian to
		      geodetic coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
void COORPP_CONV_xyz_llh
                        (/*IN    */ MATHIT_XYZ          *XYZ_in,
			 /*IN    */ INTx4                imanum,
			 /*   OUT*/ MATHIT_LLH          *LLH_out,
			 /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "COORPP_CONV_xyz_llh";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double		  dist;
   double		  tau;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Evaluate the ancillary variables
   ========================================================================== */
   dist = sqrt( XYZ_in->x * XYZ_in->x  + XYZ_in->y * XYZ_in->y );
   tau = atan2( ( XYZ_in->z * IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m ),
	        ( dist * IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m ) );

/* ==========================================================================
   Evaluate the output
   ========================================================================== */
   LLH_out->lat = atan2( ( XYZ_in->z + COORIV_conv[ imanum ].Eccentricity_2p *
			    IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m *
			    POW( sin( tau ), 3.) ),
			  ( dist - COORIV_conv[ imanum ].Eccentricity_2 *
			     IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m *
			     POW( cos( tau ), 3. ) ) );

   LLH_out->lon = atan2( XYZ_in->y, XYZ_in->x );

   LLH_out->h = dist / cos( LLH_out->lat ) -
      IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m /
      sqrt( 1. - COORIV_conv[ imanum ].Eccentricity_2 * sin( LLH_out->lat ) *
	    sin( LLH_out->lat ) );

/* ==========================================================================
   Rescale the output from radians to degrees
   ========================================================================== */
   LLH_out->lat *= RADTODEG;
   LLH_out->lon *= RADTODEG;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

}/* COORPP_CONV_xyz_llh */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_llh_en

        $TYPE         PROCEDURE

        $INPUT        LLH_in  : input ( lat, lon, h ) geodetic coordinates
                                in degree ( meters )
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       EN_out  : output ( east, north ) UTM or UPS coordinates
			        in meters

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_unhandled_projection

        $DESCRIPTION  This procedure converts a point from UTM or UPS to
		      geodetic coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
void  COORPP_CONV_llh_en
		        (/*IN    */ MATHIT_LLH          *LLH_in,
			 /*IN    */ INTx4		 imanum,
			 /*   OUT*/ MATHIT_EN	        *EN_out,
			 /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "COORPP_CONV_llh_en";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility pointers to structures
   ========================================================================== */
   IANNIT_ImageAnnot     *ImgAnno;
   COORIT_conv           *DataConv;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Point to the global structures
   ========================================================================== */
   ImgAnno = ( IANNIV_ImageAnnot + imanum );
   DataConv = ( COORIV_conv + imanum );

/* ==========================================================================
   Switch among the various MAP projections
   ========================================================================== */
   switch ( ImgAnno->MapProjectionType ) {

      case IANNIE_proj_UTM: {
	 double		        phi;
	 double			lambda;
         double			eta;
         double		        ti;
         double			n;
	 double                 s;
	 double			lambda2,lambda3,lambda4,lambda5,lambda6;
	 double                 eta2,eta3,eta4;
	 double                 ti2,ti4;
         double			cosf,cosf2,cosf3,cosf4,cosf5,sincosf;
         double			sinf,sin2f,sin4f,sin6f,sin8f;

/* ==========================================================================
   Take off the longitude offset
   ========================================================================== */
	 lambda = ( LLH_in->lon - ImgAnno->ProjectionCentralMeridian_deg  );

/* ==========================================================================
   Rescale the angles from degrees to radians
   ========================================================================== */
	 lambda *= DEGTORAD;
	 phi = LLH_in->lat * DEGTORAD;

/* ==========================================================================
   Evaluate the powers of lambda
   ========================================================================== */
         lambda2 = lambda * lambda;
         lambda3 = POW( lambda, 3. );
         lambda4 = POW( lambda, 4. );
         lambda5 = POW( lambda, 5. );
         lambda6 = POW( lambda, 6. );

/* ==========================================================================
   Evaluate the trigonometric values
   ========================================================================== */
         cosf = cos( phi );
	 sinf = sin( phi );
         ti = tan( phi );

/* ==========================================================================
   Evaluate the utility coefficients
   ========================================================================== */
         sin2f = sin( 2. * phi );
         sin4f = sin( 4. * phi );
         sin6f = sin( 6. * phi );
         sin8f = sin( 8. * phi );
         cosf2 = cosf * cosf;
         cosf3 = POW( cosf, 3. );
         cosf4 = POW( cosf, 4. );
         cosf5 = POW( cosf, 5. );
         sincosf = sinf * cosf;

         eta= ( DataConv->Eccentricity_1 * cosf ) /
	    sqrt( 1.0 - DataConv->Eccentricity_2 );
         eta2 = eta * eta;
         eta3 = POW( eta, 3. );
         eta4 = POW( eta, 4. );

         ti2 = ti * ti;
	 ti4 = POW( ti, 4. );

         n = ImgAnno->SemiMajorAxis_m /
	    sqrt( 1.0 - ( DataConv->Eccentricity_2 * sinf * sinf ) ); 
         s =  ImgAnno->SemiMajorAxis_m *
	    ( DataConv->a0 * phi - DataConv->a2 * sin2f + DataConv->a4 * sin4f -
              DataConv->a6 * sin6f + DataConv->a8 * sin8f ) /
	    ( 1.0 + DataConv->np );

/* ==========================================================================
   Evaluate the output
   ========================================================================== */
         EN_out->east = ImgAnno->FalseEast_m +
            ImgAnno->ProjectionScaleFactor * n * ( lambda * cosf + 
            lambda3 * cosf3 * ( 1.0 - ti2 + eta3 ) / 6.0 +
            lambda5 * cosf5 * ( 5.0 - 18.0*ti2 + ti4 + 14.0*eta2 -
				58.0*ti2*eta2 ) / 120.0  );

         EN_out->north = ImgAnno->FalseNorth_m +
	    ImgAnno->ProjectionScaleFactor * n *
	    ( s / n + lambda2 * sincosf / 2.0 +
            lambda4 * sincosf * cosf2 * ( 5.0 - ti2 + 9.0*eta2 +
					  4.0*eta4 ) / 24.0 +
            lambda6 * sincosf * cosf4 * ( 61.0 - 58.0*ti2 + ti4 + 270.0*eta2 -
		                          330.0*ti2*eta2 ) / 720.0 );
      }
      break;

      case IANNIE_proj_UPS: {
	 double                 phi;
	 double                 lambda;
         double		        e;
	 double                 IV;
         double                 R;

/* ==========================================================================
   Change the geodetic reference system
   ========================================================================== */
	 phi = ( LLH_in->lat >= 0. ) ? LLH_in->lat : ( - LLH_in->lat );

/* ==========================================================================
   Take off the longitude offset
   ========================================================================== */
         lambda = ( LLH_in->lon - ImgAnno->ProjectionCentralMeridian_deg );

/* ==========================================================================
   Rescale the angles
   ========================================================================== */
	 phi *= DEGTORAD;
	 lambda *= DEGTORAD;

/* ==========================================================================
   Utility variables
   ========================================================================== */
         e = DataConv->Eccentricity_1;
         IV = tan( PI / 4.0 - phi / 2. ) /
	    POW( ( 1.0 - e * sin(phi) ) / ( 1.0 + e * sin(phi) ),
		 (e / 2.0) );
         R = 2.0 * ImgAnno->SemiMajorAxis_m *
            ImgAnno->ProjectionScaleFactor * IV /
	    sqrt( POW( 1.0 + e, 1.0 + e ) * POW( 1.0 - e, 1.0 - e ) );

/* ==========================================================================
   Conversion core
   ========================================================================== */
         EN_out->east = R * sin( lambda );
	 EN_out->north = ( LLH_in->lat >= 0. ) ? ( - R * cos( lambda ) ) :
						 ( R * cos( lambda ) );

/* ==========================================================================
   Rescale the output
   ========================================================================== */
	 EN_out->east += (double)ImgAnno->FalseEast_m;
	 EN_out->north += (double)ImgAnno->FalseNorth_m;

      }
      break;
      default:
         ERRSIM_set_error(status_code, ERRSID_COOR_unhandled_projection, "" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* COORPP_CONV_llh_en */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_en_llh

        $TYPE	      PROCEDURE

        $INPUT        EN_in   : input ( east, north ) coordinates in meters
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       LLH_out : output geodetic ( lat, lon, h ) coordinates
			        in degrees and meters

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_unhandled_projection

        $DESCRIPTION  This procedure converts a point from East-North to
		      geodetic coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
void  COORPP_CONV_en_llh
			(/*IN    */ MATHIT_EN	        *EN_in,
			 /*IN    */ INTx4		 imanum,
			 /*   OUT*/ MATHIT_LLH		*LLH_out,
			 /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "COORPP_CONV_en_llh";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   IANNIT_ImageAnnot     *ImgAnno;
   COORIT_conv           *DataConv;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Point to the global structures
   ========================================================================== */
   ImgAnno = ( IANNIV_ImageAnnot + imanum );
   DataConv = ( COORIV_conv + imanum );

/* ==========================================================================
   Switch between UTM or UPS
   ========================================================================== */
   switch ( ImgAnno->MapProjectionType ) {

      case IANNIE_proj_UTM: {
	 double                 phi_f;	 
	 double			phi0 = 0.;
	 double                 phi_start;
	 double                 sp = 0.;
         double                 delta = COORID_UTMPRECISION+ 1.0;
         double                 eta;
         double                 ti;
         double                 n;
	 double                 s;
	 double                 rapp;
	 double                 eta2,eta4;
	 double                 ti2,ti4;
         double		        rapp2,rapp3,rapp4,rapp5,rapp6;
	 INTx4                  count = 0;

/* ==========================================================================
   Initializes the foot point latitude
   ========================================================================== */
         phi_start = ( EN_in->north - ImgAnno->FalseNorth_m ) *
	    ( 1.0 + DataConv->np ) /
            ( ImgAnno->SemiMajorAxis_m * DataConv->a0 * 
            ImgAnno->ProjectionScaleFactor );

/* ==========================================================================
   Evaluate iteratively the foot point latitude
   ========================================================================== */
         while ( ( delta > COORID_UTMPRECISION ) &&
		 ( count < COORID_UTMMAXITER ) ) {

/* ==========================================================================
   Reset the current foot point latitude
   ========================================================================== */
            phi_f = phi_start - sp;

/* ==========================================================================
   Re-evaluate the value sp
   ========================================================================== */
            sp = ( - DataConv->a2 * sin( 2. * phi_f ) +
		     DataConv->a4 * sin( 4. * phi_f ) -
		     DataConv->a6 * sin( 6. * phi_f ) +
		     DataConv->a8 * sin( 8. * phi_f ) ) /
		 DataConv->a0 ;

/* ==========================================================================
   Reset the parameters to be used in the next tour
   ========================================================================== */
            delta = ABS( phi0 - phi_f );
            phi0 = phi_f;
            count++;
         }

/* ==========================================================================
   Foot point latitude dependent terms evaluation
   ========================================================================== */
         eta = ( DataConv->Eccentricity_1 * cos( phi_f ) ) /
	    sqrt( 1.0 - DataConv->Eccentricity_2 ); 
         ti = tan( phi_f );
         n = ImgAnno->SemiMajorAxis_m /
	    sqrt( 1.0 - DataConv->Eccentricity_2 * sin(phi_f) * sin(phi_f) ); 
         rapp = ( EN_in->east - ImgAnno->FalseEast_m ) /
	    ( ImgAnno->ProjectionScaleFactor * n );

         eta2 = eta * eta;
	 eta4 = POW( eta, 4. );
         ti2 = ti * ti;
	 ti4 = POW( ti, 4. );
         rapp2 = rapp * rapp;
         rapp3 = POW( rapp, 3. );
         rapp4 = POW( rapp, 4. );
         rapp5 = POW( rapp, 5. );
         rapp6 = POW( rapp, 6. );

/* ==========================================================================
   Conversion core
   ========================================================================== */
         LLH_out->lat = phi_f - ( 1.0 + eta2 ) * ti * rapp2 / 2.0 +
	    ( 5.0+ 3.0*ti2 + 6.0*eta2 - 6.0*eta2*ti2 - 3.0*eta4-9.0*ti2*eta4) *
	    ti * rapp4 / 24.0 -
	    ( 61.0 + 90.0*ti2 + 45.0*ti4 - 107.0*eta2 - 162.0*ti2*eta2 -
		45.0*ti4*eta2 ) * ti * rapp6 / 720.0;

	 LLH_out->lon = ( 1. / cos( phi_f ) ) *
	    ( rapp - ( 1.0 + 2.0*ti2 + eta2 ) * rapp3 / 6.0 +
               (5.0 + 28.0*ti2 + 24.0*ti4 + 6.0*eta2 + 8.0*ti2*eta2 ) *
	       rapp5 / 120.0 );

/* ==========================================================================
   Rescale the output
   ========================================================================== */
	 LLH_out->lat *= RADTODEG;
	 LLH_out->lon = LLH_out->lon * RADTODEG +
	    ImgAnno->ProjectionCentralMeridian_deg;
         LLH_out->h = 0.0;
      }
      break;

      case IANNIE_proj_UPS: {
	 MATHIT_EN uti_en;
	 double			phi_f;
	 double                 phi0;
	 double		        sp = 0.0;
         double		        delta = COORID_UPSPRECISION + 1.0;
         double			n;
	 double                 s;
         double		        e;
         double		        r;
	 double                 psi;
         INTx4		        count = 0;

/* ==========================================================================
   Rescale the reference frame
   ========================================================================== */
         uti_en.east = EN_in->east - ImgAnno->FalseEast_m;
	 uti_en.north = EN_in->north - ImgAnno->FalseNorth_m;

/* ==========================================================================
   Switch WRT the emisphere
   ========================================================================== */
	 if ( ImgAnno->ProjectionCentralParallel_deg < 0.) {
	    uti_en.north = - uti_en.north;
	 }

/* ==========================================================================
   Utility variables evaluation
   ========================================================================== */
         e = DataConv->Eccentricity_1;
         r = sqrt( uti_en.east * uti_en.east + uti_en.north * uti_en.north );
         psi = r * sqrt( POW( 1.+ e, 1. + e ) * POW( 1. - e, 1. - e ) ) /
	    ( 2.0 * ImgAnno->SemiMajorAxis_m * ImgAnno->ProjectionScaleFactor );

/* ==========================================================================
   Initialize the foot point latitude
   ========================================================================== */
         phi0 = PI / 2.0 - 2.0 * atan( psi );

/* ==========================================================================
   Evaluate iteratively the foot point latitude
   ========================================================================== */
         while ( ( delta > COORID_UPSPRECISION ) &&
	         ( count < COORID_UPSMAXITER ) ) {

            phi_f = PI / 2.0 - 2.0 * atan( psi * POW( ( 1.0 - e * sin(phi0) ) /
	       ( 1.0 + e * sin(phi0) ), e / 2.0 ) );

/* ==========================================================================
   Reset the counters
   ========================================================================== */
            delta = ABS( phi0 - phi_f );
            phi0 = phi_f;
            count++;
         }

/* ==========================================================================
   Conversion core
   ========================================================================== */
         LLH_out->lat = PI / 2.0 - 2.0 * atan( psi * POW( (1.0 - e*sin(phi_f)) /
	    ( 1.0 + e * sin( phi_f) ),  e / 2.0 ) );
	 LLH_out->lon = atan2( uti_en.east, -1.0 * uti_en.north );

/* ==========================================================================
   Assign the rigth sign to the latitude
   ========================================================================== */
	 if ( ImgAnno->ProjectionCentralParallel_deg < 0.) {
	    LLH_out->lat = - LLH_out->lat;
	 }

/* ==========================================================================
   Rescale the output
   ========================================================================== */
	 LLH_out->lat *= RADTODEG;
	 LLH_out->lon *= RADTODEG;
	 LLH_out->lon += ImgAnno->ProjectionCentralMeridian_deg ;
         LLH_out->h=0.0;
      }
      break;

      default:
	 ERRSIM_set_error(status_code, ERRSID_COOR_unhandled_projection, "" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* COORPP_CONV_en_llh */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_rc_xyz

        $TYPE	      PROCEDURE

        $INPUT        RC_in   : input ( row, col ) image coordinates in pixel
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       XYZ_out : output cartesian ( x, y, z ) coordinates in
			        meters

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need
		      COORPV_ImgNum		: the image number among all
						  that opened in the program

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_bad_param_annot

        $DESCRIPTION  This procedure converts a point from image to cartesian 
                      coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
void COORIP_CONV_rc_xyz
			(/*IN    */ MATHIT_RC		*RC_in,
			 /*IN    */ INTx4		 imanum,
			 /*   OUT*/ MATHIT_XYZ		*XYZ_out,
			 /*   OUT*/ ERRSIT_status	*status_code )
{
   const ERRSIT_proc_name routine_name = "COORIP_CONV_rc_xyz";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   IANNIT_ImageAnnot     *ImgAnno;
   COORIT_conv           *DataConv;
   MATHIT_RC              p_rc;
   double                 t;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Point to the global structures
   ========================================================================== */
   COORPV_ImgNum = imanum;
   ImgAnno = ( IANNIV_ImageAnnot + COORPV_ImgNum );
   DataConv = ( COORIV_conv + COORPV_ImgNum );

   if ( ( ImgAnno->SamplingRate_Hz == 0.0 ) || 
        ( ImgAnno->RadarWaveLength_m == 0.0 ) ||
        ( DataConv->prf == 0.0 ) ) {
      ERRSIM_set_error( status_code, ERRSID_COOR_bad_param_annot,
			" Sampling rate, Radar wavelength or PRF" );
   }

/* ==========================================================================
   Add the offset WRT the full frame image
   ========================================================================== */
   p_rc.row = ImgAnno->SubImageTopLeftRow + RC_in->row /
      ImgAnno->YScalingFactor;
   p_rc.col = ImgAnno->SubImageTopLeftCol + RC_in->col /
      ImgAnno->XScalingFactor;

/* ==========================================================================
   Time corresponding to the given row
   ========================================================================== */
   t = DataConv->dt + p_rc.row / DataConv->prf;

/* ==========================================================================
   Spacecraft Position evaluation 
   ========================================================================== */
   /* X STVect */
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->X_STVec_m,
                              ImgAnno->NStateVectors, t, DataConv->X_STVec_2D,
                              &DataConv->SP.x, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* Y STVect */
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->Y_STVec_m,
                              ImgAnno->NStateVectors, t, DataConv->Y_STVec_2D,
                              &DataConv->SP.y, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* Z STVect */
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->Z_STVec_m,
                              ImgAnno->NStateVectors, t, DataConv->Z_STVec_2D,
                              &DataConv->SP.z, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Spacecraft Velocity evaluation 
   ========================================================================== */
   /* VX STVect */
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->VX_STVec_m_sec,
                              ImgAnno->NStateVectors, t, DataConv->VX_STVec_2D,
                              &DataConv->SV.x, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* VY STVect */
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->VY_STVec_m_sec,
                              ImgAnno->NStateVectors, t, DataConv->VY_STVec_2D,
                              &DataConv->SV.y, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* VZ STVect */
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->VZ_STVec_m_sec,
                              ImgAnno->NStateVectors, t, DataConv->VZ_STVec_2D,
                              &DataConv->SV.z, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Slant range evaluation
   ========================================================================== */
   COORIP_CONV_SlantRangeEval( p_rc.col, imanum, &DataConv->slant,
			       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Pixel spacing evaluation
   ========================================================================== */
/*
   DataConv->col_spa = ( DataConv->imaflg ) ?
      ( CVEL / 2.0 / ImgAnno->SamplingRate_Hz ) :
      ( ImgAnno->PixelSpacing_m * ImgAnno->XScalingFactor );
*/
   DataConv->col_spa = ImgAnno->PixelSpacing_m * ImgAnno->XScalingFactor;
   DataConv->SRCoeff = ( DataConv->imaflg ) ?
      ( CVEL / 2.0 / ImgAnno->SamplingRate_Hz ) : DataConv->col_spa;

/* ==========================================================================
   Solve the non linear system of the three equations:
      - Range equation,
      - Ellipsoid equation,
      - Zero doppler equation
   to evaluate the three cartesian coordinates of the point.
   The Newton-Raphson method is used ( see MATH_ROOF.C comments ).
   ========================================================================== */

   /* initializes the initial guess vector */
   XYZ_out->x = DataConv->xyz_C.x;
   XYZ_out->y = DataConv->xyz_C.y;
   XYZ_out->z = DataConv->xyz_C.z;
   MATHIP_ROOF_Newton( COORID_NEWTONMAXITER, 3, COORPP_FUNC_Newton_rc_xyz,
		       COORID_NEWTONMAXTOLX, COORID_NEWTONMAXTOLF,
		       (double *)(XYZ_out), status_code );
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* COORIP_CONV_rc_xyz */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_xyz_rc

        $TYPE         PROCEDURE

        $INPUT        XYZ_in  : input cartesian ( x, y, z ) coordinates in
			        meters
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       RC_out  : output ( row, col ) image coordinates in pixel

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
                                                  image annotations
                      COORIV_conv[imanum]	: the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need
		      COORPV_ImgNum		: the image number among all
                                                  that opened in the program

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_bad_param_annot

        $DESCRIPTION  This procedure converts a point from cartesian to image
		      coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
void COORIP_CONV_xyz_rc
			(/*IN    */ MATHIT_XYZ          *XYZ_in,
                         /*IN    */ INTx4                imanum,
                         /*   OUT*/ MATHIT_RC           *RC_out,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "COORIP_CONV_xyz_rc";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double                 col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */

   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Point to the global structures
   ========================================================================== */
   COORPV_ImgNum = imanum;

/* ==========================================================================
   Check the existence of the necessary parameters
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz == 0.0 ) ||
        ( IANNIV_ImageAnnot[ imanum ].RadarWaveLength_m == 0.0 ) ||
        ( COORIV_conv[ imanum ].prf == 0.0 ) ) {
      ERRSIM_set_error( status_code, ERRSID_COOR_bad_param_annot,
                        " Sampling rate, Radar wavelength or PRF" );
   }

/* ==========================================================================
   Initialize the first point
   ========================================================================== */
   RC_out->row = IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow +
      ( IANNIV_ImageAnnot[ imanum ].ImageLength ) / 2. /
      IANNIV_ImageAnnot[ imanum ].YScalingFactor;
   RC_out->col = IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol +
      ( IANNIV_ImageAnnot[ imanum ].ImageWidth ) / 2. /
      IANNIV_ImageAnnot[ imanum ].XScalingFactor;

/* ==========================================================================
   Slant range evaluation
   ========================================================================== */
   COORIP_CONV_SlantRangeEval( RC_out->col, imanum,
			       &COORIV_conv[ imanum ].slant,
			       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Pixel spacing evaluation
   ========================================================================== */
/*
   COORIV_conv[ imanum ].col_spa = ( COORIV_conv[ imanum ].imaflg ) ?
      ( CVEL / 2.0 / IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz ) :
      ( IANNIV_ImageAnnot[ imanum ].PixelSpacing_m *
	IANNIV_ImageAnnot[ imanum ].XScalingFactor );
*/
   COORIV_conv[ imanum ].col_spa = IANNIV_ImageAnnot[ imanum ].PixelSpacing_m *
      IANNIV_ImageAnnot[ imanum ].XScalingFactor;
   COORIV_conv[ imanum ].SRCoeff = ( COORIV_conv[ imanum ].imaflg ) ?
      ( CVEL / 2.0 / IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz ) :
      COORIV_conv[ imanum ].col_spa;

/* ==========================================================================
   Solve the non linear system of the two equations:
      - Range equation,
      - Zero doppler equation
   to evaluate the two image coordinates of the point.
   The Newton-Raphson method is used ( see MATH_ROOF.C comments ).
   ========================================================================== */

   /* fill the global vector of the cartesian coordinates */
   COORIV_conv[ imanum ].xyz_C.x = XYZ_in->x;
   COORIV_conv[ imanum ].xyz_C.y = XYZ_in->y;
   COORIV_conv[ imanum ].xyz_C.z = XYZ_in->z;
   MATHIP_ROOF_Newton( COORID_NEWTONMAXITER, 2, COORPP_FUNC_Newton_xyz_rc,
		       COORID_NEWTONMAXTOLX, COORID_NEWTONMAXTOLF,
		       (double *)(RC_out), status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Come back to the zoomed row col
   ========================================================================== */
   RC_out->row =
      ( RC_out->row - IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow ) *
      IANNIV_ImageAnnot[ imanum ].YScalingFactor;

   RC_out->col =
      ( RC_out->col - IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol ) *
      IANNIV_ImageAnnot[ imanum ].XScalingFactor;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* COORIP_CONV_xyz_rc */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_rc_llh

        $TYPE	      PROCEDURE

        $INPUT        RC_in   : input ( row, col ) image coordinates in pixel
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       LLH_out : output geodetic ( lat, lon, h ) coordinates in
                                degrees and meters

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
                                                  image annotations
                      COORIV_conv[imanum]	: the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_unhandled_projection

        $DESCRIPTION  This procedure converts a point from image ( row, col )
		      to geodetic lat lon coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

        $PDL          - Switch among geocoded and not geocoded product
		            - Case GEOCODED
			          - Converts the input ( row, col ) coordinates
				    into ( east, north ) UTM or UPS coordinates
                                  - Converts the intermediate ( east, north )
				    UTM or UPS coordinates into ( lat, lon, h )
				    geodetic coordinates
			    - End Case
			    - Case NOT GEOCODED
			          - Converts the input ( row, col ) coordinates
                                    into cartesian ( x, y, z ) coordinates
				  - Converts the intermediate  ( x, y, z )
				    cartesian coordinates into ( lat, lon, h )
				    geodetic coordinates
			    - End Case
		      - End switch

   $EH
   ========================================================================== */
void COORIP_CONV_rc_llh
			(/*IN    */ MATHIT_RC           *RC_in,
			 /*IN    */ INTx4                imanum,
			 /*   OUT*/ MATHIT_LLH          *LLH_out,
			 /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "COORIP_CONV_rc_llh";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Switch among the various map projection types
   ========================================================================== */
   switch ( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {
      case IANNIE_proj_slant:
      case IANNIE_proj_ground: {
         MATHIT_XYZ            XYZ;

/* ==========================================================================
   Not geocoded images.
   The coordinates conversions from ( row, col ) to ( lat, lon, h ) for the
   not geocoded images is done passing throw the cartesian ( x, y, z )
   coordinates.
   ========================================================================== */

	 /* ( row, col ) ==> ( x, y, z ) conversion */
         COORIP_CONV_rc_xyz ( RC_in, imanum, &XYZ, status_code );
         ERRSIM_on_err_goto_exit( *status_code);

	 /* ( x, y, z ) ==> ( lat, lon, h ) conversion */
         COORPP_CONV_xyz_llh ( &XYZ, imanum, LLH_out, status_code );
         ERRSIM_on_err_goto_exit( *status_code);
      }
      break;
      case IANNIE_proj_UTM:
      case IANNIE_proj_UPS: {
         MATHIT_EN	       EN;

/* ==========================================================================
   Geocoded images.
   The coordinates conversions from ( row, col ) to ( lat, lon, h ) for the
   geocoded images is done passing throw the UTM or UPS ( east, north )
   coordinates.
   ========================================================================== */

	 /* ( row, col ) ==> ( east, north ) conversion */
         COORIP_CONV_rc_en ( RC_in, imanum, &EN, status_code );
         ERRSIM_on_err_goto_exit( *status_code);

	 /* ( east, north ) ==> ( lat, lon, h ) conversion */
         COORPP_CONV_en_llh ( &EN, imanum, LLH_out, status_code );
         ERRSIM_on_err_goto_exit( *status_code);
      }
      break;
      default:

/* ==========================================================================
   Product not handled
   ========================================================================== */
         ERRSIM_set_error( status_code, ERRSID_COOR_unhandled_projection, "" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* COORIP_CONV_rc_llh */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_llh_rc

        $TYPE         PROCEDURE

        $INPUT        LLH_in  : input geodetic ( lat, lon, h ) coordinates in
                                degrees and meters
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       RC_out  : output ( row, col ) image coordinates in pixel
 
        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
                      ERRSID_COOR_unhandled_projection

        $DESCRIPTION  This procedure converts a point from geodetic ( lat, lon,
		      h ) to image coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

        $PDL          - Switch among geocoded and not geocoded product
                            - Case GEOCODED
                                  - Converts the input geodetic ( lat, lon, h )
				    coordinates into ( east, north ) UTM or UPS
				    coordinates
                                  - Converts the intermediate ( east, north )
                                    UTM or UPS coordinates into ( row, col )
                                    image coordinates
                            - End Case
                            - Case NOT GEOCODED
                                  - Converts the input geodetic ( lat, lon, h )
				    coordinates into cartesian ( x, y, z )
				    coordinates
                                  - Converts the intermediate  ( x, y, z )
                                    cartesian coordinates into ( row, col )
                                    image coordinates
                            - End Case
                      - End switch

   $EH
   ========================================================================== */
void COORIP_CONV_llh_rc
			(/*IN    */ MATHIT_LLH		*LLH_in,
			 /*IN    */ INTx4		 imanum,
			 /*   OUT*/ MATHIT_RC		*RC_out,
			 /*   OUT*/ ERRSIT_status	*status_code )
{
   const ERRSIT_proc_name routine_name = "COORIP_CONV_llh_rc";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Chech the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_COOR_imanum_not_allow, "" );

/* ==========================================================================
   Switch among the various map projection types
   ========================================================================== */
   switch ( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {
      case IANNIE_proj_slant:
      case IANNIE_proj_ground: {
         MATHIT_XYZ	        XYZ;

/* ==========================================================================
   Not geocoded images.
   The coordinates conversions from ( lat, lon, h ) to ( row, col ) for the
   not geocoded images is done passing throw the cartesian ( x, y, z )
   coordinates.   
   ========================================================================== */

	 /* ( lat, lon, h )  ==> ( x, y, z ) conversion */
         COORPP_CONV_llh_xyz ( LLH_in, imanum, &XYZ, status_code );
         ERRSIM_on_err_goto_exit( *status_code);

	 /* ( x, y, z ) ==> ( row, col ) conversion */
         COORIP_CONV_xyz_rc ( &XYZ, imanum, RC_out, status_code );
         ERRSIM_on_err_goto_exit( *status_code);
      }
      break;
      case IANNIE_proj_UTM:
      case IANNIE_proj_UPS: {
         MATHIT_EN	        EN;

/* ==========================================================================
   Geocoded images.
   The coordinates conversions from ( lat, lon, h ) to ( row, col ) to for the
   geocoded images is done passing throw the UTM or UPS ( east, north )
   coordinates.
   ========================================================================== */

	 /* ( lat, lon, h ) ==> ( east, north ) conversion */
         COORPP_CONV_llh_en ( LLH_in, imanum, &EN, status_code );
         ERRSIM_on_err_goto_exit( *status_code);

	 /* ( east, north ) ==> ( row, col ) conversion */
         COORPP_CONV_en_rc ( &EN, imanum, RC_out, status_code );
         ERRSIM_on_err_goto_exit( *status_code);
      }
      break;
      default:
         ERRSIM_set_error(status_code,
                           ERRSID_COOR_unhandled_projection,"");
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* COORIP_CONV_llh_rc */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_Interpolator

        $TYPE	      PROCEDURE

        $INPUT        x_axis    : abscissa axis
                      y_axis    : ordinata axis
                      NElements : number of elements of the abscissa and
                                  ordinata values
                      x_curr    : abscissa value for which to evaluate the
                                  ordinata value
                      ancillary : array of ancillary objects. In the SPLINE
                                  interpolation they're the 2d derivative values

        $MODIFIED     NONE

        $OUTPUT       value     : ordinata value evaluated corresponding to the
                                  abscissa one
 
        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_few_elements
                      ERRSID_COOR_math_exception

        $DESCRIPTION  This procedure interpolates a value in correspondence of
                      an abscissa one given a set of abscissa values and the
                      corresponding ordinata values. If the current abscissa is
                      inside the abscissa range it's interpolated by SPLINE
                      interpolation else via linear extrapolation taking the two
                      nearest points.

        $WARNING      

        $PDL          - Checks the number of elements of the array
                      - If the current abscissa value is lower than the lowest
                        abscissa array values
                            - Evaluates the delta between the first two
                              abscissa values
                            - Evaluates the coefficients of the linear
                              interpolation
                            - Evaluates the extrapolated value
                      - Else If the current abscissa value is greather than the
                        greatest abscissa array values
                            - Evaluates the delta between the last two abscissa
                              values
                            - Evaluates the coefficients of the linear
                              interpolation
                            - Evaluates the extrapolated value
                      - Else
                            - Makes the spline interpolation
                      - End Else

   $EH
   ========================================================================== */
void COORPP_CONV_Interpolator
			(/*IN    */ double              *x_axis,
                         /*IN    */ double              *y_axis,
                         /*IN    */ INTx4                NElements,
                         /*IN    */ double               x_curr,
                         /*IN    */ double              *ancillary,
			 /*   OUT*/ double              *value,
			 /*   OUT*/ ERRSIT_status	*status_code )
{
   const ERRSIT_proc_name routine_name = "COORPP_CONV_Interpolator";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code);

/* ==========================================================================
   Check the number of elements
   ========================================================================== */
   if ( NElements <= 1 ) {
      ERRSIM_set_error ( status_code, ERRSID_COOR_few_elements, "" );
   }

/* ==========================================================================
   Check if the abscissa current value is inside the abscissa range
   ========================================================================== */
   if ( x_curr < x_axis[ 0 ] )  {
      double                a_cf;
      double                b_cf;
      double                delta_x;

/* ==========================================================================
   Evaluates the delta abscissa
   ========================================================================== */
      delta_x = x_axis[ 1 ] - x_axis[ 0 ];
      if ( delta_x == (double)0 ) {
         ERRSIM_set_error ( status_code, ERRSID_COOR_math_exception,
                            " delta x equal 0" );
      }

/* ==========================================================================
   Evaluate the coefficients
   ========================================================================== */
      a_cf = (double)( y_axis[ 1 ] - y_axis[ 0 ] ) / delta_x;
      b_cf = (double)y_axis[ 0 ] - a_cf * ( (double)x_axis[ 0 ] );

/* ==========================================================================
   Evaluate the extrapolated value
   ========================================================================== */
      *value = a_cf * x_curr + b_cf;
   }
   else if ( x_curr > x_axis[ NElements - 1 ] ) {
      double                a_cf;
      double                b_cf;
      double                delta_x;

/* ==========================================================================
   Evaluates the delta abscissa
   ========================================================================== */
      delta_x = x_axis[ NElements - 1 ] - x_axis[ NElements - 2 ];
      if ( delta_x == (double)0 ) {
         ERRSIM_set_error ( status_code, ERRSID_COOR_math_exception,
                            " delta x equal 0" );
      }

/* ==========================================================================
   Evaluate the coefficients
   ========================================================================== */
      a_cf = (double)( y_axis[ NElements - 1 ] - y_axis[ NElements - 2 ] ) /
         delta_x;
      b_cf = (double)y_axis[ NElements - 1 ] - a_cf *
         ( (double)x_axis[ NElements - 1 ] );

/* ==========================================================================
   Evaluate the extrapolated value
   ========================================================================== */
      *value = a_cf * x_curr + b_cf;
   }
   else {

/* ==========================================================================
   SPLINE interpolation
   ========================================================================== */
      MATHIP_SPLN_splint ( x_axis, y_axis, ancillary, NElements, x_curr, value,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* COORPP_CONV_Interpolator */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_FirstDeriv

        $TYPE	      PROCEDURE

        $INPUT        x0      : current abscissa point in which to interpolate
                      n       : number of abscissa and ordinates elements
                      x       : array of abscissa
                      y       : array of ordinates
                      y2      : array with the second derivatives coefficients
                                evaluated by the procedures of initialization of
                                SPLINE if they're necessary

        $MODIFIED     NONE

        $OUTPUT       FirstD  : value of the first derivative of the polynomial
                                function evaluated at the point <x0>
 
        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_few_elements
                      ERRSID_COOR_math_exception

        $DESCRIPTION  This procedure evaluates the first derivative of a generic
                      function evaluated with a spline interpolation. If the
                      point in which the derivative must been evaluated is out
                      the abscissa range, the first derivative evaluated is that
                      of a linear interpolation between the nearest points

        $WARNING      NONE

        $PDL          - Checks the number of elements
                      - If the abscissa value is lesser then the lowest abscissa
                        value
                            - Evaluates the delta between the first two abscissa
                              values
                            - Evaluates the first derivative
                      - Else If the abscissa value is greather then the greatest
                        abscissa value
                            - Evaluates the delta between the last two abscissa
                              values
                            - Evaluates the first derivative
                      - Else
                            - Calls the function to evaluate the first
                              derivative of a SPLINE interpolated function
                      - End If

   $EH
   ========================================================================== */
void COORPP_CONV_FirstDeriv
			(/*IN    */ double               x0,
                         /*IN    */ INTx4                n,
                         /*IN    */ double              *x,
                         /*IN    */ double              *y,
                         /*IN    */ double              *y2,
			 /*   OUT*/ double              *FirstD,
			 /*   OUT*/ ERRSIT_status	*status_code )
{
   const ERRSIT_proc_name routine_name = "COORPP_CONV_FirstDeriv";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the number of elements
   ========================================================================== */
   if ( n <= 1 ) {
      ERRSIM_set_error ( status_code, ERRSID_COOR_few_elements, "" );
   }

/* ==========================================================================
   Check if the abscissa current value is inside the abscissa range
   ========================================================================== */
   if ( x0 < x[ 0 ] ) {
      double                delta_x;

/* ==========================================================================
   Evaluates the delta abscissa
   ========================================================================== */
      delta_x = x[ 1 ] - x[ 0 ];
      if ( delta_x == (double)0 ) {
            ERRSIM_set_error ( status_code, ERRSID_COOR_math_exception,
                               " delta x equal 0" );
      }

/* ==========================================================================
   Evaluate the first derivative
   ========================================================================== */
      *FirstD = (double)( y[ 1 ] - y[ 0 ] ) / delta_x;
   }
   else if ( x0 > x[ n - 1 ] ) {
      double                delta_x;

/* ==========================================================================
   Evaluates the delta abscissa
   ========================================================================== */
      delta_x = x[ n - 1 ] - x[ n - 2 ];
      if ( delta_x == (double)0 ) {
         ERRSIM_set_error ( status_code, ERRSID_COOR_math_exception,
                            " delta x equal 0" );
      }

/* ==========================================================================
   Evaluate the first derivative
   ========================================================================== */
      *FirstD = (double)( y[ n - 1 ] - y[ n - 2 ] ) / delta_x;
   }
   else {

/* ==========================================================================
   Call the SPLINE first derivative
   ========================================================================== */
      COORPP_CONV_SplineFirstDeriv ( x0, n, x, y, y2, FirstD, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code,
                          &log_status_code );

}/* COORPP_CONV_FirstDeriv */

#ifdef SUBS
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE
 
        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  

        $WARNING      

        $PDL

   $EH
   ========================================================================== */
void COORIP_CONV_
			(/*IN    */
			 /*IN OUT*/
			 /*   OUT*/ ERRSIT_status	*status_code )
{
   const ERRSIT_proc_name routine_name = "COORIP_CONV_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* COORIP_CONV_ */
#endif
