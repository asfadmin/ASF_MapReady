/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_IDLI

      $FUNCTION          Service routine for SAR TOOLBOX - IDL Interfacing

      $ROUTINE           STBXPP_IDLI_GetImage
                         STBXPP_IDLI_GetArray
                         STBXPP_IDLI_GetParValue
                         STBXPP_IDLI_GetParAddress
                         STBXPP_IDLI_GetArrayAddress
                         STBXPP_IDLI_CreateArray
                         STBXPP_IDLI_CreateMatrix
                         STBXPP_IDLI_IDLVar2INTx2
                         STBXPP_IDLI_IDLVar2INTx4
                         STBXPP_IDLI_IDLVar2UINTx2
                         STBXPP_IDLI_IDLVar2UINTx4
                         STBXPP_IDLI_IDLVar2float
                         STBXPP_IDLI_IDLVar2double
                         STBXPP_IDLI_IDLArray2INTx2
                         STBXPP_IDLI_IDLArray2INTx4
                         STBXPP_IDLI_IDLArray2UINTx2
                         STBXPP_IDLI_IDLArray2UINTx4
                         STBXPP_IDLI_IDLArray2float
                         STBXPP_IDLI_IDLArray2double
                         stbx_oversampling
                         stbx_kernelfiltering
                         STBXPP_IDLI_IDLOverGetInputPar
                         STBXPP_IDLI_IDLOverFillAnno
                         STBXPP_IDLI_IDLUnderGetInputPar
                         STBXPP_IDLI_IDLFillImage
                         STBXPP_IDLI_IDLUnderCheckFilter
                         STBXPP_IDLI_IDLUnderFiltCopy
                         STBXPP_IDLI_IDLGstaGetInputPar
                         STBXPP_IDLI_IDLGstaFillAnno
                         stbx_globalstatistic
                         STBXPP_IDLI_IDLLstaGetInputPar
                         STBXPP_IDLI_IDLLstaFillAnno
                         STBXPP_IDLI_IDLLocalStatistic
                         stbx_localmean
                         stbx_localsddv
                         stbx_localcfvr
                         STBXPP_IDLI_IDLPcaGetInputPar
                         STBXPP_IDLI_IDLPcaFillAnno
                         stbx_first_pca
                         stbx_second_pca
                         STBXPP_IDLI_IDLSpckGetInputPar
                         STBXPP_IDLI_IDLSpckFillAnno
                         stbx_speckle
                         STBXPP_IDLI_IDLGainGetInputPar
                         STBXPP_IDLI_IDLGainFillAnno
                         stbx_gainconv
                         STBXPP_IDLI_IDLLutGetInputPar
                         STBXPP_IDLI_IDLLutFillAnno
                         stbx_lutconv
                         STBXPP_IDLI_IDLSclGetInputPar
                         STBXPP_IDLI_IDLSclFillAnno
                         stbx_sclconv
                         stbx_dump
                         stbx_help

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       01-OCT-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <limits.h>
#include <stdio.h>
#include <string.h>

#include "libname.h"

#define STBX_IDLI_GLBL STBX_IDLI_GLBL

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include IDLI_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include SRVS_INTF_H
#include COOR_INTF_H
#include IANN_INTF_H
#include IRES_INTF_H
#include SPKF_INTF_H
#include CONV_INTF_H
#include STAT_INTF_H
#include STBX_IDLI_H
#include STBX_INTF_H

#if defined(__WIN95__) && defined(__CODEWARRIOR__)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetImage

        $TYPE         PROCEDURE

        $INPUT        descr     : descriptor of the IDL array

        $MODIFIED     NONE

        $OUTPUT       ima_p     : pointer to the image
                      nrows     : number of rows of the array
                      ncols     : number of columns of the array
                      data_type : type of the IDL array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      

        $DESCRIPTION  This procedure extracts the dimensions and the data type
                      of an IDL 2-dimensional array

        $WARNING      NONE

        $PDL          - Checks the IDL object is an array
                      - Checks that the array dimensions are two
                      - Fills the image pointer to the first data element
                      - Fills rows and columns dimensions
                      - Fills the array type

   $EH
   ========================================================================== */
void STBXPP_IDLI_GetImage
                        (/*IN    */ IDL_VPTR             descr,
                         /*   OUT*/ void               **ima_p,
                         /*   OUT*/ UINTx4              *nrows,
                         /*   OUT*/ UINTx4              *ncols,
                         /*   OUT*/ LDEFIT_data_type    *data_type,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_GetImage";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                   err_msg[ 256 ];
   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check that the array is actually an array
   ========================================================================== */
   if ( !( ( descr->flags & IDL_V_ARR ) &&            /* it's an array */
           ( !( descr->flags & IDL_V_FILE ) ) &&      /* it's not a file */
           ( !( descr->flags & IDL_V_STRUCT ) ) ) ) { /* it's not a structure */
      sprintf( err_msg, "%s is not an array", name );
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param, err_msg );
   }

/* ==========================================================================
   Check the array dimensions
   ========================================================================== */
   if ( ((descr->value).arr)->n_dim > 2 ) {
      sprintf( err_msg, "%s has an erroneous number of dimensions", name );
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param, err_msg );
   }

/* ==========================================================================
   Point to the image first pixel
   ========================================================================== */
   *ima_p = (void *)(((descr->value).arr)->data);

/* ==========================================================================
   Fill the array dimensions
   ========================================================================== */
   if ( ((descr->value).arr)->n_dim == 1 ) {
      *nrows = 1;                                       /* number of rows */
      *ncols = (UINTx4)((descr->value).arr)->dim[ 0 ];  /* and columns */
   }
   else if ( ((descr->value).arr)->n_dim == 2 ) {
      *nrows = (UINTx4)((descr->value).arr)->dim[ 1 ];  /* number of rows */
      *ncols = (UINTx4)((descr->value).arr)->dim[ 0 ];  /* and columns */
   }


/* ==========================================================================
   Search the kind of array
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:
         sprintf( err_msg, "%s has an undefined type", name );
         ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param, err_msg );
      case IDL_TYP_BYTE:
         *data_type = LDEFIE_dt_UINTx1;
         break;
      case IDL_TYP_INT: {
         INTx4                  i;
         INTx4                  j;
         INTx2                 *p;

/* ==========================================================================
   Real data
   Check that they are unsigned int
   ========================================================================== */

         /* point to the first data value */
         p = (INTx2 *)(((descr->value).arr)->data);

         for ( i=0;i<*nrows;i++ ) {
            for ( j=0;j<*ncols;j++ ) {

               if ( (float)p[ i * *ncols + j ] < 0. ) {
                  sprintf( err_msg, "%s is not real (has negative values)", 
                           name );
                  ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param, 
                                     err_msg );
               }
            }
         }

         /* set the data type */
         *data_type = LDEFIE_dt_UINTx2;
         }
         break;
      case IDL_TYP_FLOAT:
         *data_type = LDEFIE_dt_float;
         break;
      case IDL_TYP_COMPLEX:
         *data_type = LDEFIE_dt_2_float;
         break;
      default:
         sprintf( err_msg, "%s has a type not allowable", name );
         ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param, err_msg );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_GetImage */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetArray

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
                      out_type : flag to indicate which type of output array
                                 must be passed
        $MODIFIED     NONE

        $OUTPUT       n_elem   : number of array elements
                      array_p  : pointer to the array of parameters

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure extracts from an IDL object an array of
                      values

        $WARNING      NONE

        $PDL          - Checks if the array is a true array
                      - Checks the array dimension
                      - Fills the array elements
                      - Switches among the various data type
                            - Converts the array into the wanted array type
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_GetArray
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx1               out_type,
                         /*   OUT*/ UINTx4              *n_elem,
                         /*   OUT*/ void               **array_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_GetArray";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   char                   err_msg[ 256 ];
   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check if it is not an array of numbers
   ========================================================================== */
   if ( !( ( descr->flags & IDL_V_ARR ) &&            /* it's an array */
           ( !( descr->flags & IDL_V_FILE ) ) &&      /* it's not a file */
           ( !( descr->flags & IDL_V_STRUCT ) ) ) ) { /* it's not a structure */
      ERRSIM_set_error ( status_code, ERRSID_STBX_not_arr_par, name );
   }

/* ==========================================================================
   Check the array dimensions
   ========================================================================== */
   if ( ((descr->value).arr)->n_dim != 1 ) {
      sprintf( err_msg, "%s has an erroneous number of dimensions", name );
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param, err_msg );
   }

/* ==========================================================================
   Fill the number of elements
   ========================================================================== */
   *n_elem = (UINTx4)((descr->value).arr)->n_elts;

/* ==========================================================================
   Switch WRT the output array type
   ========================================================================== */
   switch ( out_type ) {
      case DATA_TYPE_INTx2:

/* ==========================================================================
   Allocate the necessary memory to store the array
   ========================================================================== */
         if ( ( *array_p = (INTx2 *)
                   MEMSIP_alloc ( (size_t)((*n_elem) * sizeof ( INTx2 ) ) ) ) ==
                 (INTx2 *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc, name );
         }

/* ==========================================================================
   Convert it
   ========================================================================== */
         STBXPP_IDLI_IDLArray2INTx2 ( descr, *n_elem, (INTx2 *)(*array_p),
                                      status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case DATA_TYPE_INTx4:

/* ==========================================================================
   Allocate the necessary memory
   ========================================================================== */
         if ( ( *array_p = (INTx4 *)
                   MEMSIP_alloc ( (size_t)((*n_elem) * sizeof (INTx4) ) ) ) ==
                 (INTx2 *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc, name );
         }

/* ==========================================================================
   Convert it
   ========================================================================== */
         STBXPP_IDLI_IDLArray2INTx4 ( descr, *n_elem, (INTx4 *)(*array_p),
                                      status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case DATA_TYPE_UINTx2:

/* ==========================================================================
   Allocate the memory
   ========================================================================== */
         if ( ( *array_p = (UINTx2 *)
                   MEMSIP_alloc ( (size_t)((*n_elem) * sizeof ( UINTx2) ) ) ) ==
                 (UINTx2 *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc, name );
         }

/* ==========================================================================
   Convert it
   ========================================================================== */
         STBXPP_IDLI_IDLArray2UINTx2 ( descr, *n_elem, (UINTx2 *)(*array_p),
                                      status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case DATA_TYPE_UINTx4:

/* ==========================================================================
   Allocate the memory
   ========================================================================== */
         if ( ( *array_p = (UINTx4 *)
                   MEMSIP_alloc ( (size_t)((*n_elem) * sizeof ( UINTx4) ) ) ) ==
                 (UINTx4 *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc, name );
         }

/* ==========================================================================
   Convert it
   ========================================================================== */
         STBXPP_IDLI_IDLArray2UINTx4 ( descr, *n_elem, (UINTx4 *)(*array_p),
                                       status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case DATA_TYPE_float:

/* ==========================================================================
   Allocate the memory
   ========================================================================== */
         if ( ( *array_p = (float *)
                   MEMSIP_alloc ( (size_t)((*n_elem) * sizeof ( float ) ) ) ) ==
                 (float *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc, name );
         }

/* ==========================================================================
   Convert it
   ========================================================================== */
         STBXPP_IDLI_IDLArray2float ( descr, *n_elem, (float *)(*array_p),
                                      status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case DATA_TYPE_double:

/* ==========================================================================
   Allocate the memory
   ========================================================================== */
         if ( ( *array_p = (double *)
                   MEMSIP_alloc ( (size_t)((*n_elem) * sizeof ( double ) ) ) ) ==
                 (double *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc, name );
         }

/* ==========================================================================
   Convert it
   ========================================================================== */
         STBXPP_IDLI_IDLArray2double( descr, *n_elem, (double *)(*array_p),
                                      status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
   }

error_exit:;

/* ==========================================================================
   Free the allocated memories if any
   ========================================================================== */
   if ( *status_code != ERRSID_normal ) {
      MEMSIP_free ( (void **)array_p );
   }

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_GetArray */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetParValue

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
                      out_type : flag to indicate which type of output variable
                                 must be passed
        $MODIFIED     NONE

        $OUTPUT       value    : output parameter value

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure extract from the IDL descriptor of each
                      parameter it's value if it isn't an array

        $WARNING      NONE

        $PDL          - Checks that the variable is not an array
                      - Switch among the various possible output data type

   $EH
   ========================================================================== */

void STBXPP_IDLI_GetParValue
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx1               out_type,
                         /*IN OUT*/ void                *value,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_GetParValue";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check it is not an array
   ========================================================================== */
   if ( ( descr->flags & IDL_V_ARR ) ||
        ( descr->flags & IDL_V_FILE ) ||
        ( descr->flags & IDL_V_STRUCT ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_arr_par, name );
   }

/* ==========================================================================
   Switch WRT the output type
   ========================================================================== */
   switch ( out_type ) {
      case DATA_TYPE_INTx2:
         STBXPP_IDLI_IDLVar2INTx2 ( descr, (INTx2 *)value, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case DATA_TYPE_INTx4:
         STBXPP_IDLI_IDLVar2INTx4 ( descr, (INTx4 *)value, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case DATA_TYPE_UINTx2:
         STBXPP_IDLI_IDLVar2UINTx2 ( descr, (UINTx2 *)value, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case DATA_TYPE_UINTx4:
         STBXPP_IDLI_IDLVar2UINTx4 ( descr, (UINTx4 *)value, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case DATA_TYPE_float:
         STBXPP_IDLI_IDLVar2float ( descr, (float *)value, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      case DATA_TYPE_double:
         STBXPP_IDLI_IDLVar2double ( descr, (double *)value, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      default:
         ERRSIM_set_error( status_code, ERRSID_STBX_par_type_not_all, name );
   }
 
error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_GetParValue */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetString

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
        $MODIFIED     NONE

        $OUTPUT       value    : output parameter value

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure extract from the IDL descriptor of each
                      parameter it's string value

        $WARNING      value should be ALLOCATED

        $PDL          - Checks that the variable is not an array

   $EH
   ========================================================================== */

void STBXPP_IDLI_GetString
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ char                *value,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_GetString";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check it is not an array
   ========================================================================== */
   if ( ( descr->flags & IDL_V_ARR ) ||
        ( descr->flags & IDL_V_FILE ) ||
        ( descr->flags & IDL_V_STRUCT ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_arr_par, name );
   }

/* ==========================================================================
   Print string
   ========================================================================== */
   if( descr->type == IDL_TYP_STRING ) {
      sprintf( value, "%s", IDL_STRING_STR( &(descr->value.str) ) );
   }
   else {
      ERRSIM_set_error( status_code, ERRSID_STBX_par_type_not_all, name );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_GetString */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetParAddress

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
                      out_type : flag to indicate which type of output variable
                                 must be passed
        $MODIFIED     NONE

        $OUTPUT       address  : output parameter address

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_par_type_not_all
                      ERRSID_STBX_par_flag_not_all

        $DESCRIPTION  This procedure extract from the IDL descriptor of each
                      parameter its address if it isn't an array

        $WARNING      NONE

        $PDL          - Checks that the variable is not an array
                      - Switch among the various possible output data type

   $EH
   ========================================================================== */
void STBXPP_IDLI_GetParAddress
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx1               out_type,
                         /*IN OUT*/ void               **address,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_GetParAddress";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check it is not an array, a file or a structure
   ========================================================================== */
   if ( ( descr->flags & IDL_V_ARR ) ||
        ( descr->flags & IDL_V_FILE ) ||
        ( descr->flags & IDL_V_STRUCT ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_arr_par, name );
   }

/* ==========================================================================
   Check it is not a constant
   ========================================================================== */
   if( descr->flags & IDL_V_CONST ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_par_flag_not_all, name );
   }

/* ==========================================================================
   Switch WRT the output type
   ========================================================================== */
   switch ( out_type ) {
      case DATA_TYPE_INTx2:
	 descr->type = IDL_TYP_INT;
	 *address = &((descr->value).i);
	 break;
      case DATA_TYPE_INTx4:
	 descr->type = IDL_TYP_LONG;
	 *address = &((descr->value).l);
	 break;
      case DATA_TYPE_float:
	 descr->type = IDL_TYP_FLOAT;
	 *address = &((descr->value).f);
	 break;
      case DATA_TYPE_double:
	 descr->type = IDL_TYP_DOUBLE;
	 *address = &((descr->value).d);
	 break;
      case DATA_TYPE_UINTx2:
      case DATA_TYPE_UINTx4:
      default:
	 ERRSIM_set_error ( status_code, ERRSID_STBX_par_type_not_all, name );
   }
 
error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_GetParAddress */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetArrayAddress

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
                      out_type : flag to indicate which type of output array
                                 must be passed
        $MODIFIED     NONE

        $OUTPUT       n_elem   : number of array elements
                      array_p  : pointer to the array of parameters

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure extracts from an IDL object an array of
                      values

        $WARNING      NONE

        $PDL          - Checks if the array is a true array
                      - Checks the array dimension
                      - Set array_p to the address of the array

   $EH
   ========================================================================== */
void STBXPP_IDLI_GetArrayAddress
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx1               out_type,
                         /*   OUT*/ UINTx4              *n_elem,
                         /*   OUT*/ void               **array_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_GetArrayAddress";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                   err_msg[ 256 ];
   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check if it is not an array of numbers
   ========================================================================== */
   if ( !( ( descr->flags & IDL_V_ARR ) &&            /* it's an array */
           ( !( descr->flags & IDL_V_FILE ) ) &&      /* it's not a file */
           ( !( descr->flags & IDL_V_STRUCT ) ) ) ) { /* it's not a structure */
      ERRSIM_set_error ( status_code, ERRSID_STBX_par_type_not_all, name );
   }

/* ==========================================================================
   Check the array dimensions
   ========================================================================== */
   if ( ((descr->value).arr)->n_dim != 1 ) {
      sprintf( err_msg, "%s does not have 1 dimension", name );
      ERRSIM_set_error (  status_code, ERRSID_STBX_inv_inp_param, err_msg );
   }

/* ==========================================================================
   Fill the number of elements
   ========================================================================== */
   *n_elem = (UINTx4)((descr->value).arr)->n_elts;

   *array_p = ((descr->value).arr)->data;

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_GetArrayAddress */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_CreateArray

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
                      out_type : flag to indicate which type of output array
                                 must be passed
        $MODIFIED     NONE

        $OUTPUT       n_elem   : number of array elements
                      array_p  : pointer to the array of parameters

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure create an IDL array of values whose
                      data points to array_p

        $WARNING      NONE

        $PDL          - Create the array
                      - Set array_p to the address of the array

   $EH
   ========================================================================== */
void STBXPP_IDLI_CreateArray
                        (/*IN    */ IDL_VPTR            *descr,
                         /*IN    */ LDEFIT_data_type     out_type,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ void               **array_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_CreateArray";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   IDL_LONG               dim[ IDL_MAX_ARRAY_DIM ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set the dimension
   ========================================================================== */
   dim[ 0 ] = (IDL_LONG) n_elem;

/* ==========================================================================
   Switch WRT the output type
   ========================================================================== */
   switch ( out_type ) {
      case LDEFIE_dt_UINTx1:
         *array_p = (void *) IDL_MakeTempArray( IDL_TYP_BYTE, 1, dim,
                                                IDL_BARR_INI_ZERO, descr );
	 break;

      case LDEFIE_dt_INTx2:
         *array_p = (void *) IDL_MakeTempArray( IDL_TYP_INT, 1, dim,
                                                IDL_BARR_INI_ZERO, descr );
	 break;

      case LDEFIE_dt_INTx4:
         *array_p = (void *) IDL_MakeTempArray( IDL_TYP_LONG, 1, dim,
                                                IDL_BARR_INI_ZERO, descr );
	 break;

      case LDEFIE_dt_float:
         *array_p = (void *) IDL_MakeTempArray( IDL_TYP_FLOAT, 1, dim,
                                                IDL_BARR_INI_ZERO, descr );
	 break;

      case LDEFIE_dt_2_float:
         *array_p = (void *) IDL_MakeTempArray( IDL_TYP_COMPLEX, 1, dim,
                                                IDL_BARR_INI_ZERO, descr );
	 break;

      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_UINTx4:
      default:
	 ERRSIM_set_error ( status_code, ERRSID_STBX_par_type_not_all, "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_CreateArray */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_CreateMatrix

        $TYPE         PROCEDURE

        $INPUT        descr       : IDL structure describing the parameter
                                    properties
                      out_type    : flag to indicate which type of output array
                                    must be passed
        $MODIFIED     NONE

        $OUTPUT       row_n_elem  : number of array row elements
                      col_n_elem  : number of array columns elements
                      array_p     : pointer to the array of parameters

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure create an IDL matrix of values whose
                      data points to array_p

        $WARNING      NONE

        $PDL          - Create the array
                      - Set array_p to the address of the array

   $EH
   ========================================================================== */
void STBXPP_IDLI_CreateMatrix
                        (/*IN    */ IDL_VPTR            *descr,
                         /*IN    */ LDEFIT_data_type     out_type,
                         /*IN    */ UINTx4               row_n_elem,
                         /*IN    */ UINTx4               col_n_elem,
                         /*   OUT*/ void               **array_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_CreateMatrix";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   IDL_LONG               dim[ IDL_MAX_ARRAY_DIM ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* =========================================================== ==============
   Set the dimension
   ========================================================================== */
   dim[ 0 ] = (IDL_LONG) col_n_elem;
   dim[ 1 ] = (IDL_LONG) row_n_elem;

/* ==========================================================================
   Switch WRT the output type
   ========================================================================== */
   switch ( out_type ) {
      case LDEFIE_dt_UINTx1:
         *array_p = (void *) IDL_MakeTempArray( IDL_TYP_BYTE, 2, dim,
                                                IDL_BARR_INI_ZERO, descr );
	 break;

      case LDEFIE_dt_INTx2:
         *array_p = (void *) IDL_MakeTempArray( IDL_TYP_INT, 2, dim,
                                                IDL_BARR_INI_ZERO, descr );
	 break;

      case LDEFIE_dt_INTx4:
         *array_p = (void *) IDL_MakeTempArray( IDL_TYP_LONG, 2, dim,
                                                IDL_BARR_INI_ZERO, descr );
	 break;

      case LDEFIE_dt_float:
         *array_p = (void *) IDL_MakeTempArray( IDL_TYP_FLOAT, 2, dim,
                                                IDL_BARR_INI_ZERO, descr );
	 break;

      case LDEFIE_dt_2_float:
         *array_p = (void *) IDL_MakeTempArray( IDL_TYP_COMPLEX, 2, dim,
                                                IDL_BARR_INI_ZERO, descr );
	 break;

      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_UINTx4:
      default:
	 ERRSIM_set_error ( status_code, ERRSID_STBX_par_type_not_all, "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_CreateMatrix */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2INTx2

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into an INTx2 one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to INTx2 if possible
                      - End switch

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLVar2INTx2
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ INTx2               *var,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLVar2INTx2";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Switch on input data type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:
         ERRSIM_set_error ( status_code, ERRSID_STBX_undef_par_type, name );
      case IDL_TYP_BYTE:
         *var = (INTx2)(descr->value.c);
      break;
      case IDL_TYP_INT:
         *var = (INTx2)(descr->value.i);
      break;
      case IDL_TYP_LONG:
         if ( ( descr->value.l < (float)SHRT_MIN ) ||
              ( descr->value.l > (float)SHRT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (INTx2)(descr->value.l);
      break;
      case IDL_TYP_FLOAT: {
         if ( ( descr->value.f < (float)SHRT_MIN ) ||
              ( descr->value.f > (float)SHRT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (INTx2)(descr->value.f);
      }
      break;
      case IDL_TYP_DOUBLE: {
         if ( ( descr->value.d < (float)SHRT_MIN ) ||
              ( descr->value.d > (float)SHRT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (INTx2)(descr->value.d);
      }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_par_type_not_all, name );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_IDLVar2INTx2 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2INTx4

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into an INTx4 one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to INTx4 if possible
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLVar2INTx4
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ INTx4               *var,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLVar2INTx4";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Switch on input data type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:
         ERRSIM_set_error ( status_code, ERRSID_STBX_undef_par_type, name );
      case IDL_TYP_BYTE:
         *var = (INTx4)(descr->value.c);
      break;
      case IDL_TYP_INT:
         *var = (INTx4)(descr->value.i);
      break;
      case IDL_TYP_LONG:
         if ( ( descr->value.l < (float)INT_MIN ) ||
              ( descr->value.l > (float)INT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (INTx4)(descr->value.l);
      break;
      case IDL_TYP_FLOAT: {
         if ( ( descr->value.f < (float)INT_MIN ) ||
              ( descr->value.f > (float)INT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (INTx4)(descr->value.f);
      }
      break;
      case IDL_TYP_DOUBLE: {
         if ( ( descr->value.d < (float)SHRT_MIN ) ||
              ( descr->value.d > (float)SHRT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (INTx4)(descr->value.d);
      }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_par_type_not_all, name );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_IDLVar2INTx4 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2UINTx2

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into an UINTx2 one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to UINTx2 if possible
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLVar2UINTx2
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ UINTx2              *var,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLVar2UINTx2";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Switch on input data type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:
         ERRSIM_set_error ( status_code, ERRSID_STBX_undef_par_type, name );
      case IDL_TYP_BYTE:
         *var = (UINTx2)(descr->value.c);
      break;
      case IDL_TYP_INT:
         *var = (UINTx2)(descr->value.i);
      break;
      case IDL_TYP_LONG:
         if ( ( descr->value.l < (float)SHRT_MIN ) ||
              ( descr->value.l > (float)USHRT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (UINTx2)(descr->value.l);
      break;
      case IDL_TYP_FLOAT: {
         if ( ( descr->value.f < (float)SHRT_MIN ) ||
              ( descr->value.f > (float)USHRT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (UINTx2)(descr->value.f);
      }
      break;
      case IDL_TYP_DOUBLE: {
         if ( ( descr->value.d < (float)SHRT_MIN ) ||
              ( descr->value.d > (float)SHRT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (UINTx2)(descr->value.d);
      }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_par_type_not_all, name );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_IDLVar2UINTx2 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2UINTx4

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into an UINTx4 one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to UINTx4 if possible
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLVar2UINTx4
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ UINTx4              *var,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLVar2UINTx4";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Switch on input data type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:
         ERRSIM_set_error ( status_code, ERRSID_STBX_undef_par_type, name );
      case IDL_TYP_BYTE:
         *var = (UINTx4)(descr->value.c);
      break;
      case IDL_TYP_INT:
         *var = (UINTx4)(descr->value.i);
      break;
      case IDL_TYP_LONG:
         if ( ( descr->value.l < (float)INT_MIN ) ||
              ( descr->value.l > (float)UINT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (UINTx4)(descr->value.l);
      break;
      case IDL_TYP_FLOAT: {
         if ( ( descr->value.f < (float)INT_MIN ) ||
              ( descr->value.f > (float)UINT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (UINTx4)(descr->value.f);
      }
      break;
      case IDL_TYP_DOUBLE: {
         if ( ( descr->value.d < (float)SHRT_MIN ) ||
              ( descr->value.d > (float)SHRT_MAX ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow, name );
         }
         *var = (INTx4)(descr->value.d);
      }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_par_type_not_all, name );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_IDLVar2UINTx4 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2float

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into an float one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to float if possible
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLVar2float
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ float               *var,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLVar2float";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Switch on input data type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:
         ERRSIM_set_error ( status_code, ERRSID_STBX_undef_par_type, name );
      case IDL_TYP_BYTE:
         *var = (float)(descr->value.c);
      break;
      case IDL_TYP_INT:
         *var = (float)(descr->value.i);
      break;
      case IDL_TYP_LONG:
         *var = (float)(descr->value.l);
      break;
      case IDL_TYP_FLOAT: {
         *var = descr->value.f;
      }
      break;
      case IDL_TYP_DOUBLE: {
         *var = (float)(descr->value.d);
      }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_par_type_not_all, name );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_IDLVar2float */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2double

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into a double one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to double if possible
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLVar2double
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ double              *var,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLVar2double";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Switch on input data type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:
         ERRSIM_set_error ( status_code, ERRSID_STBX_undef_par_type, name );
      case IDL_TYP_BYTE:
         *var = (double)(descr->value.c);
      break;
      case IDL_TYP_INT:
         *var = (double)(descr->value.i);
      break;
      case IDL_TYP_LONG:
         *var = (double)(descr->value.l);
      break;
      case IDL_TYP_FLOAT: {
         *var = (double)(descr->value.f);
      }
      break;
      case IDL_TYP_DOUBLE: {
         *var = descr->value.d;
      }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_par_type_not_all, name );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_IDLVar2double */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2INTx2

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type INTx2

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLArray2INTx2
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ INTx2               *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLArray2INTx2";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *name;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   UINTx4                 el;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check the number of elements of the array
   ========================================================================== */
   if ( ( n_elem <= 0 ) || ( n_elem > (UINTx4)((descr->value).arr)->n_elts ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_n_elem_out_of_range, name );
   }

/* ==========================================================================
   Switch WRT the array type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:

/* ==========================================================================
   Undefined array type
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "the array has an undefined type" );
      case IDL_TYP_BYTE:

/* ==========================================================================
   Convert from byte to INTx2
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (INTx2)((UINTx1 *)((descr->value).arr)->data)[ el ];
         }
      break;
      case IDL_TYP_INT:

/* ==========================================================================
   Copy itself
   ========================================================================== */
         memcpy ( (void *)arr_p, ((descr->value).arr)->data,
                  (size_t)(n_elem * sizeof ( INTx2 ) ) );
      break;
      case IDL_TYP_LONG:

/* ==========================================================================
   Convert from long into INTx2
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            if ( ( ((INTx4 *)(((descr->value).arr)->data))[ el ] <
                   (INTx4)INT_MIN ) ||
                 ( ((INTx4 *)(((descr->value).arr)->data))[ el ] >
                   (INTx4)INT_MAX ) ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                                  "for the given array" );
            }
            arr_p[ el ] = (INTx2)((INTx4 *)(((descr->value).arr)->data))[ el ];
         }
      break;
      case IDL_TYP_FLOAT:

/* ==========================================================================
   Convert from float into INTx2
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            if ( ( ((float *)(((descr->value).arr)->data))[ el ] <
                   (float)INT_MIN ) ||
                 ( ((float *)(((descr->value).arr)->data))[ el ] >
                   (float)INT_MAX ) ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                                  "for the given array" );
            }
            arr_p[ el ] = (INTx2)((float *)(((descr->value).arr)->data))[ el ];
         }
      break;
      case IDL_TYP_DOUBLE:

/* ==========================================================================
   From double
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            if ( ( ((double *)(((descr->value).arr)->data))[ el ] <
                   (double)INT_MIN ) ||
                 ( ((double *)(((descr->value).arr)->data))[ el ] >
                   (double)INT_MAX ) ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                                  "for the given array" );
            }
            arr_p[ el ] = (INTx2)((double *)(((descr->value).arr)->data))[ el ];
         }
      break;
      default:

/* ==========================================================================
   No conversion
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                            "for the given array" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_IDLI_IDLArray2INTx2 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2INTx4

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type INTx4

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLArray2INTx4
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ INTx4               *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLArray2INTx4";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   UINTx4                 el;
   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check the number of elements of the array
   ========================================================================== */
   if ( ( n_elem <= 0 ) || ( n_elem > (UINTx4)((descr->value).arr)->n_elts ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_n_elem_out_of_range, name );
   }

/* ==========================================================================
   Switch WRT the array type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:

/* ==========================================================================
   Undefined array type
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "the array has an undefined type" );
      case IDL_TYP_BYTE:

/* ==========================================================================
   Convert from byte to INTx4
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (INTx4)((UINTx1 *)((descr->value).arr)->data)[ el ];
         }
      break;
      case IDL_TYP_INT:

/* ==========================================================================
   from INTx2
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (INTx4)((INTx2 *)((descr->value).arr)->data)[ el ];
         }
      break;
      case IDL_TYP_LONG:

/* ==========================================================================
   From long
   ========================================================================== */
         memcpy ( (void *)arr_p, ((descr->value).arr)->data,
                  (size_t)(n_elem * sizeof ( INTx4 ) ) );
      break;
      case IDL_TYP_FLOAT:

/* ==========================================================================
   From float
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            if ( ( ((float *)(((descr->value).arr)->data))[ el ] <
                   (float)LONG_MIN ) ||
                 ( ((float *)(((descr->value).arr)->data))[ el ] >
                   (float)LONG_MAX ) ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                                  "for the given array" );
            }
            arr_p[ el ] = (INTx4)((float *)(((descr->value).arr)->data))[ el ];
         }
      break;
      case IDL_TYP_DOUBLE:

/* ==========================================================================
   From double
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            if ( ( ((double *)(((descr->value).arr)->data))[ el ] <
                   (double)LONG_MIN ) ||
                 ( ((double *)(((descr->value).arr)->data))[ el ] >
                   (double)LONG_MAX ) ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                                  "for the given array" );
            }
            arr_p[ el ] = (INTx4)((double *)(((descr->value).arr)->data))[ el ];
         }
      break;
      default:

/* ==========================================================================
   No conversion
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                            "for the given array" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_IDLI_IDLArray2INTx4 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2UINTx2

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type UINTx2

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLArray2UINTx2
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ UINTx2              *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLArray2UINTx2";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   UINTx4                 el;
   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check the number of elements of the array
   ========================================================================== */
   if ( ( n_elem <= 0 ) || ( n_elem > (UINTx4)((descr->value).arr)->n_elts ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_n_elem_out_of_range, name );
   }

/* ==========================================================================
   Switch WRT the array type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:

/* ==========================================================================
   Undefined array type
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "the array has an undefined type" );
      case IDL_TYP_BYTE:

/* ==========================================================================
   Convert from byte to UINTx2
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (UINTx2)((UINTx1 *)((descr->value).arr)->data)[ el ];
         }
      break;
      case IDL_TYP_INT:

/* ==========================================================================
   Copy itself if it is possible
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            if ( ((INTx2 *)((descr->value).arr)->data)[ el ] < 0 ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                                  "for the given array" );
            }
            arr_p[ el ] = (UINTx2)((INTx2 *)((descr->value).arr)->data)[ el ];
         }
      break;
      case IDL_TYP_LONG:

/* ==========================================================================
   Convert from long
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            if ( ( ((INTx4 *)(((descr->value).arr)->data))[ el ] <
                   (INTx4)INT_MIN ) ||
                 ( ((INTx4 *)(((descr->value).arr)->data))[ el ] >
                   (INTx4)UINT_MAX ) ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                                  "for the given array" );
            }
            arr_p[ el ] = (UINTx2)((INTx4 *)(((descr->value).arr)->data))[ el ];
         }
      break;
      case IDL_TYP_FLOAT:

/* ==========================================================================
   Convert from float into UINTx2
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            if ( ( ((float *)(((descr->value).arr)->data))[ el ] <
                   (float)INT_MIN ) ||
                 ( ((float *)(((descr->value).arr)->data))[ el ] >
                   (float)UINT_MAX ) ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                                  "for the given array" );
            }
            arr_p[ el ] = (UINTx2)((float *)(((descr->value).arr)->data))[ el ];
         }
      break;
      case IDL_TYP_DOUBLE:

/* ==========================================================================
   From double
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            if ( ( ((double *)(((descr->value).arr)->data))[ el ] <
                   (double)INT_MIN ) ||
                 ( ((double *)(((descr->value).arr)->data))[ el ] >
                   (double)UINT_MAX ) ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                                  "for the given array" );
            }
            arr_p[ el ] = (UINTx2)
               ((double *)(((descr->value).arr)->data))[ el ];
         }
      break;
      default:

/* ==========================================================================
   No conversion
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                            "for the given array" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_IDLI_IDLArray2UINTx2 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2UINTx4

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type UINTx4

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLArray2UINTx4
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ UINTx4              *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLArray2UINTx4";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   UINTx4                 el;
   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check the number of elements of the array
   ========================================================================== */
   if ( ( n_elem <= 0 ) || ( n_elem > (UINTx4)((descr->value).arr)->n_elts ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_n_elem_out_of_range, name );
   }

/* ==========================================================================
   Switch WRT the array type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:

/* ==========================================================================
   Undefined array type
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "the array has an undefined type" );
      case IDL_TYP_BYTE:

/* ==========================================================================
   Convert from byte to UINTx4
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (UINTx4)((UINTx1 *)((descr->value).arr)->data)[ el ];
         }
      break;
      case IDL_TYP_INT:

/* ==========================================================================
   from INTx2
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (UINTx4)((INTx2 *)((descr->value).arr)->data)[ el ];
         }
      break;
      case IDL_TYP_LONG:

/* ==========================================================================
   From long
   ========================================================================== */
         memcpy ( (void *)arr_p, ((descr->value).arr)->data,
                  (size_t)(n_elem * sizeof ( UINTx4 ) ) );
      break;
      case IDL_TYP_FLOAT:

/* ==========================================================================
   From float
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            if ( ( ((float *)(((descr->value).arr)->data))[ el ] <
                   (float)LONG_MIN ) ||
                 ( ((float *)(((descr->value).arr)->data))[ el ] >
                   (float)ULONG_MAX ) ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                                  "for the given array" );
            }
            arr_p[ el ] = (UINTx4)((float *)(((descr->value).arr)->data))[ el ];
         }
      break;
      case IDL_TYP_DOUBLE:

/* ==========================================================================
   From double
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            if ( ( ((double *)(((descr->value).arr)->data))[ el ] <
                   (double)LONG_MIN ) ||
                 ( ((double *)(((descr->value).arr)->data))[ el ] >
                   (double)ULONG_MAX ) ) {
               ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                                  "for the given array" );
            }
            arr_p[ el ] = (UINTx4)
               ((double *)(((descr->value).arr)->data))[ el ];
         }
      break;
      default:

/* ==========================================================================
   No conversion
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                            "for the given array" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_IDLArray2UINTx4 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2float

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type float

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLArray2float
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ float               *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLArray2float";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   UINTx4                 el;
   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check the number of elements of the array
   ========================================================================== */
   if ( ( n_elem <= 0 ) || ( n_elem > (UINTx4)((descr->value).arr)->n_elts ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_n_elem_out_of_range, name );
   }

/* ==========================================================================
   Switch WRT the array type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:

/* ==========================================================================
   Undefined array type
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "the array has an undefined type" );
      case IDL_TYP_BYTE:

/* ==========================================================================
   Convert from byte to float
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (float)((UINTx1 *)(((descr->value).arr)->data))[ el ];
         }
      break;
      case IDL_TYP_INT:

/* ==========================================================================
   from INTx2
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (float) ((INTx2 *)(((descr->value).arr)->data))[ el ];
         }
      break;
      case IDL_TYP_LONG:
/* ==========================================================================
   From long
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (float) ((INTx4 *)(((descr->value).arr)->data))[ el ];
         }
      break;
      case IDL_TYP_FLOAT:

/* ==========================================================================
   From float
   ========================================================================== */
         memcpy ( (void *)arr_p, ((descr->value).arr)->data,
                  (size_t)( n_elem * sizeof ( float ) ) );
      break;
      case IDL_TYP_DOUBLE:

/* ==========================================================================
   From double
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (float)
               ((double *)(((descr->value).arr)->data))[ el ];
         }
      break;
      default:

/* ==========================================================================
   No conversion
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                            "for the given array" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_IDLArray2float */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2double

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type double

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLArray2double
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ double              *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLArray2double";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   UINTx4                 el;
   char                  *name;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get the name of the variable
   ========================================================================== */
   name = IDL_VarName( descr );

/* ==========================================================================
   Check the number of elements of the array
   ========================================================================== */
   if ( ( n_elem <= 0 ) || ( n_elem > (UINTx4)((descr->value).arr)->n_elts ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_n_elem_out_of_range, name );
   }

/* ==========================================================================
   Switch WRT the array type
   ========================================================================== */
   switch ( descr->type ) {
      case IDL_TYP_UNDEF:

/* ==========================================================================
   Undefined array type
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "the array has an undefined type" );
      case IDL_TYP_BYTE:

/* ==========================================================================
   Convert from byte to double
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (double)((UINTx1 *)(((descr->value).arr)->data))[ el ];
         }
      break;
      case IDL_TYP_INT:

/* ==========================================================================
   from INTx2
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (double) ((INTx2 *)(((descr->value).arr)->data))[ el ];
         }
      break;

      case IDL_TYP_LONG:
/* ==========================================================================
   From long
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (double) ((INTx4 *)(((descr->value).arr)->data))[ el ];
         }
      break;

      case IDL_TYP_FLOAT:

/* ==========================================================================
   From float
   ========================================================================== */
         for ( el=0;el<n_elem;el++ ) {
            arr_p[ el ] = (double) ((float *)(((descr->value).arr)->data))[ el ];
         }
      break;

      case IDL_TYP_DOUBLE:

/* ==========================================================================
   From double
   ========================================================================== */
         memcpy ( (void *)arr_p, ((descr->value).arr)->data,
                  (size_t)( n_elem * sizeof ( double ) ) );
      break;

      default:

/* ==========================================================================
   No conversion
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_conv_not_allow,
                            "for the given array" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_IDLArray2double */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_oversampling

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             - InpIma       : pointer to the input image
                             - TLRow        : top left row of the zone of the
                                              input image to oversample
                             - TLCol        : top left column of the zone of
                                              the input image to oversample
                             - RangeSpacing : spacing in the range direction of
                                              the input image
                             - FdcPoly      : array with the values of the
                                              coefficients to evaluate the
                                              doppler centroide frequency
                             - PRF          : Pulse Repetition Frequency
                             - OutIma       : pointer to the buffer in which
                                              the output image will be stored

        $MODIFIED     NONE

        $OUTPUT       The output image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the oversampling
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_oversampling
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_RSMP";
#else
   const ERRSIT_proc_class proc_class   = "rsmp";
#endif
   const ERRSIT_proc_name routine_name = "stbx_oversampling";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   TIFF variables
   ========================================================================== */
   GIOSIT_io              inp_io;
   GIOSIT_io              tmp_io;
   GIOSIT_io              out_io;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   STBXPT_over_idl_par    idl_par;        /* structure with the input */
                                          /* parameters for the task  */
   UINTx4                 imanum = 0;     /* image number */
   void                  *inp_ima = (void *)NULL;    /* pointers to the input */
   void                  *out_ima = (void *)NULL;    /* and output images     */
   IDL_VPTR               idl_out_ima;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_resampling_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Set IDL dump
   ========================================================================== */
   ERRSIV_dump_to_idl = 1;

/* ==========================================================================
   Initialize the image annotations structure
   ========================================================================== */
   memset ( (void *)&IANNIV_ImageAnnot[ imanum ], 0,
            (size_t)sizeof( IANNIT_ImageAnnot ) );

/* ==========================================================================
   Initialize the input parameters structure
   ========================================================================== */
   memset ( (void *)&idl_par, 0, (size_t)(sizeof ( STBXPT_over_idl_par ) ) );

/* ==========================================================================
   Fill the input parameters structure
   ========================================================================== */
   STBXPP_IDLI_IDLOverGetInputPar ( npar, val, kw, &idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Set the type of the output image
   ========================================================================== */
   if( idl_par.InpDataType == LDEFIE_dt_2_float ) {
      idl_par.OutDataType = LDEFIE_dt_2_float;
   }
   else {
      idl_par.OutDataType = LDEFIE_dt_float;
   }
   
/* ==========================================================================
   Create the output image
   ========================================================================== */
   STBXPP_IDLI_CreateMatrix( &idl_out_ima,
                              idl_par.OutDataType,
                              idl_par.NRowsOut,
                              idl_par.NColsOut,
                              (void **) &(idl_par.out_ima),
                             &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Fill the image description structure
   ========================================================================== */
   STBXPP_IDLI_IDLOverFillAnno ( imanum, idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Initialize the input IO structure
   ========================================================================== */
   inp_io.type = GIOSIE_buffer;
   inp_io.mode = 'r';
   inp_io.val.buff.Buffer = idl_par.inp_ima;
   inp_io.val.buff.NRows = idl_par.NRowsInp;
   inp_io.val.buff.NColumns = idl_par.NColsInp;
   inp_io.val.buff.DataType = idl_par.InpDataType;

   GIOSIP_open_io( &inp_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Initialize the output IO structure
   ========================================================================== */
   out_io.type = GIOSIE_buffer;
   out_io.mode = 'w';
   out_io.val.buff.Buffer = idl_par.out_ima;
   out_io.val.buff.NRows = idl_par.NRowsOut;
   out_io.val.buff.NColumns = idl_par.NColsOut;
   out_io.val.buff.DataType = idl_par.OutDataType;

   GIOSIP_open_io( &out_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Initialize the temporary IO structure
   ========================================================================== */
   tmp_io.type = GIOSIE_buffer;
   tmp_io.mode = 'w';
   tmp_io.val.buff.NRows = idl_par.NRowsOut;
   tmp_io.val.buff.NColumns = idl_par.NColsInp;
   tmp_io.val.buff.DataType = LDEFIE_dt_2_float;

   if ( idl_par.NRowsOut > idl_par.NRowsInp ) {
      if ( idl_par.NColsOut > idl_par.NColsInp ) {
         tmp_io.val.buff.Buffer = 
            (void *) MEMSIP_alloc((size_t) idl_par.NRowsOut * idl_par.NColsInp *
                                           2 * sizeof(float) );
         GIOSIP_open_io( &tmp_io,
                         &status_code);
         ERRSIM_on_err_goto_exit( status_code );
      }
   }
   
/* ==========================================================================
   Call the image oversampling procedure
   ========================================================================== */
   IRESIP_OVER_Interpolate (&inp_io, imanum, (UINTx4)0,
                             (UINTx4)0, idl_par.NRowsInp, idl_par.NColsInp,
                            &out_io, idl_par.NRowsOut, idl_par.NColsOut, 
                            &tmp_io, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Close input
   ========================================================================== */
   GIOSIP_close_io( &inp_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close output 
   ========================================================================== */
   GIOSIP_close_io( &out_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close intermediate
   ========================================================================== */
   if ( idl_par.NRowsOut > idl_par.NRowsInp ) {
      if ( idl_par.NColsOut > idl_par.NColsInp ) {
         GIOSIP_close_io( &tmp_io,
                          &status_code);
         ERRSIM_on_err_goto_exit( status_code );
      }
   }

error_exit:;

/* ==========================================================================
   Free the allocated memory
   ========================================================================== */
   MEMSIP_free ( (void **)&(idl_par.FdcCoeff) );

   if ( idl_par.NRowsOut > idl_par.NRowsInp ) {
      if ( idl_par.NColsOut > idl_par.NColsInp ) {
         MEMSIP_free( (void **) &(tmp_io.val.buff.Buffer) );
      }
   }

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_ima );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_oversampling */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_kernelfiltering

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             - InpIma : pointer to the input image
                             - Kern   : pointer to the kernel matrix
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored

        $MODIFIED     NONE

        $OUTPUT       The output image is filled

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the undersampling
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Fills the input parameters structure
                      - Tests if the kernel matrix is a constant one
                      - Initializes the images reading and writing
                      - Evaluates the steps of the moving window
                      - Switch WRT the kernel is constant or not
                            - Calls the Core Convolution function
                      - End switch
                      - Closes the reading and writing of the images

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_kernelfiltering
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_RSMP";
#else
   const ERRSIT_proc_class proc_class   = "rsmp";
#endif
   const ERRSIT_proc_name routine_name = "stbx_kernelfiltering";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   STBXPT_under_idl_par   idl_par;        /* structure with the input */
                                          /* parameters for the task  */
   LDEFIT_boolean         const_kern = TRUE;
   double                 StepR;
   double                 StepC;
   MATHIT_RC             *vertex = (MATHIT_RC *)NULL;
   IDL_VPTR               idl_out_ima;

/* ==========================================================================
   IO variables
   ========================================================================== */
   GIOSIT_io              inp_io, out_io;
   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_resampling_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Set IDL dump
   ========================================================================== */
   ERRSIV_dump_to_idl = 1;

/* ==========================================================================
   Fill the input parameters structure
   ========================================================================== */
   STBXPP_IDLI_IDLUnderGetInputPar ( npar, val, kw, &idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Set the type of the output image
   ========================================================================== */
   if( idl_par.InpDataType == LDEFIE_dt_2_float ) {
      idl_par.OutDataType = LDEFIE_dt_2_float;
   }
   else {
      idl_par.OutDataType = LDEFIE_dt_float;
   }

/* ==========================================================================
   Create the output image
   ========================================================================== */
   STBXPP_IDLI_CreateMatrix( &idl_out_ima,
                              idl_par.OutDataType,
                              idl_par.NRowsOut,
                              idl_par.NColsOut,
                              (void **) &(idl_par.out_ima),
                             &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Check if the kernel is constant
   ========================================================================== */
   STBXPP_IDLI_IDLUnderCheckFilter ( idl_par.Kern, idl_par.Kr, idl_par.Kc,
                                     &const_kern, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Check the filter sizes consistency
   ========================================================================== */
   if ( ( idl_par.Kr > idl_par.NRowsInp ) || 
        ( idl_par.Kc > idl_par.NColsInp ) )
      ERRSIM_set_error( &status_code, ERRSID_STBX_kernel_dim_high, "" );

/* ==========================================================================
   Check the output dimensions consistency
   ========================================================================== */
   if ( ( idl_par.NRowsOut >= idl_par.NRowsInp - idl_par.Kr + 1 ) || 
        ( idl_par.NColsOut >= idl_par.NColsInp - idl_par.Kc + 1 ) )
      ERRSIM_set_error( &status_code, ERRSID_STBX_kernel_inv_dim,
                        "considering the filter transients" );

/* ==========================================================================
   Initialize the output images TIFF structures
   ========================================================================== */
   inp_io.type = GIOSIE_buffer;
   inp_io.mode = 'r';
   inp_io.val.buff.Buffer = idl_par.inp_ima;
   inp_io.val.buff.NRows = idl_par.NRowsInp;
   inp_io.val.buff.NColumns = idl_par.NColsInp;
   inp_io.val.buff.DataType = idl_par.InpDataType;

   GIOSIP_open_io( &inp_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

   out_io.type = GIOSIE_buffer;
   out_io.mode = 'w';
   out_io.val.buff.Buffer = idl_par.out_ima;
   out_io.val.buff.NRows = idl_par.NRowsOut;
   out_io.val.buff.NColumns = idl_par.NColsOut;
   out_io.val.buff.DataType = idl_par.OutDataType;

   GIOSIP_open_io( &out_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Open the write mode of the input image
   ========================================================================== */
   GIOSIP_open_line ( &out_io, 'x', 0, (idl_par.NColsOut - 1 ),
                      &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Evaluate the steps
   ========================================================================== */
   StepR = (double) SRVSIM_step( idl_par.NRowsInp,
                                 idl_par.Kr, 
                                 idl_par.NRowsOut );
   StepC = (double) SRVSIM_step( idl_par.NColsInp,
                                 idl_par.Kc,
                                 idl_par.NColsOut );
#ifdef __TRACE__
   printf ( "\n\n RStartR = 0, RStopR = %u", (UINTx4)(idl_par.NRowsInp - 1)  );
   printf ( "\n RStartW = 0, RStopW = %u", (UINTx4)(idl_par.NRowsOut - 1) );
#endif
/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) idl_par.NRowsOut, &log_status_code );

/* ==========================================================================
   Call the convolution kernel function
   ========================================================================== */
   if ( const_kern ) {
      IRESIP_UNDR_ConvCoreConstKern ( idl_par.NRowsInp, idl_par.NColsInp,
                                      (UINTx4)0, StepR, StepC, (UINTx4)0,
                                      vertex, idl_par.Kern, idl_par.Kr,
                                      idl_par.Kc, idl_par.inp_ima, (UINTx4)0,
                                      (UINTx4)(idl_par.NRowsOut - 1),
                                      idl_par.InpDataType, &out_io,
                                      (UINTx4)idl_par.NColsOut,
                                      (float)0, 0, &status_code );
      ERRSIM_on_err_goto_exit ( status_code );
   }
   else {
      IRESIP_UNDR_ConvCore ( idl_par.NRowsInp, idl_par.NColsInp, (UINTx4)0,
                             StepR, StepC, (UINTx4)0, vertex, idl_par.Kern,
                             idl_par.Kr, idl_par.Kc, idl_par.inp_ima, (UINTx4)0,
                             (UINTx4)(idl_par.NRowsOut - 1),
                             idl_par.InpDataType, &out_io, 
                             (UINTx4)idl_par.NColsOut,
                             (float)0, 0, &status_code );
      ERRSIM_on_err_goto_exit ( status_code );
   }

/* ==========================================================================
   Close the opened output channel
   ========================================================================== */
   GIOSIP_close_line ( &out_io, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Close input
   ========================================================================== */
   GIOSIP_close_io( &inp_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close output 
   ========================================================================== */
   GIOSIP_close_io( &out_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&(idl_par.inp_ima) );
   if ( idl_par.Kern != (float **)NULL ) {
      for ( i=0;i<idl_par.Kr;i++ ) {
         MEMSIP_free ( (void **)&(idl_par.Kern[ i ]) );
      }
      MEMSIP_free ( (void **)&(idl_par.Kern) );
   }
   
   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_ima );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_kernelfiltering */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLOverGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the resampling tool

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLOverGetInputPar
                        (/*IN    */ INTx4                 npar,
                         /*IN    */ IDL_VPTR             *val,
                         /*IN    */ char                 *kw,
                         /*   OUT*/ STBXPT_over_idl_par  *idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLOverGetInputPar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  par = 0;
   UINTx4                 arr_elem;
   static INTx4           ratio;
   static IDL_KW_PAR      kw_pars[] = 
               { 
                 { "RATIO", IDL_TYP_LONG, 1, IDL_KW_ZERO, 
                   0, IDL_CHARA(ratio)},
                 { NULL }
               };
   IDL_VPTR               plain_args[ 20 ];

#ifdef __SGI__
/* ==========================================================================
   Set the keyword parameters structure has the declaration settings is not
   so safe
   ========================================================================== */
   sprintf( kw_pars[ 0 ].keyword, "RATIO" );
   kw_pars[ 0 ].type = IDL_TYP_LONG;
   kw_pars[ 0 ].mask = 1;
   kw_pars[ 0 ].flags = IDL_KW_ZERO;
   kw_pars[ 0 ].specified = 0;
   kw_pars[ 0 ].value = IDL_CHARA(ratio);
   memset( &(kw_pars[ 1 ]), 0, sizeof( IDL_KW_PAR ) );
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Init structure
   ========================================================================== */
   memset( (void *) idl_par, 0, sizeof( STBXPT_over_idl_par ) );

/* ==========================================================================
   Get keywords
   ========================================================================== */
   IDL_KWGetParams( npar, val, kw, kw_pars, plain_args, 1);

/* ==========================================================================
   Clean up keyword settings
   ========================================================================== */
   IDL_KWCleanup( IDL_KW_CLEAN_ALL );

/* ==========================================================================
   Input image
   ========================================================================== */
   STBXPP_IDLI_GetImage ( val[ par ], &(idl_par->inp_ima), 
                          &(idl_par->NRowsInp), &(idl_par->NColsInp), 
                          &(idl_par->InpDataType), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
   if ( ( idl_par->NRowsInp <= 0 ) || ( idl_par->NColsInp <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "negative or null input image dimensions" );
   }

/* ==========================================================================
   Fill the Top Left pixel true coordinates
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ],              /* top left row */
                             (UINTx1)DATA_TYPE_UINTx4,
                             (void *)&(idl_par->TLRow), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   STBXPP_IDLI_GetParValue ( val[ ++par ],             /* top left column */
                             (UINTx1)DATA_TYPE_UINTx4,
                             (void *)&(idl_par->TLCol), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the top left coordinates
   ========================================================================== */
   if ( ( idl_par->TLRow < 0 ) || ( idl_par->TLCol < 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "negative image offset" );
   }

/* ==========================================================================
   Fill the range spacing parameter
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ], 
                             (UINTx1)DATA_TYPE_float,
                             (void *)&(idl_par->PixSpa), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the range spacing value
   ========================================================================== */
   if ( idl_par->PixSpa <= 0. ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "negative or null range spacing" );
   }

/* ==========================================================================
   Extracts the coefficients for the zero doppler evaluation
   ========================================================================== */
   STBXPP_IDLI_GetArray ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                          (UINTx4 *)&arr_elem, (void **)&(idl_par->FdcCoeff),
                          status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Extract the Pulse Repetition Frequency
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                             (void *)&(idl_par->prf), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check ratio keywork value
   ========================================================================== */
   if( ratio == 0 ) {

/* ==========================================================================
   Extract row and column output image size
   ========================================================================== */
      STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_UINTx4,
                                (void *)&(idl_par->NRowsOut), status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_UINTx4,
                                (void *)&(idl_par->NColsOut), status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the number of output rows and columns
   ========================================================================== */
      if ( ( idl_par->NRowsOut <= 0 ) || ( idl_par->NColsOut <= 0 ) ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "negative output dimensions" );
      }
      if ( ( idl_par->NRowsOut < idl_par->NRowsInp ) ||
           ( idl_par->NColsOut < idl_par->NColsInp) ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "output dimension(s) lesser than input one(s)" );
      }
   }
   else {
      float row_ratio, col_ratio;

/* ==========================================================================
   Get ratio factors, check them and compute output row and columns
   ========================================================================== */
      STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                                (void *)&(row_ratio), status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if( row_ratio <= 1.0 ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param,
                           "Row Ratio should be greater than 1.0" );
      }
      idl_par->NRowsOut = 
         (UINTx4) ROUND(((float) idl_par->NRowsInp) * row_ratio);

      STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                                (void *)&(col_ratio), status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

      if( col_ratio <= 1.0 ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param,
                           "Column Ratio should be greater than 1.0" );
      }
      idl_par->NColsOut = 
         (UINTx4) ROUND(((float) idl_par->NColsInp) * col_ratio);

   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLOverGetInputPar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLOverFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      oversampling taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLOverFillAnno
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ STBXPT_over_idl_par  idl_par,
                         /*IN OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLOverFillAnno";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Fill the global structure
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum ].ImageLength = (INTx4)(idl_par.NRowsInp +
      idl_par.TLRow);
   IANNIV_ImageAnnot[ imanum ].ImageWidth = (INTx4)(idl_par.NColsInp +
      idl_par.TLCol);
   IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol = (INTx4)idl_par.TLCol;
   IANNIV_ImageAnnot[ imanum ].PixelSpacing_m = idl_par.PixSpa;
   for ( i=0;i<3;i++ ) {
      IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ i ] =
         idl_par.FdcCoeff[ i ];
   }
   switch ( idl_par.InpDataType ) {
      case LDEFIE_dt_UINTx1:
      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_INTx4:
      case LDEFIE_dt_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 1;
      break;
      case LDEFIE_dt_2_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 2;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
      "the input image has a type not allowable for SAR Toolbox oversampling" );
   }
   IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz = idl_par.prf;

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLOverFillAnno */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLUnderGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       inp_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_kernel_inv_dim
                      ERRSID_STBX_kernel_dim_high
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the resampling tool

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Gets the info about the input image
                      - Checks the number of rows and columns and the input
                        image data type
                      - Fills the descriptor of the input parameters with the
                        pointer to the input image reallocated
                      - Gets the info about the kernel matrix
                      - Checks the dimensions of the kernel
                      - If the kernel image type is not float
                            - Converts the kernel matrix into a float one
                      - Endif
                      - Fills the descriptor of the input parameters with the
                        pointer to the filter matrix reallocated
                      - Gets the info about the output image
                      - Checks the number of rows and columns and the output
                        image data type
                      - Fills the descriptor of the input parameters with the
                        pointer to the output image reallocated

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLUnderGetInputPar
                        (/*IN    */ INTx4                 npar,
                         /*IN    */ IDL_VPTR             *val,
                         /*IN    */ char                 *kw,
                         /*   OUT*/ STBXPT_under_idl_par *idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLUnderGetInputPar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  par = 0;
   void                  *inp_ima = (void *)NULL;
   float                 *kfilt = (float *)NULL;
   LDEFIT_data_type       kern_type;
   static INTx4           ratio;
   static IDL_KW_PAR      kw_pars[] = 
               { 
                 { "RATIO", IDL_TYP_LONG, 1, IDL_KW_ZERO, 
                   0, IDL_CHARA(ratio)},
                 { NULL }
               };
   IDL_VPTR               plain_args[ 20 ];

#ifdef __SGI__
/* ==========================================================================
   Set the keyword parameters structure has the declaration settings is not
   so safe
   ========================================================================== */
   sprintf( kw_pars[ 0 ].keyword, "RATIO" );
   kw_pars[ 0 ].type = IDL_TYP_LONG;
   kw_pars[ 0 ].mask = 1;
   kw_pars[ 0 ].flags = IDL_KW_ZERO;
   kw_pars[ 0 ].specified = 0;
   kw_pars[ 0 ].value = IDL_CHARA(ratio);
   memset( &(kw_pars[ 1 ]), 0, sizeof( IDL_KW_PAR ) );
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );
/* ==========================================================================
   Init structure
   ========================================================================== */
   memset( (void *) idl_par, 0, sizeof( STBXPT_under_idl_par ) );

/* ==========================================================================
   Get keywords
   ========================================================================== */
   IDL_KWGetParams( npar, val, kw, kw_pars, plain_args, 1);

/* ==========================================================================
   Clean up keyword settings
   ========================================================================== */
   IDL_KWCleanup( IDL_KW_CLEAN_ALL );

/* ==========================================================================
   Input image
   ========================================================================== */
   STBXPP_IDLI_GetImage ( val[ par ], &inp_ima, &(idl_par->NRowsInp),
                          &(idl_par->NColsInp), &(idl_par->InpDataType),
                          status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
   if ( ( idl_par->NRowsInp <= 0 ) || ( idl_par->NColsInp <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "negative or null input image dimensions" );
   }

/* ==========================================================================
   Fill the input parameters descriptor with the input image
   ========================================================================== */
   STBXPP_IDLI_IDLFillImage ( inp_ima, idl_par->InpDataType,
                              idl_par->NRowsInp, idl_par->NColsInp,
                              &(idl_par->inp_ima), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the kernel 
   ========================================================================== */
   STBXPP_IDLI_GetImage ( val[ ++par ], (void *)&kfilt, &(idl_par->Kr),
                          &(idl_par->Kc),
                          &kern_type, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the kernel sizes
   ========================================================================== */
   if ( ( idl_par->Kr <= 0 ) || ( idl_par->Kc <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_kernel_inv_dim, "" );
   }
   if ( ( idl_par->Kr > idl_par->NRowsInp ) ||
        ( idl_par->Kc > idl_par->NColsInp ) ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_kernel_dim_high, "" );
   }

/* ==========================================================================
   Allocate the filter memory
   ========================================================================== */
   kfilt = (float *)NULL;
   if ( ( kfilt = (float *)
             MEMSIP_alloc( (size_t)(((val[ par ]->value).arr)->n_elts *
                           sizeof ( float ) ) ) ) == (float *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                         " for the float kernel array");
   }

   STBXPP_IDLI_IDLUnderFiltCopy ( val[ par ], &kern_type, kfilt, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the kernel pointer in the input image descriptor
   ========================================================================== */
   STBXPP_IDLI_IDLFillImage ( (void *)kfilt, kern_type, idl_par->Kr,
                              idl_par->Kc, (void ***)&(idl_par->Kern),
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check ratio keywork value
   ========================================================================== */
   if( ratio == 0 ) {

/* ==========================================================================
   Extract row and column output image size
   ========================================================================== */
      STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_UINTx4,
                                (void *)&(idl_par->NRowsOut), status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_UINTx4,
                                (void *)&(idl_par->NColsOut), status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
      if ( ( idl_par->NRowsOut <= 0 ) || ( idl_par->NColsOut <= 0 ) ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "negative or null output image dimensions" );
      }
      if ( ( idl_par->NRowsOut > idl_par->NRowsInp ) ||
           ( idl_par->NColsOut > idl_par->NColsInp) ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "output dimension(s) greather than input one(s)" );
      }
   }
   else {
      float row_ratio, col_ratio;

/* ==========================================================================
   Get ratio factors, check them and compute output row and columns
   ========================================================================== */
      STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                                (void *)&(row_ratio), status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if( (row_ratio <= 0.0) ||
          (row_ratio >= 1.0) ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_inv_inp_param,
                           "Row Ratio should be greater than 1.0" );
      }
      idl_par->NRowsOut = 
         (UINTx4) ROUND(((float) idl_par->NRowsInp) * row_ratio);

      STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                                (void *)&(col_ratio), status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

      if( (col_ratio <= 0.0) ||
          (col_ratio >= 1.0) ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_inv_inp_param,
                           "Column Ratio should be greater than 1.0" );
      }
      idl_par->NColsOut = 
         (UINTx4) ROUND(((float) idl_par->NColsInp) * col_ratio);

   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

} /* STBXPP_IDLI_IDLUnderGetInputPar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLFillImage

        $TYPE         PROCEDURE

        $INPUT        ima_p     : pointer to the image sequentially allocated
                      data_type : image data type
                      nrows     : image number of rows
                      ncols     : image number of columns

        $MODIFIED     NONE

        $OUTPUT       image     : double pointer to the image to allocate

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_image_dim
                      ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure constructs a matrix image through a
                      pointers array pointing to the first elements of
                      each row of the input image sequentially allocated

        $WARNING      NONE

        $PDL          - Checks the input parameters
                      - Switch WRT the wanted image type
                            - Allocates the array of pointers to makes to
                              them to point to the input image rows
                            - Points the elements of the array to the image
                              rows
                      - End of switch

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLFillImage
                        (/*IN    */ void                *ima_p,
                         /*IN    */ LDEFIT_data_type     data_type,
                         /*IN    */ UINTx4               nrows,
                         /*IN    */ UINTx4               ncols,
                         /*   OUT*/ void              ***image,
                         /*IN OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLFillImage";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Initialize the pointer that will be allocated
   ========================================================================== */
   *image = (void **)NULL;

/* ==========================================================================
   Check the number of rows and columns
   ========================================================================== */
   if ( ( nrows <= 0 ) || ( ncols <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_image_dim, "" );
   }

/* ==========================================================================
   Switch WRT input data type
   ========================================================================== */
   switch ( data_type ) {
      case LDEFIE_dt_UINTx1:

/* ==========================================================================
   Allocates the array of pointers pointing at the input image rows
   ========================================================================== */
         if ( ( *image = (void **)MEMSIP_alloc ( (size_t)
                   (nrows * sizeof ( UINTx1 *) ) ) ) ==
              (void **)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                            "allocating the input image" );
         }

/* ==========================================================================
   Make the pointer array elements point to the image rows
   ========================================================================== */
         for ( i=0;i<nrows;i++ ) {
            ((UINTx1 **)(*image))[ i ] = &(((UINTx1 *)ima_p)[ i * ncols ]);
         }
      break;
      case LDEFIE_dt_UINTx2:

/* ==========================================================================
   Allocates the array of pointers pointing at the input image rows ... see
   comment above
   ========================================================================== */
         if ( ( *image = (void **)MEMSIP_alloc ( (size_t)
                   (nrows * sizeof ( UINTx2 *) ) ) ) ==
              (void **)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                            "allocating the input image" );
         }
         for ( i=0;i<nrows;i++ ) {
            ((UINTx2 **)(*image))[ i ] = &(((UINTx2 *)ima_p)[ i * ncols ]);
         }
      break;
      case LDEFIE_dt_INTx4:

/* ==========================================================================
   Allocates the array of pointers pointing at the input image rows ... see
   comment above
   ========================================================================== */
         if ( ( *image = (void **)MEMSIP_alloc ( (size_t)
                   (nrows * sizeof ( INTx4 *) ) ) ) ==
              (void **)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                            "allocating the input image" );
         }
         for ( i=0;i<nrows;i++ ) {
            ((INTx4 **)(*image))[ i ] = &(((INTx4 *)ima_p)[ i * ncols ]);
         }
      break;
      case LDEFIE_dt_float:

/* ==========================================================================
   Float type image
   ========================================================================== */
         if ( ( *image = (void **)MEMSIP_alloc ( (size_t)
                   (nrows * sizeof ( float *) ) ) ) ==
              (void **)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                            "allocating the input image" );
         }
         for ( i=0;i<nrows;i++ ) {
            ((float **)(*image))[ i ] = &(((float *)ima_p)[ i * ncols ]);
         }
      break;
      case LDEFIE_dt_2_float:

/* ==========================================================================
   Complex images
   ========================================================================== */
         if ( ( *image = (void **)MEMSIP_alloc ( (size_t)
                   (nrows * 2 * sizeof ( float *) ) ) ) ==
              (void **)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                            "allocating the input image" );
         }
         for ( i=0;i<nrows;i++ ) {
            ((float **)(*image))[ i ] = &(((float *)ima_p)[ i * 2 * ncols ]);
         }
      break;
      default:

/* ==========================================================================
   Not SAR Toolbox allowable image
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
      "the input image has a type not allowable for SAR Toolbox resampling" );
   }

error_exit:;

/* ==========================================================================
   Deallocates the memories if there has been a problem
   ========================================================================== */
   if ( *status_code != ERRSID_normal ) {
      MEMSIP_free ( (void **)image );
   }

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

} /* STBXPP_IDLI_FillImage */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLUnderCheckFilter

        $TYPE         PROCEDURE

        $INPUT        kernel : filtering kernel
                      Kr     : rows kernel dimension
                      Kc     : columns kernel dimension

        $MODIFIED     NONE

        $OUTPUT       flag   : flag to indicate if the kernel is constant
                               or not

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_kernel_inv_dim

        $DESCRIPTION  This procedure cheks if the kernel is constant or not

        $WARNING      NONE

        $PDL          - Checks the kernel dimensions
                      - Checks if the kernel is a constant

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLUnderCheckFilter
                        (/*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*   OUT*/ LDEFIT_boolean      *const_kern,
                         /*IN OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLUnderCheckFilter";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 i;
   UINTx4                 j;
   float                  val;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the kernel size
   ========================================================================== */
   if ( ( Kr < 1 ) || ( Kc < 1 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_kernel_inv_dim, "" );
   }

/* ==========================================================================
   Check if the kernel is constant
   ========================================================================== */
   val = Kern[ 0 ][ 0 ];
   for ( i=0; i<Kr; i++ ) {
      for ( j=0; j<Kc; j++ ) {
         if ( Kern[ i ][ j ] != val ) {
            *const_kern = FALSE;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

} /* STBXPP_IDLI_IDLUnderCheckFilter */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLUnderFiltCopy

        $TYPE         PROCEDURE

        $INPUT        descr     : the descriptor of the kernel matrix

        $MODIFIED     kern_type : type of the filter matrix

        $OUTPUT       filter    : array of float type to store the kernel

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the float array with the kernel
                      contents

        $WARNING      NONE

        $PDL          -	If the kernel type is not float
                            - Converts it in float
                      - End if
                      - Else
                            - Copyes the filter
                      - End Else

   $EH
   ========================================================================== */

void STBXPP_IDLI_IDLUnderFiltCopy
                        (/*IN    */ IDL_VPTR              descr,
                         /*IN OUT*/ LDEFIT_data_type     *kern_type,
                         /*   OUT*/ float                *filter,
                         /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLUnderFiltCopy";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the kernel image type and converts it into float
   ========================================================================== */
   if ( *kern_type != LDEFIE_dt_float ) {

/* ==========================================================================
   Convert the array into float
   ========================================================================== */
      STBXPP_IDLI_IDLArray2float ( descr,
                                   (UINTx4)(((descr->value).arr)->n_elts),
                                   filter, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      *kern_type = LDEFIE_dt_float;
   }
   else {

/* ==========================================================================
   Copy the filter
   ========================================================================== */
      memcpy ( (void *)filter, (void *)(((descr->value).arr)->data),
               (size_t)(((descr->value).arr)->n_elts * sizeof (float)) );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* STBXPP_IDLI_IDLUnderFiltCopy */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLGstaGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the global statistic task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLGstaGetInputPar
                        (/*IN    */ INTx4                 npar,
                         /*IN    */ IDL_VPTR             *val,
                         /*IN    */ char                 *kw,
                         /*   OUT*/ STBXPT_gsta_idl_par  *idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLGstaGetInputPar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  my_npar, par = 0;
   UINTx4                 arr_elem, x_arr_elem, y_arr_elem;

   static int             nclasses_there, lclasses_there;
   static IDL_VPTR        nclasses, lclasses;
   static IDL_KW_PAR      kw_pars[] = 
               { 
                 { "LIMITS", IDL_TYP_UNDEF, 1, IDL_KW_ARRAY | IDL_KW_OUT, 
                   &lclasses_there, IDL_CHARA(lclasses)},
                 { "NCLASSES", IDL_TYP_UNDEF, 1, IDL_KW_ARRAY | IDL_KW_OUT, 
                   &nclasses_there, IDL_CHARA(nclasses)},
                 { NULL }
               };
   IDL_VPTR               plain_args[ 20 ];

/* ==========================================================================
   Set the input parameter number
   ========================================================================== */
   my_npar = npar;

#ifdef __SGI__
/* ==========================================================================
   Set the keyword parameters structure has the declaration settings is not
   so safe
   ========================================================================== */
   sprintf( kw_pars[ 0 ].keyword, "LIMITS" );
   kw_pars[ 0 ].type = IDL_TYP_UNDEF;
   kw_pars[ 0 ].mask = 1;
   kw_pars[ 0 ].flags = IDL_KW_ARRAY | IDL_KW_OUT;
   kw_pars[ 0 ].specified = &lclasses_there;
   kw_pars[ 0 ].value = IDL_CHARA(lclasses);
   sprintf( kw_pars[ 1 ].keyword, "NCLASSES" );
   kw_pars[ 1 ].type = IDL_TYP_UNDEF;
   kw_pars[ 1 ].mask = 1;
   kw_pars[ 1 ].flags = IDL_KW_ARRAY | IDL_KW_OUT;
   kw_pars[ 1 ].specified = &nclasses_there;
   kw_pars[ 1 ].value = IDL_CHARA(nclasses);
   memset( &(kw_pars[ 2 ]), 0, sizeof( IDL_KW_PAR ) );
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Init structure
   ========================================================================== */
   memset( (void *) idl_par, 0, sizeof( STBXPT_gsta_idl_par ) );

/* ==========================================================================
   Init static variables
   ========================================================================== */
   nclasses_there = lclasses_there = 0;

/* ==========================================================================
   Get keywords
   ========================================================================== */
   IDL_KWGetParams( npar, val, kw, kw_pars, plain_args, 1);

/* ==========================================================================
   Clean up keyword settings
   ========================================================================== */
   IDL_KWCleanup( IDL_KW_CLEAN_ALL );

/* ==========================================================================
   Input image
   ========================================================================== */
   STBXPP_IDLI_GetImage ( val[ par ], &(idl_par->inp_ima), 
                          &(idl_par->NRowsInp), &(idl_par->NColsInp), 
                          &(idl_par->InpDataType), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
   if ( ( idl_par->NRowsInp <= 0 ) || ( idl_par->NColsInp <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "InpIma has negative or null input image dimensions" );
   }

/* ==========================================================================
   Fill histogram parameters
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                             (void *)&(idl_par->ClassMin), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                             (void *)&(idl_par->ClassMax), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_UINTx4,
                             (void *)&(idl_par->ClassNo), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Get output parameters
   ========================================================================== */
   STBXPP_IDLI_GetParAddress( val[ ++par ], (UINTx1)DATA_TYPE_float,
                              (void **) &(idl_par->Mean), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
 
   STBXPP_IDLI_GetParAddress( val[ ++par ], (UINTx1)DATA_TYPE_float,
                              (void **) &(idl_par->Sddv), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
 
   STBXPP_IDLI_GetParAddress( val[ ++par ], (UINTx1)DATA_TYPE_float,
                              (void **) &(idl_par->Cfvr), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
 
   STBXPP_IDLI_GetParAddress( val[ ++par ], (UINTx1)DATA_TYPE_float,
                              (void **) &(idl_par->Min), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
 
   STBXPP_IDLI_GetParAddress( val[ ++par ], (UINTx1)DATA_TYPE_float,
                              (void **) &(idl_par->Max), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
 
   arr_elem = idl_par->ClassNo + 2;

/* ==========================================================================
   Create array for output nclasses and lclasses
   ========================================================================== */
   if( nclasses_there ) {
      UINTx4 nclasses_no;

      my_npar--;
      STBXPP_IDLI_GetArrayAddress (  nclasses,
                                     DATA_TYPE_float,
                                    &nclasses_no,
                                     (void **) &(idl_par->NClasses),
                                     status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if( nclasses_no < (idl_par->ClassNo + 2)) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "Not enough values in NCLASSES vector" );
      }

   }
   else {
      idl_par->NClasses = (float *) NULL;
   }
   if( lclasses_there ) {
      UINTx4 lclasses_no;

      my_npar--;
      STBXPP_IDLI_GetArrayAddress (  lclasses,
                                     DATA_TYPE_float,
                                    &lclasses_no,
                                     (void **) &(idl_par->LClasses),
                                     status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if( lclasses_no < (idl_par->ClassNo + 2)) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "Not enough values in LIMITS vector" );
      }

   }
   else {
   }

/* ==========================================================================
   Get polygonal AOI
   ========================================================================== */
   if( my_npar == (STBXPD_IDLI_gsta_nopar + 2) ) {
      STBXPP_IDLI_GetArray ( val[ ++par ], (UINTx1)DATA_TYPE_INTx4,
                             (UINTx4 *)&x_arr_elem, (void **)&(idl_par->x_aoi),
                             status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

      STBXPP_IDLI_GetArray ( val[ ++par ], (UINTx1)DATA_TYPE_INTx4,
                             (UINTx4 *)&y_arr_elem, (void **)&(idl_par->y_aoi),
                             status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

      if( x_arr_elem != y_arr_elem ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "Rows and columns AOI values have different sizes" );
      }
      if( x_arr_elem < 2 ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "Not enough values for rows and columns AOI values" );
      }
      idl_par->vertex = x_arr_elem;
   }
   else if( my_npar == (STBXPD_IDLI_gsta_nopar + 1) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "AOI specification error" );
   }
   else {
      idl_par->vertex = 0;
   }



error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLGstaGetInputPar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLGstaFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      oversampling taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLGstaFillAnno
                        (/*IN    */ UINTx1                imanum,
                         /*IN    */ STBXPT_gsta_idl_par   idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLGstaFillAnno";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Fill the global structure
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum ].ImageLength = (INTx4) idl_par.NRowsInp;
   IANNIV_ImageAnnot[ imanum ].ImageWidth = (INTx4) idl_par.NColsInp;

   switch ( idl_par.InpDataType ) {
      case LDEFIE_dt_UINTx1:
      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_INTx4:
      case LDEFIE_dt_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 1;
      break;
      case LDEFIE_dt_2_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 2;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
      "the input image has a type not allowable for SAR Toolbox oversampling" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLGstaFillAnno */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_globalstatistic

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - ClassMin     : minimun class value for the 
                                              histogram
			     - ClassMax     : maximum class value for the
                                              histogram
                             - X            : vector of AOI X coordinates
                             - Y            : vector of AOI Y coordinates
                             OUTPUT:
                             - Mean         : mean value
			     - Sddv         : standard deviation value
			     - Cfvr         : coefficient of variation value
			     - Classes      : histogram class value

        $MODIFIED     NONE

        $OUTPUT       The Mean, Sddv, Cfvr variable and Classes histogram
                      vector

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the global statistic
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_globalstatistic
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_STAT";
#else
   const ERRSIT_proc_class proc_class   = "stat";
#endif
   const ERRSIT_proc_name routine_name = "stbx_globalstatistic";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   IO variables
   ========================================================================== */
   GIOSIT_io              inp_io;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   STBXPT_gsta_idl_par    idl_par;        /* structure with the input */
                                          /* parameters for the task  */
   UINTx4                 inp_ima_num = 0;     /* image number */
   UINTx4                 i;
   IDL_VPTR               idl_out_arr;
   MATHIT_RC              TopLeft, BottomRight;
   
/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                 vertex_no = 0;
   MATHIT_RC             *vertex = (MATHIT_RC *) NULL;
   UINTx4                 TLRow = 0;
   UINTx4                 TLCol = 0;
   UINTx4                 BRRow = 0;
   UINTx4                 BRCol = 0;
   UINTx4                 nrow_inp;
   UINTx4                 ncol_inp;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_statistical_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Set IDL dump
   ========================================================================== */
   ERRSIV_dump_to_idl = 1;

/* ==========================================================================
   Initialize the image annotations structure
   ========================================================================== */
   memset ( (void *)&IANNIV_ImageAnnot[ inp_ima_num ], 0,
            (size_t)sizeof( IANNIT_ImageAnnot ) );

/* ==========================================================================
   Initialize the input parameters structure
   ========================================================================== */
   memset ( (void *)&idl_par, 0, (size_t)(sizeof ( STBXPT_gsta_idl_par ) ) );

/* ==========================================================================
   Fill the input parameters structure
   ========================================================================== */
   STBXPP_IDLI_IDLGstaGetInputPar ( npar, val, kw, &idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Create output histogram vector
   ========================================================================== */
   STBXPP_IDLI_CreateArray( &idl_out_arr,
                             LDEFIE_dt_INTx4,
                             idl_par.ClassNo+2,
                             (void **) &(idl_par.Classes),
                            &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Fill the image description structure
   ========================================================================== */
   STBXPP_IDLI_IDLGstaFillAnno ( inp_ima_num, idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Initialize the input image structure
   ========================================================================== */
   inp_io.type = GIOSIE_buffer;
   inp_io.mode = 'r';
   inp_io.val.buff.Buffer = idl_par.inp_ima;
   inp_io.val.buff.NRows = idl_par.NRowsInp;
   inp_io.val.buff.NColumns = idl_par.NColsInp;
   inp_io.val.buff.DataType = idl_par.InpDataType;

   GIOSIP_open_io( &inp_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Set the AOI
   ========================================================================== */
   if( idl_par.vertex > 0 ) {
      for( i=0; i<idl_par.vertex; i++) {
         if( idl_par.x_aoi[ i ] < 0 ) {
            ERRSIM_set_error( &status_code, ERRSID_STBX_parm_not_negative, "AOI rows" );
         }
         if( idl_par.y_aoi[ i ] < 0 ) {
            ERRSIM_set_error( &status_code, ERRSID_STBX_parm_not_negative, "AOI columns" );
         }
      }
      if( idl_par.vertex > 2 ) {
         vertex_no = idl_par.vertex;
         vertex = (MATHIT_RC *) MEMSIP_alloc( (size_t) vertex_no * 
                                                       sizeof( MATHIT_RC ));
         if( vertex == (MATHIT_RC *) NULL ) {
            ERRSIM_set_error(  &status_code,
                               ERRSID_STBX_err_mem_alloc,
                               "vertex" );
         }
         for( i=0; i<vertex_no; i++ ) {
            vertex[ i ].row = (double) idl_par.x_aoi[ i ];
            vertex[ i ].col = (double) idl_par.y_aoi[ i ];
         }
         COORIP_AOIX_CoverRect(  vertex_no,
                                 vertex,
                                &TopLeft,
                                &BottomRight,
                                &status_code );
         ERRSIM_on_err_goto_exit( status_code );
         TLRow = (UINTx4) TopLeft.row; TLCol = (UINTx4) TopLeft.col;
         BRRow = (UINTx4) BottomRight.row; BRCol = (UINTx4) BottomRight.col;
      }
      else {
         ERRSIM_set_error( &status_code, ERRSID_STBX_inv_inp_param, "AOI Rows-Columns" );
      }
   }
   else {
      vertex_no = 0; vertex = (MATHIT_RC *) NULL;
      TLRow = (UINTx4) 0; TLCol = (UINTx4) 0;
      BRRow = (UINTx4) idl_par.NRowsInp - 1; 
      BRCol = (UINTx4) idl_par.NColsInp - 1;
   }

/* ==========================================================================
   (RE)Compute nrow_inp/ncol_inp of source image
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

#ifdef __TRACE__
   fprintf( stdout, "TLRow = %0d\n", TLRow );
   fprintf( stdout, "TLCol = %0d\n", TLCol );
   fprintf( stdout, "BRRow = %0d\n", BRRow );
   fprintf( stdout, "BRCol = %0d\n", BRCol );
   for(i=0; i<vertex_no; i++) {
      fprintf( stdout, "vertex[ %0d ].row = %f\n", i, vertex[ i ].row );
      fprintf( stdout, "vertex[ %0d ].col = %f\n", i, vertex[ i ].col );
   }
#endif

/* ==========================================================================
   Call Global Statistic
   ========================================================================== */
   STATIP_GLOB_stat(&inp_io,
		     inp_ima_num,
		     TLRow,
		     TLCol,
		     nrow_inp,
		     ncol_inp,
		     vertex_no,
		     vertex,
		     idl_par.ClassMin,
		     idl_par.ClassMax,
		     idl_par.ClassNo,
                     idl_par.Min,
                     idl_par.Max,
                     idl_par.Mean,
                     idl_par.Sddv,
                     idl_par.Cfvr,
                     (UINTx4 *) idl_par.Classes,
                     idl_par.NClasses,
                     idl_par.LClasses,
		    &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

#ifdef __TRACE__
   fprintf(stdout, "\nMean = %f\n", *(idl_par.Mean));
   fprintf(stdout, "Standard Deviation = %f\n", *(idl_par.Sddv));
   fprintf(stdout, "Coefficient of variation = %f\n", *(idl_par.Cfvr));

   for( i=0; i<idl_par.ClassNo+2; i++ ) {
      fprintf(stdout, "Class %0d #%0d\n", i, idl_par.Classes[ i ] );
   }
#endif

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_arr );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_globalstatistic */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLLstaGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the local statistic task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLLstaGetInputPar
                        (/*IN    */ INTx4                 npar,
                         /*IN    */ IDL_VPTR             *val,
                         /*IN    */ char                 *kw,
                         /*   OUT*/ STBXPT_lsta_idl_par  *idl_par,
                         /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLLstaGetInputPar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  my_npar, par = 0;
   UINTx4                 x_arr_elem, y_arr_elem;
   UINTx4                 win_no;
   static INTx4           ratio;
   static IDL_KW_PAR      kw_pars[] = 
               { 
                 { "RATIO", IDL_TYP_LONG, 1, IDL_KW_ZERO, 
                   0, IDL_CHARA(ratio)},
                 { NULL }
               };
   IDL_VPTR               plain_args[ 20 ];

/* ==========================================================================
   Set the input parameter number
   ========================================================================== */
   my_npar = npar;

#ifdef __SGI__
/* ==========================================================================
   Set the keyword parameters structure has the declaration settings is not
   so safe
   ========================================================================== */
   sprintf( kw_pars[ 0 ].keyword, "RATIO" );
   kw_pars[ 0 ].type = IDL_TYP_LONG;
   kw_pars[ 0 ].mask = 1;
   kw_pars[ 0 ].flags = IDL_KW_ZERO;
   kw_pars[ 0 ].specified = 0;
   kw_pars[ 0 ].value = IDL_CHARA(ratio);
   memset( &(kw_pars[ 1 ]), 0, sizeof( IDL_KW_PAR ) );
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

fprintf( stdout, "npar=%0d\n", npar );
/* ==========================================================================
   Init structure
   ========================================================================== */
   memset( (void *) idl_par, 0, sizeof( STBXPT_lsta_idl_par ) );

/* ==========================================================================
   Get keywords
   ========================================================================== */
   IDL_KWGetParams( npar, val, kw, kw_pars, plain_args, 1);

/* ==========================================================================
   Clean up keyword settings
   ========================================================================== */
   IDL_KWCleanup( IDL_KW_CLEAN_ALL );

/* ==========================================================================
   Input image
   ========================================================================== */
   STBXPP_IDLI_GetImage ( val[ par ], &(idl_par->inp_ima), 
                          &(idl_par->NRowsInp), &(idl_par->NColsInp), 
                          &(idl_par->InpDataType), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
   if ( ( idl_par->NRowsInp <= 0 ) || ( idl_par->NColsInp <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "InpIma has negative or null input image dimensions" );
   }

/* ==========================================================================
   Get window sizes and step vector
   ========================================================================== */
   STBXPP_IDLI_GetArray ( val[ ++par ], (UINTx1)DATA_TYPE_INTx4,
                          (UINTx4 *)&win_no, (void **)&(idl_par->win_sizes),
                          status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   if( win_no < 1 ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "Not enough values for window sizes" );
   }

/* ==========================================================================
   Check ratio keywork value
   ========================================================================== */
   if( ratio == 0 ) {

      STBXPP_IDLI_GetArray ( val[ ++par ], (UINTx1)DATA_TYPE_double,
                             (UINTx4 *)&win_no, (void **)&(idl_par->win_steps),
                             status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

      if( win_no < 1 ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "Not enough values for window steps" );
      }

   }
   else {
      double *outImageRatio;
      UINTx4  outImageRatioNo, nrow_out, ncol_out;

      my_npar--;
      STBXPP_IDLI_GetArray ( val[ ++par ], (UINTx1)DATA_TYPE_double,
                             (UINTx4 *)&outImageRatioNo, 
                             (void **)&outImageRatio,
                             status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

      if( outImageRatioNo < 1 ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "Not enough values for output image ratio" );
      }

      if( (idl_par->win_steps = 
              (double *) MEMSIP_alloc( (size_t) 2 * sizeof( double ) )) ==
          (double *) NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                                "win_steps array" );
      }

      nrow_out = (UINTx4) ROUND(((double) idl_par->NRowsInp) * outImageRatio[ 0 ]);
      idl_par->win_steps[ 0 ] = 
         SRVSIM_step( idl_par->NRowsInp, (idl_par->win_sizes)[ 0 ], nrow_out );

      ncol_out = (UINTx4) ROUND(((double) idl_par->NColsInp) * outImageRatio[ 1 ]);

      idl_par->win_steps[ 1 ] = 
         SRVSIM_step( idl_par->NColsInp, (idl_par->win_sizes)[ 1 ], ncol_out );
fprintf( stdout, "%f,%f\n", idl_par->win_steps[ 0 ], idl_par->win_steps[ 1 ] );
   }

/* ==========================================================================
   Get the filler value
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                             (void *)&(idl_par->fill_val), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill AOI parameters, if any
   ========================================================================== */
   if( my_npar == (STBXPD_IDLI_lsta_nopar + 2) ) {
      STBXPP_IDLI_GetArray ( val[ ++par ], (UINTx1)DATA_TYPE_INTx4,
                             (UINTx4 *)&x_arr_elem, (void **)&(idl_par->x_aoi),
                             status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

      STBXPP_IDLI_GetArray ( val[ ++par ], (UINTx1)DATA_TYPE_INTx4,
                             (UINTx4 *)&y_arr_elem, (void **)&(idl_par->y_aoi),
                             status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

      if( x_arr_elem != y_arr_elem ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "Rows and columns AOI values have different sizes" );
      }
      if( x_arr_elem < 2 ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                            "Not enough values for rows and columns AOI values" );
      }
      idl_par->vertex = x_arr_elem;
   }
   else if( my_npar == (STBXPD_IDLI_lsta_nopar + 1) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "AOI specification error" );
   }
   else {
      idl_par->vertex = 0;
   }


error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLLstaGetInputPar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLLstaFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      oversampling taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLLstaFillAnno
                        (/*IN    */ UINTx1                imanum,
                         /*IN    */ STBXPT_lsta_idl_par   idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLLstaFillAnno";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;


/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Fill the global structure
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum ].ImageLength = (INTx4) idl_par.NRowsInp;
   IANNIV_ImageAnnot[ imanum ].ImageWidth = (INTx4) idl_par.NColsInp;

   switch ( idl_par.InpDataType ) {
      case LDEFIE_dt_UINTx1:
      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_INTx4:
      case LDEFIE_dt_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 1;
      break;
      case LDEFIE_dt_2_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 2;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
      "the input image has a type not allowable for SAR Toolbox oversampling" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLLstaFillAnno */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLLocalStatistic

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - X            : vector of AOI X coordinates
                             - Y            : vector of AOI Y coordinates
                             - WSIZE        : vector of Window Size (X,Y)
                             - WSTEP        : vector of Window Steps (X,Y)
                             - FILL VAL     : filler value for pixel outsize AOI
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the global statistic
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
IDL_VPTR STBXPP_IDLI_IDLLocalStatistic
                        (/*IN    */ STATIT_image_type    imageType,
                         /*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLLocalStatistic";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   IO variables
   ========================================================================== */
   GIOSIT_io              inp_io, out_io;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   STBXPT_lsta_idl_par    idl_par;        /* structure with the input */
                                          /* parameters for the task  */
   UINTx4                 inp_ima_num = 0;     /* image number */
   UINTx4                 out_ima_num = 0;     /* image number */
   UINTx4                 i;
   IDL_VPTR               idl_out_ima;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                 vertex_no = 0;
   MATHIT_RC             *vertex = (MATHIT_RC *) NULL;
   UINTx4                 TLRow = 0;
   UINTx4                 TLCol = 0;
   UINTx4                 BRRow = 0;
   UINTx4                 BRCol = 0;
   UINTx4                 nrow_inp;
   UINTx4                 ncol_inp;
   MATHIT_RC              TopLeft, BottomRight;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_statistical_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Set IDL dump
   ========================================================================== */
   ERRSIV_dump_to_idl = 1;

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Initialize the image annotations structure
   ========================================================================== */
   memset ( (void *)&IANNIV_ImageAnnot[ inp_ima_num ], 0,
            (size_t)sizeof( IANNIT_ImageAnnot ) );

/* ==========================================================================
   Initialize the input parameters structure
   ========================================================================== */
   memset ( (void *)&idl_par, 0, (size_t)(sizeof ( STBXPT_lsta_idl_par ) ) );

/* ==========================================================================
   Fill the input parameters structure
   ========================================================================== */
   STBXPP_IDLI_IDLLstaGetInputPar ( npar, val, kw, &idl_par, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Set the type of the output image
   ========================================================================== */
   idl_par.OutDataType = LDEFIE_dt_float;

/* ==========================================================================
   Set the AOI
   ========================================================================== */
   if( idl_par.vertex > 0 ) {
      for( i=0; i<idl_par.vertex; i++) {
         if( idl_par.x_aoi[ i ] < 0 ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative, "AOI rows" );
         }
         if( idl_par.y_aoi[ i ] < 0 ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative, "AOI columns" );
         }
      }
      if( idl_par.vertex > 2 ) {
         vertex_no = idl_par.vertex;
         vertex = (MATHIT_RC *) MEMSIP_alloc( (size_t) vertex_no *
                                                       sizeof( MATHIT_RC ));
         if( vertex == (MATHIT_RC *) NULL ) {
            ERRSIM_set_error(  status_code,
                               ERRSID_STBX_err_mem_alloc,
                               "vertex" );
         }
         for( i=0; i<vertex_no; i++ ) {
            vertex[ i ].row = (double) idl_par.x_aoi[ i ];
            vertex[ i ].col = (double) idl_par.y_aoi[ i ];
         }
         COORIP_AOIX_CoverRect(  vertex_no,
                                 vertex,
                                &TopLeft,
                                &BottomRight,
                                 status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         TLRow = (UINTx4) TopLeft.row; TLCol = (UINTx4) TopLeft.col;
         BRRow = (UINTx4) BottomRight.row; BRCol = (UINTx4) BottomRight.col;
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param, "AOI Rows-Columns" );
      }
   }
   else {
      vertex_no = 0; vertex = (MATHIT_RC *) NULL;
      TLRow = (UINTx4) 0; TLCol = (UINTx4) 0;
      BRRow = (UINTx4) idl_par.NRowsInp - 1;
      BRCol = (UINTx4) idl_par.NColsInp - 1;
   }
 
/* ==========================================================================
   (RE)Compute nrow_inp/ncol_inp of source image
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

#ifdef __TRACE__
   fprintf( stdout, "TLRow = %0d\n", TLRow );
   fprintf( stdout, "TLCol = %0d\n", TLCol );
   fprintf( stdout, "BRRow = %0d\n", BRRow );
   fprintf( stdout, "BRCol = %0d\n", BRCol );
   fprintf( stdout, "nrow_inp = %0d\n", nrow_inp);
   fprintf( stdout, "ncol_inp = %0d\n", ncol_inp);
   for(i=0; i<vertex_no; i++) {
      fprintf( stdout, "vertex[ %0d ].row = %f\n", i, vertex[ i ].row );
      fprintf( stdout, "vertex[ %0d ].col = %f\n", i, vertex[ i ].col );
   }
#endif

/* ==========================================================================
   Compute NRowsOut and NColsOut
   ========================================================================== */
   idl_par.NRowsOut = SRVSIM_out( nrow_inp, idl_par.win_sizes[ 0 ],
                                  idl_par.win_steps[ 0 ] );
   idl_par.NColsOut = SRVSIM_out( ncol_inp, idl_par.win_sizes[ 1 ],
                                  idl_par.win_steps[ 1 ] );

#ifdef __TRACE__
   fprintf( stdout, "idl_par.NRowsInp = %0d\n", idl_par.NRowsInp );
   fprintf( stdout, "idl_par.NColsInp = %0d\n", idl_par.NColsInp );
   fprintf( stdout, "idl_par.NRowsOut = %0d\n", idl_par.NRowsOut );
   fprintf( stdout, "idl_par.NColsOut = %0d\n", idl_par.NColsOut );
   fprintf( stdout, "idl_par.win_sizes[ 0 ] = %0d\n", idl_par.win_sizes[ 0 ]);
   fprintf( stdout, "idl_par.win_sizes[ 1 ] = %0d\n", idl_par.win_sizes[ 1 ]);
   fprintf( stdout, "idl_par.win_steps[ 0 ] = %0f\n", 
      idl_par.win_steps[ 0 ]);
   fprintf( stdout, "idl_par.win_steps[ 1 ] = %0f\n", 
      idl_par.win_steps[ 1 ]);
#endif

/* ==========================================================================
   Create the output image
   ========================================================================== */
   STBXPP_IDLI_CreateMatrix( &idl_out_ima,
                              idl_par.OutDataType,
                              idl_par.NRowsOut,
                              idl_par.NColsOut,
                              (void **) &(idl_par.out_ima),
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the image description structure
   ========================================================================== */
   STBXPP_IDLI_IDLLstaFillAnno ( inp_ima_num, idl_par, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );


/* ==========================================================================
   Initialize the input image structure
   ========================================================================== */
   inp_io.type = GIOSIE_buffer;
   inp_io.mode = 'r';
   inp_io.val.buff.Buffer = idl_par.inp_ima;
   inp_io.val.buff.NRows = idl_par.NRowsInp;
   inp_io.val.buff.NColumns = idl_par.NColsInp;
   inp_io.val.buff.DataType = idl_par.InpDataType;

   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Initialize the output image structure
   ========================================================================== */
   out_io.type = GIOSIE_buffer;
   out_io.mode = 'w';
   out_io.val.buff.Buffer = idl_par.out_ima;
   out_io.val.buff.NRows = idl_par.NRowsOut;
   out_io.val.buff.NColumns = idl_par.NColsOut;
   out_io.val.buff.DataType = idl_par.OutDataType;

   GIOSIP_open_io( &out_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Call Local Statistic
   ========================================================================== */
   STATIP_LOCA_stat(&inp_io,
		     inp_ima_num,
		     TLRow,
		     TLCol,
		     nrow_inp,
		     ncol_inp,
		     vertex_no,
		     vertex,
		     idl_par.win_sizes,
                     idl_par.win_steps,
		     idl_par.fill_val,
		    &out_io,
                     idl_par.NRowsOut,
                     idl_par.NColsOut,
		     imageType,
		     status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   and the outptu file.
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &(idl_par.x_aoi) );
   MEMSIP_free( (void **) &(idl_par.y_aoi) );
   MEMSIP_free( (void **) &(idl_par.win_sizes) );
   MEMSIP_free( (void **) &(idl_par.win_steps) );
   MEMSIP_free( (void **) &(vertex) );

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

   return( idl_out_ima );

} /* STBXPP_IDLI_IDLLocalStatistic */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_localmean

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - X            : vector of AOI X coordinates
                             - Y            : vector of AOI Y coordinates
                             - WSIZE        : vector of Window Size (X,Y)
                             - WSTEP        : vector of Window Steps (X,Y)
                             - FILL VAL     : filler value for pixel outsize AOI
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored


        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the local 
                      statistic (MEAN) of SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_localmean
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_STAT";
#else
   const ERRSIT_proc_class proc_class   = "stat";
#endif
   const ERRSIT_proc_name routine_name = "stbx_localmean";

   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

   IDL_VPTR               idl_out_ima;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Call STBXPP_IDLI_IDLLocalStatistic for MEAN image
   ========================================================================== */
   idl_out_ima = STBXPP_IDLI_IDLLocalStatistic(  STATIE_image_mean,
                                                 npar,
                                                 val,
                                                 kw,
                                                &status_code );
   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_ima );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_localmean */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_localsddv

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - X            : vector of AOI X coordinates
                             - Y            : vector of AOI Y coordinates
                             - WSIZE        : vector of Window Size (X,Y)
                             - WSTEP        : vector of Window Steps (X,Y)
                             - FILL VAL     : filler value for pixel outsize AOI
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the local 
                      statistic (SDDV) of SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_localsddv
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_STAT";
#else
   const ERRSIT_proc_class proc_class   = "stat";
#endif
   const ERRSIT_proc_name routine_name = "stbx_localsddv";

   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

   IDL_VPTR               idl_out_ima;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Call STBXPP_IDLI_IDLLocalStatistic for SDDV image
   ========================================================================== */
   idl_out_ima = STBXPP_IDLI_IDLLocalStatistic(  STATIE_image_sddv,
                                                 npar,
                                                 val,
                                                 kw,
                                                &status_code );
   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_ima );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_localsddv */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_localcfvr

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - X            : vector of AOI X coordinates
                             - Y            : vector of AOI Y coordinates
                             - WSIZE        : vector of Window Size (X,Y)
                             - WSTEP        : vector of Window Steps (X,Y)
                             - FILL VAL     : filler value for pixel outsize AOI
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the local 
                      statistic (CFVR) of SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_localcfvr
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_STAT";
#else
   const ERRSIT_proc_class proc_class   = "stat";
#endif
   const ERRSIT_proc_name routine_name = "stbx_localcfvr";

   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

   IDL_VPTR               idl_out_ima;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Call STBXPP_IDLI_IDLLocalStatistic for CFVR image
   ========================================================================== */
   idl_out_ima = STBXPP_IDLI_IDLLocalStatistic(  STATIE_image_cfvr,
                                                 npar,
                                                 val,
                                                 kw,
                                                &status_code );
   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_ima );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_localcfvr */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLPcaGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the pca task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLPcaGetInputPar
                        (/*IN    */ IDL_VPTR             *val,
                         /*   OUT*/ STBXPT_pca_idl_par   *idl_par,
                         /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLPcaGetInputPar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  par = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Init structure
   ========================================================================== */
   memset( (void *) idl_par, 0, sizeof( STBXPT_pca_idl_par ) );

/* ==========================================================================
   First input image
   ========================================================================== */
   STBXPP_IDLI_GetImage ( val[ par ], &(idl_par->inp_ima1),
                          &(idl_par->NRowsInp1), &(idl_par->NColsInp1), 
                          &(idl_par->InpDataType1), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
   if ( ( idl_par->NRowsInp1 <= 0 ) || ( idl_par->NColsInp1 <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                       "InpIma1 has negative or null input image dimensions" );
   }

   STBXPP_IDLI_GetImage ( val[ ++par ], &(idl_par->inp_ima2),
                          &(idl_par->NRowsInp2), &(idl_par->NColsInp2), 
                          &(idl_par->InpDataType2), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
   if ( ( idl_par->NRowsInp2 <= 0 ) || ( idl_par->NColsInp2 <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                       "InpIma2 has negative or null input image dimensions" );
   }

/* ==========================================================================
   Check if the input images have the same size
   ========================================================================== */
   if ( ( idl_par->NRowsInp1 != idl_par->NRowsInp2 ) ||
        ( idl_par->NColsInp1 != idl_par->NColsInp2 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                       "InpIma1 and InpIma2 has different sizes" );
   }
 
/* ==========================================================================
   Set the size of first PCA image
   ========================================================================== */
   idl_par->NRowsOut1 = idl_par->NRowsInp1;
   idl_par->NColsOut1 = idl_par->NColsInp1;

/* ==========================================================================
   Set the size of second PCA image
   ========================================================================== */
   idl_par->NRowsOut2 = idl_par->NRowsInp2;
   idl_par->NColsOut2 = idl_par->NColsInp2;

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLPcaGetInputPar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLPcaFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum1 : number identifing the first image in the tool
                      imanum2 : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structures describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum*] : the image annotation
                                                   structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      oversampling taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLPcaFillAnno
                        (/*IN    */ UINTx1                imanum1,
                         /*IN    */ UINTx1                imanum2,
                         /*IN    */ STBXPT_pca_idl_par    idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLPcaFillAnno";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Fill the global structure
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum1 ].ImageLength = (INTx4) idl_par.NRowsInp1;
   IANNIV_ImageAnnot[ imanum1 ].ImageWidth = (INTx4) idl_par.NColsInp1;

   switch ( idl_par.InpDataType1 ) {
      case LDEFIE_dt_UINTx1:
      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_INTx4:
      case LDEFIE_dt_float:
         IANNIV_ImageAnnot[ imanum1 ].SamplePerPixel = 1;
      break;
      case LDEFIE_dt_2_float:
         IANNIV_ImageAnnot[ imanum1 ].SamplePerPixel = 2;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
      "the input image has a type not allowable for SAR Toolbox oversampling" );
   }

   IANNIV_ImageAnnot[ imanum2 ].ImageLength = (INTx4) idl_par.NRowsInp2;
   IANNIV_ImageAnnot[ imanum2 ].ImageWidth = (INTx4) idl_par.NColsInp2;

   switch ( idl_par.InpDataType2 ) {
      case LDEFIE_dt_UINTx1:
      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_INTx4:
      case LDEFIE_dt_float:
         IANNIV_ImageAnnot[ imanum2 ].SamplePerPixel = 1;
      break;
      case LDEFIE_dt_2_float:
         IANNIV_ImageAnnot[ imanum2 ].SamplePerPixel = 2;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
      "the input image has a type not allowable for SAR Toolbox oversampling" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLLstaFillAnno */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLPca

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma1      : pointer to the first input image
                             - InpIma2      : pointer to the second input image
                             OUTPUT:
                             - OutIma[ 0 ]  : pointer to the first output image
                             - OutIma[ 1 ]  : pointer to the second output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the global statistic
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLPca 
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*IN OUT*/ IDL_VPTR            *idl_out_ima,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLPca";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   IO variables
   ========================================================================== */
   GIOSIT_io              inp_io1, out_io1;
   GIOSIT_io              inp_io2, out_io2;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   STBXPT_pca_idl_par     idl_par;        /* structure with the input */
                                          /* parameters for the task  */
   UINTx4                 inp_ima_num1 = 0;     /* image number */
   UINTx4                 inp_ima_num2 = 1;     /* image number */

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
#ifdef __TRACE__
   UINTx4                  i;
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );
 
/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_statistical_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Set IDL dump
   ========================================================================== */
   ERRSIV_dump_to_idl = 1;

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Initialize the image annotations structures
   ========================================================================== */
   memset ( (void *)&IANNIV_ImageAnnot[ inp_ima_num1 ], 0,
            (size_t)sizeof( IANNIT_ImageAnnot ) );
   memset ( (void *)&IANNIV_ImageAnnot[ inp_ima_num2 ], 0,
            (size_t)sizeof( IANNIT_ImageAnnot ) );

/* ==========================================================================
   Initialize the input parameters structure
   ========================================================================== */
   memset ( (void *)&idl_par, 0, (size_t)(sizeof ( STBXPT_pca_idl_par ) ) );

/* ==========================================================================
   Fill the input parameters structure
   ========================================================================== */
   STBXPP_IDLI_IDLPcaGetInputPar ( val, &idl_par, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Set the type of the first PCA image
   ========================================================================== */
   idl_par.OutDataType1 = LDEFIE_dt_float;

/* ==========================================================================
   Create the first PCA image
   ========================================================================== */
   STBXPP_IDLI_CreateMatrix( &(idl_out_ima[ 0 ]),
                              idl_par.OutDataType1,
                              idl_par.NRowsOut1,
                              idl_par.NColsOut1,
                              (void **) &(idl_par.out_ima1),
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Set the type of the second PCA image
   ========================================================================== */
   idl_par.OutDataType2 = LDEFIE_dt_float;

/* ==========================================================================
   Create the second output image
   ========================================================================== */
   STBXPP_IDLI_CreateMatrix( &(idl_out_ima[ 1 ]),
                              idl_par.OutDataType2,
                              idl_par.NRowsOut2,
                              idl_par.NColsOut2,
                              (void **) &(idl_par.out_ima2),
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the image description structure
   ========================================================================== */
   STBXPP_IDLI_IDLPcaFillAnno ( inp_ima_num1, inp_ima_num2, idl_par, 
                                status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Initialize the input images structure
   ========================================================================== */
   inp_io1.type = GIOSIE_buffer;
   inp_io1.mode = 'r';
   inp_io1.val.buff.Buffer = idl_par.inp_ima1;
   inp_io1.val.buff.NRows = idl_par.NRowsInp1;
   inp_io1.val.buff.NColumns = idl_par.NColsInp1;
   inp_io1.val.buff.DataType = idl_par.InpDataType1;

   GIOSIP_open_io( &inp_io1,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   inp_io2.type = GIOSIE_buffer;
   inp_io2.mode = 'r';
   inp_io2.val.buff.Buffer = idl_par.inp_ima2;
   inp_io2.val.buff.NRows = idl_par.NRowsInp2;
   inp_io2.val.buff.NColumns = idl_par.NColsInp2;
   inp_io2.val.buff.DataType = idl_par.InpDataType2;

   GIOSIP_open_io( &inp_io2,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set AOI
   ========================================================================== */
   vertex_no = 0; vertex = (MATHIT_RC *) NULL;
   TLRow = (UINTx4) 0; TLCol = (UINTx4) 0;
   BRRow = (UINTx4) idl_par.NRowsInp1 - 1;
   BRCol = (UINTx4) idl_par.NColsInp1 - 1;

/* ==========================================================================
   Initialize the output images structure
   ========================================================================== */
   out_io1.type = GIOSIE_buffer;
   out_io1.mode = 'w';
   out_io1.val.buff.Buffer = idl_par.out_ima1;
   out_io1.val.buff.NRows = idl_par.NRowsOut1;
   out_io1.val.buff.NColumns = idl_par.NColsOut1;
   out_io1.val.buff.DataType = idl_par.OutDataType1;

   GIOSIP_open_io( &out_io1,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   out_io2.type = GIOSIE_buffer;
   out_io2.mode = 'w';
   out_io2.val.buff.Buffer = idl_par.out_ima2;
   out_io2.val.buff.NRows = idl_par.NRowsOut2;
   out_io2.val.buff.NColumns = idl_par.NColsOut2;
   out_io2.val.buff.DataType = idl_par.OutDataType2;

   GIOSIP_open_io( &out_io2,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute nrow_inp/ncol_inp of source images
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

#ifdef __TRACE__
   fprintf( stdout, "TLRow = %0d\n", TLRow );
   fprintf( stdout, "TLCol = %0d\n", TLCol );
   fprintf( stdout, "BRRow = %0d\n", BRRow );
   fprintf( stdout, "BRCol = %0d\n", BRCol );
   for(i=0; i<vertex_no; i++) {
      fprintf( stdout, "vertex[ %0d ].row = %f\n", i, vertex[ i ].row );
      fprintf( stdout, "vertex[ %0d ].col = %f\n", i, vertex[ i ].col );
   }
#endif

/* ==========================================================================
   Set nrow_out/ncol_out
   ========================================================================== */
   nrow_out = nrow_inp;
   ncol_out = ncol_inp;

#ifdef __TRACE__
   fprintf( stdout, "nrow_out = %0d\n", nrow_out );
   fprintf( stdout, "ncol_out = %0d\n", ncol_out );
#endif

/* ==========================================================================
   Check size of OutIma1/OutIma2 against AOI
   ========================================================================== */
   if( ( idl_par.NRowsOut1 != nrow_out ) ||
       ( idl_par.NColsOut1 != ncol_out ) ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param, 
         "Size of OutIma1/OutIma2 is differnt from the selected AOI" );
   }


/* ==========================================================================
   Call PCA
   ========================================================================== */
   STATIP_PCAN_pca( &inp_io1,
		    &inp_io2,
	 	     inp_ima_num1,
		     inp_ima_num2,
		     TLRow,
		     TLCol,
		     nrow_inp,
		     ncol_inp,
		    &out_io1,
		    &out_io2,
		     nrow_out,
		     ncol_out,
		     status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the inputs ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io1, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   GIOSIP_close_io( &inp_io2, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   and the outputs
   ========================================================================== */
   GIOSIP_close_io( &out_io1, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   GIOSIP_close_io( &out_io2, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

} /* STBXPP_IDLI_IDLPca  */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_first_pca

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma1      : pointer to the first input image
                             - InpIma2      : pointer to the second input image
                             OUTPUT:
                             - OutIma       : pointer to the first output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the bridge to IDL for the first PCA 
                      image generation

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_first_pca 
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_STAT";
#else
   const ERRSIT_proc_class proc_class   = "stat";
#endif
   const ERRSIT_proc_name routine_name = "stbx_first_pca ";

   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

   IDL_VPTR               idl_out_ima[ STBXPD_num_pca_img ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Call generic PCA
   ========================================================================== */
   STBXPP_IDLI_IDLPca(  npar,
                        val,
                        idl_out_ima,
                       &status_code );

   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                           status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_ima[ 0 ] );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_first_pca  */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_second_pca

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma1      : pointer to the first input image
                             - InpIma2      : pointer to the second input image
                             OUTPUT:
                             - OutIma       : pointer to the first output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the bridge to IDL for the first PCA 
                      image generation

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_second_pca 
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_STAT";
#else
   const ERRSIT_proc_class proc_class   = "stat";
#endif
   const ERRSIT_proc_name routine_name = "stbx_second_pca ";

   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

   IDL_VPTR               idl_out_ima[ STBXPD_num_pca_img ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Call generic PCA
   ========================================================================== */
   STBXPP_IDLI_IDLPca(  npar,
                        val,
                        idl_out_ima,
                       &status_code );

   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                           status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_ima[ 1 ] );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_second_pca  */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_speckle

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             - InpIma : pointer to the input image
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored

        $MODIFIED     NONE

        $OUTPUT       The output image is filled

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for thes speckle filtering
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Fills the input parameters structure
                      - Tests if the kernel matrix is a constant one
                      - Initializes the images reading and writing
                      - Evaluates the steps of the moving window
                      - Switch WRT the kernel is constant or not
                            - Calls the Core Convolution function
                      - End switch
                      - Closes the reading and writing of the images

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_speckle
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_SPKF";
#else
   const ERRSIT_proc_class proc_class   = "spkf";
#endif
   const ERRSIT_proc_name routine_name = "stbx_speckle";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   STBXPT_speckle_idl_par   
                          idl_par;        /* structure with the input */
                                          /* parameters for the task  */
   IDL_VPTR               idl_out_ima;
   UINTx1                 imanum = 0;

/* ==========================================================================
   IO variables
   ========================================================================== */
   GIOSIT_io              inp_io, out_io;
   INTx4                  win_sizes[ 2 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_speckle_filtering_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Set IDL dump
   ========================================================================== */
   ERRSIV_dump_to_idl = 1;

/* ==========================================================================
   Fill the input parameters structure
   ========================================================================== */
   STBXPP_IDLI_IDLSpckGetInputPar ( npar, val, kw, &idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Fill the image description structure
   ========================================================================== */
   STBXPP_IDLI_IDLSpeckleFillAnno ( imanum, idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Set the type of the output image
   ========================================================================== */
   idl_par.OutDataType = LDEFIE_dt_float;

/* ==========================================================================
   Create the output image
   ========================================================================== */
   STBXPP_IDLI_CreateMatrix( &idl_out_ima,
                              idl_par.OutDataType,
                              idl_par.NRowsOut,
                              idl_par.NColsOut,
                              (void **) &(idl_par.out_ima),
                             &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Initialize the output images TIFF structures
   ========================================================================== */
   inp_io.type = GIOSIE_buffer;
   inp_io.mode = 'r';
   inp_io.val.buff.Buffer = idl_par.inp_ima;
   inp_io.val.buff.NRows = idl_par.NRowsInp;
   inp_io.val.buff.NColumns = idl_par.NColsInp;
   inp_io.val.buff.DataType = idl_par.InpDataType;

   GIOSIP_open_io( &inp_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

   out_io.type = GIOSIE_buffer;
   out_io.mode = 'w';
   out_io.val.buff.Buffer = idl_par.out_ima;
   out_io.val.buff.NRows = idl_par.NRowsOut;
   out_io.val.buff.NColumns = idl_par.NColsOut;
   out_io.val.buff.DataType = idl_par.OutDataType;

   GIOSIP_open_io( &out_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Init variables
   ========================================================================== */
   win_sizes[ 0 ] = (INTx4) idl_par.Kr;
   win_sizes[ 1 ] = (INTx4) idl_par.Kc;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   SPKFIP_filter(&inp_io,
		  imanum,
		  0,
		  0,
		  idl_par.NRowsInp,
		  idl_par.NColsInp,
		  win_sizes,
		  idl_par.mask_file,
                  idl_par.pfa,
                  idl_par.edge_th,
                  idl_par.line_th,
                  idl_par.scatter_th,
		 &out_io,
                  idl_par.NRowsOut,
                  idl_par.NColsOut,
		 &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close input
   ========================================================================== */
   GIOSIP_close_io( &inp_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close output 
   ========================================================================== */
   GIOSIP_close_io( &out_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_ima );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_speckle */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLSpckGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the resampling tool

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLSpckGetInputPar
                        (/*IN    */ INTx4                      npar,
                         /*IN    */ IDL_VPTR                  *val,
                         /*IN    */ char                      *kw,
                         /*   OUT*/ STBXPT_speckle_idl_par    *idl_par,
                         /*IN OUT*/ ERRSIT_status             *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLSpckGetInputPar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   static float           edge_th = 0.0, line_th = 0.0;
   static IDL_STRING      mask_file;
   static int             edge_th_there, line_th_there, mask_file_there;
   static IDL_KW_PAR      kw_pars[] = 
               { 
                 { "EDGE_TH", IDL_TYP_FLOAT, 1, 0, 
                   &edge_th_there, IDL_CHARA(edge_th)},
                 {"LINE_TH", IDL_TYP_FLOAT, 1, 0,
                   &line_th_there, IDL_CHARA(line_th)},
                 {"MASK_FILE", IDL_TYP_STRING, 1, 0,
                   &mask_file_there, IDL_CHARA(mask_file)},
                 { NULL }
               };
   IDL_VPTR               plain_args[ 20 ];

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  par = 0;

#ifdef __SGI__
/* ==========================================================================
   Set the keyword parameters structure has the declaration settings is not
   so safe
   ========================================================================== */
   sprintf( kw_pars[ 0 ].keyword, "EDGE_TH" );
   kw_pars[ 0 ].type = IDL_TYP_FLOAT;
   kw_pars[ 0 ].mask = 1;
   kw_pars[ 0 ].flags = 0;
   kw_pars[ 0 ].specified = &edge_th_there;
   kw_pars[ 0 ].value = IDL_CHARA(edge_th);
   sprintf( kw_pars[ 1 ].keyword, "LINE_TH" );
   kw_pars[ 1 ].type = IDL_TYP_FLOAT;
   kw_pars[ 1 ].mask = 1;
   kw_pars[ 1 ].flags = 0;
   kw_pars[ 1 ].specified = &line_th_there;
   kw_pars[ 1 ].value = IDL_CHARA(line_th);
   sprintf( kw_pars[ 2 ].keyword, "MASK_FILE" );
   kw_pars[ 2 ].type = IDL_TYP_STRING;
   kw_pars[ 2 ].mask = 1;
   kw_pars[ 2 ].flags = 0;
   kw_pars[ 2 ].specified = &mask_file_there;
   kw_pars[ 2 ].value = IDL_CHARA(mask_file);
   memset( &(kw_pars[ 3 ]), 0, sizeof( IDL_KW_PAR ) );
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Init structure
   ========================================================================== */
   memset( (void *) idl_par, 0, sizeof( STBXPT_speckle_idl_par ) );

/* ==========================================================================
   Init static variables
   ========================================================================== */
   edge_th_there = line_th_there = mask_file_there = 0;

/* ==========================================================================
   Get keywords
   ========================================================================== */
   IDL_KWGetParams( npar, val, kw, kw_pars, plain_args, 1);
   if(  mask_file_there && 
       !strcmp((char *) IDL_STRING_STR(&mask_file),"       1") ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param, 
            "Unknown option keyword");
   }
   strcpy( idl_par->mask_file, 
           (mask_file_there ? 
            IDL_STRING_STR(&mask_file) : ""));

   if( mask_file_there && (!edge_th_there || !line_th_there) ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param, 
           "Edge and line threshold mandatory for a user mask file");
   }

   if( edge_th_there ) {
      if( (edge_th <= 0.0 ) ||
          (edge_th >  1.0 ) ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param, "edge_th");
      }
      else {
         idl_par->edge_th = edge_th;
      }
   }
   else {
      idl_par->edge_th = 0.0;
   }
   if( line_th_there ) {
      if( (line_th <= 0.0 ) ||
          (line_th >  1.0 ) ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_inv_inp_param, "line_th");
      }
      else {
         idl_par->line_th = line_th;
      }
   }
   else {
      idl_par->line_th = 0.0;
   }

#ifdef __TRACE__
   fprintf(stdout, "edge_th=%f\n", idl_par->edge_th);
   fprintf(stdout, "line_th=%f\n", idl_par->line_th);
   fprintf(stdout, "mask_file=<%s>\n", idl_par->mask_file);
#endif

/* ==========================================================================
   Clean up keyword settings
   ========================================================================== */
   IDL_KWCleanup( IDL_KW_CLEAN_ALL );

/* ==========================================================================
   Input image
   ========================================================================== */
   STBXPP_IDLI_GetImage ( val[ par ], &(idl_par->inp_ima), 
                          &(idl_par->NRowsInp), &(idl_par->NColsInp), 
                          &(idl_par->InpDataType), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
   if ( ( idl_par->NRowsInp <= 0 ) || ( idl_par->NColsInp <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "negative or null input image dimensions" );
   }

/* ==========================================================================
   Get window sizes (row/col)
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ], 
                             (UINTx1)DATA_TYPE_UINTx4,
                             (void *)&(idl_par->Kr), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   if( (idl_par->Kr % 2) == 0 ) {
	  ERRSIM_set_error( status_code, ERRSID_STBX_parm_is_even, 
            "Row window Size" );
   }

   STBXPP_IDLI_GetParValue ( val[ ++par ], 
                             (UINTx1)DATA_TYPE_UINTx4,
                             (void *)&(idl_par->Kc), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   if( (idl_par->Kc % 2) == 0 ) {
	  ERRSIM_set_error( status_code, ERRSID_STBX_parm_is_even, 
            "Column window Size" );
   }


/* ==========================================================================
   Get look number
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ],
                             (UINTx1)DATA_TYPE_float, 
                             (void *)&(idl_par->look_no), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Get PFA
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ],
                             (UINTx1)DATA_TYPE_float, 
                             (void *)&(idl_par->pfa), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   if( idl_par->pfa <= 0 ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
         "PFA should be greater than 0.0" );
   }

/* ==========================================================================
   Get scatter threshold
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ],
                             (UINTx1)DATA_TYPE_float, 
                             (void *)&(idl_par->scatter_th), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

#ifdef __TRACE__
   printf("look_no = %f\n", idl_par->look_no);
   printf("scatter_th = %f\n", idl_par->scatter_th);
#endif
/* ==========================================================================
   Compute NRowsOut and NColsOut
   ========================================================================== */
   if( idl_par->NRowsInp < idl_par->Kr ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
         "Row window size greater or equal that number of input rows" );
   }
   idl_par->NRowsOut = (UINTx4) (idl_par->NRowsInp - idl_par->Kr + 1);
   if( idl_par->NColsInp < idl_par->Kc ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
         "Column window size greater or equal that number of input columns");
   }
   idl_par->NColsOut = (UINTx4) (idl_par->NColsInp - idl_par->Kc + 1);
   
error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLSpckGetInputPar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLSpeckleFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      speckle filtering taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLSpeckleFillAnno
                        (/*IN    */ UINTx1                   imanum,
                         /*IN    */ STBXPT_speckle_idl_par   idl_par,
                         /*IN OUT*/ ERRSIT_status           *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLSpeckleFillAnno";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Fill the global structure
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum ].ImageLength = (INTx4) idl_par.NRowsInp;
   IANNIV_ImageAnnot[ imanum ].ImageWidth = (INTx4) idl_par.NColsInp;
   switch ( idl_par.InpDataType ) {
      case LDEFIE_dt_UINTx1:
      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_INTx4:
      case LDEFIE_dt_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 1;
      break;
      case LDEFIE_dt_2_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 2;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
"the input image has a type not allowable for SAR Toolbox Speckle Filtering" );
   }

   IANNIV_ImageAnnot[ imanum ].LooksNumber = idl_par.look_no;

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLSpeckleFillAnno */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_gainconv

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - MinPerc      : a value associated to the 
                                              starting level of the linear 
                                              conversion
                             - MaxPerc      : a value associated to the 
                                              ending level of the linear 
                                              conversion
                             - NoBlacks     : a value to be used as the 
                                              initial image levels outside
                                              the conversion
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored


        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the GAIN
                      CONVERTION of the SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_gainconv
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw ) 
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_XCON";
#else
   const ERRSIT_proc_class proc_class   = "conv";
#endif
   const ERRSIT_proc_name routine_name = "stbx_gainconv";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   STBXPT_gain_idl_par    idl_par;        /* structure with the input */
                                          /* parameters for the task  */
   IDL_VPTR               idl_out_ima;
   UINTx4                 inp_ima_num = 0;     /* image number */
   UINTx4                 out_ima_num = 0;     /* image number */

/* ==========================================================================
   IO variables
   ========================================================================== */
   GIOSIT_io              inp_io, out_io;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );


/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_convertion_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Set IDL dump
   ========================================================================== */
   ERRSIV_dump_to_idl = 1;

/* ==========================================================================
   Fill the input parameters structure
   ========================================================================== */
   STBXPP_IDLI_IDLGainGetInputPar ( val, npar, kw, &idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Fill the image description structure
   ========================================================================== */
   STBXPP_IDLI_IDLGainFillAnno ( inp_ima_num, idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Set the type of the output image
   ========================================================================== */
   idl_par.OutDataType = LDEFIE_dt_UINTx1;

/* ==========================================================================
   Set the dimension of the output image
   ========================================================================== */
   idl_par.NRowsOut = idl_par.NRowsInp;
   idl_par.NColsOut = idl_par.NColsInp;

/* ==========================================================================
   Create the output image
   ========================================================================== */
   STBXPP_IDLI_CreateMatrix( &idl_out_ima,
                              idl_par.OutDataType,
                              idl_par.NRowsOut,
                              idl_par.NColsOut,
                              (void **) &(idl_par.out_ima),
                             &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Initialize the output images TIFF structures
   ========================================================================== */
   inp_io.type = GIOSIE_buffer;
   inp_io.mode = 'r';
   inp_io.val.buff.Buffer = idl_par.inp_ima;
   inp_io.val.buff.NRows = idl_par.NRowsInp;
   inp_io.val.buff.NColumns = idl_par.NColsInp;
   inp_io.val.buff.DataType = idl_par.InpDataType;

   GIOSIP_open_io( &inp_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

   out_io.type = GIOSIE_buffer;
   out_io.mode = 'w';
   out_io.val.buff.Buffer = idl_par.out_ima;
   out_io.val.buff.NRows = idl_par.NRowsOut;
   out_io.val.buff.NColumns = idl_par.NColsOut;
   out_io.val.buff.DataType = idl_par.OutDataType;

   GIOSIP_open_io( &out_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_gaincvs( &inp_io,
                    inp_ima_num,
                    0,
                    0,
                    idl_par.NRowsInp,
                    idl_par.NColsInp,
                    idl_par.min_perc,
                    idl_par.max_perc,
                    idl_par.no_black_founded,
                    idl_par.no_black,
                   &out_io,
                    out_ima_num,
 		   &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close input
   ========================================================================== */
   GIOSIP_close_io( &inp_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close output 
   ========================================================================== */
   GIOSIP_close_io( &out_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_ima );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_gainconv */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLGainGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the gain conversion task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLGainGetInputPar
                        (/*IN    */ IDL_VPTR             *val,
                         /*IN    */ INTx4                 npar,
                         /*IN    */ char                 *kw,
                         /*   OUT*/ STBXPT_gain_idl_par  *idl_par,
                         /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLGainGetInputPar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  par = 0;
   static int             no_black_there;
   static float           no_black;
   static IDL_KW_PAR      kw_pars[] =
               {
                 { "NO_BLACK", IDL_TYP_FLOAT, 1, 0,
                   &no_black_there, IDL_CHARA(no_black)},
                 { NULL }
               };
   IDL_VPTR               plain_args[ 10 ];

#ifdef __SGI__
/* ==========================================================================
   Set the keyword parameters structure has the declaration settings is not
   so safe
   ========================================================================== */
   sprintf( kw_pars[ 0 ].keyword, "NO_BLACK" );
   kw_pars[ 0 ].type = IDL_TYP_FLOAT;
   kw_pars[ 0 ].mask = 1;
   kw_pars[ 0 ].flags = 0;
   kw_pars[ 0 ].specified = &no_black_there;
   kw_pars[ 0 ].value = IDL_CHARA(no_black);
   memset( &(kw_pars[1]), 0, sizeof( IDL_KW_PAR ) );
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Init structure
   ========================================================================== */
   memset( (void *) idl_par, 0, sizeof( STBXPT_gain_idl_par ) );

/* ==========================================================================
   Init static variables
   ========================================================================== */
   no_black_there = 0; no_black = 0.0;

/* ==========================================================================
   Get keywords
   ========================================================================== */
   IDL_KWGetParams( npar, val, kw, kw_pars, plain_args, 1);
   if( no_black_there ) {
      idl_par->no_black = no_black;
      idl_par->no_black_founded = TRUE;
   }
   else {
      idl_par->no_black_founded = FALSE;
   }

/* ==========================================================================
   Clean up keyword settings
   ========================================================================== */
   IDL_KWCleanup( IDL_KW_CLEAN_ALL );
 
/* ==========================================================================
   Input image
   ========================================================================== */
   STBXPP_IDLI_GetImage ( val[ par ], &(idl_par->inp_ima), 
                          &(idl_par->NRowsInp), &(idl_par->NColsInp), 
                          &(idl_par->InpDataType), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
   if ( ( idl_par->NRowsInp <= 0 ) || ( idl_par->NColsInp <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "InpIma has negative or null input image dimensions" );
   }

/* ==========================================================================
   Get min_perc
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                             (void *)&(idl_par->min_perc), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   if( (idl_par->min_perc < 0.0) ||
       (idl_par->min_perc > 100.0) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "MinPerc is a percentage" );
   }

/* ==========================================================================
   Get max_perc
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                             (void *)&(idl_par->max_perc), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   if( (idl_par->max_perc < 0.0) ||
       (idl_par->max_perc > 100.0) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "MaxPerc is a percentage" );
   }

   if( idl_par->min_perc >= idl_par->max_perc ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
         "MinPerc should be less than MaxPerc" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLGainGetInputPar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLGainFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      gain conversion taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLGainFillAnno
                        (/*IN    */ UINTx1                imanum,
                         /*IN    */ STBXPT_gain_idl_par   idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLGainFillAnno";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;


/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Fill the global structure
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum ].ImageLength = (INTx4) idl_par.NRowsInp;
   IANNIV_ImageAnnot[ imanum ].ImageWidth = (INTx4) idl_par.NColsInp;

   switch ( idl_par.InpDataType ) {
      case LDEFIE_dt_UINTx1:
      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_INTx4:
      case LDEFIE_dt_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 1;
      break;
      case LDEFIE_dt_2_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 2;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
      "the input image has a type not allowable for SAR Toolbox Gain Convertion" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLGainFillAnno */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_lutconv

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - UserLutFile  : a file name of a user-defined 
                                              look-up table
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored


        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the GAIN
                      CONVERTION of the SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_lutconv
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val ) 
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_XCON";
#else
   const ERRSIT_proc_class proc_class   = "conv";
#endif
   const ERRSIT_proc_name routine_name = "stbx_lutconv";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   STBXPT_lut_idl_par     idl_par;        /* structure with the input */
                                          /* parameters for the task  */
   IDL_VPTR               idl_out_ima;
   UINTx4                 inp_ima_num = 0;     /* image number */
   UINTx4                 out_ima_num = 0;     /* image number */

/* ==========================================================================
   IO variables
   ========================================================================== */
   GIOSIT_io              inp_io, out_io;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_convertion_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Set IDL dump
   ========================================================================== */
   ERRSIV_dump_to_idl = 1;

/* ==========================================================================
   Fill the input parameters structure
   ========================================================================== */
   STBXPP_IDLI_IDLLutGetInputPar ( val, npar, &idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Fill the image description structure
   ========================================================================== */
   STBXPP_IDLI_IDLLutFillAnno ( inp_ima_num, idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Set the type of the output image
   ========================================================================== */
   idl_par.OutDataType = LDEFIE_dt_UINTx1;

/* ==========================================================================
   Set the dimension of the output image
   ========================================================================== */
   idl_par.NRowsOut = idl_par.NRowsInp;
   idl_par.NColsOut = idl_par.NColsInp;

/* ==========================================================================
   Create the output image
   ========================================================================== */
   STBXPP_IDLI_CreateMatrix( &idl_out_ima,
                              idl_par.OutDataType,
                              idl_par.NRowsOut,
                              idl_par.NColsOut,
                              (void **) &(idl_par.out_ima),
                             &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Initialize the output images TIFF structures
   ========================================================================== */
   inp_io.type = GIOSIE_buffer;
   inp_io.mode = 'r';
   inp_io.val.buff.Buffer = idl_par.inp_ima;
   inp_io.val.buff.NRows = idl_par.NRowsInp;
   inp_io.val.buff.NColumns = idl_par.NColsInp;
   inp_io.val.buff.DataType = idl_par.InpDataType;

   GIOSIP_open_io( &inp_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

   out_io.type = GIOSIE_buffer;
   out_io.mode = 'w';
   out_io.val.buff.Buffer = idl_par.out_ima;
   out_io.val.buff.NRows = idl_par.NRowsOut;
   out_io.val.buff.NColumns = idl_par.NColsOut;
   out_io.val.buff.DataType = idl_par.OutDataType;

   GIOSIP_open_io( &out_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_ugaincvs( &inp_io,
                     inp_ima_num,
                     0,
                     0,
                     idl_par.NRowsInp,
                     idl_par.NColsInp,
                     idl_par.lut_file,
                    &out_io,
                     out_ima_num,
                    &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close input
   ========================================================================== */
   GIOSIP_close_io( &inp_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close output 
   ========================================================================== */
   GIOSIP_close_io( &out_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_ima );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_lutconv */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLLutGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the LUT gain conversion task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLLutGetInputPar
                        (/*IN    */ IDL_VPTR             *val,
                         /*IN    */ INTx4                 npar,
                         /*   OUT*/ STBXPT_lut_idl_par   *idl_par,
                         /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLLutGetInputPar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  par = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Init structure
   ========================================================================== */
   memset( (void *) idl_par, 0, sizeof( STBXPT_lut_idl_par ) );

/* ==========================================================================
   Input image
   ========================================================================== */
   STBXPP_IDLI_GetImage ( val[ par ], &(idl_par->inp_ima), 
                          &(idl_par->NRowsInp), &(idl_par->NColsInp), 
                          &(idl_par->InpDataType), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
   if ( ( idl_par->NRowsInp <= 0 ) || ( idl_par->NColsInp <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "InpIma has negative or null input image dimensions" );
   }

/* ==========================================================================
   Get lut_file
   ========================================================================== */
   STBXPP_IDLI_GetString( val[ ++par ], idl_par->lut_file, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );


error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLLutGetInputPar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLLutFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      LUT gain conversion taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLLutFillAnno
                        (/*IN    */ UINTx1                imanum,
                         /*IN    */ STBXPT_lut_idl_par    idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLLutFillAnno";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;


/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Fill the global structure
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum ].ImageLength = (INTx4) idl_par.NRowsInp;
   IANNIV_ImageAnnot[ imanum ].ImageWidth = (INTx4) idl_par.NColsInp;

   switch ( idl_par.InpDataType ) {
      case LDEFIE_dt_UINTx1:
      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_INTx4:
      case LDEFIE_dt_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 1;
      break;
      case LDEFIE_dt_2_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 2;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
      "the input image has a type not allowable for SAR Toolbox Lut Gain Convertion" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLLutFillAnno */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_sclconv

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - ScaleFact    : image scaling factor value
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored


        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the GAIN
                      CONVERTION of the SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
EXPORT IDL_VPTR stbx_sclconv
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val ) 
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_XCON";
#else
   const ERRSIT_proc_class proc_class   = "conv";
#endif
   const ERRSIT_proc_name routine_name = "stbx_sclconv";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   STBXPT_scale_idl_par   idl_par;        /* structure with the input */
                                          /* parameters for the task  */
   IDL_VPTR               idl_out_ima;
   UINTx4                 inp_ima_num = 0;     /* image number */
   UINTx4                 out_ima_num = 0;     /* image number */

/* ==========================================================================
   IO variables
   ========================================================================== */
   GIOSIT_io              inp_io, out_io;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_convertion_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Set IDL dump
   ========================================================================== */
   ERRSIV_dump_to_idl = 1;

/* ==========================================================================
   Fill the input parameters structure
   ========================================================================== */
   STBXPP_IDLI_IDLSclGetInputPar ( val, npar, &idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Fill the image description structure
   ========================================================================== */
   STBXPP_IDLI_IDLSclFillAnno ( inp_ima_num, idl_par, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Set the type of the output image
   ========================================================================== */
   idl_par.OutDataType = LDEFIE_dt_UINTx1;

/* ==========================================================================
   Set the dimension of the output image
   ========================================================================== */
   idl_par.NRowsOut = idl_par.NRowsInp;
   idl_par.NColsOut = idl_par.NColsInp;

/* ==========================================================================
   Create the output image
   ========================================================================== */
   STBXPP_IDLI_CreateMatrix( &idl_out_ima,
                              idl_par.OutDataType,
                              idl_par.NRowsOut,
                              idl_par.NColsOut,
                              (void **) &(idl_par.out_ima),
                             &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Initialize the output images TIFF structures
   ========================================================================== */
   inp_io.type = GIOSIE_buffer;
   inp_io.mode = 'r';
   inp_io.val.buff.Buffer = idl_par.inp_ima;
   inp_io.val.buff.NRows = idl_par.NRowsInp;
   inp_io.val.buff.NColumns = idl_par.NColsInp;
   inp_io.val.buff.DataType = idl_par.InpDataType;

   GIOSIP_open_io( &inp_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

   out_io.type = GIOSIE_buffer;
   out_io.mode = 'w';
   out_io.val.buff.Buffer = idl_par.out_ima;
   out_io.val.buff.NRows = idl_par.NRowsOut;
   out_io.val.buff.NColumns = idl_par.NColsOut;
   out_io.val.buff.DataType = idl_par.OutDataType;

   GIOSIP_open_io( &out_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_sgaincvs( &inp_io,
                     inp_ima_num,
                     0,
                     0,
                     idl_par.NRowsInp,
                     idl_par.NColsInp,
                     idl_par.scale_fact,
                    &out_io,
                     out_ima_num,
                    &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close input
   ========================================================================== */
   GIOSIP_close_io( &inp_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close output 
   ========================================================================== */
   GIOSIP_close_io( &out_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

   if( status_code == ERRSID_normal ) {
      return( idl_out_ima );
   }
   else {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_LONGJMP, " ");
   }

   return( (IDL_VPTR) NULL );
} /* stbx_sclconv */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLSclGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the Scale factor gain conversion task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLSclGetInputPar
                        (/*IN    */ IDL_VPTR             *val,
                         /*IN    */ INTx4                 npar,
                         /*   OUT*/ STBXPT_scale_idl_par *idl_par,
                         /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLSclGetInputPar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  par = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Init structure
   ========================================================================== */
   memset( (void *) idl_par, 0, sizeof( STBXPT_scale_idl_par ) );

/* ==========================================================================
   Input image
   ========================================================================== */
   STBXPP_IDLI_GetImage ( val[ par ], &(idl_par->inp_ima), 
                          &(idl_par->NRowsInp), &(idl_par->NColsInp), 
                          &(idl_par->InpDataType), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check the image dimensions
   ========================================================================== */
   if ( ( idl_par->NRowsInp <= 0 ) || ( idl_par->NColsInp <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "InpIma has negative or null input image dimensions" );
   }


/* ==========================================================================
   Get scaling factor
   ========================================================================== */
   STBXPP_IDLI_GetParValue ( val[ ++par ], (UINTx1)DATA_TYPE_float,
                             (void *)&(idl_par->scale_fact), status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   if( idl_par->scale_fact == 0.0 ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
                         "ScaleFactor should be nonzero" );
   }


error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLSclGetInputPar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLSclFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      Scale factor gain conversion taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
void STBXPP_IDLI_IDLSclFillAnno
                        (/*IN    */ UINTx1                imanum,
                         /*IN    */ STBXPT_scale_idl_par  idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_IDLI_IDLSclFillAnno";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;


/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Fill the global structure
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum ].ImageLength = (INTx4) idl_par.NRowsInp;
   IANNIV_ImageAnnot[ imanum ].ImageWidth = (INTx4) idl_par.NColsInp;

   switch ( idl_par.InpDataType ) {
      case LDEFIE_dt_UINTx1:
      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_INTx4:
      case LDEFIE_dt_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 1;
      break;
      case LDEFIE_dt_2_float:
         IANNIV_ImageAnnot[ imanum ].SamplePerPixel = 2;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_STBX_inv_inp_param,
      "the input image has a type not allowable for SAR Toolbox Scale Factor Gain Convertion" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* STBXPP_IDLI_IDLSclFillAnno */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_dump

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - OutFile      : Output Dump File Namevalue

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the DUMP
                      ANCILLARY ANNOTATION of the SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information

   $EH
   ========================================================================== */
EXPORT void stbx_dump
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val ) 
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_XCON";
#else
   const ERRSIT_proc_class proc_class   = "conv";
#endif
   const ERRSIT_proc_name routine_name = "stbx_dump";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   FILSIT_file_name       inImage, outFile;
   INTx4                  par = 0;

/* ==========================================================================
   IO variables
   ========================================================================== */
   GIOSIT_io              inp_io;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_convertion_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Set IDL dump
   ========================================================================== */
   ERRSIV_dump_to_idl = 1;

/* ==========================================================================
   Get input TIFF file name and output Dump file
   ========================================================================== */
   STBXPP_IDLI_GetString( val[ par ], inImage, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

   STBXPP_IDLI_GetString( val[ ++par ], outFile, &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                   &status_code);
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   CONVIP_dumpannot( &inp_io,
                      outFile,
                     &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Close input
   ========================================================================== */
   GIOSIP_close_io( &inp_io, &status_code);
   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

} /* stbx_dump */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_help

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the help
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
EXPORT void stbx_help
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_XSTB";
#else
   const ERRSIT_proc_class proc_class   = "stbx";
#endif
   const ERRSIT_proc_name routine_name = "stbx_help";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

   char                   idl_routine[ 100 ];
   UINTx4                 i;
   char                  *ptr, line[ STBXPD_IDLI_max_mess_length ];
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );


/* ==========================================================================
   Try to print help, if any
   ========================================================================== */
   if( npar == 0 ) {
      IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, "Usage: stbx_help, \"stbx_topic\" " );
      IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, "Allowed stbx_topics:" );
      for( i=0; i<STBXPD_idl_total_task_no; i++ ) {
         if( strcmp( STBXPV_IDLI_routine_name[ i ], " " ) ) {
            sprintf( idl_routine, "   %s", STBXPV_IDLI_routine_name[ i ] );
            IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, idl_routine );
         }
      }
   }
   else if( ( npar == 1 ) &&
            ( val[ 0 ]->type == IDL_TYP_STRING ) ) {
      sprintf(idl_routine, "%s", IDL_STRING_STR( &(val[ 0 ]->value.str) ) );
      for( i=0; i<STBXPD_idl_total_task_no; i++ ) {
         if( !strcmp( idl_routine, STBXPV_IDLI_routine_name[ i ] ) ) {
            /* fprintf ( stdout, "%s", STBXPV_IDLI_help_message[ i ] ); */
            IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, " ");
	    if( strlen( STBXPV_IDLI_help_message[ i ] ) > STBXPD_IDLI_max_mess_length ) {
	       strncpy( line, STBXPV_IDLI_help_message[ i ], STBXPD_IDLI_max_mess_length - 1 );
	       line[ STBXPD_IDLI_max_mess_length - 1 ] = '\0';
	    }
	    else {
               strcpy(line, STBXPV_IDLI_help_message[ i ]);
	    }
            ptr = strtok( line, "$");
            do {
               ptr = strtok( '\0', "$" );
               if( ptr ) {
                  IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, ptr );
               }
            } while( ptr );
            IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, " ");
            break;
         }
      }

   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

} /* stbx_help */
