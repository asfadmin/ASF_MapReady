/* ==========================================================================
   $MODULE_HEADER

      $NAME             FIIS_GETS

      $FUNCTION         Provide a function set uset to get the info from the 
                        specified file.

      $ROUTINES         FIISIP_GETS_get_info
                        FIISPP_GETS_get_last_section
			FIISIP_GETS_get_sections

      $HISTORY

           SCR NO.   DATE          INITIALS        DESCRIPTION
   -------------------------------------------------------------------------
        N/A         02/11/92       AC             First Issue
        SCR #10     01/12/97       AG             Check output *section_no
                                                  on zero and returns error
                                                  in FIISIP_GETS_get_sections
        SCR #12     01/12/97       AG             Fixed bug in FIISIP_GETS_get_info
                                                  when looking for parameter
                                                  name in buffer lines
        SCR #14     01/12/97       AG             Set error in FIISIP_GETS_get_info
                                                  when sscanf fails
        SCR #15     02/12/97       AG             Set error in FIISIP_GETS_get_info
                                                  for null strings
        SCR #22     17/12/97       AG             Set error in FIISIP_GETS_get_info
                                                  for line too long

   ========================================================================== */


/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include FILS_INTF_H
#include FIIS_INTF_H
#include FIIS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

static void trace_in( ERRSIT_flag      process_flag )
{
   ERRSIT_status log_status_code;
   char          tmp_char[FIISID_max_char];

   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);


   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);
}

static void trace_out( ERRSIT_flag   process_flag )
{
   ERRSIT_status log_status_code;

   ERRSIP_HPEL_trace_proc_err_log(" ",&log_status_code);
   ERRSIP_HPEL_trace_proc_err_log("NO OUTPUT PARAMETER:", &log_status_code);
}

/* ==========================================================================

   $ROUTINE_HEADER

   $NAME         FIISIP_GETS_get_info

   $DESCRIPTION  Read the wanted parameters from the specified INI file.

   $TYPE         PROCEDURE

   $INPUT        file_name  : INI file name
                 section    : section name of the INI file in which the
                              searched parameter is
                 section_no : number of the section in the INI file
                              or 0, if unknown

   $MODIFIED     param	    : pointer to the parameter to fill

   $GLOBAL       NONE

   $RET_STATUS   ERRSID_FIIS_err_bad_input
                 ERRSID_FIIS_err_open_file

   $WARNING      NONE

   $PDL
                 - Input check
                 - Search the section
                 - Search the tag and consider vector definitions

   $EH
   ========================================================================== */
void FIISIP_GETS_get_info
                   ( /*IN    */ FILSIT_file_name       file_name,
                     /*IN    */ char                  *section,
                     /*IN    */ UINTx4                 section_no,
                     /*IN OUT*/ FIISIT_parm           *parm,
                     /*   OUT*/ ERRSIT_status         *status_code )
{
   const ERRSIT_proc_name  routine_name = "FIISIP_GETS_get_info";
   ERRSIT_status           log_status_code;
   ERRSIT_flag             process_flag;
   FILE                   *fid = NULL;
   char                   *result;
   char                   *pos_eq = NULL;
   char                   *op_brak;
   char                   *cl_brak;
   LDEFIT_boolean          flag;
   char                    file_buff[ FIISID_max_char ];
   LDEFIT_boolean          new_section = FALSE;
   INTx4                   i;
   UINTx4                  count_section;
   char                    tmp_buff[ FIISID_max_char ];
   char                    tmp_buff1[ FIISID_max_char ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   parm->founded = FALSE;

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in( process_flag );
   }

/* ==========================================================================
   Check input paramaters
   ========================================================================== */
   if (( file_name    == NULL ) || 
       ( section      == NULL ) ||
       ( parm->name   == NULL ) ||
       ( parm->value  == NULL ))
   {
      ERRSIM_set_error( status_code,
                        ERRSID_FIIS_err_bad_input,
                        ": # 1" );
   }

/* ==========================================================================
   Open INI file for read
   ========================================================================== */
   FILSIP_open( file_name, "r", 0, &fid, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Search the section required
   ========================================================================== */
   count_section = 0;
   for( result =  fgets( file_buff, FIISID_max_char, fid );
        ( (result != NULL) && (new_section == FALSE) && 
          ( parm->founded == FALSE ));
        result =  fgets( file_buff, FIISID_max_char, fid )) {

/* ==========================================================================
   Skip the blank on the beginning of the line
   ========================================================================== */
      for( op_brak = file_buff, i = 0;
           ( ((*op_brak) == ' ') && 
             ((*op_brak) != '\0') && 
             (i < FIISID_max_char));
              op_brak++, i++ );

/* ==========================================================================
   Check if the first character after the blanks is an open square bracket
   ========================================================================== */
      if ( *op_brak == '[' )
      {
         count_section++;
/* ==========================================================================
   Looks for the closed square bracket
   ========================================================================== */
         cl_brak = strchr( op_brak, ']' );
         if ( cl_brak != NULL )
         {
            *cl_brak = '\0';
         }
      }

/* ==========================================================================
   Test if the name inside the bracket is the section required
   ========================================================================== */
      if( ( *op_brak == '[' ) && ( !strcmp( (op_brak + 1), section )) &&
          ( ( section_no == 0) || 
            ( (section_no != 0) && (count_section == section_no) ) )
        ) {

/* ==========================================================================
   Search the tag required in the appropriate section
   ========================================================================== */
         for( result = fgets( file_buff, FIISID_max_char, fid ), 
              new_section = FALSE;
              ( result != NULL ) && ( new_section == FALSE ) &&
              ( parm->founded == FALSE );
              result = fgets( file_buff, FIISID_max_char, fid )) {

            if( strcmp( file_buff, "\n" ) ) {

/* ==========================================================================
   Skip the blank on the start of the line
   ========================================================================== */
               for(    pos_eq  = file_buff,                       i = 0;
                    ((*pos_eq) == ' ') && ((*pos_eq) != '\0') && (i < FIISID_max_char);
                       pos_eq++,                                  i++ );

/* ==========================================================================
   Check if a new section has been found
   ========================================================================== */
               if ( *pos_eq == '[' ) {
                  count_section++;
                  cl_brak  = strchr( pos_eq, ']' );
                  if ( cl_brak != NULL )
                  {
                     *cl_brak = '\0';
                  }


/* ==========================================================================
   Exit is a different section is found
   ========================================================================== */
                  if( strcmp( (op_brak + 1), section ) || 
                      (section_no == 0) || (count_section != section_no) ) {
                     new_section = TRUE;
                  }
               }
               else if ( strcmp( pos_eq, "\n" ) ) {
                  FIISIT_parm_name  parmname;

/* ==========================================================================
   If this is the requested parameter ...
   ========================================================================== */
                  if( strchr(pos_eq, '=') == (char *) NULL ) {
                     ERRSIM_set_error( status_code,
                                       ERRSID_FIIS_err_bad_input,
                                       file_buff );
                  }
                  strncpy( parmname, pos_eq, strchr(pos_eq, '=') - pos_eq);
                  parmname[ strchr(pos_eq, '=') - pos_eq ] = '\0';
                  for( i=strlen(parmname)-1; i>=0; i++) {
                     if( parmname[i] == ' ' ) {
                        parmname[ i ] = '\0';
                     }
                     else {
                        break;
                     }
                  }
                  if (!strcmp( parmname, parm->name )) {

                     switch( parm->type )
                     {
                        case FIISIE_tt_char :
                        {
/* ==========================================================================
   Looks for the first '
   ========================================================================== */
                           pos_eq = strchr( file_buff, '\'' );
                           if ( pos_eq != NULL ) {
                              *((char*)parm->value) = *(pos_eq + 1);
                              parm->founded = TRUE;
                           }
                           else {
                              pos_eq = strchr( file_buff, '\"' );
                              if ( pos_eq != NULL ) {
                                 *((char*)parm->value) = *(pos_eq + 1);
                                 parm->founded = TRUE;
                              }
                              else {
                                 ERRSIM_set_error( status_code,
                                                   ERRSID_FIIS_err_bad_input,
                                                   file_buff );
                              }
                           }
                           break;
                        }
                        case FIISIE_tt_string :
                        {
                           char *p,*q;

/* ==========================================================================
   Looks for the '=' separator
   ========================================================================== */
                           pos_eq = strchr( file_buff, '=' );
                           memset( tmp_buff, '\0', FIISID_max_char );
                           strcpy( tmp_buff, pos_eq+1 );

/* ==========================================================================
   Tokenize tmp_buff string in ", "
   ========================================================================== */
                           if ( ( p = strtok( tmp_buff, "," ) ) == NULL ) {
                              ERRSIM_set_error( status_code,
                                                ERRSID_FIIS_err_bad_input,
                                                file_buff );
                           }

                           parm->number = 0;

/* ==========================================================================
   Loop on definition of vector of strings
   ========================================================================== */
                           do {

/* ==========================================================================
   Looks for the first "
   ========================================================================== */
                              pos_eq = strchr( p, '\"' );
                              if ( pos_eq != NULL ) {

                                 memset( tmp_buff1, '\0', FIISID_max_char );
                                 strcpy( tmp_buff1, pos_eq+1 );

/* ==========================================================================
   Looks for the second "
   ========================================================================== */
                                 pos_eq = strchr( tmp_buff1, '\"' );
			         if ( pos_eq != NULL ) {
				    *pos_eq = '\0';

				    if( strlen(tmp_buff) > parm->size ) {
                                       tmp_buff1[ parm->size ] ='\0';
                                    }

                                    if( !strcmp( tmp_buff1, "" ) ) {
			               ERRSIM_set_error( status_code,
                                                         ERRSID_FIIS_err_bad_input,
						         file_buff );
                                    }

				    if( parm->vector ) {
                                       if( parm->number < parm->max_number ) {
                                          q = (char *)parm->value + parm->number*parm->size;
					  memset( q, '\0', parm->size );
					  strcpy( q, tmp_buff1 );
					  q[ parm->size - 1 ] = '\0';
                                          parm->number++;
				       }
				    }
				    else {
				       memset( parm->value, '\0', parm->size );
				       strcpy( (char*)parm->value, tmp_buff1 );
				       ((char*)parm->value)[ parm->size - 1 ] = '\0';
				    }
				    parm->founded = TRUE;
			         }
			         else {
				    ERRSIM_set_error( status_code,
                                                      ERRSID_FIIS_err_bad_input,
                                                      file_buff );
			         }
			      }
			      else {
			         ERRSIM_set_error( status_code,
                                                   ERRSID_FIIS_err_bad_input,
						   file_buff );
			      }

/* ==========================================================================
   Get next token
   ========================================================================== */
			      p = strtok( '\0', "," );

			   } while( p != NULL );
                           break;
                        }
			 case FIISIE_tt_int :
			 case FIISIE_tt_long_int :
			 case FIISIE_tt_float :
			 case FIISIE_tt_double :
			 {
			    pos_eq = strchr( file_buff, '=' );
			    memset( tmp_buff, '\0', FIISID_max_char );
			    strcpy( tmp_buff, pos_eq+1 );

			    parm->number = 0;
/* ==========================================================================
   Loop on definition of vector
   ========================================================================== */
			    do {
			       if ( pos_eq != NULL ) {
				  switch( parm->type )
				  {
				     case FIISIE_tt_int :
				     {
					if( parm->vector ) {
					   if( parm->number < parm->max_number ) {
					      if ( sscanf( (pos_eq + 1), "%d", 
							   &(((INTx4 *) parm->value)[ parm->number ]) ) > 0) {
						 parm->founded = TRUE;
						 parm->number++;
					      }
					      else {
						 ERRSIM_set_error( status_code,
								   ERRSID_FIIS_err_bad_input,
								   parm->name );
					      }
					   }
					}
					else {
					   if ( sscanf( (pos_eq + 1), "%d", 
							(INTx4 *) parm->value ) > 0) {
					      parm->founded = TRUE;
					   }
					   else {
					      ERRSIM_set_error( status_code,
								ERRSID_FIIS_err_bad_input,
								parm->name );
					   }
					}
					break;
				     }
				     case FIISIE_tt_long_int :
				     {
					if( parm->vector ) {
					   if( parm->number < parm->max_number ) {
					      if ( sscanf( (pos_eq + 1), "%ld", 
							   &(((INTx8 *) parm->value)[ parm->number ]) ) > 0) {
						 parm->founded = TRUE;
						 parm->number++;
					      }
					      else {
						 ERRSIM_set_error( status_code,
								   ERRSID_FIIS_err_bad_input,
								   parm->name );
					      }
					   }
					}
					else {
					   if ( sscanf( (pos_eq + 1), "%ld", 
							(INTx8 *) parm->value ) > 0) {
					      parm->founded = TRUE;
					   }
					   else {
					      ERRSIM_set_error( status_code,
								ERRSID_FIIS_err_bad_input,
								parm->name );
					   }
					}
					break;
				     }
				     case FIISIE_tt_float :
				     {
					if( parm->vector ) {
					   if ( sscanf( 
						  (pos_eq + 1), "%f",
						 &(((float *)parm->value)[ parm->number ]) ) > 0) {
					      if( parm->number < parm->max_number ) {
						 parm->founded = TRUE;
						 parm->number++;
					      }
					   }
					   else {
					      ERRSIM_set_error( status_code,
								ERRSID_FIIS_err_bad_input,
								parm->name );
					   }
					}
					else {
					   if ( sscanf( 
						  (pos_eq + 1), "%f", (float*)parm->value ) > 0) {
						 parm->founded = TRUE;
					   }
					   else {
					      ERRSIM_set_error( status_code,
								ERRSID_FIIS_err_bad_input,
								parm->name );
					   }
					}
					break;
				     }
				     case FIISIE_tt_double :
				     {
					if( parm->vector ) {
					   if ( sscanf( 
						  (pos_eq + 1), "%lf",
						 &(((double *)parm->value)[ parm->number ]) ) > 0) {
					      if( parm->number < parm->max_number ) {
						 parm->founded = TRUE;
						 parm->number++;
					      }
					   }
					   else {
					      ERRSIM_set_error( status_code,
								ERRSID_FIIS_err_bad_input,
								parm->name );
					   }
					}
					else {
					   if ( sscanf( 
						  (pos_eq + 1), "%lf", (double *)parm->value ) > 0) {
						 parm->founded = TRUE;
					   }
					   else {
					      ERRSIM_set_error( status_code,
								ERRSID_FIIS_err_bad_input,
								parm->name );
					   }
					}
					break;
				     }
				  }
			       }

/* ==========================================================================
   Search next element of line. This is done also if the parameter is not a
   vector: in this case the last value is considered
   ========================================================================== */
			       pos_eq = strchr( tmp_buff, ',' );

			       if ( pos_eq != NULL ) {
				  memset( tmp_buff1, '\0', FIISID_max_char );
				  strcpy( tmp_buff1, tmp_buff );
				  pos_eq = strchr( tmp_buff1, ',' );
				  memset( tmp_buff, '\0', FIISID_max_char );
				  strcpy( tmp_buff, pos_eq+1 );
			       }

			    } while (pos_eq != NULL);
			    break;
			 }
			 default :
			 {
			    ERRSIM_set_error( status_code,
					      ERRSID_FIIS_err_bad_input,
					      "Invalid tag_type : # 3" );
			 }
		      }      
		   }
               }
            }
         }
      }
   }

   if( ERRSIM_out_parms( process_flag ))
   {
      trace_out( process_flag );
   }

error_exit:;

   if ( fid != NULL )
   {
      FILSIP_close( &fid, &log_status_code );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                           *status_code,
                          &log_status_code );

} /* FIISIP_GETS_get_info */

/* ==========================================================================

   $ROUTINE_HEADER

   $NAME         FIISPP_GETS_get_last_section

   $DESCRIPTION  Finds the last section.

   $TYPE         PROCEDURE

   $INPUT        file_name  : name of the INI file

   $MODIFIED     NONE

   $OUTPUT       section    : last section of the INI file
                 founded    : flag that indicated if the last section has
                              been founded

   $GLOBAL       NONE

   $RET_STATUS   ERRSID_FIIS_err_bad_input
                 ERRSID_FIIS_err_open_file

   $WARNING      NONE

   $PDL
                 - Input check
                 - Search last section
                 - Search the tag

   $EH
   ========================================================================== */
void FIISPP_GETS_get_last_section
                   ( /*IN    */ FILSIT_file_name      file_name,
                     /*   OUT*/ char                 *section,
                     /*   OUT*/ LDEFIT_boolean       *founded,
                     /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name  routine_name = "FIISPP_GETS_get_last_section";
   ERRSIT_status           log_status_code;
   ERRSIT_flag             process_flag;
   FILE                   *fid = NULL;
   char                   *result;
   char                   *op_brak;
   char                   *cl_brak;
   char                    file_buff[ FIISID_max_char ];
   INTx4                   i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );
   *founded = FALSE;

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in( process_flag );
   }

/* ==========================================================================
   Check input paramaters
   ========================================================================== */
   if (( file_name == NULL ) || ( section == NULL ))
   {
      ERRSIM_set_error( status_code,
                        ERRSID_FIIS_err_bad_input,
                        ": # 1" );
   }

   FILSIP_open( file_name, "r", 0, &fid, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   /* Search the section required */

   for( result =  fgets( file_buff, FIISID_max_char, fid );
        result != NULL;
        result =  fgets( file_buff, FIISID_max_char, fid ))
   {
      /* Skip the blank on the start of the line */
      for(    op_brak = file_buff,                         i = 0;
           ((*op_brak) == ' ') && ((*op_brak) != '\0') && (i < FIISID_max_char);
              op_brak++,                                   i++ );

      if ( *op_brak == '[' )
      {
         cl_brak  = strchr( op_brak, ']' );
         if ( cl_brak != NULL )
         {
            *cl_brak = '\0';
         }

	 *founded = TRUE;
	 strcpy( section, (op_brak + 1) );
      }
   }

   if( ERRSIM_out_parms( process_flag ))
   {
      trace_out( process_flag );
   }

error_exit:;

   if ( fid != NULL )
   {
      FILSIP_close( &fid, &log_status_code );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                           *status_code,
                          &log_status_code );

} /* FIISPP_GETS_get_last_section */


/* ==========================================================================

   $ROUTINE_HEADER

   $NAME         FIISIP_GETS_get_sections

   $DESCRIPTION  Finds all the sections contained in an INI file

   $TYPE         PROCEDURE

   $INPUT        file_name  : name of the INI file

   $MODIFIED     NONE

   $OUTPUT       section_no : number of section found in the INI file
                 section    : section of the INI file

   $GLOBAL       NONE

   $RET_STATUS   ERRSID_FIIS_err_bad_input
                 ERRSID_FIIS_err_open_file

   $WARNING      NONE

   $PDL
                 - Input check
                 - Search sections

   $EH
   ========================================================================== */
void FIISIP_GETS_get_sections
                   ( /*IN    */ FILSIT_file_name      file_name,
                     /*   OUT*/ UINTx4               *section_no,
                     /*   OUT*/ char               ***section,
                     /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name  routine_name = "FIISIP_GETS_get_sections";
   ERRSIT_status           log_status_code;
   ERRSIT_flag             process_flag;
   FILE                   *fid = NULL;
   char                   *result;
   char                   *op_brak;
   char                   *cl_brak;
   char                    file_buff[ FIISID_max_char ];
   INTx4                   i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in( process_flag );
   }

/* ==========================================================================
   Check input paramaters
   ========================================================================== */
   if (( file_name == NULL ) || ( section == NULL ))
   {
      ERRSIM_set_error( status_code,
                        ERRSID_FIIS_err_bad_input,
                        ": # 1" );
   }

   *section_no = 0;
   *section = (char **) NULL;

/* ==========================================================================
   Open INI file
   ========================================================================== */
   FILSIP_open( file_name, "r", 0, &fid, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   /* Search the section required */

   for( result =  fgets( file_buff, FIISID_max_char, fid );
        result != NULL;
        result =  fgets( file_buff, FIISID_max_char, fid ))
   {
      /* Skip the blank on the start of the line */
      for(    op_brak = file_buff,                         i = 0;
           ((*op_brak) == ' ') && ((*op_brak) != '\0') && (i < FIISID_max_char);
              op_brak++,                                   i++ );

      if ( *op_brak == '[' )
      {
         cl_brak  = strchr( op_brak, ']' );
         if ( cl_brak != NULL )
         {
            *cl_brak = '\0';
         }

/* ==========================================================================
   Enlarge section vector and copy section name found
   ========================================================================== */
         (*section_no)++;
         *section = (char **) MEMSIP_realloc( (void *) *section, 
                                              *section_no * sizeof(char *) );
         if( *section == (char **) NULL) {
            ERRSIM_set_error( status_code,
                              ERRSID_FIIS_err_mem_alloc,
                              "section" );
         }
         (*section)[ *section_no - 1 ] =
               (char *) MEMSIP_alloc( 256 * sizeof( char ) );
         if( (*section)[ *section_no - 1 ] == (char *) NULL) {
            ERRSIM_set_error( status_code,
                              ERRSID_FIIS_err_mem_alloc,
                              "section[i]" );
         }
	 strcpy( (*section)[ *section_no - 1 ], (op_brak + 1) );
      }
   }

   if( ERRSIM_out_parms( process_flag ))
   {
      trace_out( process_flag );
   }

   if( *section_no == 0 ) {
      ERRSIM_set_error( status_code,
                        ERRSID_FIIS_err_no_sect_found,
                        file_name );
   }


error_exit:;

   if ( fid != NULL )
   {
      FILSIP_close( &fid, &log_status_code );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                           *status_code,
                          &log_status_code );

} /* FIISIP_GETS_get_sections */
