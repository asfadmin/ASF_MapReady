/* ==========================================================================
   $MODULE_HEADER

      $NAME              IREG_BSLN

      $FUNCTION          This modulus contains the procedure for the baseline
                         evaluation in the co-registration tool

      $ROUTINE           IREGPP_BSLN_BaselineEval

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       17-MAR-98     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include COOR_INTF_H
#include IREG_INTF_H
#include IREG_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_BSLN_BaselineEval

        $TYPE         PROCEDURE

        $INPUT        mas_imanum : master image ID
                      sla_imanum : array of IDs of the slave images
                      TLRow      : row coordinate of the top left corner of the
                                   AoI
                      TLCol      : column coordinate of the top left corner of
                                   the AoI
                      NRow       : number of rows of the AoI
                      NCol       : number of columns of the AoI
                      NImages    : number of images
                      degree     : degree of the warp used in the registration
                      out_fp     : pointer to the opened ASCII file that will
                                   contain the baseline informations

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot : image annotations INFO structure

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_image_number_out
                      ERRSID_IREG_incons_corn
                      ERRSID_IREG_warp_not_create
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the baselines for all the slaves
                      WRT the master image co-registered and writes the
                      evaluated values into the ASCII file previously opened

        $WARNING      THE WARP MUST BE EVALUATE AND THE IMAGE ANNOTATIONS MUST
                      BE READ BEFORE

        $PDL          - Checks the input parameters
                      - Allocates the necessary memories
                      - Initializes the coordinates conversions for the master
                        image
                      - Sets the central points of the AoI in image coordinates
                      - Evaluates the satellite position and velocity for the
                        master central point
                      - Evaluates the cartesian coordinates of the central point
                        of the AoI on the master image
                      - Evaluates the Satellite - Target versor
                      - Loop over the slaves
                            - Evaluates the slave point corresponding to the
                              central master one
                            - Initializes the coordinates conversions for the
                              slave image
                            - Evaluates the satellite position and velocity
                              for the row of the point corresponding to the
                              master central one
                            - Evaluates the baseline cartesian components
                            - Evaluates the baseline component parallel to the
                              Satellite - Target direction
                            - Evaluates the sign to attribute to the normal
                              baseline component
                            - Evaluates the normal baseline component
                            - Writes the baseline information on the output
                              file
                      - End Loop
                      - Free the allocated memories

   $EH
   ========================================================================== */

void IREGPP_BSLN_BaselineEval
                        (/*IN    */ UINTx1               mas_imanum,
                         /*IN    */ UINTx1              *sla_imanum,
                         /*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ UINTx4               NRow,
                         /*IN    */ UINTx4               NCol,
                         /*IN    */ INTx4                NImages,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ FILE                *out_fp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_BSLN_BaselineEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx2                 ima;
   INTx2                  sign;
   MATHIT_XYZ             MasSatP;
   MATHIT_XYZ             MasSatV;
   MATHIT_XYZ             SlaSatP;
   MATHIT_XYZ             SlaSatV;
   MATHIT_XYZ             ST;
   MATHIT_XYZ             CP;
   MATHIT_XYZ            *baseline = (MATHIT_XYZ *)NULL;
   MATHIT_RC              MasCentralP;
   MATHIT_RC              SlaCentralP;
   LDEFIT_boolean         first = TRUE;
   double                 central_time;
   double                *base_n = (double *)NULL;
   double                *base_p = (double *)NULL;
   double                 scalar;
   double                 cos_theta;
   double                 theta;
   double                 zero = 1.e-06;
   char                   err_mess[ LDEFID_char_num ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the number of images
   ========================================================================== */
   if ( ( NImages < 2 ) || ( NImages > IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_ima_num_inv, "" );
   }

/* ==========================================================================
   Check the image ID
   ========================================================================== */
   if ( mas_imanum > IREGID_MaxImaNum ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out, "" );
   }
   for ( ima=0; ima<NImages-1; ima++ ) {
      if ( sla_imanum[ ima ] > IREGID_MaxImaNum ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_image_number_out, "" );
      }
   }

/* ==========================================================================
   Check that the warp matrices have been generated
   ========================================================================== */
   if ( IREGPV_warp_matr[ mas_imanum ].wmas2sla == (double **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_warp_not_create, "" );
   }

/* ==========================================================================
   Allocate the baseline array of vectors
   ========================================================================== */
   if ( ( baseline = (MATHIT_XYZ *)MEMSIP_alloc ( (size_t)(NImages *
                                                 sizeof (MATHIT_XYZ)) ) ) ==
        (MATHIT_XYZ *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the baseline vector array" );
   }

   /* parallel baseline array */
   if ( ( base_p = (double *)MEMSIP_alloc ( (size_t)(NImages *
                                            sizeof (double)) ) ) ==
        (double *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the parallel baseline array" );
   }
   memset ( (void *)base_p, '\0', (size_t)(NImages * sizeof (double)) );

   /* normal baseline array */
   if ( ( base_n = (double *)MEMSIP_alloc ( (size_t)(NImages *
                                            sizeof (double)) ) ) ==
        (double *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "for the normal baseline array" );
   }
   memset ( (void *)base_n, '\0', (size_t)(NImages * sizeof (double)) );

/* ==========================================================================
   Evaluate the central coordinates
   ========================================================================== */
   MasCentralP.row = (double)TLRow + (double)(NRow / 2.);
   MasCentralP.col = (double)TLCol + (double)(NCol / 2.);

/* ==========================================================================
   Check if it is possible to evaluate the baseline
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ mas_imanum ].MapProjectionType ==
          IANNIE_proj_UTM ) ||
         ( IANNIV_ImageAnnot[ mas_imanum ].MapProjectionType ==
          IANNIE_proj_UPS ) ) {
      ERRSIM_print_warning (
         "The baseline cannot be evaluated for georeferenced products" );
   }
   else {

/* ==========================================================================
   Evaluate the spacecraft position and velocity at the central point
   ========================================================================== */
      COORIP_CONV_SatPosition ( mas_imanum, MasCentralP.row, &MasSatP, &MasSatV,
                                status_code );
      if ( *status_code != STC ( ERRSID_normal ) ) {
         *status_code = STC ( ERRSID_normal );
         ERRSIM_print_warning ( "The baseline cannot be evaluated" );
      }
      else {

/* ==========================================================================
   Evaluate the cartesian coordinates of the target
   ========================================================================== */
         COORIP_CONV_rc_xyz ( &MasCentralP, (INTx4)mas_imanum, &ST,
                              status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the satellite - target versor
   ========================================================================== */
         MATHIP_STYP_XYZSubt ( ST, MasSatP, &ST, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         MATHIP_STYP_XYZVers ( ST, &ST, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Loop over the slaves
   ========================================================================== */
         for ( ima=1; ima<NImages; ima++ ) {

/* ==========================================================================
   Evaluate the slave point corresponding to the central master
   ========================================================================== */
            IREGPP_WAEV_Mas2Sla ( MasCentralP, degree, (UINTx1)ima,
                                  &SlaCentralP, status_code );
            ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Check if the baseline can be evaluated
   ========================================================================== */
            if ( ( IANNIV_ImageAnnot[ mas_imanum ].MapProjectionType ==
                   IANNIE_proj_UTM ) ||
                 ( IANNIV_ImageAnnot[ mas_imanum ].MapProjectionType ==
                   IANNIE_proj_UPS ) ) {
               ERRSIM_print_warning ( "The baseline cannot be evaluated for \
georeferenced products" );
            }
            else  {

/* ==========================================================================
   Evaluate the coordinates conversions
   ========================================================================== */
               COORIP_CONV_SatPosition ( sla_imanum[ ima - 1 ], SlaCentralP.row,
                                         &SlaSatP, &SlaSatV, status_code );
               if ( *status_code != STC ( ERRSID_normal ) ) {
                  *status_code = STC ( ERRSID_normal );
                  sprintf ( err_mess,
                            "The baseline cannot be evaluated for the slave # \
%0d", ima );
                  ERRSIM_print_warning ( err_mess );
               }
               else {

/* ==========================================================================
   Baseline evaluation
   ========================================================================== */
                  MATHIP_STYP_XYZSubt ( SlaSatP, MasSatP, &baseline[ ima ],
                                        status_code );
                  ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Baseline check
   ========================================================================== */
                  MATHIP_STYP_XYZModu ( baseline[ ima ], &scalar, status_code );
                  ERRSIM_on_err_goto_exit ( *status_code );
                  if ( scalar > zero ) {

/* ==========================================================================
   Evaluate the baseline component parallel to the master satellite - target
   direction
   ========================================================================== */
                     MATHIP_STYP_XYZScalProd ( baseline[ ima ], ST,
                                               &base_p[ ima ], status_code );
                     ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the cross product between the baseline vector and the master
   satellite - target vector
   ========================================================================== */
                     MATHIP_STYP_XYZCrosProd ( ST, baseline[ ima ], &CP,
                                               status_code );
                     ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the cosine of the angle between CP and V
   ========================================================================== */

                     /* CP scal V */
                     MATHIP_STYP_XYZScalProd ( CP, MasSatV, &cos_theta,
                                               status_code );
                     ERRSIM_on_err_goto_exit ( *status_code );

                     /* CP modulus */
                     MATHIP_STYP_XYZModu ( CP, &scalar, status_code );
                     ERRSIM_on_err_goto_exit ( *status_code );

                     /* re-scale the numerator */
                     cos_theta /= scalar;

                     /* V modulus */
                     MATHIP_STYP_XYZModu ( MasSatV, &scalar, status_code );
                     ERRSIM_on_err_goto_exit ( *status_code );

                     /* cos theta */
                     cos_theta /= scalar;

/* ==========================================================================
   Angle between CP and the master velocity
   ========================================================================== */
                     theta = acos ( cos_theta );

/* ==========================================================================
   Evaluate the sign of the normal baseline
   ========================================================================== */
                     sign = ( theta < PI / 2. ) ? -1 : 1;

/* ==========================================================================
   Evaluate the normal baseline
   ========================================================================== */
                     MATHIP_STYP_XYZModu ( baseline[ ima ], &scalar,
                                           status_code );
                     ERRSIM_on_err_goto_exit ( *status_code );

                     base_n[ ima ] = sign *
                        sqrt ( scalar * scalar -
                               base_p[ ima ] * base_p[ ima ] );
                  }
               }
            }

/* ==========================================================================
   Print the baseline in the output file
   ========================================================================== */
            if ( first ) {
               first = FALSE;
            }
            else {
               fprintf ( out_fp, "\n\n\n" );
            }

            fprintf ( out_fp, " ### Slave number %0d", ima );
            fprintf ( out_fp, "\n\n Baseline Cartesian Components in meters:" );
            fprintf ( out_fp, "\n\n        X               Y               Z" );
            fprintf ( out_fp,
                      "\n ----------------------------------------------" );
            fprintf ( out_fp, "\n   %f      %f      %f", baseline[ ima ].x,
                      baseline[ ima ].y, baseline[ ima ].z );
            fprintf ( out_fp,
                      "\n\n Baseline Components in the Sat - Target Plane" );
            fprintf ( out_fp, " in meters:" );
            fprintf ( out_fp, "\n\n           Normal            Parallel" );
            fprintf ( out_fp,
                      "\n ----------------------------------------------" );
            fprintf ( out_fp, "\n         %f         %f", base_n[ ima ],
                      base_p[ ima ] );
         }
      }
   }

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&base_n );
   MEMSIP_free ( (void **)&base_p );
   MEMSIP_free ( (void **)&baseline );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_BSLN_BaselineEval */

#ifdef _EXAM__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGIP_BSLN_

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void IREGIP_BSLN_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGIP_BSLN_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code,
                          &log_status_code );

}/* IREGIP_BSLN_ */
#endif
