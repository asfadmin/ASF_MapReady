/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_STRE

      $FUNCTION          Stretching for quick look extraction

      $ROUTINE           PMDSIP_STRE_TiffFileData
                         PMDSIP_STRE_GeoPresentation

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       17-FEB-98     EL       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */


#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include SRVS_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include IANN_INTF_H
#include CONV_INTF_H
#include PMDS_INTF_H
#include PMDS_PGLB_H

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_STRE_GeoPresentation

        $TYPE

        $INPUT        

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_error_paramaters

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void PMDSIP_STRE_GeoPresentation
                        (/*IN    */ char                *ql_image,
                         /*IN    */ UINTx1               ql_ima_num,
                         /*IN    */ char                *geo_image,
                         /*IN    */ UINTx1               geo_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_STRE_GeoPresentation";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, col, nrow, ncol;
   UINTx1                *inpline = (UINTx1 *) NULL;
   UINTx1                *outline = (UINTx1 *) NULL;
   GIOSIT_io              inp_io, out_io;
   float                  tmpLat, tmpLon;
   
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Open TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, ql_image);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = inp_io.val.tif.bpar.imagelength;
   out_io.val.tif.bpar.imagewidth = inp_io.val.tif.bpar.imagewidth;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.photometricinterpretation = (UINTx2) 1;
   out_io.val.tif.bpar.bitspersample[ 0 ] =
             (UINTx2)(sizeof(UINTx1)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[ 0 ] = TIFSID_uintdata;

/* ==========================================================================
   Open output STANDARD TIFF file
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, geo_image );
   out_io.val.tif.standard = TRUE;
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Change presentation tag
   ========================================================================== */
   IANNIV_ImageAnnot[ geo_ima_num ].Presentation = IANNIE_pres_geo;

/* ==========================================================================
   Change image corner coordinates
   ========================================================================== */
   if( IANNIV_ImageAnnot[ geo_ima_num ].OrbitDirection == 
       IANNIE_orbit_ascend ) {

      tmpLat = IANNIV_ImageAnnot[ geo_ima_num ].TopLeftLat_deg;
      tmpLon = IANNIV_ImageAnnot[ geo_ima_num ].TopLeftLon_deg;

      IANNIV_ImageAnnot[ geo_ima_num ].TopLeftLat_deg = 
	 IANNIV_ImageAnnot[ geo_ima_num ].BottomLeftLat_deg;
      IANNIV_ImageAnnot[ geo_ima_num ].TopLeftLon_deg = 
	 IANNIV_ImageAnnot[ geo_ima_num ].BottomLeftLon_deg;

      IANNIV_ImageAnnot[ geo_ima_num ].BottomLeftLat_deg = tmpLat;
      IANNIV_ImageAnnot[ geo_ima_num ].BottomLeftLon_deg = tmpLon;


      tmpLat = IANNIV_ImageAnnot[ geo_ima_num ].TopRightLat_deg;
      tmpLon = IANNIV_ImageAnnot[ geo_ima_num ].TopRightLon_deg;

      IANNIV_ImageAnnot[ geo_ima_num ].TopRightLat_deg = 
	 IANNIV_ImageAnnot[ geo_ima_num ].BottomRightLat_deg;
      IANNIV_ImageAnnot[ geo_ima_num ].TopRightLon_deg = 
	 IANNIV_ImageAnnot[ geo_ima_num ].BottomRightLon_deg;

      IANNIV_ImageAnnot[ geo_ima_num ].BottomRightLat_deg = tmpLat;
      IANNIV_ImageAnnot[ geo_ima_num ].BottomRightLon_deg = tmpLon;

   }
   else {

      tmpLat = IANNIV_ImageAnnot[ geo_ima_num ].TopLeftLat_deg;
      tmpLon = IANNIV_ImageAnnot[ geo_ima_num ].TopLeftLon_deg;

      IANNIV_ImageAnnot[ geo_ima_num ].TopLeftLat_deg = 
	 IANNIV_ImageAnnot[ geo_ima_num ].TopRightLat_deg;
      IANNIV_ImageAnnot[ geo_ima_num ].TopLeftLon_deg = 
	 IANNIV_ImageAnnot[ geo_ima_num ].TopRightLon_deg;

      IANNIV_ImageAnnot[ geo_ima_num ].TopRightLat_deg = tmpLat;
      IANNIV_ImageAnnot[ geo_ima_num ].TopRightLon_deg = tmpLon;

      tmpLat = IANNIV_ImageAnnot[ geo_ima_num ].BottomLeftLat_deg;
      tmpLon = IANNIV_ImageAnnot[ geo_ima_num ].BottomLeftLon_deg;

      IANNIV_ImageAnnot[ geo_ima_num ].BottomLeftLat_deg = 
	 IANNIV_ImageAnnot[ geo_ima_num ].BottomRightLat_deg;
      IANNIV_ImageAnnot[ geo_ima_num ].BottomLeftLon_deg = 
	 IANNIV_ImageAnnot[ geo_ima_num ].BottomRightLon_deg;

      IANNIV_ImageAnnot[ geo_ima_num ].BottomRightLat_deg = tmpLat;
      IANNIV_ImageAnnot[ geo_ima_num ].BottomRightLon_deg = tmpLon;
   }
  

/* ==========================================================================
   Get the number of image row/col
   ========================================================================== */
   nrow = (UINTx4) inp_io.val.tif.bpar.imagelength;
   ncol = (UINTx4) inp_io.val.tif.bpar.imagewidth;

/* ==========================================================================
   Allocate output line
   ========================================================================== */
   if( (outline = (UINTx1 *) MEMSIP_alloc( (size_t) ncol *
                                                   sizeof(UINTx1) )) ==
       (UINTx1 *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_PMDS_err_mem_alloc, "outline" );
   }

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow, &log_status_code );

/* ==========================================================================
   Change geographic presentation according to ascending or descending orbit
   ========================================================================== */
   if( IANNIV_ImageAnnot[ geo_ima_num ].OrbitDirection == 
       IANNIE_orbit_ascend ) {

/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
      GIOSIP_open_line( &inp_io, 'x', 0, ncol-1, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
      GIOSIP_open_line( &out_io, 'x', 0, ncol-1, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      for( row=0; row<nrow; row++ ) {

         SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the row
   ========================================================================== */
         GIOSIP_read_line( &inp_io, row, 0, (void *) &inpline, status_code );
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Write the row
   ========================================================================== */
         GIOSIP_write_line( &out_io, nrow-row-1, (void *) inpline,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );

      }

   }
   else {
/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
      GIOSIP_open_line( &inp_io, 'x', 0, ncol-1, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
      GIOSIP_open_line( &out_io, 'x', 0, ncol-1, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      for( row=0; row<nrow; row++ ) {

         SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the row
   ========================================================================== */
         GIOSIP_read_line( &inp_io, row, 0, (void *) &inpline, status_code );
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Flip horizontal
   ========================================================================== */
         for( col=0; col<ncol; col++ ) {
            outline[ col ] = inpline[ ncol-col-1 ];
         }

/* ==========================================================================
   Write the row
   ========================================================================== */
         GIOSIP_write_line( &out_io, row, (void *) outline,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );

      }

   }
/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
                            out_io.img,
                            geo_ima_num,
                            status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &outline );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_STRE_TiffFileData

        $TYPE

        $INPUT        input_file_name_p  : input tiff file name
                      output_file_name_p : output tiff file name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_error_paramaters

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void PMDSIP_STRE_TiffFileData
                        (/*IN    */ char                *input_file_name_p,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ float                minPerc,
                         /*IN    */ float                maxPerc,
                         /*IN    */ LDEFIT_boolean       noBlackFound,
                         /*IN    */ float                noBlack,
                         /*IN    */ char                *output_file_name_p,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_STRE_TiffFileData";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   GIOSIT_io              inp_io;
   GIOSIT_io              out_io;
   UINTx4                 nrow_inp;
   UINTx4                 ncol_inp;
   UINTx2                 tag[ 5000 ];  /* array of tags MAXTAGS = 5000 */
   INTx4                  itag;
   TIFSIT_par             param;       /* TIFF parameter structure */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Open TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, input_file_name_p);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = inp_io.val.tif.bpar.imagelength;
   out_io.val.tif.bpar.imagewidth = inp_io.val.tif.bpar.imagewidth;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.photometricinterpretation = (UINTx2) 1;
   out_io.val.tif.bpar.bitspersample[ 0 ] =
             (UINTx2)(sizeof(UINTx1)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[ 0 ] = TIFSID_uintdata;

/* ==========================================================================
   Open output STANDARD TIFF file
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, output_file_name_p );
   out_io.val.tif.standard = TRUE;
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = inp_io.val.tif.npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set all the row/col of the image
   ========================================================================== */
   nrow_inp = (UINTx4) inp_io.val.tif.bpar.imagelength;
   ncol_inp = (UINTx4) inp_io.val.tif.bpar.imagewidth;

/* ==========================================================================
   Get tags from input file
   ========================================================================== */
   TIFSIP_dir_par( inp_io.chan, inp_io.img, tag, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the tags of the input files
   ========================================================================== */
   for(itag = TIFSID_nbpar; itag < inp_io.val.tif.npar; itag++)
   {
      param.tag = tag[itag];
      TIFSIP_get_par(inp_io.chan, inp_io.img, &param, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      TIFSIP_store_par( out_io.chan, out_io.img, &param, status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }


/* ==========================================================================
   Call gain convertion tool
   ========================================================================== */
   CONVIP_gaincvs( &inp_io,
                    inp_ima_num,
                    0,
                    0,
                    nrow_inp,
                    ncol_inp,
                    minPerc,
                    maxPerc,
                    noBlackFound,
                    noBlack,
                   &out_io,
                    out_ima_num,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSIP_STRE_TiffFileData */
