/* ==========================================================================
   $MODULE_HEADER

      $NAME             FIIS_PUTS

      $FUNCTION         Provide a function set uset to put a info on the 
                        specified file.

      $ROUTINES         FIIS_PUTS_ ..

      $HISTORY

              SCR NO.   DATE          INITIALS        DESCRIPTION
   -------------------------------------------------------------------------
              N/A       02/11/92       AC             First Issue

   ========================================================================== */


/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include <math.h>

#include "libname.h"
#include ERRS_INTF_H
#include LDEF_INTF_H
#include FIIS_INTF_H
#include FIIS_PGLB_H

/* ==========================================================================
                        GLOBAL VAR DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

static void trace_in( ERRSIT_flag      process_flag )
{
   ERRSIT_status log_status_code;
   char          tmp_char[256];

   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);


   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);
}

static void trace_out( ERRSIT_flag   process_flag )
{
   ERRSIT_status log_status_code;

   ERRSIP_HPEL_trace_proc_err_log(" ",&log_status_code);
   ERRSIP_HPEL_trace_proc_err_log("NO OUTPUT PARAMETER:", &log_status_code);
}

/* ==========================================================================

   $ROUTINE_HEADER

   $NAME         FIISIP_PUTS_put_info

   $DESCRIPTION  Write the info on the specified file in ascii format.

   $TYPE         Procedure

   $INPUT        

   $MODIFIED     NONE

   $OUTPUT       NONE.

   $GLOBAL       NONE

   $RET_STATUS   NONE

   $WARNING      NONE

   $EH
   ========================================================================== */
   void FIISIP_PUTS_put_info
                   ( /*IN    */ char           *file_name,
                     /*IN    */ char           *section,
                     /*IN    */ char           *tag,
                     /*IN    */ void           *buffer,
                     /*IN    */ FIISIT_tag_type tag_type,
                     /*   OUT*/ ERRSIT_status  *status_code )
{
   const ERRSIT_proc_name  routine_name = "FIISPP_PUTS_put_info";
   ERRSIT_status           log_status_code;

   char                    curr_section[ 128 ]   = "";
   LDEFIT_boolean          founded;

   ERRSIT_flag             process_flag;
   FILE                   *fid = NULL;
   INTx4                   result;
   char                    value[64];   
   
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in( process_flag );
   }

/* ==========================================================================
   Check input paramaters
   ========================================================================== */
   if (( file_name == NULL ) || 
       ( section   == NULL ) ||
       ( tag       == NULL ) ||
       ( buffer    == NULL ))
   {
      ERRSIM_set_error( status_code,
                        ERRSID_FIIS_err_bad_input,
                        ": # 1" );
   }

   FIISPP_GETS_get_last_section(   file_name,
			           curr_section,
				  &founded,
				   status_code );
   if ( *status_code != ERRSID_normal )
   {
      /* error is ignored */
      *status_code = STC( ERRSID_normal );
   }

   FILSIP_open( file_name, "a", 0, &fid, status_code );
   ERRSIM_on_err_goto_exit( *status_code );   

   if ( ( founded == FALSE ) || strcmp( curr_section, section ))
   {
      result = fprintf( fid, "[%s]\n", section );
      if ( result == EOF )
      {
         char    msg[500];
         sprintf( msg, "Can't read %s file : # 3", file_name );

         ERRSIM_set_error( status_code,
                           ERRSID_FIIS_err_read_file,
                           msg );
      }
   }

   switch( tag_type )
   {
      case FIISIE_tt_char :
      {
         result = fprintf( fid, "%s = \'%c\'\n", tag, *((char *)buffer) );
         break;
      }
      case FIISIE_tt_string :
      {
         result = fprintf( fid, "%s = \"%s\"\n", tag, (char *)buffer );
         break;
      }
      case FIISIE_tt_int :
      {
         result = fprintf( fid, "%s = %d\n", tag, *((INTx4 *)buffer) );
         break;
      }
      case FIISIE_tt_long_int :
      {
         result = fprintf( fid, "%s = %ld\n", tag, *((INTx8 *)buffer));
         break;
      }
      case FIISIE_tt_float :
      {
         INTx4 p_int;
         INTx4 p_dec;

         p_int = *((float *)buffer);
         p_dec = (( *((float *)buffer) - (float) p_int) * 100000000.0 );

         result = fprintf( fid, "%s = %d.%d\n", tag, p_int, p_dec );
         break;
      }
      case FIISIE_tt_double :
      {
         INTx4 p_int;
         INTx4 p_dec;
         double double_val;
         
         double_val = *((double *)buffer);
         p_int = (int)double_val;

         p_dec = (int)(( double_val - (double) p_int) * 100000000.0 );

         result = fprintf( fid, "%s = %d.%d\n", tag, p_int, p_dec );
         break;
      }
      default :
      {
         ERRSIM_set_error( status_code,
                           ERRSID_FIIS_err_bad_input,
                           "Invalid tag_type : # 4" );
      }      
   }

   if ( result == EOF )
   {
      char    msg[500];
      sprintf( msg, "Abnormal %s file termination : # 5", file_name );

      ERRSIM_set_error( status_code,
                        ERRSID_FIIS_err_read_file,
                        msg );
   }

   if( ERRSIM_out_parms( process_flag ))
   {
      trace_out( process_flag );
   }

error_exit:;

   if ( fid != NULL )
   {
      fclose( fid );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                           *status_code,
                          &log_status_code );

} /* end routine */
