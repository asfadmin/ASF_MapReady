/* ==========================================================================
   $MODULE_HEADER

      $NAME              STAT_PCAN

      $FUNCTION          This module contains the procedure to execute
			 the PCA analysis of two images

      $ROUTINE           STATIP_PCAN_pca

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       20-AUG-97     AG       Initial Release
          SCR #3      27-NOV-97     AG       Fixed bug on g0 and g1 generation

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */


#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include SRVS_INTF_H
#include IANN_INTF_H
#include STAT_INTF_H
#include STAT_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STATIP_PCAN_pca

        $TYPE         PROCEDURE

	$INPUT	      inp1_io   : structure with the IO basic parameters of 
                                  the first input image
		      inp2_ior  : structure with the TIFF basic parameters of 
                                  the second input image
		      imanums1  : number identifing the first image in the tool
		      imanums2  : number identifing the second image in the tool
                      TLRow     : the row image coordinate in the full 
                                  reference frame of both images
                      TLCol     : the column image coordinate in the full 
                                  reference frame of both images
                      nrow_inp  : number of rows of both images
		      ncol_inp  : number of columns of both images
		      pca1_out_io
				: structure with the IO basic parameters of the
                                  first PCA image
		      pca2_out_io
				: structure with the IO basic parameters of the
                                  second PCA image
		      nrow_out  : number of rows of the output PCA images
		      ncol_out  : number of columns of the output PCA images

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot 
                                : the structure with the image annotations

        $RET_STATUS   ERRSID_STAT_start_stop_coord_err
                      ERRSID_STAT_data_type_not_allow
		      ERRSID_STAT_err_mem_alloc

        $DESCRIPTION  This procedure executes the PRINCIPAL COMPONENT ANALYSIS
		      of the two input images and creates the first and second
		      PCA images

        $WARNING      The input and the output files shall be already opened.

        $PDL	      - Compute E[X^2], E[Y^2], E[X*Y], E[X], E[Y]
		      - Evaluate the covariance matrix (G0,G1)
                      - Find Min((X,Y)*G0) and Min((X,Y)*G1)
		      - Write the PCA images (X,Y)*G0 - Min((X,Y)*G0) and
		        (X,Y)*G1 - Min((X,Y)*G1)

   $EH
   ========================================================================== */
void STATIP_PCAN_pca   
                       ( /*IN    */ GIOSIT_io           *inp1_io,
                         /*IN    */ GIOSIT_io           *inp2_io,
                         /*IN    */ UINTx1               imanums1,
                         /*IN    */ UINTx1               imanums2,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ GIOSIT_io           *pca1_out_io,
                         /*IN    */ GIOSIT_io           *pca2_out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STATIP_PCAN_pca";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 row, col, i;
   MATHIT_array           imgline1, imgline2, prod_outline,
                          sqr_outline1, sqr_outline2, g0, g1, x, min;
   double                 doubleTmp, no_sample, sum1, sum2,
                          sqr_sum1, sqr_sum2, sum12;
   double               **cov = (double **) NULL, *d = (double *) NULL, 
                         *e = (double *) NULL;
   float                 *pca1line = (float *) NULL;
   float                 *pca2line = (float *) NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Array initialization
   ========================================================================== */
   MATHIM_init_array( imgline1 );
   MATHIM_init_array( imgline2 );
   MATHIM_init_array( prod_outline );
   MATHIM_init_array( sqr_outline1 );
   MATHIM_init_array( sqr_outline2 );
   MATHIM_init_array( g0 );
   MATHIM_init_array( g1 );
   MATHIM_init_array( x );
   MATHIM_init_array( min );

/* ==========================================================================
   Check the first image number
   ========================================================================== */
   if ( imanums1 >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_STAT_imanum_not_allow, "imanums1");
   }

/* ==========================================================================
   Check the second image number
   ========================================================================== */
   if ( imanums2 >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_STAT_imanum_not_allow, "imanums2");
   }

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow_inp > IANNIV_ImageAnnot[ imanums1 ].ImageLength ) ||
        ( TLCol + ncol_inp > IANNIV_ImageAnnot[ imanums1 ].ImageWidth ) ||
	( TLRow + nrow_inp > IANNIV_ImageAnnot[ imanums2 ].ImageLength ) ||
	( TLCol + ncol_inp > IANNIV_ImageAnnot[ imanums2 ].ImageWidth ) ) {
      ERRSIM_set_error( status_code, ERRSID_STAT_start_stop_coord_err, "" );
   }

/* ==========================================================================
   Set array imgline1 and imgline2 nelem
   ========================================================================== */
   imgline1.nelem = ncol_inp;
   imgline2.nelem = ncol_inp;

/* ==========================================================================
   Set array imgline1 and imgline2 type
   ========================================================================== */
   switch ( inp1_io->spp ) {
      case 1:
/* ==========================================================================
   Real data
   ========================================================================== */
	 switch( inp1_io->bps ) {
	    case 8:
               imgline1.atype = MATHIE_uchar;
	       break;
	    case 16:
               imgline1.atype = MATHIE_uintx2;
	       break;
	    case 32: 
               imgline1.atype = MATHIE_float;
	       break;
	    default:
	       ERRSIM_set_error(status_code, ERRSID_STAT_data_type_not_allow,
		  "");
	 }
	 break;
      default:
	 ERRSIM_set_error(status_code, ERRSID_STAT_data_type_not_allow,
	    "");
   }
   switch ( inp2_io->spp ) {
      case 1:
/* ==========================================================================
   Real data
   ========================================================================== */
	 switch( inp2_io->bps ) {
	    case 8:
               imgline2.atype = MATHIE_uchar;
	       break;
	    case 16:
               imgline2.atype = MATHIE_uintx2;
	       break;
	    case 32: 
               imgline2.atype = MATHIE_float;
	       break;
	    default:
	       ERRSIM_set_error(status_code, ERRSID_STAT_data_type_not_allow,
		  "");
	 }
	 break;
      default:
	 ERRSIM_set_error(status_code, ERRSID_STAT_data_type_not_allow,
	    "");
   }

/* ==========================================================================
   Make the other arrays
   ========================================================================== */
   MATHIP_VECT_Make( ncol_inp, MATHIE_float, 
		    &prod_outline, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   MATHIP_VECT_Make( ncol_inp, MATHIE_float, 
		    &sqr_outline1, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   MATHIP_VECT_Make( ncol_inp, MATHIE_float, 
		    &sqr_outline2, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Zero stores
   ========================================================================== */
   no_sample = 0.0;
   sum1 = 0.0;
   sum2 = 0.0;
   sqr_sum1 = 0.0;
   sqr_sum2 = 0.0;
   sum12 = 0.0;

/* ==========================================================================
   Open the read mode for the two input files
   ========================================================================== */
   GIOSIP_open_line( inp1_io, 'x', TLCol, TLCol + ncol_inp - 1,
                     status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   GIOSIP_open_line( inp2_io, 'x', TLCol, TLCol + ncol_inp - 1, 
                     status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) 3*nrow_inp, &log_status_code );

/* ==========================================================================
   Read the two images by rows
   ========================================================================== */
   for( row=TLRow; row<TLRow+nrow_inp; row++ ) {

      SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Set the outlines to zero
   ========================================================================== */
      MATHIP_VECT_SetZero( &prod_outline, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      MATHIP_VECT_SetZero( &sqr_outline1, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      MATHIP_VECT_SetZero( &sqr_outline2, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
    Count the sample of this line
   ========================================================================== */
      no_sample += (double) ncol_inp;

/* ==========================================================================
   Read the rows
   ========================================================================== */
      GIOSIP_read_line( inp1_io, row, 0, &(imgline1.ap), status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      GIOSIP_read_line( inp2_io, row, 0, &(imgline2.ap), status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute statistical values
   ========================================================================== */
      MATHIP_VECT_Total( imgline1, &doubleTmp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      sum1 += doubleTmp;

      MATHIP_VECT_Total( imgline2, &doubleTmp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      sum2 += doubleTmp;

      MATHIP_VECT_HeterProd( imgline1, imgline2, &prod_outline, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      MATHIP_VECT_Total( prod_outline, &doubleTmp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      sum12 += doubleTmp;

      MATHIP_VECT_Pow( imgline1, (double) 2.0, &sqr_outline1, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      MATHIP_VECT_Total( sqr_outline1, &doubleTmp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      sqr_sum1 += doubleTmp;
      MATHIP_VECT_Pow( imgline2, (double) 2.0, &sqr_outline2, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      MATHIP_VECT_Total( sqr_outline2, &doubleTmp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      sqr_sum2 += doubleTmp;

   }

/* ==========================================================================
   Close the read mode of the input images
   ========================================================================== */
   GIOSIP_close_line( inp1_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );   
   GIOSIP_close_line( inp2_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );   

#ifdef __TRACE__
   printf("\nsum1=%f\nsum2=%f\nsum12=%f\nsqr_sum1=%f\nsqr_sum2=%f\n", 
                sum1, sum2, sum12, sqr_sum1, sqr_sum2 );
   printf("COV(X,X)=%f\nCOV(X,Y)=%f\nCOV(Y,Y)=%f\n",
           sqr_sum1/no_sample - POW((sum1/no_sample),2.0),
           sum12/no_sample - ((sum1/no_sample)*(sum2/no_sample)),
           sqr_sum2/no_sample - POW((sum2/no_sample),2.0) );
#endif

/* ==========================================================================
   Prepare to covariance matrix evaluation
   ========================================================================== */
   cov = (double **) MEMSIP_alloc((size_t) (2*sizeof(double *)));
   if( cov == (double **) NULL ) {
      ERRSIM_set_error(status_code, ERRSID_STAT_err_mem_alloc, "cov");
   }
   for( i=0; i<2; i++) {
      cov[ i ] = (double *) MEMSIP_alloc((size_t) (2*sizeof(double)));
      if( cov[ i ] == (double *) NULL ) {
         ERRSIM_set_error(status_code, ERRSID_STAT_err_mem_alloc, "cov[i]");
      }
   }

   /* eigen values array */
   d = (double *) MEMSIP_alloc((size_t) (2*sizeof(double)));
   if( d == (double *) NULL ) {
      ERRSIM_set_error(status_code, ERRSID_STAT_err_mem_alloc, "d");
   }

   /* sub diagonal elements array */
   e = (double *) MEMSIP_alloc((size_t) (2*sizeof(double)));
   if( e == (double *) NULL ) {
      ERRSIM_set_error(status_code, ERRSID_STAT_err_mem_alloc, "e");
   }

/* ==========================================================================
   Evaluate the covariance matrix
   ========================================================================== */
   cov[ 0 ][ 0 ] =
           sqr_sum1/no_sample - POW((sum1/no_sample),2.0);
   cov[ 0 ][ 1 ] = cov[ 1 ][ 0 ] = 
           sum12/no_sample - ((sum1/no_sample)*(sum2/no_sample));
   cov[ 1 ][ 1 ] =    
           sqr_sum2/no_sample - POW((sum2/no_sample),2.0);

/* ==========================================================================
   Householder matrix transformation of the covariance matrix
   ========================================================================== */
   MATHIP_EIGV_tred( 2,
                     cov,
                     d,
                     e,
                     status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Diagonalize the covariance matrix
   ========================================================================== */
   MATHIP_EIGV_tqli( 2,
		     d,
                     e,
                     cov,
                     status_code );
   ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
   printf("G(X,X)=%f\nG(X,Y)=%f\nG(Y,X)=%f\nG(Y,Y)=%f\n", 
           cov[0][0], cov[1][0], cov[0][1], cov[1][1] );
#endif
/* ==========================================================================
   Make array for PCA computation
   ========================================================================== */
   MATHIP_VECT_Make( 2, MATHIE_float,
		    &g0, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   MATHIP_VECT_Make( 2, MATHIE_float,
		    &g1, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   MATHIP_VECT_Make( 2, MATHIE_float,
		    &x, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   MATHIP_VECT_Make( 2, MATHIE_float,
		    &min, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   The columns of the diagonalized covariance matrix are the system
   eigenvectors. These matrix is the rotation matrix of the final
   transformation.
   ========================================================================== */
   ((float *)(g0.ap))[0] = (float)cov[0][0];
   ((float *)(g0.ap))[1] = (float)cov[0][1];
   ((float *)(g1.ap))[0] = (float)cov[1][0];
   ((float *)(g1.ap))[1] = (float)cov[1][1];

/* ==========================================================================
   Find minumum on PCA images
   ========================================================================== */
   ((float *) min.ap)[ 0 ] = 999999999.999999999;
   ((float *) min.ap)[ 1 ] = 999999999.999999999;

/* ==========================================================================
   Open the read mode for the two input files
   ========================================================================== */
   GIOSIP_open_line( inp1_io, 'x', TLCol, TLCol + ncol_inp - 1,
                     status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   GIOSIP_open_line( inp2_io, 'x', TLCol, TLCol + ncol_inp - 1,
                     status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read the two images by rows (switch are useful in order to avoid checks
   on each row)
   ========================================================================== */
   switch( imgline1.atype ) {
      case MATHIE_uchar:
	 switch( imgline2.atype ) {
	    case MATHIE_uchar:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx1 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx1 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
                     printf("\n%f\t", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 0 ] ){
			((float *) min.ap)[ 0 ] = (float) doubleTmp;
		     }
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
		     printf("%f", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 1 ] ){
			((float *) min.ap)[ 1 ] = (float) doubleTmp;
		     }
		  }
	       }
	       break;
	    case MATHIE_uintx2:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx1 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx2 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
                     printf("\n%f\t", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 0 ] ){
			((float *) min.ap)[ 0 ] = (float) doubleTmp;
		     }
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
		     printf("%f", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 1 ] ){
			((float *) min.ap)[ 1 ] = (float) doubleTmp;
		     }
		  }
	       }
	       break;
	    case MATHIE_float:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx1 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((float *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
                     printf("\n%f\t", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 0 ] ){
			((float *) min.ap)[ 0 ] = (float) doubleTmp;
		     }
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
		     printf("%f", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 1 ] ){
			((float *) min.ap)[ 1 ] = (float) doubleTmp;
		     }
		  }
	       }
	       break;
	 }
	 break;
      case MATHIE_uintx2:
	 switch( imgline2.atype ) {
	    case MATHIE_uchar:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx2 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx1 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
                     printf("\n%f\t", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 0 ] ){
			((float *) min.ap)[ 0 ] = (float) doubleTmp;
		     }
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
		     printf("%f", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 1 ] ){
			((float *) min.ap)[ 1 ] = (float) doubleTmp;
		     }
		  }
	       }
	       break;
	    case MATHIE_uintx2:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx2 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx2 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
                     printf("\n%f\t", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 0 ] ){
			((float *) min.ap)[ 0 ] = (float) doubleTmp;
		     }
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
		     printf("%f", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 1 ] ){
			((float *) min.ap)[ 1 ] = (float) doubleTmp;
		     }
		  }
	       }
	       break;
	    case MATHIE_float:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx2 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((float *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
                     printf("\n%f\t", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 0 ] ){
			((float *) min.ap)[ 0 ] = (float) doubleTmp;
		     }
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
		     printf("%f", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 1 ] ){
			((float *) min.ap)[ 1 ] = (float) doubleTmp;
		     }
		  }
	       }
	       break;
	 }
	 break;
      case MATHIE_float:
	 switch( imgline2.atype ) {
	    case MATHIE_uchar:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((float *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx1 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
                     printf("\n%f\t", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 0 ] ){
			((float *) min.ap)[ 0 ] = (float) doubleTmp;
		     }
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
		     printf("%f", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 1 ] ){
			((float *) min.ap)[ 1 ] = (float) doubleTmp;
		     }
		  }
	       }
	       break;
	    case MATHIE_uintx2:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((float *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx2 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
                     printf("\n%f\t", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 0 ] ){
			((float *) min.ap)[ 0 ] = (float) doubleTmp;
		     }
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
		     printf("%f", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 1 ] ){
			((float *) min.ap)[ 1 ] = (float) doubleTmp;
		     }
		  }
	       }
	       break;
	    case MATHIE_float:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((float *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((float *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
                     printf("\n%f\t", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 0 ] ){
			((float *) min.ap)[ 0 ] = (float) doubleTmp;
		     }
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
#ifdef __TRACE__
		     printf("%f", doubleTmp);
#endif
		     if( ((float) doubleTmp) < ((float *) min.ap)[ 1 ] ){
			((float *) min.ap)[ 1 ] = (float) doubleTmp;
		     }
		  }
	       }
	       break;
	 }
	 break;
   }

/* ==========================================================================
   Close the read mode of the input images
   ========================================================================== */
   GIOSIP_close_line( inp1_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );   
   GIOSIP_close_line( inp2_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );   

#ifdef __TRACE__
   printf("\nmin0=%f\tmin1=%f\n", ((float *) min.ap)[ 0 ], 
                                  ((float *) min.ap)[ 1 ] );
#endif

/* ==========================================================================
   Allocate output PCA image vectors
   ========================================================================== */
   pca1line = (float *) MEMSIP_alloc((size_t) (ncol_out*sizeof(float)));
   if( pca1line == (float *) NULL ) {
      ERRSIM_set_error(status_code, ERRSID_STAT_err_mem_alloc, "pca1line");
   }
   pca2line = (float *) MEMSIP_alloc((size_t) (ncol_out*sizeof(float)));
   if( pca2line == (float *) NULL ) {
      ERRSIM_set_error(status_code, ERRSID_STAT_err_mem_alloc, "pca2line");
   }

/* ==========================================================================
   Open the read mode for the two input files
   ========================================================================== */
   GIOSIP_open_line( inp1_io, 'x', TLCol, TLCol + ncol_inp - 1,
                     status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   GIOSIP_open_line( inp2_io, 'x', TLCol, TLCol + ncol_inp - 1,
                     status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the write mode of the output files in the row direction
   ========================================================================== */
   GIOSIP_open_line( pca1_out_io, 'x', 0, ncol_out-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   GIOSIP_open_line( pca2_out_io, 'x', 0, ncol_out-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read the two images by rows (switch are useful in order to avoid checks
   on each row)
   ========================================================================== */
   switch( imgline1.atype ) {
      case MATHIE_uchar:
	 switch( imgline2.atype ) {
	    case MATHIE_uchar:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx1 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx1 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca1line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 0 ];
#ifdef __TRACE__
                     printf("\n%f", pca1line[ col ]);
#endif
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca2line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 1 ];
#ifdef __TRACE__
                     printf("\t%f", pca2line[ col ]);
#endif
		  }
                  GIOSIP_write_line( pca1_out_io, (row - TLRow), 
                                     (void *) pca1line, status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
                  GIOSIP_write_line( pca2_out_io, (row - TLRow),
                                     (void *) pca2line, status_code );
                  ERRSIM_on_err_goto_exit( *status_code );
	       }
	       break;
	    case MATHIE_uintx2:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx1 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx2 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca1line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 0 ];
#ifdef __TRACE__
                     printf("\n%f", pca1line[ col ]);
#endif
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
		     pca2line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 1 ];
#ifdef __TRACE__
                     printf("\t%f", pca2line[ col ]);
#endif
		  }
                  GIOSIP_write_line( pca1_out_io, (row - TLRow), 
                                     (void *) pca1line, status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
                  GIOSIP_write_line( pca2_out_io, (row - TLRow),
                                     (void *) pca2line, status_code );
                  ERRSIM_on_err_goto_exit( *status_code );
	       }
	       break;
	    case MATHIE_float:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx1 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((float *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca1line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 0 ];
#ifdef __TRACE__
                     printf("\n%f", pca1line[ col ]);
#endif
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca2line[ col ] =
                          (float) doubleTmp - ((float *) min.ap)[ 1 ];
#ifdef __TRACE__
                     printf("\t%f", pca2line[ col ]);
#endif
		  }
                  GIOSIP_write_line( pca1_out_io, (row - TLRow), 
                                     (void *) pca1line, status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
                  GIOSIP_write_line( pca2_out_io, (row - TLRow),
                                     (void *) pca2line, status_code );
                  ERRSIM_on_err_goto_exit( *status_code );
	       }
	       break;
	 }
	 break;
      case MATHIE_uintx2:
	 switch( imgline2.atype ) {
	    case MATHIE_uchar:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx2 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx1 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca1line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 0 ];
#ifdef __TRACE__
                     printf("\n%f", pca1line[ col ]);
#endif
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca2line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 1 ];
#ifdef __TRACE__
                     printf("\t%f", pca2line[ col ]);
#endif
		  }
                  GIOSIP_write_line( pca1_out_io, (row - TLRow), 
                                     (void *) pca1line, status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
                  GIOSIP_write_line( pca2_out_io, (row - TLRow),
                                     (void *) pca2line, status_code );
                  ERRSIM_on_err_goto_exit( *status_code );
	       }
	       break;
	    case MATHIE_uintx2:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx2 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx2 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca1line[ col ] =
                          (float) doubleTmp - ((float *) min.ap)[ 0 ];
#ifdef __TRACE__
                     printf("\n%f", pca1line[ col ]);
#endif
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca2line[ col ] =
                          (float) doubleTmp - ((float *) min.ap)[ 1 ];
#ifdef __TRACE__
                     printf("\t%f", pca2line[ col ]);
#endif
		  }
                  GIOSIP_write_line( pca1_out_io, (row - TLRow), 
                                     (void *) pca1line, status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
                  GIOSIP_write_line( pca2_out_io, (row - TLRow),
                                     (void *) pca2line, status_code );
                  ERRSIM_on_err_goto_exit( *status_code );
	       }
	       break;
	    case MATHIE_float:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((UINTx2 *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((float *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca1line[ col ] =
                          (float) doubleTmp - ((float *) min.ap)[ 0 ];
#ifdef __TRACE__
                     printf("\n%f", pca1line[ col ]);
#endif
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca2line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 1 ];
#ifdef __TRACE__
                     printf("\t%f", pca2line[ col ]);
#endif
		  }
                  GIOSIP_write_line( pca1_out_io, (row - TLRow), 
                                     (void *) pca1line, status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
                  GIOSIP_write_line( pca2_out_io, (row - TLRow),
                                     (void *) pca2line, status_code );
                  ERRSIM_on_err_goto_exit( *status_code );
	       }
	       break;
	 }
	 break;
      case MATHIE_float:
	 switch( imgline2.atype ) {
	    case MATHIE_uchar:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((float *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx1 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca1line[ col ] =
                          (float) doubleTmp - ((float *) min.ap)[ 0 ];
#ifdef __TRACE__
                     printf("\n%f", pca1line[ col ]);
#endif
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca2line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 1 ];
#ifdef __TRACE__
                     printf("\t%f", pca2line[ col ]);
#endif
		  }
                  GIOSIP_write_line( pca1_out_io, (row - TLRow), 
                                     (void *) pca1line, status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
                  GIOSIP_write_line( pca2_out_io, (row - TLRow),
                                     (void *) pca2line, status_code );
                  ERRSIM_on_err_goto_exit( *status_code );
	       }
	       break;
	    case MATHIE_uintx2:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((float *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((UINTx2 *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca1line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 0 ];
#ifdef __TRACE__
                     printf("\n%f", pca1line[ col ]);
#endif
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca2line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 1 ];
#ifdef __TRACE__
                     printf("\t%f", pca2line[ col ]);
#endif
		  }
                  GIOSIP_write_line( pca1_out_io, (row - TLRow), 
                                     (void *) pca1line, status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
                  GIOSIP_write_line( pca2_out_io, (row - TLRow),
                                     (void *) pca2line, status_code );
                  ERRSIM_on_err_goto_exit( *status_code );
	       }
	       break;
	    case MATHIE_float:
	       for( row=TLRow; row<TLRow+nrow_inp; row++ ) {
		  SRVSIP_trace_comp( &log_status_code );
/* ==========================================================================
   Read the rows
   ========================================================================== */
		  GIOSIP_read_line(  inp1_io, row, 0, 
                                    &(imgline1.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
		  GIOSIP_read_line(  inp2_io, row, 0,
                                    &(imgline2.ap), status_code );
		  ERRSIM_on_err_goto_exit( *status_code );

		  for( col=0; col<ncol_inp; col++ ) {
		     ((float *)(x.ap))[0] = ((float *) imgline1.ap)[ col ];
		     ((float *)(x.ap))[1] = ((float *) imgline2.ap)[ col ];

		     MATHIP_VECT_HeterInnerProd(  g0, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca1line[ col ] =
                          (float) doubleTmp - ((float *) min.ap)[ 0 ];
#ifdef __TRACE__
                     printf("\n%f", pca1line[ col ]);
#endif
		     MATHIP_VECT_HeterInnerProd(  g1, x, 
                                                 &doubleTmp, status_code );
		     ERRSIM_on_err_goto_exit( *status_code );
                     pca2line[ col ] = 
                          (float) doubleTmp - ((float *) min.ap)[ 1 ];
#ifdef __TRACE__
                     printf("\t%f", pca2line[ col ]);
#endif
		  }
                  GIOSIP_write_line( pca1_out_io, (row - TLRow), 
                                     (void *) pca1line, status_code );
		  ERRSIM_on_err_goto_exit( *status_code );
                  GIOSIP_write_line( pca2_out_io, (row - TLRow),
                                     (void *) pca2line, status_code );
                  ERRSIM_on_err_goto_exit( *status_code );
	       }
	       break;
	 }
	 break;
   }

/* ==========================================================================
   Close the read mode of the input images
   ========================================================================== */
   GIOSIP_close_line( inp1_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );   
   GIOSIP_close_line( inp2_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );   

/* ==========================================================================
   Close the write mode of the output images
   ========================================================================== */
   GIOSIP_close_line( pca1_out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   GIOSIP_close_line( pca2_out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   
error_exit:;

/* ==========================================================================
   Freeze memory
   ========================================================================== */
   MATHIP_VECT_Free( &prod_outline, &log_status_code );
   MATHIP_VECT_Free( &sqr_outline1, &log_status_code );
   MATHIP_VECT_Free( &sqr_outline2, &log_status_code );
   MATHIP_VECT_Free( &g0, &log_status_code );
   MATHIP_VECT_Free( &g1, &log_status_code );
   MATHIP_VECT_Free( &x, &log_status_code );
   MATHIP_VECT_Free( &min, &log_status_code );
   MEMSIP_free( (void **) &d);
   MEMSIP_free( (void **) &e);
   if( cov != (double **) NULL ) {
      for( i=0; i<2; i++) {
         MEMSIP_free( (void **) &(cov[i]) );
      }
      MEMSIP_free( (void **) &cov );
   }
   MEMSIP_free( (void **) &pca1line);
   MEMSIP_free( (void **) &pca2line);

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STATIP_PCAN_pca */
