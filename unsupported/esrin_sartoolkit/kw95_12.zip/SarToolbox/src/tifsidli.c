#ifdef __HAVEIDL__
/* ==========================================================================
   $MODULE_HEADER

      $NAME              TIFS_IDLI

      $FUNCTION          TIFF IDL Interface (exported) 

      $ROUTINE           TIFS_IDLI

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       03-SEP-97     EL       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#if defined(__WIN95__) && defined(__CODEWARRIOR__)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include IDLI_INTF_H
#include TIFS_INTF_H
#include TIFS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_geterrorcode

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure is maintained just for compatibility but does nothing.
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is the error code
		    1 *           STRING          error message

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_geterrorcode
                        (/*IN    */ INTx4                npar,
                         /*INOUT*/  IDL_VPTR             par[]) 
{

  /* Reset the status */ 
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=2) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  if( TIFSPV_ErrData.code == 0 ) {
    return;
  }

  strcpy( TIFSPV_ErrData.string, 
          TIFSIV_ERRS_error_message[ TIFSPV_ErrData.code ] );

  /* copy the error message string reallocating the memory space */
  if((par[1]->value).str.s==NULL)
    (par[1]->value).str.s=
       realloc((par[1]->value).str.s,
                strlen(TIFSPV_ErrData.string)+1);

  sprintf((par[1]->value).str.s,"%s",TIFSPV_ErrData.string);
  (par[1]->value).str.stype=0;  /* declare as static avoiding IDL free problems*/
  (par[1]->value).str.slen=strlen(TIFSPV_ErrData.string);

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_opentiff

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and open_tiff.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             STRING          name of the file to be opened
		    2             STRING          a character indicating the open in read mode
                                                  'r' or write 'w' or update 'u'
		    3 *           LONG INT        the channel of the opened file

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_opentiff
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  ERRSIT_status    status_code;
  
  status_code      = STC( ERRSID_normal );

  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=4) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  TIFSIP_open_tiff((par[1]->value).str.s,
			*((par[2]->value).str.s),
			(INTx4 *)(&((par[3]->value).l)),&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }

}


/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_initfiledata

      $TYPE         PROCEDURE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and init_filedata.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    - none -

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_initfiledata
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  TIFSIP_init_filedata(&status_code);

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_closetiff

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and close_tiff.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file to be close
 
      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_closetiff
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=2) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  TIFSIP_close_tiff((par[1]->value).l,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_gettag

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and GetTag.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             LONG INT        the tag number
		    4 *           unspecified     the value in a allowed IDL type
 
      $WARNING      NONE

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_gettag
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{


  TIFSIT_par       btiffpar;
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=5) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  btiffpar.tag=(par[3]->value).l;

  TIFSIP_get_par((par[1]->value).l,(par[2]->value).l,&btiffpar,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
  }

  if(((par[0]->value).l)!=0) {
    TIFSPV_ErrData.code = 6;
    return;
  }

  /*in BTIFF_LIBRTL was: if(TIFSPF_IDLI_CvtBTIFFtoIDL(btiffpar,par[4])) { */
  if(TIFSPF_IDLI_CvtBTIFFtoIDL(btiffpar,&par[4])) {
    (par[0]->value).l=1;
  }

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_getparnum

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and GetParNum.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3 *           LONG INT        the number of parameters

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_getparnum
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  UINTx2 dummy;
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=4) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  TIFSIP_get_parnum((par[1]->value).l,(par[2]->value).l,&dummy,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
  }

  (par[3]->value).l=(INTx4)dummy;

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_dirpar

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and dir_par.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3 *           LONG INT array  the array of tags present in the file
				  of the same size
				  of the number
				  of par as given
				  from par_num
 
      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_dirpar
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  INTx4 i;
  UINTx2 *temp;
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=4) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  /* check that a LONG ARRAY is passed into */
  if(!((par[3]->flags)&IDL_V_ARR)) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 24;
    return;
  }
  if((par[3]->type)!=IDL_TYP_LONG) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 24;
    return;
  }


  /* check that has enough room */
  if((((par[3]->value).arr)->n_elts)<TIFSPV_gid[(par[1]->value).l].npar[(par[2]->value).l]) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 24;
    return;
  }


  temp=(UINTx2 *)malloc(sizeof(INTx2)*TIFSPV_gid[(par[1]->value).l].npar[(par[2]->value).l]);

  if(temp==NULL) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 24;
    return;
  }

  TIFSIP_dir_par((par[1]->value).l,(par[2]->value).l,temp,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
  }

  if((par[0]->value).l) {
    free(temp);
    return;
  }

  for(i=0;i<TIFSPV_gid[(par[1]->value).l].npar[(par[2]->value).l];i++) 
    *( (INTx4 *)(((par[3]->value).arr)->data) + i )=(INTx4)(*(temp + i));


  free(temp);

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_getimgnum

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and GetImgNum.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2 *           LONG INT        the image number

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_getimgnum
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=3) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  TIFSIP_get_imgnum((par[1]->value).l,(INTx4 *)(&((par[2]->value).l)),&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
  }

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_getblockinfo

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and Get_BlockInfo.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3 *           LONG INT        the compression
		    4 *           LONG INT        the imagewidth
		    5 *           LONG INT        the imagelenght
		    6 *           LONG INT        the rowsperblock
		    7 *           LONG INT        the columnsperblock
		    8 *           LONG INT        the bitspersample (SCALAR)
		    9 *           LONG INT        the sampleperpixel
		    10 *          LONG INT        the photometricinterpretation
		    11 *          STRING          the disposition

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_getblockinfo
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  TIFSIT_basicpar dummy;
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=13) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  TIFSIP_get_blockinfo((par[1]->value).l,(par[2]->value).l,&dummy,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }

  /* Waiting the IDL struct interface; for now, copy the structure fields into 
     the parameters */
  
  (par[3]->value).l=dummy.compression;
  (par[4]->value).l=dummy.imagewidth;
  (par[5]->value).l=dummy.imagelength;
  (par[6]->value).l=dummy.rowsperblock;
  (par[7]->value).l=dummy.columnsperblock;
  (par[8]->value).l=dummy.bitspersample[0]; /* is used only the first value, as done in all the BITIF lib (future expansion) */
  (par[9]->value).l=dummy.sampleperpixel;
  (par[10]->value).l=dummy.photometricinterpretation;
  (par[12]->value).l=dummy.sampleformat[0]; /* is used only the first value, as done in all the BITIF lib (future expansion) */


  /* copy the disposition as a 1 char string and the terminator reallocating 
     2 byte memory space */
  if((par[11]->value).str.s==NULL)
    (par[11]->value).str.s=realloc((par[11]->value).str.s,2);

  *((par[11]->value).str.s)=dummy.disposition;
  *((par[11]->value).str.s+1)=0;
  (par[11]->value).str.stype=0;  /* declare as static avoiding IDL free problems*/
  (par[11]->value).str.slen=1;
  
}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_readsubimage

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and the following BTIFF routines
		    open_line, readline, close_line
		    This routine does not exist into the original BTIFF package and is build
		    just for IDL. With this routine a image portion can be read
		    into a array ** allocated from IDL **
		    A copy line by line is made from the image buffer into the IDL array using
		    the pointer restituited from BTIFF readline routine
		    The IDL array type IS NOT checked. 
		    The IDL array size IS checked.
		    A byte per byte copy of the BTIFF image buffer is then done.
		    The reading direction is always fixed to be X
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             LONG INT        Start X coord
		    4             LONG INT        Start Y coord
		    5             LONG INT        End   X coord
		    6             LONG INT        End   Y coord
		    7 *           unspecified arr the IDL array that will contain the image porti
 
      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_readsubimage
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  UINTx4 y;
  INTx4 sx;
  INTx4 sy;
  INTx4 ex;
  INTx4 ey;
  INTx4 chan;
  INTx4 img;
  INTx4 wid;
  INTx4 len;
  INTx4 read_ok=0;
  register UINTx4 xsize;
  UINTx4 sizeb;
  void *source;
  register INTx1 *dest;
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  
  /* check sul numero di parametri */
  if(npar!=8) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  chan=(par[1]->value).l;
  img=(par[2]->value).l;
  sx=(par[3]->value).l;
  sy=(par[4]->value).l;
  ex=(par[5]->value).l;
  ey=(par[6]->value).l;

  wid=TIFSPV_gid[chan].imgcol[img];
  len=TIFSPV_gid[chan].imgrig[img];

  if( (sx<0) || (sy<0) || (ex<0) || (ey<0) ||	/* check for coord less than 0 */
      (sx>=wid) || (ex>=wid) || (sy>=len) || (ey>=len) ||	/* check for coord greater than image 0 */
      (sx>ex) || (sy>ey)	/* check for coords inconstency */
    ) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 25;
    return;
  }


  sizeb=(ey-sy+1)*(ex-sx+1)*TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;

  /* sanity checks on IDL array */
  if(
     (!((par[7]->flags)&IDL_V_ARR) ) || 	/* check that is an array */
     ( ((par[7]->value).arr)->arr_len != sizeb ) || /* and has enought rooms */
     ( ((par[7]->value).arr)->data == NULL ) 	/* check that is allocated */
    ) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 26;
    return;
  }
  
  dest=(INTx1 *)((par[7]->value).arr)->data;

  /* lenght of the line to be read in bytes */
  xsize=(ex-sx+1)*TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;

  TIFSIP_open_line(chan,img,'x',sx,ex,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }

  for(y=sy;y<=ey;y++) {

    TIFSIP_read_line(chan,img,y,&source,&status_code); /* accumulate the errors avoiding that a no error condition overwrites an error */

    if(status_code != STC( ERRSID_normal))  {
      read_ok ++;
    }

    memcpy(dest,source,xsize);
    dest += xsize;
  }

  TIFSIP_close_line(chan,img,&status_code);
  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }
  
  if(read_ok) {
    (par[0]->value).l=1;
    return;
  }

  (par[0]->value).l=read_ok;

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_openline

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and OpenLine.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             STRING          the direction of the reading (x or y)
		    5             LONG INT        Start sample coord
		    6             LONG INT        End sample coord
 
      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_openline
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  INTx4 samplestart;
  INTx4 sampleend;
  INTx4 chan;
  INTx4 img;
  INTx1 direction;
  INTx4 wid;
  INTx4 len;
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );
  
  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=6) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  chan=(par[1]->value).l;
  img=(par[2]->value).l;
  direction= *((par[3]->value).str.s);
  samplestart=(par[4]->value).l;
  sampleend=(par[5]->value).l;

  wid=TIFSPV_gid[chan].imgcol[img];
  len=TIFSPV_gid[chan].imgrig[img];

  if(tolower(direction)=='x') {
    if( (samplestart<0) || (sampleend<0) ||		/* check for coord less than 0 */
        (samplestart>=wid) || (sampleend>=wid) ||	/* check for coord greater than image 0 */
        (samplestart>sampleend)				/* check for coords inconstency */
      ) {
      (par[0]->value).l=1;
      TIFSPV_ErrData.code = 25;
      return;
    }
  }
  else if(tolower(direction)=='y') {
    if( (samplestart<0) || (sampleend<0) ||		/* check for coord less than 0 */
        (samplestart>=len) || (sampleend>=len) ||	/* check for coord greater than image 0 */
        (samplestart>sampleend)				/* check for coords inconstency */
      ) {
      (par[0]->value).l=1;
      TIFSPV_ErrData.code = 25;
      return;
    }
  }
  else {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 25;
    return;
  }

  TIFSIP_open_line(chan,img,direction,samplestart,sampleend,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }


}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_readline

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and read_line.
		    The IDL array type IS NOT checked.
		    The IDL array size IS checked.
 		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             LONG INT        the line number of the line to be read
		    4 *           unspecified arr the IDL array that will contain the image porti

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_readline
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[])
{

  INTx4 chan;
  INTx4 img;
  UINTx4 line;
  void *source;
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );
  
  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=5) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  chan=(par[1]->value).l;
  img=(par[2]->value).l;
  line=(par[3]->value).l;

  /* sanity checks on IDL array */
  if(
     (!((par[4]->flags)&IDL_V_ARR) ) || 	/* check that is an array */
     ( ((par[4]->value).arr)->arr_len != TIFSPV_gid[chan].linesize[img]) || /* and has enought rooms */
     ( ((par[4]->value).arr)->data == NULL ) 	/* check that is allocated */
    ) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 26;
    return;
  }

  TIFSIP_read_line(chan,img,line,&source,&status_code);

  if(status_code == STC( ERRSID_normal))  {
    memcpy(((par[4]->value).arr)->data,source,TIFSPV_gid[chan].linesize[img]);
  }
  else {
    (par[0]->value).l=1;
    return;
  }

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_writeline

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and writeline.
		    The IDL array type IS NOT checked.
		    The IDL array size IS checked.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             LONG INT        the line number of the line to be writed
		    4             unspecified arr the IDL array that contain the image portion

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_writeline
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  INTx4 chan;
  INTx4 img;
  UINTx4 line;
  register void *source;
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );
  
  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=5) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  chan=(par[1]->value).l;
  img=(par[2]->value).l;
  line=(par[3]->value).l;

  source=(INTx1 *)((par[4]->value).arr)->data; /* set to the start of IDL array */

  /* sanity checks on IDL array */
  if(
     (!((par[4]->flags)&IDL_V_ARR) ) || 	/* check that is an array */
     ( ((par[4]->value).arr)->arr_len != TIFSPV_gid[chan].linesize[img]) || /* and has enought rooms */
     ( ((par[4]->value).arr)->data == NULL ) 	/* check that is allocated */
    ) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 26;
    return;
  }

  TIFSIP_write_line(chan,img,line,(void *)source,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }


}


/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_closeline

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and  close_line.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_closeline
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  INTx4 chan;
  INTx4 img;
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  
  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=3) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  chan=(par[1]->value).l;
  img=(par[2]->value).l;

  TIFSIP_close_line(chan,img,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_setimgnum

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and set_imgnum.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the name of the BTIFF file
		    2             LONG INT        the image number to be set

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_setimgnum
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=3) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  TIFSIP_set_imgnum((par[1]->value).str.s,(par[2]->value).l,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }


}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_setparnum

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and set_parnum.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the name of the BTIFF file
		    2             LONG INT        the image number
		    3             LONG INT        the number of parameters to be set

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_setparnum
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=4) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  TIFSIP_set_parnum((par[1]->value).str.s,(par[2]->value).l,
                    (UINTx2)(par[3]->value).l,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_setblockinfo

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and set_blockinfo.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
  		    1             LONG INT        the name of the file
  		    2             LONG INT        the image number
  		    3             LONG INT        the compression
  		    4             LONG INT        the imagewidth
  		    5             LONG INT        the imagelenght
  		    6             LONG INT        the rowsperblock
  		    7             LONG INT        the columnsperblock
  		    8             LONG INT        the bitspersample (SCALAR)
  		    9             LONG INT        the sampleperpixel
  		    10            LONG INT        the photometricinterpretation
  		    11            STRING          the disposition

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_setblockinfo
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]) 
{

  TIFSIT_basicpar dummy;
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );


  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=13) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  /* Waiting the IDL struct interface; for now, copy the parameters into the 
     structure fields */
  
  dummy.compression=(par[3]->value).l;
  dummy.imagewidth=(par[4]->value).l;
  dummy.imagelength=(par[5]->value).l;
  dummy.rowsperblock=(par[6]->value).l;
  dummy.columnsperblock=(par[7]->value).l;
  dummy.bitspersample[0]=(par[8]->value).l; /* is used only the first value, as done in all the BITIF lib (future expansion) */
  dummy.sampleperpixel=(par[9]->value).l;
  dummy.photometricinterpretation=(par[10]->value).l;
  dummy.sampleformat[0]=(par[12]->value).l; /* is used only the first value, as done in all the BITIF lib (future expansion) */

  /* always set to 300 (never used) */
  dummy.xresolution[0]=300;
  dummy.xresolution[1]=1;
  dummy.yresolution[0]=300;
  dummy.yresolution[1]=1;
  dummy.resolutionunit=2;
   

  /* copy the disposition as a 1 char */
  dummy.disposition=*((par[11]->value).str.s);

  TIFSIP_set_blockinfo((par[1]->value).str.s,(par[2]->value).l,
                       &dummy,&status_code);
  
  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_storeblockinfo

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and store_blockinfo.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
  		    0 *           LONG INT        return status 0 is OK, nonzero is error
  		    1             LONG INT        the channel of the file
  		    2             LONG INT        the image number

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_storeblockinfo
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[])
{
 
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );

  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=3) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  TIFSIP_store_blockinfo((par[1]->value).l,(par[2]->value).l,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_storetag

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and store_par.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
  		    0 *           LONG INT        return status 0 is OK, nonzero is error
  		    1             LONG INT        the channel of the file
  		    2             LONG INT        the image number
  		    3             LONG INT        the tag number
  		    4             unspecified     the value in a allowed IDL type

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_storetag
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[])
{                     
          
  TIFSIT_par       btiffpar;
  ERRSIT_status    status_code;

  status_code      = STC( ERRSID_normal );
 
  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=5) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  btiffpar.tag=(par[3]->value).l;

  /* in BTIFF_LIB_RTL was: if(TIFSPF_IDLI_CvtIDLtoBTIFF(par[4],&btiffpar)) { */
  if(TIFSPF_IDLI_CvtIDLtoBTIFF(&par[4],&btiffpar)) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 30;
    return;
  }

  TIFSIP_store_par((par[1]->value).l,(par[2]->value).l,&btiffpar,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_writesubimage

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and the following BTIFF routines
		    open_line, writeline, close_line
		    This routine does not exist into the original BTIFF package and is build
		    just for IDL. With this routine a image portion can be written into a BTIFF
		    file
		    A copy line by line is made from the IDL array image buffer into the file
		    The IDL array type IS NOT checked. 
		    The IDL array size IS checked.
		    A byte per byte copy into the BTIFF image buffer is then done.
		    The writing direction is always fixed to be X
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             LONG INT        Start X coord
		    4             LONG INT        Start Y coord
		    5             LONG INT        End   X coord
		    6             LONG INT        End   Y coord
		    7             unspecified arr the IDL array that contain the image portion

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_writesubimage
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[])
{  
          
  UINTx4 y;
  INTx4 sx;
  INTx4 sy;
  INTx4 ex;
  INTx4 ey;
  INTx4 chan;
  INTx4 img;
  INTx4 wid;
  INTx4 len;
  register UINTx4 xsize;
  UINTx4 sizeb;
  INTx4 write_ok=0;
  INTx1 *source;
  ERRSIT_status    status_code;
 
  status_code      = STC( ERRSID_normal );

  
  /* Reset the status */ 
  TIFSPV_ErrData.code = 0;
  (par[0]->value).l=0;

  /* check sul numero di parametri */
  if(npar!=8) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 31;
    return;
  }

  chan=(par[1]->value).l;
  img=(par[2]->value).l;
  sx=(par[3]->value).l;
  sy=(par[4]->value).l;
  ex=(par[5]->value).l;
  ey=(par[6]->value).l;

  wid=TIFSPV_gid[chan].imgcol[img];
  len=TIFSPV_gid[chan].imgrig[img];

  if( (sx<0) || (sy<0) || (ex<0) || (ey<0) ||	/* check for coord less than 0 */
      (sx>=wid) || (ex>=wid) || (sy>=len) || (ey>=len) ||	/* check for coord greater than image 0 */
      (sx>ex) || (sy>ey)	/* check for coords inconstency */
    ) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 27;
    return;
  }

  sizeb=(ey-sy+1)*(ex-sx+1)*TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;

  /* sanity checks on IDL array */
  if(
     (!((par[7]->flags)&IDL_V_ARR) ) || 	/* check that is an array */
     ( ((par[7]->value).arr)->arr_len != sizeb ) || /* and has enought rooms */
     ( ((par[7]->value).arr)->data == NULL ) 	    /* check that is allocated */
    ) {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = 28;
    return;
  }
  
  source=(INTx1 *)((par[7]->value).arr)->data; /* set to the start of IDL array */

  /* lenght of the line to be write in bytes */
  xsize=(ex-sx+1)*TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;

  TIFSIP_open_line(chan,img,'x',sx,ex,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }
 
  for(y=sy;y<=ey;y++) {

    TIFSIP_write_line(chan,img,y,(void *)source,&status_code);  /* accumulate the errors avoiding that a no error condition overwrites an error */

    if(status_code != STC( ERRSID_normal))  {
      write_ok ++; 
    }

    source += xsize;
  }

  TIFSIP_close_line(chan,img,&status_code);

  if(status_code != STC( ERRSID_normal))  {
    (par[0]->value).l=1;
    TIFSPV_ErrData.code = (status_code & 0x0000FFFF);
    return;
  }
  
  if(write_ok) {
    (par[0]->value).l=1;
    return;
  }

  (par[0]->value).l=write_ok;

}


/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifspf_idli_cvtbtifftoidl

      $TYPE         FUNCTION

      $INPUT        btiffpar: a TTIFF parameter structure
                    idlpar : the same parameter converted in IDL

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   1=error 0=OK

      $DESCRIPTION    This procedure convert a BTIFF parameter into a IDL variable.
		      The types allowed are:
		      BTIFF type            IDL type
		      SCALAR TYPE_BYTE      BYTE
		      SCALAR TYPE_UBYTE     INT
		      SCALAR TYPE_SHORT     INT
		      SCALAR TYPE_USHORT    LONG
		      SCALAR TYPE_INT       LONG
		      SCALAR TYPE_FLOAT     FLOAT
		      ARRAY  TYPE_ASCII     SCALAR STRING

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
   INTx4 TIFSPF_IDLI_CvtBTIFFtoIDL
                        (/*IN    */ TIFSIT_par           btiffpar,
                         /*INOUT */ IDL_VPTR             idlpar[]) {


  if((btiffpar.length!=1)&&(btiffpar.type!=TYPE_ASCII)) { /* not a scalar parameter or a string */
    TIFSPV_ErrData.code = 23;
    return(1);
  }

  switch(btiffpar.type) {
    case TYPE_BYTE:
      idlpar[0]->type=IDL_TYP_BYTE;
      (idlpar[0]->value).c=*(INTx1 *)btiffpar.val;
    break;
    case TYPE_UBYTE:
    case TYPE_SHORT:
      idlpar[0]->type=IDL_TYP_INT;
      (idlpar[0]->value).i=*(INTx2 *)btiffpar.val;
    break;
    case TYPE_USHORT:
    case TYPE_UINT:   /* !!!*** May OVERFLOW ***!!! */
    case TYPE_INT:
      idlpar[0]->type=IDL_TYP_LONG;
      (idlpar[0]->value).l=*(INTx4 *)btiffpar.val;
    break;
    case TYPE_FLOAT:
      idlpar[0]->type=IDL_TYP_FLOAT;
      (idlpar[0]->value).f=*(float *)btiffpar.val;
    break;
    case TYPE_ASCII:
      idlpar[0]->type=IDL_TYP_STRING;
      (idlpar[0]->value).str.s=btiffpar.val;
      (idlpar[0]->value).str.stype=0;
      (idlpar[0]->value).str.slen=strlen(btiffpar.val);
    break;
    default:
      return(1);
  }
  return(0);

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifspf_idli_cvtidltobtiff

      $TYPE         FUNCTION

      $INPUT        idlpar : the same parameter converted in IDL
		    btiffpar: a TTIFF parameter structure

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   1=error 0=OK

      $DESCRIPTION  This procedure convert a IDL variable into a TTIFF parameter.
		    The types allowed are:
		    BTIFF type            IDL type
		    SCALAR TYPE_BYTE      BYTE
		    SCALAR TYPE_UBYTE     INT
		    SCALAR TYPE_SHORT     INT
		    SCALAR TYPE_USHORT    LONG
		    SCALAR TYPE_INT       LONG
		    SCALAR TYPE_FLOAT     FLOAT
		    ARRAY  TYPE_ASCII     SCALAR STRING

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
   INTx4 TIFSPF_IDLI_CvtIDLtoBTIFF
                        (/*INOUT */ IDL_VPTR             idlpar[],
                         /*IN    */ TIFSIT_par           *btiffpar) {


  if((idlpar[0]->flags&IDL_V_STRUCT)||
     (idlpar[0]->flags&IDL_V_ARR)||
     (idlpar[0]->flags&IDL_V_FILE)) { /* cannot convert a array or a struct or a file*/
    return(1);
  }

  switch(idlpar[0]->type) {
    case IDL_TYP_BYTE:
      btiffpar->val=malloc(sizeof(INTx1));
      if(btiffpar->val==NULL) return(1); /* problems allocating the memory */
      *(INTx1 *)btiffpar->val=(idlpar[0]->value).c;
      btiffpar->type=TYPE_BYTE;
      btiffpar->length=1;      
    break;
    case IDL_TYP_INT:
      btiffpar->val=malloc(sizeof(INTx2));
      if(btiffpar->val==NULL) return(1); /* problems allocating the memory */
      *(INTx2 *)btiffpar->val=(idlpar[0]->value).i;
      btiffpar->type=TYPE_SHORT;
      btiffpar->length=1;      
    break;
    case IDL_TYP_LONG:
      btiffpar->val=malloc(sizeof(INTx4));
      if(btiffpar->val==NULL) return(1); /* problems allocating the memory */
      *(INTx4 *)btiffpar->val=(idlpar[0]->value).l;
      btiffpar->type=TYPE_INT;
      btiffpar->length=1;      
    break;
    case IDL_TYP_FLOAT:
      btiffpar->val=malloc(sizeof(float));
      if(btiffpar->val==NULL) return(1); /* problems allocating the memory */
      *(float *)btiffpar->val=(idlpar[0]->value).f;
      btiffpar->type=TYPE_FLOAT;
      btiffpar->length=1;      
    break;
    case IDL_TYP_STRING:
      btiffpar->val=malloc((idlpar[0]->value).str.slen+1);
      if(btiffpar->val==NULL) return(1); /* problems allocating the memory */
      memcpy(btiffpar->val,(idlpar[0]->value).str.s,(idlpar[0]->value).str.slen+1);
      btiffpar->type=TYPE_ASCII;
      btiffpar->length=(idlpar[0]->value).str.slen+1; /* including the terminator */
    break;
    default: /* not a allowed type */
      return(1);
  }

  return(0);

}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifspf_idli_dumpidlvar

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   1=error 0=OK

      $DESCRIPTION  Dump a IDL variable -just for test-

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
EXPORT void tifsip_idli_dumpidlvar
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             val[])
{
         
  INTx4 par;
  INTx4 i,j;
  UINTx1 flag_val;
  UINTx1 is_array;

  printf("\n Dump the IDL variables passed into");
  printf("\n Number of variables = %d",npar);

  for(par=0;par<npar;par++) {
    printf("\n Type var %d: %d",par,val[par]->type);

    flag_val=val[par]->flags;
    if(flag_val&IDL_V_CONST) printf("\n   It is a CONSTANT class variable");
    if(flag_val&IDL_V_TEMP) printf("\n   It is a TEMP class variable");
    if(flag_val&IDL_V_ARR) printf("\n   It is a ARRAY class variable");
    if(flag_val&IDL_V_FILE) printf("\n   It is a FILE class variable");
    if(flag_val&IDL_V_DYNAMIC) printf("\n   It is a DYNAMIC class variable");
    if(flag_val&IDL_V_STRUCT) printf("\n   It is a STRUCT class variable");
    if(flag_val&IDL_V_NOT_SCALAR) printf("\n   It is a NOT SCALAR class variable");

    /* An array is a ARR but not FILE and not a STRUCT */
    is_array=	(flag_val&IDL_V_ARR) &&
		(!(flag_val&IDL_V_FILE)) &&
		(!(flag_val&IDL_V_STRUCT));

    if(is_array) {
      printf("\n   Length of element in char units var %d: %d",
            par,((val[par]->value).arr)->elt_len);
      printf("\n   Length of entire array (char) var %d: %d",
            par,((val[par]->value).arr)->arr_len);
      printf("\n   Total # of elements var %d: %d",
            par,((val[par]->value).arr)->n_elts);
      printf("\n   # of dimensions used by array var %d: %d",
            par,((val[par]->value).arr)->n_dim);
      printf("\n   Array block flags var %d: %d",
            par,((val[par]->value).arr)->flags);
      printf("\n   Guard longword var %d: %d",
            par,((val[par]->value).arr)->data_guard);

      printf("\n   Dimensions var %d: ",par);
      for(i=0;i<((val[par]->value).arr)->n_dim;i++)
        printf(" %d ",((val[par]->value).arr)->dim[i]);

      for(i=0;i<((val[par]->value).arr)->n_elts;i++)
          printf("\n val[%d]=%d ",i,
                 *((INTx2 *)(((val[par]->value).arr)->data) + i));

            
    }
    else {

      switch(val[par]->type) {
        case IDL_TYP_UNDEF:
          printf("\n   Val var %d: Undefined",par);
        break;
        case IDL_TYP_BYTE:
          printf("\n   Val var %d: %d",par,(val[par]->value).c);
        break;
        case IDL_TYP_INT:
          printf("\n   Val var %d: %d",par,(val[par]->value).i);
        break;
        case IDL_TYP_LONG:
          printf("\n   Val var %d: %d",par,(val[par]->value).l);
        break;
        case IDL_TYP_FLOAT:
          printf("\n   Val var %d: %f",par,(val[par]->value).f);
        break;
        case IDL_TYP_DOUBLE:
          printf("\n   Val var %d: IDL bug !!",par);
        break;
        case IDL_TYP_COMPLEX:
          printf("\n   Val var %d: R=%f I=%f",par,
                (val[par]->value).cmp.r,(val[par]->value).cmp.i);
        break;
        case IDL_TYP_STRING:
          printf("\n   Val var %d: ",par);
          for(j=0;j<(val[par]->value).str.slen;j++) 
            printf("%c",*((val[par]->value).str.s+j));
        break;
        case IDL_TYP_STRUCT:
          printf("\n   Val var %d: Not Implemented Yet",par);
        break;
        case IDL_TYP_DCOMPLEX:
          printf("\n   Val var %d: IDL bug !!",par);
        break;
      }

    }
      
  }

}

#endif /* __HAVEIDL__ */
