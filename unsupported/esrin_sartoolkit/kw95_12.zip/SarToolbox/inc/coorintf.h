/* ==========================================================================
   $MODULE_HEADER

      $NAME              COOR_INTF

      $FUNCTION          interface module.

      $ROUTINE           COORIP_AOIX_CheckAoI
                         COORIP_AOIX_CheckPointInAoID
                         COORIP_AOIX_CheckPointInAoIS
                         COORIP_AOIX_CoverRect
                         COORIP_AOIX_CheckRect
                         COORIP_AOIX_CheckPointInRect
			 COORIP_CONV_Init
                         COORIP_CONV_RangeAndAnglesEval
			 COORIP_CONV_SlantRangeEval
                         COORIP_CONV_SatPosition
			 COORIP_CONV_rc_en
			 COORIP_CONV_rc_xyz
			 COORIP_CONV_xyz_rc
			 COORIP_CONV_rc_llh
			 COORIP_CONV_llh_rc

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       19-JUN-97     MC       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef COOR
#define COOR COOR


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include IANN_INTF_H
#include MATH_INTF_H

#ifdef COOR_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         COORID_NIMAMAX

      $DESCRIPTION  Limit the max number of simultaneous opened images 
                    for conversion

   $EH
   ========================================================================== */
#define COORID_NIMAMAX IANNID_NIMAMAX


/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         COORIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum COORIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         COORIC_

      $DESCRIPTION  The COORIC_

   $EH
   ========================================================================== */
/*   const COORIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         COORIT_conv

      $DESCRIPTION  struct containing intermediate values for 
                    conversions routines

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          Flatness                         Ellipsoid flatness
                                             f=(a-b)/a
          Eccentricity_1                   sqtr(Eccentricity_1)
          Eccentricity_2                   first numeric eccentricity
                                             e2=(a^2 -b^2)/a^2
          Eccentricity_2p                  second numeric eccentricity
                                             e'2=(a^2 -b^2)/b^2
          np                               =f/(2-f)
          a0
          a2
          a4
          a6
          a8
          imaflg                           0   complex image
                                           1   real image
          prf                              Pulse Repetition Frequence
          xyz_C
          dt
          ST_time[IANNID_NSTVECMAX]        array of the times at the
                                           state vectors
          X_STVec_2D[IANNID_NSTVECMAX]     array of X-position at the state
                                           vectors of the spacecraft
          Y_STVec_2D[IANNID_NSTVECMAX]     array of Y-position at the state
                                           vectors of the spacecraft
          Z_STVec_2D[IANNID_NSTVECMAX]     array of Z-position at the state
                                           vectors of the spacecraft
          VX_STVec_2D[IANNID_NSTVECMAX]    array of X-velocity at the state
                                           vectors of the spacecraft
          VY_STVec_2D[IANNID_NSTVECMAX]    array of Y-velocity at the state
                                           vectors of the spacecraft
          VZ_STVec_2D[IANNID_NSTVECMAX]    array of Z-velocity at the state
                                           vectors of the spacecraft
          SP                               cartesian coordinates of 
                                           current spacecraft position
          SV                               cartesian coordinates of 
                                           current spacecraft velocity
          slant                            evalutation of slant range
          col_spa                          evaluation of column spacing

   $EH
   ========================================================================== */
   struct COORIT_conv_def
    {
      double		Flatness;
      double		Eccentricity_1;
      double		Eccentricity_2;
      double		Eccentricity_2p;
      double            np;
      double            a0;
      double            a2;
      double            a4;
      double            a6;
      double            a8;
      INTx4             imaflg;
      double            prf;
      MATHIT_XYZ        xyz_C;
      double            dt;
      double            ST_time[IANNID_NSTVECMAX];
      double            X_STVec_2D[IANNID_NSTVECMAX];
      double            Y_STVec_2D[IANNID_NSTVECMAX];
      double            Z_STVec_2D[IANNID_NSTVECMAX];
      double            VX_STVec_2D[IANNID_NSTVECMAX];
      double            VY_STVec_2D[IANNID_NSTVECMAX];
      double            VZ_STVec_2D[IANNID_NSTVECMAX];
      MATHIT_XYZ        SP;
      MATHIT_XYZ        SV;
      double            slant;
      double            col_spa;
      double            SRCoeff;
   };
   typedef struct COORIT_conv_def COORIT_conv;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         COORIV_conv

      $DESCRIPTION  it contains the structure COORIT_conv type 
                    of each image

   $EH
   ========================================================================== */
   GLOBAL  COORIT_conv COORIV_conv[COORID_NIMAMAX];

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CheckAoI

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     nVertex : number of points
                      coords  : array of coordinates

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_few_vertex
		      
        $DESCRIPTION  This procedure checks and , if it is possible, fixes the
		      polygonal array of AoI vertex coordinates

        $WARNING      NONE

        $PDL	      - Checks th emultiple defined vertex
		      - Fixes them if there are
		      - Resets the vertex

   $EH
   ========================================================================== */
   extern void COORIP_AOIX_CheckAoI
			(/*IN OUT*/ UINTx4               nVertex, 
			 /*IN OUT*/ MATHIT_RC           *coords, 
			 /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CheckPointInAoID

        $TYPE         PROCEDURE

        $INPUT        nVertex : number of vertexes of the AoI
		      coords  : array of vertex coordinates
		      point   : coordinates of the point to check

        $MODIFIED     NONE

        $OUTPUT       in_out  : indicator of the point position WRT the AoI:
				 -1  point out of the AoI;
				  0  point on the AoI borders;
				  1  point into the AoI;

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure checks if a point lies into a polygonal
		      AoI

        $WARNING      The number of vertex nVertex is used to dynamically allocate diff and dist.
                      No formal check is made for the AoI: call the 
                      COORIP_AOIX_CheckAoI routine before

        $PDL	      - Evaluates the differences of the point coordinates
			WRT each AoI vertex
		      - Evaluates the distances between the point and each
		        vertex
		      - Loop on the vertex
		            - Evaluates the scalar product between the contigues
			      vectors distances
                            - Evaluates the vector product between them
			    - Sums the angles with their sign given by the sign
			      of the vector product component out of the vectors
			      plane
		      - End Loop
		      - Checks the point position using the value of the angles
		        sum

   $EH
   ========================================================================== */
   extern void COORIP_AOIX_CheckPointInAoID
			(/*IN    */ UINTx4               nVertex, 
			 /*IN    */ MATHIT_RC           *coords, 
                         /*IN    */ MATHIT_RC           *point, 
                         /*   OUT*/ INTx4               *in_out,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CheckPointInAoIS

        $TYPE         PROCEDURE

        $INPUT        nVertex : number of vertexes of the AoI
		      coords  : array of vertex coordinates
		      point   : coordinates of the point to check

        $MODIFIED     NONE

        $OUTPUT       in_out  : indicator of the point position WRT the AoI:
				 -1  point out of the AoI;
				  0  point on the AoI borders;
				  1  point into the AoI;

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure checks if a point lies into a polygonal
		      AoI

        $WARNING      No formal check is made for the AoI: call the 
                      COORIP_AOIX_CheckAoI routine before

        $PDL	      - Evaluates the differences of the point coordinates
			WRT each AoI vertex
		      - Evaluates the distances between the point and each
		        vertex
		      - Loop on the vertex
		            - Evaluates the scalar product between the contigues
			      vectors distances
                            - Evaluates the vector product between them
			    - Sums the angles with their sign given by the sign
			      of the vector product component out of the vectors
			      plane
		      - End Loop
		      - Checks the point position using the value of the angles
		        sum

   $EH
   ========================================================================== */
   extern void COORIP_AOIX_CheckPointInAoIS
			(/*IN    */ UINTx4               nVertex, 
			 /*IN    */ MATHIT_RC           *coords, 
                         /*IN    */ MATHIT_RC           *point, 
                         /*   OUT*/ INTx4               *in_out,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CoverRect

        $TYPE	      PROCEDURE

        $INPUT        nVertex	    : number of vertex
                      coords	    : array of coordinates of the vertex

        $MODIFIED     NONE

        $OUTPUT       TopLeft       : coordinates of the Top Left corner of the
                                      rectangle covering the AoI
                      BottomRight   : coordinates of the Bottom Right corner of
                                      the rectangle covering the AoI

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_few_vertex
		      ERRSID_COOR_invalid_AoI

        $DESCRIPTION  This procedure computes the smallest rectangle including
		      the given AoI

        $WARNING      NONE

        $PDL          - Searches the minima Top Left corner coordinates
		      - Searches the maxima Bottom Right corner coordinates

   $EH
   ========================================================================== */
   extern void COORIP_AOIX_CoverRect
			(/*IN    */ UINTx4              nVertex, 
			 /*IN    */ MATHIT_RC          *coords, 
			 /*   OUT*/ MATHIT_RC          *TopLeft, 
			 /*   OUT*/ MATHIT_RC          *BottomRight,
			 /*   OUT*/ ERRSIT_status      *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CheckRect

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     TopLeft	    : input row, col coordinates of the Top Left
				      corner
		      BottomRight   : input row, col coordinates of the Bottom
				      Right corner

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_invalid_AoI

        $DESCRIPTION  This procedure checks and, if it is possible, fixs the
		      rectangular array of AoI coordinates

        $WARNING      The first point is the top-left corner, the others
		      follow clockwise.

	$PDL	      - Checks if the coordinates defines a line or a point
		      - Exchanges the corners coordinates if they are not
		        in the right order
   $EH
   ========================================================================== */
   extern void COORIP_AOIX_CheckRect
			(/*IN OUT*/ MATHIT_RC           *TopLeft, 
			 /*IN OUT*/ MATHIT_RC           *BottomRight,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CheckPointInRect

        $TYPE	      PROCEDURE

        $INPUT        TopLeft	    : Top Left row, col coordinates of the
				      rectangular area
		      BottomRight   : Bottom Right row, col coordinates of the
				      rectangular area
		      point	    : coordinates of the point to check

        $MODIFIED     NONE

        $OUTPUT       in_out	    : flag to indicate the point position WRT
				      the rectangular area
				       - 1        point into the rectangle
				       - 0        point on the rectangular
						  borders
				       - -1       point out of the rectangle

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure checks if a point is into a rectangular AoI

        $WARNING      No formal check is made for the rect AoI: call the 
                      COORIP_AOIX_RectCheckAoI routine before

        $PDL	      - Checks if the point is on the rectangular borders
		      - Checks if the point is internal of the rectangle

   $EH
   ========================================================================== */
   extern void COORIP_AOIX_CheckPointInRect 
			(/*IN    */ MATHIT_RC           *TopLeft, 
			 /*IN    */ MATHIT_RC           *BottomRight,
			 /*IN    */ MATHIT_RC           *point,
			 /*   OUT*/ INTx4               *in_out,
			 /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_Init

        $TYPE	      PROCEDURE

        $INPUT        imanum  : number of the image among the other in the
                                tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_bad_param_annot

        $DESCRIPTION  This procedure initialize the COORIV_conv[imanum]
		      structure for all the coordinates conversions that could
		      be made on the product <imanum>

        $WARNING      The procedure IANNIP_GETP_GetImageAnnot must be called
		      before to call this

   $EH
   ========================================================================== */
   extern void COORIP_CONV_Init
			(/*IN    */ INTx4                imanum,
			 /*   OUT*/ ERRSIT_status	*status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_RangeAndAnglesEval

        $TYPE	      PROCEDURE

        $INPUT        imanum          : image ID
                      TLRow           : top left row AoI coordinate
                      TLCol           : top left col AoI coordinate
                      NRow            : number of rows of the AoI
                      NCol            : number of columns of the AoI

        $MODIFIED     NONE

        $OUTPUT       look_angle      : array to fill with the columns dependent
                                        look angles
                      incidence_angle : array to fill with the columns dependent
                                        incidence angles
                      slant_range     : array to fill with the columns dependent
                                        slant range
 
        $GLOBAL       IANNIV_ImageAnnot : image annotations INFO structure
                      COORIV_conv       : coordinates conversions structure

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
                      ERRSID_COOR_out_of_range

        $DESCRIPTION  This procedure evaluates the slant range, the incidence
                      angle and the look angle values for the central row of
                      the AoI of the image defined by its ID <imanum>

        $WARNING      THE COORDINATES CONVERSIONS MUST BE INITIALIZED BEFORE

        $PDL          - Evaluates the central row of the image
                      - Evaluates its value in the full frame reference
                        system
                      - Evaluates the time corresponding to the row
                      - Evaluates the spacecraft position at that time
                      - Loop over the columns in the AoI
                            - Evaluates the column coordinate in the full frame 
                              reference system
                            - Evaluates the slant range corresponding to that
                              column
                            - Evaluates the target position
                            - Evaluates the earth radius of curvature
                            - Evaluates the spacecraft position range
                            - Evaluates the incidence angle at the current
                              column
                            - Evaluates the look angle at the current column
                            - Rescale the incidence angle from radians to
                              degrees
                      - End Loop

   $EH
   ========================================================================== */
   extern void COORIP_CONV_RangeAndAnglesEval
			(/*IN    */ UINTx1               imanum,
			 /*IN    */ UINTx4               TLRow,
			 /*IN    */ UINTx4               TLCol,
			 /*IN    */ UINTx4               NRow,
			 /*IN    */ UINTx4               NCol,
                         /*   OUT*/ float               *look_angle,
                         /*   OUT*/ float               *incidence_angle,
                         /*   OUT*/ float               *slant_range,
			 /*   OUT*/ ERRSIT_status	*status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_SlantRange

        $TYPE	      PROCEDURE

        $INPUT        col	 : input column at which the slant range must be
				   evaluate
		      imanum	 : number of the image among the other in the
                                   tool

        $MODIFIED     NONE

        $OUTPUT       SlantRange : slant range at the given column in meters
 
        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_unhandled_projection

        $DESCRIPTION  This procedure evaluates the slant range at a given
		      column

	$PDL	      - Switch between the image type
		            - Evaluate the spacing
			    - Evaluate the actual column
			    - Evaluate the slant range
		      - End switch

   $EH
   ========================================================================== */
   extern void COORIP_CONV_SlantRangeEval
			(/*IN    */ double               col,
			 /*IN    */ INTx4                imanum,
			 /*   OUT*/ double              *SlantRange,
			 /*   OUT*/ ERRSIT_status	*status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_SatPosition

        $TYPE	      PROCEDURE

        $INPUT        imanum : image ID
                      row    : row coordinates at which to evaluate the
                               satellite position

        $MODIFIED     NONE

        $OUTPUT       XYZ_out : spacecraft position
                      V_out   : spacecraft velocity 

        $GLOBAL       IANNIV_ImageAnnot : image annotations structure INFO
                      COORIV_conv       : coordinates converions INFO

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
                      ERRSID_COOR_bad_param_annot

        $DESCRIPTION  This procedure evaluates the spacecraft position
                      interpolating the annotated state vectors at the time
                      corresponding to the input row coordinate

        $WARNING      THE COORDINATES CONVERSIONS INITIALIZATION MUST BE DONE
                      BEFORE FOR THE IMAGE

        $PDL          - Checks the image ID
                      - Checks the necessary annotations
                      - Re-scale the row coordinate to the full frame image
                      - Evaluate the corresponding time
                      - Interpolates the spacecraft cartesian position
                      - Interpolates the spacecraft cartesian velocity

   $EH
   ========================================================================== */
   extern void COORIP_CONV_SatPosition
			(/*IN    */ UINTx1               imanum,
                         /*IN    */ double               row,
                         /*   OUT*/ MATHIT_XYZ          *XYZ_out,
                         /*   OUT*/ MATHIT_XYZ          *V_out,
			 /*   OUT*/ ERRSIT_status	*status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_rc_xyz

        $TYPE	      PROCEDURE

        $INPUT        RC_in   : input ( row, col ) image coordinates in pixel
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       XYZ_out : output cartesian ( x, y, z ) coordinates in
			        meters

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need
                      COORPV_ImgNum             : the image number among all
                                                  that opened in the program

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_bad_param_annot

        $DESCRIPTION  This procedure converts a point from image to cartesian 
                      coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
   extern void COORIP_CONV_rc_xyz
			(/*IN    */ MATHIT_RC		*RC_in,
			 /*IN    */ INTx4		 imanum,
			 /*   OUT*/ MATHIT_XYZ		*XYZ_out,
			 /*   OUT*/ ERRSIT_status	*status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_xyz_rc

        $TYPE         PROCEDURE

        $INPUT        XYZ_in  : input cartesian ( x, y, z ) coordinates in
			        meters
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       RC_out  : output ( row, col ) image coordinates in pixel

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
                                                  image annotations
                      COORIV_conv[imanum]	: the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need
		      COORPV_ImgNum             : the image number among all
                                                  that opened in the program

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_bad_param_annot

        $DESCRIPTION  This procedure converts a point from cartesian to image
		      coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
   extern void COORIP_CONV_xyz_rc
			(/*IN    */ MATHIT_XYZ          *XYZ_in,
                         /*IN    */ INTx4                imanum,
                         /*   OUT*/ MATHIT_RC           *RC_out,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_rc_en

        $TYPE         PROCEDURE

        $INPUT        RC_in   : input ( row, col ) coordinates to convert
		      imanum  : image number among the others in the
				program

        $MODIFIED     NONE

        $OUTPUT       EN_out  : output ( east, north ) UTM or UPS coordinates
				in meters

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations

        $RET_STATUS   ERRSID_COOR_imanum_not_allow

        $DESCRIPTION  This procedure converts a point from a image to East-
		      North coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
		      before all the conversions procedures

   $EH
   ========================================================================== */
   extern void COORIP_CONV_rc_en
                        (/*IN    */ MATHIT_RC           *RC_in,
                         /*IN    */ INTx4                imanum,
                         /*   OUT*/ MATHIT_EN           *EN_out,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_rc_llh

        $TYPE	      PROCEDURE

        $INPUT        RC_in   : input ( row, col ) image coordinates in pixel
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       LLH_out : output geodetic ( lat, lon, h ) coordinates in
                                degrees and meters

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
                                                  image annotations
                      COORIV_conv[imanum]	: the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_unhandled_projection

        $DESCRIPTION  This procedure converts a point from image ( row, col )
		      to geodetic lat lon coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

        $PDL          - Switch among geocoded and not geocoded product
		            - Case GEOCODED
			          - Converts the input ( row, col ) coordinates
				    into ( east, north ) UTM or UPS coordinates
                                  - Converts the intermediate ( east, north )
				    UTM or UPS coordinates into ( lat, lon, h )
				    geodetic coordinates
			    - End Case
			    - Case NOT GEOCODED
			          - Converts the input ( row, col ) coordinates
                                    into cartesian ( x, y, z ) coordinates
				  - Converts the intermediate  ( x, y, z )
				    cartesian coordinates into ( lat, lon, h )
				    geodetic coordinates
			    - End Case
		      - End switch

   $EH
   ========================================================================== */
   extern void COORIP_CONV_rc_llh
			(/*IN    */ MATHIT_RC           *RC_in,
			 /*IN    */ INTx4                imanum,
			 /*   OUT*/ MATHIT_LLH          *LLH_out,
			 /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_llh_rc

        $TYPE         PROCEDURE

        $INPUT        LLH_in  : input geodetic ( lat, lon, h ) coordinates in
                                degrees and meters
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       RC_out  : output ( row, col ) image coordinates in pixel
 
        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
                      ERRSID_COOR_unhandled_projection

        $DESCRIPTION  This procedure converts a point from geodetic ( lat, lon,
		      h ) to image coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

        $PDL          - Switch among geocoded and not geocoded product
                            - Case GEOCODED
                                  - Converts the input geodetic ( lat, lon, h )
				    coordinates into ( east, north ) UTM or UPS
				    coordinates
                                  - Converts the intermediate ( east, north )
                                    UTM or UPS coordinates into ( row, col )
                                    image coordinates
                            - End Case
                            - Case NOT GEOCODED
                                  - Converts the input geodetic ( lat, lon, h )
				    coordinates into cartesian ( x, y, z )
				    coordinates
                                  - Converts the intermediate  ( x, y, z )
                                    cartesian coordinates into ( row, col )
                                    image coordinates
                            - End Case
                      - End switch

   $EH
   ========================================================================== */
   extern void COORIP_CONV_llh_rc
			(/*IN    */ MATHIT_LLH		*LLH_in,
			 /*IN    */ INTx4		 imanum,
			 /*   OUT*/ MATHIT_RC		*RC_out,
			 /*   OUT*/ ERRSIT_status	*status_code );


/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         COORIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void COORIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) COORIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         COORIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    COORIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define COORIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#ifdef __VMS__

#define ERRSID_COOR_err_mem_alloc        2
#define ERRSID_COOR_unhandled_projection 3
#define ERRSID_COOR_math_exception       4
#define ERRSID_COOR_TEST                 5
#define ERRSID_COOR_imanum_not_allow     6
#define ERRSID_COOR_bad_param_annot      7
#define ERRSID_COOR_value_out_of_abs     8
#define ERRSID_COOR_null_interval        9
#define ERRSID_COOR_null_dist_sp_target 10
#define ERRSID_COOR_invalid_AoI         11
#define ERRSID_COOR_few_vertex          12
#define ERRSID_COOR_few_elements        13
#define ERRSID_COOR_proc_name_unknown   14
#define ERRSID_COOR_conv_not_allowed    15
#define ERRSID_COOR_out_of_range        16

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef COOR_GLBL
   GLOBAL char *COORIV_ERRS_error_message[] = {
      "No error happens",                                                /* 0 */
      "Generic error happens",                                           /* 1 */
      "SYSTEM ERROR: memory allocation error",                           /* 2 */
      "Unhandled projection type",                                       /* 3 */
      "Mathematic exception occurs",                                     /* 4 */
      "TEST Error ",                                                     /* 5 */
      "Image number not good",                                           /* 6 */
      "BAD PARAMETERS ANNOTATED",                                        /* 7 */
      "Current abscissa out of the allowed range",                       /* 8 */
      "Null interval in the abscissa array",                             /* 9 */
      "Null distance Spacecraft-Target",                                /* 10 */
      "Invalid AoI coordinates",                                        /* 11 */
      "Number of vertices defining the AoI out of range",               /* 12 */
      "Too few elements",                                               /* 13 */
      "Processor name not known",                                       /* 14 */
      "Coordinate convertion not allowed",                              /* 15 */
      "Number of pixel out of image range",                             /* 16 */
   };

#else
   GLOBAL char *COORIV_ERRS_error_message[];
#endif

#else

#define ERRSID_COOR_err_mem_alloc        2
#define ERRSID_COOR_unhandled_projection 2
#define ERRSID_COOR_math_exception       2
#define ERRSID_COOR_TEST                 2
#define ERRSID_COOR_imanum_not_allow     2
#define ERRSID_COOR_bad_param_annot      2
#define ERRSID_COOR_value_out_of_abs     2
#define ERRSID_COOR_null_interval        2
#define ERRSID_COOR_null_dist_sp_target  2
#define ERRSID_COOR_invalid_AoI          2
#define ERRSID_COOR_few_vertex           2
#define ERRSID_COOR_few_elements         2
#define ERRSID_COOR_proc_name_unknown    2
#define ERRSID_COOR_conv_not_allowed     2
#define ERRSID_COOR_out_of_range         2

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef COOR_GLBL
   GLOBAL char *COORIV_ERRS_error_message[] = {
      "No error happens",                                                /* 0 */
      "Generic error happens",                                           /* 1 */
      "Coordinates Convertion library error happens"                     /* 2 */
   };

#else
   GLOBAL char *COORIV_ERRS_error_message[];
#endif

#endif

#endif

