/* ==========================================================================
   $MODULE_HEADER

      $NAME              TIFS_PGLB

      $FUNCTION          TIFF library global module.

      $ROUTINE           TIFSPP_disp_evaluate
			 TIFSPP_ifd_reorder
			 TIFSPP_LZWencode
			 TIFSPP_LZWdecode
			 TIFSPP_check_tiff
			 TIFSPP_find_chan
			 TIFSPF_get_block
			 TIFSPF_store_block
			 TIFSPF_readandswap
			 TIFSPP_TEST_Strdivide2
			 TIFSPP_TEST_Strdivide3
			 TIFSPP_TEST_ReadTags
			 TIFSPP_TEST_FindTag
			 TIFSPP_TEST_FillBpar
			 TIFSPF_TEST_RemoveSpaces
			 TIFSPP_TEST_GenConstImgline
			 TIFSPP_TEST_GenRandomImgline
			 TIFSPF_TEST_CountUsertags
			 TIFSPP_TEST_FillTagVet
			 TIFSPP_TEST_GetTagName
                         TIFSPF_IDLI_CvtBTIFFtoIDL
			 TIFSPF_IDLI_CvtIDLtoBTIFF

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       02-JAN-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#ifdef __HAVEIDL__
#include IDLI_INTF_H
#endif /* __HAVEIDL__ */
#include TIFS_INTF_H


#ifdef  TIFS_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ---

      $DESCRIPTION  TIFF library limits

   $EH
   ========================================================================== */
#define LZWBUFSIZE	    65536   /* dimensione del buffer per il 
                                       (de)compressore */
#define LINEMAX		    1000000 /* numero massimo di linea usabile (serve 
                                       solo per il set iniziale della variabile 
                                       minline) */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IMGLINELEN

      $DESCRIPTION  The size of the buffer containing one image line
		    Used for TIFS_TEST only

   $EH
   ========================================================================== */
#define IMGLINELEN 15000

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MAXTAGS

      $DESCRIPTION  The maximum number of tags contained in a TIF file
		    Used for TIFS_TEST only

   $EH
   ========================================================================== */
#define MAXTAGS 5000

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIRST_NONFUNDAMENTALTAG

      $DESCRIPTION  The value of the tagnumber of the first user tag
		    Used for TIFS_TEST only

   $EH
   ========================================================================== */
#define FIRST_NONFUNDAMENTALTAG 2000

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum TIFSPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSPC_

      $DESCRIPTION  The TIFSPC_

   $EH
   ========================================================================== */
/*   const TIFSPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSPT_filedata

      $DESCRIPTION  Struttura con i parametri di scambio globali tra le varie 
                    routines relativi ai file TIFF

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct TIFSPT_filedata_def {
     UINTx4      	freeptr;  /* puntatore al primo byte libero su disco */
     UINTx4      	actptr;   /* puntatore alla posizione attuale nel file 
                                     su disco */
     INTx4		used;	  /* flag di used(1)/unused(0) */
     char		mode;	  /* carattere di r(ead)/w(rite)/u(pdate) */
     char		name[80]; /* nome del file TIFF */
     INTx4		nimg;	  /* numero di immagini presenti nel file */
     UINTx1            *imgpar[MAX_IMAGES];	/* vettore contenente i puntatori alle 
                                           aree di parametri di ogni immagine 
                                           (max MAX_IMAGES immagini) */
     UINTx2        	npar[MAX_IMAGES]; /* numero di parametri per ogni immagine*/
     UINTx4      	ifd[MAX_IMAGES];  /* vettore contenente l'indice della 
                                         prossima IFD da usare */
     UINTx4            *blockoffs[MAX_IMAGES]; /* vettore contenente i puntatori 
                                              ai vettori di block offset per 
                                              ogni immagine */
     UINTx4            *blocksize[MAX_IMAGES]; /* vettore contenente i puntatori 
                             ai vettori di block byte size per ogni immagine. 
			     Questa dimensione e' quella del numero di bytes 
			     del blocco come si trova su disco (se e' compresso
			     la dimensione varia da blocco a blocco) */
     char		disp[MAX_IMAGES];             /* disposizione dei blocchi */
     UINTx4      	imgcol[MAX_IMAGES];   /* numero di colonne dell'immagine */
     UINTx4      	imgrig[MAX_IMAGES];   /* numero di righe dell'immagine */
     UINTx4      	blockcol[MAX_IMAGES]; /* numero di colonne del blocco non 
			    compresso - dimensione unica per tutti i blocchi di
			    una immagine*/
     UINTx4      	blockrig[MAX_IMAGES]; /* numero di righe del blocco non 
			    compresso - dimensione unica per tutti i blocchi di
			    una immagine*/
     UINTx2        	sampix[MAX_IMAGES];   /* sample per pixel */
     UINTx2            *bitsam[MAX_IMAGES];   /* bits per sample */
     UINTx2            *sampleformat[MAX_IMAGES];   /* sample per format */
     UINTx2         	photometricinterpretation[MAX_IMAGES];
     UINTx4         	xresolution[MAX_IMAGES][2];
     UINTx4         	yresolution[MAX_IMAGES][2];
     UINTx2         	resolutionunit[MAX_IMAGES];
     UINTx2         	compression[MAX_IMAGES]; /* parametro indicante la 
						compressione */
     UINTx1            *lzwbuf[MAX_IMAGES];  /* buffer per il compressore */
     UINTx4        	nblock[MAX_IMAGES]; /* vettore contenente il numero di 
					   blocchi per ogni immagine */
     UINTx1            *blockbuf[MAX_IMAGES]; /* buffer per 1 blocco nella read e 
					     write line */
     UINTx1            *linebuf[MAX_IMAGES]; /* buffer delle linee (piu' blocchi) 
					    per la read e write line */
     UINTx1            *linebufbase[MAX_IMAGES]; /* punta, nel buffer di linea, il
						campione della prima linea, 
						relativo a samplestart */ 
     UINTx4       	blkstart[MAX_IMAGES]; /* blocco iniziale del buffer di 
					    linea, nella direzione di lettura */
     UINTx4      	blkend[MAX_IMAGES]; /* blocco finale del buffer di linea, 
					   nella direzione di lettura */
     UINTx4      	nblkx[MAX_IMAGES]; /* numero di blocchi dell'immagine nella
					  direzione x */
     UINTx4      	linebufdim[MAX_IMAGES]; /* size in bytes nella direzione di
					       lettura del buffer di linea */
     UINTx4      	blkbufdim[MAX_IMAGES]; /* size in bytes nella direzione di 
					      lettura del buffer di blocco */
     UINTx4      	linesize[MAX_IMAGES]; /* size in bytes della linea */
     UINTx4      	minline[MAX_IMAGES]; /* usata per gestire il caricamento di
                                            nuovi blocchi nella read line */
     char		direction[MAX_IMAGES]; /* direzione (x o y) lungo la quale 
                                              si legge la linea */
     UINTx1            *blkflag[MAX_IMAGES];  /* puntatore al vettore di flags 
                                             indicante se un blocco, durante la 
                                             writeline, e' stato salvato o no */
     FILE	       *tf;	          /* puntatore al file tiff */
     char               swap_byte;        /* indica se durante la lettura i 
                                             bytes necessitano dello swap 
					     (dipende dalla macchina e dalla 
					      memorizzazione usata II o MM ) */
     UINTx1             tif[MAX_IMAGES];  /* set to 1 if the image is tif 
                                             standard */
   };

   typedef struct TIFSPT_filedata_def TIFSPT_filedata;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSPT_CodeTable

      $DESCRIPTION  Header file per algoritmo LZW utilizzato nel formato dati 
		    TIFF

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct TIFSPT_CodeTable_def {
      UINTx4       Pr;	     /* puntatore al prefisso della stringa */
      UINTx4       Co;	     /* carattere seguente la stringa */
      UINTx4       FrstPr;   /* puntatore al primo codice di prefisso */
      UINTx4       NextPrLo; /* puntatore al prossimo prefisso uguale a Pr */
      UINTx4       NextPrHi; /* puntatore al prossimo prefisso uguale a Pr */
      UINTx4       NBitCode; /* dimensione del codice in bit */
   };

   typedef struct TIFSPT_CodeTable_def TIFSPT_CodeTable;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSPT_ErrData

      $DESCRIPTION  IDL error management structure

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          code                             IDL internal error code
          string                           IDL internal error message

   $EH
   ========================================================================== */
   struct TIFSPT_ErrData_def {
      INTx4       code;
      char        string[ IDLMESSAGESLENGTH ];
   };

   typedef struct TIFSPT_ErrData_def TIFSPT_ErrData;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSPV_ErrData

      $DESCRIPTION  IDL error management structure

   $EH
   ========================================================================== */
   GLOBAL TIFSPT_ErrData TIFSPV_ErrData;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSPV_gid

      $DESCRIPTION  Vector of filedata

   $EH
   ========================================================================== */
   GLOBAL TIFSPT_filedata TIFSPV_gid[ MAX_FILES ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSPV_size

      $DESCRIPTION  Vector of type sizes 

   $EH
   ========================================================================== */
#ifdef TIFS_GLBL
   GLOBAL UINTx4       TIFSPV_size[ N_TYPES ] = 
                                    { 0, /* primo elemento non usato */
                                      SIZE_TYPE_UBYTE,
                                      SIZE_TYPE_ASCII,
                                      SIZE_TYPE_USHORT,
                                      SIZE_TYPE_UINT,
                                      SIZE_TYPE_URATIONAL,
                                      SIZE_TYPE_BYTE,
                                      SIZE_TYPE_SHORT,
                                      SIZE_TYPE_INT,
                                      SIZE_TYPE_FLOAT,
                                      SIZE_TYPE_DOUBLE,
                                      SIZE_TYPE_UBYTE_COD_ASCII,
                                      SIZE_TYPE_BYTE_COD_ASCII,
                                      SIZE_TYPE_USHORT_COD_ASCII,
                                      SIZE_TYPE_SHORT_COD_ASCII,
                                      SIZE_TYPE_UINT_COD_ASCII,
                                      SIZE_TYPE_INT_COD_ASCII,
                                      SIZE_TYPE_FLOAT_COD_ASCII,
                                      SIZE_TYPE_DOUBLE_COD_ASCII,
                                      SIZE_TYPE_UBYTE_32,
                                      SIZE_TYPE_UBYTE_220,
                                      SIZE_TYPE_ASCII_STRING,
                                      SIZE_TYPE_RATIONAL
                                    };
#else
   GLOBAL UINTx4       TIFSPV_size[N_TYPES];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSPV_StringTable

      $DESCRIPTION  Vector of TIFSPT_CodeTable

   $EH
   ========================================================================== */
   GLOBAL TIFSPT_CodeTable TIFSPV_StringTable[4096];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ---

      $DESCRIPTION  LZW Encode/Decode global variables

   $EH
   ========================================================================== */
   GLOBAL UINTx4      	   DecNInCar;
   GLOBAL UINTx4      	   DecNOutCar;
   GLOBAL UINTx4      	   EncNOutCar;
   GLOBAL UINTx4      	   NextTableEntry;
   GLOBAL UINTx1       	  *EncInCar;
   GLOBAL UINTx1          *DecOutCar;
   GLOBAL UINTx1          *EncOutCar;
   GLOBAL UINTx1          *DecInCar;
   GLOBAL UINTx4           CodeNumBit;
   GLOBAL UINTx4           FBitFree;
   GLOBAL UINTx4           FBitToMove;

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_disp_evaluate

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
		      img: image number

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Calcola a seconda del parametro DISPOSITION come disporre 
                      i blocchi su disco

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_disp_evaluate
			( /*IN    */ INTx4	    chan,
                          /*IN    */ INTx4          img,
			  /*   OUT*/ ERRSIT_status *status_code);

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPF_get_block

        $TYPE         FUNCTION

        $INPUT        chan: TIFF channel number
                      img: img number
                      block: block number

        $MODIFIED     NONE

        $OUTPUT       buf: pointer to buffer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Legge un blocco da un immagine

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 TIFSPF_get_block
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ INTx4                block,
                         /*   OUT*/ void                *buf,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPF_store_block

        $TYPE         FUNCTION

        $INPUT        chan: TIFF channel number
                      img: img number
                      block: block number
                      buf: pointer to buffer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Scrive un blocco in un immagine

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 TIFSPF_store_block
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ INTx4                block,
                         /*IN    */ void                *buf,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_ifd_reorder

        $TYPE         FUNCTION

        $INPUT        img: image number

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Riordinatore della ifd: tag riordinati in senso 
		      ascendente

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_ifd_reorder
                        (/*IN    */ INTx4                chan,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_check_tiff

        $TYPE         PROCEDURE

        $INPUT        chan: TIFF open channel

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Controlla che il file sia TIFF e si posiziona sulla 
                      prima IFD

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_check_tiff
			( /*IN    */ INTx4	          chan,
			  /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_find_chan

        $TYPE	      PROCEDURE

        $INPUT        namefile: TIFF open file name

        $MODIFIED     NONE

        $OUTPUT       chan: TIFF open channel

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Trova il canale relativo ad un file specificato dal nome 

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_find_chan
			( /*IN    */ char                *namefile,
                          /*   OUT*/ INTx4	         *chan,
			  /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPF_readandswap

        $TYPE         FUNCTION

        $INPUT        size: size of pointer
                      nitems: number of size pointer
		      stream: poiter to FILE

        $MODIFIED     NONE

        $OUTPUT       ptr: pointer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Same as fread

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 TIFSPF_readandswap 
                        ( /*   OUT*/ void          *ptr,
                          /*IN    */ INTx4          size,
                          /*IN    */ INTx4          nitems,
                          /*IN    */ FILE          *stream,
                          /*IN    */ char           swap_byte );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_LZWencode

        $TYPE	      PROCEDURE

        $INPUT        pibuff: pointer to input buffer
		      ibuffLen: length of input buffer

        $MODIFIED     NONE

        $OUTPUT       pobuff: pointer to output buffer
                      obuffLen: length of output buffer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  LZW encode procedure

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_LZWencode
                        ( /*IN    */ UINTx1        *pibuff, 
                          /*IN    */ UINTx4         ibuffLen, 
                          /*   OUT*/ UINTx1        *pobuff, 
                          /*   OUT*/ UINTx4        *obuffLen,
                          /*   OUT*/ ERRSIT_status *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_LZWdecode

        $TYPE	      PROCEDURE

        $INPUT        pibuff: pointer to input buffer
		      ibuffLen: length of input buffer

        $MODIFIED     NONE

        $OUTPUT       pobuff: pointer to output buffer
                      obuffLen: length of output buffer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  LZW decode procedure

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_LZWdecode
                        ( /*IN    */ UINTx1        *pibuff, 
                          /*IN    */ UINTx4         ibuffLen, 
                          /*   OUT*/ UINTx1        *pobuff, 
                          /*   OUT*/ UINTx4        *obuffLen,
                          /*   OUT*/ ERRSIT_status *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         TIFSPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE	    FUNCTION

      $INPUT        local_staus_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 TIFSPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_staus_code );


#ifdef __HAVEIDL__
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         TIFSPF_IDLI_CvtBTIFFtoIDL

      $TYPE         FUNCTION

      $INPUT        btiffpar: a TTIFF parameter structure
                    idlpar : the same parameter converted in IDL

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   1=error 0=OK

      $DESCRIPTION    This procedure convert a BTIFF parameter into a IDL variable.
		      The types allowed are:
		      BTIFF type            IDL type
		      SCALAR TYPE_BYTE      BYTE
		      SCALAR TYPE_UBYTE     INT
		      SCALAR TYPE_SHORT     INT
		      SCALAR TYPE_USHORT    LONG
		      SCALAR TYPE_INT       LONG
		      SCALAR TYPE_FLOAT     FLOAT
		      ARRAY  TYPE_ASCII     SCALAR STRING

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 TIFSPF_IDLI_CvtBTIFFtoIDL
                        (/*IN    */ TIFSIT_par           btiffpar,
                         /*IN OUT*/ IDL_VPTR             idlpar[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         TIFSPF_IDLI_CvtIDLtoBTIFF

      $TYPE         FUNCTION

      $INPUT        idlpar : the same parameter converted in IDL
		    btiffpar: a TTIFF parameter structure

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   1=error 0=OK

      $DESCRIPTION  This procedure convert a IDL variable into a TTIFF parameter.
		    The types allowed are:
		    BTIFF type            IDL type
		    SCALAR TYPE_BYTE      BYTE
		    SCALAR TYPE_UBYTE     INT
		    SCALAR TYPE_SHORT     INT
		    SCALAR TYPE_USHORT    LONG
		    SCALAR TYPE_INT       LONG
		    SCALAR TYPE_FLOAT     FLOAT
		    ARRAY  TYPE_ASCII     SCALAR STRING

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 TIFSPF_IDLI_CvtIDLtoBTIFF
                        (/*IN OUT*/ IDL_VPTR              idlpar[],
                         /*IN    */ TIFSIT_par           *btiffpar);

#endif /* __HAVEIDL__ */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         TIFSPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void TIFSPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) TIFSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_TEST_Strdivide2

        $TYPE         PROCEDURE

        $INPUT        line: a string containing one entire line of test to be divided into 2 parts

        $MODIFIED     NONE

        $OUTPUT	      par1: a string containing the 1st parameter 
		      par2: a string containing the 2nd parameter 

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Divide a string having the form "par1=par2" into the 2 
		      parameters, returned as strings

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_TEST_Strdivide2
                        (/*IN    */ char                *line,
                         /*   OUT*/ char                *par1,
                         /*   OUT*/ char                *par2,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_TEST_Strdivide3

        $TYPE         PROCEDURE

        $INPUT        line: a string containing one entire line of test to be 
		      divided into 3 parts

        $MODIFIED     NONE

        $OUTPUT	      par1: a string containing the 1st parameter 
		      par2: a string containing the 2nd parameter 
		      par3: a string containing the 3rd parameter 


        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Divide a string having the form "par1:par2,par3" into the
		      3 parameters, returned as strings

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_TEST_Strdivide3
                        (/*IN    */ char                *line,
                         /*   OUT*/ char                *par1,
                         /*   OUT*/ char                *par2,
                         /*   OUT*/ char                *par3,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_TEST_ReadTags

        $TYPE         PROCEDURE

        $INPUT        fp: the pointer to the dump file
 
        $MODIFIED     NONE

        $OUTPUT       tagnames[][REPLINELEN]: an array of strings containing the
		      names of the tags obtained from the dump file
		      tagnumbers[REPLINELEN]: an array of uns short containing
		      the equivalent tag numbers
		      tagvalues[][REPLINELEN]: an array of strings containing 
		      the values of the tags
		      nparfound: an uns int hich returns the number of founded
		      tags

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Extracts from the fump file the name, number and value of
		      the founded tags as 3 arrays; gives also the total number
		      of founded tags

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_TEST_ReadTags
                        (/*IN    */ FILE                *fp,
                         /*   OUT*/ char                tagnames[][REPLINELEN],
                         /*   OUT*/ UINTx2		tagnumbers[REPLINELEN],
                         /*   OUT*/ char		tagvalues[][REPLINELEN],
                         /*   OUT*/ UINTx4		*nparfound,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPF_TEST_FindTag

        $TYPE         PROCEDURE

        $INPUT        wantedtag: the tagnumber to find
		      tagnumbers: the array in which the search is performed
		      tagvalues: the array of strings containing all the tag 
		      values

        $MODIFIED     NONE

        $OUTPUT       wantedtagvalue: a string containing the found tag value

        $GLOBAL       NONE

        $RET_STATUS   1 if found, 0 otherwise

        $DESCRIPTION  Starting from a two arrays, containing all the tag numbers
		      and all the tag values, finds the value of a specified tag

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 TIFSPF_TEST_FindTag
                        (/*IN    */ UINTx2              wantedtag,
                         /*IN    */ UINTx2              *tagnumbers,
                         /*IN    */ char                tagvalues[][REPLINELEN],
                         /*   OUT*/ char		*wantedtagvalue,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_TEST_FillBpar

        $TYPE         PROCEDURE

        $INPUT        tagnumbers: the array in which the search is performed
		      tagvalues: the array of strings containing all the tag 
		      values

        $MODIFIED     NONE

        $OUTPUT       bpar: the structure containing the TIF basic parameters 
		      filled with the values directly obtained from the arrays
		      tagumbers and tagvalues

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  starting from the two arrays tagumbers and tagvalues, 
		      searchs into the basic parameters and fill the bpar
		      structure

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_TEST_FillBpar
                        (/*IN    */ UINTx2              *tagnumbers,
                         /*IN    */ char                tagvalues[][REPLINELEN],
                         /*   OUT*/ TIFSIT_basicpar     *bpar,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_TEST_RemoveSpaces

        $TYPE         PROCEDURE

        $INPUT        strwithspaces: a string with spaces

        $MODIFIED     NONE

        $OUTPUT       returns the input string but without spaces

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Eliminates from the input string, the spaces

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern char *TIFSPF_TEST_RemoveSpaces
                        (/*IN    */ char                *strwithspaces,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_TEST_GenConstImgline

        $TYPE         PROCEDURE

        $INPUT        maxval: the constant value of the image line (can be
		      negative)
		      linewidth: the number of pixels in the image line
		      sampleperpixel: the number of sample per pixel of the 
		      the image line
		      bitspersample: the number of bits per sample of the 
		      the image line
		      sampleformat: the sample format of the image line chosen
		      between 1=integer or 4=float

        $MODIFIED     NONE

        $OUTPUT       linebuffer: the buffer containing the generated image line

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Starting from the wanted image line parameters, generates
		      the pixel values all set to a constant value

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_TEST_GenConstImgline
                        (/*IN    */ float		maxval,
                         /*IN    */ UINTx4		linewidth,
                         /*IN    */ UINTx2		sampleperpixel,
                         /*IN    */ UINTx2		bitspersample,
                         /*IN    */ UINTx2		sampleformat,
                         /*IN    */ void		*linebuffer,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_TEST_GenRandomImgline

        $TYPE         PROCEDURE

        $INPUT        maxval: the maximum value of the random image line
		      (the minimum is equal to -maxval)
		      linewidth: the number of pixels in the image line
		      sampleperpixel: the number of sample per pixel of the 
		      the image line
		      bitspersample: the number of bits per sample of the 
		      the image line
		      sampleformat: the sample format of the image line chosen
		      between 1=integer or 4=float

        $MODIFIED     NONE

        $OUTPUT       linebuffer: the buffer containing the generated image line

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Starting from the wanted image line parameters, generates
		      the pixel values all set to a random value in 
		      [-maxval,maxval]

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_TEST_GenRandomImgline
                        (/*IN    */ float		maxval,
                         /*IN    */ UINTx4		linewidth,
                         /*IN    */ UINTx2		sampleperpixel,
                         /*IN    */ UINTx2		bitspersample,
                         /*IN    */ UINTx2		sampleformat,
                         /*IN    */ void		*linebuffer,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPF_TEST_CountUsertags

        $TYPE         FUNCTION

        $INPUT        tagnumbers: the array containing the tagnumbers

        $MODIFIED     NONE

        $OUTPUT       The number of tags which don't belongs to the basic tags

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Gives the number of tags which are not basic. A tag is
		      basic if its tagnumber is below the symbol FIRST_NONFUNDAMENTALTAG

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern UINTx2 TIFSPF_TEST_CountUsertags
                        (/*IN    */ UINTx2              *tagnumbers,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_TEST_FillTagVet

        $TYPE         FUNCTION

        $INPUT        file_name: the name of the file containing the tag names (.h)

        $MODIFIED     NONE

        $OUTPUT       tag_vet: an array of structures containing the tag names and numbers
                      tot_tag: the total number of founded tags

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Fills the structure containing the tag names and numbers
		      starting from the .h file containing the various #define 

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_TEST_FillTagVet
                        (/*IN    */ char                *filename,
                         /*   OUT*/ UINTx4              *tot_tag,
                         /*   OUT*/ TIFSIT_tag_elem     *tag_vet,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_TEST_GetTagName

        $TYPE         FUNCTION

        $INPUT        tag_vet: the array of structures containing the tag numbers and names
		      tot_tag: the size of the tag structure (quantity of tags)
		      tag_num: the searched tag number

        $MODIFIED     NONE

        $OUTPUT       tag_name: a string containing the name of the tag, searched by its number

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Obtain the tag name from the tag number searching in the tag array of structure

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSPP_TEST_GetTagName
                        (/*IN    */ TIFSIT_tag_elem     *tag_vet,
                         /*IN    */ UINTx2              tot_tag,
                         /*IN    */ UINTx2              tag_num,
                         /*   OUT*/ char                *tag_name,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( TIFSPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         TIFSIM_

      $DESCRIPTION  This procedure

                    TIFSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define TIFSPM_
*/
