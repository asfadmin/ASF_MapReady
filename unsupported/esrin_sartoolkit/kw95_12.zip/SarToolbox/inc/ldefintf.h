/* ==========================================================================
   $MODULE_HEADER

      $NAME              LDEF_INTF

      $FUNCTION          interface module.

      $ROUTINE           LDEFIP_LIST_insert_list_elem
                         LDEFIP_LIST_delete_list_elem
                         LDEFIP_TREE_append_unbtree
                         LDEFIF_TREE_search_minimum
                         LDEFIP_TREE_unbtree_to_btree
                         LDEFIF_UTIL_strnmatch
                         LDEFIP_UTIL_get_unique_id
                         LDEFIP_DATE_JDate 
                         LDEFIP_DATE_StrDate 
                         LDEFIP_DATE_DiffDate 
      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       04-OCT-95     DD       Initial Release
          SCR #1      26-NOV-97     AG       Macro ACOS implemented

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef LDEF
#define LDEF LDEF

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <string.h>
#include <math.h>

#include "libname.h"

#include ERRS_INTF_H

#ifdef LDEF_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

   $NAME         Boolean value

   $DESCRIPTION  Defines TRUE and FALSE

   $EH
   ========================================================================== */
#ifdef FALSE
#undef FALSE
#endif

#ifdef TRUE
#undef TRUE
#endif

#define TRUE           1
#define FALSE          0

/* ==========================================================================
   $DECLARATION_HEADER

   $NAME         TAB
                 CR
                 LF
                 FF
                 ESC
                 EOT
                 BELL
                 CLS

   $DESCRIPTION  Defines some useful ASCII char.

   $EH
   ========================================================================== */
#define TAB     0x09
#define CR      0x0D
#define LF      0x0A
#define FF      0x0C
#define ESC     0x1B
#define EOT     0x04
#define BELL    0x07
#define CLS "[2J[0;1H"

/* ==========================================================================
   $DECLARATION_HEADER

   $NAME         PI

   $DESCRIPTION  Defines the pi grec value.

   $EH
   ========================================================================== */
#ifdef PI
#undef PI
#endif
#define PI    ( (double) 3.141592653589793 )

/* ==========================================================================
   $DECLARATION_HEADER

   $NAME         DEGTORAD

   $DESCRIPTION  Defines the convertor factor from degrees to radians

   $EH
   ========================================================================== */
#ifdef DEGTORAD
#undef DEGTORAD
#endif
#define DEGTORAD    ( ( (double)3.141592653589793 ) / (double)180.0 )

/* ==========================================================================
   $DECLARATION_HEADER

   $NAME         RADTODEG

   $DESCRIPTION  Defines the convertor factor from radians to degrees

   $EH
   ========================================================================== */
#ifdef RADTODEG
#undef DEGTORAD
#endif
#define RADTODEG    ( ( (double)180. ) / (double)3.141592653589793 )

/* ==========================================================================
   $DECLARATION_HEADER

   $NAME         CVEL

   $DESCRIPTION  Defines the velocity of light in meter / seconds

   $EH
   ========================================================================== */
#define CVEL  ( (double) 2.99792896e+08 )

/* ==========================================================================
   $DECLARATION_HEADER

   $NAME         LDEFID_ann_kbytes

   $DESCRIPTION  Defines the size in Kbytes necessary to store the image
                 file annotations of internal TIFF files

   $EH
   ========================================================================== */
#define LDEFID_ann_kbytes ( (UINTx4) 200)

/* ==========================================================================
   $DECLARATION_HEADER

   $NAME         LDEFID_block_size

   $DESCRIPTION  Defines the number of bytes in a block

   $EH
   ========================================================================== */
#define LDEFID_block_size ( (UINTx2)512 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFID_char_num

      $DESCRIPTION  Default command line number of char

   $EH
   ========================================================================== */
#define LDEFID_char_num         256

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFID_dense_line

      $DESCRIPTION  Default text dense line number of char

   $EH
   ========================================================================== */
#define LDEFID_dense_line      132

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFID_char_line

      $DESCRIPTION  Default text line number of char

   $EH
   ========================================================================== */
#define LDEFID_char_line      80

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFID_byte_size

      $DESCRIPTION  Number of bits in a byte

   $EH
   ========================================================================== */
#define LDEFID_byte_size       8

/* ==========================================================================
   $DECLARATION_HEADER

   $NAME         LDEFID_at_last

   $DESCRIPTION  Defines the last position in a linked list.

   $EH
   ========================================================================== */
#define LDEFID_at_last -1

/* ==========================================================================
   $DECLARATION_HEADER

   $NAME         LDEFID_at_first

   $DESCRIPTION  Defines the first position in a linked list.

   $EH
   ========================================================================== */
#define LDEFID_at_first 0

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME             ABS
                        MAX
                        MIN
                        SIGN
                        CEIL                            : Return the near big
                                                          integer (INTx4)
                        ROUND				: Return the round
                                                          integer (INTx4)
                        isprint
                        strupr
			strlow
                        beep
                        STRLEN

      $DESCRIPTION      Defines some useful functions

   $EH
   ========================================================================== */
#ifdef ABS
#undef ABS
#endif
#define ABS( value ) (( value ) < 0 ? -( value ) : ( value ))

#ifndef MAX
#define MAX( value1, value2 ) (( value1 ) <= ( value2 ) ? ( value2 ):( value1 ))
#endif

#ifndef MIN
#define MIN( value1, value2 ) (( value1 ) >= ( value2 ) ? ( value2 ):( value1 ))
#endif

#define SIGN( value ) (( value ) >= 0  ?  1 : -1 )

#define CEIL( x ) \
((float)((INTx4)( x ))==(float)( x ) ? (INTx4)( x ) : (INTx4)(x+1))

#define ROUND( x ) (INTx4) ( (( x ) <= 0 ) ? (( x ) - 0.5 ) : (( x ) + 0.5 ) )

#ifdef __DOS__
#define SQRT( x ) ( (ABS(x)<0.00001) ? 0.0 : sqrt( x ) )
#else
#define SQRT( x ) ( sqrt( x ) )
#endif

#define beep printf( "%c", BELL )

#define STRLEN( str ) ( str == NULL ? 0 : strlen( str ) )

#define ACOS( x )  ( acos( MIN( 1.0, MAX( -1.0, x ) ) ) )

#undef strupr
#define strupr( str )                                                          \
{                                                                              \
   INTx4 i;                                                                    \
   for (i=0;i<STRLEN( str );i++) str[i] = toupper( str[i] );                   \
}

#undef strlow
#define strlow( str )                                                          \
{                                                                              \
   INTx4 i;                                                                    \
   for (i=0;i<STRLEN(str);i++) str[i] = tolower( str[i] );                     \
}

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIE_data_type

      $DESCRIPTION  It enumerates the possible data type that SAR Toolbox can
                    handle

   $EH
   ========================================================================== */
   enum LDEFIE_data_type {
      LDEFIE_dt_undef,		/* null value */
      LDEFIE_dt_UINTx1,         /* unsigned char */
      LDEFIE_dt_INTx2,          /* signed char */
      LDEFIE_dt_2_UINTx1,       /* two sample unsigned char */
      LDEFIE_dt_UINTx2,         /* unsigned short int */
      LDEFIE_dt_2_INTx2,        /* two sample signed short */
      LDEFIE_dt_UINTx4,         /* unsigned int */
      LDEFIE_dt_INTx4,          /* signed int */
      LDEFIE_dt_float,          /* float */
      LDEFIE_dt_2_float,        /* two sample float */
      LDEFIE_dt_double          /* double */
   };


/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIC_MonName

      $DESCRIPTION  The LDEFIC_MonName defines the names of the months so to
		    associate the month's number in the Year to its name

   $EH
   ========================================================================== */
#ifdef LDEF_GLBL
   GLOBAL const char LDEFIC_MonName[ 12 ][ 4 ] = {

/* ==========================================================================
   String with the months names
   ========================================================================== */
   "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT",
   "NOV", "DEC"
   };
#else
   GLOBAL const char LDEFIC_MonName[][ 4 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIC_inp_dir_val

      $DESCRIPTION  The LDEFIC_inp_dir_val is the value of the input dir
                    according to the target platform

   $EH
   ========================================================================== */
#ifdef LDEF_GLBL
#ifdef __VMS__
   GLOBAL const char LDEFIC_inp_dir_val[ 256 ] = "dat$:";
#endif
#ifdef __UNIX__
   GLOBAL const char LDEFIC_inp_dir_val[ 256 ] = "./";
#endif
#if defined __MC68K__ || defined __POWERPC__
   GLOBAL const char LDEFIC_inp_dir_val[ 256 ] = ":";
#endif
#if defined __WIN95__ || defined __DOS__
   GLOBAL const char LDEFIC_inp_dir_val[ 256 ] = ".\\";
#endif
#else
   GLOBAL const char LDEFIC_inp_dir_val[ 256 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIC_out_dir_val

      $DESCRIPTION  The LDEFIC_out_dir_val is the value of the output dir
                    according to the target platform

   $EH
   ========================================================================== */
#ifdef LDEF_GLBL
#ifdef __VMS__
   GLOBAL const char LDEFIC_out_dir_val[ 256 ] = "dat$:";
#endif
#ifdef __UNIX__
   GLOBAL const char LDEFIC_out_dir_val[ 256 ] = "./";
#endif
#if defined __MC68K__ || defined __POWERPC__
   GLOBAL const char LDEFIC_out_dir_val[ 256 ] = ":";
#endif
#if defined __WIN95__ || defined __DOS__
   GLOBAL const char LDEFIC_out_dir_val[ 256 ] = ".\\";
#endif
#else
   GLOBAL const char LDEFIC_out_dir_val[ 256 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIC_temp_dir_val

      $DESCRIPTION  The LDEFIC_temp_dir_val is the value of the temporary dir
                    according to the target platform

   $EH
   ========================================================================== */
#ifdef LDEF_GLBL
#ifdef __VMS__
   GLOBAL const char LDEFIC_temp_dir_val[ 256 ] = "dat$:";
#endif
#ifdef __UNIX__
   GLOBAL const char LDEFIC_temp_dir_val[ 256 ] = "./";
#endif
#if defined __MC68K__ || defined __POWERPC__
   GLOBAL const char LDEFIC_temp_dir_val[ 256 ] = ":";
#endif
#if defined __WIN95__ || defined __DOS__
   GLOBAL const char LDEFIC_temp_dir_val[ 256 ] = ".\\";
#endif
#else
   GLOBAL const char LDEFIC_temp_dir_val[ 256 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIC_cfg_dir_val

      $DESCRIPTION  The LDEFIC_cfg_dir_val is the value of the config dir
                    according to the target platform

   $EH
   ========================================================================== */
#ifdef LDEF_GLBL
#ifdef __VMS__
   GLOBAL const char LDEFIC_cfg_dir_val[ 256 ] = "dat$:";
#endif
#ifdef __UNIX__
   GLOBAL const char LDEFIC_cfg_dir_val[ 256 ] = "./";
#endif
#if defined __MC68K__ || defined __POWERPC__
   GLOBAL const char LDEFIC_cfg_dir_val[ 256 ] = ":";
#endif
#if defined __WIN95__ || defined __DOS__
   GLOBAL const char LDEFIC_cfg_dir_val[ 256 ] = ".\\";
#endif
#else
   GLOBAL const char LDEFIC_cfg_dir_val[ 256 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIC_delete_input_val

      $DESCRIPTION  The LDEFIC_delete_input_val is the value of the delete
                    input val

   $EH
   ========================================================================== */
#ifdef LDEF_GLBL
   GLOBAL const char LDEFIC_delete_input_val = 'N';
#else
   GLOBAL const char LDEFIC_delete_input_val;
#endif

/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIT_boolean

      $DESCRIPTION  This type defines the boolean value FALSE and TRUE.

   $EH
   ========================================================================== */
typedef char LDEFIT_boolean;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIT_func_point

      $DESCRIPTION  This type defines the pointer to a generic void function.

   $EH
   ========================================================================== */
   typedef void (*LDEFIT_func_point) ();

/* ==========================================================================

   $DECLARATION_HEADER

        $NAME         LDEFIT_tree_node

        $TYPE         Type

        $DESCRIPTION  Data struct containing the general tree node struct

        $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          left                             pointer to left tree
          right                            pointer to right tree
          key                              key used to create
                                           an oredered tree
          record                           pointer to record struct
   $EH
   ========================================================================== */
   struct LDEFIT_tree_node_def{ struct LDEFIT_tree_node_def *left;
                                struct LDEFIT_tree_node_def *right;
                                float                        key;
                                void                        *record;
                              };
   typedef struct LDEFIT_tree_node_def LDEFIT_tree_node;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIT_data_type 

      $DESCRIPTION  This type defines possible data type

   $EH
   ========================================================================== */
   typedef enum LDEFIE_data_type LDEFIT_data_type;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIV_tmp_id_name

      $DESCRIPTION  It contains the temporary file name prefix

   $EH
   ========================================================================== */
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_tmp_id_name[ 10 ] = "stb";
#else
   GLOBAL char LDEFIV_tmp_id_name[ 10 ];
#endif


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIV_tmp_ext_name

      $DESCRIPTION  It contains the temporary file name default extension

   $EH
   ========================================================================== */
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_tmp_ext_name[ 10 ] = "tmp";
#else
   GLOBAL char LDEFIV_tmp_ext_name[ 10 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIV_inp_dir

      $DESCRIPTION  It contains the directory name containing the input
                    files

   $EH
   ========================================================================== */
#ifdef __VMS__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_inp_dir[ 256 ] = "dat$:";
#else
   GLOBAL char LDEFIV_inp_dir[ 256 ];
#endif
#endif

#ifdef __UNIX__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_inp_dir[ 256 ] = "./";
#else
   GLOBAL char LDEFIV_inp_dir[ 256 ];
#endif
#endif

#if defined __MC68K__ || defined __POWERPC__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_inp_dir[ 256 ] = ":";
#else
   GLOBAL char LDEFIV_inp_dir[ 256 ];
#endif
#endif

#if defined __WIN95__ || defined __DOS__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_inp_dir[ 256 ] = ".\\";
#else
   GLOBAL char LDEFIV_inp_dir[ 256 ];
#endif
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIV_out_dir

      $DESCRIPTION  It contains the directory name containing the output
                    files

   $EH
   ========================================================================== */
#ifdef __VMS__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_out_dir[ 256 ] = "dat$:";
#else
   GLOBAL char LDEFIV_out_dir[ 256 ];
#endif
#endif

#ifdef __UNIX__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_out_dir[ 256 ] = "./";
#else
   GLOBAL char LDEFIV_out_dir[ 256 ];
#endif
#endif

#if defined __MC68K__ || __POWERPC__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_out_dir[ 256 ] = ":";
#else
   GLOBAL char LDEFIV_out_dir[ 256 ];
#endif
#endif

#if defined __WIN95__ || defined __DOS__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_out_dir[ 256 ] = ".\\";
#else
   GLOBAL char LDEFIV_out_dir[ 256 ];
#endif
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIV_temp_dir

      $DESCRIPTION  It contains the directory name containing the temporary
                    files

   $EH
   ========================================================================== */
#ifdef __VMS__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_temp_dir[ 256 ] = "dat$:";
#else
   GLOBAL char LDEFIV_temp_dir[ 256 ];
#endif
#endif

#ifdef __UNIX__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_temp_dir[ 256 ] = "./";
#else
   GLOBAL char LDEFIV_temp_dir[ 256 ];
#endif
#endif

#if defined __MC68K__ || __POWERPC__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_temp_dir[ 256 ] = ":";
#else
   GLOBAL char LDEFIV_temp_dir[ 256 ];
#endif
#endif

#if defined __WIN95__ || defined __DOS__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_temp_dir[ 256 ] = ".\\";
#else
   GLOBAL char LDEFIV_temp_dir[ 256 ];
#endif
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIV_cfg_dir

      $DESCRIPTION  It contains the directory name containing the input
                    files

   $EH
   ========================================================================== */
#ifdef __VMS__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_cfg_dir[ 256 ] = "dat$:";
#else
   GLOBAL char LDEFIV_cfg_dir[ 256 ];
#endif
#endif

#ifdef __UNIX__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_cfg_dir[ 256 ] = "./";
#else
   GLOBAL char LDEFIV_cfg_dir[ 256 ];
#endif
#endif

#if defined __MC68K__ || __POWERPC__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_cfg_dir[ 256 ] = ":";
#else
   GLOBAL char LDEFIV_cfg_dir[ 256 ];
#endif
#endif

#if defined __WIN95__ || defined __DOS__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_cfg_dir[ 256 ] = ".\\";
#else
   GLOBAL char LDEFIV_cfg_dir[ 256 ];
#endif
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIV_current_dir

      $DESCRIPTION  It contains the directory name containing the input
                    files

   $EH
   ========================================================================== */
#ifdef __VMS__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_current_dir[ 256 ] = "[]";
#else
   GLOBAL char LDEFIV_current_dir[ 256 ];
#endif
#endif

#ifdef __UNIX__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_current_dir[ 256 ] = "./";
#else
   GLOBAL char LDEFIV_current_dir[ 256 ];
#endif
#endif

#if defined __MC68K__ || __POWERPC__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_current_dir[ 256 ] = ":";
#else
   GLOBAL char LDEFIV_current_dir[ 256 ];
#endif
#endif

#if defined __WIN95__ || defined __DOS__
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_current_dir[ 256 ] = ".\\";
#else
   GLOBAL char LDEFIV_current_dir[ 256 ];
#endif
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIV_system_file

      $DESCRIPTION  It contains the file name containing the system
                    user settings

   $EH
   ========================================================================== */
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_system_file[ 256 ] = "system.ini";
#else
   GLOBAL char LDEFIV_system_file[ 256 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFIV_delete_input

      $DESCRIPTION  It contains the directory name containing the input
                    files

   $EH
   ========================================================================== */
#ifdef  LDEF_GLBL
   GLOBAL char LDEFIV_delete_input = 'N';
#else
   GLOBAL char LDEFIV_delete_input;
#endif

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_LIST_insert_list_elem

        $DESCRIPTION  Insert one element in the specified linked list at the
                      given position. LDEFID_at_last specify the last position.

        $TYPE         PROCEDURE

        $INPUT        list_elem        : pointer to the new element
                      position         : position in the list

        $MODIFIED     list_pointer     : pointer to the linked list

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void LDEFIP_LIST_insert_list_elem( /*IN    */ void   *list_elem,
                                             /*IN    */ INTx4   position,
                                             /*IN OUT*/ void  **list_pointer );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_LIST_delete_list_elem

        $DESCRIPTION  Delete one element in the specified linked list at the
                      given position. LDEFID_at_last specify the last position.

        $TYPE         PROCEDURE

        $INPUT        position         : position in the list

        $MODIFIED     list_pointer     : poineter to the linked list

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void LDEFIP_LIST_delete_list_elem( /*IN    */ INTx4   position,
                                             /*IN OUT*/ void  **list_pointer );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_TREE_append_unbtree

        $DESCRIPTION  Append a record to an unbalanced tree.
                      If the key of the node to add is less tha the current
                      node key, the new node is added on the left, on the right
                      otherwise.

        $TYPE         Procedure

        $INPUT        record     : pointer to the record struct
                      key        : key used to order the tree

        $MODIFIED     root_node  : pointer to the unbalanced root pointer

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_err_no_mem_allocated

        $WARNING      The input recored is used to constitude the node,
                      no copy is made.
                      Don't delete or free the input record.

        $PDL

   $EH
   ========================================================================== */
   extern void LDEFIP_TREE_append_unbtree
                        (/*IN    */ void             *record,
                         /*IN    */ float             key,
                         /*IN OUT*/ LDEFIT_tree_node *(*root_pointer),
                         /*   OUT*/ ERRSIT_status    *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIF_TREE_search_minimum

        $DESCRIPTION  This procedure scan a tree to search the node that
                      contain the key with minimum value.

        $TYPE         Function

        $INPUT        root_pointer : pointer to the unbtree root
                      element_no       : number of element that constitute the
                                         unbalanced tree.

        $MODIFIED     NONE

        $OUTPUT       Pointer to the added node, the root on the first call.

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      If the number of element in the unbalanced tree is
                      less than the input element_no value the process will
                      crash.

        $PDL

   $EH
   ========================================================================== */
   extern LDEFIT_tree_node **LDEFIF_TREE_search_minimum
                                 (/*IN   */ LDEFIT_tree_node *(*root_pointer) );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_TREE_unbtree_to_btree

        $DESCRIPTION  This routine create a balanced tree from an unbalanced
                      ordered tree.
                      The unbalanced tree is scanned to get the maximum element.
                      Note that the unbalanced tree must be ordered with
                      less key on the left and greather key on the right.
                      To create the ordered unbalanced tree the
                      LDEFIP_TREE_append_unbtree can be used.
                      There are not new created nodes for btree creation:
                      the unbalanced tree nodes are used.

        $TYPE         Procedure

        $INPUT        element_no       : number of element that constitute the
                                         unbalanced tree.

        $MODIFIED     unb_root_pointer : pointer to pointer to the unbtree root.
                                         At the return the pointer to the
                                         unbtree root will be NULL.

        $OUTPUT       added_node       : pointer to the Pointer to the added
                                         node, the root on the first call.

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      If the number of element in the unbalanced tree is
                      less than the input element_no value the process will
                      crash.

        $PDL

   $EH
   ========================================================================== */
   extern void LDEFIP_TREE_unbtree_to_btree
                              (/*IN OUT*/ LDEFIT_tree_node *(*unb_root_pointer),
                               /*IN    */ INTx4             element_no,
                               /*   OUT*/ LDEFIT_tree_node *(*added_node),
                               /*   OUT*/ ERRSIT_status    *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_TREE_delete_btree_node

        $DESCRIPTION  This procedure delete a node from a balanced
                      tree.

        $TYPE         Procedure

        $INPUT        root_pointer      : pointer to the pointer of the node
                                          to delete.
                                          This is the pointer to the left or
                                          right pointer of the node to delete;
                                          it isn't an external pointer.

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      root_pointer is the pointer to the left or right pointer
                      of the node to delete; it isn't an external pointer.

        $PDL

   $EH
   ========================================================================== */
   extern void LDEFIP_TREE_delete_btree_node
                     ( /*IN    */ LDEFIT_tree_node *(*root_pointer),
                       /*   OUT*/ ERRSIT_status    *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_TREE_destroy_tree

        $DESCRIPTION  Create the ers1 balanced tree with the frame info as node.

        $TYPE         Procedure

        $INPUT        root    : pointer to the pointer to the tree root

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void LDEFIP_TREE_destroy_tree
                           (/*IN    */ LDEFIT_tree_node *(*root),
                            /*   OUT*/ ERRSIT_status      *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEF_IDMP_tree_node

        $DESCRIPTION  Dump the LDEFIT_tree_node struct.

        $TYPE         Procedure

        $INPUT        var_string                : variable name
                      variable                  : Variable to dump
                      verbose                   : Verbose flag
                      ind                       : Indentation level

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void LDEFIP_IDMP_tree_node
                       ( /*IN    */ char               *var_string,
                         /*IN    */ LDEFIT_tree_node   *variable,
                         /*IN    */ LDEFIT_boolean      verbose,
                         /*IN    */ INTx4               ind );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_UTIL_strnmatch

        $TYPE         FUNCTION

        $INPUT        str1  : string to match with the other. Its number of
                              character must be lesser or equal then the
                              number of the second string
                      str2  : string in which to search the first

        $MODIFIED     NONE

        $OUTPUT       a status code that can be 0 = the string match
                                                1 = no match
                                              - 1 = memory allocation error
                                                    has occurred
                                              - 2 = the second string is lesser
                                                    then the first

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_LDEF_first_longer
                      ERRSID_LDEF_no_mem_allocated

        $DESCRIPTION  This function returns a flag indicating if the two string
                      match together

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern INTx1 LDEFIF_UTIL_strnmatch
                        (/*IN    */ char                *str1,
                         /*IN    */ char                *str2,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         LDEFIP_UTIL_get_unique_id

      $TYPE         PROCEDURE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       unique_id                 : unique id

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  Generates an unique id of 5 characters for the current
                    process.

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void LDEFIP_UTIL_get_unique_id
                        (/*   OUT*/ ERRSIT_unique_id  *unique_id,
                         /*   OUT*/ ERRSIT_status     *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         LDEFIP_UTIL_gen_tmp_name

      $TYPE         PROCEDURE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       tmp_name                  : unique file name

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  Generates an unique file name of the current process.

      $WARNING      tmp_name shall be allocated

   $EH
   ========================================================================== */
   extern void LDEFIP_UTIL_gen_tmp_name
                        (/*   OUT*/ char              *tmp_name,
                         /*   OUT*/ ERRSIT_status     *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_DATE_JDate

        $TYPE         void

        $INPUT        the date string to convert

        $MODIFIED     the value returning the julian date

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Computes the julian day from a the 01-jan-1950 in the 
                      format

                              DD-MON-YYYY hh:mm:ss.ddd

        $WARNING      The formal check for the date validity is not 
                      complete; check the string before submit to the 
                      routine;

        $PDL

   $EH
   ========================================================================== */
   extern void LDEFIP_DATE_JDate (/*IN    */ char *strData,
                        /*IN OUT*/ double *TotDays,
                       /*   OUT*/ ERRSIT_status     *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_DATE_StrDate

        $TYPE         void

        $INPUT        the julian date value

        $MODIFIED     the string containing the date

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Convert an julian day into a string with the format:

                              DD-MON-YYYY hh:mm:ss.ddd

        $WARNING      The pointer to output date string must refer to a
                      buffer with at least 24 character;

        $PDL

   $EH
   ========================================================================== */
   extern void LDEFIP_DATE_StrDate (/*IN    */ double *jDate,
                          /*IN OUT*/ char *strData,
                          /*   OUT*/ ERRSIT_status     *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_DATE_DiffDate

        $TYPE         void

        $INPUT        two date strings whose difference is to be computed

        $MODIFIED     the value returning the difference

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Computes the difference between two dates expressed
                      in the format

                              DD-MON-YYYY hh:mm:ss.ddd

        $WARNING      The formal check for the dates validity is not 
                      exaustive; check the strings before call the routine;

        $PDL

   $EH
   ========================================================================== */
   extern void LDEFIP_DATE_DiffDate (/*IN    */ char *strData0,
                          /*IN    */ char *strData1 ,
                        /*IN OUT*/ double *DiffDays,
                       /*   OUT*/ ERRSIT_status     *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_DATE_NextDate

        $TYPE         void

        $INPUT        the base date string
                      the date interval expressed in number of days

        $MODIFIED     the string containing the new date

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Computes the next date from a base after a specific
                      time

        $WARNING      The formal check for the dates validity is not 
                      exaustive; check the strings before call the routine;

        $PDL

   $EH
   ========================================================================== */
   extern void LDEFIP_DATE_NextDate (/*IN    */ char *strData0,
                           /*IN    */ double *DiffDays,
                           /*IN OUT*/ char *strData1 ,
                       /*   OUT*/ ERRSIT_status     *status_code );


/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFLM_abs
                    ( (*IN    *) x )

      $DESCRIPTION  Returns the abs of _x

   $EH   
   ========================================================================== */
#define LDEFLM_abs( _x ) ( (_x) > 0 ? (_x) : -(_x) )

/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_LDEF_no_mem_allocated     2
#define ERRSID_LDEF_first_longer         3
#define ERRSID_LDEF_uncomput_size_avail  4
#define ERRSID_LDEF_invalid_date         5

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */
#ifdef LDEF_GLBL
   GLOBAL char *LDEFIV_ERRS_error_message[] =
                        { "No error happens",                           /* 0 */
                          "Generic error happens",                      /* 1 */
			  "Error in memory allocation",                 /* 2 */
                          "The first string is longer then the second", /* 3 */
                          "Size quota cannot be computed",              /* 4 */
                          "Invalid Date String"                         /* 5 */
			};
#else
   GLOBAL char *LDEFIV_ERRS_error_message[];
#endif

#endif
