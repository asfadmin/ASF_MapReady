/* ==========================================================================
   $MODULE_HEADER

      $NAME          ERRS_PGLB

      $FUNCTION      Error handling global package

      $ROUTINE       

      $HISTORY

            SCR NO.      DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       21-SEP-92     DD       Initial Release

    $EH
   ========================================================================== */

/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */
#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern

/* ==========================================================================
                          INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include "libname.h"
#include ERRS_INTF_H

#ifdef  ERRS_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                         TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSPT_flag_struct

      $DESCRIPTION  This type handles the CSS global flag structure.

      $CONTENTS

           FIELD                            DESCRIPTION
         ----------------------------     ----------------------------------
         proc_id                          procedure name
         flag                             flag value

   $EH
   ========================================================================== */
   struct ERRSPT_flag_struct_def{ ERRSIT_proc_name proc_id;
                                  ERRSIT_flag      flag; };

   typedef struct ERRSPT_flag_struct_def ERRSPT_flag_struct;

/* ==========================================================================
                      VARIABLES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSPV_proc_err_log_fid

      $DESCRIPTION  Process error log file pointer.

   $EH
   ========================================================================== */
   GLOBAL FILE *ERRSPV_proc_err_log_fid;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSPV_global_flag

      $DESCRIPTION  This var handles the CSS global flag list pointer;

   $EH
   ========================================================================== */
   GLOBAL ERRSPT_flag_struct  *ERRSPV_global_flag;

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSPD_start_time

      $DESCRIPTION  Default start time

   $EH
   ========================================================================== */
#if defined(__MC68K__) || defined(__POWERPC__)
#define ERRSPD_start_time 1111111111
#else
#define ERRSPD_start_time 738293792
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSPD_proc_log_dir

      $DESCRIPTION  Default processor log directory

   $EH
   ========================================================================== */
#ifdef __VMS__
#define ERRSPD_proc_log_dir "log$:"
#else
#define ERRSPD_proc_log_dir "log"
#endif

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME             ERRSPF_GLBL_set_error;

      $FUNCTION         Return global error from the package error. On first
                        call the package message array is registered.

      $INPUT            local_staus_code    : local package status code.

      $MODIFIED         NONE

      $OUTPUT           Global status code.

      $GLOBAL           NONE

      $RET_STATUS       NONE

      $DESCRIPTION      Return global error from the package error. On first
                        call the package message array is registered.

      $WARNING          NONE


   ========================================================================== */
   extern INTx4 ERRSPF_GLBL_set_error
                      ( /*IN    */ ERRSIT_status  local_staus_code );

