/* ==========================================================================
   $MODULE_HEADER

      $NAME              ICAL_PGLB

      $FUNCTION          IMAGE CALIBRATION global module.

      $ROUTINE           ICALPP_COMP_info
                         ICALPP_COMP_lut_pass
                         ICALPP_COMP_load_pattern
                         ICALPP_COMP_adc_comp
                         ICALPP_COMP_adc_lut_row_index
                         ICALPP_COMP_adc_lut_row
                         ICALPP_GLUT_antenna_pattern
                         ICALPP_GLUT_range_spread_loss
                         ICALPP_GLUT_calib_const
                         ICALPP_GLUT_replica_power
                         ICALPP_GLUT_gamma_image

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       14-MAR-98     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include ICAL_INTF_H


#ifdef  ICAL_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ICALPD_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*#define ICALPD_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ICALPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum ICALPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ICALPC_

      $DESCRIPTION  The ICALPC_

   $EH
   ========================================================================== */
/*   const ICALPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ICALPT_pattern

      $DESCRIPTION  Basic type to contain the antenna pattern values

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          value                            value
          patt                             corresponding pattern

   $EH
   ========================================================================== */
   struct ICALPT_pattern_def { 
      float    value;
      float    patt;
   };

   typedef struct ICALPT_pattern_def ICALPT_pattern;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ICALPV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_info            

        $TYPE         PROCEDURE

        $INPUT        imanum     : number identifing the image annotation
                      TLRow      : the row image coordinate of the AoI
                      TLCol      : the column image coordinate of the AoI
                      nrow_inp   : number of rows of the AoI
                      ncol_inp   : number of columns of the AoI

        $MODIFIED     NONE

        $OUTPUT       look_angle      : array of look angle values
                      incidence_angle : array of incidence angle values
                      slant_range     : array of slant range values

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute the look angle, the incidence angle
                      and the slant range values at TLCol ... TLCol+ncol_inp

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ICALPP_COMP_info
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*   OUT*/ float              **look_angle,
                         /*   OUT*/ float              **incidence_angle,
                         /*   OUT*/ float              **slant_range,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_lut_pass

        $TYPE         PROCEDURE

        $INPUT        inp_io     : input image description
                      inp_ima_num
                                 : number identifing the input image annotations
                      TLRow      : the row image coordinate in the full
                                   reference frame of the image
                      TLCol      : the column image coordinate in the full
                                   reference frame of the image
                      nrow       : number of rows of the image
                      ncol       : number of columns of the image
                      out_io     : output image description
                      out_ima_scale
                                 : linear or dB scale
                      lut        : array of lut values
                      adc_lut_direction
                                 : apply or none ADC lut
                      adc_io     : adc lut description
                      adc_ima_num: adc lut annotation index

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute an output image as a LUT pass on the
                      input image

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ICALPP_COMP_lut_pass
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ IANNIT_ImageScale    out_ima_scale,
                         /*IN    */ double              *lut,
                         /*IN    */ ICALIT_lut_direct    adc_lut_direction,
                         /*IN    */ GIOSIT_io           *adc_io,
                         /*IN    */ UINTx1               adc_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================


   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_load_pattern

        $TYPE         PROCEDURE

        $INPUT        pattern_file
                                  : file containing the pattern values

        $MODIFIED     NONE

        $OUTPUT       pattern     : pattern vector
                      pattern_no  : number of element into the pattern vector

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine loads the pattern_file
                      into the pattern vector

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ICALPP_COMP_load_pattern
                        (/*IN    */ char                *pattern_file,
                         /*   OUT*/ ICALPT_pattern     **pattern,
                         /*   OUT*/ UINTx4              *pattern_no,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALLF_COMP_pattern

        $TYPE         FUNCTION

        $INPUT        value       : value to be interpolated
                      antenna_pattern
                                  : antenna pattern vector

        $MODIFIED     NONE

        $OUTPUT       NONE 

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute the interpolation of value into the
                      pattern vector and return 10^(V/10.0) 

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern double ICALLF_COMP_pattern
                        (/*IN    */ float                value,
                         /*IN    */ ICALPT_pattern      *pattern,
                         /*IN    */ UINTx4               pattern_no,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_adc_comp

        $TYPE         PROCEDURE

        $INPUT        inp_io     : input image description
                      inp_ima_num
                                 : number identifing the input image annotations
                      TLRow      : the row image coordinate in the full
                                   reference frame of the image
                      TLCol      : the column image coordinate in the full
                                   reference frame of the image
                      nrow       : number of rows of the image
                      ncol       : number of columns of the image
                      calib_const: calibration constant
                      adc_correct_lut
                                 : ADC Correction lut
                      adc_correct_lut_no
                                 : number of pattern in the adc_correct_lut
                      out_io     : output image description

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute the ADC LUT image 

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void ICALPP_COMP_adc_comp
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ float                calib_const,
                         /*IN    */ ICALPT_pattern      *adc_correct_lut,
                         /*IN    */ UINTx4               adc_correct_lut_no,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_adc_lut_row_index

        $TYPE         PROCEDURE

        $INPUT        start_col  : index of starting column
                      ncol       : number of columns of the image
                      adc_ima_num
                                 : number identifing the ADC image annotations
                      inp_ima_num
                                 : number identifing the input image annotations

        $MODIFIED     NONE

        $OUTPUT       adc_lut_row_index
                                 : computed ADC lut row index

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute the ADC lut row index used by
                      ICALPP_COMP_adc_lut_row

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void ICALPP_COMP_adc_lut_row_index
                        (/*IN    */ UINTx4               start_col,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ UINTx1               adc_ima_num,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ UINTx4              *adc_lut_row_index,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_COMP_adc_lut_row

        $TYPE         PROCEDURE

        $INPUT        row        : number of image row
                      ncol       : number of columns of the image
                      adc_lut_direction
                                 : apply or null ADC lut
                      adc_io     : ADC image description
                      adc_ima_num
                                 : number identifing the ADC image annotations
                      inp_ima_num
                                 : number identifing the input image annotations
                      adc_lut_row_index
                                 : index of ADC lut row


        $MODIFIED     NONE

        $OUTPUT       adc_lut    : computed ADC lut

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine compute extract the row from and ADC lut

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void ICALPP_COMP_adc_lut_row
                        (/*IN    */ UINTx4               row,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ ICALIT_lut_direct    adc_lut_direction,
                         /*IN    */ GIOSIT_io           *adc_io,
                         /*IN    */ UINTx1               adc_ima_num,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4              *adc_lut_row_index,
                         /*   OUT*/ double              *adc_lut,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_GLUT_antenna_pattern

        $TYPE         PROCEDURE

        $INPUT        look_angle  : vector of look angle values
                      look_angle_no
                                  : number of elements of look_angle vector
                      in_boresight_angle
                                  : user supplied boresight angle value
                      use_bore_angle
                                  : TRUE if in_boresight_angle has to override the
                                    related annotation
                      inp_ima_num      : annotation index in IANNIV_ImageAnnot
                      antenna_pattern_file
                                  : file containing the antenna pattern values
                      application_type
                                  : ICALIT_lut_direct enumerated value

        $MODIFIED     NONE

        $OUTPUT       antenna_pattern_lut
                                  : antenna pattern look-up table

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is used to generate the antenna pattern LUT

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ICALPP_GLUT_antenna_pattern
                        (/*IN    */ float               *look_angle,
                         /*IN    */ UINTx4               look_angle_no,
                         /*IN    */ float                in_boresight_angle,
                         /*IN    */ LDEFIT_boolean       use_bore_angle,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ char                *antenna_pattern_file,
                         /*IN    */ ICALIT_lut_direct    application_type,
                         /*   OUT*/ double              *antenna_pattern_lut,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_GLUT_range_spread_loss

        $TYPE         PROCEDURE

        $INPUT        slant_range : vector of slant range values
                      slant_range_no
                                  : number of elements of slant_range vector
                      in_ref_slant_range      
                                  : user slant range reference values
                      use_ref_sl  : TRUE if slant range reference values has
                                    to be used
                      inp_ima_num      : annotation index in IANNIV_ImageAnnot
                      application_type
                                  : ICALIT_lut_direct enumerated value

        $MODIFIED     NONE

        $OUTPUT       range_spread_loss_lut
                                  : range spreading looss look-up table

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is used to generate the range spreading
                      loss LUT

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ICALPP_GLUT_range_spread_loss
                        (/*IN    */ float               *slant_range,
                         /*IN    */ UINTx4               slant_range_no,
                         /*IN    */ float                in_ref_slant_range,
                         /*IN    */ LDEFIT_boolean       use_ref_sl,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ ICALIT_lut_direct    application_type,
                         /*   OUT*/ double              *range_spread_loss_lut,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_GLUT_calib_const

        $TYPE         PROCEDURE

        $INPUT        incid_angle : vector of incidence angle values
                      incid_angle_no
                                  : number of elements of incid_angle vector
                      ref_incid_angle
                                  : reference incidence angle
                      in_calib_const
                                  : user calibration constant value
                      use_calib_const
                                  : TRUE if user calibration constant value has
                                    to be used
                      inp_ima_num      : annotation index in IANNIV_ImageAnnot
                      application_type
                                  : ICALIT_lut_direct enumerated value

        $MODIFIED     NONE

        $OUTPUT       calib_const_lut
                                  : range spreading looss look-up table

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is used to generate the calibration
                      constant LUT

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ICALPP_GLUT_calib_const
                        (/*IN    */ float               *incid_angle,
                         /*IN    */ UINTx4               incid_angle_no,
                         /*IN    */ float                ref_incid_angle,
                         /*IN    */ float                in_calib_const,
                         /*IN    */ LDEFIT_boolean       use_calib_const,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ ICALIT_lut_direct    application_type,
                         /*   OUT*/ double              *calib_const_lut,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_GLUT_replica_power

        $TYPE         PROCEDURE

        $INPUT        ref_replica_power
                                  : reference replica power value
                      ref_chirp_average
                                  : reference chirp average density value
                      replica_power_lut_no
                                  : size of replica_power_lut vector
                      inp_ima_num      : annotation index in IANNIV_ImageAnnot
                      application_type
                                  : ICALIT_lut_direct enumerated value

        $MODIFIED     NONE

        $OUTPUT       replica_power_lut
                                  : range spreading looss look-up table

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is used to generate the replica power LUT

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ICALPP_GLUT_replica_power
                        (/*IN    */ float                ref_replica_power,
                         /*IN    */ float                ref_chirp_average,
                         /*IN    */ UINTx4               replica_power_lut_no,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ ICALIT_lut_direct    application_type,
                         /*   OUT*/ double              *replica_power_lut,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALPP_GLUT_gamma_image

        $TYPE         PROCEDURE

        $INPUT        incid_angle : vector of incidence angle values
                      incid_angle_no
                                  : number of elements of incid_angle vector
                      inp_ima_num : annotation index in IANNIV_ImageAnnot

        $MODIFIED     NONE

        $OUTPUT       gamma_image_lut
                                  : gamma image look-up table

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is used to generate the gamma image
                      direct LUT

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ICALPP_GLUT_gamma_image
                        (/*IN    */ float               *incid_angle,
                         /*IN    */ UINTx4               incid_angle_no,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ double              *gamma_image_lut,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ICALPP_

      $DESCRIPTION  

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/*   extern void ICALPP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ICALPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 ICALPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ICALPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void ICALPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) ICALIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( ICALPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ICALIM_

      $DESCRIPTION  This procedure

                    ICALIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define ICALPM_
*/
