/* ==========================================================================
   $MODULE_HEADER

      $NAME              IANN_INTF

      $FUNCTION          interface module.

      $ROUTINE           IANNIP_GETP_ImageAnnot
                         IANNIP_PUTP_ImageAnnot
			 IANNIP_PUTP_UpdateProcHistory
                         IANNIP_MPHP_GetAnnotations
                         IANNIP_MPHP_PutAnnotations
                         IANNIP_GETP_AnnotDump
                         IANNIP_MPHP_AnnotDump
                         IANNIP_GETP_DoppCentFreqEval

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       13-MAY-97     GRV       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef IANN
#define IANN IANN


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include TIFS_INTF_H
#include IANN_TAGS_H

#ifdef IANN_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ---

      $DESCRIPTION  Annotations limits

   $EH
   ========================================================================== */
#define IANNID_NSTVECMAX    14   /* maximum number of allowable state vectors */
#define IANNID_DOPP_COEF    4    /* maximum number of doppler polynomial coef */
#define IANNID_GRSRMAX	    4    /* maximum number of coefficients of the  */
                                 /* ground to slant range polynomial       */
#define IANNID_NIMAMAX	   20	 /* maximum number of images that can be */
                                 /* simultaneously open                  */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNID_<tool>_<task>

      $DESCRIPTION  They are flags indicating the tools that must act on TIFF
                    images

   $EH
   ========================================================================== */
#define IANNID_IANN        (UINTx1) 0    /* image annotations reading tool */
#define IANNID_IRES_OVER   (UINTx1) 1    /* image resampling */
#define IANNID_IRES_UNDR   (UINTx1) 2
#define IANNID_STAT_GLOB   (UINTx1) 3    /* image statistic tool */
#define IANNID_STAT_LOCA   (UINTx1) 4
#define IANNID_STAT_PCA    (UINTx1) 5
#define IANNID_EXTR_MDAN   (UINTx1) 6    /* image extraction tool */
#define IANNID_EXTR_HEAD   (UINTx1) 7
#define IANNID_EXTR_QLCK   (UINTx1) 8
#define IANNID_EXTR_PREV   (UINTx1) 9
#define IANNID_EXTR_CORT   (UINTx1) 10
#define IANNID_EXTR_FRES   (UINTx1) 11
#define IANNID_EXTR_SDA    (UINTx1) 12
#define IANNID_EXTR_NFOR   (UINTx1) 13
#define IANNID_CONV_AMPW   (UINTx1) 14   /* image convertion tool */
#define IANNID_CONV_PWAM   (UINTx1) 15
#define IANNID_CONV_CAMP   (UINTx1) 16
#define IANNID_CONV_PFLT   (UINTx1) 17
#define IANNID_CONV_GCVS   (UINTx1) 18
#define IANNID_CONV_TGEN   (UINTx1) 19
#define IANNID_CONV_BGEN   (UINTx1) 20
#define IANNID_CONV_DUMP   (UINTx1) 21
#define IANNID_CONV_RAST   (UINTx1) 22
#define IANNID_CONV_LIDB   (UINTx1) 23
#define IANNID_SPKF_SPKF   (UINTx1) 24   /* speckle filtering tool */
#define IANNID_IREG_IREG   (UINTx1) 25   /* coregistration tool */
#define IANNID_IREG_COHE   (UINTx1) 26
#define IANNID_ICAL_BSCA   (UINTx1) 27   /* calibration tool */
#define IANNID_ICAL_BADC   (UINTx1) 28
#define IANNID_ICAL_GAMM   (UINTx1) 29
#define IANNID_ICAL_SATC   (UINTx1) 30

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNID_histo_sect

      $DESCRIPTION  It defines the number of sections present in the product
                    history tag in the image annotations

   $EH
   ========================================================================== */
#define IANNID_histo_sect           20

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNID_sect_size

      $DESCRIPTION  It defines the size in characters of each section of the
                    product history tag

   $EH
   ========================================================================== */
#define IANNID_sect_size            100

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNID_ImageAnnotNumber

      $DESCRIPTION  It contains the number of image annotation of the structure
                    IANNIV_ImageAnnot

   $EH
   ========================================================================== */
#define IANNID_ImageAnnotNumber	    80

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNID_ImageAnnotMaxNumber

      $DESCRIPTION  It define the maximum number of image annotations
                    as:
		    IANNID_ImageAnnotNumber +      Number of member of the
						   IANNIT_ImageAnnotation_def
						   structure

		    (IANNID_DOPP_COEF-1)    +	   Coefficients of the doppler
						   frequency

		    6*(IANNID_NSTVECMAX-1) +       State vectors components
						   ( position + velocity )

                    (IANNID_GRSRMAX-1)             Coefficients of the ground to
						   slant polynomial

   $EH
   ========================================================================== */
#define IANNID_ImageAnnotMaxNumber ( IANNID_ImageAnnotNumber +                 \
   ( IANNID_DOPP_COEF - 1 ) + 6 * ( IANNID_NSTVECMAX - 1 ) +                   \
   ( IANNID_GRSRMAX - 1 ) )


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNID_ProjTypeNum

      $DESCRIPTION  Number of Projection Type

   $EH
   ========================================================================== */
#define IANNID_ProjTypeNum 4

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIE_proj_type

      $DESCRIPTION  It enumerate the possible Map projection type of the image

   $EH
   ========================================================================== */
   enum IANNIE_proj_type {
      IANNIE_proj_undef,          /* null value                  */
      IANNIE_proj_UTM,            /* UTM MAP Projection          */
      IANNIE_proj_UPS,            /* UPS MAP Projection          */
      IANNIE_proj_ground,         /* ground projected image      */
      IANNIE_proj_slant           /* slant range projected image */
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIE_prod_type

      $DESCRIPTION  It enumerate the possible product types

   $EH
   ========================================================================== */
   enum IANNIE_prod_type {
      IANNIE_prod_undef,
      IANNIE_prod_ERS1_RAW,
      IANNIE_prod_ERS1_SLC,
      IANNIE_prod_ERS1_SLCI,
      IANNIE_prod_ERS1_PRI,
      IANNIE_prod_ERS1_GEC,
      IANNIE_prod_ERS1_GTC,
      IANNIE_prod_ERS2_RAW,
      IANNIE_prod_ERS2_SLC,
      IANNIE_prod_ERS2_SLCI,
      IANNIE_prod_ERS2_PRI,
      IANNIE_prod_ERS2_GEC,
      IANNIE_prod_ERS2_GTC
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIE_ellips_type

      $DESCRIPTION  It enumerate the possible ellipsoid name

   $EH
   ========================================================================== */
   enum IANNIE_ellips_type {
      IANNIE_ell_undef,
      IANNIE_ell_GEM6,
      IANNIE_ell_WGS84,
      IANNIE_ell_International
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIE_pixel_type

      $DESCRIPTION  It enumerate the possible pixel types

   $EH
   ========================================================================== */
   enum IANNIE_pixel_type {
      IANNIE_pixt_undef,                    /* undefined pixel type */
      IANNIE_pixt_complex,                  /* complex image pixel */
      IANNIE_pixt_amplitude,                /* amplitude image pixel */
      IANNIE_pixt_power                     /* power image pixel */
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIE_proc_PAF

      $DESCRIPTION  It enumerate the possible PAF processing the image

   $EH
   ========================================================================== */
   enum IANNIE_proc_PAF {
      IANNIE_proc_undef,                    /* undefined PAF */
      IANNIE_proc_CPAF,                     /* Central - PAF */
      IANNIE_proc_DPAF,                     /* German - PAF */
      IANNIE_proc_UPAF,                     /* U. K. - PAF */
      IANNIE_proc_IPAF,                     /* Italian - PAF */
      IANNIE_proc_APAF,                     /* U.S.A. - PAF */
      IANNIE_proc_SPAF                      /* Singapore - PAF */
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIE_sproc_SW

      $DESCRIPTION  It enumerate the possible SWs' processing the images

   $EH
   ========================================================================== */
   enum IANNIE_sproc_SW {
      IANNIE_sproc_undef,     /* null element */
      IANNIE_sproc_VMP,       /* VMP software */
      IANNIE_sproc_ESAR,      /* ESAR software */
      IANNIE_sproc_Bangkok    /* Bangkok software */
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIE_ImageScale

      $DESCRIPTION  It enumerates the possible image scale

   $EH
   ========================================================================== */
   enum IANNIE_ImageScale {
      IANNIE_iscale_undef,    /* null element */
      IANNIE_iscale_linear,   /* linear image scale */
      IANNIE_iscale_db        /* db image scale */
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIE_Presentation

      $DESCRIPTION  It enumerates the possible image presentation

   $EH
   ========================================================================== */
   enum IANNIE_Presentation {
      IANNIE_pres_undef,     /* null element */
      IANNIE_pres_normal,    /* image rendered in radar mode */
      IANNIE_pres_geo        /* image rendered in geographic mode */
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIE_OrbitDirection

      $DESCRIPTION  It enumerates the possible image orbit direction

   $EH
   ========================================================================== */
   enum IANNIE_OrbitDirection {
      IANNIE_orbit_undef,         /* null element */
      IANNIE_orbit_ascend,        /* ascending orbit */
      IANNIE_orbit_descend        /* descending orbit */
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIE_AnnotState

      $DESCRIPTION  It enumerates the possible annotation state

   $EH
   ========================================================================== */
   enum IANNIE_AnnotState {
      IANNIE_state_undef,     /* null element */
      IANNIE_state_notfound,  /* tag not found */
      IANNIE_state_invalid,   /* tag invalid */
      IANNIE_state_ok         /* tag ok */
   };

/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIC_coorconv_necessary_tag

      $DESCRIPTION  The IANNIC_coorconv_necessary_tag contains the annotation
                    needed to execute coordinate convertion

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const UINTx4 IANNIC_coorconv_necessary_tag[ IANNID_ProjTypeNum ]
                                                    [ IANNID_ImageAnnotMaxNumber + 1 ] =
   { /* UTM */
     { 10, TOP_LEFT_EAST, TOP_LEFT_NORTH, UTM_FALSE_EAST, UTM_FALSE_NORTH,
           UTM_SCALE_FACTOR, UTM_CENTER_PROJ_LON, ELLIPSOID_SEMIMAJOR_AXIS,
           ELLIPSOID_SEMIMINOR_AXIS, PIXEL_SPACING, LINE_SPACING },
     /* UPS */
     { 9,  TOP_LEFT_EAST, TOP_LEFT_NORTH, UPS_SCALE_FACTOR, UPS_CENTER_PROJ_LAT,
           UPS_CENTER_PROJ_LON, ELLIPSOID_SEMIMAJOR_AXIS,
           ELLIPSOID_SEMIMINOR_AXIS, PIXEL_SPACING, LINE_SPACING },
     /* GROUND */
     { 32, SAMPLING_RATE, RADAR_WAVELEN, TIME_INTERVAL_DATA_POINT, NB_DATA_POINTS,
           X_SAT_1, X_SAT_2, Y_SAT_1, Y_SAT_2, Z_SAT_1, Z_SAT_2,
           VX_SAT_1, VX_SAT_2, VY_SAT_1, VY_SAT_2, VZ_SAT_1, VZ_SAT_2,
           PIXEL_SPACING, CENTRE_GEODETIC_LAT, CENTRE_GEODETIC_LON,
           ELLIPSOID_SEMIMAJOR_AXIS, ELLIPSOID_SEMIMINOR_AXIS, PROCESSOR_NAME,
           GR_SR_POL_DEGREE, GR_SR_COEFF_1, GR_SR_COEFF_2, GR_SR_COEFF_3,
           ZERO_DOPP_RANGE_FIRST_TIME, ZERO_DOPP_AZIM_FIRST_TIME,
           YEAR_DATA_POINT, MONTH_DATA_POINT, DAY_DATA_POINT, SECOND_OF_DAY },
     /* SLANT */
     { 27, PRF, RADAR_WAVELEN, TIME_INTERVAL_DATA_POINT, NB_DATA_POINTS,
           X_SAT_1, X_SAT_2, Y_SAT_1, Y_SAT_2, Z_SAT_1, Z_SAT_2,
           VX_SAT_1, VX_SAT_2, VY_SAT_1, VY_SAT_2, VZ_SAT_1, VZ_SAT_2,
           PIXEL_SPACING, CENTRE_GEODETIC_LAT, CENTRE_GEODETIC_LON,
           ELLIPSOID_SEMIMAJOR_AXIS, ELLIPSOID_SEMIMINOR_AXIS,
           ZERO_DOPP_RANGE_FIRST_TIME, ZERO_DOPP_AZIM_FIRST_TIME,
           YEAR_DATA_POINT, MONTH_DATA_POINT, DAY_DATA_POINT, SECOND_OF_DAY }
   };
#else
   GLOBAL const UINTx4 IANNIC_coorconv_necessary_tag[ IANNID_ProjTypeNum ]
                                                    [ IANNID_ImageAnnotMaxNumber + 1 ];
#endif

/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIT_proj

      $DESCRIPTION  It enumerates the possible Map Projection image types

   ========================================================================== */
   typedef enum IANNIE_proj_type IANNIT_proj;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIT_prod

      $DESCRIPTION  It enumerates the possible product types

   ========================================================================== */
   typedef enum IANNIE_prod_type IANNIT_prod;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIT_ellips

      $DESCRIPTION  It enumerates the possible ellipsoid types

   ========================================================================== */
   typedef enum IANNIE_ellips_type IANNIT_ellips;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIT_pixel_type

      $DESCRIPTION  It enumerates the possible ellipsoid types

   ========================================================================== */
   typedef enum IANNIE_pixel_type IANNIT_pixelt;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIT_proc_PAF

      $DESCRIPTION  It enumerates the possible PAF processing the image

   ========================================================================== */
   typedef enum IANNIE_proc_PAF IANNIT_proc_PAF;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIT_sproc_SW

      $DESCRIPTION  It enumerates the possible SWs' processing the image

   ========================================================================== */
   typedef enum IANNIE_sproc_SW IANNIT_sproc_SW;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIT_ImageScale

      $DESCRIPTION  It enumerates the possible image scale

   ========================================================================== */
   typedef enum IANNIE_ImageScale IANNIT_ImageScale;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIT_Presentation

      $DESCRIPTION  It enumerates the possible image rendering mode

   ========================================================================== */
   typedef enum IANNIE_Presentation IANNIT_Presentation;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIT_OrbitDirection

      $DESCRIPTION  It enumerates the possible orbit direction

   ========================================================================== */
   typedef enum IANNIE_OrbitDirection IANNIT_OrbitDirection;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIT_AnnotState

      $DESCRIPTION  It enumerates the possible annotation state

   ========================================================================== */
   typedef enum IANNIE_AnnotState IANNIT_AnnotState;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIT_ImageAnnot

      $DESCRIPTION  It contains the image annotation extracted from each image

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          ImageLength                        Number of image rows
          ImageWidth                         Number of image columns
          SamplePerPixel                     Sample per pixel
          BitsPerSample[NSAMPLEPERPIXELMAX]  Bits per sample
          SampleFormat[NSAMPLEPERPIXELMAX]   Data type
1         dataFormat                         ceos | mphsph
2         sourceId                           dep | itp | esp | ...
3         numberOfVolumes                    number of media volumes
4         ProductType                        Product name (LOG VOL ID)
5         SceneReferenceNumbers              Orbit and frame numbers
6         ProcessingPAF                      Name of the PAF that had produced
                                             the image
7         ProcessorName                      Name identifing the processor that
                                             generated the image
8         CalibrationConstant                Reference calibration of the image
9         IncidenceAngleAtMiddleRange_deg    Incidence angle at middle range
10        BoresightAngle_deg                 Boresight angle
11        TopLeftLat_deg                     Geodetic coordinates of the image
12        TopLeftLon_deg                     corners expressed in the reference
13        TopRightLat_deg 	             ellipsoid
14        TopRightLon_deg                                   "
15        BottomLeftLat_deg                                 "
16        BottomLeftLon_deg
17        BottomRightLat_deg
18        BottomRightLon_deg                                "
19        CentreGeodeticLat_deg 	     Geodetic coordinates of the centre
20        CentreGeodeticLon_deg              image point in the reference
                                             ellipsoid
21        TopZeroFilledLines 	             Borders pixels set to zero in the
                                             image
22        BottomZeroFilledLines                             "
23        LeftZeroFilledPixels                              "
24        RightZeroFilledPixels
25        MapProjectionType                  MAP Projection type
                                             (IANNIE_proj_type type)
26        ProjectionScaleFactor              Scale factor of the projection
                                             (UTM or UPS)
27        ProjectionCentralMeridian_deg      Geodetic longitude of the central
                                             meridian
28        ProjectionCentralParallel_deg      Geodetic latitude of the pole of
					     reference
                                             of the projection (UTM or UPS)
29        TopLeftEast_m                      UTM or UPS corners' coordinates
30        TopLeftNorth_m                                    "
31        FalseEast_m                        Coordinates of the center of
                                             the zone (false origin)
32        FalseNorth_m                                      "
33        LineSpacing_m                      Line spacing in azimuth direction
34        PixelSpacing_m                     Pixel spacing in range direction
35        FirstSTVectYear                    Year of the UTC date of the first
                                             image state vector annotated
36        FirstSTVectMonth                   Month of the UTC date of the first
                                             image state vector annotated
37        FirstSTVectDay                     Day in the year of the UTC
                                             date of the first image state
                                             vector annotated
38        FirstSTVectSeconds                 Seconds in the day of the UTC
                                             date of the first image state
                                             vector annotated
39        ZeroDopplerAzimuthFirstLine        Time of the first processed image
                                             line
40        ZeroDopplerAzimuthLastLine         Time of the last processed image
                                             line
41        RadarWaveLength_m                  Radar wavelength
42        SamplingRate_Hz                    Lines' sampling rate
43        RangeFirstTime_sec                 (2 way) time of the first range
                                             column acquired
44        PulseRepetitionFreq_Hz             Pulse repetition frequency
45        EquivalentPulseRepetitionFreq_Hz   Equivalent pulse repetition
  					     frequency evaluated by the number
					     of image lines and the last and
					     first times
46        DopplerFreqCoeff_Hz_sec[4]         Coefficients of the polynomial
                                             describing the
                                             doppler centroide frequency as
                                             function of azimuth
NOT USED
          EllipsoidType                      Type of the reference ellipsoid

47        SemiMajorAxis_m                    Reference ellipsoid semi-major axis
48        SemiMinorAxis_m                    Reference ellipsoid semi-minor axis
49        STVectIntervalTime                 Time interval between a couple of
                                             consequent State Vectors
50        NStateVectors                      Number of state vector points
51        X_STVec_m[IANNID_NSTVECMAX]        Cartesian coordinates of
52        Y_STVec_m[IANNID_NSTVECMAX]        satellite's positions and 
53        Z_STVec_m[IANNID_NSTVECMAX] 	     velocities in the Earth Fixed
54        VX_STVec_m_sec[IANNID_NSTVECMAX]   reference system defined by the
55        VY_STVec_m_sec[IANNID_NSTVECMAX]   ellipsoid and Greenwich position
56        VZ_STVec_m_sec[IANNID_NSTVECMAX]                               "
57        GroundToSlantDegree                Degree of the ground to slant
                                             range polynomial
58        GroundToSlantCoeff[IANNID_GRSRMAX] Coefficients of the ground to
                                             slant range polynomial
59        SubImageTopLeftRow		     Top left image coordinates in the
                                             reference system of the full frame
                                             image
60        SubImageTopLeftCol                 row and column directions in the
                                             reference system of the full frame
                                             image
61        PixelType                          Type of image pixel among the three
                                             possibility: - "AMPLITUDE"
                                                          - "POWER"
                                                          - "COMPLEX"
62        ScalingFactor                      A floating point number by which
					     the product has been rescaled. By
					     default is 1.
63        LooksNumber                        Nominal number of azimuth looks
64        ReferenceSlantRange_m              Reference slant range for the
                                             range spreading loss compensation
65        ProductReplicaPower                Power of the chirp replica
66        ChirpAverageDensity                Average density of the chirp
                                             replica
67        ProcessingHistory                  String that contains information
                                             about the processing steps of the
                                             product
68        AntennaPatternCorrectionFlag       Flag indicating if the antenna
                                             pattern correction has been applied
                                             or not to the product
69        RangeSpreadingLossCompensationFlag Flag indicating if the range
                                             spreading loss compensation has
                                             been applied
70        CalibrationConstantApplicationFlag Flag indicating if the constant
                                             calibration has been applied
71        ADCSaturationCompensationFlag      Flag indicating if the ADC
                                             saturation compensation has been
                                             applied
72        ReplicaPowerCompensationFlag       Flag indicating if the replica power
                                             compensation has been applied
73        MasterSceneReference               Scene reference numbers ( with
					     orbit and frame ) of the master
					     image in the output slaves of a
					     co-registration
74        XScalingFactor		     Scaling factor in the column
					     direction
75	  YScalingFactor		     Scaling factor in the row direction
76        ImageScale                         Scale (linear or db) of the image
77        RowTransient                       Number of Rows lost in filtering
78        ColTransient                       Number of Columns lost in filtering
79        Presentation                       Normal or Geographic presentation
80        OrbitDirection                     Ascending or Descending orbit

   $EH

   ========================================================================== */
   struct IANNIT_ImageAnnotation_def {

/* ==========================================================================
   Basic annotation section
   ========================================================================== */
      INTx4		ImageLength;                      /* u */
      INTx4		ImageWidth;                       /* u */
      INTx2		SamplePerPixel;                   /* u */
      INTx2		BitsPerSample[ NSAMPLEPERPIXELMAX ]; /* u */
      INTx1		SampleFormat[ NSAMPLEPERPIXELMAX ];  /* u */

/* ==========================================================================
   General info section
   ========================================================================== */
      IANNIT_prod      	ProductType;
      char              dataFormat[ 20 ];
      char              sourceId[ 20 ];
      INTx4             numberOfVolumes;
      char              SceneReferenceNumbers[ LDEFID_char_line ];
      IANNIT_proc_PAF   ProcessingPAF;
      IANNIT_sproc_SW   ProcessorName;

/* ==========================================================================
   Calibration section
   ========================================================================== */
      float		CalibrationConstant;
      float		IncidenceAngleAtMiddleRange_deg;
      float		BoresightAngle_deg;

/* ==========================================================================
   Corners coordinates section
   ========================================================================== */
      float		TopLeftLat_deg;
      float		TopLeftLon_deg;
      float		TopRightLat_deg;
      float		TopRightLon_deg;
      float		BottomLeftLat_deg;
      float		BottomLeftLon_deg;
      float		BottomRightLat_deg;
      float		BottomRightLon_deg;
      float		CentreGeodeticLat_deg;	    /* u */
      float		CentreGeodeticLon_deg;	    /* u */
      INTx4		TopZeroFilledLines;
      INTx4		BottomZeroFilledLines;
      INTx4		LeftZeroFilledPixels;
      INTx4		RightZeroFilledPixels;

/* ==========================================================================
   MAP Projection section
   ========================================================================== */
      IANNIT_proj	MapProjectionType;		 /* u */
      float		ProjectionScaleFactor;		 /* u */
      float		ProjectionCentralMeridian_deg;	 /* u */
      float		ProjectionCentralParallel_deg;	 /* u */
      float		TopLeftEast_m;			 /* u */
      float		TopLeftNorth_m;			 /* u */
      float		FalseEast_m;			 /* u */
      float		FalseNorth_m;			 /* u */

/* ==========================================================================
   Spacing section
   ========================================================================== */
      float		LineSpacing_m;			    /* u */
      float		PixelSpacing_m;                   /* u */

/* ==========================================================================
   Timing section
   ========================================================================== */
      INTx2		FirstSTVectYear;		 /* u */
      INTx2             FirstSTVectMonth;	         /* u */
      INTx2		FirstSTVectDay;			 /* u */
      float		FirstSTVectSeconds;		 /* u */
      char              ZeroDopplerAzimuthFirstLine_UTC[ LDEFID_char_line ];
/* u */
      char              ZeroDopplerAzimuthLastLine_UTC[ LDEFID_char_line ]; 
/* u */
      float		RadarWaveLength_m;		    /* u */
      float		SamplingRate_Hz;		    /* u */
      float		RangeFirstTime_sec;		    /* u */
      float		PulseRepetitionFreq_Hz;            /* u */
      float		EquivalentPulseRepetitionFreq_Hz;  /* u */
      float		DopplerFreqCoeff_Hz_sec [ 4 ];     /* u */

/* ==========================================================================
   Ellipsoid section
   ========================================================================== */
/*
      IANNIT_ellips	EllipsoidType;
*/
      float		SemiMajorAxis_m;		    /* u */
      float		SemiMinorAxis_m;		    /* u */

/* ==========================================================================
   State vectors section
   ========================================================================== */
      float             STVectIntervalTime_sec;		       /* u */
      INTx1		NStateVectors;			       /* u */
      double		X_STVec_m[ IANNID_NSTVECMAX ];	       /* u */
      double		Y_STVec_m[ IANNID_NSTVECMAX ];	       /* u */
      double		Z_STVec_m[ IANNID_NSTVECMAX ];	       /* u */
      double		VX_STVec_m_sec[ IANNID_NSTVECMAX ];    /* u */
      double		VY_STVec_m_sec[ IANNID_NSTVECMAX ];    /* u */
      double		VZ_STVec_m_sec[ IANNID_NSTVECMAX ];    /* u */

/* ==========================================================================
   Ground to slant section
   ========================================================================== */
      INTx1		GroundToSlantDegree;				 /* u */
      double		GroundToSlantCoeff[ IANNID_GRSRMAX ];		 /* u */

/* ==========================================================================
   Image processing INFO
   ========================================================================== */
      INTx4             SubImageTopLeftRow;                              /* u */
      INTx4             SubImageTopLeftCol;                              /* u */
      IANNIT_pixelt     PixelType;                                       /* u */
      float             ScalingFactor;
      float             LooksNumber;                                     /* u */
      float             ReferenceSlantRange_m;
      float             ProductReplicaPower;
      float             ChirpAverageDensity;
      char              ProcessingHistory[ IANNID_histo_sect*IANNID_sect_size ];
/* u */

/* ==========================================================================
   Flags about the applied processing corrections
   ========================================================================== */
      LDEFIT_boolean    AntennaPatternCorrectionFlag;
      LDEFIT_boolean    RangeSpreadingLossCompensationFlag;
      LDEFIT_boolean    CalibrationConstantApplicationFlag;
      LDEFIT_boolean    ADCSaturationCompensationFlag;
      LDEFIT_boolean    ReplicaPowerCompensationFlag;

/* ==========================================================================
   Co-registration INFO
   ========================================================================== */
      char              MasterSceneReference[ LDEFID_char_line ];

/* ==========================================================================
   Resampling factors
   ========================================================================== */
      float		XScalingFactor;                                  /* u */
      float		YScalingFactor;                                  /* u */

/* ==========================================================================
   ImageScale identifies if the image is linear or dB
   ========================================================================== */
      IANNIT_ImageScale ImageScale;                                      /* u */

/* ==========================================================================
   Transient offset from subimage when filtering
   ========================================================================== */
      INTx4             RowTransient;                                    /* u */
      INTx4             ColTransient;                                    /* u */
      IANNIT_Presentation
                        Presentation;                                    /* u */
      IANNIT_OrbitDirection
                        OrbitDirection;                                  /* u */

   };

   typedef struct IANNIT_ImageAnnotation_def IANNIT_ImageAnnot;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIV_ImageAnnot

      $DESCRIPTION  It contains the structure of IANNIT type containing the
                    image annotation of each image.

   $EH
   ========================================================================== */
   GLOBAL IANNIT_ImageAnnot IANNIV_ImageAnnot[ IANNID_NIMAMAX ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIV_NotFoundTags

      $DESCRIPTION  It contains the image annotation not found for each image.

   $EH
   ========================================================================== */
   GLOBAL UINTx4 IANNIV_NotFoundTags[ IANNID_NIMAMAX ]
                                    [ IANNID_ImageAnnotMaxNumber ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNIV_InvalidTags

      $DESCRIPTION  It contains for each image the image annotation not valid 

   $EH
   ========================================================================== */
   GLOBAL UINTx4 IANNIV_InvalidTags[ IANNID_NIMAMAX ]
                                   [ IANNID_ImageAnnotMaxNumber ];

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_GETP_ImageAnnot

        $TYPE         PROCEDURE

        $INPUT        chan	    : the open TIFF file channel from which the
                                      parameters must be read
                      img	    : the image number in the TIFF file
                      imanum	    : progressive number of the image (more
                                      than one images can be simultaneously
                                      handled)
                      tool_descr    : flag describing the tool that call the
                                      reading image annotation procedure
                      bpar	    : basic parameters of the input file

        $MODIFIED     NONE

        $OUTPUT       The global structure with the <imanum> image annotations
                      stored

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the image
                                                  annotations that must be
                                                  filled

        $RET_STATUS   ERRSID_IANN_not_allow_imanum
                      ERRSID_IANN_tag_not_found
                      ERRSID_IANN_tag_invalid

        $DESCRIPTION  This procedure fills the global structure
                      <IANNIV_ImageAnnot[i]> with the annotations read from the
                      Toolbox file of which <chan> and <img> refers

        $WARNING      NONE

        $PDL	      - Check if the basic parameters annotated in the structure
                        IANNIV_ImageAnnot[imanum] are in their range of validity
		      - Get all the other tags in the file, filling a vector of
                        not found parameters
		      - Fill a vector with the invalid parameters checking if
                        they're in their range of validity
                      - Check if some mandatory tag is not found
                      - Check if some mandatory tag is not valid

   $EH
   ========================================================================== */
   extern void IANNIP_GETP_ImageAnnot
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx1               tool_descr,
                         /*IN    */ TIFSIT_basicpar      bpar,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_PUTP_ImageAnnot

        $TYPE         PROCEDURE

        $INPUT        chan          : the open TIFF file channel in which the
                                      parameters must be stored
                      img           : the image number in the TIFF file
                      imanum        : progressive number of the image (more
                                      than one images can be simultaneously
                                      handled)

        $MODIFIED     NONE

        $OUTPUT       The tags of the image are stored

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the image
                                                  annotations that must be
                                                  stored

        $RET_STATUS   ERRSID_IANN_not_allow_imanum

        $DESCRIPTION  This procedure stores the tags annotated in the global
                      structure <IANNIV_ImageAnnot[imanum]> in the TIFF file
                      defined by the channel <chan>

        $WARNING      The TIFF file in which the tags must be stored must be
                      opened and initialised befor the procedure calling

        $PDL	      - Puts the tags from IANNIV_ImageAnnot[imanum] in the
                        corresponding tag file
   $EH
   ========================================================================== */
   extern void IANNIP_PUTP_ImageAnnot
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx1               imanum,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_PUTP_UpdateProcHistory

        $TYPE         PROCEDURE

        $INPUT        imanum      : progressive number of the image
                      taskname    : name of the task executing the update
		      usrstrng    : user string to append to the processing
                                    history current string

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum].ProcessingHistory

        $RET_STATUS   ERRSID_IANN_not_allow_imanum

        $DESCRIPTION  This procedure update the PROC_HISTORY tag

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void IANNIP_PUTP_UpdateProcHistory
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ char                *taskname,
			 /*IN    */ char                *usrstrng,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_MPHP_GetAnnotations

        $TYPE         PROCEDURE

        $INPUT        chan   : channel of the input TIFF file
                      img    : image ID in the input TIFF file
                      imanum : progressive number of the image
                      bpar          : basic parameters of the input file

        $MODIFIED     NONE

        $OUTPUT       The global structure with the <imanum> image annotations
                      stored

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the image
                                                  annotations that must be
                                                  filled

        $RET_STATUS   ERRSID_IANN_not_allow_imanum
                      ERRSID_LDEF_first_longer

        $DESCRIPTION  This procedure gets the MPH-SPHlike image annotations
                      from the input TIFF file and fill with them the image
                      annotations structure

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void IANNIP_MPHP_GetAnnotations
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ TIFSIT_basicpar      bpar,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_MPHP_PutAnnotations

        $TYPE         PROCEDURE

        $INPUT        chan   : channel of the output TIFF file
                      img    : image ID in the output TIFF file
                      imanum : progressive number of the image

        $MODIFIED     NONE

        $OUTPUT       The global structure with the <imanum> image annotations
                      stored

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the image
                                                  annotations that must be
                                                  filled

        $RET_STATUS   ERRSID_IANN_not_allow_imanum

        $DESCRIPTION  This procedure puts the image annotations read from an
                      MPH-SPH format file in an output TIFF file

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void IANNIP_MPHP_PutAnnotations
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx1               imanum,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_GETP_AnnotDump

        $TYPE         PROCEDURE

        $INPUT        imanum : ID number of the image
                      fpt    : output file pointer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure dumps the annotations stored in the
                      image annotations structure

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void IANNIP_GETP_AnnotDump
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ FILE                *fpt,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_GETP_CopyAnnot

        $TYPE         PROCEDURE

        $INPUT        inp_ima_num : ID number of the input image annotation
                      out_ima_num : ID number of the output image annotation

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot, IANNIV_NotFoundTags, IANNIV_InvalidTags

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure copy the annotations stored in the
                      image annotations structure

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void IANNIP_GETP_CopyAnnot
                        (/*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_MPHP_AnnotDump

        $TYPE         PROCEDURE

        $INPUT        imanum : ID number of the image
                      fpt    : output file pointer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure dumps the annotations stored in the
                      image annotations structure

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void IANNIP_MPHP_AnnotDump
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ FILE                *fpt,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_GETP_DoppCentFreqEval

        $TYPE         PROCEDURE

        $INPUT        imanum    : the number identified the image among all
                                  that treated in the tool
                      start_col : the actual starting column of the image in
                                  the full resolution image
                      stop_col  : the actual last column of the image in the
                                  full resolution image

        $MODIFIED     NONE

        $OUTPUT       fdc       : the array with the doppler centroid
                                  frequencies evaluated

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_IRES_imanum_not_allow
                      ERRSID_IRES_start_stop_col_err

        $DESCRIPTION  This procedure evaluates the doppler centroid frequencies
                      of the image numerated by <imanum> for the columns indices
                      starting with start_col and ending with stop_col

        $WARNING      The column indices passed in input are in the full
                      reference frame

   $EH
   ========================================================================== */
   extern void IANNIP_GETP_DoppCentFreqEval
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ INTx4                start_col,
                         /*IN    */ INTx4                stop_col,
                         /*   OUT*/ float               *fdc,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_GETP_AnnotState

        $TYPE         PROCEDURE

        $INPUT        imanum    : the number identified the image among all
                                  that treated in the tool
                      annotation: annotation number

        $MODIFIED     NONE

        $OUTPUT       state     : state of the annotation for that imanum

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_IRES_imanum_not_allow

        $DESCRIPTION  This procedure check inside IANNIV_ImageAnnot[imanum]
                      is the annotation is not found or is invalid 

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void IANNIP_GETP_AnnotState
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               annotation,
                         /*   OUT*/ IANNIT_AnnotState   *state,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IANNIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/*   extern void IANNIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IANNIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void IANNIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) IANNIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IANNIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    IANNIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define IANNIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_IANN_err_mem_alloc        2
#define ERRSID_IANN_tag_not_found        3
#define ERRSID_IANN_not_allow_imanum     4
#define ERRSID_IANN_proj_not_def         5
#define ERRSID_IANN_tag_type_not_known   6
#define ERRSID_IANN_tag_invalid          7
#define ERRSID_IANN_basic_tag_invalid    8
#define ERRSID_IANN_string_too_long      9
#define ERRSID_IANN_TEST_ERROR          10
#define ERRSID_IANN_invalid_date        11
#define ERRSID_IANN_imanum_not_allow    12
#define ERRSID_IANN_start_stop_col_err  13

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef IANN_GLBL
   GLOBAL char *IANNIV_ERRS_error_message[] = 
                        { "No error happens",                            /* 0 */
                          "Generic error happens",                       /* 1 */
                          "Memory allocation error",                     /* 2 */
                          "Necessary tag not found",                     /* 3 */
                          "Image number not allowable",                  /* 4 */
                          "Image projection not defined",                /* 5 */
                          "Tag type not known",                          /* 6 */
                          "The tag is not in the right range",           /* 7 */
                          "Invalid value for the basic tag number",      /* 8 */
			  "Processing History too long. It is cut",      /* 9 */
                          "TEST ERROR",                                 /* 10 */
                          "Invalid date string",                        /* 11 */
                          "Image ID out of range",                      /* 12 */
                          "Indipendent variable out of range",          /* 13 */
                        };
#else
   GLOBAL char *IANNIV_ERRS_error_message[];
#endif

#endif
