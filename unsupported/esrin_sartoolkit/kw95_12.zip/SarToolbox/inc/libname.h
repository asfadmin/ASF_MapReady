#ifndef LIBNAME
#define LIBNAME LIBNAME

/* ==========================================================================
   DEFINE INTERFACE MODULE LOGICAL NAMES FOR LOW LEVEL LIBRARIES
   ========================================================================== */
#define PORT_DEFS_H "portdefs.h"

#define ERRS_INTF_H "errsintf.h"
#define ERRS_PGLB_H "errspglb.h"

#define MEMS_INTF_H "memsintf.h"
#define MEMS_PGLB_H "memspglb.h"

#define LDEF_INTF_H "ldefintf.h"
#define LDEF_PGLB_H "ldefpglb.h"

#define MATH_INTF_H "mathintf.h"
#define MATH_PGLB_H "mathpglb.h"
#define MATH_NREC_H "mathnrec.h"

#define FILS_INTF_H "filsintf.h"
#define FILS_PGLB_H "filspglb.h"

#define BUFS_INTF_H "bufsintf.h"
#define BUFS_PGLB_H "bufspglb.h"

#define DEVS_INTF_H "devsintf.h"
#define DEVS_PGLB_H "devspglb.h"

#define FIIS_INTF_H "fiisintf.h"
#define FIIS_PGLB_H "fiispglb.h"

#define TIFS_INTF_H "tifsintf.h"
#define TIFS_PGLB_H "tifspglb.h"

#define GIOS_INTF_H "giosintf.h"
#define GIOS_PGLB_H "giospglb.h"

#define SRVS_INTF_H "srvsintf.h"
#define SRVS_PGLB_H "srvspglb.h"

#define COOR_INTF_H "coorintf.h"
#define COOR_PGLB_H "coorpglb.h"

#define STAT_INTF_H "statintf.h"
#define STAT_PGLB_H "statpglb.h"

#define CONV_INTF_H "convintf.h"
#define CONV_PGLB_H "convpglb.h"

#define SPKF_INTF_H "spkfintf.h"
#define SPKF_PGLB_H "spkfpglb.h"

#define IANN_INTF_H "iannintf.h"
#define IANN_PGLB_H "iannpglb.h"
#define IANN_TAGS_H "ianntags.h"

#define IRES_INTF_H "iresintf.h"
#define IRES_PGLB_H "irespglb.h"

#define PMDS_INTF_H "pmdsintf.h"
#define PMDS_PGLB_H "pmdspglb.h"

#define EXTR_INTF_H "extrintf.h"
#define EXTR_PGLB_H "extrpglb.h"

#define OVLS_INTF_H "ovlsintf.h"
#define OVLS_PGLB_H "ovlspglb.h"

#define TEST_INTF_H "testintf.h"
#define TEST_PGLB_H "testpglb.h"

#define IDLI_INTF_H "export.h"

#define CEOS_INTF_H "ceosintf.h"
#define CEOS_PGLB_H "ceospglb.h"

#define IREG_INTF_H "iregintf.h"
#define IREG_PGLB_H "iregpglb.h"

#define ICAL_INTF_H "icalintf.h"
#define ICAL_PGLB_H "icalpglb.h"

/* ==========================================================================
   DEFINE INTERFACE MODULE LOGICAL NAMES FOR MAIN PROCESSES
   ========================================================================== */
#define STBX_INTF_H "stbxintf.h"
#define STBX_PGLB_H "stbxpglb.h"
#define STBX_IDLI_H "stbxidli.h"

#endif
