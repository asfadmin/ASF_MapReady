/* ==========================================================================
   $MODULE_HEADER

      $NAME              MEMS_INTF

      $FUNCTION          Memory Management interface module.

      $ROUTINE           MEMSIP_dump
                         MEMSIP_alloc
			 MEMSIP_realloc
			 MEMSIP_free
			 MEMSIP_free_all
			 MEMSIP_size

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       04-FEB-97     AG       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef MEMS
#define MEMS MEMS


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"

#include ERRS_INTF_H

#ifdef MEMS_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MEMSID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define MEMSID_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MEMSIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum MEMSIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MEMSIC_

      $DESCRIPTION  The MEMSIC_

   $EH
   ========================================================================== */
/*   const MEMSIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MEMSIT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct MEMSIT_*_def { 

   typedef struct MEMSIT_*_def MEMSIT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MEMSIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_alloc

        $TYPE         FUNCTION

        $INPUT        size of pointer to be allocated

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine manages the allocation of buffer memory.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void *MEMSIP_alloc
                       ( /*IN    */ size_t	         size);

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_realloc

        $TYPE         FUNCTION

        $INPUT        pVoid     :   pointer to be reallocated
                      size	:   size of pointer to be reallocated

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine manages the reallocation of buffer memory.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void *MEMSIP_realloc     
                         ( /*IN    */ void              *pVoid, 
                           /*IN    */ size_t	         size );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_free

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine manages the deallocation of buffer memory.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void MEMSIP_free
                       ( /*IN    */ void               **pVoid);

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_free_all

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine manages the deallocation of buffer memory.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void MEMSIP_free_all ( );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_dump

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine print on stdout the actual status of memory.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void MEMSIP_dump   ( );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MEMSIP_size

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       size   : size in bytes of allocated memory

        $GLOBAL       MEMSPV_pointers

        $RET_STATUS   NONE

        $DESCRIPTION  This routine returns the amount of allocated
                      memory via MEMSIP_alloc.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MEMSIP_size         
                             ( /*   OUT*/ UINTx4	        *size );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MEMSIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

   $EH
   ========================================================================== */
/*   extern void MEMSIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MEMSIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void MEMSIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) MEMSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MEMSIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    MEMSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define MEMSIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif


/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef MEMS_GLBL
   GLOBAL char *MEMSIV_ERRS_error_message[] = 
                        { "No error happens",
                          "Generic error happens"
                        };
#else
   GLOBAL char *MEMSIV_ERRS_error_message[];
#endif


#endif
