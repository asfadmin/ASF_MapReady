/* ==========================================================================
   $MODULE_HEADER

      $NAME              STAT_INTF

      $FUNCTION          STATISTICAL TOOL interface module.

      $ROUTINE           STATIP_GLOB_stat
                         STATIP_LOCA_stat
			 STATIP_PCAN_pca   

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       29-JUL-97     AG       Initial Release
          SCR #4      26-NOV-97     AG       ERRSID_STAT_math_exception code 
                                             inserted
            N/A       23-MAR-97     AG       Add for Reqs B10/B18

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef STAT
#define STAT STAT


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include FILS_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H

#ifdef STAT_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STATID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define STATID_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STATIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
   enum STATIE_image_type {
      STATIE_image_mean,
      STATIE_image_sddv,
      STATIE_image_cfvr,
      STATIE_image_copy
   };

/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STATIC_

      $DESCRIPTION  The STATIC_

   $EH
   ========================================================================== */
/*   const STATIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STATIT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct STATIT_*_def { 

   typedef struct STATIT_*_def STATIT_*
*/
   typedef enum STATIE_image_type STATIT_image_type;
/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STATIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STATIP_GLOB_stat

      $TYPE	    PROCEDURE

      $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                    imanum    : number identifing the image inside the tool
                    TLRow     : the row image coordinate in the full
                                reference frame of the image
                    TLCol     : the column image coordinate in the full
                                reference frame of the image
                    nrow_inp  : number of rows of the image
                    ncol_inp  : number of columns of the images
		    vertex_no : number of the vertex of an AOI, if any 
                                (0, otherwise)
                    vertex    : array of vertex coordinates
		    class_min : minimun class value for the histogram
		    class_max : maximum class value for the histogram
		    class_no  : number of class between class_min - class_max
                    min       : min value
                    max       : max value
                    mean      : mean value
                    sddv      : standard deviation value
                    cfvr      : coeffiecient of variation
                    out_class : histogram of (class_no + 2) values
                    out_class_norm
                              : normalized histogram of (class_no + 2) values
                    out_class_limit
                              : histogram limits of (class_no + 2) values

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       IANNIV_ImageAnnot
                              : the structure with the image annotations

      $RET_STATUS   ERRSID_STAT_start_stop_coord_err
                    ERRSID_STAT_range_error
		    ERRSID_STAT_data_type_not_allow
		    ERRSID_STAT_err_mem_alloc

      $DESCRIPTION  This procedure executes the GLOBAL STATISTICS of an image
                    creating a report containg Mean, Standard Deviation,
                    Coefficient of Variation and Histogram values

      $WARNING      The input file shall be already opened.

      $PDL	    - Compute E[X], E[X^2], E[X^4] and C class vector
                      keeping in account the AOI (when defined) 
                    - Output Mean, Standard Deviation, Coefficient of Variation 
                      and Histogram values

   $EH
   ========================================================================== */
   extern void STATIP_GLOB_stat
                       ( /*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4               vertex_no,
			 /*IN    */ MATHIT_RC           *vertex,
			 /*IN    */ float                class_min,
			 /*IN    */ float                class_max,
                         /*IN    */ UINTx4               class_no,
                         /*   OUT*/ float               *min,
                         /*   OUT*/ float               *max,
			 /*   OUT*/ float               *mean, 
                         /*   OUT*/ float               *sddv, 
                         /*   OUT*/ float               *cfvr,
                         /*   OUT*/ UINTx4              *out_class,
                         /*   OUT*/ float               *out_class_norm,
                         /*   OUT*/ float               *out_class_limit,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STATIP_LOCA_stat

      $TYPE	    PROCEDURE

      $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                    imanum    : number identifing the image inside the tool
                    TLRow     : the row image coordinate in the full
                                reference frame of the image
                    TLCol     : the column image coordinate in the full
                                reference frame of the image
                    nrow_inp  : number of rows of the image
                    ncol_inp  : number of columns of the images
		    vertex_no : number of the vertex of an AOI, if any 
                                (0, otherwise)
                    vertex    : array of vertex coordinates
		    win_sizes : size of the window (row, col)
		    win_increments
		              : step size of the window (row, col)
	            fill_val  : value to be used to fill the image outside
			        the AOI
                    out_io    : structure with the IO basic parameters of the
                                output image
                    nrow_out  : number of rows of the output image block
                    ncol_out  : number of columns of the output image block
                    imageType : type of image to be produced(MEAN, SDDV 
                                or CFVR)

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   ERRSID_STAT_data_type_not_allow
                    ERRSID_STAT_err_mem_alloc

      $DESCRIPTION  This procedure executes the LOCAL STATISTICS of an image
                    creating as output one of MEAN, SDDV or CFVR statistic
                    image

      $WARNING      The input and the output files shall be already opened.

      $PDL          - Select core_func for kernel-image window convolution
                    - Select the data type of the input image
		    - Build kernel
		    - Call Overlap & Save windowing image method

   $EH
   ========================================================================== */
   extern void STATIP_LOCA_stat
                       ( /*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4               vertex_no,
			 /*IN    */ MATHIT_RC           *vertex,
			 /*IN    */ INTx4               *win_sizes,
			 /*IN    */ double              *win_increments,
                         /*IN    */ float                fill_val,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ STATIT_image_type    imageType,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STATIP_PCAN_pca

        $TYPE         PROCEDURE

	$INPUT	      inp1_io   : structure with the IO basic parameters of 
                                  the first input image
		      inp2_ior  : structure with the TIFF basic parameters of 
                                  the second input image
		      imanums1  : number identifing the first image in the tool
		      imanums2  : number identifing the second image in the tool
                      TLRow     : the row image coordinate in the full 
                                  reference frame of both images
                      TLCol     : the column image coordinate in the full 
                                  reference frame of both images
                      nrow_inp  : number of rows of both images
		      ncol_inp  : number of columns of both images
		      pca1_out_io
				: structure with the IO basic parameters of the
                                  first PCA image
		      pca2_out_io
				: structure with the IO basic parameters of the
                                  second PCA image
		      nrow_out  : number of rows of the output PCA images
		      ncol_out  : number of columns of the output PCA images

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot 
                                : the structure with the image annotations

        $RET_STATUS   ERRSID_STAT_start_stop_coord_err
                      ERRSID_STAT_data_type_not_allow
		      ERRSID_STAT_err_mem_alloc

        $DESCRIPTION  This procedure executes the PRINCIPAL COMPONENT ANALYSIS
		      of the two input images and creates the first and second
		      PCA images

        $WARNING      The input and the output files shall be already opened.

        $PDL	      - Compute E[X^2], E[Y^2], E[X*Y], E[X], E[Y]
		      - Evaluate the covariance matrix (G0,G1)
                      - Find Min((X,Y)*G0) and Min((X,Y)*G1)
		      - Write the PCA images (X,Y)*G0 - Min((X,Y)*G0) and
		        (X,Y)*G1 - Min((X,Y)*G1)

   $EH
   ========================================================================== */
   extern void STATIP_PCAN_pca   
                       ( /*IN    */ GIOSIT_io           *inp1_io,
                         /*IN    */ GIOSIT_io           *inp2_io,
                         /*IN    */ UINTx1               imanums1,
                         /*IN    */ UINTx1               imanums2,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ GIOSIT_io           *pca1_out_io,
                         /*IN    */ GIOSIT_io           *pca2_out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STATIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void STATIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) STATIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STATIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    STATIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define STATIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_STAT_err_mem_alloc        2
#define ERRSID_STAT_start_stop_coord_err 3
#define ERRSID_STAT_data_type_not_allow  4
#define ERRSID_STAT_range_error          5
#define ERRSID_STAT_kernel_dim_high      6
#define ERRSID_STAT_bad_steps            7
#define ERRSID_STAT_bad_write_size       8
#define ERRSID_STAT_imanum_not_allow     9
#define ERRSID_STAT_math_exception      10

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef STAT_GLBL
   GLOBAL char *STATIV_ERRS_error_message[] = 
                        { "No error happens",			    /* 0  */
                          "Generic error happens",		    /* 1  */
                          "SYSTEM ERROR: memory allocation error",  /* 2  */
			  "Invalid start/stop coordinates",         /* 3  */
			  "Data type not allowed",                  /* 4  */
			  "Error in class definition",              /* 5  */
			  "Kernel dimensions too high",             /* 6  */
			  "Bad window steps",                       /* 7  */
			  "Bad output size",                        /* 8  */
                          "Image annotation number not allowed",    /* 9  */
                          "Mathematical exception"                  /* 10 */
                        };
#else
   GLOBAL char *STATIV_ERRS_error_message[];
#endif


#endif
