/* ==========================================================================
   $MODULE_HEADER

      $NAME              COOR_PGLB

      $FUNCTION          global module.

      $ROUTINE           COORPP_CONV_EllipsoidInit
			 COORPP_CONV_SplineFirstDeriv
			 COORPP_FUNC_Newton_rc_xyz
			 COORPP_FUNC_Newton_xyz_rc
                         COORPP_CONV_en_rc
                         COORPP_CONV_llh_xyz
                         COORPP_CONV_xyz_llh
                         COORPP_CONV_llh_en
                         COORPP_CONV_en_llh
                         COORPP_CONV_Interpolator
                         COORPP_CONV_FirstDeriv

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       19-JUN-97     MC       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include COOR_INTF_H


#ifdef  COOR_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         COORPD_*

      $DESCRIPTION  Constants used for iterative computing

   $EH
   ========================================================================== */

/* ==========================================================================
   Max rounding extimated for the sum of angles in COORIP_2D_is_point_in_AoI   
   ========================================================================== */
#define COORID_AOIPRECISION  0.01

/* ==========================================================================
   Max number of iterations allowed for UTM conversions
   ========================================================================== */
#define COORID_UTMMAXITER    1000

/* ==========================================================================
    Min precision assumed for UTM conversions
   ========================================================================== */
#define COORID_UTMPRECISION  0.000000000001

/* ==========================================================================
   Max number of iterations allowed for UPS conversions
   ========================================================================== */
#define COORID_UPSMAXITER    1000

/* ==========================================================================
    Min precision assumed for UPS conversions
   ========================================================================== */
#define COORID_UPSPRECISION  0.000000000001

/* ==========================================================================
   Max number of iterations allowed for Newton functions
   ========================================================================== */
#define COORID_NEWTONMAXITER  20

/* ==========================================================================
   Max tolerance allowed for x variables in Newton functions   
   ========================================================================== */
#define COORID_NEWTONMAXTOLX  0.0001 

/* ==========================================================================
   Max tolerance allowed for functions in Newton functions
   ========================================================================== */
#define COORID_NEWTONMAXTOLF  0.0001

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         COORPD_Max_Vertex

      $DESCRIPTION  Limit the max number of vertex of an AoI 

   $EH
   ========================================================================== */
#define COORPD_Max_Vertex 50

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         COORPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum COORPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         COORPC_

      $DESCRIPTION  The COORPC_

   $EH
   ========================================================================== */
/*   const COORPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         COORPT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct COORPT_*_def { 

   typedef struct COORPT_*_def COORPT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         COORPV_ImgNum

      $DESCRIPTION  

   $EH
   ========================================================================== */
   GLOBAL INTx4 COORPV_ImgNum;

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_EllipsoidInit

        $TYPE	      PROCEDURE

        $INPUT        imanum  : number of the image among the other in the
				tool

        $MODIFIED     NONE

        $OUTPUT       NONE
 
        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
						  image annotations
		      COORIV_conv[imanum]	: the structure with all
						  the global variables that
						  the coordinates conversions
						  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow

        $DESCRIPTION  This procedure initializes the variables needed in the
		      coordinates conversions that are function of the
		      ellipsoid semiaxes

        $WARNING      

   $EH
   ========================================================================== */
   extern void COORPP_CONV_EllipsoidInit
			(/*IN    */ INTx4                imanum,
			 /*   OUT*/ ERRSIT_status	*status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_SplineFirstDeriv

        $TYPE         PROCEDURE

        $INPUT        x0      : current abscissa point in which to interpolate
		      n	      : number of abscissa and ordinates elements
		      x	      : array of abscissa
		      y	      : array of ordinates
		      y2      : array with the second derivatives coefficients
			        evaluated by the procedures of initialization of
				SPLINE

        $MODIFIED     NONE

        $OUTPUT       FirstD  : value of the first derivative of the polynomial
			        function evaluated at the point <x0>

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_value_out_of_abs
		      ERRSID_COOR_null_interval

        $DESCRIPTION  This procedure evaluates the first derivative of a generic
		      function evaluated with a spline interpolation

        $WARNING      NONE

        $PDL	      - Evaluate the class of the current abscissa value
		      - Evaluate some ancillary variables
		      - Evaluate the First Derivative

   $EH
   ========================================================================== */
   extern void COORPP_CONV_SplineFirstDeriv
			(/*IN    */ double               x0,
			 /*IN    */ INTx4                n,
			 /*IN    */ double              *x,
			 /*IN    */ double              *y,
			 /*IN    */ double              *y2,
			 /*   OUT*/ double              *FirstD,
			 /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_FUNC_Newton_rc_xyz

        $TYPE         PROCEDURE

        $INPUT        x	      : current point array

        $MODIFIED     alpha   : matrix with the values of the first derivatives 
			        of the three functions WRT the three variables
				in the current point <x>
		      beta    : array with the values of the functions ( with
			        the minus sign ) in the current point <x>

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need
                      COORPV_ImgNum		: number of the current image
						  among the other in the tool

        $RET_STATUS   ERRSID_COOR_null_dist_sp_target

        $DESCRIPTION  This procedure is ancillary to the coordinates conversion
		      procedure that transforms from image to cartesian
		      coordinates. It's used by the procedure MATH_ROOF_Newton
		      for the resolution of systems of non linear equations

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void COORPP_FUNC_Newton_rc_xyz
			(/*IN    */ double              *x,
                         /*IN OUT*/ double             **alpha,
                         /*IN OUT*/ double              *beta,
			 /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_FUNC_Newton_xyz_rc

        $TYPE         PROCEDURE

        $INPUT        x       : current point array

        $MODIFIED     alpha   : matrix with the values of the first derivatives
                                of the two functions WRT the two variables
                                in the current point <x>
		      beta    : array with the values of the functions ( with
                                the minus sign ) in the current point <x>

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need
                      COORPV_ImgNum             : number of the current image
                                                  among the other in the tool

        $RET_STATUS   ERRSID_COOR_null_dist_sp_target

        $DESCRIPTION  This procedure is ancillary to the coordinates conversion
                      procedure that transforms from cartesian to image
		      coordinates. It's used by the procedure MATH_ROOF_Newton
		      for the resolution of systems of non linear equations

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void COORPP_FUNC_Newton_xyz_rc
			(/*IN    */ double              *x,
                         /*IN OUT*/ double             **alpha,
                         /*IN OUT*/ double              *beta,
			 /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_en_rc

        $TYPE	      PROCEDURE

        $INPUT        EN_in   : input ( east, north ) UTM or UPS coordinates
			        in meters
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       RC_out  : output ( row, col ) coordinates in pixel

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
                                                  image annotations

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_bad_param_annot

        $DESCRIPTION  This procedure converts a point from East-North to
		      image coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
   extern void COORPP_CONV_en_rc
                        (/*IN    */ MATHIT_EN           *EN_in,
                         /*IN    */ INTx4                imanum,
                         /*   OUT*/ MATHIT_RC           *RC_out,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_llh_xyz

        $TYPE	      PROCEDURE

        $INPUT        LLH_in  : input ( lat, lon, h ) geodetic coordinates
			        in degree ( meters )
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       XYZ_out : output cartesian ( x, y, z ) coordinates in
			        meters

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow

        $DESCRIPTION  This procedure converts a point from geodetic to
		      cartesian coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
   extern void COORPP_CONV_llh_xyz
			(/*IN    */ MATHIT_LLH          *LLH_in,
			 /*IN    */ INTx4                imanum,
			 /*   OUT*/ MATHIT_XYZ          *XYZ_out,
		         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_xyz_llh

        $TYPE         PROCEDURE

        $INPUT        XYZ_in  : input cartesian ( x, y, z ) coordinates in
			        meters
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       LLH_out : output ( lat, lon, h ) geodetic coordinates
                                in degree ( meters )

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow

        $DESCRIPTION  This procedure converts a point from cartesian to
		      geodetic coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
   extern void COORPP_CONV_xyz_llh
                        (/*IN    */ MATHIT_XYZ          *XYZ_in,
			 /*IN    */ INTx4                imanum,
			 /*   OUT*/ MATHIT_LLH          *LLH_out,
			 /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_llh_en

        $TYPE         PROCEDURE

        $INPUT        LLH_in  : input ( lat, lon, h ) geodetic coordinates
                                in degree ( meters )
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       EN_out  : output ( east, north ) UTM or UPS coordinates
			        in meters

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_unhandled_projection

        $DESCRIPTION  This procedure converts a point from UTM or UPS to
		      geodetic coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
   extern void  COORPP_CONV_llh_en
		        (/*IN    */ MATHIT_LLH          *LLH_in,
			 /*IN    */ INTx4		 imanum,
			 /*   OUT*/ MATHIT_EN	        *EN_out,
			 /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_en_llh

        $TYPE	      PROCEDURE

        $INPUT        EN_in   : input ( east, north ) coordinates in meters
		      imanum  : image number among the others in the
                                program

        $MODIFIED     NONE

        $OUTPUT       LLH_out : output geodetic ( lat, lon, h ) coordinates
			        in degrees and meters

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need

        $RET_STATUS   ERRSID_COOR_imanum_not_allow
		      ERRSID_COOR_unhandled_projection

        $DESCRIPTION  This procedure converts a point from East-North to
		      geodetic coordinates

        $WARNING      The procedure COORIP_CONV_Init must be called once a time
                      before all the conversions procedures

   $EH
   ========================================================================== */
   extern void  COORPP_CONV_en_llh
			(/*IN    */ MATHIT_EN	        *EN_in,
			 /*IN    */ INTx4		 imanum,
			 /*   OUT*/ MATHIT_LLH		*LLH_out,
			 /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_Interpolator

        $TYPE	      PROCEDURE

        $INPUT        x_axis    : abscissa axis
                      y_axis    : ordinata axis
                      NElements : number of elements of the abscissa and
                                  ordinata values
                      x_curr    : abscissa value for which to evaluate the
                                  ordinata value
                      ancillary : array of ancillary objects. In the SPLINE
                                  interpolation they're the 2d derivative values

        $MODIFIED     NONE

        $OUTPUT       value     : ordinata value evaluated corresponding to the
                                  abscissa one
 
        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_few_elements
                      ERRSID_COOR_math_exception

        $DESCRIPTION  This procedure interpolates a value in correspondence of
                      an abscissa one given a set of abscissa values and the
                      corresponding ordinata values. If the current abscissa is
                      inside the abscissa range it's interpolated by SPLINE
                      interpolation else via linear extrapolation taking the two
                      nearest points.

        $WARNING      

        $PDL          - Checks the number of elements of the array
                      - If the current abscissa value is lower than the lowest
                        abscissa array values
                            - Evaluates the delta between the first two
                              abscissa values
                            - Evaluates the coefficients of the linear
                              interpolation
                            - Evaluates the extrapolated value
                      - Else If the current abscissa value is greather than the
                        greatest abscissa array values
                            - Evaluates the delta between the last two abscissa
                              values
                            - Evaluates the coefficients of the linear
                              interpolation
                            - Evaluates the extrapolated value
                      - Else
                            - Makes the spline interpolation
                      - End Else

   $EH
   ========================================================================== */
   extern void COORPP_CONV_Interpolator
			(/*IN    */ double              *x_axis,
                         /*IN    */ double              *y_axis,
                         /*IN    */ INTx4                NElements,
                         /*IN    */ double               x_curr,
                         /*IN    */ double              *ancillary,
			 /*   OUT*/ double              *value,
			 /*   OUT*/ ERRSIT_status	*status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_CONV_FirstDeriv

        $TYPE	      PROCEDURE

        $INPUT        x0      : current abscissa point in which to interpolate
                      n       : number of abscissa and ordinates elements
                      x       : array of abscissa
                      y       : array of ordinates
                      y2      : array with the second derivatives coefficients
                                evaluated by the procedures of initialization of
                                SPLINE if they're necessary

        $MODIFIED     NONE

        $OUTPUT       FirstD  : value of the first derivative of the polynomial
                                function evaluated at the point <x0>
 
        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_few_elements
                      ERRSID_COOR_math_exception

        $DESCRIPTION  This procedure evaluates the first derivative of a generic
                      function evaluated with a spline interpolation. If the
                      point in which the derivative must been evaluated is out
                      the abscissa range, the first derivative evaluated is that
                      of a linear interpolation between the nearest points

        $WARNING      NONE

        $PDL          - Checks the number of elements
                      - If the abscissa value is lesser then the lowest abscissa
                        value
                            - Evaluates the delta between the first two abscissa
                              values
                            - Evaluates the first derivative
                      - Else If the abscissa value is greather then the greatest
                        abscissa value
                            - Evaluates the delta between the last two abscissa
                              values
                            - Evaluates the first derivative
                      - Else
                            - Calls the function to evaluate the first
                              derivative of a SPLINE interpolated function
                      - End If

   $EH
   ========================================================================== */
   extern void COORPP_CONV_FirstDeriv
			(/*IN    */ double               x0,
                         /*IN    */ INTx4                n,
                         /*IN    */ double              *x,
                         /*IN    */ double              *y,
                         /*IN    */ double              *y2,
			 /*   OUT*/ double              *FirstD,
			 /*   OUT*/ ERRSIT_status	*status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         COORPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 COORPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         COORPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void COORPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) COORIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( COORPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         COORIM_

      $DESCRIPTION  This procedure

                    COORIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define COORPM_
*/
