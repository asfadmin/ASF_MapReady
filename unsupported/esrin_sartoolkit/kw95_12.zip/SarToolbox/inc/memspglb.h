/* ==========================================================================
   $MODULE_HEADER

      $NAME              MEMS_PGLB

      $FUNCTION          global module.

      $ROUTINE           MEMSPP_

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       04-FEB-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"

#include ERRS_INTF_H
#include MEMS_INTF_H


#ifdef  MEMS_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MEMSPD_max_pointers

      $DESCRIPTION  

   $EH
   ========================================================================== */
#define MEMSPD_max_pointers 10000

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MEMSPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum MEMSPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MEMSPC_

      $DESCRIPTION  The MEMSPC_

   $EH
   ========================================================================== */
/*   const MEMSPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MEMSPT_pointer

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          routine                          Contains the name of the routine 
                                           which has allocated the memory
	  pointer		           Contain the allocated pointer
          memsiz                           Number of allocated bytes
	  next				   Next pointer allocated
   $EH
   ========================================================================== */
   struct MEMSPT_pointer_def { 
      char                          *routine;
      void                          *pointer;
      size_t                         memsiz;
      struct MEMSPT_pointer_def	    *next;
   };
   typedef struct MEMSPT_pointer_def MEMSPT_pointer;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MEMSPV_pointers

      $DESCRIPTION  Linked list of pointer to void containing all the memory
		    allocated with MEMSIP_alloc

   $EH
   ========================================================================== */
#ifdef MEMS_GLBL
   GLOBAL MEMSPT_pointer *MEMSPV_pointers = (MEMSPT_pointer *) NULL;
#else
   GLOBAL MEMSPT_pointer *MEMSPV_pointers;
#endif

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MEMSPP_

      $DESCRIPTION  

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/*   extern void MEMSPP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MEMSPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 MEMSPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MEMSPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void MEMSPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) MEMSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( MEMSPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MEMSIM_

      $DESCRIPTION  This procedure

                    MEMSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define MEMSPM_
*/
