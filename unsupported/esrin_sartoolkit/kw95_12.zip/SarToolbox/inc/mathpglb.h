/* ==========================================================================
   $MODULE_HEADER

      $NAME              MATH_PGLB

      $FUNCTION          global module.

      $ROUTINE           MATHIP_INTR_Bilinear
                         MATHPP_INTR_BLUINTx1
                         MATHPP_INTR_BLUINTx2
                         MATHPP_INTR_BLfloat
                         MATHPP_INTR_BL2INTx2
                         MATHPP_INTR_BL2float
                         MATHPP_INTR_CCUINTx1
                         MATHPP_INTR_CCUINTx2
                         MATHPP_INTR_CCfloat
                         MATHPP_INTR_CC2INTx2
                         MATHPP_INTR_CC2float
                         MATHPF_INTR_CubiConvKernel
                         MATHPP_INTR_SincAzimuth
                         MATHPP_INTR_SincRange
                         MATHPP_INTR_SNUINTx1
                         MATHPP_INTR_SNUINTx2
                         MATHPP_INTR_SNfloat
                         MATHPP_INTR_SN2INTx2
                         MATHPP_INTR_SN2float
                         MATHPP_INTR_FillArray
                         MATHPP_INTR_FillImage
                         MATHPP_INTR_ImageRowConstShift
                         MATHPP_INTR_ImageColConstShift
                         MATHPP_INTR_FillRowArray
                         MATHPP_INTR_FillColArray
                         MATHPP_INTR_FillImaRow
                         MATHPP_INTR_FillImaCol

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       15-APR-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"
#include MATH_NREC_H

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H


#ifdef  MATH_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHPD_fftnlen

      $DESCRIPTION  Defines the minimum recommended number of elements that 
                    a signal must have to optimize it's FFT evaluation

   $EH
   ========================================================================== */
#define MATHPD_fftnlen ( (INTx4)(40))

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHPD_sinc_prec

      $DESCRIPTION  It defines the inverse of the minimum precision required
                    in the sinc interpolation ( default value )

   $EH
   ========================================================================== */
#define MATHPD_sinc_prec      1000
 
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum MATHPE_
*/

/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHPT_interp_func

      $DESCRIPTION  This type defines the prototype of the core functions for
                    the cubic convolution interpolation

   $EH
   ========================================================================== */
   typedef void (*MATHPT_interp_func)
         ( void **, UINTx4, UINTx4, MATHIT_RC_float **, UINTx4, UINTx4, float,
           void **, ERRSIT_status * );

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHPT_interp_sfunc

      $DESCRIPTION  This type defines the prototype of the core functions for
                    the sinc interpolation

   $EH
   ========================================================================== */
   typedef void (*MATHPT_interp_sfunc)
         ( UINTx1, void **, UINTx4, UINTx4, MATHIT_RC_float **, UINTx4, UINTx4,
           float, void **, ERRSIT_status * );

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHPV_CubiConvTable

      $DESCRIPTION  It contains the tabulated values for the cubic
                    convolution

   $EH
   ========================================================================== */
#ifdef MATH_GLBL
   GLOBAL float **MATHPV_CubiConvTable = (float **)NULL;
#else
   GLOBAL float **MATHPV_CubiConvTable;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHPV_SincRowTable
                    MATHPV_SincColTable

      $DESCRIPTION  They contain the matrices of tabulated values for the sinc
                    interpolation

   $EH
   ========================================================================== */
#ifdef MATH_GLBL
   GLOBAL float          ***MATHPV_SincRowTable = (float ***)NULL;
   GLOBAL MATHIT_complex ***MATHPV_SincColTable = (MATHIT_complex ***)NULL;
#else
   GLOBAL float          ***MATHPV_SincRowTable;
   GLOBAL MATHIT_complex ***MATHPV_SincColTable;
#endif

/* ==========================================================================
                  IMPORTED ROUTINES DECLARATION SECTION
   ========================================================================== */


/* f2c.h  --  Standard Fortran to C header file */

/**  barf  [ba:rf]  2.  "He suggested using FORTRAN, and everybody barfed."

	- From The Shogakukan DICTIONARY OF NEW ENGLISH (Second edition) */

#ifndef F2C_INCLUDE
#define F2C_INCLUDE

typedef INTx8 integer;
typedef char *address;
typedef INTx2 shortint;
typedef float real;
typedef double doublereal;
typedef struct { real r, i; } complex;
typedef struct { doublereal r, i; } doublecomplex;
typedef INTx8 logical;
typedef INTx2 shortlogical;
typedef char logical1;
typedef char integer1;
/* typedef long long longint; */ /* system-dependent */

#define TRUE_ (1)
#define FALSE_ (0)

/* Extern is for use with -E */
#ifndef Extern
#define Extern extern
#endif

/* I/O stuff */

#ifdef f2c_i2
/* for -i2 */
typedef INTx2 flag;
typedef INTx2 ftnlen;
typedef INTx2 ftnint;
#else
typedef INTx8 flag;
typedef INTx8 ftnlen;
typedef INTx8 ftnint;
#endif

/*external read, write*/
typedef struct
{	flag cierr;
	ftnint ciunit;
	flag ciend;
	char *cifmt;
	ftnint cirec;
} cilist;

/*internal read, write*/
typedef struct
{	flag icierr;
	char *iciunit;
	flag iciend;
	char *icifmt;
	ftnint icirlen;
	ftnint icirnum;
} icilist;

/*open*/
typedef struct
{	flag oerr;
	ftnint ounit;
	char *ofnm;
	ftnlen ofnmlen;
	char *osta;
	char *oacc;
	char *ofm;
	ftnint orl;
	char *oblnk;
} olist;

/*close*/
typedef struct
{	flag cerr;
	ftnint cunit;
	char *csta;
} cllist;

/*rewind, backspace, endfile*/
typedef struct
{	flag aerr;
	ftnint aunit;
} alist;

/* inquire */
typedef struct
{	flag inerr;
	ftnint inunit;
	char *infile;
	ftnlen infilen;
	ftnint	*inex;	/*parameters in standard's order*/
	ftnint	*inopen;
	ftnint	*innum;
	ftnint	*innamed;
	char	*inname;
	ftnlen	innamlen;
	char	*inacc;
	ftnlen	inacclen;
	char	*inseq;
	ftnlen	inseqlen;
	char 	*indir;
	ftnlen	indirlen;
	char	*infmt;
	ftnlen	infmtlen;
	char	*inform;
	ftnint	informlen;
	char	*inunf;
	ftnlen	inunflen;
	ftnint	*inrecl;
	ftnint	*innrec;
	char	*inblank;
	ftnlen	inblanklen;
} inlist;

#define VOID void

union Multitype {	/* for multiple entry points */
	integer1 g;
	shortint h;
	integer i;
	/* longint j; */
	real r;
	doublereal d;
	complex c;
	doublecomplex z;
	};

typedef union Multitype Multitype;

/*typedef long int Long;*/	/* No longer used; formerly in Namelist */

struct Vardesc {	/* for Namelist */
	char *name;
	char *addr;
	ftnlen *dims;
	int  type;
	};
typedef struct Vardesc Vardesc;

struct Namelist {
	char *name;
	Vardesc **vars;
	int nvars;
	};
typedef struct Namelist Namelist;

/* 
#define abs(x) ((x) >= 0 ? (x) : -(x))
#define dabs(x) (doublereal)abs(x)
#define min(a,b) ((a) <= (b) ? (a) : (b))
#define max(a,b) ((a) >= (b) ? (a) : (b))
#define dmin(a,b) (doublereal)min(a,b)
#define dmax(a,b) (doublereal)max(a,b)
*/

/* procedure parameter types for -A and -C++ */

#define F2C_proc_par_types 1
#ifdef __cplusplus
typedef int /* Unknown procedure type */ (*U_fp)(...);
typedef shortint (*J_fp)(...);
typedef integer (*I_fp)(...);
typedef real (*R_fp)(...);
typedef doublereal (*D_fp)(...), (*E_fp)(...);
typedef /* Complex */ VOID (*C_fp)(...);
typedef /* Double Complex */ VOID (*Z_fp)(...);
typedef logical (*L_fp)(...);
typedef shortlogical (*K_fp)(...);
typedef /* Character */ VOID (*H_fp)(...);
typedef /* Subroutine */ int (*S_fp)(...);
#else
typedef int /* Unknown procedure type */ (*U_fp)();
typedef shortint (*J_fp)();
typedef integer (*I_fp)();
typedef real (*R_fp)();
typedef doublereal (*D_fp)(), (*E_fp)();
typedef /* Complex */ VOID (*C_fp)();
typedef /* Double Complex */ VOID (*Z_fp)();
typedef logical (*L_fp)();
typedef shortlogical (*K_fp)();
typedef /* Character */ VOID (*H_fp)();
typedef /* Subroutine */ int (*S_fp)();
#endif
/* E_fp is for real functions when -R is not specified */
typedef VOID C_f;	/* complex function */
typedef VOID H_f;	/* character function */
typedef VOID Z_f;	/* double complex function */
typedef doublereal E_f;	/* real function with -R not specified */

/* undef any lower-case symbols that your C compiler predefines, e.g.: */

#ifndef Skip_f2c_Undefs
#undef cray
#undef gcos
#undef mc68010
#undef mc68020
#undef mips
#undef pdp11
#undef sgi
#undef sparc
#undef sun
#undef sun2
#undef sun3
#undef sun4
#undef u370
#undef u3b
#undef u3b2
#undef u3b5
#undef unix
#undef vax
#endif

#endif /* F2C_INCLUDE */

/* Subroutine */ int MATHLP_DFFT_cfftf(integer *n, real *c__, real *wsave);
/* Subroutine */ int MATHLP_DFFT_cfftb(integer *n, real *c__, real *wsave);
/* Subroutine */ int MATHLP_DFFT_cffti(integer *n, real *wsave);

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_BLUINTx1

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input matrix
                      NRowInp  : number of rows of the input matrix
                      NColInp  : number of columns of the input matrix
                      OutPoint : 2D array with the row, col coordinates of the
                                 the points in which to interpolate
                      NRowOut  : number of rows of the output matrix
                      NColOut  : number of columns of the output matrix
                      InvVal   : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma   : matrix with the values of the input matrix
                                 into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
                      matrix of UINTx1 type on the points coordinates given by
                      an array of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the number of output rows' coordinates
                            - Loop over the number of output columns'
                              coordinates
                                  - Evaluate the image coordinates of the image
                                    point on the top left of the square
                                    surrounding the wanted point
                                  - If it is in the image or not
                                        - Evaluate the value of the point with
                                          coordinates equals to the top square
                                          row at the wanted fractionary column
                                          with a linear interpolation
                                        - Evaluate the value of the point with
                                          coordinates equals to the bottom
                                          square row at the wanted fractionary
                                          column with a linear interpolation
                                        - Evaluated the output value with a
                                          linear interpolation between the two
                                          interpolated points at the fractionary
                                          row
                                  - End if
                                  - Else
                                        - Put the invalid value as output
                                          interpolated value
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_BLUINTx1
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_BLUINTx2

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input matrix
                      NRowInp  : number of rows of the input matrix
                      NColInp  : number of columns of the input matrix
                      OutPoint : 2D array with the row, col coordinates of the
                                 the points in which to interpolate
                      NRowOut  : number of rows of the output matrix
                      NColOut  : number of columns of the output matrix
                      InvVal   : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma   : matrix with the values of the input matrix
                                 into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
                      matrix of UINTx2 type on the points coordinates given by
                      an array of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the number of output rows' coordinates
                            - Loop over the number of output columns'
                              coordinates
                                  - Evaluate the image coordinates of the image
                                    point on the top left of the square
                                    surrounding the wanted point
                                  - If it is in the image or not
                                        - Evaluate the value of the point with
                                          coordinates equals to the top square
                                          row at the wanted fractionary column
                                          with a linear interpolation
                                        - Evaluate the value of the point with
                                          coordinates equals to the bottom
                                          square row at the wanted fractionary
                                          column with a linear interpolation
                                        - Evaluated the output value with a
                                          linear interpolation between the two
                                          interpolated points at the fractionary
                                          row
                                  - End if
                                  - Else
                                        - Put the invalid value as output
                                          interpolated value
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_BLUINTx2
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_BLfloat

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input matrix
                      NRowInp  : number of rows of the input matrix
                      NColInp  : number of columns of the input matrix
                      OutPoint : 2D array with the row, col coordinates of the
                                 the points in which to interpolate
                      NRowOut  : number of rows of the output matrix
                      NColOut  : number of columns of the output matrix
                      InvVal   : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma   : matrix with the values of the input matrix
                                 into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
                      matrix of float type on the points coordinates given by
                      an array of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the number of output rows' coordinates
                            - Loop over the number of output columns'
                              coordinates
                                  - Evaluate the image coordinates of the image
                                    point on the top left of the square
                                    surrounding the wanted point
                                  - If it is in the image or not
                                        - Evaluate the value of the point with
                                          coordinates equals to the top square
                                          row at the wanted fractionary column
                                          with a linear interpolation
                                        - Evaluate the value of the point with
                                          coordinates equals to the bottom
                                          square row at the wanted fractionary
                                          column with a linear interpolation
                                        - Evaluated the output value with a
                                          linear interpolation between the two
                                          interpolated points at the fractionary
                                          row
                                  - End if
                                  - Else
                                        - Put the invalid value as output
                                          interpolated value
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_BLfloat
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_BL2INTx2

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input matrix
                      NRowInp  : number of rows of the input matrix
                      NColInp  : number of columns of the input matrix
                      OutPoint : 2D array with the row, col coordinates of the
                                 the points in which to interpolate
                      NRowOut  : number of rows of the output matrix
                      NColOut  : number of columns of the output matrix
                      InvVal   : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma   : matrix with the values of the input matrix
                                 into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
                      matrix of 2INTx2 type on the points coordinates given by
                      an array of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the number of output rows' coordinates
                            - Loop over the number of output columns'
                              coordinates
                                  - Evaluate the image coordinates of the image
                                    point on the top left of the square
                                    surrounding the wanted point
                                  - If it is in the image or not
                                        - Evaluate the value of the point with
                                          coordinates equals to the top square
                                          row at the wanted fractionary column
                                          with a linear interpolation
                                        - Evaluate the value of the point with
                                          coordinates equals to the bottom
                                          square row at the wanted fractionary
                                          column with a linear interpolation
                                        - Evaluated the output value with a
                                          linear interpolation between the two
                                          interpolated points at the fractionary
                                          row
                                  - End if
                                  - Else
                                        - Put the invalid value as output
                                          interpolated value
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_BL2INTx2
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_BL2float

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input matrix
                      NRowInp  : number of rows of the input matrix
                      NColInp  : number of columns of the input matrix
                      OutPoint : 2D array with the row, col coordinates of the
                                 the points in which to interpolate
                      NRowOut  : number of rows of the output matrix
                      NColOut  : number of columns of the output matrix
                      InvVal   : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma   : matrix with the values of the input matrix
                                 into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
                      matrix of 2float type on the points coordinates given by
                      an array of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the number of output rows' coordinates
                            - Loop over the number of output columns'
                              coordinates
                                  - Evaluate the image coordinates of the image
                                    point on the top left of the square
                                    surrounding the wanted point
                                  - If it is in the image or not
                                        - Evaluate the value of the point with
                                          coordinates equals to the top square
                                          row at the wanted fractionary column
                                          with a linear interpolation
                                        - Evaluate the value of the point with
                                          coordinates equals to the bottom
                                          square row at the wanted fractionary
                                          column with a linear interpolation
                                        - Evaluated the output value with a
                                          linear interpolation between the two
                                          interpolated points at the fractionary
                                          row
                                  - End if
                                  - Else
                                        - Put the invalid value as output
                                          interpolated value
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_BL2float
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_CCUINTx1

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates for images of UINTx1 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the left integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the tables
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_CCUINTx1
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_CCUINTx2

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates for images of UINTx2 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the left integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the tables
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_CCUINTx2
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_CCfloat

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates for images of float type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the left integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the tables
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_CCfloat
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_CC2INTx2

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates for images of 2INTx2 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the left integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the tables
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_CC2INTx2
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_CC2float

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates for images of 2float type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the left integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the tables
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_CC2float
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPF_INTR_CubiConvKernel

        $TYPE         FUNCTION

        $INPUT        x : the independent variable value 

        $MODIFIED     NONE

        $OUTPUT       y : the function value evaluated in x

        $GLOBAL       MATHPD_cubi_conv_coeff : coefficient of the cubic
                                               convolution kernel function

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the value of the cubic
                      convolution kernel at the given value of shift from
                      the integer point coordinate

        $WARNING      NONE

        $PDL          - Switches between the various distances ranges
                            - assignes the kernel function value
                      - End switch

   $EH
   ========================================================================== */
   extern float MATHPF_INTR_CubiConvKernel
                        (/*IN    */ float                x,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SincAzimuth

        $TYPE         PROCEDURE

        $INPUT        shift : the independent variable value
                      fc    : doppler centroid frequency

        $MODIFIED     NONE

        $OUTPUT       y     : the array of the sinc function evaluated for the
                              shift <shift>

        $GLOBAL       MATHPV_sinc_elem : the length of the sinc

        $RET_STATUS   ERRSID_MATH_delta_out

        $DESCRIPTION  This procedure evaluates an array of values of the sinc
                      function in the form: sinc ( x ) = sin ( x ) / x for a
                      given value of delta (shift). The sinc function is
                      evaluated considering the modulation given by the doppler
                      centroid frequency <fc>

        $WARNING      THE INITIALIZATION PROCEDURE MUST BE CALLED BEFORE THE
                      PRESENT ONE

        $PDL          - Evaluates the frequence of the sinc
                      - Loop over the points of the sinc to evaluate
                            - Evaluates the delta from the current point
                            - Fill the real part of the result
                            - Modulates the array point with the term due to
                              the doppler centroid freq.
                            - Increments the array modulus sum
                      - End loop
                      - Normalizes the result with the modulus of the array

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_SincAzimuth
                        (/*IN    */ float                shift,
                         /*IN    */ float                fc,
                         /*   OUT*/ MATHIT_complex      *y,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SincRange

        $TYPE         PROCEDURE

        $INPUT        shift : the independent variable value

        $MODIFIED     NONE

        $OUTPUT       y     : the array of the sinc function evaluated for the
                              shift <shift>

        $GLOBAL       MATHPV_sinc_elem : the length of the sinc

        $RET_STATUS   ERRSID_MATH_delta_out

        $DESCRIPTION  This procedure evaluates an array of values of the sinc
                      function in the form: sinc ( x ) = sin ( x ) / x for a
                      given value of delta (shift).

        $WARNING      THE INITIALIZATION PROCEDURE MUST BE CALLED BEFORE THE
                      PRESENT ONE

        $PDL          - Evaluates the frequence of the sinc
                      - Loop over the points of the sinc to evaluate
                            - Evaluates the delta from the current point
                            - Fill the real part of the result
                            - Increments the array modulus sum
                      - End loop
                      - Normalizes the result with the modulus of the array

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_SincRange
                        (/*IN    */ float                shift,
                         /*   OUT*/ float               *y,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SNUINTx1

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHPV_SincTableLength : inverse of the precision required
                                               for the sinc interpolation
                      MATHPV_SincRowTable    : the table with the values for the
                                               sinc interpolation in the row
                                               direction
                      MATHPV_SincColTable    : the table with the values for the
                                               sinc interpolation in the column
                                               direction

        $RET_STATUS   ERRSID_MATH_table_not_allocated

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates for images of UINTx1 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the round integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the azimuth
                                          table
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_SNUINTx1
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SNUINTx2

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHPV_SincTableLength : inverse of the precision required
                                               for the sinc interpolation
                      MATHPV_SincRowTable    : the table with the values for the
                                               sinc interpolation in the row
                                               direction
                      MATHPV_SincColTable    : the table with the values for the
                                               sinc interpolation in the column
                                               direction

        $RET_STATUS   ERRSID_MATH_table_not_allocated

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates for images of UINTx2 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the round integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the azimuth
                                          table
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_SNUINTx2
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SNfloat

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHPV_SincTableLength : inverse of the precision required
                                               for the sinc interpolation
                      MATHPV_SincRowTable    : the table with the values for the
                                               sinc interpolation in the row
                                               direction
                      MATHPV_SincColTable    : the table with the values for the
                                               sinc interpolation in the column
                                               direction

        $RET_STATUS   ERRSID_MATH_table_not_allocated

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates for images of float type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the round integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the azimuth
                                          table
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_SNfloat
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SN2INTx2

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHPV_SincTableLength : inverse of the precision required
                                               for the sinc interpolation
                      MATHPV_SincRowTable    : the table with the values for the
                                               sinc interpolation in the row
                                               direction
                      MATHPV_SincColTable    : the table with the values for the
                                               sinc interpolation in the column
                                               direction

        $RET_STATUS   ERRSID_MATH_table_not_allocated

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates for images of 2INTx2 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the round integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the azimuth
                                          table
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_SN2INTx2
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SN2float

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHPV_SincTableLength : inverse of the precision required
                                               for the sinc interpolation
                      MATHPV_SincRowTable    : the table with the values for the
                                               sinc interpolation in the row
                                               direction
                      MATHPV_SincColTable    : the table with the values for the
                                               sinc interpolation in the column
                                               direction

        $RET_STATUS   ERRSID_MATH_table_not_allocated

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates for images of 2float type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the round integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the azimuth
                                          table
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_SN2float
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillArray

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input image block
                      NRowInp  : number of rows of the image block
                      NColInp  : number of columns of the image block
                      DataType : input image block data type

        $MODIFIED     NONE

        $OUTPUT       array    : output array containing the 2D input matrix

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_negative_dimen
                      ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills an array with the 2D image block
                      given in input in a sequential manner

        $WARNING      NONE

        $PDL          - Checks the number of rows and columns of the input
                        image block
                      - Checks the number of elements of the output array
                      - Checks the array type
                      - Switch over the input image block data type
                            - Loop over the input image block rows
                                  - Loop over the row elements
                                        - Fills the array element
                                  - End loop
                            - End loop
                      - End switch

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_FillArray
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *array,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillImage

        $TYPE         PROCEDURE

        $INPUT        sign_s   : array to copy
                      NColInp  : number of image columns
                      NRowInp  : number of image rows
                      DataType : data type of the output image

        $MODIFIED     NONE

        $OUTPUT       OutIma   : image to rewrite

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills the image from the sequentially
                      written array

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_FillImage
                        (/*IN    */ MATHIT_array         sign_s,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ void               **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_ImageRowConstShift

        $TYPE         PROCEDURE

        $INPUT        NRowInp  : number of rows of the image portion
                      NColInp  : number of columns of the image portion
                      shift    : column shift to apply to the image
                      DataType : data type of the image

        $MODIFIED     InpIma   : the image to shift

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_dim

        $DESCRIPTION  This procedure shifts a block image of a wanted number
                      (floating) of pixels in the column direction

        $WARNING      NONE

        $PDL          - Checks the number of rows and columns of the block
                        image
                      - Initializes the usefull variables
                      - Allocates the wanted memories
                      - Loop over the number of columns
                            - Evaluates the phase of the multiplicator factor
                            - Fills the vector element with the multiplication
                              factor
                            - Fills the vector element complementar to the
                              current column
                      - End loop
                      - Fills the central element of the multiplication factors
                        vector if the total number of elements if odd
                      - Loop over the rows of the image block
                            - Zeroes the signal vector
                            - Fills the signal vector with the image row
                            - Makes the FFT of the signal
                            - Multiplicates the signal FFT with the phase
                              vector
                            - Makes the inverse FFT of the signal FFT
                            - Fills the image row with the new values
                      - End loop
                      - Frees the allocated memories

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_ImageRowConstShift
                        (/*IN    */ UINTx4              NRowInp,
                         /*IN    */ UINTx4              NColInp,
                         /*IN    */ float               shift,
                         /*IN    */ LDEFIT_data_type    DataType,
                         /*IN OUT*/ void              **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_ImageColConstShift

        $TYPE         PROCEDURE

        $INPUT        NRowInp  : number of rows of the image portion
                      NColInp  : number of columns of the image portion
                      shift    : column shift to apply to the image
                      DataType : data type of the image

        $MODIFIED     InpIma   : the image to shift

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_dim

        $DESCRIPTION  This procedure shifts a block image of a wanted number
                      (floating) of pixels in the column direction

        $WARNING      NONE

        $PDL          - Checks the number of rows and columns of the block
                        image
                      - Initializes the usefull variables
                      - Allocates the wanted memories
                      - Loop over the number of rows
                            - Evaluates the phase of the multiplicator factor
                            - Fills the vector element with the multiplication
                              factor
                            - Fills the vector element complementar to the
                              current row
                      - End loop
                      - Fills the central element of the multiplication factors
                        vector if the total number of elements if odd
                      - Loop over the rows of the image block
                            - Zeroes the signal vector
                            - Fills the signal vector with the image row
                            - Makes the FFT of the signal
                            - Multiplicates the signal FFT with the phase
                              vector
                            - Makes the inverse FFT of the signal FFT
                            - Fills the image col with the new values
                      - End loop
                      - Clears all the memories of the FFT evaluation
                      - Frees the allocated memories

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_ImageColConstShift
                        (/*IN    */ UINTx4              NRowInp,
                         /*IN    */ UINTx4              NColInp,
                         /*IN    */ float               shift,
                         /*IN    */ LDEFIT_data_type    DataType,
                         /*IN OUT*/ void              **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillRowArray

        $TYPE         PROCEDURE

        $INPUT        InpIma    : input image
                      row       : image row to copy
                      NColInp   : number of elements of the line
                      DataType  : enumerate the various image types

        $MODIFIED     NONE

        $OUTPUT       sign_s    : array with the image row copy

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills an array with an image row to be
                      processed by FFT algorithms

        $WARNING      NONE

        $PDL          - Checks the number of elements of the image row
                      - Checks the array type
                      - Switch over the data types
                            - Loop over the image elements
                                  - Copies the image row element
                            - End loop
                      - End switch

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_FillRowArray
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               row,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *sign_s,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillColArray

        $TYPE         PROCEDURE

        $INPUT        InpIma    : input image
                      col       : image col to copy
                      NRowInp   : number of elements of the column 
                      DataType  : enumerate the various image types

        $MODIFIED     NONE

        $OUTPUT       sign_s    : array with the image row copy

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills an array with an image row to be
                      processed by FFT algorithms

        $WARNING      NONE

        $PDL          - Checks the number of elements of the image column
                      - Checks the array type
                      - Switch over the data types
                            - Loop over the image rows
                                  - Copies the image column element
                            - End loop
                      - End switch

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_FillColArray
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               col,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *sign_s,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillImaRow

        $TYPE         PROCEDURE

        $INPUT        sign_s   : array to copy
                      row      : image line to fill
                      NColInp  : number of image columns
                      DataType : data type of the output image line

        $MODIFIED     InpIma   : image to rewrite

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills the image row indicated by the input
                      <row>

        $WARNING      NONE

        $PDL          - Checks the number of array elements
                      - Checks the array type
                      - Switch over the output image types
                            - Loop over the array elements
                                  - Fills the image row element
                            - End loop
                      - End switch

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_FillImaRow
                        (/*IN    */ MATHIT_array         sign_s,
                         /*IN    */ UINTx4               row,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN OUT*/ void               **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillImaCol

        $TYPE         PROCEDURE

        $INPUT        sign_s   : array to copy
                      col      : image line to fill
                      NRowInp  : number of image rows
                      DataType : data type of the output image line

        $MODIFIED     InpIma   : image to rewrite

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills the image column indicated by the
                      input <row>

        $WARNING      NONE

        $PDL          - Checks the number of array elements
                      - Checks the array type
                      - Switch over the output image types
                            - Loop over the array elements
                                  - Fills the image row element
                            - End loop
                      - End switch

   $EH
   ========================================================================== */
   extern void MATHPP_INTR_FillImaCol
                        (/*IN    */ MATHIT_array         sign_s,
                         /*IN    */ UINTx4               col,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN OUT*/ void               **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MATHPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 MATHPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MATHPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void MATHPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) MATHIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( MATHPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MATHIM_

      $DESCRIPTION  This procedure

                    MATHIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define MATHPM_
*/

/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHPC_bl_func

      $DESCRIPTION  This array of pointers to functions contains the functions
                    needed to the bilinear interpolator

   $EH
   ========================================================================== */
#ifdef MATH_GLBL
   GLOBAL const MATHPT_interp_func MATHPC_bl_func[] = {
      MATHPP_INTR_BLUINTx1,
      MATHPP_INTR_BLUINTx2,
      MATHPP_INTR_BLfloat,
      MATHPP_INTR_BL2INTx2,
      MATHPP_INTR_BL2float
   };
#else
   GLOBAL const MATHPT_interp_func MATHPC_bl_func[];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHPC_cc_func

      $DESCRIPTION  This array of pointers to functions contains the functions
                    needed to the cubic convolution interpolator

   $EH
   ========================================================================== */
#ifdef MATH_GLBL
   GLOBAL const MATHPT_interp_func MATHPC_cc_func[] = {
      MATHPP_INTR_CCUINTx1,
      MATHPP_INTR_CCUINTx2,
      MATHPP_INTR_CCfloat,
      MATHPP_INTR_CC2INTx2,
      MATHPP_INTR_CC2float
   };
#else
   GLOBAL const MATHPT_interp_func MATHPC_cc_func[];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHPC_sinc_func

      $DESCRIPTION  This array of pointers to functions contains the functions
                    needed to the sinc interpolator

   $EH
   ========================================================================== */
#ifdef MATH_GLBL
   GLOBAL const MATHPT_interp_sfunc MATHPC_sinc_func[] = {
      MATHPP_INTR_SNUINTx1,
      MATHPP_INTR_SNUINTx2,
      MATHPP_INTR_SNfloat,
      MATHPP_INTR_SN2INTx2,
      MATHPP_INTR_SN2float
   };
#else
   GLOBAL const MATHPT_interp_sfunc MATHPC_sinc_func[];
#endif
