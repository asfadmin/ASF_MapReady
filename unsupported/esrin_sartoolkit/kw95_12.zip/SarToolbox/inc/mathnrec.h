void dspline(double *x,double *y,INTx4 n,double yp1,double ypn,double *y2,
             INTx4 *status);

void dsplint(double *xa,double *ya,double *y2a,INTx4 n,double x,double *y,
             INTx4 *status);

void damoeba(double **p,double *y,INTx4 ndim,double ftol,double vtol,
             double (*funk)(),
             INTx4 *nfunk,INTx4 *status);

void dludcmp(double **a,INTx4 n,INTx4 *indx,double *d,INTx4 *status);

void dlubksb(double **a,INTx4 n,INTx4 *indx,double *b,INTx4 *status);

void dmnewt(INTx4 ntrial,double *x,INTx4 n,void (*usrfun)(),double tolx,
            double tolf,INTx4 *status);

void dtred2(double **a,INTx4 n,double *d,double *e,INTx4 *status);

void dtqli(double *d,double *e,INTx4 n,double **z,INTx4 *status);
