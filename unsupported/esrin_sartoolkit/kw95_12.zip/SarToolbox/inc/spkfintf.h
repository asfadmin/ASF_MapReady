/* ==========================================================================
   $MODULE_HEADER

      $NAME              SPKF_INTF

      $FUNCTION          SPECKLE FILTERING library interface module.

      $ROUTINE           SPKFIP_load_mask
                         SPKFIP_filter
                         SPKFIP_AUTO_select_mask
                         SPKFIP_AUTO_free

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       20-OCT-97     AN       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef SPKF
#define SPKF SPKF


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include GIOS_INTF_H

#ifdef SPKF_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define SPKFID_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum SPKFIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIC_

      $DESCRIPTION  The SPKFIC_

   $EH
   ========================================================================== */
/*   const SPKFIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIT_mask_type

      $DESCRIPTION  Enumerated for different IO types

   $EH
   ========================================================================== */
   enum SPKFIE_mask_type  {
      SPKFIE_mt_all,
      SPKFIE_mt_scatter,
      SPKFIE_mt_edgline
   };
   typedef enum SPKFIE_mask_type SPKFIT_mask_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIT_all_mask

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct SPKFIT_all_mask_def {
      UINTx4                      n;
      float                     **vect;
      float                       mean;
      LDEFIT_boolean              mean_computed;
      float                       sigma;
      LDEFIT_boolean              sigma_computed;
   };

   typedef struct SPKFIT_all_mask_def SPKFIT_all_mask;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIT_scatter_mask

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct SPKFIT_scatter_mask_def {
      UINTx4                      ncl;
      float                     **clutter;
      float                       clutter_mean;
      LDEFIT_boolean              clutter_mean_computed;
      UINTx4                      nbf;
      float                     **buffer;
      float                       buffer_mean;
      LDEFIT_boolean              buffer_mean_computed;
      UINTx4                      nml;
      float                     **mailobe;
      float                       mailobe_mean;
      LDEFIT_boolean              mailobe_mean_computed;
   };

   typedef struct SPKFIT_scatter_mask_def SPKFIT_scatter_mask;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIT_edgline_mask

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct SPKFIT_edgline_mask_def {
      UINTx4                      nedge1;
      float                     **edge1;
      float                       edge1_mean;
      LDEFIT_boolean              edge1_mean_computed;
      UINTx4                      nedge2;
      float                     **edge2;
      float                       edge2_mean;
      LDEFIT_boolean              edge2_mean_computed;
      UINTx4                      nbf1;
      float                     **buff1;
      float                       buff1_mean;
      LDEFIT_boolean              buff1_mean_computed;
      UINTx4                      nbf2;
      float                     **buff2;
      float                       buff2_mean;
      LDEFIT_boolean              buff2_mean_computed;
      UINTx4                      nline;
      float                     **line;
      float                       line_mean;
      LDEFIT_boolean              line_mean_computed;
      UINTx4                      nedgbuff1;
      float                     **edgbuff1;
      float                       edgbuff1_mean;
      LDEFIT_boolean              edgbuff1_mean_computed;
      UINTx4                      nedgbuff2;
      float                     **edgbuff2;
      float                       edgbuff2_mean;
      LDEFIT_boolean              edgbuff2_mean_computed;
   };

   typedef struct SPKFIT_edgline_mask_def SPKFIT_edgline_mask;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIT_mask

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct SPKFIT_mask_def {
      SPKFIT_mask_type            type;
      float                       the;
      float                       thl;
      float                       ths;
      union {
         SPKFIT_scatter_mask      scatter;
         SPKFIT_edgline_mask      edgline;
         SPKFIT_all_mask          all;
      } val;
   };

   typedef struct SPKFIT_mask_def SPKFIT_mask;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct SPKFIT_*_def { 

   typedef struct SPKFIT_*_def SPKFIT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIV_mask_file

      $DESCRIPTION  user mask file

   $EH
   ========================================================================== */
   GLOBAL FILSIT_file_name SPKFIV_mask_file;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIV_edge_th

      $DESCRIPTION  user edge threshold

   $EH
   ========================================================================== */
   GLOBAL float SPKFIV_edge_th;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIV_line_th

      $DESCRIPTION  user line threshold

   $EH
   ========================================================================== */
   GLOBAL float SPKFIV_line_th;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFIV_scatter_th

      $DESCRIPTION  user scatter threshold

   $EH
   ========================================================================== */
   GLOBAL float SPKFIV_scatter_th;

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SPKFIP_filter   

      $TYPE	    PROCEDURE

      $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                    imanum    : number identifing the image inside the tool
                    TLRow     : the row image coordinate in the full
                                reference frame of the image
                    TLCol     : the column image coordinate in the full
                                reference frame of the image
                    nrow_inp  : number of rows of the image
                    ncol_inp  : number of columns of the images
		    win_sizes : size of the window (row, col)
	            mask_file : user's mask file, NULL if not
                    pfa       : PFA user's value
                    edge_th   : user's edge threshold
                    line_th   : user's line threshold
                    scatter_th: user's scatter threshold
                    out_io    : structure with the IO basic parameters of the
                                output image
                    nrow_out  : number of rows of the output image block
                    ncol_out  : number of columns of the output image block

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure executes the SPECKLE FILTERING of an
                    intensity image
 
      $WARNING      The input and the output files shall be already opened.

      $PDL          - Build kernel (just sizes)
		    - Call Overlap & Save windowing image method

   $EH
   ========================================================================== */
   extern void SPKFIP_filter   
                       ( /*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ INTx4               *win_sizes,
                         /*IN    */ FILSIT_file_name     mask_file,
                         /*IN    */ float                pfa,
                         /*IN    */ float                edge_th,
                         /*IN    */ float                line_th,
                         /*IN    */ float                scatter_th,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SPKFIP_load_masks

      $TYPE	    PROCEDURE

      $INPUT        inp_win         : window image matrix
                    inp_data_type   : input data type
                    row_size        : row window size
                    col_size        : column window size

      $MODIFIED     NONE

      $OUTPUT       mask_no         : number of loaded masks
                    mask            : array of mask

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure load the mask into memory 
 
      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void SPKFIP_load_masks
                       ( /*IN    */ float              **inp_win,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ UINTx4               row_size,
                         /*IN    */ UINTx4               col_size,
                         /*IN    */ UINTx4              *mask_no,
                         /*   OUT*/ SPKFIT_mask        **mask,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SPKFIP_mask_set_thresh

      $TYPE	    PROCEDURE

      $INPUT        mask_no         : number of loaded masks
                    mask            : array of mask
                    pfa             : input probability
                    row_size        : row window size
                    col_size        : column window size
                    looks_no        : image number of looks

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure load the mask into memory 
 
      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void SPKFIP_mask_set_thresh
                       ( /*IN    */ UINTx4               mask_no,
                         /*IN OUT*/ SPKFIT_mask         *mask,
                         /*IN    */ float                pfa,
                         /*IN    */ UINTx4               row_size,
                         /*IN    */ UINTx4               col_size,
                         /*IN    */ float                looks_no,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SPKFIP_AUTO_select_mask

        $TYPE         PROCEDURE

        $INPUT        inp_win   : image window on which to select the mask
                      imanum    : index of the image in IANNIV_ImageAnnot
                      row_size  : row size of the window
                      col_size  : column size of the window
                      mask      : masks descriptor
                      pfa       : PFA user's value

        $MODIFIED     NONE

        $OUTPUT       value     : output value of the inp_win with the selected
                                  mask

        $GLOBAL       IANNIV_ImageAnnot

        $RET_STATUS   ERRSID_SPKF_err_mem_alloc
                      ERRSID_SPKF_err_comp_mask
                      
        $DESCRIPTION  

        $WARNING      NONE

        $PDL          - If called for the first time, init the global variables
                      - Init the global variable having the central pixel value
                      - Start the automa
                      - Returns the output value

   $EH
   ========================================================================== */
   extern void SPKFIP_AUTO_select_mask
                      ( /*IN    */ float              **inp_win,
                        /*IN    */ UINTx4               row_size,
                        /*IN    */ UINTx4               col_size,
                        /*IN    */ UINTx4               mask_no,
                        /*IN    */ SPKFIT_mask         *mask,
                        /*IN    */ float                looks_no,
                        /*   OUT*/ float               *value,
#ifdef __TRACE__
                        /*   OUT*/ UINTx1              *acc,
#endif
                        /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SPKFIP_AUTO_free

        $TYPE         PROCEDURE

        $INPUT        NONE 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE
                      
        $DESCRIPTION  

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void SPKFIP_AUTO_free
                      ( /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SPKFIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/*   extern void SPKFIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SPKFIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void SPKFIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) SPKFIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SPKFIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    SPKFIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define SPKFIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_SPKF_err_mem_alloc        2
#define ERRSID_SPKF_imanum_not_allow     3
#define ERRSID_SPKF_kernel_dim_high      4
#define ERRSID_SPKF_bad_steps            5
#define ERRSID_SPKF_bad_write_size       6
#define ERRSID_SPKF_data_type_not_allow  7
#define ERRSID_SPKF_inv_speckle_mask     8
#define ERRSID_SPKF_inv_speckle_char     9
#define ERRSID_SPKF_err_comp_mask        10
#define ERRSID_SPKF_eof_loading_mask     11
#define ERRSID_SPKF_eof_loading_coeff    12
#define ERRSID_SPKF_inv_threshold        13

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef SPKF_GLBL
   GLOBAL char *SPKFIV_ERRS_error_message[] = 
                        { "No error happens",                         /*  0 */
                          "Generic error happens",                    /*  1 */
                          "SYSTEM ERROR: memory allocation error",    /*  2 */
                          "Image number not allowed in annotation",   /*  3 */
			  "Kernel dimension too high",                /*  4 */
			  "Bad row-column steps",                     /*  5 */
			  "Bad output size",                          /*  6 */
			  "Invalid data type",                        /*  7 */
			  "Invalid Speckle Mask",                     /*  8 */
			  "Invalid character in Mask File",           /*  9 */
                          "Uncomputable region mask",                 /* 10 */
                          "Unexpected EOF while loading mask file",   /* 11 */
                          "Unexpected EOF while loading coefficient file",
                                                                      /* 12 */
                          "Invalid threshold"                         /* 13 */
                        };
#else
   GLOBAL char *SPKFIV_ERRS_error_message[];
#endif


#endif
