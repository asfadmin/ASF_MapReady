/* ==========================================================================
   $MODULE_HEADER

      $NAME              SRVS_PGLB

      $FUNCTION          global module.

      $ROUTINE           SRVSPP_

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       28-AUG-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include SRVS_INTF_H


#ifdef  SRVS_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSPD_count_step

      $DESCRIPTION  Step used for percentage of completition

   $EH
   ========================================================================== */
#define SRVSPD_count_step 5

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSPD_system

      $DESCRIPTION  System name

   $EH
   ========================================================================== */
#ifdef __VMS__
#define SRVSPD_system	    "VMS"
#endif
#ifdef __UNIX__
#ifdef __SUN__
#define SRVSPD_system	    "SUN"
#endif
#ifdef __SGI__
#define SRVSPD_system	    "SGI"
#endif
#ifdef __HP__
#define SRVSPD_system	    "HP"
#endif
#ifdef __OSF__
#define SRVSPD_system	    "OSF"
#endif
#ifdef __IBM__
#define SRVSPD_system	    "IBM"
#endif
#endif
#ifdef __DOS__
#define SRVSPD_system	    "DOS"
#endif
#ifdef __WIN95__
#define SRVSPD_system	    "WIN95"
#endif
#if defined(__MC68K__) || defined(__POWERPC__)
#define SRVSPD_system	    "MAC"
#endif
   
/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSPD_system_memory

      $DESCRIPTION  User setting of system memory size in Kbytes

   $EH
   ========================================================================== */
#define SRVSPD_system_memory	    "System Memory"

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSPD_system_memory_thresh

      $DESCRIPTION  Threshold size

   $EH
   ========================================================================== */
#if defined __MC68K__ || defined __POWERPC__
#define SRVSPD_system_memory_thresh   ((float) 0.65)
#else
#define SRVSPD_system_memory_thresh   ((float) 0.9)
#endif

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum SRVSPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSPC_

      $DESCRIPTION  The SRVSPC_

   $EH
   ========================================================================== */
/*   const SRVSPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSPT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct SRVSPT_*_def { 

   typedef struct SRVSPT_*_def SRVSPT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSPV_target_comp

      $DESCRIPTION  If different from 0 is the completition target number

   $EH
   ========================================================================== */
#ifdef SRVS_GLBL
   GLOBAL UINTx4 SRVSPV_target_comp = 0;
#else
   GLOBAL UINTx4 SRVSPV_target_comp;
#endif


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSPV_sum

      $DESCRIPTION  It represent the number of loop already executed

   $EH
   ========================================================================== */
#ifdef SRVS_GLBL
   GLOBAL UINTx4 SRVSPV_sum = 0;
#else
   GLOBAL UINTx4 SRVSPV_sum;
#endif


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSPV_perc

      $DESCRIPTION  It represents the percentage to be printed

   $EH
   ========================================================================== */
#ifdef SRVS_GLBL
   GLOBAL UINTx4 SRVSPV_perc = SRVSPD_count_step;
#else
   GLOBAL UINTx4 SRVSPV_perc;
#endif


/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SRVSPP_

      $DESCRIPTION  

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/*   extern void SRVSPP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SRVSPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 SRVSPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SRVSPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void SRVSPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) SRVSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( SRVSPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SRVSIM_

      $DESCRIPTION  This procedure

                    SRVSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define SRVSPM_
*/
