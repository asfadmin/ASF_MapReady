/* ==========================================================================
   $MODULE_HEADER

      $NAME              CONV_INTF

      $FUNCTION          CONVERTION TOOL interface module.

      $ROUTINE           CONVIP_amp2pow
                         CONVIP_pow2amp
                         CONVIP_complex2amp
                         CONVIP_gaincvs
                         CONVIP_ugaincvs
                         CONVIP_sgaincvs
                         CONVIP_int2float
                         CONVIP_tiffgen
                         CONVIP_bilgen
                         CONVIP_dumpannot
                         CONVIP_impraster
                         CONVIP_lin2db

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       28-OCT-97     RZ       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef CONV
#define CONV CONV


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include GIOS_INTF_H

#ifdef CONV_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         CONVID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define CONVID_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         CONVIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum CONVIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         CONVIC_

      $DESCRIPTION  The CONVIC_

   $EH
   ========================================================================== */
/*   const CONVIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         CONVIT_raster_data_type

      $DESCRIPTION  Data type of the input raster image

   $EH
   ========================================================================== */
   enum CONVIE_raster_data_type {
      CONVIE_raster_none,
      CONVIE_raster_2i,
      CONVIE_raster_complex2i
   };
   typedef enum CONVIE_raster_data_type CONVIT_raster_data_type;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         CONVIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_amp2pow

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of AMPLITUDE TO POWER convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_amp2pow
                       ( /*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_pow2amp

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of POWER TO AMPLITUDE
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_pow2amp
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_complex2amp

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of COMPLEX TO AMPLITUDE
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_complex2amp
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_gaincvs

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      min_perc  : minimum percentage 
                      max_perc  : maximum percentage
                      no_black  : number of black
                      no_black_found
                                : TRUE if the value of no_black has been 
                                  found in the INI file
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of GAIN convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_gaincvs
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ float                min_perc,
                         /*IN    */ float                max_perc,
                         /*IN    */ LDEFIT_boolean       no_black_found,
                         /*IN    */ float                no_black,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_ugaincvs

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      user_lut  : name of the file containing the user-defined
                                  look-up table
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of GAIN convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_ugaincvs
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ char                *user_lut,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_sgaincvs

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      scale_fact: scaling factor value
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of GAIN convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_sgaincvs
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ float                scale_fact,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_int2float

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of INTEGER TO FLOAT
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_int2float
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_tiffgen

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input images
                      image_no  : number of input images
                      out_io    : IO structure of the output 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of TIFF generation
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_tiffgen
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               image_no,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_bilgen

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input images
                      image_no  : number of input images
                      out_io    : IO structure of the output 
                      out_image_erm
                                : name of ascii file for ERMPAPPER import 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of BIL generation
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_bilgen
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               image_no,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ char                *out_image_erm,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_dumpannot

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      dump_file : output dump file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure contains the core of ANCILLARY DUMP
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_dumpannot
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ char                *dump_file,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_impraster

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      media_file_skip
                                : number of file to skip on TAPE
                      file_skip : header skip in bytes
                      line_skip : line skip in bytes
                      rec_len   : image record length
                      nrows     : number of rows
                      ncols     : number of columns
                      data_type : raster data type
                      swap_bytes: 'Y" if bytes needs to be swapped
                      out_io    : IO structure of the output 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of IMPORT RASTER
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_impraster
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ INTx4                media_file_skip,
                         /*IN    */ INTx4                file_skip,
                         /*IN    */ INTx4                line_skip,
                         /*IN    */ INTx4                rec_len,
                         /*IN    */ INTx4                nrows,
                         /*IN    */ INTx4                ncols,
                         /*IN    */ CONVIT_raster_data_type     
                                                         data_type,
                         /*IN    */ char                 swap_bytes,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_lin2db

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of LINEAR TO DB 
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void CONVIP_lin2db
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         CONVIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/*   extern void CONVIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         CONVIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void CONVIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) CONVIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         CONVIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    CONVIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define CONVIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_CONV_err_mem_alloc        2
#define ERRSID_CONV_start_stop_col_err   3
#define ERRSID_CONV_inv_data_type        4
#define ERRSID_CONV_inv_param_val        5
#define ERRSID_CONV_inv_user_lut         6

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef CONV_GLBL
   GLOBAL char *CONVIV_ERRS_error_message[] = 
                        { "No error happens",                            /* 0 */
                          "Generic error happens",                       /* 1 */
                          "SYSTEM ERROR: memory allocation error",       /* 2 */
                          "Error for specifified start/stop row/column", /* 3 */
                          "Invalid data type",                           /* 4 */
                          "Invalid parameter value",                     /* 5 */
                          "Invalid user look-up table"                   /* 6 */
                        };
#else
   GLOBAL char *CONVIV_ERRS_error_message[];
#endif


#endif
