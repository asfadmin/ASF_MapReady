/* ==========================================================================
   $MODULE_HEADER

      $NAME              OVLS_PGLB

      $FUNCTION          global module.

      $ROUTINE           OVLSPP_

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       05-AUG-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include OVLS_INTF_H


#ifdef  OVLS_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         OVLSPD_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*#define OVLSPD_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         OVLSPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum OVLSPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         OVLSPC_

      $DESCRIPTION  The OVLSPC_

   $EH
   ========================================================================== */
/*   const OVLSPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         OVLSPT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct OVLSPT_*_def { 

   typedef struct OVLSPT_*_def OVLSPT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         OVLSPV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         OVLSPP_

      $DESCRIPTION  

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/*   extern void OVLSPP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         OVLSPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 OVLSPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         OVLSPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void OVLSPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) OVLSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( OVLSPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         OVLSIM_

      $DESCRIPTION  This procedure

                    OVLSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define OVLSPM_
*/
