/* ==========================================================================
   $MODULE_HEADER

      $NAME              FIIS_INTF

      $FUNCTION          interface module.

      $ROUTINE           FIISIP_GETS_get_info
                         FIISIP_GETS_get_sections

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       02-NOV-92     AD       Initial Release
            SCR #10   01-DEC-97     AG       Introduced define error code       
                                             ERRSID_FIIS_err_no_sect_found     

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef FIIS
#define FIIS FIIS


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <string.h>
#include <stdio.h>
#include <math.h>

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include FILS_INTF_H
#include MATH_INTF_H

#ifdef FIIS_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISID_max_char

      $DESCRIPTION  Number of character of the string read from the INI file

   $EH
   ========================================================================== */
#define FIISID_max_char        1024

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISID_parm_name_length

      $DESCRIPTION  Length for the parm name string

   $EH
   ========================================================================== */
#define FIISID_parm_name_length 40

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISID_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISIE_tag_type

      $DESCRIPTION  List the variable types handled from the library (the
                    allowable variables types for the passed parameters)

   $EH
   ========================================================================== */
   enum FIISIE_tag_type {  FIISIE_tt_not_available,   /* null value */
                           FIISIE_tt_char,            /* character type */
                           FIISIE_tt_string,          /* string type */
                           FIISIE_tt_int,             /* INTx4 type */
                           FIISIE_tt_long_int,        /* INTx8 type */
                           FIISIE_tt_float,           /* float type */
                           FIISIE_tt_double           /* double type */
   };

/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISIC_

      $DESCRIPTION  The FIISIC_

   $EH
   ========================================================================== */
/*   const FIISIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================

   $DECLARATION_HEADER

        $NAME         FIISIT_tag_type

        $DESCRIPTION  This type defines the enumerated FIISIE type (see
                      above)

   $EH
   ========================================================================== */
   typedef enum FIISIE_tag_type FIISIT_tag_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISIT_parm_name

      $DESCRIPTION  Definition of the parameter type name

   ========================================================================== */
   typedef char FIISIT_parm_name [ FIISID_parm_name_length ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISIT_parm

      $DESCRIPTION  Definition of the structure to hold a parameter given
                    by the INI file

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          name                             name of the parameter
          type                             type of the parameter
          size                             size of the parameter
          vector                           the parameter can be a vector
          max_number                       maximum number of values accepted 
                                           as vector
          founded                          boolean: TRUE if this parameter
                                           has been initialized
          mandatory                        boolean: TRUE if this parameter
                                           has to be always defined
          number                           number of values found
          value                            value of the parameter
   $EH
   ========================================================================== */
   struct FIISIT_parm_def { 
      FIISIT_parm_name      name;
      FIISIT_tag_type       type;
      INTx4                 size;
      LDEFIT_boolean        mandatory;
      LDEFIT_boolean        vector;
      INTx4                 max_number;
      LDEFIT_boolean        founded;
      INTx4                 number;
      void                 *value;
   };

   typedef struct FIISIT_parm_def FIISIT_parm;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

   $NAME         FIISIP_GETS_get_info

   $DESCRIPTION  Read the wanted parameters from the specified INI file.

   $TYPE         PROCEDURE

   $INPUT        file_name  : INI file name
                 section    : section name of the INI file in which the
                              searched parameter is
                 section_no : number of the section in the INI file
                              or 0, if unknown

   $MODIFIED     param	    : pointer to the parameter to fill

   $GLOBAL       NONE

   $RET_STATUS   ERRSID_FIIS_err_bad_input
                 ERRSID_FIIS_err_open_file

   $WARNING      NONE

   $PDL
                 - Input check
                 - Search the section
                 - Search the tag and consider vector definitions

   $EH
   ========================================================================== */
   extern void FIISIP_GETS_get_info
                   ( /*IN    */ FILSIT_file_name         file_name,
                     /*IN    */ char                    *section,
                     /*IN    */ UINTx4                   section_no,
                     /*IN OUT*/ FIISIT_parm             *parm,
                     /*   OUT*/ ERRSIT_status           *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

   $NAME         FIISIP_GETS_get_sections

   $DESCRIPTION  Finds all the sections contained in an INI file

   $TYPE         PROCEDURE

   $INPUT        file_name  : name of the INI file

   $MODIFIED     NONE

   $OUTPUT       section_no : number of section found in the INI file
                 section    : section of the INI file

   $GLOBAL       NONE

   $RET_STATUS   ERRSID_FIIS_err_bad_input
                 ERRSID_FIIS_err_open_file

   $WARNING      NONE

   $PDL
                 - Input check
                 - Search section

   $EH
   ========================================================================== */
   extern void FIISIP_GETS_get_sections
                   ( /*IN    */ FILSIT_file_name      file_name,
                     /*   OUT*/ UINTx4               *section_no,
                     /*   OUT*/ char               ***section,
                     /*   OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FIISIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/*   extern void FIISIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FIISIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void FIISIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) FIISIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FIISIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    FIISIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define FIISIM_
*/

/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#ifdef __VMS__

#define ERRSID_FIIS_err_mem_alloc	 2
#define ERRSID_FIIS_err_open_file        3
#define ERRSID_FIIS_err_read_file        4
#define ERRSID_FIIS_err_write_file       5
#define ERRSID_FIIS_err_close_file       6
#define ERRSID_FIIS_err_seek_file        7
#define ERRSID_FIIS_err_bad_input        8
#define ERRSID_FIIS_err_no_sect_found    9

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */
#ifdef FIIS_GLBL
   GLOBAL char *FIISIV_ERRS_error_message[] = 
                  { "No error happens", /* 0 */
                    "Generic error happens", /* 1 */
                    "SYSTEM ERROR: memory allocation error", /* 2 */
                    "SYSTEM ERROR: opening file", /* 3 */
                    "SYSTEM ERROR: reading file", /* 4 */
                    "SYSTEM ERROR: writing file", /* 5 */
                    "SYSTEM ERROR: closing file", /* 6 */
                    "SYSTEM ERROR: seeking file", /* 7 */
                    "Bad input parameter(s)",     /* 8 */
                    "No section headers found"    /* 9 */
		  };
#else
   GLOBAL  char *FIISIV_ERRS_error_message[];
#endif

#else

#define ERRSID_FIIS_err_mem_alloc	 2
#define ERRSID_FIIS_err_open_file        2
#define ERRSID_FIIS_err_read_file        2
#define ERRSID_FIIS_err_write_file       2
#define ERRSID_FIIS_err_close_file       2
#define ERRSID_FIIS_err_seek_file        2
#define ERRSID_FIIS_err_bad_input        3
#define ERRSID_FIIS_err_no_sect_found    4

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */
#ifdef FIIS_GLBL
   GLOBAL char *FIISIV_ERRS_error_message[] = 
                  { "No error happens", /* 0 */
                    "Generic error happens", /* 1 */
                    "Parameters File Handling library error happens", /* 2 */
                    "Bad input parameter(s)", /* 3 */
                    "No section headers found" /* 4 */
		  };
#else
   GLOBAL  char *FIISIV_ERRS_error_message[];
#endif

#endif

#endif
