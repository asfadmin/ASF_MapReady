/* ==========================================================================
   $MODULE_HEADER

      $NAME              SPKF_PGLB

      $FUNCTION          SPECKLE FILTERING package global module

      $ROUTINE           SPKFPP_core
                         SPKFPP_AUTO_select_mask
                         SPKFPP_AUTO_free

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       20-OCT-97     AN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include SPKF_INTF_H


#ifdef  SPKF_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFPD_spk_ker_prefix
                    SPKFPD_spk_ker_suffix
		    SPKFPD_spk_scatter
		    SPKFPD_spk_edgline
		    SPKFPD_edgline_edge1
		    SPKFPD_edgline_buffer1
		    SPKFPD_edgline_line
		    SPKFPD_edgline_buffer2
		    SPKFPD_edgline_edge2
		    SPKFPD_scatter_clutter
		    SPKFPD_scatter_buffer
		    SPKFPD_scatter_mailobe

      $DESCRIPTION  Define for the symbol used in the KER files

   $EH
   ========================================================================== */
#define SPKFPD_spk_ker_prefix    "spk"
#define SPKFPD_spk_ker_suffix    "ker"
#define SPKFPD_spk_scatter        "scatter"
#define SPKFPD_spk_edgline        "edgeline"
#define SPKFPD_edgline_edge1      '1'
#define SPKFPD_edgline_buffer1    '2'
#define SPKFPD_edgline_line       '.'
#define SPKFPD_edgline_buffer2    '3'
#define SPKFPD_edgline_edge2      '4'
#define SPKFPD_scatter_clutter    '.'
#define SPKFPD_scatter_buffer     'B'
#define SPKFPD_scatter_mailobe    'X'


/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum SPKFPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFPC_

      $DESCRIPTION  The SPKFPC_

   $EH
   ========================================================================== */
/*   const SPKFPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFPT_state    

      $DESCRIPTION  Enumerated for different AUTOMA state

   $EH
   ========================================================================== */
   enum SPKFPE_state {
      SPKFPE_st_start,
      SPKFPE_st_is_uniform_0,
      SPKFPE_st_is_heterogeneus,
      SPKFPE_st_can_be_edge_0,
      SPKFPE_st_can_be_line_0,
      SPKFPE_st_can_be_edge_1,
      SPKFPE_st_can_be_line_1,
      SPKFPE_st_edge_texture,
      SPKFPE_st_line_texture,
      SPKFPE_st_can_be_scat,
      SPKFPE_st_is_edge,
      SPKFPE_st_is_line,
      SPKFPE_st_is_uniform_1,
      SPKFPE_st_is_uniform_2,
      SPKFPE_st_can_be_scat_2,
      SPKFPE_st_can_be_scat_3,
      SPKFPE_st_is_scat,
      SPKFPE_st_is_scat_0,
      SPKFPE_st_is_scat_1,
      SPKFPE_st_is_not_scat,
      SPKFPE_st_is_not_scat_0,
      SPKFPE_st_is_not_scat_1,
      SPKFPE_st_end,
      SPKFPE_st_error
   };
   typedef enum SPKFPE_state SPKFPT_state;

   typedef SPKFPT_state (*SPKFPT_state_func)
      ( void );

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SPKFPV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SPKFPP_core     

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_io 	    : IO structure of the output image
                      pfa           : PFA user's value
                      look_no       : LOOK NUMBER user's value
                      inp_ima_num   : annotation index of the input image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_SPKF_kernel_dim_high
		      ERRSID_SPKF_bad_steps
		      ERRSID_SPKF_bad_write_size
		      ERRSID_SPKF_err_mem_alloc
		      ERRSID_SPKF_data_type_not_allow

        $DESCRIPTION  

        $WARNING      The output structure must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Loop on the rows' steps
                         - Loop on the columns' steps
                            - Reset the index of start and stop
                            - End columns' loop
                         - Write the output row in the output file
                      - End rows' loop

   $EH
   ========================================================================== */
   extern void SPKFPP_core        
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
			 /*IN    */ float                pfa,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SPKFPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 SPKFPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( SPKFPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SPKFIM_

      $DESCRIPTION  This procedure

                    SPKFIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define SPKFPM_
*/
