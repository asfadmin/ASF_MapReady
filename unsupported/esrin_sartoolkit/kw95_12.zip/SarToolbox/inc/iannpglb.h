/* ==========================================================================
   $MODULE_HEADER

      $NAME              IANN_PGLB

      $FUNCTION          global module.

      $ROUTINE           IANNPP_GETP_TagsCheck
                         IANNPP_GETP_BasicTagsCheck
                         IANNPP_PUTP_SetTag
                         IANNPP_MPHP_set_month
                         IANNPP_GETP_SetDateString
                         IANNPP_GETP_CheckValidTag

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       13-MAY-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <string.h>
#include <math.h>

#include "libname.h"
#include IANN_TAGS_H

#include ERRS_INTF_H
#include LDEF_INTF_H
#include IANN_INTF_H


#ifdef  IANN_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPD_TasksNumber

      $DESCRIPTION  It define the number of existing tasks that use the IANN
                    package to read the image annotations

   $EH
   ========================================================================== */
#define IANNPD_TasksNumber	    31

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPD_UPSFalseEast(North)_m

      $DESCRIPTION  They define the false origin of the UPS reference system.
		    Now the values are set to the ArchInfo SW values

   $EH
   ========================================================================== */
#define IANNPD_UPSFalseEast_m	    2.e+06
#define IANNPD_UPSFalseNorth_m	    2.e+06

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPD_boresigth_angle_deg

      $DESCRIPTION  It define the boresigth angle

   $EH
   ========================================================================== */
#define IANNPD_boresigth_angle_deg ( (float)2.03550e+01 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPD_reference_slant_range_m

      $DESCRIPTION  It define the Reference Slant Range default value

   $EH
   ========================================================================== */
#define IANNPD_reference_slant_range_m ( (float) 847000 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPD_radar_wavelength_m

      $DESCRIPTION  It define the boresigth angle

   $EH
   ========================================================================== */
#define IANNPD_radar_wavelength_m ( (float)5.656470e-02 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPD_sec_in_a_day

      $DESCRIPTION  It defines the number of seconds in a day

   $EH
   ========================================================================== */
#define IANNPD_sec_in_a_day   ( (INTx4)86400 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPD_semimajor_axis_km
                    IANNPD_semiminor_axis_km
                    
      $DESCRIPTION  They define the GEM6 ellipsoid semiaxes in km

   $EH
   ========================================================================== */
#define IANNPD_semimajor_axis_km ( (float)6.3781440e+03 )
#define IANNPD_semiminor_axis_km ( (float)6.3567590e+03 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPD_MPHSPH_N_STVec

      $DESCRIPTION  It defines the number of state vectors annotatec in the
                    MPH-SPH format

   $EH
   ========================================================================== */
#define IANNPD_MPHSPH_N_STVec     ( (INTx1)5 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPD_VMP_GR2SR_degree

      $DESCRIPTION  It defines the polynomial degree of the ground to slant
                    conversion for the VMP products

   $EH
   ========================================================================== */
#define IANNPD_VMP_GR2SR_degree   ( (INTx1)3 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPD_MPHSPH_GR2SR_div

      $DESCRIPTION  This is the divisor used in the MPH - SPH format to
                    evaluate the original form of the ground to slant
                    coefficients

   $EH
   ========================================================================== */
#define IANNPD_MPHSPH_GR2SR_div  ( (INTx4)16777216 )

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum IANNPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_necessary_tag

      $DESCRIPTION  It's a matrix that cross correlate the necessary tags
                    with each task and product type

      $WARNINGS     The values filling this array must be changed if the
                    numbers IANNPD_TasksNumber and/or IANNID_ProjTypeNum 
                    are incremented

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const UINTx4 IANNPC_necessary_tag[ IANNPD_TasksNumber ]
                                           [ IANNID_ProjTypeNum ]
                                           [ IANNID_ImageAnnotMaxNumber + 1 ] =
   { 
     /* no necessary tags, use for debug purposes */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 },
     },
     /* oversampling */
     { /* UTM */
       { 1, PIXEL_SPACING },
       /* UPS */
       { 1, PIXEL_SPACING },
       /* GROUND */
       { 1, PIXEL_SPACING },
       /* SLANT */
       { 6, PIXEL_SPACING, CROSS_DOPP_FREQ_CONST,
            CROSS_DOPP_FREQ_LINEAR, CROSS_DOPP_FREQ_QUAD, 
            DOPPL_CENTR_CUB_COEFF, PRF } 
     },
     /* undersampling */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* global statistic */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* local statistic */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* pca */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* media analysis */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* header analysis */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* quick look */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* image preview */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* coordinates retrieving */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* full resolution */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* support data */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* new format */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* amplitude to power */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* power to amplitude */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* complex to amplitude */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* pixel to float */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* gain convertion */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* tiff generation */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* bil generation */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* annotation dump */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* import raster */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* linear to db */
     { /* UTM */
       { 1, PIXEL_TYPE },
       /* UPS */
       { 1, PIXEL_TYPE },
       /* GROUND */
       { 1, PIXEL_TYPE },
       /* SLANT */
       { 1, PIXEL_TYPE }
     },
     /* speckle filtering */
     { /* UTM */
       { 1, PIXEL_TYPE },
       /* UPS */
       { 1, PIXEL_TYPE },
       /* GROUND */
       { 1, PIXEL_TYPE },
       /* SLANT */
       { 1, PIXEL_TYPE }
     },
     /* coregistration */
     { /* UTM */
       { 10, TOP_LEFT_EAST, TOP_LEFT_NORTH, UTM_FALSE_EAST, UTM_FALSE_NORTH,
             UTM_SCALE_FACTOR, UTM_CENTER_PROJ_LON, ELLIPSOID_SEMIMAJOR_AXIS,
             ELLIPSOID_SEMIMINOR_AXIS, PIXEL_SPACING, LINE_SPACING },
       /* UPS */
       { 9,  TOP_LEFT_EAST, TOP_LEFT_NORTH, UPS_SCALE_FACTOR, UPS_CENTER_PROJ_LAT, 
             UPS_CENTER_PROJ_LON, ELLIPSOID_SEMIMAJOR_AXIS,
             ELLIPSOID_SEMIMINOR_AXIS, PIXEL_SPACING, LINE_SPACING },
       /* GROUND */
       { 32, SAMPLING_RATE, RADAR_WAVELEN, TIME_INTERVAL_DATA_POINT, NB_DATA_POINTS,
             X_SAT_1, X_SAT_2, Y_SAT_1, Y_SAT_2, Z_SAT_1, Z_SAT_2,
             VX_SAT_1, VX_SAT_2, VY_SAT_1, VY_SAT_2, VZ_SAT_1, VZ_SAT_2,
             PIXEL_SPACING, CENTRE_GEODETIC_LAT, CENTRE_GEODETIC_LON,
             ELLIPSOID_SEMIMAJOR_AXIS, ELLIPSOID_SEMIMINOR_AXIS, PROCESSOR_NAME,
             GR_SR_POL_DEGREE, GR_SR_COEFF_1, GR_SR_COEFF_2, GR_SR_COEFF_3,
             ZERO_DOPP_RANGE_FIRST_TIME, ZERO_DOPP_AZIM_FIRST_TIME, 
             YEAR_DATA_POINT, MONTH_DATA_POINT, DAY_DATA_POINT, SECOND_OF_DAY },
       /* SLANT */
       { 30, PRF, RADAR_WAVELEN, TIME_INTERVAL_DATA_POINT, NB_DATA_POINTS,
             X_SAT_1, X_SAT_2, Y_SAT_1, Y_SAT_2, Z_SAT_1, Z_SAT_2,
             VX_SAT_1, VX_SAT_2, VY_SAT_1, VY_SAT_2, VZ_SAT_1, VZ_SAT_2,
             PIXEL_SPACING, CENTRE_GEODETIC_LAT, CENTRE_GEODETIC_LON,
             ELLIPSOID_SEMIMAJOR_AXIS, ELLIPSOID_SEMIMINOR_AXIS,
             ZERO_DOPP_RANGE_FIRST_TIME, ZERO_DOPP_AZIM_FIRST_TIME,
             YEAR_DATA_POINT, MONTH_DATA_POINT, DAY_DATA_POINT, SECOND_OF_DAY,
             CROSS_DOPP_FREQ_CONST, CROSS_DOPP_FREQ_LINEAR,
             CROSS_DOPP_FREQ_QUAD }
     },
     /* coherence image generation */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     },
     /* backscattering image */
     { /* UTM */
       { 2, PIXEL_TYPE, PROCESSOR_RANGE_COMPRESSION },
       /* UPS */
       { 2, PIXEL_TYPE, PROCESSOR_RANGE_COMPRESSION },
       /* GROUND */
       { 2, PIXEL_TYPE, PROCESSOR_RANGE_COMPRESSION },
       /* SLANT */
       { 2, PIXEL_TYPE, PROCESSOR_RANGE_COMPRESSION },
     },
     /* adc image for backscattering */
     { /* UTM */
       { 2, ROW_TRANSIENT, COL_TRANSIENT },
       /* UPS */
       { 2, ROW_TRANSIENT, COL_TRANSIENT },
       /* GROUND */
       { 2, ROW_TRANSIENT, COL_TRANSIENT },
       /* SLANT */
       { 2, ROW_TRANSIENT, COL_TRANSIENT },
     },
     /* gamma image */
     { /* UTM */
       { 1, PIXEL_TYPE },
       /* UPS */
       { 1, PIXEL_TYPE },
       /* GROUND */
       { 1, PIXEL_TYPE },
       /* SLANT */
       { 1, PIXEL_TYPE },
     },
     /* adc saturation correction */
     { /* UTM */
       { 0 },
       /* UPS */
       { 0 },
       /* GROUND */
       { 0 },
       /* SLANT */
       { 0 }
     }
   };
#else
   GLOBAL const UINTx4 IANNPC_necessary_tag[ IANNPD_TasksNumber ]
                                           [ IANNID_ProjTypeNum ]
                                           [ IANNID_ImageAnnotMaxNumber + 1];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_map

      $DESCRIPTION  This constant variable contains the strings to match to
                    recover the map projection of the product

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const char IANNPC_map[][ 4 ] = {
      "UTM",                /* string to match for UTM projection */
      "TRA",                /* string to match for UTM projection */
      "UPS",                /* string to match for UPS projection */
      "GRO",             /* string to match for ground projection */
      "SLA"               /* string to match for slant projection */
   };
#else
   GLOBAL const char IANNPC_map[][ 4 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_sat

      $DESCRIPTION  This constant vector contains the strings to match to
                    recover the satellite of the product

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const char IANNPC_sat[][ 5 ] = {
      "ERS1",                /* string to mathc for ERS 1 satellite */
      "ERS2"                 /* string to mathc for ERS 2 satellite */
   };
#else
   GLOBAL const char IANNPC_sat[][ 5 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_prod

      $DESCRIPTION  This constant vector contains the strings to match to
                    recover the product name

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const char IANNPC_prod[][ 4 ] = {
      "RAW",                 /* string to mathc for RAW product */
      "SLC",                 /* string to mathc for SLC product */
      "LCI",                 /* string to mathc for SLCI product */
      "PRI",                 /* string to mathc for PRI product */
      "GEC",                 /* string to mathc for GEC product */
      "GTC"                  /* string to mathc for GTC product */
   };
#else
   GLOBAL const char IANNPC_prod[][ 4 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_pixt

      $DESCRIPTION  This constant vector contains the strings to match to
                    recover the product pixel type

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const char IANNPC_pixt[][ 6 ] = {
      "COMPL",              /* string to match for complex images */
      "AMPLI",              /* string to match for amplitude images */
      "POWER"               /* string to match for power images */
   };
#else
   GLOBAL const char IANNPC_pixt[][ 6 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_proc

      $DESCRIPTION  This constant variable contains the strings to match to
                    recover the processing PAF generator of the product

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const char IANNPC_proc[][ 3 ] = {
      "CP",                 /* string to match for Central PAF products */
      "D-",                 /* string to match for German PAF products */
      "U-",                 /* string to match for U. K. PAF products */
      "IP",                 /* string to match for IPAF products */
      "AP",                 /* string to match for U.S.A. PAF products */
      "SP"                  /* string to match for Singapore PAF products */
   };
#else
   GLOBAL const char IANNPC_proc[][ 3 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_swproc

      $DESCRIPTION  This constant variable contains the strings to match to
                    recover the software processor used in the product

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const char IANNPC_swproc[ ][ 5 ] = {
      "VMP-",                /* string to match for VMP products */
      "MSAR",                /*       "         "            */
      "SAR-",                /* string to match for ESAR products */
      "BAN-"                 /* string to match for Bangkok products */
   };
#else
   GLOBAL const char IANNPC_swproc[][ 5 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_iscale

      $DESCRIPTION  This constant vector contains the strings to match to
                    recover the product image scale

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const char IANNPC_iscale[][ 6 ] = {
      "LINEA",              /* string to match for linear scale images */
      "DB"                  /* string to match for db scale images */
   };
#else
   GLOBAL const char IANNPC_iscale[][ 6 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_pres

      $DESCRIPTION  This constant vector contains the strings to match to
                    recover the product presentation

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const char IANNPC_pres[][ 7 ] = {
      "NORMAL",              /* string to match for normal rendered images */
      "GEO"                  /* string to match for geo rendered images */
   };
#else
   GLOBAL const char IANNPC_pres[][ 7 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_orbdir

      $DESCRIPTION  This constant vector contains the strings to match to
                    recover the orbit direction

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const char IANNPC_orbdir[][ 6 ] = {
      "ASCEN",                /* string to match for ascending orbit */
      "DESCE"                 /* string to match for descending orbit */
   };
#else
   GLOBAL const char IANNPC_orbdir[][ 6 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_prcrcmp

      $DESCRIPTION  This constant vector contains the strings to match to
                    recover the orbit direction

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL const char IANNPC_prcrcmp[][ 10 ] = {
      "EXTRACTED",                /* string to match for extracted chirp */
      "SYNTHETIC"                 /* string to match for nominal chirp */
   };
#else
   GLOBAL const char IANNPC_prcrcmp[][ 10 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPC_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* const IANNPC_
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct IANNPT_*_def { 

   typedef struct IANNPT_*_def IANNPT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IANNPV_found_tag

      $DESCRIPTION  This array is filled with true or false flags to recover
                    founded or not founded tags in the MPH - SPH format

   $EH
   ========================================================================== */
#ifdef IANN_GLBL
   GLOBAL LDEFIT_boolean IANNPV_found_tag[ IANNID_ImageAnnotMaxNumber ];
#else
   GLOBAL LDEFIT_boolean IANNPV_found_tag[];
#endif

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IANNPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 IANNPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_GETP_TagsCheck

        $TYPE         PROCEDURE

        $INPUT        imanum	    : number of the image among that of the
                                      tool

        $MODIFIED     NONE

        $OUTPUT       invalid_tags  : pointer to the array with the tags that
                                      are invalid in their range of variation
                      count	    : counter of the invalid tags

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the image
                                                  annotations

        $RET_STATUS   ERRSID_IANN_not_allow_imanum

        $DESCRIPTION  This procedure checks if the tags annotated are in their
                      range of validity

        $WARNING      The check has no validity for the tags that are not
                      found; so the use of the vector of invalid tags must
                      always follow the check on the found tags

   $EH
   ========================================================================== */
   extern void IANNPP_GETP_TagsCheck
                        (/*IN    */ UINTx1               imanum,
                         /*   OUT*/ UINTx4              *count,
                         /*   OUT*/ UINTx4              *invalid_tags,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_GETP_BasicTagsCheck

        $TYPE         PROCEDURE

        $INPUT        imanum	: number of the image among that of the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the image
                                                  annotations

        $RET_STATUS   ERRSID_IANN_not_allow_imanum
                      ERRSID_IANN_basic_tag_invalid

        $DESCRIPTION  This procedure checks if the basic image tags are in their
                      range of validity

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void IANNPP_GETP_BasicTagsCheck
                        (/*IN    */ UINTx1               imanum,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_PUTP_SetTag

        $TYPE         PROCEDURE

        $INPUT        tag_num     : tag number
                      p_tag       : pointer to the tag value
                      tag_type    : tag type
                      out_type    : the output tag type among the predefined
                                    type in the TIFS_INTF.H include file
                      chan        : channel of the opened TIFF file in which to
                                    store the tag_val
                      img         : image number in the TIFF file

        $MODIFIED     NONE

        $OUTPUT       The tag is stored in the file

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IANN_tag_type_not_known

        $DESCRIPTION  This procedure store the tag passed in input in the file
                      TIFF with the channel <chan>

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void IANNPP_PUTP_SetTag
                        (/*IN    */ UINTx4               tag_num,
                         /*IN    */ void                *p_tag,
                         /*IN    */ UINTx1               tag_type,
                         /*IN    */ UINTx1               out_type,
                         /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_MPHP_set_month

        $TYPE         PROCEDURE

        $INPUT        sst : string to convert into number

        $MODIFIED     NONE

        $OUTPUT       num : number of the month

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure assignes the sequential number of the 
                      month in the year

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void IANNPP_MPHP_set_month
                        (/*IN    */ char                *sst,
                         /*   OUT*/ INTx2               *num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_GETP_SetDateString

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     str : string to modify

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IANN_invalid_date

        $DESCRIPTION  This procedure converts a string with a UTC date in the
                      exact format: DD-MMM-YYYY HH:MM:SS.SSSS putting the
                      character '0' where it's loose

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void IANNPP_GETP_SetDateString
                        (/*IN    */ char                *str,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_GETP_CheckValidTag

        $TYPE         PROCEDURE

        $INPUT        tag        : string tag to check

        $MODIFIED     NONE

        $OUTPUT       valid_flag : flag to indicate the validity of the tag

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure checks if a tag is a valid or has an
                      invalid value as a certain number of numbers 9

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void IANNPP_GETP_CheckValidTag
                        (/*IN    */ char                *tag,
                         /*   OUT*/ LDEFIT_boolean      *valid_flag,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IANNPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void IANNPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) IANNIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( IANNPF_GLBL_set_error(status_code) )


