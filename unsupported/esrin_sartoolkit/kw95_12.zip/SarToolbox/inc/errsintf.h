/* ==========================================================================
   $MODULE_HEADER

      $NAME          ERRS_INTF

      $FUNCTION      ERRS global low level definition package

      $DESCRIPTION   The ERRS package holds all low level global definition

      $ROUTINE       ERRSIP_EPEL_exit_proc_err_log
                     ERRSIF_HMSG_register_error_msgs
                     ERRSIP_HPEL_process_init
                     ERRSIP_HPEL_process_shutdown
                     ERRSIP_HPEL_trace_proc_err_log
                     ERRSIP_RFLG_read_flag
                     ERRSIP_WPEL_write
		     ERRSIM_in_parms
		     ERRSIM_out_parms
		     ERRSIM_verbose
		     ERRSIM_loop
		     ERRSIM_message_on_monitor
		     ERRSIM_init_routine
		     ERRSIM_close_routine
		     ERRSIM_on_err_goto_exit
		     ERRSIM_on_err_write_and_exit
		     ERRSIM_set_error
		     ERRSIM_get_pckg_code
		     ERRSIM_print_warning
                     
      $HISTORY

            SCR NO.      DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       21-SEP-92   DD/FR       Initial Release

    $EH
   ========================================================================== */

/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */
#ifndef ERRS
#define ERRS ERRS

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern

/* ==========================================================================
                          INCLUDE DECLARATION SECTION
   ========================================================================== */

#ifdef  __WIN95__
#include "windows.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "libname.h"

#include PORT_DEFS_H
#if defined(__HAVEIDL__)
#include IDLI_INTF_H
#endif

#ifdef ERRS_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                          DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSID_in_parms
                    ERRSID_out_parms
                    ERRSID_verbose
                    ERRSID_loop
                    ERRSID_msg
                    ERRSID_not_used_6
                    ERRSID_not_used_7
                    ERRSID_not_used_8

      $DESCRIPTION  This const handles the string of the logical name for the 
                    FLAGFILE.

   $EH
   ========================================================================== */
#define ERRSID_in_parms      0x80
#define ERRSID_out_parms     0x40
#define ERRSID_verbose       0x20
#define ERRSID_loop          0x10
#define ERRSID_msg           0x08
#define ERRSID_init_close    0x04
#define ERRSID_not_used_7    0x02
#define ERRSID_not_used_8    0x01

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSID_max_routine_stack

      $DESCRIPTION  Maximum number of dumped routine

   $EH
   ========================================================================== */
#define ERRSID_max_routine_stack 20

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         DATA_TYPE

      $DESCRIPTION  It enumerates the possible types of data handled by
                    Toolbox

   $EH
   ========================================================================== */
   enum DATA_TYPE {
      DATA_TYPE_undef,
      DATA_TYPE_INTx1,
      DATA_TYPE_INTx2,
      DATA_TYPE_INTx4,
      DATA_TYPE_INTx8,
      DATA_TYPE_UINTx1,
      DATA_TYPE_UINTx2,
      DATA_TYPE_UINTx4,
      DATA_TYPE_UINTx8,
      DATA_TYPE_float,
      DATA_TYPE_double
   };

/* ==========================================================================
   $DECLARATION_HEADER
 
      $NAME         ERRSID_start_time
 
      $DESCRIPTION  Default stbx home symbol directory
 
   $EH
   ========================================================================== */
#define ERRSID_stbxhome "STBXHOME"

/* ==========================================================================
   $DECLARATION_HEADER
 
      $NAME         ERRSID_dir_separator
 
      $DESCRIPTION  Directory separator symbol
 
   $EH
   ========================================================================== */
#ifdef __UNIX__
#define ERRSID_dir_separator "/"
#endif
 
#if defined __MC68K__ || defined __POWERPC__
#define ERRSID_dir_separator ":"
#endif
 
#ifdef __VMS__
#define ERRSID_dir_separator "."
#endif
 
#ifdef __WIN95__
#define ERRSID_dir_separator "\\"
#endif
 
#ifdef __DOS__
#define ERRSID_dir_separator "\\"
#endif

/* ==========================================================================
                          CONST DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIC_flagfile

      $DESCRIPTION  Handle the string of the logical name for the FLAGFILE.

   $EH
   ========================================================================== */
#ifdef ERRS_GLBL
   GLOBAL const char ERRSIC_flagfile[] = "FLAGFILE";
#else
   GLOBAL const char ERRSIC_flagfile[];
#endif

/* ==========================================================================
                          TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         DATA_TYPEIT

      $DESCRIPTION  This type defines the possible data types

   $EH
   ========================================================================== */
   typedef enum DATA_TYPE DATA_TYPEIT;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIT_package_name

      $DESCRIPTION  This type defines the executable module;
                    this is used for Windows Modules.

   $EH
   ========================================================================== */
   typedef char ERRSIT_package_name[16];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIT_proc_name

      $DESCRIPTION  This type defines the process name string.

   $EH
   ========================================================================== */
   typedef char ERRSIT_proc_name[32];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIT_status

      $DESCRIPTION  This type defines the return status code.

   $EH
   ========================================================================== */
   typedef UINTx4 ERRSIT_status;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIT_flag

      $DESCRIPTION  This type handles the process flags.

   $EH
   ========================================================================== */
   typedef UINTx1 ERRSIT_flag;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIT_proc_class

      $DESCRIPTION  This type defines the process class string.
                    The class name is in this format :
                       xxxv_Xmmm
                    as :
                    STBX_XMAI

   $EH
   ========================================================================== */
   typedef char ERRSIT_proc_class[10];
 
/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIT_unique_id

      $DESCRIPTION  This type defines the unique id used for process id.

   $EH
   ========================================================================== */
   typedef UINTx4 ERRSIT_unique_id;
 
/* ==========================================================================
                      VARIABLES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIV_HERR_vector_message

      $DESCRIPTION  This var is the array of packages errors arry string;

   $EH
   ========================================================================== */
#ifdef ERRS_GLBL
   GLOBAL char ***ERRSIV_HERR_vector_message = NULL;
#else
   GLOBAL char ***ERRSIV_HERR_vector_message;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIV_vector_message_entry_no

      $DESCRIPTION  This var say the number of entyes in the  array of packages
                    errors arry string;

   $EH
   ========================================================================== */
#ifdef ERRS_GLBL
   GLOBAL INTx4 ERRSIV_vector_message_entry_no = 0;
#else
   GLOBAL INTx4 ERRSIV_vector_message_entry_no;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIV_level

      $DESCRIPTION  This var handles the number of routine nesting level in the
                    PROCESS ERROR LOG;

   $EH
   ========================================================================== */

#ifdef ERRS_GLBL
   GLOBAL UINTx4 ERRSIV_level = 0;
#else
   GLOBAL UINTx4 ERRSIV_level;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIV_routine_stack

      $DESCRIPTION  This var keeps actual routine stack up to 
                    ERRSID_max_routine_stack

   $EH
   ========================================================================== */

#ifdef ERRS_GLBL
   GLOBAL ERRSIT_proc_name ERRSIV_routine_stack[ ERRSID_max_routine_stack ] 
	= { "", "", "", "", "","", "", "", "", "",
	    "", "", "", "", "","", "", "", "", "" };
#else
   GLOBAL ERRSIT_proc_name ERRSIV_routine_stack[ ERRSID_max_routine_stack ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIV_dump_error

      $DESCRIPTION  General variable for error dump on screen

   $EH
   ========================================================================== */

#ifdef ERRS_GLBL
   GLOBAL INTx4 ERRSIV_dump_error = 1;
#else
   GLOBAL INTx4 ERRSIV_dump_error;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIV_dump_to_idl

      $DESCRIPTION  General variable for error dump on screen

   $EH
   ========================================================================== */

#ifdef ERRS_GLBL
   GLOBAL INTx4 ERRSIV_dump_to_idl = 0;
#else
   GLOBAL INTx4 ERRSIV_dump_to_idl;
#endif

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_EPEL_exit_proc_err_log

      $FUNCTION     Write a procedure exit message in the PROCESS ERROR LOG

      $INPUT        routine_name              : routine name
                    ret_status                : return status

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid

      $RET_STATUS   NONE

      $DESCRIPTION  This routine write in the process error log an  exit
                    string containing the routine name and the exit time.
                    Decrement the nesting level.

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ERRSIP_EPEL_exit_proc_err_log
                        ( /*IN    */ const ERRSIT_proc_name proc_name,
                          /*IN    */ ERRSIT_status          ret_status,
                          /*   OUT*/ ERRSIT_status         *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_HPEL_process_init

      $FUNCTION     Initialize a process

      $INPUT        Proc_class                 : Process Class xxxv_Xmmm

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure performs all initialization activities.

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ERRSIP_HPEL_process_init
                        ( /*IN    */ const ERRSIT_proc_class   proc_class,
                          /*   OUT*/ ERRSIT_status            *status_code );


/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_HPEL_process_shutdown

      $FUNCTION     Close a process

      $INPUT        Proc_name                 : Process name

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure performs all closing activities. No
                     strong error checking is done.

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ERRSIP_HPEL_process_shutdown
                        ( /*IN    */ const ERRSIT_proc_class  proc_class,
                          /*   OUT*/ ERRSIT_status           *status_code );


/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_HPEL_trace_proc_err_log

      $FUNCTION     Write a string into the process error log

      $INPUT        string_parameter          : pointer to the string to print

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid;

      $RET_STATUS   ERRSID_err_file_write_error

      $DESCRIPTION  This procedure writes a line into the process error log.

      $WARNING      If a single character without terminator has been passed
                    as input a runtime error may occour. If a string with
                    length > 1024 has been passed as input a message will be
                    written in the process_error_log and the string will not
                    be written.

   $EH
   ========================================================================== */
   extern void ERRSIP_HPEL_trace_proc_err_log
                        ( /*IN    */ char           *string_parameter,
                          /*   OUT*/ ERRSIT_status  *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_IPEL_init_proc_err_log

      $FUNCTION     Write an initialization message in the PROCESS ERROR LOG

      $INPUT        routine_name              : routine name

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid
                    ERRSPV_level

      $RET_STATUS   ERRSID_err_file_write_error

      $DESCRIPTION  This routine writes in the process error log an 
                    initialization string containing the routine name and the
                    start time.  This routine uses the nesting level.

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ERRSIP_IPEL_init_proc_err_log
                        ( /*IN    */ const ERRSIT_proc_name   proc_name,
                          /*   OUT*/ ERRSIT_status           *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ERRSIP_HMSG_error_message

        $TYPE         PROCEDURE

        $INPUT        routine_name   : current routine
                      status_code    : current status_code
                      message        : custom message: can be NULL
                      error_line     : module line number.
                      process_flag   : process flag

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Write Log Messages

        $WARNING      Use ERRSIM_on_err_goto_exit, ERRSIM_on_err_write_and_exit
		      and ERRSIM_set_error macros instead to access this 
		      function

        $PDL

   $EH
   ========================================================================== */
   extern void ERRSIP_HMSG_error_message
                        (/*IN    */ const ERRSIT_proc_name routine_name,
                         /*IN    */ ERRSIT_status          status_code,
                         /*IN    */ char                  *message,
                         /*IN    */ INTx4                  error_line,
                         /*IN    */ ERRSIT_flag            process_flag );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ERRSIP_IDLI_error_message

        $TYPE         PROCEDURE

        $INPUT        routine_name   : current routine
                      status_code    : current status_code
                      message        : custom message: can be NULL
                      error_line     : module line number.
                      process_flag   : process flag

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Write Log Messages on IDL interface

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void ERRSIP_IDLI_error_message
                        (/*IN    */ const ERRSIT_proc_name routine_name,
                         /*IN    */ ERRSIT_status          status_code,
                         /*IN    */ char                  *message,
                         /*IN    */ INTx4                  error_line,
                         /*IN    */ ERRSIT_flag            process_flag );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ERRSIF_HMSG_register_error_msgs

        $TYPE         function

        $INPUT        message_array      : Package error messages array.

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern INTx4 ERRSIF_HMSG_register_error_msgs
                        ( /*IN    */ char         **message_array );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_RFLG_read_flag

      $FUNCTION     Read the flag list

      $INPUT        routine_name              : routine name

      $MODIFIED     NONE

      $OUTPUT       process_flag              : Flag setting

      $GLOBAL       ERRSPA_global_flag        : Read

      $RET_STATUS   ERRSID_err_pnt_alloc_error

      $DESCRIPTION  Read the flag setting.

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ERRSIP_RFLG_read_flag
                        ( /*IN    */ const ERRSIT_proc_name  routine_name,
                          /*   OUT*/ ERRSIT_flag	    *process_flag,
                          /*   OUT*/ ERRSIT_status	    *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_WPEL_write

      $FUNCTION     Write a string to the process error log

      $INPUT        routine_name           : Name of calling routine
                    string                 : Input string

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid

      $RET_STATUS   ERRSID_err_file_write_error

      $DESCRIPTION  This procedure inserts a new line into the process
                    error log containing the string message.

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ERRSIP_WPEL_write
                        ( /*IN    */ const ERRSIT_proc_class   routine_name,
                          /*IN    */ char                     *string,
                          /*   OUT*/ ERRSIT_status            *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_WPEL_dump_stack

      $FUNCTION     Write stack routine on PEL

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid;

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure prints the actual stack of calls

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ERRSIP_WPEL_dump_stack
                        ( /*OUT   */ ERRSIT_status         *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIF_LODT_out_date

      $FUNCTION     Get the date time in output format

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       out_date_time             : Is the pointer to an empty
                                                string of 25 char.

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This function get the system date and time.
                    The time is returned  in the output standard format:

                       DD-MON-YYYY HH:MM:SS.CCC

                    The function return the pointer to the data time and the
                    null pointer if an error occur.

      $WARNING      It is necessary that the space for the out_data_time
                    string is already allocated.

   $EH
   ========================================================================== */
   extern char *ERRSIF_LODT_out_date
                              (/*  OUT*/ char *out_date_time);

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIM_in_parms
                    ERRSIM_out_parms
                    ERRSIM_verbose
                    ERRSIM_loop

      $DESCRIPTION  These macros check if a flag is set.

   $EH
   ========================================================================== */
#define ERRSIM_in_parms(flag) ((UINTx1) flag & ERRSID_in_parms) 
#define ERRSIM_out_parms(flag) ((UINTx1) flag & ERRSID_out_parms) 
#define ERRSIM_verbose(flag) ((UINTx1) flag & ERRSID_verbose) 
#define ERRSIM_loop(flag) ((UINTx1) flag & ERRSID_loop) 
#define ERRSIM_message_on_monitor(flag) ((UINTx1) flag & ERRSID_msg)
#define ERRSIM_init_close(flag) ((UINTx1) flag & ERRSID_init_close)

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIM_init_routine
                    ( (*IN    *) ERRSIT_proc_name  routine_name,
                      (*IN    *) ERRSIT_flag      *process_flag,
                      (*   OUT*) ERRSIT_status    *status_code )

      $DESCRIPTION  Read the flag for the current routine.
                    Write a routine header to the process log file if the flag
                    has been set for the routine.
                    Note that the status_code is a pointer.

   $EH
   ========================================================================== */
#define ERRSIM_init_routine( routine_name, process_flag, status_code)   \
{                                                                       \
   ERRSIV_level++;                                                      \
   /* status_code is a pointer */                                       \
   ERRSIP_RFLG_read_flag( routine_name, process_flag, status_code );    \
                                                                        \
   if ( ERRSIM_init_close ( *process_flag ) )                           \
   {                                                                    \
      ERRSIP_IPEL_init_proc_err_log( routine_name, status_code);        \
   }                                                                    \
									\
   if( ERRSIV_level< ERRSID_max_routine_stack ) {                       \
      strcpy( ERRSIV_routine_stack[ ERRSIV_level ], routine_name );     \
   }                                                                    \
}                                                                       \

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIM_close_routine
                    ( (*IN    *) ERRSIT_proc_name routine_name,
                      (*IN    *) ERRSIT_flag      *flag,
                      (*IN    *) ERRSIT_status    ret_status,
                      (*   OUT*) ERRSIT_status    *status_code)

      $DESCRIPTION  Write a routine closing header to the process error log file
                    if the flag has been set for the routine.
                    Note that the status_code is a pointer.

   $EH
   ========================================================================== */
#define ERRSIM_close_routine( routine_name, flag, ret_status, status_code) \
{                                                                          \
   /* status_code is a pointer */                                          \
   if ( ERRSIM_init_close ( *flag ) )                                      \
   {                                                                       \
      ERRSIP_EPEL_exit_proc_err_log( routine_name,                         \
                                     ret_status,                           \
                                     status_code);                         \
   }                                                                       \
   ERRSIV_level--;                                                         \
}                                                                          \

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIM_on_err_goto_exit
                    ( (*   OUT*) ERRSIT_status    status_code )

      $DESCRIPTION  On error goto error_exit Label;

   $EH
   ========================================================================== */
#define ERRSIM_on_err_goto_exit( status_code )                          \
{									\
   if( ERRSIM_get_pckg_code( status_code ) != ERRSID_normal )           \
   {									\
      goto error_exit;							\
   }									\
}

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME    ERRSIM_on_err_write_and_exit
                    ( (*IN    *) ERRSIT_status    status_code,
                      (*IN    *) char             message )

      $DESCRIPTION  On error write error log mesagge and goto error_exit Label;

   $EH
   ========================================================================== */
#define ERRSIM_on_err_write_and_exit( status_code, message )            \
{                                                                       \
   if( ERRSIM_get_pckg_code( status_code ) != ERRSID_normal )           \
   {                                                                    \
      if( ERRSIV_dump_to_idl == 1 )                                     \
      {                                                                 \
         ERRSIP_IDLI_error_message                                      \
                        ( routine_name,					\
                          status_code,					\
                          message,					\
                          __LINE__ - 9,                                 \
                          process_flag );				\
      }                                                                 \
      else                                                              \
      {                                                                 \
      ERRSIP_HMSG_error_message						\
                        ( routine_name,					\
                          status_code,					\
                          message,					\
                          __LINE__ - 9,                                 \
                          process_flag );				\
      }                                                                 \
      goto error_exit;                                                  \
   }                                                                    \
}

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIM_set_error
                    ( (*   OUT*) ERRSIT_status    status_code )

      $DESCRIPTION  Set status_code write error log mesagge and exit;

   $EH
   ========================================================================== */
#define ERRSIM_set_error( status_code, error_code, message )            \
{                                                                       \
   *(status_code) = STC( error_code );                                  \
                                                                        \
   if( ERRSIV_dump_to_idl == 1 )                                        \
   {                                                                    \
      ERRSIP_IDLI_error_message                                         \
                        ( routine_name,                                 \
                         *status_code,                                  \
                          message,                                      \
                          __LINE__ - 1,                                 \
                          process_flag );                               \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      ERRSIP_HMSG_error_message                                         \
                        ( routine_name,                                 \
                         *status_code,                                  \
                          message,                                      \
                          __LINE__ - 1,                                 \
                          process_flag );                               \
   }                                                                    \
   ERRSIP_WPEL_dump_stack( &log_status_code );                          \
   goto error_exit;                                                     \
}

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIM_get_pckg_code
                    ( (*   OUT*) ERRSIT_status    *status_code )

      $DESCRIPTION  Return the package status_code 

   $EH
   ========================================================================== */
#define ERRSIM_get_pckg_code( status_code ) ( status_code & 0x0000FFFF )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSIM_print_warning

      $DESCRIPTION  Prints a warning message on stdout lefting the status_code
                    unmodified

   $EH
   ========================================================================== */
#ifdef __VMS__
#ifdef __HAVEIDL__
#define ERRSIM_print_warning( message )                                 \
{                                                                       \
   char msg[132];                                                       \
   sprintf(msg, "Warning in %s at line %d. %s",                         \
      routine_name, __LINE__, message);                                 \
   IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, " " );                      \
   IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, msg );                      \
   IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, " " );                      \
}
#else
#define ERRSIM_print_warning( message )                                 \
{                                                                       \
   fprintf(stdout, "\n\nWarning in %s at line %d. %s\n",                \
                   routine_name, __LINE__, message);                    \
}
#endif
#else
#ifdef __HAVEIDL__
#define ERRSIM_print_warning( message )                                 \
{                                                                       \
   char msg[132];                                                       \
   sprintf(msg, "%s warning. %s",                                       \
      ERRSIV_routine_stack[ 0 ], message);                              \
   IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, " " );                      \
   IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, msg );                      \
   IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, " " );                      \
}
#else
#define ERRSIM_print_warning( message )                                 \
{                                                                       \
   fprintf(stdout, "\n\n%s warning. %s\n",                              \
                   ERRSIV_routine_stack[ 0 ], message);                 \
}
#endif
#endif

/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error */
#define ERRSID_normal                    0
#define ERRSID_error                     1
#define ERRSID_recoverable_error         2


/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */
#ifdef ERRS_GLBL
   GLOBAL char *ERRSIV_ERRS_error_message[] = { "No error happens",
                                                "Generic error happens",
                                                "Recoverable Error",
                                              };
#else
   GLOBAL char *ERRSIV_ERRS_error_message[];
#endif

#endif
