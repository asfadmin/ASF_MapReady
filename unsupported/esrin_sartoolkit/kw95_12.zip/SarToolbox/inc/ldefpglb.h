/* ==========================================================================
   $MODULE_HEADER

      $NAME              LDEF_PGLB

      $FUNCTION          global module.

      $ROUTINE           LDEFPP_

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       gg-mmm-aa     DD       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H


#ifdef  LDEF_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFPD_start_time

      $DESCRIPTION  Default start time

   $EH
   ========================================================================== */
#define LDEFPD_start_time 738293792

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFPD_block_size

      $DESCRIPTION  Number of bytes in a block

   $EH
   ========================================================================== */
#define LDEFPD_block_size       512

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* enum LDEFPE_ */

/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFPC_

      $DESCRIPTION  The LDEFPC_

   $EH
   ========================================================================== */
/* const LDEFPC_   = ; */

/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFPT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/* struct LDEFPT_*_def { 

   typedef struct LDEFPT_*_def LDEFPT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         LDEFPV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME             LDEFPF_GLBL_set_error;

      $FUNCTION         Return global error from the package error. On first
                        call the package message array is registered.

      $INPUT            local_staus_code    : local package status code.

      $MODIFIED         NONE

      $OUTPUT           Global status code.

      $GLOBAL           NONE

      $RET_STATUS       NONE

      $DESCRIPTION      Return global error from the package error. On first
                        call the package message array is registered.

      $WARNING          NONE


   ========================================================================== */
   extern INTx4 LDEFPF_GLBL_set_error
                       ( /*IN    */ ERRSIT_status  local_staus_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         LDEFPP_

      $DESCRIPTION  

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* extern void LDEFPP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         LDEFPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void LDEFPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) LDEFIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STC

      $TYPE         MACRO

      $INPUT        status_code

      $MODIFIED     NONE

      $OUTPUT       Global error code

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure...

                    STC( (*IN    *)ERRSIT_status  status_code );

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
#define STC( status_code ) ( LDEFPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         LDEFLM_abs
                    ( (*IN    *) x )

      $DESCRIPTION  Returns the abs of _x

   $EH
   ========================================================================== */
#define LDEFLM_abs( _x ) ( (_x) > 0 ? (_x) : -(_x) )


