/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_INTF

      $FUNCTION          Product Media Deformatting Service interface module.

      $ROUTINE           PMDSIP_Deformat
                         PMDSIP_VIEW_CreatePreviewFile
                         PMDSIP_RETR_CheckImage
                         PMDSIP_GRID_DrawArea
                         PMDSIP_MDAN_MediaAnalysis
                         PMDSIP_SUPP_SetSupportData
                         PMDSIP_STRE_TiffFileData
		         
      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       07-FEB-97     AG       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef PMDS
#define PMDS PMDS


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include DEVS_INTF_H
#include GIOS_INTF_H
#include MATH_INTF_H
#include IANN_INTF_H

#ifdef PMDS_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define PMDSID_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum PMDSIE_
*/

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSIT_product_type

      $DESCRIPTION  Enumerated for different product types

   $EH
   ========================================================================== */
   enum PMDSIE_product_type {
      PMDSIE_unk_prod,
      PMDSIE_raw_prod,
      PMDSIE_slc_prod,
      PMDSIE_slci_prod,
      PMDSIE_pri_prod,
      PMDSIE_gec_prod,
      PMDSIE_gtc_prod
   };
   typedef enum PMDSIE_product_type PMDSIT_product_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSIT_deformat_mode

      $DESCRIPTION  Enumerated for different deformatting modes

   $EH
   ========================================================================== */
   enum PMDSIE_deformat_mode {
      PMDSIE_HeaderDecodeMode,
      PMDSIE_FullResolutionMode,
      PMDSIE_QuickLookMode
   };
   typedef enum PMDSIE_deformat_mode PMDSIT_deformat_mode;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSIT_drawing_mode

      $DESCRIPTION  Enumerated for different drawing mode(s)

   $EH
   ========================================================================== */
   enum PMDSIE_drawing_mode {
      PMDSIE_drawing_none,
      PMDSIE_drawing_overwrite,
      PMDSIE_drawing_transparent
   };
   typedef enum PMDSIE_drawing_mode PMDSIT_drawing_mode;

/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSIC_

      $DESCRIPTION  The PMDSIC_

   $EH
   ========================================================================== */
/*   const PMDSIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSIT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct PMDSIT_*_def { 

   typedef struct PMDSIT_*_def PMDSIT_*
*/


/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_Deformat

        $TYPE	      PROCEDURE

        $INPUT        input_media_path       : source product media
                      media_type             : product media type
                      product_type           : product type
                      sensor_id              : sensor id
                      data_format            : data format (ceos/mph-sph)
                      source                 : i-paf, ...
                      mode                   : deformat, create annotation, ...
                      num_of_vol             : number of volume(s)
                      start_row              : top corner value
                      start_col              : left corner value
                      end_row                : bottom corner value
                      end_col                : right corner value
                      ql_width               : width of the output quick look
                      ql_height              : height of the output quick look
                      win_width              : width of the window to be used
                      win_height             : height of the window to be used
                      tif_ann_file           : tif annotation file name
                      tif_output_file        : tif output file name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSIP_Deformat
                        (/*IN    */ char                *input_media_path,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ DEVSIT_media_type    media_type,
                         /*IN    */ PMDSIT_product_type  product_type,
                         /*IN    */ INTx4                sensor_id,
                         /*IN    */ char                *data_format,
                         /*IN    */ char                *source,
                         /*IN    */ PMDSIT_deformat_mode mode,
                         /*IN    */ INTx4                num_of_vol,
                         /*IN    */ char                 ack_mount_flag,
                         /*IN    */ char                 dismount_flag,
                         /*IN    */ INTx4                start_row,
                         /*IN    */ INTx4                start_col,
                         /*IN    */ INTx4                end_row,
                         /*IN    */ INTx4                end_col,
                         /*IN    */ INTx4                ql_width,
                         /*IN    */ INTx4                ql_height,
                         /*IN    */ UINTx4               win_width,
                         /*IN    */ UINTx4               win_height,
                         /*IN    */ char                *tif_ann_file,
                         /*IN    */ char                *tif_output_file,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_VIEW_CreatePreviewFile

        $TYPE

        $INPUT        tif_input_file   : input file name
                      start_col        : starting column
                      start_row        : starting row
                      end_col          : end column
                      end_row          : end row
                      tif_output_file  : output file name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void PMDSIP_VIEW_CreatePreviewFile
                        (/*IN    */ char                *tif_input_file,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ INTx4                start_col,
                         /*IN    */ INTx4                start_row,
                         /*IN    */ INTx4                end_col,
                         /*IN    */ INTx4                end_row,
                         /*IN OUT*/ char                *tif_output_file,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_RETR_CheckImage

        $TYPE

        $INPUT        image_file     : image file from where extract sub-image
                      sub_image_file : image file to use as check to find image

        $MODIFIED     NONE

        $OUTPUT       out_retr_file  : output data file

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_alloc_memory

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void PMDSIP_RETR_CheckImage
                        (/*IN    */ char                *image_file,
                         /*IN    */ char                *sub_image_file,
                         /*   OUT*/ char                *out_retr_file,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_GRID_DrawArea

        $TYPE

        $INPUT        tif_input_file  : input tiff file
                      tif_output_file : output tiff file
                      max_ipoint      : number of points in the x axis
                      max_jpoint      : number of points in the y axis
                      lat_lon_flag    : flag to draw lines in latlon or pixline
                      drawing_mode    : transparent, overwrite, none, mode(s)

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void PMDSIP_GRID_DrawArea
                        (/*IN    */ char                *tif_input_file,
                         /*IN    */ UINTx1               full_ima_num,
                         /*IN    */ UINTx1               und_ima_num,
                         /*IN    */ char                *tif_output_file,
                         /*IN    */ INTx4                max_ipoint,
                         /*IN    */ INTx4                max_jpoint,
                         /*IN    */ INTx4                lat_lon_flag,
                         /*IN    */ PMDSIT_drawing_mode  drawing_mode,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_MediaAnalysis

        $TYPE

        $INPUT        input_media_path : source product media
                      media_type       : product media type
                      num_of_vol       : number of volume(s)
                      db_file_name_p   : product(s) data base file name


        $MODIFIED     NONE

        $OUTPUT       mcr_file_name_p  : media content report file name

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void PMDSIP_MDAN_MediaAnalysis
                        (/*IN    */ char                *input_media_path,
                         /*IN    */ DEVSIT_media_type    media_type,
                         /*IN    */ INTx4                num_of_vol,
                         /*IN    */ char                *db_file_name_p,
                         /*   OUT*/ char                *mcr_file_name_p,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_SUPP_SetSupportData

        $TYPE

        $INPUT        support_file     : support ingestion data file
                      tif_output_file  : output file name


        $MODIFIED     NONE

        $OUTPUT       mcr_file_name_p  : media content report file name

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void PMDSIP_SUPP_SetSupportData
                        (/*IN    */ char                *support_file,
                         /*   OUT*/ char                *tif_output_file,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_STRE_TiffFileData

        $TYPE

        $INPUT        input_file_name_p  : input tiff file name
                      output_file_name_p : output tiff file name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_error_paramaters

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void PMDSIP_STRE_TiffFileData
                        (/*IN    */ char                *input_file_name_p,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ float                minPerc,
                         /*IN    */ float                maxPerc,
                         /*IN    */ LDEFIT_boolean       noBlackFound,
                         /*IN    */ float                noBlack,
                         /*IN    */ char                *output_file_name_p,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_STRE_GeoPresentation

        $TYPE

        $INPUT        

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_error_paramaters

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void PMDSIP_STRE_GeoPresentation
                        (/*IN    */ char                *ql_image,
                         /*IN    */ UINTx1               ql_ima_num,
                         /*IN    */ char                *geo_image,
                         /*IN    */ UINTx1               geo_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         PMDSIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/*   extern void PMDSIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         PMDSIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void PMDSIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) PMDSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         PMDSIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    PMDSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define PMDSIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                     0
#define ERRSID_error                      1
#endif

#define ERRSID_PMDS_opn_in_cfg		  2 /* + */
#define ERRSID_PMDS_rea_in_cfg		  3
#define ERRSID_PMDS_eof_in_cfg		  4
#define ERRSID_PMDS_store_var		  5
#define ERRSID_PMDS_log_vol               6
#define ERRSID_PMDS_opn_in_prod 	  7
#define ERRSID_PMDS_pars_var              8
#define ERRSID_PMDS_bad_in_cfg            9
#define ERRSID_PMDS_alloc_cfg_field      10
#define ERRSID_PMDS_alloc_cfg_rec        11
#define ERRSID_PMDS_defo_prod            12
#define ERRSID_PMDS_rea_in_prod          13
#define ERRSID_PMDS_alloc_memory         14
#define ERRSID_PMDS_not_found            15
#define ERRSID_PMDS_error_paramaters     16
#define ERRSID_PMDS_error_create_file    17
#define ERRSID_PMDS_error_close_file     18
#define ERRSID_PMDS_error_reading_file   19
#define ERRSID_PMDS_error_open_file      20
#define ERRSID_PMDS_error_not_allowed    21
#define ERRSID_PMDS_kernel_dim_high      22
#define ERRSID_PMDS_bad_steps            23
#define ERRSID_PMDS_bad_write_size       24
#define ERRSID_PMDS_err_mem_alloc        25
#define ERRSID_PMDS_not_under_allow      26

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef PMDS_GLBL
   GLOBAL char *PMDSIV_ERRS_error_message[] = {
      "No error happens",                                               /*  0 */
      "Generic error happens",                                          /*  1 */
      "Error opening input trace file",                                 /*  2 */
      "Error reading input trace file",                                 /*  3 */
      "Reach EOF in input trace file",                                  /*  4 */
      "Error parsing variable",                                         /*  5 */
      "Error in log vol structure",                                     /*  6 */
      "Error opening product file",                                     /*  7 */
      "Error parsing variable",                                         /*  8 */
      "Error in product format description file",                       /*  9 */
      "Error allocating product file structure field",                  /* 10 */
      "Error allocating product file repeat field",                     /* 11 */
      "Error while deformat record",                                    /* 12 */
      "Error reading product file",                                     /* 13 */
      "Error allocating memory",                                        /* 14 */
      "Error, not found",                                               /* 15 */
      "Internal error in function parameters",                          /* 16 */
      "Error creating file",                                            /* 17 */
      "Error closing file",                                             /* 18 */
      "Error reading file",                                             /* 19 */
      "Error opening file",                                             /* 20 */
      "Error on not allowed data",                                      /* 21 */
      "Kernel dimensions too high",                                     /* 22 */
      "Steps sizes not good for undersampling",                         /* 23 */
      "Bad writing counters",                                           /* 24 */
      "SYSTEM ERROR: memory allocation error",                          /* 25 */
      "Undersampling not defined for such product"                      /* 26 */
   };
#else
   GLOBAL char *PMDSIV_ERRS_error_message[];
#endif


#endif
