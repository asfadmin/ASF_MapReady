/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_INTF

      $FUNCTION          interface module.

      $ROUTINE           NONE

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       10-MAR-97     AN       Initial Release
            SCR#11    01-DEC-97     GRV      The checks on the Rect AoI sizes
                                             control if they are greather then
                                             zero
   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef STBX
#define STBX STBX


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "libname.h"

#include ERRS_INTF_H
#include LDEF_INTF_H

#ifdef STBX_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define
*/

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum STBXIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXIC_

      $DESCRIPTION  The STBXIC_

   $EH
   ========================================================================== */
/*   const STBXIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXIT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct STBXIT_*_def { 

   typedef struct STBXIT_*_def STBXIT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STBXIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void STBXIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) STBXIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STBXIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    STBXIM_
                                ( (*IN    *) ,
                                  (*IN OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define STBXIM_
*/

/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_STBX_err_mem_alloc        2
#define ERRSID_STBX_not_if_parm		 3
#define ERRSID_STBX_err_type             4
#define ERRSID_STBX_parm_not_defined     5
#define ERRSID_STBX_parm_not_negative    6
#define ERRSID_STBX_parm_invalid         7
#define ERRSID_STBX_section_invalid      8
#define ERRSID_STBX_coord_not_cons       9
#define ERRSID_STBX_not_poly_aoi         10
#define ERRSID_STBX_undef_task           11
#define ERRSID_STBX_inv_prod_type        12
#define ERRSID_STBX_inv_inp_param        13
#define ERRSID_STBX_arr_par              14
#define ERRSID_STBX_undef_par_type       15
#define ERRSID_STBX_par_type_not_all     16
#define ERRSID_STBX_conv_not_allow       17
#define ERRSID_STBX_n_elem_out_of_range  18
#define ERRSID_STBX_inv_output_ima_dim   19
#define ERRSID_STBX_inv_out_ima_type     20
#define ERRSID_STBX_inv_image_dim        21
#define ERRSID_STBX_kernel_dim_high      22
#define ERRSID_STBX_kernel_inv_dim       23
#define ERRSID_STBX_no_interp_req        24
#define ERRSID_STBX_par_flag_not_all     25
#define ERRSID_STBX_not_arr_par          26
#define ERRSID_STBX_parm_is_even         27
#define ERRSID_STBX_dimens_not_set       28
#define ERRSID_STBX_task_not_defined     29
#define ERRSID_STBX_insuff_input_num     30
#define ERRSID_STBX_insuff_output_num    31
#define ERRSID_STBX_invalid_warp_val     32
#define ERRSID_STBX_invalid_ov_mode      33
#define ERRSID_STBX_invalid_in_mode      34
#define ERRSID_STBX_inp_files_not_two    35
#define ERRSID_STBX_bad_vect_par_num     36

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef STBX_GLBL
   GLOBAL char *STBXIV_ERRS_error_message[] = 
                        { "No error happens",                          /* 0  */
                          "Generic error happens",                     /* 1  */
                          "SYSTEM ERROR: memory allocation error",     /* 2  */
                          "Parameter -if not defined",                 /* 3  */
                          "Erroneous type for this function",          /* 4  */
                          "Parameter not defined",                     /* 5  */
                          "Parameter cannot have negative (null) value",/* 6  */
                          "Invalid parameter",                         /* 7  */
                          "Invalid section for this tool",             /* 8  */
			  "Inconsistent coordinates",                  /* 9  */
			  "Polygonal AOI not managed for this tool",   /* 10 */
                          "Undefined task",                            /* 11 */
			  "Invalid input product type",                /* 12 */
                          "Invalid input parameter",                   /* 13 */
                          "Array parameter when scalar expected",      /* 14 */
                          "Undefined parameter type",                  /* 15 */
                          "Parameter type not allowed",                /* 16 */
                          "Type conversion not allowed",               /* 17 */
                          "Number of array elements out of bounds",    /* 18 */
                          "Invalid output image dimensions",           /* 19 */
                          "Invalid output image data type",            /* 20 */
                          "Invalid image dimensions",                  /* 21 */
                          "Kernel dimensions too high",                /* 22 */
                          "Null or negative kernel dimensions",        /* 23 */
                          "No interpolation required",                 /* 24 */
                          "Parameter flag not allowed",                /* 25 */
                          "Not an array parameter",                    /* 26 */
                          "Parameter value is even",                   /* 27 */
			  "Invalid ROW/COL dimensions",                /* 28 */
                          "Task not defined",                          /* 29 */
                          "Insufficient number of input files",        /* 30 */
                          "Insufficient number of output files",       /* 31 */
                          "Invalid warp degree required",              /* 32 */
                          "Invalid overlapping mode",                  /* 33 */
                          "Invalid interpolation mode",                /* 34 */
                          "The input files are not two",               /* 35 */
                   "Bad input number for the vectorial parameter",     /* 36 */
                        };
#else
   GLOBAL char *STBXIV_ERRS_error_message[];
#endif

#endif
