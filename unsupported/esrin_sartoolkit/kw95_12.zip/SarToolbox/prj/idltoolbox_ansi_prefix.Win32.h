/*  Metrowerks Standard Library  Version 2.1.2  1997 May  */

/*
 *	ansi_prefix.win32.h
 *	
 *		Copyright � 1996-1997 Metrowerks, Inc.
 *		All rights reserved.
 */

#ifndef __ansi_prefix__
#define __ansi_prefix__

#define __dest_os	__win32_os
#define __LITTLE_ENDIAN

#include <x86_prefix.h>
#include <ansi_parms.h>
#include <wchar_t.h>	/* 960711 KO */

/* For Sar Toolbox */
#define __CODEWARRIOR__
#define __WIN95__
#define __HAVEIDL__

/* For IDL */
#define MS_WIN
#define WIN_32

#endif

/*	Change Log
960711 KO		Added this include for the WinNT headers
960829 bkoz	need to define modena lib for c++ libraries
*/
