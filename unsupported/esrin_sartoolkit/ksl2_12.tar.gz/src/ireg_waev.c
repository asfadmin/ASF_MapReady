/* ==========================================================================
   $MODULE_HEADER

      $NAME              IREG_WAEV

      $FUNCTION          This module contains the procedures to evaluate the
                         warp matrix to convert the GCPs from the master to
                         the slave reference system and viceversa

      $ROUTINE           IREGPP_WAEV_InitWarp
                         IREGPP_WAEV_Warp
                         IREGPP_WAEV_CloseWarp
                         IREGPP_WAEV_WriteResid
                         IREGPP_WAEV_VectMas2Sla
                         IREGPP_WAEV_VectSla2Mas
                         IREGPP_WAEV_WarpEval
                         IREGPP_WAEV_Mas2Sla
                         IREGPP_WAEV_Sla2Mas
                         IREGPP_WAEV_WarpCheck
                         IREGPP_WAEV_EditGCPs
                         IREGPP_WAEV_MatrEval
                         IREGPP_WAEV_NormMatrEval
                         IREGPP_WAEV_OneDegMatrEval
                         IREGPP_WAEV_OneHalfDegMatrEval
                         IREGPP_WAEV_TwoDegMatrEval
                         IREGPP_WAEV_ThreeDegMatrEval
                         IREGPP_WAEV_OneDegConv
                         IREGPP_WAEV_OneAndHalfDegConv
                         IREGPP_WAEV_TwoDegConv
                         IREGPP_WAEV_ThreeDegConv

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       30-JAN-98     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>
#include <string.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include IANN_INTF_H
#include COOR_INTF_H
#include IREG_INTF_H
#include IREG_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_InitWarp

        $TYPE         PROCEDURE

        $INPUT        degree : the wanted degree of the transformation

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_warp_deg  : wanted warp degree
                      IREGPV_warp_matr : structure with the pointers to the
                                         warp matrices

        $RET_STATUS   ERRSID_IREG_degree_undef
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure allocates the warp matrices

        $WARNING      THE CLOSE WARP MUST BE CALLED AT THE END OF THE PROGRAM

        $PDL          - Evaluates the number of parameters
                      - Checks them
                      - Allocates the direct warp matrix
                      - Zeroes the matrix row
                      - Allocates the inverse warp matrix
                      - Zeroes the matrix row

   $EH
   ========================================================================== */

void IREGPP_WAEV_InitWarp
                        (/*IN    */ IREGPT_warp_deg      degree,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_InitWarp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 npar;
   UINTx2                 ima;
   UINTx2                 row;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Set the global variable to the wanted degree
   ========================================================================== */
   IREGPV_warp_deg = degree;

/* ==========================================================================
   Evaluate the number of parameters
   ========================================================================== */
   npar = IREGPC_warp_npar[ degree ];

/* ==========================================================================
   Check the number of parameters
   ========================================================================== */
   if ( npar == 0 ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_degree_undef, "" );
   }

/* ==========================================================================
   Allocate the warp matrices
   ========================================================================== */
   for ( ima=0; ima<IREGID_MaxImaNum; ima++ ) {
      if ( ( IREGPV_warp_matr[ ima ].wmas2sla = (double **)
               MEMSIP_alloc ( (size_t)(2 * sizeof (double *)) ) ) ==
           (double **)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "for the direct warp matrix");
      }
      for ( row=0; row<2; row++ ) {
         if ( ( IREGPV_warp_matr[ ima ].wmas2sla[ row ] = (double *)MEMSIP_alloc (
                 (size_t)(npar * sizeof (double)) ) ) ==
              (double *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                               "for the direct warp matrix");
         }
         memset ( (void *)IREGPV_warp_matr[ ima ].wmas2sla[ row ], '\0',
                  (size_t)(npar * sizeof (double)) );
      }
      if ( ( IREGPV_warp_matr[ ima ].wsla2mas = (double **)
               MEMSIP_alloc ( (size_t)(2 * sizeof (double *)) ) ) ==
           (double **)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "for the inverse warp matrix");
      }
      for ( row=0; row<2; row++ ) {
         if ( ( IREGPV_warp_matr[ ima ].wsla2mas[ row ] = (double *)MEMSIP_alloc (
                 (size_t)(npar * sizeof (double)) ) ) ==
              (double *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                               "for the inverse warp matrix");
         }
         memset ( (void *)IREGPV_warp_matr[ ima ].wmas2sla[ row ], '\0',
                  (size_t)(npar * sizeof (double)) );
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_InitWarp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_Warp

        $TYPE         PROCEDURE

        $INPUT        NImages : number of input images
                      degree  : degree of the warp transformation required

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         for each degree of the warp
                      IREGPV_gcp       : structure with the GCPs INFO

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_insuff_GCPs
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the warp matrices starting
                      from the valid GCPs for each master and slave couples

        $WARNING      THE GCP EVALUATION MUST BE DONE BEFORE AND THE WARP
                      INIT PROCEDURE TOO

        $PDL          - Checks the image number
                      - Reads the number of parameters to evaluate
                      - Checks if the maximum number of GCPs is sufficient to
                        evaluate the warp matrices
                      - Loop over the slaves
                            - Zeroes a counter
                            - Loop over the master GCPs
                                  - If the slave GCP is valid
                                        - Increments the counter
                                  - End If
                            - End Loop
                            - Allocates two vectors for the master and slave
                              GCPs storage
                            - Loop over the master GCPs
                                  - If the corresponding slave GCP is valid
                                        - Stores the master ...
                                        - ... and the slave GCP
                                  - End If
                            - End Loop
                            - Evaluates the warp matrices
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_WAEV_Warp
                        (/*IN    */ INTx4                NImages,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_Warp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   MATHIT_RC             *master = (MATHIT_RC *)NULL;
   MATHIT_RC             *slave = (MATHIT_RC *)NULL;
   UINTx1                 npar;
   UINTx1                 mas_gnum = 0;
   INTx4                  ima;
   INTx4                  gcp;
   INTx4                  Ngcp;
   UINTx4                 count = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the images number
   ========================================================================== */
   if ( ( NImages < 2 ) || ( NImages > IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_ima_num_inv, "" );
   }

/* ==========================================================================
   Evaluate the number of parameters to evaluate
   ========================================================================== */
   npar = IREGPC_warp_npar[ degree ];

/* ==========================================================================
   Check the number of GCPs of the master
   ========================================================================== */
   if ( IREGPV_gcp[ mas_gnum ].n_gcp < (INTx4)npar ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_insuff_GCPs, "" );
   }

/* ==========================================================================
   Loop over the slaves
   ========================================================================== */
   for ( ima=1; ima<NImages; ima++ ) {

/* ==========================================================================
   Count the valid GCPs
   ========================================================================== */
      for ( gcp=0, count=0; gcp<IREGPV_gcp[ mas_gnum ].n_gcp; gcp++ ) {

/* ==========================================================================
   Check if the GCP is valid for the current slave
   ========================================================================== */
         if ( ( IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp ].valid ) &&
              ( IREGPV_gcp[ ima ].gcp_arr[ gcp ].valid ) ) {
            count++;
         }
      }

/* ==========================================================================
   Check the number of valid GCPs
   ========================================================================== */
      if ( count < (INTx4)npar ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_insuff_GCPs, "" );
      }

/* ==========================================================================
   Allocate the master and slave arrays
   ========================================================================== */

      /* master array */
      if ( ( master = (MATHIT_RC *)MEMSIP_realloc ( (void *)master,
                                                    (size_t)(count *
                                                     sizeof (MATHIT_RC)) ) ) ==
           (MATHIT_RC *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the master GCPs array" );
      }

      /* slave array */
      if ( ( slave = (MATHIT_RC *)MEMSIP_realloc ( (void *)slave,
                                                    (size_t)(count *
                                                     sizeof (MATHIT_RC)) ) ) ==
           (MATHIT_RC *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the slave GCPs array" );
      }

/* ==========================================================================
   Copy the valid GCPs
   ========================================================================== */
      for ( gcp=0, count=0; gcp<IREGPV_gcp[ mas_gnum ].n_gcp; gcp++ ) {

/* ==========================================================================
   Check if the GCP is valid for the current slave
   ========================================================================== */
         if ( ( IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp ].valid ) &&
              ( IREGPV_gcp[ ima ].gcp_arr[ gcp ].valid ) ) {

/* ==========================================================================
   Store master ...
   ========================================================================== */
            memcpy ( (void *)&(master[ count ]),
                     (const void *)&IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp ].coor,
                     sizeof (MATHIT_RC) );

/* ==========================================================================
   ... and slave GCP
   ========================================================================== */
            memcpy ( (void *)&slave[ count++ ],
                     (const void *)&IREGPV_gcp[ ima ].gcp_arr[ gcp ].coor,
                     sizeof (MATHIT_RC) );
         }
      }

/* ==========================================================================
   Fix the number of valid GCPs
   ========================================================================== */
      Ngcp = count;

/* ==========================================================================
   Evaluate the warp matrices
   ========================================================================== */
      IREGPP_WAEV_WarpEval ( ima, master, slave, Ngcp, degree, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Edit the points with the RMS too height
   ========================================================================== */
      IREGPP_WAEV_EditGCPs ( ima, degree, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Count the valid GCPs after the editing
   ========================================================================== */
      for ( gcp=0, count=0; gcp<IREGPV_gcp[ mas_gnum ].n_gcp; gcp++ ) {

/* ==========================================================================
   Check if the GCP is valid for the current slave
   ========================================================================== */
         if ( ( IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp ].valid ) &&
              ( IREGPV_gcp[ ima ].gcp_arr[ gcp ].valid ) ) {
            count++;
         }
      }

/* ==========================================================================
   Check the number of valid GCPs
   ========================================================================== */
      if ( count < (INTx4)npar ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_insuff_GCPs, "" );
      }

/* ==========================================================================
   Allocate the master and slave arrays
   ========================================================================== */

      /* master array */
      if ( ( master = (MATHIT_RC *)MEMSIP_realloc ( (void *)master,
                                                    (size_t)(count *
                                                     sizeof (MATHIT_RC)) ) ) ==
           (MATHIT_RC *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the master GCPs array" );
      }

      /* slave array */
      if ( ( slave = (MATHIT_RC *)MEMSIP_realloc ( (void *)slave,
                                                    (size_t)(count *
                                                     sizeof (MATHIT_RC)) ) ) ==
           (MATHIT_RC *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "in the slave GCPs array" );
      }

/* ==========================================================================
   Copy the valid GCPs
   ========================================================================== */
      for ( gcp=0, count=0; gcp<IREGPV_gcp[ mas_gnum ].n_gcp; gcp++ ) {

/* ==========================================================================
   Check if the GCP is valid for the current slave
   ========================================================================== */
         if ( ( IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp ].valid ) &&
              ( IREGPV_gcp[ ima ].gcp_arr[ gcp ].valid ) ) {

/* ==========================================================================
   Store master ...
   ========================================================================== */
            memcpy ( (void *)&(master[ count ]),
                     (const void *)&IREGPV_gcp[ mas_gnum ].gcp_arr[ gcp ].coor,
                     sizeof (MATHIT_RC) );

/* ==========================================================================
   ... and slave GCP
   ========================================================================== */
            memcpy ( (void *)&slave[ count++ ],
                     (const void *)&IREGPV_gcp[ ima ].gcp_arr[ gcp ].coor,
                     sizeof (MATHIT_RC) );
         }
      }

/* ==========================================================================
   Fix the number of valid GCPs
   ========================================================================== */
      Ngcp = count;

/* ==========================================================================
   Re-evaluate the warp matrices
   ========================================================================== */
      IREGPP_WAEV_WarpEval ( ima, master, slave, Ngcp, degree, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&master );
   MEMSIP_free ( (void **)&slave );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_Warp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_CloseWarp

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure free all the memories allocated for the
                      warp matrices

        $WARNING      NONE

        $PDL          - Evaluates the transformation parameters
                      - Frees the direct warp
                      - Frees the inverse warp

   $EH
   ========================================================================== */

void IREGPP_WAEV_CloseWarp
                        (/*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_CloseWarp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  ima;
   INTx4                  row;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

   for ( ima=0; ima<IREGID_MaxImaNum; ima++ ) {

/* ==========================================================================
   Free the direct matrix
   ========================================================================== */
      if ( IREGPV_warp_matr[ ima ].wmas2sla != (double **)NULL ) {
         for ( row=0; row<2; row++ ) {
            MEMSIP_free ( (void **)&(IREGPV_warp_matr[ ima ].wmas2sla[ row ]) );
         }
         MEMSIP_free ( (void **)&(IREGPV_warp_matr[ ima ].wmas2sla) );
      }
      if ( IREGPV_warp_matr[ ima ].wsla2mas != (double **)NULL ) {
         for ( row=0; row<2; row++ ) {
            MEMSIP_free ( (void **)&(IREGPV_warp_matr[ ima ].wsla2mas[ row ]) );
         }
         MEMSIP_free ( (void **)&(IREGPV_warp_matr[ ima ].wsla2mas) );
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_CloseWarp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_WriteResid

        $TYPE         PROCEDURE

        $INPUT        NImages : number of total input mages
                      degree  : degree of the transformation used
                      fp      : output log file pointer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_ima_num_inv

        $DESCRIPTION  This procedure writes the statistics for each slave in
                      an output file

        $WARNING      THE OUTPUT FILE MUST BE OPENED BEFORE

        $PDL          - Checks the input parameters
                      - Loop over the images
                            - Prints in the file the slave number
                            - Zeroes the utility variables
                            - Prints the table header
                            - Loop over the master GCPs
                                  - If the slave GCP is valid
                                        - Increments the GCPs counter
                                        - Prints the master and slave GCPs
                                        - Transforms the master into slave GCP
                                          with the evaluates warp matrix
                                        - Evaluates the residual between the
                                          registered slave GCP and the evaluated
                                          one
                                        - Prints the residual
                                        - Increments the mean and the square
                                          residual variables
                                  - End If
                            - End Loop
                            - Evaluates the mean values of the residuals
                            - Evaluates the RMS of the residuals
                            - Writes them
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_WAEV_WriteResid
                        (/*IN    */ UINTx4               NImages,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ FILE                *fp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_WriteResid";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  ima;
   MATHIT_RC              mean;
   MATHIT_RC              Square;
   MATHIT_RC              std;
   MATHIT_RC              tmp;
   UINTx1                 mas_imanum = 0;
   INTx4                  gcp_i;
   INTx4                  N = 0;
   INTx2                  i;
   INTx2                  j;
   UINTx1                 npar;
   float                  n_deg;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the number of images
   ========================================================================== */
   if ( ( NImages < 2 ) || ( NImages > IREGID_MaxImaNum ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_ima_num_inv, "" );
   }

/* ==========================================================================
   Evaluate the number of parameters
   ========================================================================== */
   npar = IREGPC_warp_npar[ degree ];

/* ==========================================================================
   Loop over the slaves
   ========================================================================== */
   for ( ima=1;ima<NImages; ima++ ) {

/* ==========================================================================
   Print out the image info
   ========================================================================== */
      fprintf ( fp, "\n\n\n ### Slave Number = %2d", ima );

/* ==========================================================================
   Annotate the transformation degree
   ========================================================================== */
      switch ( degree ) {
         case IREGPE_wd_one:
            n_deg = 1.0;
         break;
         case IREGPE_wd_one_half:
            n_deg = 1.5;
         break;
         case IREGPE_wd_two:
            n_deg = 2.0;
         break;
         case IREGPE_wd_three:
            n_deg = 3.0;
         break;
         default:
            ERRSIM_set_error ( status_code, ERRSID_IREG_warp_deg_not_allow,
                               "" );
      }
      fprintf ( fp, "\n\n Transformation Degree = %0f", n_deg );

/* ==========================================================================
   Write the direct warp
   ========================================================================== */
      fprintf ( fp, "\n\n Master to Slave Warp Matrix:" );
      for ( i=0; i<2; i++ ) {
         fprintf ( fp, "\n" );
         for ( j=0; j<npar; j++ ) {
            fprintf ( fp, " %12.5f",
                      IREGPV_warp_matr[ ima ].wmas2sla[ i ][ j ] );
         }
      }
      fprintf ( fp, "\n\n Slave to Master Warp Matrix:" );
      for ( i=0; i<2; i++ ) {
         fprintf ( fp, "\n" );
         for ( j=0; j<npar; j++ ) {
            fprintf ( fp, " %12.5f",
                      IREGPV_warp_matr[ ima ].wsla2mas[ i ][ j ] );
         }
      }

/* ==========================================================================
   Zero the variables to fill iteratively
   ========================================================================== */
      memset ( (void *)&mean, '\0', sizeof (MATHIT_RC) );
      memset ( (void *)&Square, '\0', sizeof (MATHIT_RC) );
      memset ( (void *)&std, '\0', sizeof (MATHIT_RC) );
      N = 0;

/* ==========================================================================
   
   ========================================================================== */
      fprintf ( fp, "\n\n     | GCP master row | GCP master col |" );
      fprintf ( fp,           " GCP slave row  | GCP slave col  |" );
      fprintf ( fp,           "  Row Residuals |  Col Residuals |" );
      fprintf ( fp,           "     Points RMS |" );
      fprintf ( fp,   "\n ---------------------------------------" );
      fprintf ( fp,           "----------------------------------" );
      fprintf ( fp,           "----------------------------------" );
      fprintf ( fp,           "-----------------" );

/* ==========================================================================
   Loop over the number of GCPs
   ========================================================================== */
      for ( gcp_i=0; gcp_i<IREGPV_gcp[ mas_imanum ].n_gcp; gcp_i++ ) {

/* ==========================================================================
   Check if the GCP is valid
   ========================================================================== */
         if ( IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].valid ) {

/* ==========================================================================
   Increment the counter
   ========================================================================== */
            N++;

/* ==========================================================================
   Write the GCPs master ...
   ========================================================================== */
            fprintf ( fp, "\n %3d |      %9.3f |      %9.3f |", N,
                      IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor.row,
                      IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor.col );

/* ==========================================================================
   ... and slave
   ========================================================================== */
            fprintf ( fp,         "      %9.3f |      %9.3f |",
                      IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.row,
                      IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.col );

/* ==========================================================================
   Transform from master to slave
   ========================================================================== */
            IREGPP_WAEV_Mas2Sla ( IREGPV_gcp[ mas_imanum ].gcp_arr[
                                  gcp_i ].coor, degree, ima, &tmp,
                                  status_code );
            ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the residual
   ========================================================================== */
            tmp.row -= IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.row;
            tmp.col -= IREGPV_gcp[ ima ].gcp_arr[ gcp_i ].coor.col;

/* ==========================================================================
   Print the residuals
   ========================================================================== */
            fprintf ( fp,         "      %9.3f |      %9.3f |",
                      tmp.row, tmp.col );

/* ==========================================================================
   and the point RMS
   ========================================================================== */
            fprintf ( fp,         "      %9.3f ",
                      sqrt ( POW ( tmp.row, 2. ) + POW ( tmp.col, 2. ) ) );

/* ==========================================================================
   Increment the mean residulas
   ========================================================================== */
            mean.row += tmp.row;
            mean.col += tmp.col;

/* ==========================================================================
   Increment the square residulas
   ========================================================================== */
            Square.row += POW ( tmp.row, 2. );
            Square.col += POW ( tmp.col, 2. );
         }
      }

/* ==========================================================================
   Evaluate the mean residual values ...
   ========================================================================== */
      mean.row /= N;
      mean.col /= N;

/* ==========================================================================
   ... and the RMS values
   ========================================================================== */
      Square.row /= N;
      Square.col /= N;
      std.row = sqrt ( Square.row - POW ( mean.row, 2. ) );
      std.col = sqrt ( Square.col - POW ( mean.col, 2. ) );
      Square.row = sqrt ( Square.row );
      Square.col = sqrt ( Square.col );

/* ==========================================================================
   Print out the residual statistics
   ========================================================================== */
      fprintf ( fp, "\n\n mean residuals in the rows     = %9.3f", mean.row );
      fprintf ( fp, "\n mean residuals in the columns  = %9.3f", mean.col );
      fprintf ( fp, "\n\n std of residual in the rows    = %9.3f", std.row );
      fprintf ( fp, "\n std of residual in the columns  = %9.3f", std.col );
      fprintf ( fp, "\n\n RMS of the residuals in the rows    = %9.3f",
                Square.row );
      fprintf ( fp, "\n RMS of the residuals in the columns = %9.3f",
                Square.col );
      fprintf ( fp, "\n\n Total mean = %9.3f\n Total std  = %9.3f\
\n Total RMS  = %9.3f",
                ( mean.row + mean.col ) / 2.,
                sqrt ( ( POW ( std.row, 2. ) + POW ( std.col, 2. ) ) / 2. ),
                sqrt ( ( POW ( Square.row, 2. ) +
                         POW ( Square.col, 2. ) ) / 2. ) );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_WriteResid */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_VectMas2Sla

        $TYPE         PROCEDURE

        $INPUT        maspts   : master points to convert
                      NRow     : number of points to convert in the row direction
                      NCol     : number of points to convert in the row direction
                      degree   : degree of the used transformation
                      sla_gnum : ID of the slave image

        $MODIFIED     NONE

        $OUTPUT       slapts   : slave points converted

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_warp_not_create

        $DESCRIPTION  This procedure converts a set of master points into
                      their slave coordinates

        $WARNING      NONE

        $PDL          - Loop over the points to convert
                            - Converts the points coordinates
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_WAEV_VectMas2Sla
                        (/*IN    */ MATHIT_RC_float    **maspts,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ UINTx1               sla_gnum,
                         /*   OUT*/ MATHIT_RC_float    **slapts,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_VectMas2Sla";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   REGISTER UINTx4           pt;
   REGISTER UINTx4           NPoints;
   REGISTER UINTx1           el;
   REGISTER UINTx1           npar;
   REGISTER double          *pWr = (double *)NULL;
   REGISTER double          *pWc = (double *)NULL;
   REGISTER MATHIT_RC_float *ptm = (MATHIT_RC_float *)NULL;
   REGISTER MATHIT_RC_float *pts = (MATHIT_RC_float *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the warp creation
   ========================================================================== */
   if ( IREGPV_warp_matr[ sla_gnum ].wmas2sla == (double **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_warp_not_create, "" );
   }

/* ==========================================================================
   Evaluate the number of parameters
   ========================================================================== */
   npar = IREGPC_warp_npar[ degree ];

/* ==========================================================================
   Point to the master ... and slave arrays
   ========================================================================== */
   ptm = *maspts - 1;

/* ==========================================================================
   ... and slave arrays
   ========================================================================== */
   pts = *slapts - 1;

/* ==========================================================================
   Point to the row warp transformation for writing simplicity
   ========================================================================== */
   pWr = IREGPV_warp_matr[ sla_gnum ].wmas2sla[ 0 ];

/* ==========================================================================
   Point to the row warp transformation for writing simplicity
   ========================================================================== */
   pWc = IREGPV_warp_matr[ sla_gnum ].wmas2sla[ 1 ];

/* ==========================================================================
   Evaluate the number of points
   ========================================================================== */
   NPoints = NRow * NCol;

/* ==========================================================================
   Switch over the degree values
   ========================================================================== */
   switch ( degree ) {
      case IREGPE_wd_one:

/* ==========================================================================
   Loop over the points
   ========================================================================== */
         for ( pt=0; pt<NPoints; pt++ ) {

/* ==========================================================================
   Increments the pointers
   ========================================================================== */
            pts++;
            ptm++;

/* ==========================================================================
   Evaluate the value of the output coordinates
   ========================================================================== */
            pts->row = *pWr +
               *(pWr + 1) * ptm->row +
               *(pWr + 2) * ptm->col;
            pts->col = *pWc +
               *(pWc + 1) * ptm->row +
               *(pWc + 2) * ptm->col;
         }
      break;
      case IREGPE_wd_one_half:

/* ==========================================================================
   Loop over the points
   ========================================================================== */
         for ( pt=0; pt<NPoints; pt++ ) {

/* ==========================================================================
   Increments the pointers
   ========================================================================== */
            pts++;
            ptm++;

/* ==========================================================================
   Evaluate the value of the output coordinates
   ========================================================================== */
            pts->row = *pWr +
               *(pWr + 1) * ptm->row +
               *(pWr + 2) * ptm->col +
               *(pWr + 3) * ptm->row * ptm->col;
            pts->col = *pWc +
               *(pWc + 1) * ptm->row +
               *(pWc + 2) * ptm->col +
               *(pWc + 3) * ptm->row * ptm->col;
         }
      break;
      case IREGPE_wd_two:

/* ==========================================================================
   Loop over the points
   ========================================================================== */
         for ( pt=0; pt<NPoints; pt++ ) {

/* ==========================================================================
   Increments the pointers
   ========================================================================== */
            pts++;
            ptm++;

/* ==========================================================================
   Evaluate the value of the output coordinates
   ========================================================================== */
            pts->row = *pWr +
               *(pWr + 1) * ptm->row +
               *(pWr + 2) * ptm->col +
               *(pWr + 3) * ptm->row * ptm->row +
               *(pWr + 4) * ptm->row * ptm->col +
               *(pWr + 5) * ptm->col * ptm->col;
            pts->col = *pWc +
               *(pWc + 1) * ptm->row +
               *(pWc + 2) * ptm->col +
               *(pWc + 3) * ptm->row * ptm->row +
               *(pWc + 4) * ptm->row * ptm->col +
               *(pWc + 5) * ptm->col * ptm->col;
         }
      break;
      case IREGPE_wd_three:

/* ==========================================================================
   Loop over the points
   ========================================================================== */
         for ( pt=0; pt<NPoints; pt++ ) {

/* ==========================================================================
   Increments the pointers
   ========================================================================== */
            pts++;
            ptm++;

/* ==========================================================================
   Evaluate the value of the output coordinates
   ========================================================================== */
            pts->row = *pWr +
               *(pWr + 1) * ptm->row +
               *(pWr + 2) * ptm->col +
               *(pWr + 3) * ptm->row * ptm->row +
               *(pWr + 4) * ptm->row * ptm->col +
               *(pWr + 5) * ptm->col * ptm->col +
               *(pWr + 6) * ptm->row * ptm->row * ptm->row +
               *(pWr + 7) * ptm->row * ptm->row * ptm->col +
               *(pWr + 8) * ptm->row * ptm->col * ptm->col +
               *(pWr + 9) * ptm->col * ptm->col * ptm->col;
            pts->col = *pWc +
               *(pWc + 1) * ptm->row +
               *(pWc + 2) * ptm->col +
               *(pWc + 3) * ptm->row * ptm->row +
               *(pWc + 4) * ptm->row * ptm->col +
               *(pWc + 5) * ptm->col * ptm->col +
               *(pWc + 6) * ptm->row * ptm->row * ptm->row +
               *(pWc + 7) * ptm->row * ptm->row * ptm->col +
               *(pWc + 8) * ptm->row * ptm->col * ptm->col +
               *(pWc + 9) * ptm->col * ptm->col * ptm->col;
         }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_warp_deg_not_allow,
                            "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_VectMas2Sla */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_VectSla2Mas

        $TYPE         PROCEDURE

        $INPUT        slapts   : slave points to convert
                      NRow     : number of points to convert in the row direction
                      NCol     : number of points to convert in the row direction
                      degree   : degree of the used transformation
                      sla_gnum : ID of the slave image

        $MODIFIED     NONE

        $OUTPUT       maspts   : master points converted

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_warp_not_create

        $DESCRIPTION  This procedure converts a set of slave points into
                      their master coordinates

        $WARNING      NONE

        $PDL          - Loop over the points to convert
                            - Converts the points coordinates
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_WAEV_VectSla2Mas
                        (/*IN    */ MATHIT_RC          **slapts,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ UINTx1               sla_gnum,
                         /*   OUT*/ MATHIT_RC          **maspts,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_VectSla2Mas";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the warp creation
   ========================================================================== */
   if ( IREGPV_warp_matr[ sla_gnum ].wsla2mas == (double **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_warp_not_create, "" );
   }

/* ==========================================================================
   Loop over the points
   ========================================================================== */
   for ( row=0; row<NRow; row++ ) {
      for ( col=0; col<NCol; col++ ) {
         IREGPP_WAEV_Sla2Mas ( slapts[ row ][ col ], degree, sla_gnum,
                               &maspts[ row ][ col ], status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_VectSla2Mas */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_WarpEval

        $TYPE         PROCEDURE

        $INPUT        sla_num   : ID of the slave image from which to evaluate
                                  the warps matrices
                      masterpts : vector of coordinates of the master image GCPs
                      slavepts  : vector of coordinates of the slave image GCPs
                      N         : number of valid GCPs
                      degree    : wanted degree of the transformation

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_warp_matr : direct and inverse matrices

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_insuff_GCPs

        $DESCRIPTION  This procedure evaluates the direct warp ( from master
                      to slave coordinates ) and the inverse one

        $WARNING      NONE

        $PDL          - Checks the slave ID
                      - Evaluate the number of parameters
                      - Checks if the data are sufficient
                      - Evaluates the direct warp
                      - Evaluates the inverse warp

   $EH
   ========================================================================== */
void IREGPP_WAEV_WarpEval
                        (/*IN    */ UINTx1               sla_num,
                         /*IN    */ MATHIT_RC           *masterpts,
                         /*IN    */ MATHIT_RC           *slavepts,
                         /*IN    */ INTx4                N,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_WarpEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the direct warp
   ========================================================================== */
   IREGPP_WAEV_MatrEval ( masterpts, slavepts, N, degree,
                          IREGPV_warp_matr[ sla_num ].wmas2sla, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the inverse warp
   ========================================================================== */
   IREGPP_WAEV_MatrEval ( slavepts, masterpts, N, degree,
                          IREGPV_warp_matr[ sla_num ].wsla2mas,
                          status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_WarpEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_Mas2Sla

        $TYPE         PROCEDURE

        $INPUT        maspt    : coordinates of the point to convert
                      degree   : degree of the transformation
                      sla_gnum : ID of the slave

        $MODIFIED     NONE

        $OUTPUT       slapt    : transformed point coordinates

        $GLOBAL       IREGPV_warp_matr : warp matrices global variables

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure converts the master coordinates of a
                      point in the slave ones

        $WARNING      NONE

        $PDL          - Switch over the degree
                            - Set the index to the procedure to use
                      - End Switch

   $EH
   ========================================================================== */

void IREGPP_WAEV_Mas2Sla
                        (/*IN    */ MATHIT_RC            maspt,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ UINTx1               sla_gnum,
                         /*   OUT*/ MATHIT_RC           *slapt,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_Mas2Sla";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Call the transformation procedure
   ========================================================================== */
   ( *IREGPC_conv_func[ (degree - 1) ] )
      ( maspt, IREGPV_warp_matr[ sla_gnum ].wmas2sla, slapt, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_Mas2Sla */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_Sla2Mas

        $TYPE         PROCEDURE

        $INPUT        slapt    : coordinates of the point to convert
                      degree   : degree of the transformation
                      sla_gnum : ID of the slave

        $MODIFIED     NONE

        $OUTPUT       maspt    : transformed point coordinates

        $GLOBAL       IREGPV_warp_matr : warp matrices global variables

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure converts the slave coordinates of a
                      point in the master ones

        $WARNING      NONE

        $PDL          - Switch over the degree
                            - Set the index to the procedure to use
                      - End Switch

   $EH
   ========================================================================== */

void IREGPP_WAEV_Sla2Mas
                        (/*IN    */ MATHIT_RC            slapt,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ UINTx1               sla_gnum,
                         /*   OUT*/ MATHIT_RC           *maspt,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_Sla2Mas";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Call the transformation procedure
   ========================================================================== */
   ( *IREGPC_conv_func[ degree - 1 ] )
      ( slapt, IREGPV_warp_matr[ sla_gnum ].wsla2mas, maspt, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_Sla2Mas */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_WarpCheck

        $TYPE         PROCEDURE

        $INPUT        imanum : image ID
                      degree : degree of the transformation

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_gcp : the structure with the GCPs INFO

        $RET_STATUS   ERRSID_IREG_warp_not_good

        $DESCRIPTION  This procedure checks the warp matrices comparing the
                      residuals obtained with the warp between the master and
                      slave coordinates coarse registered and that evaluates with
                      the evaluated warps

        $WARNING      NONE

        $PDL          - Sets the number of GCPs
                      - Loop over the GCPs of the master image
                            - Converts the master point into the slave reference
                              system
                            - Sums the difference between the transformed
                              and the evaluated slave coordinates to the
                              previous value
                            - Sums the square of the difference
                            - Converts the slave point into the master reference
                              system
                            - Sums the difference between the transformed
                              and the evaluated master coordinates to the
                              previous value
                            - Sums the square of the difference
                      - End Loop
                      - Evaluates the mean values of the residual
                      - Evaluates the RMSs
                      - Checks the RMSs

   $EH
   ========================================================================== */

void IREGPP_WAEV_WarpCheck
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_WarpCheck";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   MATHIT_RC              meanX;
   MATHIT_RC              meanY;
   MATHIT_RC              XSquare;
   MATHIT_RC              YSquare;
   MATHIT_RC              tmp;
   UINTx1                 mas_imanum = 0;
   INTx4                  gcp_i;
   INTx4                  N;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Zero the variables to fill iteratively
   ========================================================================== */
   memset ( (void *)&meanX, '\0', sizeof (MATHIT_RC) );
   memset ( (void *)&meanY, '\0', sizeof (MATHIT_RC) );
   memset ( (void *)&XSquare, '\0', sizeof (MATHIT_RC) );
   memset ( (void *)&YSquare, '\0', sizeof (MATHIT_RC) );

/* ==========================================================================
   Set the number of GCPs
   ========================================================================== */
   N = IREGPV_gcp[ mas_imanum ].n_gcp;

/* ==========================================================================
   Loop over the GCPs
   ========================================================================== */
   for ( gcp_i=0; gcp_i<IREGPV_gcp[ mas_imanum ].n_gcp; gcp_i++ ) {

/* ==========================================================================
   Convert the point from master to slave
   ========================================================================== */
      IREGPP_WAEV_Mas2Sla ( IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor,
                            degree, imanum, &tmp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Increment the mean value
   ========================================================================== */
      meanX.row += tmp.row - IREGPV_gcp[ imanum ].gcp_arr[ gcp_i ].coor.row;
      meanX.col += tmp.col - IREGPV_gcp[ imanum ].gcp_arr[ gcp_i ].coor.col;

/* ==========================================================================
   Increment the square
   ========================================================================== */
      XSquare.row +=
         POW ( ( tmp.row - IREGPV_gcp[ imanum ].gcp_arr[ gcp_i ].coor.row ),
               2. );
      XSquare.col +=
         POW ( ( tmp.col - IREGPV_gcp[ imanum ].gcp_arr[ gcp_i ].coor.col ),
               2. );

/* ==========================================================================
   Convert from slave to master
   ========================================================================== */
      IREGPP_WAEV_Sla2Mas ( IREGPV_gcp[ imanum ].gcp_arr[ gcp_i ].coor, degree,
                            imanum, &tmp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Increment the mean value
   ========================================================================== */
      meanY.row += tmp.row - IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor.row;
      meanY.col += tmp.col - IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor.col;

/* ==========================================================================
   Increment the square
   ========================================================================== */
      YSquare.row +=
         POW ( ( tmp.row - IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor.row ),
               2. );
      YSquare.col +=
         POW ( ( tmp.col - IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor.col ),
               2. );
   }

/* ==========================================================================
   Evaluate the mean residual
   ========================================================================== */
   meanX.row /= N;
   meanX.col /= N;
   meanY.row /= N;
   meanY.col /= N;

/* ==========================================================================
   Evaluate the RMSs
   ========================================================================== */
   XSquare.row /= N;
   XSquare.col /= N;
   YSquare.row /= N;
   YSquare.col /= N;

   XSquare.row = sqrt ( XSquare.row );
   XSquare.col = sqrt ( XSquare.col );
   YSquare.row = sqrt ( YSquare.row );
   YSquare.col = sqrt ( YSquare.col );

/* ==========================================================================
   Check the goodness of the warp through the residuals
   ========================================================================== */
   if ( ( XSquare.row > IREGPD_max_RMS ) || ( XSquare.col > IREGPD_max_RMS ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_warp_not_good,
                         "to transform master into slave coordinates" );
   }
   if ( ( YSquare.row > IREGPD_max_RMS ) || ( YSquare.col > IREGPD_max_RMS ) ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_warp_not_good,
                         "to transform slave into master coordinates" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_WarpCheck */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_MatrEval

        $TYPE         PROCEDURE

        $INPUT        source  : array with the valid GCPs coordinates to be
                                used as the source coordinates in the
                                transformation
                      target  : array with the valid GCPs coordinates to be
                                used as the target coordinates in the
                                transformation
                      N       : number of input data
                      degree  : flag indicating the wanted transformation to
                                evaluate

        $MODIFIED     NONE

        $OUTPUT       Warp    : the transformation matrix that applied to a
                                particular combination of the source data gives
                                the transformed target data

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_insuff_GCPs
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the warp matrix that transform
                      the source coordinates into the target ones

        $WARNING      NONE

        $PDL          - Checks the number of data against the number of
                        parameters to evaluate for the wanted transformation
                      - Allocates the memories to store the input data, the
                        normal matrix and the expected parameters vector
                      - Loop over the coordinates
                            - Fills the vector of input data with the rows'
                              coordinates
                            - Fills the vector of input data with the columns'
                              coordinates
                      - End Loop
                      - Evaluates the normal matrix
                      - Zeroes the parameters vector
                      - Evaluates the parameters with the Least Mean Square
                        Adjustment
                      - Copy the parameters in the warp matrix

   $EH
   ========================================================================== */

void IREGPP_WAEV_MatrEval
                        (/*IN    */ MATHIT_RC           *master,
                         /*IN    */ MATHIT_RC           *slave,
                         /*IN    */ INTx4                N,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN OUT*/ double             **Warp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_MatrEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double               *y = (double *)NULL;
   double               *p = (double *)NULL;
   double              **A = (double **)NULL;
   UINTx1                m;
   INTx4                 row;
   INTx4                 col;
   INTx4                 gcp_i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Copy the number of parameters
   ========================================================================== */
   m = IREGPC_warp_npar[ degree ];

/* ==========================================================================
   Check the number of data
   ========================================================================== */
   if ( N < (INTx4)m ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_insuff_GCPs, "" );
   }

/* ==========================================================================
   Allocate the vector of data inputs
   ========================================================================== */
   if ( ( y = (double *)MEMSIP_alloc ( (size_t)(2 * N * sizeof (double)) ) ) ==
        (double *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "allocating the input data vector" );
   }

/* ==========================================================================
   Allocate the normal matrix
   ========================================================================== */
   if ( ( A = (double **)MEMSIP_alloc ( (size_t)(2 * N *
                                         sizeof (double *)) ) ) ==
        (double **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "allocating the normal matrix" );
   }
   for ( row=0; row<( 2 * N ); row++ ) {
      if ( ( A[ row ] = (double *)MEMSIP_alloc ( (size_t)(2 * m *
                                                    sizeof (double)) ) ) ==
           (double *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                            "allocating the normal matrix for 1 deg" );
      }

      /* zeroes the matrix */
      memset ( (void *)A[ row ], '\0', (size_t)(2 * m * sizeof (double)) );
   }

/* ==========================================================================
   Allocate the vector of parameters
   ========================================================================== */
   if ( ( p = (double *)MEMSIP_alloc ( (size_t)(2 * m * sizeof (double)) ) ) ==
        (double *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_err_mem_alloc,
                         "allocating the parameters vector" );
   }

/* ==========================================================================
   Fill the input data vector with the slave GCPs' coordinates
   ========================================================================== */
   for ( gcp_i=0; gcp_i<N; gcp_i++ ) {
      y[ gcp_i ] = slave[ gcp_i ].row;
      y[ N + gcp_i ] = slave[ gcp_i ].col;
   }

/* ==========================================================================
   Create the normal matrix with the master GCPs' coordinates
   ========================================================================== */
   IREGPP_WAEV_NormMatrEval ( master, degree, N, A, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Zero the parameters vector
   ========================================================================== */
   memset ( (void *)p, '\0', (size_t)(2 * m * sizeof (double)) );

/* ==========================================================================
   Invert the equation y = A * p and evaluate the parameters
   ========================================================================== */
   MATHIP_LIAL_LLSQEval ( (INTx4)(2 * N), y, (INTx4)(2 * m), A, p,
                          status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the Direct Warp matrix
   ========================================================================== */
   for ( row=0; row<2; row++ ) {
      memcpy ( (void *)Warp[ row ], (const void *)&(p[ m * row ]),
               (size_t)(m * sizeof (double)) );
   }

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&y );
   MEMSIP_free ( (void **)&p );

   if ( A != (double **)NULL ) {
      for ( row=0; row<( 2 * N ); row++ ) {
         MEMSIP_free ( (void **)&A[ row ] );
      }
      MEMSIP_free ( (void **)&A );
   }

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_MatrEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_NormMatrEval

        $TYPE         PROCEDURE

        $INPUT        coor     : array with the coordinates to use to fill the
                                 normal matrix
                      degree   : transformation degree
                      Ngcp     : number of valid GCPs

        $MODIFIED     A        : pointer to the allocated normal matrix
                                 of the transformation

        $OUTPUT       NONE

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         to evaluate
                      IREGPC_norm_func : array of functions that evaluate the
                                         normal matrix

        $RET_STATUS   ERRSID_IREG_warp_deg_not_allow
                      ERRSID_IREG_insuff_GCPs
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure creates and fills the normal matrix for
                      the warp evaluation

        $WARNING      NONE

        $PDL          - Switch over the degrees
                            - Sets the index for the function to call
                      - End Switch
                      - Checks the number of GCPs
                      - Allocates the normal matrix
                      - Zeroes the normal matrix
                      - Calls the procedure for that degree

   $EH
   ========================================================================== */

void IREGPP_WAEV_NormMatrEval
                        (/*IN    */ MATHIT_RC           *coor,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ INTx4                Ngcp,
                         /*IN OUT*/ double             **A,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_NormMatrEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 fun;
   INTx4                  row;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Switch over the various degree
   ========================================================================== */
   switch ( degree ) {
      case IREGPE_wd_one:
         fun = 0;              /* degree one  */
      break;
      case IREGPE_wd_one_half:
         fun = 1;              /* degree one and half */
      break;
      case IREGPE_wd_two:
         fun = 2;              /* degree two */
      break;
      case IREGPE_wd_three:
         fun = 3;              /* degree three */
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_IREG_warp_deg_not_allow, "" );
   }

/* ==========================================================================
   Check the number of valid GCP(s)
   ========================================================================== */
   if ( Ngcp < (INTx4)IREGPC_warp_npar[ degree ] ) {
      ERRSIM_set_error ( status_code, ERRSID_IREG_insuff_GCPs, "" );
   }

/* ==========================================================================
   Call the normal matrix evaluator procedure
   ========================================================================== */
   ( *IREGPC_norm_func[ fun ] )
      ( coor, Ngcp, A, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_NormMatrEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_OneDegMatrEval

        $TYPE         PROCEDURE

        $INPUT        coor     : coordinates with which to fill the normal
                                 matrix
                      Ngcp     : the number of valid GCPs

        $MODIFIED     NONE

        $OUTPUT       A        : normal matrix

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         to evaluate

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the normal matrix for the one degree
                      warp with the GCP(s) previously evaluated

        $WARNING      THE GCP(S) INFO STRUCTURES MUST BE CREATED, FILLED AND
                      THE GCP(S) CO-REGISTERED BEFORE CALLING THIS PROCEDURE

        $PDL          - Loop over the gcps
                            - Fills the normal matrix in all the current
                              row with the master coordinates
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_WAEV_OneDegMatrEval
                        (/*IN    */ MATHIT_RC           *coor,
                         /*IN    */ INTx4                Ngcp,
                         /*   OUT*/ double             **A,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_OneDegMatrEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  gcp_i;
   INTx1                  m;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Set the number of parameters
   ========================================================================== */
   m = IREGPC_warp_npar[ 1 ];

/* ==========================================================================
   Copy the GPC(s) coordinates in the matrix
   ========================================================================== */
   for ( gcp_i=0; gcp_i<Ngcp; gcp_i++ ) {
      A[ gcp_i ][ 0 ] = A[ Ngcp + gcp_i ][ m + 0 ] = (double)1;
      A[ gcp_i ][ 1 ] = A[ Ngcp + gcp_i ][ m + 1 ] = coor[ gcp_i ].row;
      A[ gcp_i ][ 2 ] = A[ Ngcp + gcp_i ][ m + 2 ] = coor[ gcp_i ].col;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_OneDegMatrEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_OneHalfDegMatrEval

        $TYPE         PROCEDURE

        $INPUT        coor     : coordinates with which to fill the normal
                                 matrix
                      Ngcp     : the number of valid GCPs

        $MODIFIED     NONE

        $OUTPUT       A        : normal matrix

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         to evaluate

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the normal matrix for the one and
                      half degree with the GCP(s) previously evaluated

        $WARNING      THE GCP(S) INFO STRUCTURES MUST BE CREATED, FILLED AND
                      THE GCP(S) CO-REGISTERED BEFORE CALLING THIS PROCEDURE

        $PDL          - Loop over the GCP(s)
                            - Fills the normal matrix in all the current
                              row with the master coordinates
                      - End loop

   $EH
   ========================================================================== */

void IREGPP_WAEV_OneHalfDegMatrEval
                        (/*IN    */ MATHIT_RC           *coor,
                         /*IN    */ INTx4                Ngcp,
                         /*   OUT*/ double             **A,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_OneHalfDegMatrEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  gcp_i;
   INTx1                  m;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Set the number of parameters
   ========================================================================== */
   m = IREGPC_warp_npar[ 2 ];

/* ==========================================================================
   Copy the GPC(s) coordinates in the matrix
   ========================================================================== */
   for ( gcp_i=0; gcp_i<Ngcp; gcp_i++ ) {
      A[ gcp_i ][ 0 ] = A[ Ngcp + gcp_i ][ m + 0 ] = (double)1;
      A[ gcp_i ][ 1 ] = A[ Ngcp + gcp_i ][ m + 1 ] = coor[ gcp_i ].row;
      A[ gcp_i ][ 2 ] = A[ Ngcp + gcp_i ][ m + 2 ] = coor[ gcp_i ].col;
      A[ gcp_i ][ 3 ] = A[ Ngcp + gcp_i ][ m + 3 ] = coor[ gcp_i ].row *
         coor[ gcp_i ].col;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_OneHalfDegMatrEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_TwoDegMatrEval

        $TYPE         PROCEDURE

        $INPUT        coor     : coordinates with which to fill the normal
                                 matrix
                      Ngcp     : the number of valid GCPs

        $MODIFIED     NONE

        $OUTPUT       A        : normal matrix

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         to evaluate

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the normal matrix for the degree
                      two with the GCP(s) previously evaluated

        $WARNING      THE GCP(S) INFO STRUCTURES MUST BE CREATED, FILLED AND
                      THE GCP(S) CO-REGISTERED BEFORE CALLING THIS PROCEDURE

        $PDL          - Loop over the total number of GCP(s)
                            - Fills the normal matrix in all the current
                              row with the master coordinates
                      - End loop

   $EH
   ========================================================================== */

void IREGPP_WAEV_TwoDegMatrEval
                        (/*IN    */ MATHIT_RC           *coor,
                         /*IN    */ INTx4                Ngcp,
                         /*   OUT*/ double             **A,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_TwoDegMatrEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  gcp_i;
   INTx1                  m;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Set the number of parameters
   ========================================================================== */
   m = IREGPC_warp_npar[ 3 ];

/* ==========================================================================
   Copy the GPC(s) coordinates in the matrix
   ========================================================================== */
   for ( gcp_i=0; gcp_i<Ngcp; gcp_i++ ) {
      A[ gcp_i ][ 0 ] = A[ Ngcp + gcp_i ][ m + 0 ] = (double)1;
      A[ gcp_i ][ 1 ] = A[ Ngcp + gcp_i ][ m + 1 ] = coor[ gcp_i ].row;
      A[ gcp_i ][ 2 ] = A[ Ngcp + gcp_i ][ m + 2 ] = coor[ gcp_i ].col;
      A[ gcp_i ][ 3 ] = A[ Ngcp + gcp_i ][ m + 3 ] =
         POW ( coor[ gcp_i ].row, 2. );
      A[ gcp_i ][ 4 ] = A[ Ngcp + gcp_i ][ m + 4 ] = coor[ gcp_i ].row *
         coor[ gcp_i ].col;
      A[ gcp_i ][ 5 ] = A[ Ngcp + gcp_i ][ m + 5 ] =
         POW ( coor[ gcp_i ].col, 2. );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_TwoDegMatrEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_ThreeDegMatrEval

        $TYPE         PROCEDURE

        $INPUT        coor     : coordinates with which to fill the normal
                                 matrix
                      Ngcp     : the number of valid GCPs

        $MODIFIED     NONE

        $OUTPUT       A        : normal matrix

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         to evaluate

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the normal matrix for the degree
                      three with the GCP(s) previously evaluated

        $WARNING      THE GCP(S) INFO STRUCTURES MUST BE CREATED, FILLED AND
                      THE GCP(S) CO-REGISTERED BEFORE CALLING THIS PROCEDURE

        $PDL          - Loop over the total number of GCP(s)
                            - Fills the normal matrix in all the current
                              row with the master coordinates
                      - End loop

   $EH
   ========================================================================== */

void IREGPP_WAEV_ThreeDegMatrEval
                        (/*IN    */ MATHIT_RC           *coor,
                         /*IN    */ INTx4                Ngcp,
                         /*   OUT*/ double             **A,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_ThreeDegMatrEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  gcp_i;
   INTx1                  m;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Set the number of parameters
   ========================================================================== */
   m = IREGPC_warp_npar[ 4 ];

/* ==========================================================================
   Copy the GPC(s) coordinates in the matrix
   ========================================================================== */
   for ( gcp_i=0; gcp_i<Ngcp; gcp_i++ ) {
      A[ gcp_i ][ 0 ] = A[ Ngcp + gcp_i ][ m + 0 ] = (double)1;
      A[ gcp_i ][ 1 ] = A[ Ngcp + gcp_i ][ m + 1 ] = coor[ gcp_i ].row;
      A[ gcp_i ][ 2 ] = A[ Ngcp + gcp_i ][ m + 2 ] = coor[ gcp_i ].col;
      A[ gcp_i ][ 3 ] = A[ Ngcp + gcp_i ][ m + 3 ] =
         POW ( coor[ gcp_i ].row, 2. );
      A[ gcp_i ][ 4 ] = A[ Ngcp + gcp_i ][ m + 4 ] = coor[ gcp_i ].row *
         coor[ gcp_i ].col;
      A[ gcp_i ][ 5 ] = A[ Ngcp + gcp_i ][ m + 5 ] =
         POW ( coor[ gcp_i ].col, 2. );
      A[ gcp_i ][ 6 ] = A[ Ngcp + gcp_i ][ m + 6 ] =
         POW ( coor[ gcp_i ].row, 3. );
      A[ gcp_i ][ 7 ] = A[ Ngcp + gcp_i ][ m + 7 ] =
         POW ( coor[ gcp_i ].row, 2. ) * coor[ gcp_i ].col;
      A[ gcp_i ][ 8 ] = A[ Ngcp + gcp_i ][ m + 8 ] = coor[ gcp_i ].row *
         POW ( coor[ gcp_i ].col, 2. );
      A[ gcp_i ][ 9 ] = A[ Ngcp + gcp_i ][ m + 9 ] =
         POW ( coor[ gcp_i ].col, 3. );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_ThreeDegMatrEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_OneDegConv

        $TYPE         PROCEDURE

        $INPUT        x : coordinates to transform
                      T : matrix of transformation

        $MODIFIED     NONE

        $OUTPUT       y : coordinates transformed

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure transform the coordinates with the matrix
                      <T>

        $WARNING      NONE

        $PDL          - Evaluates the row coordinate of the output point
                      - Evaluates the col coordinate of the output point

   $EH
   ========================================================================== */

void IREGPP_WAEV_OneDegConv
                        (/*IN    */ MATHIT_RC            x,
                         /*IN    */ double             **T,
                         /*   OUT*/ MATHIT_RC           *y,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_OneDegConv";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the value of the output coordinates
   ========================================================================== */
   y->row = T[ 0 ][ 0 ] + T[ 0 ][ 1 ] * x.row + T[ 0 ][ 2 ] * x.col;
   y->col = T[ 1 ][ 0 ] + T[ 1 ][ 1 ] * x.row + T[ 1 ][ 2 ] * x.col;

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_OneDegConv */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_OneAndHalfDegConv

        $TYPE         PROCEDURE

        $INPUT        x : coordinates to transform
                      T : matrix of transformation

        $MODIFIED     NONE

        $OUTPUT       y : coordinates transformed

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure transform the coordinates with the matrix
                      <T>

        $WARNING      NONE

        $PDL          - Evaluates the row coordinate of the output point
                      - Evaluates the col coordinate of the output point

   $EH
   ========================================================================== */

void IREGPP_WAEV_OneAndHalfDegConv
                        (/*IN    */ MATHIT_RC            x,
                         /*IN    */ double             **T,
                         /*   OUT*/ MATHIT_RC           *y,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_OneAndHalfDegConv";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the value of the output coordinates
   ========================================================================== */
   y->row = T[ 0 ][ 0 ] + T[ 0 ][ 1 ] * x.row + T[ 0 ][ 2 ] * x.col +
      T[ 0 ][ 3 ] * x.row * x.col;
   y->col = T[ 1 ][ 0 ] + T[ 1 ][ 1 ] * x.row + T[ 1 ][ 2 ] * x.col +
      T[ 1 ][ 3 ] * x.row * x.col;

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_OneAndHalfDegConv */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_TwoDegConv

        $TYPE         PROCEDURE

        $INPUT        x : coordinates to transform
                      T : matrix of transformation

        $MODIFIED     NONE

        $OUTPUT       y : coordinates transformed

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure transform the coordinates with the matrix
                      <T>

        $WARNING      NONE

        $PDL          - Evaluates the row coordinate of the output point
                      - Evaluates the col coordinate of the output point

   $EH
   ========================================================================== */

void IREGPP_WAEV_TwoDegConv
                        (/*IN    */ MATHIT_RC            x,
                         /*IN    */ double             **T,
                         /*   OUT*/ MATHIT_RC           *y,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_TwoDegConv";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the value of the output coordinates
   ========================================================================== */
   y->row = T[ 0 ][ 0 ] + T[ 0 ][ 1 ] * x.row + T[ 0 ][ 2 ] * x.col +
      T[ 0 ][ 3 ] * x.row * x.row + T[ 0 ][ 4 ] * x.row * x.col +
      T[ 0 ][ 5 ] * x.col * x.col;
   y->col = T[ 1 ][ 0 ] + T[ 1 ][ 1 ] * x.row + T[ 1 ][ 2 ] * x.col +
      T[ 1 ][ 3 ] * x.row * x.row + T[ 1 ][ 4 ] * x.row * x.col +
      T[ 1 ][ 5 ] * x.col * x.col;

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_TwoDegConv */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_ThreeDegConv

        $TYPE         PROCEDURE

        $INPUT        x : coordinates to transform
                      T : matrix of transformation

        $MODIFIED     NONE

        $OUTPUT       y : coordinates transformed

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure transform the coordinates with the matrix
                      <T>

        $WARNING      NONE

        $PDL          - Evaluates the row coordinate of the output point
                      - Evaluates the col coordinate of the output point

   $EH
   ========================================================================== */

void IREGPP_WAEV_ThreeDegConv
                        (/*IN    */ MATHIT_RC            x,
                         /*IN    */ double             **T,
                         /*   OUT*/ MATHIT_RC           *y,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_ThreeDegConv";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the value of the output coordinates
   ========================================================================== */
   y->row = T[ 0 ][ 0 ] + T[ 0 ][ 1 ] * x.row + T[ 0 ][ 2 ] * x.col +
      T[ 0 ][ 3 ] * x.row * x.row + T[ 0 ][ 4 ] * x.row * x.col +
      T[ 0 ][ 5 ] * x.col * x.col + T[ 0 ][ 6 ] * x.row * x.row * x.row +
      T[ 0 ][ 7 ] * x.row * x.row * x.col +
      T[ 0 ][ 8 ] * x.row * x.col * x.col +
      T[ 0 ][ 9 ] * x.col * x.col * x.col;
   y->col = T[ 1 ][ 0 ] + T[ 1 ][ 1 ] * x.row + T[ 1 ][ 2 ] * x.col +
      T[ 1 ][ 3 ] * x.row * x.row + T[ 1 ][ 4 ] * x.row * x.col +
      T[ 1 ][ 5 ] * x.col * x.col + T[ 1 ][ 6 ] * x.row * x.row * x.row +
      T[ 1 ][ 7 ] * x.row * x.row * x.col +
      T[ 1 ][ 8 ] * x.row * x.col * x.col +
      T[ 1 ][ 9 ] * x.col * x.col * x.col;

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_ThreeDegConv */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_EditGCPs

        $TYPE         PROCEDURE

        $INPUT        sla_imanum : slave image ID
                      degree     : degree of the warp transformation

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_gcp           : the structure with the GCPs info
                      IREGPV_max_point_RMS : the maximum allowable point RMS
                                             value

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the RMS for each valid GCP
                      of the given slave image and re-write the master and
                      slave arrays with the only GCPs with the RMS lesser then
                      the fixed value

        $WARNING      NONE

        $PDL          - Loop over the GCPs
                            - If the GCP is valid for the master and the slave
                                  - Converts the current coordinates from
                                    master to slave
                                  - Evaluates the GCP residuals
                                  - If the RMS is lesser then the defined
                                    maximum RMS allowable value
                                        - Sets the GCP invalid for the slave
                                  - End If
                            - End If
                      - End Loop

   $EH
   ========================================================================== */

void IREGPP_WAEV_EditGCPs
                        (/*IN    */ UINTx1               sla_imanum,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGPP_WAEV_EditGCPs";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 mas_imanum = 0;
   INTx4                  gcp_i;
   INTx4                  Npts;
   MATHIT_RC              sla_p;
   MATHIT_LLH             sla_g;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Set the number of valid GCPs
   ========================================================================== */
   Npts = IREGPV_gcp[ mas_imanum ].n_gcp;

/* ==========================================================================
   Initialize the coordinates conversions for the master image
   ========================================================================== */
   COORIP_CONV_Init ( mas_imanum, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Loop over the GCPs
   ========================================================================== */
   for ( gcp_i=0; gcp_i<Npts; gcp_i++ ) {

/* ==========================================================================
   Check if the GCP is valid
   ========================================================================== */
      if ( ( IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].valid ) &&
           ( IREGPV_gcp[ sla_imanum ].gcp_arr[ gcp_i ].valid ) ) {

/* ==========================================================================
   Convert from master to slave
   ========================================================================== */
         IREGPP_WAEV_Mas2Sla ( IREGPV_gcp[ mas_imanum ].gcp_arr[ gcp_i ].coor,
                               degree, sla_imanum, &sla_p, status_code ); 
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the residuals 
   ========================================================================== */
         sla_p.row -= IREGPV_gcp[ sla_imanum ].gcp_arr[ gcp_i ].coor.row;
         sla_p.col -= IREGPV_gcp[ sla_imanum ].gcp_arr[ gcp_i ].coor.col;

/* ==========================================================================
   Check the RMS
   ========================================================================== */
         if ( sqrt ( POW ( sla_p.row, 2. ) + POW ( sla_p.col, 2. ) ) <
              IREGPV_max_point_RMS ) {
#ifdef __TRACE__
   fprintf ( stdout, "\n GCP # %d, Slave Resid. = ( %lf, %lf ), RMS = %lf",
             gcp_i + 1, sla_p.row, sla_p.col,
             sqrt ( POW ( sla_p.row, 2. ) + POW ( sla_p.col, 2. ) ) );
#endif
            IREGPV_gcp[ sla_imanum ].gcp_arr[ gcp_i ].valid = TRUE;
         }
         else {

/* ==========================================================================
   Convert the master coordinates into slave ones
   ========================================================================== */
            COORIP_CONV_rc_llh ( &(IREGPV_gcp[ mas_imanum ].gcp_arr[
                                      gcp_i ].coor),
                                 (INTx4)mas_imanum, &sla_g, status_code );
            ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Initialize the coordinates conversions for the slave
   ========================================================================== */
            COORIP_CONV_Init ( sla_imanum, status_code );
            ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Convert from geodetic to image coordinates
   ========================================================================== */
            COORIP_CONV_llh_rc ( &sla_g, (INTx4)sla_imanum,
                                 &(IREGPV_gcp[ sla_imanum ].gcp_arr[
                                      gcp_i ].coor),
                                 status_code );
            ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Set the GCP invalid
   ========================================================================== */
            IREGPV_gcp[ sla_imanum ].gcp_arr[ gcp_i ].valid = FALSE;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGPP_WAEV_EditGCPs */

#ifdef __EXAM__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGIP_WAEV_

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void IREGIP_WAEV_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IREGIP_WAEV_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IREGIP_WAEV_ */
#endif
