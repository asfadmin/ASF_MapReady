/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_TFDM

      $FUNCTION          Tiff fields data list internal services

      $ROUTINE           PMDSPP_TFDM_AddTiffField
                         PMDSPP_TFDM_FreeTiffField
                         PMDSPP_TFDM_GetTagFromDescr
                         PMDSPP_TFDM_GetTagsFromFile

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       24-SEP-97     DDN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <stdlib.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include PMDS_INTF_H
#include PMDS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_TFDM_AddTiffField

        $TYPE         PROCEDURE

        $INPUT        field_name_p        : tiff field name (description)
                      field_value_p       : pointer to the tiff field value
 
        $MODIFIED     tiff_field_list_p   : pointer to the tiff fields list

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_alloc_memory

        $DESCRIPTION  This procedure allows to add the list containing the
                      fields to be put into the output tiff file.  

        $WARNING      BE SURE TO SET TO NULL THE LIST POINTER AND THE LIST
                      INDEX COUNTER AT THE START-UP.

        $PDL

   $EH
   ========================================================================== */

void PMDSPP_TFDM_AddTiffField
                        (/*IN    */ char                *field_name_p,
                         /*IN    */ char                *field_value_p,
                         /*IN OUT*/ PMDSPT_TiffList     *tiff_field_list_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_TFDM_AddTiffField";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   INTx4                  itag;       /* convenient loop variable */
   INTx4                  found;      /* convenient loop variable */
   UINTx2                 tag;        /* tag to be set into the tiff field */
   char                   field_name[256]; /* temporary field name */
   char                   msg[ 256 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get tag from description
   ========================================================================== */
   strcpy(field_name, field_name_p);
   PMDSPP_TFDM_GetTagFromDescr(field_name, &tag, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check if tag has already been found
   ========================================================================== */
   found = 0;
   for(itag = 0; itag < tiff_field_list_p->num; itag++)
   {
      if((tag == tiff_field_list_p->list[itag].tag) && (tag > 2000))
      {
         sprintf( msg, "Tag %s (%0d) already exists: storing last value",
            field_name, tag );
         ERRSIM_print_warning( msg );
/* ==========================================================================
         Set data into the new item
   ========================================================================== */
         strcpy(tiff_field_list_p->list[itag].name, field_name);
         tiff_field_list_p->list[itag].type = PMDSPE_string_parm;
         strcpy(tiff_field_list_p->list[itag].value, field_value_p);
         found = 1;
         break;
      }
   }

/* ==========================================================================
   Add an item only if a tag has been found
   ========================================================================== */
   if((tag != 0) && (found == 0))
   {
/* ==========================================================================
      Try to allocate a new item into the tiff field list
   ========================================================================== */
      if((tiff_field_list_p->list = (PMDSPT_TiffField *) MEMSIP_realloc( 
         tiff_field_list_p->list, (size_t)((tiff_field_list_p->num + 1) *
         sizeof(PMDSPT_TiffField)))) == NULL)
      {
         ERRSIM_set_error( status_code, ERRSID_PMDS_alloc_memory,
            "adding tiff field" );
      }

/* ==========================================================================
      Increase the list counter
   ========================================================================== */
      tiff_field_list_p->num++;

/* ==========================================================================
      Set data into the new item
   ========================================================================== */
      tiff_field_list_p->list[tiff_field_list_p->num - 1].tag = tag;
      strcpy(tiff_field_list_p->list[tiff_field_list_p->num - 1].name,
         field_name);
      tiff_field_list_p->list[tiff_field_list_p->num - 1].type =
         PMDSPE_string_parm;
      strcpy(tiff_field_list_p->list[tiff_field_list_p->num - 1].value,
         field_value_p);
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_TFDM_AddTiffField */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_TFDM_FreeTiffField

        $TYPE         PROCEDURE

        $INPUT        NONE
 
        $MODIFIED     tiff_field_list_p   : pointer to the tiff fields list

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure allows to free the list containing the
                      fields to be put into the output tiff file.  

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSPP_TFDM_FreeTiffField
                        (/*IN OUT*/ PMDSPT_TiffList     *tiff_field_list_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_TFDM_FreeTiffField";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Try to free the tiff field list
   ========================================================================== */
   MEMSIP_free((void**) &(tiff_field_list_p->list));

/* ==========================================================================
   Reset the list counter
   ========================================================================== */
   tiff_field_list_p->num = 0;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_TFDM_FreeTiffField */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_TFDM_GetTagFromDescr

        $TYPE         PROCEDURE

        $INPUT        descr_p             : tiff field name (description)
 
        $MODIFIED     NONE

        $OUTPUT       tag_p               : pointer to the tag to be returned

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_alloc_memory
                      ERRSID_PMDS_not_found

        $DESCRIPTION  This procedure allows to find a tag into the tag list 
                      according to its description (tiff field name)

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSPP_TFDM_GetTagFromDescr
                        (/*IN    */ char                *descr_p,
                         /*   OUT*/ UINTx2              *tag_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_TFDM_GetTagFromDescr";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   INTx4                  ichar;      /* Convenient loop variable */
   INTx4                  itag;       /* Convenient loop variable */
   char                   file_name[256]; /* tag file name */
   static PMDSPT_TagList  tag_data;   /* structure containing array of tags */
   char                   msg[ 132 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set data to default value(s)
   ========================================================================== */
   *tag_p = 0;

/* ==========================================================================
   Try (if not already done) to load tags from file
   ========================================================================== */
#ifdef __VMS__
   sprintf(file_name, "%s%s", "inc$:", "iann_tags.h");
#else
   sprintf(file_name, "%s%s", LDEFIV_cfg_dir, "tags.h");
#endif
   if(tag_data.num == 0)
   {
      PMDSPP_TFDM_GetTagsFromFile(file_name, &tag_data, status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Loop onto the tag list
   ========================================================================== */
   for(ichar = 0; ichar < strlen(descr_p); ichar++)
   {
      descr_p[ichar] = tolower(descr_p[ichar]);
   }
/* ==========================================================================
   Loop onto the tag list
   ========================================================================== */
   for(itag = 0; itag < tag_data.num; itag++)
   {
      if((strcmp(descr_p, tag_data.list[itag].name)) == 0)
      {
/* ==========================================================================
         Check if tag is a not a basic tag
   ========================================================================== */
         if(tag_data.list[itag].tag > 2000)
         {
            *tag_p = tag_data.list[itag].tag;
         }
         break;
      }
   }

   if( itag == tag_data.num ) {
      sprintf( msg, "<%s> does not exists in the %s dictionary",
               descr_p, file_name );
      ERRSIM_print_warning( msg );
      *tag_p = 0;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_TFDM_GetTagFromDescr */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_TFDM_GetTagsFromFile

        $TYPE         PROCEDURE

        $INPUT        file_name_p         : file name with tags definitions
 
        $MODIFIED     NONE

        $OUTPUT       tag_data_p          : pointer to the tags list

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_not_found

        $DESCRIPTION  This procedure allows to fill tag list from file data.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSPP_TFDM_GetTagsFromFile
                        (/*IN    */ char                *file_name_p,
                         /*   OUT*/ PMDSPT_TagList      *tag_data_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_TFDM_GetTagsFromFile";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   INTx4                  ichar;      /* Convenient loop variable */
   FILE                   *fp;        /* file pointer */
   char                   buffer[256]; /* line read from file */
   char                   define[256]; /* define temporary buffer */
   char                   tagname[256]; /* tagname buffer */
   UINTx2                 tag;        /* tag value */
   char                   msg[256];   /* message buffer */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Open file containing tags
   ========================================================================== */
   if((fp = fopen(file_name_p, "r")) == NULL)
   {
      sprintf(msg, "Cannot open tags file: %s", file_name_p);
      ERRSIM_set_error(status_code, ERRSID_PMDS_not_found, msg);
   }

/* ==========================================================================
   Loop onto the tag file line(s)
   ========================================================================== */
   tag_data_p->num = 0;
   while(fgets(buffer, sizeof(buffer), fp) != NULL)
   {
      for(ichar = (strlen(buffer) - 1); ichar >= 0; ichar--)
      {
         if(buffer[ichar] == '\n')
            buffer[ichar] = '\0';
      }

      if((strncmp(buffer, "#define", (strlen("#define") - 1))) == 0)
      {
#ifdef __VMS__
         if((sscanf(buffer, "%s %s %d", define, tagname, &tag)) == 3)
#else
         if((sscanf(buffer, "%s %s %hd", define, tagname, &tag)) == 3)
#endif
         {
/* ==========================================================================
            Set tag data onto a new tag array item
   ========================================================================== */
            strcpy(tag_data_p->list[tag_data_p->num].name, tagname);
            for(ichar = 0; ichar < strlen(tagname); ichar++)
            {
                tag_data_p->list[tag_data_p->num].name[ichar] =
                   tolower(tagname[ichar]);
            }
            tag_data_p->list[tag_data_p->num].tag = tag;
/* ==========================================================================
            Increase tags counter
   ========================================================================== */
            tag_data_p->num++;

/* ==========================================================================
            Check if tags found are more than allowed
   ========================================================================== */
            if(tag_data_p->num >= PMDSPD_max_tags_num)
               break;
         }
      }
   }

/* ==========================================================================
   Close tags file
   ========================================================================== */
   fclose(fp);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_TFDM_GetTagsFromFile */

