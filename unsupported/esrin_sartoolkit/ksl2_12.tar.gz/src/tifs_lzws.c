/* ==========================================================================
   $MODULE_HEADER

      $NAME              TIFS_LZWS

      $FUNCTION          

      $ROUTINE           TIFS_LZWS

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       07-JAN-97     AG       Initial Release

   $EH
   ========================================================================== */

/*****************************************************************************/
/* Algoritmo di codifica/decodifica LZW  per formato TIFF                    */
/*                                                                           */
/*                                           by C.MARZO  01/10/92            */
/*                                                                           */
/* modifica del 25/03/93: miglioramento del controllo sul numero di bytes    */
/*                          letti e verifica del codice END_OF_IMAGE         */
/*****************************************************************************/
#define CLEAR_CODE 256
#define END_OF_IMAGE 257
#define MAX_TABLE_ENTRY 4094
#define LZW_NO_DEBUG

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <string.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include TIFS_INTF_H
#include TIFS_PGLB_H

/* ==========================================================================
                        LOCAL ROUTINE DECLARATION SECTION
   ========================================================================== */

/*************************************************************************/
static void LZWencInitializeStringTable(void)
{
    UINTx4       i;

    for (i=0;i<258;i++) {
	TIFSPV_StringTable[i].Pr = END_OF_IMAGE;
	TIFSPV_StringTable[i].Co = i;
	TIFSPV_StringTable[i].NextPrHi = i;
	TIFSPV_StringTable[i].NextPrLo = i;
	TIFSPV_StringTable[i].FrstPr   = i;
    }
    for (i=258;i<4096;i++) {
	TIFSPV_StringTable[i].Pr = END_OF_IMAGE;
	TIFSPV_StringTable[i].Co = END_OF_IMAGE;
	TIFSPV_StringTable[i].NextPrHi = i;
	TIFSPV_StringTable[i].NextPrLo = i;
	TIFSPV_StringTable[i].FrstPr   = i;
    }
    /* inizializzazione del numero di bit da assegnare al codice */
    for (i=   0;i< 512;i++) TIFSPV_StringTable[i].NBitCode = 9;
    for (i= 512;i<1024;i++) TIFSPV_StringTable[i].NBitCode = 10;
    for (i=1024;i<2048;i++) TIFSPV_StringTable[i].NBitCode = 11;
    for (i=2048;i<4097;i++) TIFSPV_StringTable[i].NBitCode = 12;

    NextTableEntry = 258;
    CodeNumBit = 9;
}
/*************************************************************************/
static void LZWdecInitializeStringTable(void)
{
    UINTx4       i;

    for (i=0;i<258;i++) {
	TIFSPV_StringTable[i].Pr = END_OF_IMAGE;
	TIFSPV_StringTable[i].Co = i;
    }
    for (i=258;i<4096;i++) {
	TIFSPV_StringTable[i].Pr = END_OF_IMAGE;
	TIFSPV_StringTable[i].Co = END_OF_IMAGE;
    }
    /* inizializzazione del numero di bit da assegnare al codice */
    for (i=   0;i< 511;i++) TIFSPV_StringTable[i].NBitCode = 9;
    for (i= 511;i<1023;i++) TIFSPV_StringTable[i].NBitCode = 10;
    for (i=1023;i<2047;i++) TIFSPV_StringTable[i].NBitCode = 11;
    for (i=2047;i<4097;i++) TIFSPV_StringTable[i].NBitCode = 12;
    NextTableEntry = 258;
    CodeNumBit = 9;
}
/*************************************************************************/
static UINTx4       LZWdecIsInTable(UINTx4       cod)
{
    /* Se la stringa Codice e' presente nella tabella restituisce il
    codice relativo */    
    if (TIFSPV_StringTable[cod].Co != END_OF_IMAGE) 
	return(1); /* Presente */
    return(0); /* Non Presente */
}
/*************************************************************************/
static UINTx4       LZWencIsInTable(UINTx4       pre)
{
    /* La routine verifica se nella tavola dei codici esiste la stringa
       Pre + *EncInCar */

    UINTx4       i, cod, noMoreItem;

    cod = *EncInCar;
    /* Se la stringa Prefisso+Codice e' presente nella tabella 
       restituisce il codice relativo */    
    if ((i = TIFSPV_StringTable[pre].FrstPr) == pre)
        return(0); /* stringa non trovata, restituisce NULL */
    i = TIFSPV_StringTable[pre].FrstPr;
    noMoreItem = 0;
    while (noMoreItem == 0) {
	  /* Stringa tovata, restituisce il codice relativo */
	  if (TIFSPV_StringTable[i].Co == cod)
	     return(i);
	  /* Stringa non trovata, si punta ad una nuova combinazione 
	     prefisso-codice nell'albero binario */
	  if (cod < TIFSPV_StringTable[i].Co) {
	     if (TIFSPV_StringTable[i].NextPrLo == i) 
	        noMoreItem = 1;
	     else
	        i = TIFSPV_StringTable[i].NextPrLo;
	  }
	  else {
	     if (TIFSPV_StringTable[i].NextPrHi == i) 
	        noMoreItem = 1;
	     else
	        i = TIFSPV_StringTable[i].NextPrHi;
	  }
    }
    /* check sull'ultimo elemento della lista */
    if (TIFSPV_StringTable[i].Co == cod  && i > 257)
       return(i);
    return(0); /* stringa non trovata, restituisce NULL */
}
/*************************************************************************/
static UINTx4       LZWencGetNewPrefix(UINTx4       pre, UINTx4       cod)
{
    INTx4 i, foundPos;

    TIFSPV_StringTable[NextTableEntry].Pr = pre;
    TIFSPV_StringTable[NextTableEntry].Co = cod;
    /* aggiornamento dell'albero */
    if ((i = TIFSPV_StringTable[pre].FrstPr) == pre)
       TIFSPV_StringTable[pre].FrstPr = NextTableEntry;
    /* ricerca della posizione da assumere nell'albero e set dei puntatori,
       il ciclo di ricerca viene eseguito se esiste almeno una diramazione */
    else {
	foundPos = 0;
	while (foundPos == 0) {
	    if (cod < TIFSPV_StringTable[i].Co) {
	        if (TIFSPV_StringTable[i].NextPrLo == i) {
		   TIFSPV_StringTable[i].NextPrLo = NextTableEntry;
		   foundPos = 1;
		} else
		   i = TIFSPV_StringTable[i].NextPrLo;
	    }
	    else {
	        if (TIFSPV_StringTable[i].NextPrHi == i) {
		   TIFSPV_StringTable[i].NextPrHi = NextTableEntry;
		   foundPos = 1;
                }
		else
		   i = TIFSPV_StringTable[i].NextPrHi;
	    }
	}
    } /* fine ciclo ricerca posizione */
    /* aggiornamento della lunghezza in bit del codice */
    CodeNumBit = TIFSPV_StringTable[NextTableEntry].NBitCode;
    /* Dopo aver aggiornato il puntatore alla prossima Table entry 
       ritorna il valore della entry corrente */
    NextTableEntry++;
    return(NextTableEntry - 1); 
}
/*************************************************************************/
static UINTx4       LZWdecGetNewPrefix(UINTx4       pre, UINTx4       cod)
{
    TIFSPV_StringTable[NextTableEntry].Pr = pre;
    TIFSPV_StringTable[NextTableEntry].Co = cod;
    /* aggiornamento della lunghezza in bit del codice */
    CodeNumBit = TIFSPV_StringTable[NextTableEntry].NBitCode;
    /* Dopo aver aggiornato il puntatore alla prossima Table entry 
       ritorna il valore della entry corrente */
    NextTableEntry++;
    return(NextTableEntry - 1); 
}
/*************************************************************************/
static void LZWencWriteCode(UINTx4       cod)
{
    INTx4 i;

    /*printf(" %d", Cod);*/
    /* loop su tutti i bit da scrivere */
    for(i=CodeNumBit-1; i >= 0; i--) {
       *EncOutCar |= (((cod >> i) & 0x0001) << FBitFree);
       /* aggiornamento del puntatore al bit da scrivere nei bytes di out */
       if (FBitFree > 0) 
          FBitFree--;
       else {
          FBitFree = 7;
	  EncOutCar++;
          *EncOutCar = 0;
	  EncNOutCar++;
       }
    } /* fine loop sui bit */
}
/*************************************************************************/
static UINTx4       LZWdecGetNextCode(void)
{
    INTx4 i;
    UINTx4       cod;

    cod = 0;
    /* loop su tutti i bit da leggere */
    for(i=CodeNumBit - 1; i >= 0; i--) {
       cod |= ((*DecInCar >> FBitToMove) & 0x0001) << i;
       /* aggiornamento puntatore al bit da leggere nel byte di input */
       if (FBitToMove > 0)
          FBitToMove--;
       else {
          FBitToMove = 7;
          /* aggiorna il puntatore al buffer di input ed 
          ilnumero di caratteri letti */
	  DecInCar++;
          DecNInCar++;
       }
    } /* fine loop sui bit */
    return(cod);
}
/*************************************************************************/
static void LZWdecWriteOutString(UINTx4       cod)
{
    if (cod < 256) {
       *DecOutCar++ = cod;
       DecNOutCar++;
       /* printf(" %d", cod);*/
    } else {
       LZWdecWriteOutString(TIFSPV_StringTable[cod].Pr);
       *DecOutCar++ = TIFSPV_StringTable[cod].Co;
       DecNOutCar++;
       /*printf(" %d", TIFSPV_StringTable[cod].Co);*/
    }
}
/*************************************************************************/
static UINTx4       LZWdecFirstChar(UINTx4       cod)
{
    if (cod < 256)
	return(cod);
    else
	return(LZWdecFirstChar(TIFSPV_StringTable[cod].Pr));
}


/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_LZWencode

        $TYPE	      PROCEDURE

        $INPUT        pibuff: pointer to input buffer
		      ibuffLen: length of input buffer

        $MODIFIED     NONE

        $OUTPUT       pobuff: pointer to output buffer
                      obuffLen: length of output buffer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  LZW encode procedure

        $WARNING      NONE

   $EH
   ========================================================================== */
void TIFSPP_LZWencode
                        ( /*IN    */ UINTx1        *pibuff, 
                          /*IN    */ UINTx4         ibuffLen, 
                          /*   OUT*/ UINTx1        *pobuff, 
                          /*   OUT*/ UINTx4        *obuffLen,
                          /*   OUT*/ ERRSIT_status *status_code)
{
   const ERRSIT_proc_name routine_name = "TIFSPP_LZWencode";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i, temp, prefix;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);


   FBitFree = 7;
   FBitToMove = 7;
   EncNOutCar = 0;
   EncOutCar = pobuff;
   EncInCar  = pibuff;
   LZWencInitializeStringTable();
   LZWencWriteCode(CLEAR_CODE);
   prefix = *EncInCar;
   for(i=1; i<ibuffLen; i++) {
      EncInCar++;
      if (temp = LZWencIsInTable(prefix)) {
	 prefix = temp; /* concatenazione */
      } 
      else {
	 LZWencWriteCode(prefix);
	 /* Invio codice reset della tabella dei codici
	    quando viene raggiunta la massima dimensione della 
	    tabella di codici */
	 if (NextTableEntry == MAX_TABLE_ENTRY) {
	    LZWencWriteCode(CLEAR_CODE);
	    LZWencInitializeStringTable();
	    prefix = *EncInCar;
	 }
	 else {
	    /* prefix e' utilizzata come dummy */
	    prefix = LZWencGetNewPrefix(prefix, *EncInCar); 
	    prefix = *EncInCar;
	 }
      }
   } /* Loop on Input String */
   LZWencWriteCode(prefix);
   LZWencWriteCode(END_OF_IMAGE);
   EncNOutCar++;
   *obuffLen = EncNOutCar;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSPP_LZWencode */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSPP_LZWdecode

        $TYPE	      PROCEDURE

        $INPUT        pibuff: pointer to input buffer
		      ibuffLen: length of input buffer

        $MODIFIED     NONE

        $OUTPUT       pobuff: pointer to output buffer
                      obuffLen: length of output buffer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  LZW decode procedure

        $WARNING      NONE

   $EH
   ========================================================================== */
void TIFSPP_LZWdecode   ( /*IN    */ UINTx1        *pibuff, 
                          /*IN    */ UINTx4         ibuffLen, 
                          /*   OUT*/ UINTx1        *pobuff, 
                          /*   OUT*/ UINTx4        *obuffLen,
                          /*   OUT*/ ERRSIT_status *status_code)
{
   const ERRSIT_proc_name routine_name = "TIFSPP_LZWdecode";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 code, oldCode, outString;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   FBitFree = 7;
   FBitToMove = 7;
   DecNOutCar = 0;
   DecNInCar  = 0; 
   *obuffLen = 0;
   DecInCar  = pibuff;
   DecOutCar = pobuff;
   oldCode = CLEAR_CODE;
   CodeNumBit = 9;

   /* ciclo principale. se viene raggiunto il massimo numero di bytes
      in ingresso senza incontrare un END_OF_IMAGE viene riportato un 
      errore (vedi fine routine) */
   while(((code = LZWdecGetNextCode()) != END_OF_IMAGE) && 
            DecNInCar <= ibuffLen) {
      if (code == CLEAR_CODE) {
	 LZWdecInitializeStringTable();
	 code = LZWdecGetNextCode();
	 if (code == END_OF_IMAGE)
	    break;
	 LZWdecWriteOutString(code);
	 oldCode = code;
      } /* end of CLEAR_CODE case */
      else {
         if (LZWdecIsInTable(code)) {
	    /* Nuovo codice nella tavola, outString e' Dummy */
	    outString = LZWdecGetNewPrefix(oldCode, 
					   LZWdecFirstChar(code)); 
	    LZWdecWriteOutString(code);
	    oldCode = code;
	 }
	 else {
	    /* Nuovo codice nella tavola */
	    outString = LZWdecGetNewPrefix(oldCode, 
					   LZWdecFirstChar(oldCode)); 
	    LZWdecWriteOutString(outString);
	    oldCode = code;
	 }
      } /* end of not CLEAR_CODE case */
   } /* end of while cicle */
   /* return number of bytes */
   *obuffLen = DecNOutCar;
   /* se il numero di bytes letti e' superiore alla dimensione del
      buffer di input viene data una segnalazione di errore */ 
   if (DecNInCar > ibuffLen)
       printf("\n ! Errore troppi bytes in input, END_OF_IMAGE non trovato");
    
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSPP_LZWdecode */

