/* ==========================================================================
   $MODULE_HEADER

      $NAME              STAT_KERN

      $FUNCTION          This module contains the definition of 
                         kernel-image window convolution when generating
			 LOCAL STATISTIC image

      $ROUTINE           STATPP_KERN_Mean
                         STATPP_KERN_Sddv
			 STATPP_KERN_Cfvr
			 STATPP_KERN_Copy

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       06-AUG-97     AG       Initial Release
          SCR #2      26-NOV-97     GRV      Fixed bug on the AoI management
          SCR #4      27-NOV-97     AG       Check args of sqrt and cfvr 
                                             computation
          SCR #5      27-NOV-97     AG       Changed checks of Kr and Kc
                                             RStartW vs RStopW
            N/A       23-MAR-97     AG       Add for Reqs B10/B18

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <math.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include GIOS_INTF_H
#include SRVS_INTF_H
#include COOR_INTF_H
#include STAT_INTF_H
#include STAT_PGLB_H


/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STATPP_KERN_Mean

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI

        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STAT_kernel_dim_high
		      ERRSID_STAT_bad_steps
		      ERRSID_STAT_bad_write_size
		      ERRSID_STAT_err_mem_alloc
		      ERRSID_STAT_data_type_not_allow

        $DESCRIPTION  This procedure convolves the constant kernel given in
		      input with the image block also given and writes the
		      output in the file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
					- Check if whole window is inside AOI
                                        - Sum the window element
                                        - Fill the output vector rescaling it
					  by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */
void STATPP_KERN_Mean
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
			 /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STATPP_KERN_Mean";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 rs;
   UINTx4                 cs;
   UINTx4                 RStart;
   UINTx4                 RStop;
   UINTx4                 CStart;
   UINTx4                 CStop;
   REGISTER UINTx4	  row, col;
   MATHIT_RC              point;
   INTx4                  in_out;
   float                 *OutIma = (float *)NULL;
   float		  k;
   REGISTER UINTx2        i;
   REGISTER UINTx2        j;
   REGISTER double        OutPoint;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the kernel sizes consistency
   ========================================================================== */
   if ( ( Kr > nrow_inp ) || ( Kc > ncol_inp ) )
      ERRSIM_set_error( status_code, ERRSID_STAT_kernel_dim_high, "" );

/* ==========================================================================
   Check the steps values
   ========================================================================== */
   if ( ( StepR <= 0.0 ) || ( StepC <= 0.0 ) )
      ERRSIM_set_error( status_code, ERRSID_STAT_bad_steps, "" );

/* ==========================================================================
   Check the writing counters
   ========================================================================== */
   if ( RStartW > RStopW )
      ERRSIM_set_error( status_code, ERRSID_STAT_bad_write_size, "" );

/* ==========================================================================
   Copy the kernel value in a variable
   ========================================================================== */
   k = Kern[ 0 ][ 0 ];

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
   if ( ( OutIma = (float *)
           MEMSIP_alloc((size_t)(ncol_out * sizeof(float))) ) ==(float *)NULL) {
      ERRSIM_set_error( status_code, ERRSID_STAT_err_mem_alloc, "" );
   }

#ifdef __TRACE__
   fprintf( stderr, "%s: RStartR = %0d\nStepR = %20.10f StepC = %20.10f\n", 
            routine_name, RStartR, StepR, StepC );
   fprintf( stderr, "%s: inp_data_type = %0d\n", routine_name, inp_data_type);
#endif

/* ==========================================================================
   Switch the various input types
   ========================================================================== */
   switch ( inp_data_type ) {
      case LDEFIE_dt_UINTx1: {
         REGISTER UINTx1       *p = (UINTx1 *)NULL;

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
               CStart = (UINTx4) ROUND( cs * StepC );
               RStop = RStart + Kr - 1;
               CStop = CStart + Kc - 1;
#ifdef __TRACE__
   fprintf( stderr, "%s: RStart = %0d RStop = %0d CStart = %0d CStop = %0d\n",
                    routine_name, RStart, RStop, CStart, CStop );
#endif

/* ==========================================================================
   Chek if this kernel step belong to AOI, if any
   ========================================================================== */
	       if( vertex_no > 0 ) {
		  for( row=RStart; row<=RStop; row++) {
		     point.row = (double) row;
		     for( col=CStart; col<=CStop; col++) {
			point.col = (double) col;
			COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point,
						     &in_out, status_code);
			if( in_out < 0 ) break;
		     }
		     if( in_out < 0 ) break;
	          }
	       }
	       else {
		  in_out = 1;
	       }

/* ==========================================================================
   If the kernel step is not in AOI write the filler value
   ========================================================================== */
	       if( in_out < 0 ) {
		  OutIma[ cs ] = fill_val;
	       }
	       else {	       
/* ==========================================================================
   else execute the convolution core
   ========================================================================== */
		  OutPoint = 0.0;
		  for ( i=0; i<Kr; i++ ) {

		     /* point to the beginning of the matrices rows */
		     p = &((UINTx1 **)InpIma)[ RStart + i ][ CStart ] - 1;

		     /* internal convolution loop */
		     for ( j=0; j<Kc; j++ ) OutPoint += (double)(*++p);
		  }

/* ==========================================================================
   Fill the output vector
   ========================================================================== */
		  OutIma[ cs ] = (float) (OutPoint * ((double) k));
	       }
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      break;
      case LDEFIE_dt_UINTx2: {
         REGISTER UINTx2       *p = (UINTx2 *)NULL;

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
               CStart = (UINTx4) ROUND( cs* StepC );
               RStop = RStart + Kr - 1;
               CStop = CStart + Kc - 1;

#ifdef __TRACE__
   fprintf( stderr, "%s: RStart = %0d RStop = %0d CStart = %0d CStop = %0d\n",
                    routine_name, RStart, RStop, CStart, CStop );
#endif

/* ==========================================================================
   Chek if this kernel step belong to AOI, if any
   ========================================================================== */
	       if( vertex_no > 0 ) {
		  for( row=RStart; row<=RStop; row++) {
                     point.row = (double) row;
		     for( col=CStart; col<=CStop; col++) {
			point.col = (double) col;
			COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point,
						     &in_out, status_code );
			if( in_out < 0 ) break;
		     }
		     if( in_out < 0 ) break;
	          }
	       }
	       else {
		  in_out = 1;
	       }

/* ==========================================================================
   If the kernel step is not in AOI write the filler value
   ========================================================================== */
	       if( in_out < 0 ) {
		  OutIma[ cs ] = fill_val;
	       }
	       else {	       
/* ==========================================================================
   else execute the convolution core
   ========================================================================== */
		  OutPoint = 0.0;
		  for ( i=0; i<Kr; i++ ) {

		     /* point to the beginning of the matrices rows */
		     p = &((UINTx2 **)InpIma)[ RStart + i ][ CStart ] - 1;

		     /* internal convolution loop */
		     for ( j=0; j<Kc; j++ ) OutPoint += (double)(*++p);
		  }

/* ==========================================================================
   Fill the output vector
   ========================================================================== */
		  OutIma[ cs ] = (float) (OutPoint * ((double) k));
               }
	    }
/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      break;
      case LDEFIE_dt_float: {
         REGISTER float       *p = (float *)NULL;

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
               CStart = (UINTx4) ROUND( cs * StepC );
               RStop = RStart + Kr - 1;
               CStop = CStart + Kc - 1;

#ifdef __TRACE__
   fprintf( stderr, "%s: RStart = %0d RStop = %0d CStart = %0d CStop = %0d\n",
                    routine_name, RStart, RStop, CStart, CStop );
#endif

/* ==========================================================================
   Check if this kernel step belong to AOI, if any
   ========================================================================== */
	       if( vertex_no > 0 ) {
		  for( row=RStart; row<=RStop; row++) {
		     point.row = (double) row;
		     for( col=CStart; col<=CStop; col++) {
			point.col = (double) col;
			COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point,
						     &in_out, status_code );
			if( in_out < 0 ) break;
		     }
		     if( in_out < 0 ) break;
	          }
	       }
	       else {
		  in_out = 1;
	       }

/* ==========================================================================
   If the kernel step is not in AOI write the filler value
   ========================================================================== */
	       if( in_out < 0 ) {
		  OutIma[ cs ] = fill_val;
	       }
	       else {	       
/* ==========================================================================
   else execute the convolution core
   ========================================================================== */
		  OutPoint = 0.0;
		  for ( i=0; i<Kr; i++ ) {

		     /* point to the beginning of the matrices rows */
		     p = &((float **)InpIma)[ RStart + i ][ CStart ] - 1;

		     /* internal convolution loop */
		     for ( j=0; j<Kc; j++ ) OutPoint += (double)(*++p);
		  }

/* ==========================================================================
   Fill the output vector
   ========================================================================== */
		  OutIma[ cs ] = (float) (OutPoint * ((double) k));
               }
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      break;
      case LDEFIE_dt_2_float: {
         REGISTER float       *p = (float *)NULL;

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
               CStart = (UINTx4) ROUND( cs * StepC );
               RStop = RStart + Kr - 1;
               CStop = CStart + Kc - 1;

#ifdef __TRACE__
   fprintf( stderr, "%s: RStart = %0d RStop = %0d CStart = %0d CStop = %0d\n",
                    routine_name, RStart, RStop, CStart, CStop );
#endif

/* ==========================================================================
   Check if this kernel step belong to AOI, if any
   ========================================================================== */
	       if( vertex_no > 0 ) {
		  for( row=RStart; row<=RStop; row++) {
		     point.row = (double) row;
		     for( col=CStart; col<=CStop; col++) {
			point.col = (double) col;
			COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point,
						     &in_out, status_code );
			if( in_out < 0 ) break;
		     }
		     if( in_out < 0 ) break;
	          }
	       }
	       else {
		  in_out = 1;
	       }

/* ==========================================================================
   If the kernel step is not in AOI write the filler value
   ========================================================================== */
	       if( in_out < 0 ) {
		  OutIma[ cs ] = fill_val;
	       }
	       else {	       
/* ==========================================================================
   else execute the convolution core
   ========================================================================== */
		  OutPoint = 0.0;
		  for ( i=0; i<Kr; i++ ) {

		     /* point to the beginning of the matrices rows */
		     p = &((float **)InpIma)[ RStart + i ][ CStart ];

		     /* internal convolution loop */
		     for ( j=0; j<Kc; j++ ) {
                        OutPoint += 
                           sqrt( ((*p) * (*p)) + ((*(p+1)) * (*(p+1))) );
                           p += 2;
                     }
		  }

/* ==========================================================================
   Fill the output vector
   ========================================================================== */
		  OutIma[ cs ] = (float) (OutPoint * ((double) k));
               }
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      break;
      case LDEFIE_dt_2_INTx2: {
         REGISTER INTx2       *p = (INTx2 *)NULL;

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
               CStart = (UINTx4) ROUND( cs * StepC );
               RStop = RStart + Kr - 1;
               CStop = CStart + Kc - 1;

#ifdef __TRACE__
   fprintf( stderr, "%s: RStart = %0d RStop = %0d CStart = %0d CStop = %0d\n",
                    routine_name, RStart, RStop, CStart, CStop );
#endif

/* ==========================================================================
   Check if this kernel step belong to AOI, if any
   ========================================================================== */
	       if( vertex_no > 0 ) {
		  for( row=RStart; row<=RStop; row++) {
		     point.row = (double) row;
		     for( col=CStart; col<=CStop; col++) {
			point.col = (double) col;
			COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point,
						     &in_out, status_code );
			if( in_out < 0 ) break;
		     }
		     if( in_out < 0 ) break;
	          }
	       }
	       else {
		  in_out = 1;
	       }

/* ==========================================================================
   If the kernel step is not in AOI write the filler value
   ========================================================================== */
	       if( in_out < 0 ) {
		  OutIma[ cs ] = fill_val;
	       }
	       else {	       
/* ==========================================================================
   else execute the convolution core
   ========================================================================== */
		  OutPoint = 0.0;
		  for ( i=0; i<Kr; i++ ) {

		     /* point to the beginning of the matrices rows */
		     p = &((INTx2 **)InpIma)[ RStart + i ][ CStart ];

		     /* internal convolution loop */
		     for ( j=0; j<Kc; j++ ) {
                        OutPoint += 
                           sqrt( ((*p) * (*p)) + ((*(p+1)) * (*(p+1))) );
                           p += 2;
                     }
		  }

/* ==========================================================================
   Fill the output vector
   ========================================================================== */
		  OutIma[ cs ] = (float) (OutPoint * ((double) k));
               }
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      break;
      default:
         ERRSIM_set_error( status_code, ERRSID_STAT_data_type_not_allow, "" );
   }

error_exit:;

/* ==========================================================================
   Free the output vector memory
   ========================================================================== */
   MEMSIP_free( (void **)(&OutIma) );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STATPP_KERN_Mean */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STATPP_KERN_Sddv

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI

        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STAT_kernel_dim_high
		      ERRSID_STAT_bad_steps
		      ERRSID_STAT_bad_write_size
		      ERRSID_STAT_err_mem_alloc
		      ERRSID_STAT_data_type_not_allow

        $DESCRIPTION  This procedure convolves the constant kernel given in
		      input with the image block also given and writes the
		      output in the file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
					- Check if whole window is inside AOI
                                        - Sum the window element
					- Sum the square of the window element
                                        - Fill the output vector rescaling it
					  by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */
void STATPP_KERN_Sddv
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
			 /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STATPP_KERN_Sddv";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 rs;
   UINTx4                 cs;
   UINTx4                 RStart;
   UINTx4                 RStop;
   UINTx4                 CStart;
   UINTx4                 CStop;
   REGISTER UINTx4	  row, col;
   MATHIT_RC              point;
   INTx4                  in_out;
   float                 *OutIma = (float *)NULL;
   double		  k;
   REGISTER UINTx2        i;
   REGISTER UINTx2        j;
   REGISTER double        OutPoint;
   REGISTER double        SqrOutPoint;
   double                 sqrtarg;
   char                   errmsg[ 132 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the kernel sizes consistency
   ========================================================================== */
   if ( ( Kr > nrow_inp ) || ( Kc > ncol_inp ) )
      ERRSIM_set_error( status_code, ERRSID_STAT_kernel_dim_high, "" );

/* ==========================================================================
   Check the steps values
   ========================================================================== */
   if ( ( StepR <= 0.0 ) || ( StepC <= 0.0 ) )
      ERRSIM_set_error( status_code, ERRSID_STAT_bad_steps, "" );

/* ==========================================================================
   Check the writing counters
   ========================================================================== */
   if ( RStartW > RStopW )
      ERRSIM_set_error( status_code, ERRSID_STAT_bad_write_size, "" );

/* ==========================================================================
   Copy the kernel value in a variable
   ========================================================================== */
   k = (double) Kern[ 0 ][ 0 ];

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
   if ( ( OutIma = (float *)
           MEMSIP_alloc((size_t)(ncol_out * sizeof(float))) ) ==(float *)NULL) {
      ERRSIM_set_error( status_code, ERRSID_STAT_err_mem_alloc, "" );
   }

/* ==========================================================================
   Switch the various input types
   ========================================================================== */
   switch ( inp_data_type ) {
      case LDEFIE_dt_UINTx1: {
         REGISTER UINTx1       *p = (UINTx1 *)NULL;

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
               CStart = (UINTx4) ROUND( cs* StepC );
               RStop = RStart + Kr - 1;
               CStop = CStart + Kc - 1;

/* ==========================================================================
   Chek if this kernel step belong to AOI, if any
   ========================================================================== */
	       if( vertex_no > 0 ) {
		  for( row=RStart; row<=RStop; row++) {
		     point.row = (double) row;
		     for( col=CStart; col<=CStop; col++) {
			point.col = (double) col;
			COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point,
						     &in_out, status_code );
			if( in_out < 0 ) break;
		     }
		     if( in_out < 0 ) break;
	          }
	       }
	       else {
		  in_out = 1;
	       }

/* ==========================================================================
   If the kernel step is not in AOI write the filler value
   ========================================================================== */
	       if( in_out < 0 ) {
		  OutIma[ cs ] = fill_val;
	       }
	       else {	       
/* ==========================================================================
   else execute the convolution core
   ========================================================================== */
		  OutPoint = 0.0;
		  SqrOutPoint = 0.0;
		  for ( i=0; i<Kr; i++ ) {

		     /* point to the beginning of the matrices rows */
		     p = &((UINTx1 **)InpIma)[ RStart + i ][ CStart ] - 1;

		     /* internal convolution loop */
		     for ( j=0; j<Kc; j++ ) {
			OutPoint += (double) (*++p);
			SqrOutPoint += POW((double)(*p), (double)2.0 );
	             }
		  }

/* ==========================================================================
   Fill the output vector
   ========================================================================== */
                  sqrtarg = ( (k * SqrOutPoint) -
                              (k * k * POW ((double) OutPoint, (double)2.0) )
                            );
                  if( (k * SqrOutPoint) == ((double) 0.0) ) {
                     OutIma[ cs ] = fill_val;
                  }
                  else {
                     OutIma[ cs ] =
                        ( ( (sqrtarg/(k * SqrOutPoint)) < 
                            (- STATPD_sqrt_epsilon) )?
                                fill_val : 
                                ((float) (SQRT( sqrtarg ))) 
                        );
                  }
	       }
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      break;
      case LDEFIE_dt_UINTx2: {
         REGISTER UINTx2       *p = (UINTx2 *)NULL;

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
               CStart = (UINTx4) ROUND( cs* StepC );
               RStop = RStart + Kr - 1;
               CStop = CStart + Kc - 1;

/* ==========================================================================
   Chek if this kernel step belong to AOI, if any
   ========================================================================== */
	       if( vertex_no > 0 ) {
		  for( row=RStart; row<=RStop; row++) {
		     point.row = (double) row;
		     for( col=CStart; col<=CStop; col++) {
			point.col = (double) col;
			COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point,
						     &in_out, status_code );
			if( in_out < 0 ) break;
		     }
		     if( in_out < 0 ) break;
	          }
	       }
	       else {
		  in_out = 1;
	       }

/* ==========================================================================
   If the kernel step is not in AOI write the filler value
   ========================================================================== */
	       if( in_out < 0 ) {
		  OutIma[ cs ] = fill_val;
	       }
	       else {	       
/* ==========================================================================
   else execute the convolution core
   ========================================================================== */
		  OutPoint = 0.0;
		  SqrOutPoint = 0.0;
		  for ( i=0; i<Kr; i++ ) {

		     /* point to the beginning of the matrices rows */
		     p = &((UINTx2 **)InpIma)[ RStart + i ][ CStart ] - 1;

		     /* internal convolution loop */
		     for ( j=0; j<Kc; j++ ) {
			OutPoint += (double) (*++p);
			SqrOutPoint += POW((double)(*p), (double)2.0 );
		     }
		  }

/* ==========================================================================
   Fill the output vector
   ========================================================================== */
                  sqrtarg = ( (k * SqrOutPoint) -
                              (k * k * POW ((double) OutPoint, (double)2.0) )
                            );
                  if( (k * SqrOutPoint) == ((double) 0.0) ) {
                     OutIma[ cs ] = fill_val;
                  }
                  else {
                     OutIma[ cs ] =
                        ( ( (sqrtarg/(k * SqrOutPoint)) < 
                            (- STATPD_sqrt_epsilon) )?
                                fill_val : 
                                ((float) (SQRT( sqrtarg ))) 
                        );
                  }
               }
	    }
/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      break;
      case LDEFIE_dt_float: {
         REGISTER float       *p = (float *)NULL;

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
               CStart = (UINTx4) ROUND( cs * StepC );
               RStop = RStart + Kr - 1;
               CStop = CStart + Kc - 1;

/* ==========================================================================
   Chek if this kernel step belong to AOI, if any
   ========================================================================== */
	       if( vertex_no > 0 ) {
		  for( row=RStart; row<=RStop; row++) {
		     point.row = (double) row;
		     for( col=CStart; col<=CStop; col++) {
			point.col = (double) col;
			COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point,
						     &in_out, status_code );
			if( in_out < 0 ) break;
		     }
		     if( in_out < 0 ) break;
	          }
	       }
	       else {
		  in_out = 1;
	       }

/* ==========================================================================
   If the kernel step is not in AOI write the filler value
   ========================================================================== */
	       if( in_out < 0 ) {
		  OutIma[ cs ] = fill_val;
	       }
	       else {	       
/* ==========================================================================
   else execute the convolution core
   ========================================================================== */
		  OutPoint = 0.0;
		  SqrOutPoint = 0.0;
		  for ( i=0; i<Kr; i++ ) {

		     /* point to the beginning of the matrices rows */
		     p = &((float **)InpIma)[ RStart + i ][ CStart ] - 1;

		     /* internal convolution loop */
		     for ( j=0; j<Kc; j++ ) {
			OutPoint += (double) (*++p);
                        SqrOutPoint += POW((double)(*p), (double)2.0 );
		     }
		  }

/* ==========================================================================
   Fill the output vector
   ========================================================================== */
                  sqrtarg = ( (k * SqrOutPoint) -
                              (k * k * POW ((double) OutPoint, (double)2.0) )
                            );
                  if( (k * SqrOutPoint) == ((double) 0.0) ) {
                     OutIma[ cs ] = fill_val;
                  }
                  else {
                     OutIma[ cs ] =
                        ( ( (sqrtarg/(k * SqrOutPoint)) < 
                            (- STATPD_sqrt_epsilon) )?
                                fill_val : 
                                ((float) (SQRT( sqrtarg ))) 
                        );
                  }
               }
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      break;
      default:
         ERRSIM_set_error( status_code, ERRSID_STAT_data_type_not_allow, "" );
   }

error_exit:;

/* ==========================================================================
   Free the output vector memory
   ========================================================================== */
   MEMSIP_free( (void **)(&OutIma) );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STATPP_KERN_Sddv */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STATPP_KERN_Cfvr

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI


        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STAT_kernel_dim_high
		      ERRSID_STAT_bad_steps
		      ERRSID_STAT_bad_write_size
		      ERRSID_STAT_err_mem_alloc
		      ERRSID_STAT_data_type_not_allow

        $DESCRIPTION  This procedure convolves the constant kernel given in
		      input with the image block also given and writes the
		      output in the file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
					- Sum the square of the window element
                                        - Sum the 4th power of the window 
                                          element
                                        - Fill the output vector rescaling it
					  by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */
void STATPP_KERN_Cfvr
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
			 /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STATPP_KERN_Cfvr";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 rs;
   UINTx4                 cs;
   UINTx4                 RStart;
   UINTx4                 RStop;
   UINTx4                 CStart;
   UINTx4                 CStop;
   REGISTER UINTx4	  row, col;
   MATHIT_RC              point;
   INTx4                  in_out;
   float                 *OutIma = (float *)NULL;
   double		  k;
   REGISTER UINTx2        i;
   REGISTER UINTx2        j;
   REGISTER double        SqrOutPoint;
   REGISTER double        FourthOutPoint;
   double                 sqrtarg;
   char                   errmsg[ 132 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the kernel sizes consistency
   ========================================================================== */
   if ( ( Kr > nrow_inp ) || ( Kc > ncol_inp ) )
      ERRSIM_set_error( status_code, ERRSID_STAT_kernel_dim_high, "" );

/* ==========================================================================
   Check the steps values
   ========================================================================== */
   if ( ( StepR <= 0.0 ) || ( StepC <= 0.0 ) )
      ERRSIM_set_error( status_code, ERRSID_STAT_bad_steps, "" );

/* ==========================================================================
   Check the writing counters
   ========================================================================== */
   if ( RStartW > RStopW )
      ERRSIM_set_error( status_code, ERRSID_STAT_bad_write_size, "" );

/* ==========================================================================
   Copy the kernel value in a variable
   ========================================================================== */
   k = Kern[ 0 ][ 0 ];

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
   if ( ( OutIma = (float *)
           MEMSIP_alloc((size_t)(ncol_out * sizeof(float))) ) ==(float *)NULL) {
      ERRSIM_set_error( status_code, ERRSID_STAT_err_mem_alloc, "" );
   }

/* ==========================================================================
   Switch the various input types
   ========================================================================== */
   switch ( inp_data_type ) {
      case LDEFIE_dt_UINTx1: {
         REGISTER UINTx1       *p = (UINTx1 *)NULL;

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
               CStart = (UINTx4) ROUND( cs* StepC );
               RStop = RStart + Kr - 1;
               CStop = CStart + Kc - 1;

/* ==========================================================================
   Chek if this kernel step belong to AOI, if any
   ========================================================================== */
	       if( vertex_no > 0 ) {
		  for( row=RStart; row<=RStop; row++) {
		     point.row = (double) row;
		     for( col=CStart; col<=CStop; col++) {
			point.col = (double) col;
			COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point,
						     &in_out, status_code );
			if( in_out < 0 ) break;
		     }
		     if( in_out < 0 ) break;
	          }
	       }
	       else {
		  in_out = 1;
	       }

/* ==========================================================================
   If the kernel step is not in AOI write the filler value
   ========================================================================== */
	       if( in_out < 0 ) {
		  OutIma[ cs ] = fill_val;
	       }
	       else {	       
/* ==========================================================================
   else execute the convolution core
   ========================================================================== */
		  SqrOutPoint = 0.0;
		  FourthOutPoint = 0.0;
		  for ( i=0; i<Kr; i++ ) {

		     /* point to the beginning of the matrices rows */
		     p = &((UINTx1 **)InpIma)[ RStart + i ][ CStart ] - 1;

		     /* internal convolution loop */
		     for ( j=0; j<Kc; j++ ) {
		        p++;
			SqrOutPoint += POW((double)(*p), (double)2.0 );
			FourthOutPoint += POW((double)(*p), (double)4.0 );
		     }
		  }

/* ==========================================================================
   Fill the output vector
   ========================================================================== */
                  if( (k * FourthOutPoint) == ((double) 0.0) ) {
                     OutIma[ cs ] = fill_val;
                  }
                  else {
                     sqrtarg = ( (k * FourthOutPoint) -
                                 (k * k * POW ((double) SqrOutPoint, (double)2.0) )
                               );
                     OutIma[ cs ] =
                        ( ( (sqrtarg/(k * FourthOutPoint)) <
                            (- STATPD_sqrt_epsilon) ) ?
                                fill_val :
                                ((float) (SQRT( sqrtarg )/(k * SqrOutPoint)))
                        );
                  }
	       }
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      break;
      case LDEFIE_dt_UINTx2: {
         REGISTER UINTx2       *p = (UINTx2 *)NULL;

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
               CStart = (UINTx4) ROUND( cs* StepC );
               RStop = RStart + Kr - 1;
               CStop = CStart + Kc - 1;

/* ==========================================================================
   Chek if this kernel step belong to AOI, if any
   ========================================================================== */
	       if( vertex_no > 0 ) {
		  for( row=RStart; row<=RStop; row++) {
		     point.row = (double) row;
		     for( col=CStart; col<=CStop; col++) {
			point.col = (double) col;
			COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point,
						     &in_out, status_code );
			if( in_out < 0 ) break;
		     }
		     if( in_out < 0 ) break;
	          }
	       }
	       else {
		  in_out = 1;
	       }

/* ==========================================================================
   If the kernel step is not in AOI write the filler value
   ========================================================================== */
	       if( in_out < 0 ) {
		  OutIma[ cs ] = fill_val;
	       }
	       else {	       
/* ==========================================================================
   else execute the convolution core
   ========================================================================== */
		  SqrOutPoint = 0.0;
		  FourthOutPoint = 0.0;
		  for ( i=0; i<Kr; i++ ) {

		     /* point to the beginning of the matrices rows */
		     p = &((UINTx2 **)InpIma)[ RStart + i ][ CStart ] - 1;

		     /* internal convolution loop */
		     for ( j=0; j<Kc; j++ ) {
		        p++;
			SqrOutPoint += POW((double)(*p), (double)2.0 );
			FourthOutPoint += POW((double)(*p), (double)4.0 );
		     }
		  }

/* ==========================================================================
   Fill the output vector
   ========================================================================== */
                  if( (k * FourthOutPoint) == ((double) 0.0) ) {
                     OutIma[ cs ] = fill_val;
                  }
                  else {
                     sqrtarg = ( (k * FourthOutPoint) -
                                 (k * k * POW ((double) SqrOutPoint, (double)2.0) )
                               );
                     OutIma[ cs ] =
                        ( ( (sqrtarg/(k * FourthOutPoint)) <
                            (- STATPD_sqrt_epsilon) ) ?
                                fill_val :
                                ((float) (SQRT( sqrtarg )/(k * SqrOutPoint)))
                        );
                  }
               }
	    }
/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      break;
      case LDEFIE_dt_float: {
         REGISTER float       *p = (float *)NULL;

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
               CStart = (UINTx4) ROUND( cs * StepC );
               RStop = RStart + Kr - 1;
               CStop = CStart + Kc - 1;

/* ==========================================================================
   Chek if this kernel step belong to AOI, if any
   ========================================================================== */
	       if( vertex_no > 0 ) {
		  for( row=RStart; row<=RStop; row++) {
		     point.row = (double) row;
		     for( col=CStart; col<=CStop; col++) {
			point.col = (double) col;
			COORIP_AOIX_CheckPointInAoIS( vertex_no, vertex, &point,
						     &in_out, status_code );
			if( in_out < 0 ) break;
		     }
		     if( in_out < 0 ) break;
	          }
	       }
	       else {
		  in_out = 1;
	       }

/* ==========================================================================
   If the kernel step is not in AOI write the filler value
   ========================================================================== */
	       if( in_out < 0 ) {
		  OutIma[ cs ] = fill_val;
	       }
	       else {	       
/* ==========================================================================
   else execute the convolution core
   ========================================================================== */
		  SqrOutPoint = 0.0;
		  FourthOutPoint = 0.0;
		  for ( i=0; i<Kr; i++ ) {

		     /* point to the beginning of the matrices rows */
		     p = &((float **)InpIma)[ RStart + i ][ CStart ] - 1;

		     /* internal convolution loop */
		     for ( j=0; j<Kc; j++ ) {
		        p++;
			SqrOutPoint += POW((double)(*p), (double)2.0 );
			FourthOutPoint += POW((double)(*p), (double)4.0 );
		     }
		  }

/* ==========================================================================
   Fill the output vector
   ========================================================================== */
                  if( (k * FourthOutPoint) == ((double) 0.0) ) {
                     OutIma[ cs ] = fill_val;
                  }
                  else {
                     sqrtarg = ( (k * FourthOutPoint) -
                                 (k * k * POW ((double) SqrOutPoint, (double)2.0) )
                               );
                     OutIma[ cs ] =
                        ( ( (sqrtarg/(k * FourthOutPoint)) <
                            (- STATPD_sqrt_epsilon) ) ?
                                fill_val :
                                ((float) (SQRT( sqrtarg )/(k * SqrOutPoint)))
                        );
                  }
               }
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
      break;
      default:
         ERRSIM_set_error( status_code, ERRSID_STAT_data_type_not_allow, "" );
   }

error_exit:;

/* ==========================================================================
   Free the output vector memory
   ========================================================================== */
   MEMSIP_free( (void **)(&OutIma) );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STATPP_KERN_Cfvr */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STATPP_KERN_Copy

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI

        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STAT_kernel_dim_high
		      ERRSID_STAT_bad_steps
		      ERRSID_STAT_bad_write_size
		      ERRSID_STAT_err_mem_alloc
		      ERRSID_STAT_data_type_not_allow

        $DESCRIPTION  This procedure convolves the constant kernel given in
		      input with the image block also given and writes the
		      output in the file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
					- Check if whole window is inside AOI
                                        - Sum the window element
                                        - Fill the output vector rescaling it
					  by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */
void STATPP_KERN_Copy
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
			 /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STATPP_KERN_Copy";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 rs;
   UINTx4                 cs;
   UINTx4                 RStart;
   UINTx4                 CStart;
   REGISTER UINTx4	  row, col;
   MATHIT_RC              point;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the kernel sizes consistency
   ========================================================================== */
   if ( ( Kr > 1 ) || ( Kc > 1 ) )
      ERRSIM_set_error( status_code, ERRSID_STAT_kernel_dim_high, "" );

/* ==========================================================================
   Check the steps values
   ========================================================================== */
   if ( ( StepR != 1.0 ) || ( StepC != 1.0 ) )
      ERRSIM_set_error( status_code, ERRSID_STAT_bad_steps, "" );

/* ==========================================================================
   Check the writing counters
   ========================================================================== */
   if ( RStartW > RStopW )
      ERRSIM_set_error( status_code, ERRSID_STAT_bad_write_size, "" );

/* ==========================================================================
   Check vertex no
   ========================================================================== */
   if( vertex_no > 0 )
      ERRSIM_set_error( status_code, ERRSID_error, "internal error" );

/* ==========================================================================
   Switch the various input types
   ========================================================================== */
   switch ( inp_data_type ) {

      case LDEFIE_dt_UINTx1: {
         UINTx1      *OutIma = (UINTx1 *)NULL;

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
         if ( ( OutIma = (UINTx1 *)
                MEMSIP_alloc((size_t)(ncol_out * sizeof(UINTx1))) ) == 
              (UINTx1 *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_STAT_err_mem_alloc, 
               "OutIma" );
         }

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = rs - RStartR;
               CStart = cs;

               OutIma[ cs ] = ((UINTx1 **)InpIma)[ RStart ][ CStart ];

            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
         MEMSIP_free( (void **)(&OutIma) );
      }
      break;

      case LDEFIE_dt_UINTx2: {
         UINTx2      *OutIma = (UINTx2 *)NULL;

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
         if ( ( OutIma = (UINTx2 *)
                MEMSIP_alloc((size_t)(ncol_out * sizeof(UINTx2))) ) == 
              (UINTx2 *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_STAT_err_mem_alloc, 
               "OutIma" );
         }

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = rs - RStartR;
               CStart = cs;

               OutIma[ cs ] = ((UINTx2 **)InpIma)[ RStart ][ CStart ];
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
         MEMSIP_free( (void **)(&OutIma) );
      }
      break;


      case LDEFIE_dt_2_INTx2: {
         INTx2      *OutIma = (INTx2 *)NULL;

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
         if ( ( OutIma = (INTx2 *)
                MEMSIP_alloc((size_t)(2 * ncol_out * sizeof(INTx2))) ) == 
              (INTx2 *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_STAT_err_mem_alloc, 
               "OutIma" );
         }

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = rs - RStartR;
               CStart = cs;

               OutIma[ 2 * cs ] = 
                     ((INTx2 **)InpIma)[ RStart ][ 2 * CStart ];
               OutIma[ 2 * cs + 1 ] = 
                     ((INTx2 **)InpIma)[ RStart ][ 2 * CStart + 1];
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
         MEMSIP_free( (void **)(&OutIma) );
      }
      break;

      case LDEFIE_dt_2_UINTx1: {
         UINTx1      *OutIma = (UINTx1 *)NULL;

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
         if ( ( OutIma = (UINTx1 *)
                MEMSIP_alloc((size_t)(2 * ncol_out * sizeof(UINTx1))) ) == 
              (UINTx1 *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_STAT_err_mem_alloc, 
               "OutIma" );
         }

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = rs - RStartR;
               CStart = cs;

               OutIma[ 2 * cs ] = 
                     ((UINTx1 **)InpIma)[ RStart ][ 2 * CStart ];
               OutIma[ 2 * cs + 1 ] = 
                     ((UINTx1 **)InpIma)[ RStart ][ 2 * CStart + 1];
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
         MEMSIP_free( (void **)(&OutIma) );
      }
      break;


      case LDEFIE_dt_float: {
         float       *OutIma = (float *)NULL;

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
         if( ( OutIma = (float *)
                MEMSIP_alloc((size_t)(ncol_out * sizeof(float))) ) ==
             (float *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_STAT_err_mem_alloc, 
               "OutIma" );
         }

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = rs - RStartR;
               CStart = cs;

               OutIma[ cs ] = ((float **)InpIma)[ RStart ][ CStart ];
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
         MEMSIP_free( (void **)(&OutIma) );
      }
      break;

      case LDEFIE_dt_2_float: {
         float      *OutIma = (float *)NULL;

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
         if ( ( OutIma = (float *)
                MEMSIP_alloc((size_t)(2 * ncol_out * sizeof(float))) ) == 
              (float *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_STAT_err_mem_alloc, 
               "OutIma" );
         }

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
         for ( rs=RStartW; rs<=RStopW; rs++ ) {

	    SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
            for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	       RStart = rs - RStartR;
               CStart = cs;

               OutIma[ 2 * cs ] = 
                     ((float **)InpIma)[ RStart ][ 2 * CStart ];
               OutIma[ 2 * cs + 1 ] = 
                     ((float **)InpIma)[ RStart ][ 2 * CStart + 1];
            }

/* ==========================================================================
   Write the output line
   ========================================================================== */
            GIOSIP_write_line( out_io, rs, (void *)OutIma,
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
         MEMSIP_free( (void **)(&OutIma) );
      }
      break;


      default:
         ERRSIM_set_error( status_code, ERRSID_STAT_data_type_not_allow, "" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STATPP_KERN_Copy */
