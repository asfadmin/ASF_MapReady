/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_INTS

      $FUNCTION          Product Media Deformatting internal services

      $ROUTINE           PMDSPP_AdjustImageLine
                         PMDSPP_StoreVar
                         PMDSPP_StoreVarAndValue
                         PMDSPP_GetVar
                         PMDSPP_GetType
                         PMDSPP_EvalAssign
                         PMDSPP_InitLibrary
                         PMDSPP_DefRecField
                         PMDSPP_ReadCurrRec
                         PMDSPP_GetCfgLine
                         PMDSPP_ReadGlobalVar
                         PMDSPP_DefLogVolField
                         PMDSPP_SeekCfgFile
                         PMDSPP_SeekNextMarker
                         PMDSPP_ReadCurrRepeat
                         PMDSPP_FreeRec
                         PMDSPP_FreeGrpRec
                         PMDSPP_DeformatProdRecord
                         PMDSPP_GenerateTifImage
                         PMDSPP_DeformatGrpProdRecord
                         PMDSPP_DeformatFile

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       07-FEB-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <string.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include FILS_INTF_H
#include IANN_TAGS_H
#include TIFS_INTF_H
#include SRVS_INTF_H
#include OVLS_INTF_H
#include GIOS_INTF_H
#include MATH_INTF_H
#include COOR_INTF_H
#include PMDS_INTF_H
#include PMDS_PGLB_H

/* ==========================================================================
                      LOCAL ROUTINE DECLARATION SECTION
   ========================================================================== */
static int PMDSLP_trunctString(
   char            *buffer,             /* input buffer */
   char             items[][512],       /* items in the buffer (return) */
   int              items_nb,           /* max number of items to read */
   char            *resto)              /* other items in the buffer */
{
   int                  i;
   char                *tok_sep = " ";
   char                *thistoken;
   PMDSPT_tmp_buf       tmp_buf;

   if (buffer == NULL || items_nb == 0)
      return 0;

   strcpy(tmp_buf, buffer);
   resto[0] = '\0';

   thistoken = strtok(buffer, tok_sep);
   if (thistoken == '\0')
      return 0;

   strcpy(items[0], thistoken);


   for (i = 1; i < items_nb && thistoken != NULL;  )
   {
      thistoken = strtok(NULL, tok_sep);
      if (thistoken)
      {
         strcpy(items[i], thistoken);
      }
      i++;
   }

   if (thistoken)
   {
      thistoken = strtok(NULL, tok_sep);
      if (thistoken)
      {
         strcpy(buffer, tmp_buf);
         strcpy(resto, thistoken);
      }
   }

   return i;
}

static void PMDSLP_Adjust( void *val_ptr, INTx4 size )
{
#if defined(__VMS__) || defined(__WIN95__) || defined(__DOS__) || defined(__OSF__)
   int            i;
   unsigned char  comodo;
   unsigned char *buffer = (unsigned char *) val_ptr;

   for (i = 0; i < size/2; i++)
   {
      comodo                  =  buffer[ i ];
      buffer[ i ]             =  buffer[ size - i - 1 ];
      buffer[ size - i - 1 ]  =  comodo;
   }
#endif
}

static void PMDSLP_KFormatAdjust( void *val_ptr, INTx4 size )
{
   int            i;
   unsigned char  comodo;
   unsigned char *buffer = (unsigned char *) val_ptr;

   for (i = 0; i < size/2; i++)
   {
      comodo                  =  buffer[ i ];
      buffer[ i ]             =  buffer[ size - i - 1 ];
      buffer[ size - i - 1 ]  =  comodo;
   }
}

static void PMDSLP_SprintfStringParm
   (
   char   *out_string,
   char   *field_name,
   char   *field_value
   )
{
   INTx4  blank_skip = 0;

/* ==========================================================================
   Truncate the output value if it is too large
   ========================================================================== */
   if (strlen(field_value) > 1000) {
      field_value[ 1000 ] = '\0';
   }

/* ==========================================================================
   Truncate the output value if the field name is 'spare'
   ========================================================================== */
   if (strcmp(field_name, "spare") == 0) {
      field_value[ 0 ] = '\0';
   }

#ifdef __TRACE__
   printf("%-39.39s:%-39.39s", field_name, field_value + blank_skip );
#endif

#ifndef CEOG_DEBUG

   for (blank_skip = 0; blank_skip < strlen(field_value); blank_skip++) {
      if ( field_value[ blank_skip ] != ' ' )
         break;
   }

   sprintf(out_string, "%-39.39s:%-39.39s\n", field_name, 
                                              field_value + blank_skip );

#else

   sprintf(out_string, "%-39.39s: '%s'\n", field_name, field_value);

#endif
}


static void PMDSLP_SprintfIntegerParm
   (
   char   *out_string,
   char   *field_name,
   INTx4   field_value
   )
{
#ifdef __TRACE__
   printf("%-39.39s:%d", field_name, field_value);
#endif

#ifndef CEOG_DEBUG

   sprintf(out_string, "%-39.39s:%d\n", field_name, field_value);

#else

   sprintf(out_string, "%-39.39s: '%d'\n", field_name, field_value);

#endif
}

static void PMDSLP_ConvertToFloat
  ( 
   double *tmpDouble, 
   char   *out_record 
  )
{
   *tmpDouble = atof( out_record );
}

static void PMDSLP_SprintfFloatParm
   (
   char   *out_string,
   char   *field_name,
   double  tmpDouble,
   int     f,
   int     d
   )
{
   char     tmpFormat[ 20 ];

#ifdef __TRACE__
   sprintf( tmpFormat,"%%-39.39s:%%%0d.%0df", f, d );
   printf( tmpFormat, field_name, tmpDouble);
#endif

#ifndef CEOG_DEBUG

   sprintf( tmpFormat,"%%-39.39s:%%%0d.%0df\n", f, d );
   sprintf(out_string, tmpFormat, field_name, tmpDouble);

#else

   sprintf( tmpFormat,"%%-39.39s: '%%%0d.%0df'\n", f, d );
   sprintf(out_string, tmpFormat, field_name, tmpDouble);

#endif
}

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_AdjustImageLine

        $TYPE              PROCEDURE

        $INPUT        var           : string containing the variable assignment
                      type       : variable type

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Assign variable

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_AdjustImageLine
   (
   void                   *val_ptr,
   INTx4                   max_bytes,    /* image width in byte */
   PMDSPT_prod_data_type   prod_data_type
   )
{
   INTx4          i;
   INTx1          comodo;
   unsigned char *buffer = (unsigned char *) val_ptr; 

   switch (prod_data_type)
   {
      case PMDSPE_data_1_unsigned16:     /* SWAP ON VMS */
#if defined(__VMS__) || defined(__WIN95__) || defined(__DOS__) || defined(__OSF__)
         for (i = 0; i < max_bytes; i += 2) {
            comodo           =  buffer[ i ];
            buffer[ i ]      =  buffer[ i + 1 ];
            buffer[ i + 1 ]  =  comodo;
         }
#endif
         break;

      case PMDSPE_data_1_unsigned16_nodec:     /* SWAP ON NON VMS */
#if !defined(__VMS__) && !defined(__WIN95__) && !defined(__DOS__) && !defined(__OSF__)
         for (i = 0; i < max_bytes; i += 2) {
            comodo           =  buffer[ i ];
            buffer[ i ]      =  buffer[ i + 1 ];
            buffer[ i + 1 ]  =  comodo;
         }
#endif
         break;


      case PMDSPE_data_1_signed8:     /* NO_SWAP */
         break;

      case PMDSPE_data_none:
      default:
         break;
   }


}

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_StoreVar

        $TYPE              PROCEDURE

        $INPUT        var           : string containing the variable assignment
                      type       : variable type

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Assign variable

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_StoreVar      (/*IN    */ char                *var,
                           /*IN    */ PMDSPT_parm_type     type,
                           /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_StoreVar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;
   char                  *pos;
   LDEFIT_boolean         old_var = FALSE;
   PMDSPT_parm_name       name;
   PMDSPT_parm_value      val;
   char                  *end_p;
   char                   msg[ 512 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Look for = character
   ========================================================================== */
   pos = strchr(var, '=');

   if (var[0] != '@' || pos == NULL) {
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_store_var,
                        var );
   }

/* ==========================================================================
   Deformat variable
   ========================================================================== */
   strncpy(name, var+1, strlen(var) - strlen(pos) - 1);
   name[strlen(var) - strlen(pos) - 1] = '\0';
   strcpy(val, pos+1);

/* ==========================================================================
   Check if replace
   ========================================================================== */
   for (i = 0; i < PMDSPV_gm.global_vars_stored; i++)
   {
      if(strcmp(name, PMDSPV_gm.global_vars[i].name) == 0)     /* Found */
      {
         old_var = TRUE;
         break;
      }
   }

/* ==========================================================================
   Check if the old variables is different by new
   ========================================================================== */
   if (old_var == TRUE && PMDSPV_gm.global_vars[i].type != type)
   {
      sprintf(msg,
         "%s. Old type is different by new.", var);
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_store_var,
                        msg );
   }

/* ==========================================================================
   Set the new data of the variable
   ========================================================================== */
   if (old_var == FALSE)
   {
      i = PMDSPV_gm.global_vars_stored;
   }


   switch(type)
   {
      case PMDSPE_real_parm:
         PMDSPV_gm.global_vars[i].val.number = strtod(val, &end_p);
         if ( *end_p == '\0' || *end_p == ' ' || 
              *end_p == '\t' || *end_p == '\n' ) {
            strcpy(PMDSPV_gm.global_vars[i].name, name);
            PMDSPV_gm.global_vars[i].type   = PMDSPE_real_parm;
         }
         else {
            sprintf(msg,
               "%s. Bad real variable value", var);
            ERRSIM_set_error( status_code,
                              ERRSID_PMDS_store_var,
                              msg );
         }
         break;

      case PMDSPE_int_parm:
         PMDSPV_gm.global_vars[i].val.number = (double) strtol(val, &end_p, 10);
         if ( *end_p == '\0' || *end_p == ' ' || 
              *end_p == '\t' || *end_p == '\n' )
         {
            strcpy(PMDSPV_gm.global_vars[i].name, name);
            PMDSPV_gm.global_vars[i].type   = PMDSPE_int_parm;
         }
         else
         {
            sprintf(msg,
               "%s. Bad integer variable value", var);
            ERRSIM_set_error( status_code,
                              ERRSID_PMDS_store_var,
                              msg );
         }
         break;

      case PMDSPE_string_parm:
      case PMDSPE_date_parm:
         strcpy(PMDSPV_gm.global_vars[i].name, name);
         PMDSPV_gm.global_vars[i].type   = PMDSPE_string_parm;
         strcpy(PMDSPV_gm.global_vars[i].val.string, val);
         break;
   }

   if (old_var == FALSE)
   {
      PMDSPV_gm.global_vars_stored++;
   }



error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_StoreVar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_StoreVarAndValue

        $TYPE              PROCEDURE

        $INPUT        var           : string containing the variable
                      value      : string containing the value
                      type       : variable type

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Assign variable

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_StoreVarAndValue(/*IN    */ char                *var,
                             /*IN    */ char                *value,
                             /*IN    */ PMDSPT_parm_type     type,
                             /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_StoreVarAndValue";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                   tmp_buf[ 80 ];
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Build assignment string
   ========================================================================== */
   sprintf(tmp_buf, "@%s=%s", var, value);

/* ==========================================================================
   Call PMDSPP_StoreVar
   ========================================================================== */
   PMDSPP_StoreVar(tmp_buf, type, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_StoreVarAndValue */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_GetVar

        $TYPE              PROCEDURE

        $INPUT        var           : variable name

        $MODIFIED     NONE

        $OUTPUT       out_value  : value variable

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Find variable value

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_GetVar      (/*IN    */ PMDSPT_parm_name     var,
                         /*   OUT*/ char                *out_value,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_GetVar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Looks for variable
   ========================================================================== */
   for (i = 0; i < PMDSPV_gm.global_vars_stored; i++)
   {
      if (strcmp(var, PMDSPV_gm.global_vars[i].name) == 0)     /* Found */
      {
         switch(PMDSPV_gm.global_vars[i].type)
         {
            case PMDSPE_real_parm:
               sprintf(out_value, "%lf", 
                               (double)PMDSPV_gm.global_vars[i].val.number);
               break;

            case PMDSPE_int_parm:
               sprintf(out_value, "%d",
                               (INTx4)PMDSPV_gm.global_vars[i].val.number);
               break;

            case PMDSPE_string_parm:
            case PMDSPE_date_parm:
               strcpy(out_value, PMDSPV_gm.global_vars[i].val.string);
               break;
            default:
               strcpy(out_value, PMDSPV_gm.global_vars[i].val.string);
               break;
         }
      break;
      }
   }

/* ==========================================================================
   Return error if not found
   ========================================================================== */
   if( i >= PMDSPV_gm.global_vars_stored )
   {
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_pars_var,
                        var );
   }



error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_GetVar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_GetType

        $TYPE              PROCEDURE

        $INPUT        var           : variable name

        $MODIFIED     NONE

        $OUTPUT       out_type      : variable type

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Find variable value

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_GetType     (/*IN    */ PMDSPT_parm_name     var,
                         /*   OUT*/ PMDSPT_parm_type    *out_type,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_GetType";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Looks for variable
   ========================================================================== */
   for (i = 0; i < PMDSPV_gm.global_vars_stored; i++)
   {
      if (strcmp(var, PMDSPV_gm.global_vars[i].name) == 0)     /* Found */
      {
         *out_type = PMDSPV_gm.global_vars[i].type;
         break;
      }
   }

/* ==========================================================================
   Return error if not found
   ========================================================================== */
   if( i >= PMDSPV_gm.global_vars_stored )
   {
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_pars_var,
                        var );
   }



error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_GetType */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_EvalAssign

        $TYPE              PROCEDURE

        $INPUT        expr          : variable name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Execute simple assignment 
                      @VAR = [@VAR|CONST] +/- [@VAR|CONST] +/- ...

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_EvalAssign  (/*IN    */ char                *expr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_EvalAssign";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   PMDSPT_parm_name       var_to;
   PMDSPT_parm_type       var_to_type;
   PMDSPT_parm_name       var;
   PMDSPT_parm_type       var_type;
   PMDSPT_parm_value      out_val;
   char                  *ptr;
   char                   dupexpr[ 256 ], tmp_buf[ 256 ];
   INTx4                  index, i, j, val, total;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Duplicate expression
   ========================================================================== */
   sprintf( dupexpr, "%s", expr );

/* ==========================================================================
   Search '='
   ========================================================================== */
   ptr = strtok( expr, "=" );
   if( ptr == (char *) NULL ) {
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_pars_var,
                        dupexpr );
   }
   for( i=0; i<strlen(ptr); i++ ) {
      if( ptr[ i ] != ' ' ) {
         break;
      }
   }
   var_to[ 0 ] = '\0';
   for( i=0, j=0; i<strlen(ptr); i++ ) {
      if( (ptr[ i ] != ' ') &&
          (ptr[ i ] != '\n') ) {
         var_to[ j ] = ptr[ i ];
         j++;
      }
   }
   var_to[ j ] = '\0';
   if( var_to[ 0 ] != '@' ) {
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_pars_var,
                        var_to );
   }
   PMDSPP_GetType(  var_to + 1,
                   &var_to_type,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   if( var_to_type != PMDSPE_int_parm ) {
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_pars_var,
                        "Assignment implemented for integer type only" );
   }

   total = 0;   
/* ==========================================================================
   Examine the expression
   ========================================================================== */
   do {
      if( ptr = strtok( '\0', "+-" ) ) {
         index = ptr - &(expr[ 0 ]) - 1;
         var[ 0 ] = '\0';
         for( i=0, j=0; i<strlen(ptr); i++ ) {
            if( (ptr[ i ] != ' ') &&
                (ptr[ i ] != '\n') ) {
               var[ j ] = ptr[ i ];
               j++;
            }
         }
         var[ j ] = '\0';
         if( strcmp( var, "" ) ) {
            if( var[ 0 ] == '@' ) {
               PMDSPP_GetType(  var + 1,
                               &var_type,
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               if( var_type != var_to_type ) {
                  ERRSIM_set_error( status_code,
                                    ERRSID_PMDS_pars_var,
                                    "Different type in assignments" );
               }
               PMDSPP_GetVar( var + 1,
                              out_val,
                              status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               val = atoi( out_val );
            }
            else {
               val = atoi( var );
            }
         }
         switch( dupexpr[ index ] )
         {
            case '+':
               total += val;
               break;
            case '-':
               total -= val;
               break;
            case '=':
               if( strcmp( var, "" ) ) {
                  total += val;
               }
               break;
            
         }
      }
   } while( ptr );

#ifdef __TRACE__
   fprintf( stdout, "\n%s=%0d\n\n", var_to, total);
#endif

   sprintf( tmp_buf, "%s=%0d", var_to, total);
   PMDSPP_StoreVar( tmp_buf,
                    var_to_type,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_EvalAssign */ 

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_InitLibrary

        $TYPE              PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Init library

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_InitLibrary
                          (/*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_InitLibrary";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Initialize global variable
   ========================================================================== */
   PMDSPV_gm.cfg_pos            = 0;
   PMDSPV_gm.cur_file_num       = 0;
   PMDSPV_gm.cur_mvol_rec_num   = 0;
   PMDSPV_gm.cur_rec_num        = 0;
   PMDSPV_gm.cur_vol_num        = 0;
   PMDSPV_gm.phsy_vol_num       = 0;
   PMDSPV_gm.global_vars_stored = 0;
   memset(PMDSPV_gm.global_vars, '\0', 
             sizeof(PMDSPT_global_vars)*PMDSPD_max_global_vars);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_InitLibrary */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_DefRecField

        $TYPE         PROCEDURE

        $INPUT        buffer         : buffer line

        $MODIFIED     NONE

        $OUTPUT       field_ptr  : CFG field pointer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This service fill the 'field_ptr' structure which the 
                      values contained into 'buffer' vector.

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_DefRecField (/*IN    */ char                 *buffer,
                         /*   OUT*/ PMDSPT_cfg_field     *field_ptr,
                         /*   OUT*/ INTx4                *nb_rec_field,
                         /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_DefRecField";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  ichar;
   INTx4                  last_four_fields_len;
   INTx4                  current_field = 0;
   INTx4                  count;
   char                   temp_string[PMDSPD_max_number_cfg_field][512];
   char                  *tmp_str_p;
   char                  *tmp_p;
   char                   msg[ 512 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Quickly set expression strings
   ========================================================================== */
   if( buffer[ 0 ] == '@' ) {
      strcpy( field_ptr->default_value, buffer );
      field_ptr->num = -1;
      *nb_rec_field = 0;
      return;
   }

/* ==========================================================================
   Read number of fields and chek if it is not equal to
   PMDSPD_max_number_cfg_field
   ========================================================================== */
   count = PMDSLP_trunctString( buffer, 
                                temp_string, 
                                PMDSPD_max_number_cfg_field-1, 
                                temp_string[PMDSPD_max_number_cfg_field-1]);

   if(strlen(temp_string[PMDSPD_max_number_cfg_field-1]))
      count++;


/* ==========================================================================
   Check error
   ========================================================================== */
   if(count != PMDSPD_max_number_cfg_field)
   {
      sprintf(msg,
              "The number of field are not equal to %d at line %d", 
              PMDSPD_max_number_cfg_field, PMDSPV_gm.cfg_pos);
      ERRSIM_set_error(status_code, ERRSID_PMDS_bad_in_cfg, msg);
   }

/* ==========================================================================
   Fills number of the current field and the start byte
   ========================================================================== */
   current_field = 0;
   field_ptr->num = atoi(temp_string[current_field]);

   current_field++;
   field_ptr->byte_start = atoi(temp_string[current_field]);

   current_field++;
   if (temp_string[current_field][0] == 'Y')
      field_ptr->write_tif = TRUE;
   else
      field_ptr->write_tif = FALSE;

/* ==========================================================================
   Copy the align mode
   ========================================================================== */
   current_field++;
   if(strncmp(temp_string[current_field], "L", 1) == 0)
   {
      field_ptr->align = PMDSPE_align_left;
   }
   else if(strncmp(temp_string[current_field], "C", 1) == 0)
   {
      field_ptr->align = PMDSPE_align_centered;
   }
   else if(strncmp(temp_string[current_field], "R", 1) == 0)
   {
      field_ptr->align = PMDSPE_align_right;
   }
   else
   {
      sprintf(msg, "Wrong alignment at line %d", PMDSPV_gm.cfg_pos);
      ERRSIM_set_error( status_code, ERRSID_PMDS_bad_in_cfg, msg);
   }

/* ==========================================================================
   Copy the number of field to repeat, the format, and the size
   ========================================================================== */
   current_field++;
   field_ptr->format = temp_string[current_field][0];
   field_ptr->format_size = atoi(temp_string[current_field] + 1);

   field_ptr->after_comma_size = 0;
   tmp_str_p = strchr(temp_string[current_field], '.');
   if (tmp_str_p != NULL)
      field_ptr->after_comma_size = atoi(tmp_str_p+1);

/* ==========================================================================
   Copy the parameter name
   ========================================================================== */
   current_field++;
   strcpy(field_ptr->name, temp_string[current_field]);

/* ==========================================================================
   Copy the parameter value type
   ========================================================================== */
   current_field++;
   switch(temp_string[current_field][0])
   {
      case 'D':
      case 'd':
         field_ptr->fill_type = PMDSPE_fill_default;
         break;
      case 'C':
      case 'c':
         field_ptr->fill_type = PMDSPE_fill_computable;
         break;
      case 'G':
      case 'g':
         field_ptr->fill_type = PMDSPE_fill_geo;
         break;
      case 'S':
      case 's':
         field_ptr->fill_type = PMDSPE_fill_sar;
         break;
      case 'B':
      case 'b':
         field_ptr->fill_type = PMDSPE_fill_blank;
         break;
      case 'N':
      case 'n':
         field_ptr->fill_type = PMDSPE_fill_null;
         break;
      default:
         sprintf(msg, "Wrong fill type at line %d", PMDSPV_gm.cfg_pos);
         ERRSIM_set_error(status_code, ERRSID_PMDS_bad_in_cfg, msg);
   }

/* ==========================================================================
   Copy the default parameter value
   ========================================================================== */
   current_field++;
   strcpy(field_ptr->in_var, temp_string[current_field]);

   if(strlen(temp_string[current_field]) > 30)
   {
      sprintf( msg, "Field <%s> too long at line %d", 
               temp_string[current_field], PMDSPV_gm.cfg_pos);
      ERRSIM_set_error(status_code, ERRSID_PMDS_bad_in_cfg, msg);
   }
   current_field++;
   strcpy(field_ptr->check_field, temp_string[current_field]);

   current_field++;

/* ==========================================================================
   Set the length of the last four fields found in the record
   ========================================================================== */
   last_four_fields_len = 131 + 1 + 81 + 1 + 21 + 1 + 101;

/* ==========================================================================
   Split the last data read into four different fields
   ========================================================================== */
   if (strlen(temp_string[current_field]) > last_four_fields_len)
   {
      sprintf( msg, "Field <%s> too long at line %d", 
               temp_string[current_field], PMDSPV_gm.cfg_pos);
      ERRSIM_set_error(status_code, ERRSID_PMDS_bad_in_cfg, msg);
   }

/* ==========================================================================
   Check the cfg file format to allow the compatibility with old version(s)
   ========================================================================== */
   if (strlen(temp_string[current_field]) < 131)
   {
      strcpy(field_ptr->default_value, temp_string[current_field]);
   }
   else
   {
      if (strlen(temp_string[current_field]) < (last_four_fields_len - 100))
      {
         sprintf( msg, "Field <%s> too short at line %d", 
                  temp_string[current_field], PMDSPV_gm.cfg_pos);
         ERRSIM_set_error( status_code,
                           ERRSID_PMDS_bad_in_cfg,
                           msg );
      }

      tmp_p = temp_string[current_field];

      strncpy(field_ptr->default_value, tmp_p, 131);
      field_ptr->default_value[130] = '\0';
      for(ichar = strlen(field_ptr->default_value) - 1; ichar >= 0; ichar--)
      {
         if(field_ptr->default_value[ichar] == ' ')
            field_ptr->default_value[ichar] = '\0';
         else
            break;
      }

      strncpy(field_ptr->esa_name, tmp_p + 132, 81);
      field_ptr->esa_name[80] = '\0';
      for(ichar = strlen(field_ptr->esa_name) - 1; ichar >= 0; ichar--)
      {
         if(field_ptr->esa_name[ichar] == ' ')
            field_ptr->esa_name[ichar] = '\0';
         else
            break;
      }

      strncpy(field_ptr->units, tmp_p + 214, 21);
      field_ptr->units[20] = '\0';
      for(ichar = strlen(field_ptr->units) - 1; ichar >= 0; ichar--)
      {
         if(field_ptr->units[ichar] == ' ')
            field_ptr->units[ichar] = '\0';
         else
            break;
      }

      strcpy(field_ptr->remark, tmp_p + 236);
      for(ichar = strlen(field_ptr->remark) - 1; ichar >= 0; ichar--)
      {
         if((field_ptr->remark[ichar] == ' ')    ||
            (field_ptr->remark[ichar] == '\n'))
            field_ptr->remark[ichar] = '\0';
         else
            break;
      }
   }

/* ==========================================================================
   A record field has been found
   ========================================================================== */
   *nb_rec_field = 1;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_DefRecField */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_ReadCurrRec

        $TYPE         PROCEDURE

        $INPUT        cfg_fp   : pointer to CFG file

        $MODIFIED     NONE

        $OUTPUT       rec_ptr : pointer to CFG record

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read the next record contained into CFG file and load all
                      into memory.

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_ReadCurrRec (/*IN    */ FILE                 *cfg_fp,
                         /*   OUT*/ PMDSPT_cfg_rec       *rec_ptr,
                         /*   OUT*/ INTx4                *nb_rec_field,
                         /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_ReadCurrRec";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  nb_field = 0;
   INTx4                  tmp_nb_rec_field = 0;
   PMDSPT_tmp_buf         buffer;
   PMDSPT_cfg_field      *field_ptr    = (PMDSPT_cfg_field *) NULL;
   PMDSPT_cfg_field     **tmp_rec_ptr  = (PMDSPT_cfg_field **) NULL;
   LDEFIT_boolean         cfg_read      = FALSE;
   LDEFIT_boolean         is_in_repeat, begin_repeat, end_repeat;
   PMDSPT_parm_name       num_repeat_str;
   char                  *str_pos;
   char                   msg[ 256 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Read from PMDS file structure
   ========================================================================== */
   is_in_repeat = FALSE;
   begin_repeat = end_repeat = FALSE;
   num_repeat_str[0] = '\0';

   do {
      PMDSPP_GetCfgLine(cfg_fp, sizeof(PMDSPT_tmp_buf), buffer, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check if the end of record
   ========================================================================== */
      if(strncmp(buffer, PMDSPM_mrk_record_end,
                 strlen(PMDSPM_mrk_record_end)) == 0)
      {
         cfg_read = TRUE;
         break;
      }
/* ==========================================================================
   Check if the PMDSPM_mrk_repeat_begin
   ========================================================================== */
      else if( (strncmp(buffer, PMDSPM_mrk_repeat_begin,
                        strlen(PMDSPM_mrk_repeat_begin)) == 0) ||
               (strncmp(buffer, PMDSPM_mrk_img_begin,
                        strlen(PMDSPM_mrk_img_begin)) == 0) )
      {
         char *sub_str = strchr(buffer, ':');
         if(sub_str == NULL)
         {
            sprintf( msg, "Syntax error at label <%s> at line %d",
                      buffer, PMDSPV_gm.cfg_pos);
            ERRSIM_set_error( status_code,
                              ERRSID_PMDS_bad_in_cfg,
                              msg );
         }
         else
         {
            is_in_repeat = TRUE;
            begin_repeat = TRUE;

            str_pos = strchr(buffer, '@');
            if (str_pos == NULL) {
               strcpy(num_repeat_str, sub_str+1);
            }
            else
            {
               strcpy(num_repeat_str, str_pos);
            }
         }
         continue;
      }
/* ==========================================================================
   Check if the PMDSPM_mrk_repeat_end
   ========================================================================== */
      else if( (strncmp(buffer, PMDSPM_mrk_repeat_end,
                        strlen(PMDSPM_mrk_repeat_end)) == 0) ||
               (strncmp(buffer, PMDSPM_mrk_img_end,
                        strlen(PMDSPM_mrk_img_end)) == 0) )
      {
         if(is_in_repeat == FALSE)
         {
            sprintf( msg, "Syntax error at label <%s> at line %d",
                      buffer, PMDSPV_gm.cfg_pos);
            ERRSIM_set_error( status_code,
                              ERRSID_PMDS_bad_in_cfg,
                              msg );
         }
         is_in_repeat  = FALSE;
         field_ptr->end_repeat = TRUE;
         continue;
      }
/* ==========================================================================
   Check if error
   ========================================================================== */
      else if (buffer[0] == '.')
      {
         sprintf( msg, "Syntax error at label <%s> at line %d",
                   buffer, PMDSPV_gm.cfg_pos);
         ERRSIM_set_error( status_code,
                           ERRSID_PMDS_bad_in_cfg,
                           msg );
      }

/* ==========================================================================
   Increment the number of field read
   ========================================================================== */
      nb_field = nb_field + 1;

/* ==========================================================================
   Alloc memory for new record field
   ========================================================================== */
      field_ptr = (PMDSPT_cfg_field *) MEMSIP_alloc(sizeof(PMDSPT_cfg_field));
      if( field_ptr == (PMDSPT_cfg_field *) NULL)
      {
         sprintf( msg, "Label <%s> at line %d",
                   buffer, PMDSPV_gm.cfg_pos);
         ERRSIM_set_error( status_code,
                           ERRSID_PMDS_alloc_cfg_field,
                           msg );
      }

/* ==========================================================================
   Realloc the vector of pointer and attach the new field to it
   ========================================================================== */
      tmp_rec_ptr = MEMSIP_realloc( tmp_rec_ptr,
                                    nb_field*sizeof(PMDSPT_cfg_field *));
      if( field_ptr == (PMDSPT_cfg_field *) NULL)
      {
         sprintf( msg, "Label <%s> at line %d",
                   buffer, PMDSPV_gm.cfg_pos);
         ERRSIM_set_error( status_code,
                           ERRSID_PMDS_alloc_cfg_field,
                           msg );
      }
      tmp_rec_ptr[nb_field - 1] = field_ptr;

/* ==========================================================================
   Deformat field
   ========================================================================== */
      PMDSPP_DefRecField(buffer, field_ptr, &tmp_nb_rec_field, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      *nb_rec_field += tmp_nb_rec_field;

      field_ptr->begin_repeat = begin_repeat;
      field_ptr->end_repeat   = end_repeat;
      strcpy(field_ptr->max_rep_str, num_repeat_str);

      begin_repeat = end_repeat = FALSE;
      num_repeat_str[0] = '\0';

   } while ( TRUE );

/* ==========================================================================
   Copy the number of fields and the pointer to CFG field
   ========================================================================== */
   rec_ptr->max_field = nb_field;
   rec_ptr->cfg_field  = tmp_rec_ptr;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_ReadCurrRec */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_IsComment

        $TYPE              FUNCTION

        $INPUT        buffer         : CFG file line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   TRUE if the line is a comment one

        $DESCRIPTION  check if a CFG file line is a comment

        $WARNING      NONE

   $EH
   ========================================================================== */
LDEFIT_boolean PMDSPF_IsComment
                          (/*IN    */ char                *buffer )
{
   if (buffer[0] == 'C' || buffer[0] == 'c' || strlen(buffer) == 0)
   {
      return(TRUE);
   }

   return (FALSE);
}


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_GetCfgLine

        $TYPE              PROCEDURE

        $INPUT        fpCfg         : pointer to CFG file
                      max        : max character for the line

        $MODIFIED     NONE

        $OUTPUT       str        : CFG line

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Read a line from CFG file

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_GetCfgLine     (/*IN    */ FILE               *fpCfg,
                           /*IN    */ INTx4                max,
                           /*IN    */ char                *str,
                           /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_GetCfgLine";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Read CFG file line until a non blank or a non comment one is found
   ========================================================================== */
   for (;;)
   {
      PMDSPV_gm.cfg_pos++;


      fgets(str, max, fpCfg);
#ifdef __TRACE__
      fprintf( stdout, "<%s>\n", str );
#endif
      if(str == (char *) NULL)
      {
         if(feof(fpCfg))
         {
            ERRSIM_set_error(status_code, ERRSID_PMDS_eof_in_cfg, "");
         }
         else
         {
            ERRSIM_set_error(status_code, ERRSID_PMDS_rea_in_cfg, "");
         }
      }

      if (PMDSPF_IsComment(str) == TRUE)
         continue;
      else if ( !strcmp( str, "\n" ) )
         continue;
      else if (strlen(str))
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_GetCfgLine */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_ReadGlobalVar

        $TYPE              PROCEDURE

        $INPUT        fpCfg         : pointer to CFG file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       ?

        $RET_STATUS   NONE

        $DESCRIPTION  Read the global var section from the CFG file

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_ReadGlobalVar (/*IN    */ FILE                *fpCfg,
                           /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_ReadGlobalVar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   PMDSPT_tmp_buf         buffer;
   char                  *ptr1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get a line until PMDSPM_mrk_var_begin
   ========================================================================== */
   do
   {
      PMDSPP_GetCfgLine(fpCfg, sizeof(PMDSPT_tmp_buf), buffer, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

   } while(strncmp(buffer, PMDSPM_mrk_var_begin, strlen(PMDSPM_mrk_var_begin))
        != 0);

/* ==========================================================================
   Get a line until PMDSPM_mrk_var_end
   ========================================================================== */
   do
   {
      PMDSPP_GetCfgLine(fpCfg, sizeof(PMDSPT_tmp_buf), buffer, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   If the line is not PMDSPM_mrk_var_end process it
   ========================================================================== */
      if(strncmp(buffer, PMDSPM_mrk_var_end, strlen(PMDSPM_mrk_var_end)) != 0)
      {

/* ==========================================================================
   Check if is PMDSPE_string_parm
   ========================================================================== */
         ptr1 = strchr(buffer, '"');
         if (ptr1)
         {
            memcpy(ptr1, ptr1+1, strlen(ptr1+1));
            ptr1 = strchr(buffer, '"');
            if (ptr1)
            {
               *(ptr1) = '\0';
            }
            PMDSPP_StoreVar(buffer, PMDSPE_string_parm, status_code);
            ERRSIM_on_err_goto_exit( *status_code );
         }
         else
         {
            PMDSPP_StoreVar(buffer, PMDSPE_int_parm, status_code);
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
   } while (strncmp(buffer, PMDSPM_mrk_var_end, strlen(PMDSPM_mrk_var_end))
        != 0);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_ReadGlobalVar */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_ReadLogVolStru

        $TYPE              FUNCTION

        $INPUT        fpCfg         : pointer to CFG file

        $MODIFIED     NONE

        $OUTPUT       PMDSLogVol : logical volume structure data

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read the log vol section from the CFG file

        $WARNING      NONE

   $EH
   ========================================================================== */
INTx4 PMDSPF_ReadLogVolStru
                          (/*IN    */ FILE                *fpCfg,
                           /*   OUT*/ PMDSPT_log_vol      *prodLogVol,
                           /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPF_ReadLogVolStru";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  index = 0;
   PMDSPT_tmp_buf         buffer;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get a line until PMDSPM_mrk_log_vol_begin
   ========================================================================== */
   do
   {
      PMDSPP_GetCfgLine(fpCfg, sizeof(PMDSPT_tmp_buf), buffer, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

   } while (strncmp(buffer, PMDSPM_mrk_log_vol_begin, 
                    strlen(PMDSPM_mrk_log_vol_begin)) != 0);

/* ==========================================================================
   Get a line until PMDSPM_mrk_log_vol_end
   ========================================================================== */
   do
   {
      PMDSPP_GetCfgLine(fpCfg, sizeof(PMDSPT_tmp_buf), buffer, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   If the line is not PMDSPM_mrk_log_vol_end process it
   ========================================================================== */
      if(strncmp(buffer, PMDSPM_mrk_log_vol_end,
         strlen(PMDSPM_mrk_log_vol_end)) != 0)
      {
         if((index + 1) == PMDSPD_max_log_vol_item)
         {
            ERRSIM_set_error(status_code,
                             ERRSID_PMDS_log_vol,
                             "Internal buffer too small");
         }

         PMDSPP_DefLogVolField(buffer, &(prodLogVol[index]), status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         if(prodLogVol[index].presence_type != PMDSPE_none_pres)
         {
            index++;
         }
      }
   } while (strncmp(buffer, PMDSPM_mrk_log_vol_end,
        strlen(PMDSPM_mrk_log_vol_end)) != 0);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return( index );

}/* PMDSPF_ReadLogVolStru */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_VolumeType

        $TYPE              FUNCTION

        $INPUT        file_code        :   file code 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Return the volume type on the file_code

        $WARNING      NONE

   $EH
   ========================================================================== */
PMDSPT_volume_type PMDSPF_VolumeType  
                        (/*IN    */ PMDSPT_file_code     file_code )
{
   PMDSPT_volume_type     tmp_volume_type;

/* ==========================================================================
   Set the volume type according to the file_code 
   ========================================================================== */
   if(!strncmp(file_code, PMDSPM_vdf_volume, strlen(PMDSPM_vdf_volume)))
   {
      tmp_volume_type = PMDSPE_vdf_volume;
   } 
   else if(!strncmp(file_code, PMDSPM_ldr_volume, 
                    strlen( PMDSPM_ldr_volume)))
   {
      tmp_volume_type = PMDSPE_ldr_volume;
   }
   else if(!strncmp(file_code, PMDSPM_img_volume,
                     strlen( PMDSPM_img_volume)))
   {
      tmp_volume_type = PMDSPE_img_volume;
   }
   else if(!strncmp(file_code, PMDSPM_nul_volume,
                     strlen( PMDSPM_nul_volume)))
   {
      tmp_volume_type = PMDSPE_nul_volume;
   }

   return(tmp_volume_type);

}/* PMDSPF_VolumeType */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_DefLogVolField

        $TYPE              PROCEDURE

        $INPUT        buffer            : CFG file line

        $MODIFIED     NONE

        $OUTPUT       prodLogVol : Product logical volume structure

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Define the prodLogVol for the given line

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_DefLogVolField
                          (/*IN    */ char                *buffer,
                           /*   OUT*/ PMDSPT_log_vol      *prodLogVol,
                           /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_DefLogVolField";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  count;
   char                   temp_string[8][255];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Read field number
   ========================================================================== */
   count = sscanf(buffer, "%s %s %s %s %s %s",
      temp_string[0], temp_string[1], temp_string[2],
      temp_string[3], temp_string[4], temp_string[5]);

/* ==========================================================================
   Check errors
   ========================================================================== */
   if (count != 6) {
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_log_vol,
                        "Wrong field number" );
   }

/* ==========================================================================
   Fills structure fields
   ========================================================================== */
   prodLogVol->num = atoi(temp_string[0]);             /* Field number */
   strcpy(prodLogVol->file, temp_string[1]);           /* File name */
   strcpy(prodLogVol->file_code, temp_string[2]);

   if (!strncmp(temp_string[3], "A", 1))
   {
      prodLogVol->presence_type = PMDSPE_all_pres;
   }
   else if(!strncmp(temp_string[3], "F", 1))
   {
      prodLogVol->presence_type = PMDSPE_first_pres;
   }
   else if(!strncmp(temp_string[3], "L", 1))
   {
      prodLogVol->presence_type = PMDSPE_last_pres;
   }
   else if(!strncmp(temp_string[3], "N", 1))
   {
      prodLogVol->presence_type = PMDSPE_none_pres;
   }
   else {
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_log_vol,
                        "Wrong presence_type field" );
   }


   if (!strncmp(temp_string[4], "Y", 1))
   {
      prodLogVol->is_interruptable = TRUE;
   }
   else if(!strncmp(temp_string[4], "N", 1))
   {
      prodLogVol->is_interruptable = FALSE;
   }
   else {
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_log_vol,
                        "Wrong is_interruptable field" );
   }

   if (!strncmp(temp_string[5], "FIXD", 4))
   {
      prodLogVol->rec_format = PMDSPE_rfm_fixed_size;
   }
   else if(!strncmp(temp_string[5], "VARE", 4))
   {
      prodLogVol->rec_format = PMDSPE_rfm_variable_size;
   }
   else {
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_log_vol,
                        "Wrong rec_format field" );
   }


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_DefLogVolField */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_SeekCfgFile

        $TYPE              PROCEDURE

        $INPUT        fpCfg         : pointer to CFG file
                      file_code  : code file where to position

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Position in the CFG file at file_code

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_SeekCfgFile    (/*IN    */ FILE               *fpCfg,
                           /*IN    */ PMDSPT_file_code     file_code,
                           /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_SeekCfgFile";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *sub_str;
   PMDSPT_tmp_buf         buffer;
   LDEFIT_boolean         found = FALSE;
   
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get a line until PMDSPM_mrk_file_begin
   ========================================================================== */
   do
   {
      PMDSPP_GetCfgLine(fpCfg, sizeof(PMDSPT_tmp_buf), buffer, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      if( strncmp(buffer, PMDSPM_mrk_file_begin, strlen(PMDSPM_mrk_file_begin))
          == 0)
      {
         sub_str = strchr(buffer, ':');
         if (sub_str != NULL &&
             strncmp(sub_str+1, file_code, strlen(file_code)) == 0)
         {
            found = TRUE;
         }
      }
   } while ( !found );



error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_SeekCfgFile */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_SeekNextMarker

        $TYPE              PROCEDURE

        $INPUT        fpCfg         : pointer to CFG file

        $MODIFIED     NONE

        $OUTPUT       marker     : found marker
                      marker_value_str
                                 : found marker string

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Position in the CFG file at next file marker

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_SeekNextMarker(/*IN    */ FILE                *fpCfg,
                           /*   OUT*/ PMDSPT_marker       *marker,
                           /*   OUT*/ char                *marker_value_str,
                           /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_SeekNextMarker";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   PMDSPT_tmp_buf         buffer;
   LDEFIT_boolean         found = FALSE;
   INTx4                  i;
   
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get a line until a marker is found
   ========================================================================== */
   do
   {
      PMDSPP_GetCfgLine(fpCfg, sizeof(PMDSPT_tmp_buf), buffer, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      if (buffer[0] == '.')
      {
         for (i = 0; i < PMDSPV_max_marker; i++)
         {
            if (strncmp(buffer, PMDSPV_marker_name[i], 
                        strlen(PMDSPV_marker_name[i])) == 0)
            {
               char *two_point = strchr(buffer, ':');

               marker_value_str[0] = '\0';
               if (two_point != NULL)
               {
                  two_point += 1;
                  while( isspace(two_point[0]) && two_point[0] != '\0' )
                     two_point++;
                  strcpy(marker_value_str, two_point);
               }

               marker->type = (PMDSPT_marker_type) i;
               found = TRUE;
               break;
            }
         }
      }
      else  if( buffer[ 0 ] == '@' ) {
         marker->type = PMDSPE_mrk_assign;
         strcpy(marker_value_str, buffer );
         break;
      }
   } while ( !found );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_SeekNextMarker */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_GetCurrRecordSize

        $TYPE              FUNCTION

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read the record size of the current record from
                      F_R(f,r) variable

        $WARNING      NONE

   $EH
   ========================================================================== */
INTx4 PMDSPF_GetCurrRecordSize
                          (/*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPF_GetCurrRecordSize";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   PMDSPT_parm_name       var;
   char                   msg[ 256 ];
   PMDSPT_parm_value      out_value;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Read variables
   ========================================================================== */
   sprintf(var, "F_R(%d,%d)", PMDSPV_gm.cur_file_num, PMDSPV_gm.cur_rec_num );
   PMDSPP_GetVar(var, out_value, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check record size equal to 0
   ========================================================================== */
   if( atoi(out_value) == 0 ) {
      sprintf( msg, "%s is 0", var );
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_log_vol,
                        msg );
   }


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return( atoi(out_value) );

}/* PMDSPF_GetCurrRecordSize */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_ReadCurrRepeat

        $TYPE         PROCEDURE

        $INPUT        cfg_fp   : pointer to CFG file

        $MODIFIED     NONE

        $OUTPUT       grp_rec_ptr : pointer to record

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read the next record contained into CFG file and load all
                      into memory.

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_ReadCurrRepeat (/*IN    */ FILE                 *cfg_fp,
                            /*IN    */ PMDSIT_deformat_mode  mode,
                            /*   OUT*/ PMDSPT_cfg_grp_rec   *grp_rec_ptr,
                            /*   OUT*/ INTx4                *nb_rec_field,
                            /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_ReadCurrRepeat";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   PMDSPT_marker          marker;
   char                   marker_val_str[255];
   PMDSPT_cfg_rec         *rec_ptr = (PMDSPT_cfg_rec *) NULL;
   char                   record_name[256];
   char                   msg[ 512 ];
   char                   note2[256];
   INTx4                  ichar;
   LDEFIT_boolean         end_repeat = FALSE;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Init grp_rec_ptr
   ========================================================================== */
   grp_rec_ptr->max_rec = 0;
   grp_rec_ptr->cfg_rec  = (PMDSPT_cfg_rec **) NULL;

/* ==========================================================================
   Read from PMDS file structure
   ========================================================================== */
   while (!end_repeat)
   {

/* ==========================================================================
    Seek next marker
   ========================================================================== */
      PMDSPP_SeekNextMarker(cfg_fp, &marker, marker_val_str, status_code);
      ERRSIM_on_err_goto_exit( *status_code );


      if( (marker.type != PMDSPE_mrk_repeat_end) &&
          (marker.type != PMDSPE_mrk_img_end) )
      {
/* ==========================================================================
   Alloc memory for new record record
   ========================================================================== */
         rec_ptr = MEMSIP_alloc( sizeof(PMDSPT_cfg_rec));
         if(rec_ptr == (PMDSPT_cfg_rec *) NULL)
         {
            sprintf( msg, "Line %d", PMDSPV_gm.cfg_pos);
            ERRSIM_set_error( status_code,
                              ERRSID_PMDS_alloc_cfg_rec,
                              msg );
         }

/* ==========================================================================
   Realloc the vector of pointer
   ========================================================================== */
         grp_rec_ptr->cfg_rec = MEMSIP_realloc(
            grp_rec_ptr->cfg_rec,
            (grp_rec_ptr->max_rec+1)*sizeof(PMDSPT_cfg_rec *));
         if(grp_rec_ptr->cfg_rec == ((PMDSPT_cfg_rec **) NULL))
         {
            sprintf( msg, "Line %d", PMDSPV_gm.cfg_pos);
            ERRSIM_set_error( status_code,
                              ERRSID_PMDS_alloc_cfg_rec,
                              msg );
         }

/* ==========================================================================
   Attach the new record to pointer
   ========================================================================== */
         grp_rec_ptr->cfg_rec[grp_rec_ptr->max_rec] = rec_ptr;
      }

      switch(marker.type)
      {
         case PMDSPE_mrk_record_begin:
            /* Read current record */
            rec_ptr->max_repeat = 1;

            PMDSPP_ReadCurrRec(cfg_fp, rec_ptr, nb_rec_field, status_code);
            ERRSIM_on_err_goto_exit( *status_code );

            if( *nb_rec_field > 0 ) {
               strcpy(record_name, marker_val_str);
               for(ichar = (strlen(record_name) - 1); ichar >= 0; ichar--)
               {
                  if(record_name[ichar] == '\n')
                  {
                     record_name[ichar] = '\0';
                     break;
                  }
               }

               if( mode == PMDSIE_HeaderDecodeMode ) {

                  fprintf( stdout, "%s\n", record_name );

                  strcpy(note2, "--------------------------------------------------");
                  strcat(note2, "--------------------------------------------------");
                  strcat(note2, "--------------------------------------------------");

                  PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                                         PMDSPE_ANNF_DataType,
                                         "Record name................: ",
                                         (void*)record_name,
                                         status_code);
                  ERRSIM_on_err_goto_exit( *status_code );

                  PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                                         PMDSPE_ANNF_HeaderType,
                                         NULL,
                                         NULL,
                                         status_code);
                  ERRSIM_on_err_goto_exit( *status_code );

                  PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                                         PMDSPE_ANNF_DataType,
                                         NULL,
                                         (void*)note2,
                                         status_code);
                  ERRSIM_on_err_goto_exit( *status_code );
               }
            }
            break;

         case PMDSPE_mrk_repeat_end:
         case PMDSPE_mrk_img_end:
            end_repeat = TRUE;
            break;

         default:
            sprintf( msg, "Line %d", PMDSPV_gm.cfg_pos);
            ERRSIM_set_error( status_code,
                              ERRSID_PMDS_alloc_cfg_rec,
                              msg );
      }

      if(end_repeat != TRUE)
      {
         grp_rec_ptr->max_rec++;
      }
   }     /* End for */


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_ReadCurrRepeat */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_FreeRec

        $TYPE         PROCEDURE

        $INPUT        rec_ptr  : pointer to record

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This service free all memory allocated by
                      'PMDSPP_ReadCurrRec' function for store all fields 
                      of the CFG record.

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_FreeRec     (/*IN    */ PMDSPT_cfg_rec       *rec_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_FreeRec";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Free memory
   ========================================================================== */
   for (i = 0; i < rec_ptr->max_field; i++)
   {
      MEMSIP_free((void **) &((rec_ptr->cfg_field)[i]));
   }

   MEMSIP_free((void **) &(rec_ptr->cfg_field));

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_FreeRec */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_FreeGrpRec

        $TYPE         PROCEDURE

        $INPUT        grp_rec_ptr  : pointer to record

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This service free all memory allocated by
                      'PMDSPP_ReadCurrRepeat' function for store all fields 
                      of the CFG record.

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_FreeGrpRec  (/*IN    */ PMDSPT_cfg_grp_rec   *grp_rec_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_FreeGrpRec";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Free memory
   ========================================================================== */
   for (i = 0; i < grp_rec_ptr->max_rec; i++)
   {
      PMDSPP_FreeRec(grp_rec_ptr->cfg_rec[ i ], status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      MEMSIP_free((void **) &(grp_rec_ptr->cfg_rec[ i ]));
   }

   MEMSIP_free((void **) &(grp_rec_ptr->cfg_rec));

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_FreeGrpRec */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_ReadProdRec

        $TYPE         FUNCTION

        $INPUT        size   : byte to read

        $MODIFIED     NONE

        $OUTPUT       ptr    : pointer to product data

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read product record

        $WARNING      NONE

   $EH
   ========================================================================== */
INTx4 PMDSPF_ReadProdRec   ( /*IN    */ INTx4                data_size,
                             /*   OUT*/ void                *prod_ptr,
                             /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPF_ReadProdRec";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  bytes_read;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   if((PMDSPV_input.media_type == DEVSIE_mt_file)                             ||
      (PMDSPV_input.media_type == DEVSIE_mt_cdrom))
   {
/* ==========================================================================
   Read from file
   ========================================================================== */
      bytes_read = FILSIF_read( PMDSPV_input.media_pointer.fp,
                                data_size,
                                prod_ptr,
                                status_code );
   }
   else if(PMDSPV_input.media_type == DEVSIE_mt_exa)
   {
      bytes_read = DEVSIF_read( PMDSPV_input.media_pointer.exa,
                                data_size,
                                prod_ptr,
                                status_code );
   }
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return( bytes_read );

}/* PMDSPF_ReadProdRec */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_GetCurrFileSize

        $TYPE              FUNCTION

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read the variable MAX_F_SZ and return the value

        $WARNING      NONE

   $EH
   ========================================================================== */
INTx4 PMDSPF_GetCurrFileSize
                        (/*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPF_GetCurrFileSize";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   PMDSPT_parm_name       var;
   PMDSPT_parm_value      out_value;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Read variables
   ========================================================================== */
   sprintf(var, "MAX_F_SZ(%d)", PMDSPV_gm.cur_file_num);

   PMDSPP_GetVar(var, out_value, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return ( atoi(out_value) );

}/* PMDSPF_GetCurrFileSize */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_DeformatProdRecord

        $TYPE              PROCEDURE

        $INPUT        data_size        : record data size
                      mode             : deformatting mode
                      cfg_rec          : pointer to CFG record

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_DeformatProdRecord
                        (/*IN    */ INTx4                data_size,
                         /*IN    */ PMDSIT_deformat_mode mode,
                         /*IN    */ PMDSPT_cfg_rec      *cfg_rec,
                         /*IN    */ LDEFIT_boolean       annotate,
                         /*IN    */ INTx4                nb_rec_field,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_DeformatProdRecord";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx1                 integer1;
   UINTx2                 integer2;
   UINTx4                 integer4;
   double                 tmpDouble;
   INTx4                  i;
   INTx4                  cut_position;
   INTx4                  curr_repeat, max_repeat, size_grp_field;
   INTx4                  first_rec_repeat;
   INTx4                  bytes_read;
   char                  *out_record = NULL;
   char                  *value_str = NULL;
   PMDSPT_cfg_field       *field_ptr;
   PMDSPT_parm_value      out_var;
   PMDSPT_field_name      cur_field_name;
   char                  *input_prod_data = NULL;
   char                   note2[256];
   char                   field_value[1000];
   char                   msg[ 512 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Alloc buffer and read the data from file
   ========================================================================== */
   input_prod_data = MEMSIP_alloc(data_size + 1);
   if( input_prod_data == (char *) NULL)
   {
      sprintf( msg, "Allocating input_prod_data (size %0d)", 
                    data_size+1);
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_defo_prod,
                        msg );
   }

   if( nb_rec_field > 0 ) {

      bytes_read = PMDSPF_ReadProdRec( data_size, 
                                       input_prod_data, 
                                       status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      if(bytes_read > data_size)
      {
         sprintf(msg, "Internal buffer size is %d, but read %d bytes.",
            data_size, bytes_read);
	 ERRSIM_set_error( status_code,
                           ERRSID_PMDS_defo_prod,
                           msg );
      }

      if( mode != PMDSIE_QuickLookMode ) {
#ifdef __TRACE__
         memcpy(&integer4, input_prod_data, 4);
         PMDSLP_Adjust( &integer4, sizeof(INTx4));
         if ((integer4 % 100) == 0) fprintf( stdout, "%0d %0d\n", integer4, bytes_read );
#endif
         SRVSIP_trace_comp( &log_status_code );
      }
   }

/* ==========================================================================
   Initialize counter(s)
   ========================================================================== */
   curr_repeat    = 0;
   max_repeat     = 0;

/* ==========================================================================
   Loop onto fields number
   ========================================================================== */
   for (i = 0; i < cfg_rec->max_field; i++)
   {
      field_ptr = (cfg_rec->cfg_field)[i];
      if( field_ptr->num == -1 ) {
         PMDSPP_EvalAssign( field_ptr->default_value, status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
      else {

         strcpy(cur_field_name, field_ptr->name);

         out_record = MEMSIP_realloc(out_record, field_ptr->format_size + 100);
         if( out_record == (char *) NULL)
         {
            sprintf( msg, "Error allocating input_prod_data (size %0d)", 
                          data_size+1);
            ERRSIM_set_error( status_code,
                              ERRSID_PMDS_defo_prod,
                              "Cannot realloc out_record" );
         }


         value_str = MEMSIP_realloc(value_str, field_ptr->format_size + 100);
         if( value_str == (char *) NULL)
         {
            ERRSIM_set_error( status_code,
                              ERRSID_PMDS_defo_prod,
                              "Cannot realloc value_str" );
         }

/* ==========================================================================
   CFG Repeat CONTROL
   ========================================================================== */
         if(field_ptr->begin_repeat == TRUE)
         {
            if(curr_repeat == 0)
            {
               size_grp_field = 0;
               first_rec_repeat = i - 1;

               if(field_ptr->max_rep_str[0] == '@')
               {
                  char *new_line;
                  if( (new_line = strchr( field_ptr->max_rep_str, '\n' )) != 
                      ((char *) NULL))
                  {
                     *new_line = '\0';
                  }
                  PMDSPP_GetVar(field_ptr->max_rep_str+1, out_var, status_code);
                  ERRSIM_on_err_goto_exit( *status_code );
                  max_repeat = curr_repeat = atoi(out_var);
               }
               else
               {
                  max_repeat = curr_repeat = atoi(field_ptr->max_rep_str);
               }
            }
         }

         if( max_repeat >= 0 ) {
/* ==========================================================================
   Deformat data
   ========================================================================== */
	    cut_position = field_ptr->byte_start - 1 +
	       (max_repeat - curr_repeat) * size_grp_field;

	    memcpy(out_record, input_prod_data + cut_position,
	       field_ptr->format_size);
	    out_record[ field_ptr->format_size ] = '\0';

	    if(curr_repeat)
	    {
	       sprintf(cur_field_name, "%s_%d", cur_field_name, max_repeat -
		  curr_repeat + 1);
	    }

	    strcpy(field_value, " ");
	    switch(field_ptr->format)
	    {
	       case 'b'        :
	       case 'B'        :
		  if (field_ptr->format_size == 1)
		  {
		     memcpy(&integer1, out_record, 1);
		     PMDSLP_Adjust(&integer1, sizeof(INTx1));
		     sprintf( out_record, "%0d", integer1 );
		     PMDSLP_SprintfIntegerParm(value_str, cur_field_name,
			(INTx4) integer1);
		     sprintf(field_value, "%d", (INTx4)integer1);
		  }
		  if (field_ptr->format_size == 2)
		  {
		     memcpy(&integer2, out_record, 2);
		     PMDSLP_Adjust( &integer2, sizeof(INTx2));
		     sprintf( out_record, "%0d", integer2 );
		     PMDSLP_SprintfIntegerParm(value_str, cur_field_name,
			(INTx4) integer2);
		     sprintf(field_value, "%d", (INTx4)integer2);
		  }
		  if (field_ptr->format_size == 4)
		  {
		     memcpy(&integer4, out_record, 4);
		     PMDSLP_Adjust( &integer4, sizeof(INTx4));
		     sprintf( out_record, "%0d", integer4 );
		     PMDSLP_SprintfIntegerParm(value_str, cur_field_name,
			(INTx4) integer4);
		     sprintf(field_value, "%d", (INTx4)integer4);
		  }
		  break;

	       case 'k'        :
	       case 'K'        :
		  if (field_ptr->format_size == 1)
		  {
		     memcpy(&integer1, out_record, 1);
		     PMDSLP_KFormatAdjust(&integer1, sizeof(INTx1));
		     PMDSLP_Adjust(&integer1, sizeof(INTx1));
		     sprintf( out_record, "%0d", integer1 );
		     PMDSLP_SprintfIntegerParm(value_str, cur_field_name,
			(INTx4) integer1);
		     sprintf(field_value, "%d", (INTx4)integer1);
		  }
		  if (field_ptr->format_size == 2)
		  {
		     memcpy(&integer2, out_record, 2);
		     PMDSLP_KFormatAdjust( &integer2, sizeof(INTx2));
		     PMDSLP_Adjust( &integer2, sizeof(INTx2));
		     sprintf( out_record, "%0d", integer2 );
		     PMDSLP_SprintfIntegerParm(value_str, cur_field_name,
			(INTx4) integer2);
		     sprintf(field_value, "%d", (INTx4)integer2);
		  }
		  if (field_ptr->format_size == 4)
		  {
		     memcpy(&integer4, out_record, 4);
		     PMDSLP_KFormatAdjust( &integer4, sizeof(INTx4));
		     PMDSLP_Adjust( &integer4, sizeof(INTx4));
		     sprintf( out_record, "%0d", integer4 );
		     PMDSLP_SprintfIntegerParm(value_str, cur_field_name,
			(INTx4) integer4);
		     sprintf(field_value, "%d", (INTx4)integer4);
		  }
		  break;

	       case 'a'        :
	       case 'A'        :
	       case 'i'        :
	       case 'I'        :
	       case 'd'        :
	       case 'D'        :
	       case 'e'        :
	       case 'E'        :
		  PMDSLP_SprintfStringParm(value_str, cur_field_name, out_record);
		  strcpy(field_value, "-");
		  break;

	       case 'f'        :
	       case 'F'        :
		  PMDSLP_ConvertToFloat( &tmpDouble, out_record );
		  sprintf(field_value, "%s", out_record);
		  PMDSLP_SprintfFloatParm(value_str, cur_field_name, tmpDouble,
					  field_ptr->format_size,
					  field_ptr->after_comma_size );
		  break;

	       case 'R'        :
	       case 'r'        :
	       case 'C'        :
	       case 'c'        :
	       case 'V'        :
	       case 'v'        :
		  break;

	       default         :

		  ERRSIM_set_error( status_code,
				    ERRSID_PMDS_defo_prod,
				    "Cannot parse record structure" );
	    }

/* ==========================================================================
   Write if request to TIF file annotation
   ========================================================================== */
	    if( (mode == PMDSIE_HeaderDecodeMode ) && 
		(field_ptr->write_tif == TRUE) )
	    {
	       if((strcmp(field_value, "-")) == 0)
	       {
		  PMDSPP_TFDM_AddTiffField(field_ptr->name,
					   out_record,
					  &PMDSPV_TiffList,
					   status_code);
		  ERRSIM_on_err_goto_exit( *status_code );
	       }
	       else
	       {
		  PMDSPP_TFDM_AddTiffField(field_ptr->name,
					   field_value,
					  &PMDSPV_TiffList,
					   status_code);
		  ERRSIM_on_err_goto_exit( *status_code );
	       }

	    }

/* ==========================================================================
   Store variables
   ========================================================================== */
	    if(field_ptr->in_var[0] == '@')
	    {
	       PMDSPP_StoreVarAndValue( field_ptr->in_var + 1,
					out_record,
					PMDSPE_int_parm,
					status_code);
	       ERRSIM_on_err_goto_exit( *status_code );
	    }

/* ==========================================================================
      Write data into the annotation file
   ========================================================================== */
	    if( (mode == PMDSIE_HeaderDecodeMode) && 
		(annotate == TRUE) )
	    {
	       strcpy(note2, "--------------------------------------------------");
	       strcat(note2, "--------------------------------------------------");
	       strcat(note2, "--------------------------------------------------");

	       if((strcmp(field_value, "-")) == 0)
	       {
		  PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
					 PMDSPE_ANNF_FieldType,
					 out_record,
					 (void*)field_ptr,
					 status_code);
		  ERRSIM_on_err_goto_exit( *status_code );
	       }
	       else
	       {
		  PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
					 PMDSPE_ANNF_FieldType,
					 field_value,
					 (void*)field_ptr,
					 status_code);
		  ERRSIM_on_err_goto_exit( *status_code );
	       }

	       PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
				      PMDSPE_ANNF_DataType,
				      NULL,
				      (void*)note2,
				      status_code);
	       ERRSIM_on_err_goto_exit( *status_code );
	    }

/* ==========================================================================
   Calculate the sum of the size of all fields of REPEAT
   ========================================================================== */
	    if (curr_repeat == max_repeat)
	    {
	       size_grp_field += field_ptr->format_size;
	    }

/* ==========================================================================
   Repeat CONTROL
   ========================================================================== */
	    if (field_ptr->end_repeat == TRUE)
	    {
	       if (curr_repeat)
	       {
		     if (--curr_repeat == 0)
		  {
		     curr_repeat = 0;
		     max_repeat  = 0;
		  }
		  else
		  {
		     i = first_rec_repeat;
		  }
	       }
	       else
	       { 
		  ERRSIM_set_error( status_code,
				    ERRSID_PMDS_defo_prod,
				    "Cannot parse record structure" );
	       }
	    }
         }
      }
   }

error_exit:;

   MEMSIP_free( (void **) &value_str );
   MEMSIP_free( (void **) &out_record );
   MEMSIP_free( (void **) &input_prod_data );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_DeformatProdRecord */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_GenerateTifImage

        $TYPE              PROCEDURE

        $INPUT        record_data_size  : size of product image data
                      mode              : deformatting mode
                      record_num        : number of image records
                      record_skipped    : record to be skipped
                      record_kept       : record to be kept
                      width_skipped     : width to be skipped
                      width_kept        : width to be kept
                      ql_width          : width of the output quick look
                      ql_height         : height of the output quick look
                      win_width         : width of the window to be used
                      win_height        : height of the window to be used
                      vol_id            : current volume (tape) id
                      tif_ann_file      : tif annotation file name
                      out_img_name      : output tiff image name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This service call the various image generation.

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_GenerateTifImage
                        (/*IN    */ INTx4                record_data_size,
                         /*IN    */ PMDSIT_deformat_mode mode,
                         /*IN    */ INTx4                record_num,
                         /*IN    */ INTx4                record_skipped,
                         /*IN    */ INTx4                record_kept,
                         /*IN    */ INTx4                width_skipped,
                         /*IN    */ INTx4                width_kept,
                         /*IN    */ INTx4                ql_width,
                         /*IN    */ INTx4                ql_height,
                         /*IN    */ UINTx4               win_width,
                         /*IN    */ UINTx4               win_height,
                         /*IN    */ INTx4                vol_id,
                         /*IN    */ char                *tif_ann_file,
                         /*IN    */ char                *out_img_name,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ LDEFIT_boolean      *image_completed,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_GenerateTifImage";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;
                         
   INTx4                  iitem;
   INTx4                  jitem;
   INTx4                  line;
   INTx4                  bytes_read;
   INTx4                  lines_to_be_read;
   char                   msg[ 512 ];
   INTx4                  count = 0;
   
   UINTx2                 npar;
   UINTx2                 npar_basic = 13;
   UINTx2                 npar_user = 0;
   static INTx4           channel;
   static INTx4           ann_chan;  
   INTx4                  ann_image = 0;
   INTx4                  ann_nimage = 1;
   INTx4                  image = 0;
   INTx4                  nimage = 1;
   void                  *imgline;
   UINTx1                *tmp_imageline;
   float                **win_data;
   double                 step_row;
   double                 step_col;
   float                  reduct_col;
   float                  reduct_row;
   MATHIT_RC              corner_rc;
   MATHIT_LLH             corner_llh;
   GIOSIT_io              inp_io;
   GIOSIT_io              out_io;
   INTx4                  data_size;
   OVLSIT_core_func       core_func = PMDSPP_UNDR_ConvCoreConstKern;
   TIFSIT_basicpar        out_bpar;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the current volume (tape) id
   ========================================================================== */
   if( ((vol_id == PMDSPD_first_vol) || (vol_id == PMDSPD_single_vol)) &&
       ((mode == PMDSIE_FullResolutionMode) || (mode == PMDSIE_QuickLookMode)))
   {

/* ==========================================================================
      Init basic parameter of output image
   ========================================================================== */
      TIFSIM_bpar_init(out_bpar);

/* ==========================================================================
      Number of pixels in the X image direction
   ========================================================================== */
      if(mode == PMDSIE_QuickLookMode)
         out_bpar.imagewidth = ql_width;
      else
         out_bpar.imagewidth = width_kept;

/* ==========================================================================
      Number of pixels in the Y image direction
   ========================================================================== */
      if(mode == PMDSIE_QuickLookMode)
         out_bpar.imagelength = ql_height;
      else
         out_bpar.imagelength = record_kept;

/* ==========================================================================
      Number of samples per pixel
   ========================================================================== */
      if(mode == PMDSIE_QuickLookMode)
         out_bpar.sampleperpixel = 1;
      else
         out_bpar.sampleperpixel = PMDSPV_prod_image.sample_per_pix;

/* ==========================================================================
      Sample format of the pixel
   ========================================================================== */
      if(mode == PMDSIE_QuickLookMode)
      {
         out_bpar.sampleformat[0] = TIFSID_float;
      }
      else
      {
         if(out_bpar.sampleperpixel == 1)
         {
            if(PMDSPV_prod_image.bits_per_sample == 16)
               out_bpar.sampleformat[0] = TIFSID_uintdata;
         }
         else if(out_bpar.sampleperpixel == 2)
         {
            if(PMDSPV_prod_image.bits_per_sample == 8)
               out_bpar.sampleformat[0] = TIFSID_uintdata;
            else if(PMDSPV_prod_image.bits_per_sample == 16)
               out_bpar.sampleformat[0] = TIFSID_sintdata;
         }
         else
         {
            out_bpar.sampleformat[0] = TIFSID_undef;
            ERRSIM_set_error(status_code, ERRSID_PMDS_error_not_allowed, "");
         }
      }

/* ==========================================================================
      Number of bits per sample
   ========================================================================== */
      for(iitem = 0; iitem < out_bpar.sampleperpixel; iitem++)
      {
         if(mode == PMDSIE_QuickLookMode)
            out_bpar.bitspersample[iitem] = 32;
         else
            out_bpar.bitspersample[iitem] = PMDSPV_prod_image.bits_per_sample;
      }

/* ==========================================================================
      Alloc buffer
   ========================================================================== */
      imgline = (void *) MEMSIP_alloc
         (((out_bpar.sampleperpixel * out_bpar.bitspersample[0]) / 8 *
            PMDSPV_prod_image.image_width) + PMDSPV_prod_image.bytes_skip);

/* ==========================================================================
      Initialize the coordinates conversions
      nel full non servono
   ========================================================================== */
      IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth = PMDSPV_prod_image.image_width;
      IANNIV_ImageAnnot[ inp_ima_num ].ImageLength = record_num;
      IANNIV_ImageAnnot[ inp_ima_num ].SamplePerPixel = 
         PMDSPV_prod_image.sample_per_pix;
      IANNIV_ImageAnnot[ inp_ima_num ].BitsPerSample[0] = 
         PMDSPV_prod_image.bits_per_sample;
      IANNIV_ImageAnnot[ inp_ima_num ].SampleFormat[0]  = 
         out_bpar.sampleformat[0];

/*
      if(out_bpar.sampleperpixel == 1)
         IANNIV_ImageAnnot[0].PixelType = IANNIE_pixt_amplitude;
      else
         IANNIV_ImageAnnot[0].PixelType = IANNIE_pixt_complex;
*/

/* ==========================================================================
      Zero the output image annotations structure and copy
   ========================================================================== */
      IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Update tags for the portion of the extracted image
   ========================================================================== */
      IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
	 out_bpar.imagewidth;
      IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
	 out_bpar.imagelength;
      IANNIV_ImageAnnot[ out_ima_num ].SamplePerPixel = 
	 out_bpar.sampleperpixel;
      IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] = 
	 out_bpar.bitspersample[0];
      IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
	 out_bpar.sampleformat[0];
      IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow = record_skipped;
      IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol = width_skipped;

#ifdef __NOT_USEFUL__
      if(out_bpar.sampleperpixel == 1)
	 IANNIV_ImageAnnot[ out_ima_num ].PixelType = IANNIE_pixt_amplitude;
      else
	 IANNIV_ImageAnnot[ out_ima_num ].PixelType = IANNIE_pixt_complex;
      IANNIV_ImageAnnot[ out_ima_num ].ScalingFactor = 1.0;

      IANNIV_ImageAnnot[ out_ima_num ].CalibrationConstantApplicationFlag = 
	 0;
      IANNIV_ImageAnnot[ out_ima_num ].ADCSaturationCompensationFlag = 0;
#endif

      if( mode == PMDSIE_QuickLookMode ) {
         step_col = (double) SRVSIM_step( width_kept, win_width, ql_width );
         step_row = (double) SRVSIM_step( record_kept, win_height, ql_height );

         reduct_col = ((float) (width_kept - 1))/((float) (ql_width - 1));
         reduct_row = ((float) (record_kept - 1))/((float) (ql_height - 1));

         IANNIV_ImageAnnot[ out_ima_num ].XScalingFactor /= reduct_col;
         IANNIV_ImageAnnot[ out_ima_num ].YScalingFactor /= reduct_row;
         IANNIV_ImageAnnot[ out_ima_num ].PixelSpacing_m *= reduct_col;
         IANNIV_ImageAnnot[ out_ima_num ].LineSpacing_m *= reduct_row;
      }

/* ==========================================================================
      Update processing history
   ========================================================================== */
      IANNIP_PUTP_UpdateProcHistory( out_ima_num,
                                     (mode == PMDSIE_QuickLookMode ?
                                        "QUICK LOOK" : "FULL RESOLUTION" ),
                                     "",
                                     status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Initialize coordinate conversion(s)
   ========================================================================== */
      COORIP_CONV_Init( inp_ima_num, status_code);
      if( *status_code != STC( ERRSID_normal ) ) {
         *status_code = ERRSID_normal;
         ERRSIM_print_warning( "Corners coordinates not evaluable" );
         IANNIV_ImageAnnot[ out_ima_num ].TopLeftLat_deg = 0.0;
         IANNIV_ImageAnnot[ out_ima_num ].TopLeftLon_deg = 0.0;
         IANNIV_ImageAnnot[ out_ima_num ].TopRightLat_deg = 0.0;
         IANNIV_ImageAnnot[ out_ima_num ].TopRightLon_deg = 0.0;
         IANNIV_ImageAnnot[ out_ima_num ].BottomRightLat_deg = 0.0;
         IANNIV_ImageAnnot[ out_ima_num ].BottomRightLon_deg = 0.0;
         IANNIV_ImageAnnot[ out_ima_num ].BottomLeftLat_deg = 0.0;
         IANNIV_ImageAnnot[ out_ima_num ].BottomLeftLon_deg = 0.0;
         IANNIV_ImageAnnot[ out_ima_num ].CentreGeodeticLat_deg = 0.0;
         IANNIV_ImageAnnot[ out_ima_num ].CentreGeodeticLon_deg = 0.0;
      }         
      else {
/* ==========================================================================
      Corners coordinates
   ========================================================================== */
/* Top Left corner */
         corner_rc.row = (double) record_skipped;
         corner_rc.col = (double) width_skipped;
         COORIP_CONV_rc_llh( &corner_rc,
                              inp_ima_num,
   			     &corner_llh,
   			     status_code );
         ERRSIM_on_err_goto_exit( *status_code );
         IANNIV_ImageAnnot[ out_ima_num ].TopLeftLat_deg = (float) corner_llh.lat;
         IANNIV_ImageAnnot[ out_ima_num ].TopLeftLon_deg = (float) corner_llh.lon;

/* Top Right corner */
         corner_rc.row = (double) record_skipped;
         corner_rc.col = (double)(width_skipped + width_kept - 1);
         COORIP_CONV_rc_llh( &corner_rc,
   			     inp_ima_num,
			     &corner_llh,
			     status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
	 IANNIV_ImageAnnot[ out_ima_num ].TopRightLat_deg = (float) corner_llh.lat;
	 IANNIV_ImageAnnot[ out_ima_num ].TopRightLon_deg = (float) corner_llh.lon;

/* Bottom Right corner */
	 corner_rc.row = (double)(record_skipped + record_kept - 1 );
	 corner_rc.col = (double)(width_skipped + width_kept - 1 );
	 COORIP_CONV_rc_llh( &corner_rc,
			     inp_ima_num,
			     &corner_llh,
			     status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
	 IANNIV_ImageAnnot[ out_ima_num ].BottomRightLat_deg = (float) corner_llh.lat;
	 IANNIV_ImageAnnot[ out_ima_num ].BottomRightLon_deg = (float) corner_llh.lon;

/* Bottom Left corner */
	 corner_rc.row = (double)(record_skipped + record_kept - 1 );
	 corner_rc.col = (double) width_skipped;
	 COORIP_CONV_rc_llh( &corner_rc,
			     inp_ima_num,
			     &corner_llh,
			     status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
	 IANNIV_ImageAnnot[ out_ima_num ].BottomLeftLat_deg = (float) corner_llh.lat;
	 IANNIV_ImageAnnot[ out_ima_num ].BottomLeftLon_deg = (float) corner_llh.lon;

/* Center point */
	 corner_rc.row = (double)(record_skipped + (INTx4)((record_kept - 1) / 2));
	 corner_rc.col = (double)(width_skipped + (INTx4)((width_kept - 1) / 2));
	 COORIP_CONV_rc_llh( &corner_rc,
			     inp_ima_num,
			     &corner_llh,
			     status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
	 IANNIV_ImageAnnot[ out_ima_num ].CentreGeodeticLat_deg = (float) corner_llh.lat;
	 IANNIV_ImageAnnot[ out_ima_num ].CentreGeodeticLon_deg = (float) corner_llh.lon;

/* ==========================================================================
   Geocoded product
   ========================================================================== */
         switch ( IANNIV_ImageAnnot[ out_ima_num ].MapProjectionType ) {
	    case IANNIE_proj_UTM:
	    case IANNIE_proj_UPS: {
	       MATHIT_EN	   corner_en;

/* ==========================================================================
   Rescale the top left corner
   ========================================================================== */
	       corner_rc.row = (double) 
                  (IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow *
                   IANNIV_ImageAnnot[ out_ima_num ].YScalingFactor);
	       corner_rc.col = (double) 
                  (IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol *
                   IANNIV_ImageAnnot[ out_ima_num ].XScalingFactor);

/* ==========================================================================
   Convert the top left corner
   ========================================================================== */
	       COORIP_CONV_rc_en( &corner_rc,
				  out_ima_num,
				  &corner_en,
				  status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the corresponding tags in the structure
   ========================================================================== */
	       IANNIV_ImageAnnot[ out_ima_num ].TopLeftEast_m = (float)
		  corner_en.east;
	       IANNIV_ImageAnnot[ out_ima_num ].TopLeftNorth_m = (float)
		  corner_en.north;
	    }
         }
      }

/* ==========================================================================
      Set total parameters number
   ========================================================================== */
      npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;


#ifdef __TRACE__

fprintf(stderr, "Debug:             npar = <%d>\n", npar);
fprintf(stderr, "Debug:       npar_basic = <%d>\n", npar_basic);
fprintf(stderr, "Debug:        npar_user = <%d>\n", npar_user);
fprintf(stderr, "Debug: record_data_size = <%d>\n", record_data_size);
fprintf(stderr, "Debug:       record_num = <%d>\n", record_num);
fprintf(stderr, "Debug:   record_skipped = <%d>\n", record_skipped);
fprintf(stderr, "Debug:      record_kept = <%d>\n", record_kept);
fprintf(stderr, "Debug:    width_skipped = <%d>\n", width_skipped);
fprintf(stderr, "Debug:       width_kept = <%d>\n", width_kept);
fprintf(stderr, "Debug:           vol_id = <%d>\n", vol_id);
fprintf(stderr, "Debug:     out_img_name = <%s>\n", out_img_name);
fprintf(stderr, "Debug:    bytes_skipped = <%d>\n", PMDSPV_prod_image.bytes_skip);
fprintf(stderr, "Debug:      image_width = <%d>\n", out_bpar.imagewidth);
fprintf(stderr, "Debug:     image_height = <%d>\n", out_bpar.imagelength);
fprintf(stderr, "Debug:   sampleperpixel = <%d>\n", out_bpar.sampleperpixel);
fprintf(stderr, "Debug:    bitspersample = <%d>\n", out_bpar.bitspersample[0]);

#endif

/* ==========================================================================
      Set the number of images found in the file
   ========================================================================== */
      TIFSIP_set_imgnum(out_img_name, nimage, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Set the number of total parameters for each image
   ========================================================================== */
      TIFSIP_set_parnum(out_img_name, image, npar, status_code); 
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Compute internal parameters
   ========================================================================== */
      TIFSIP_set_blockinfo(out_img_name, image, &out_bpar, status_code); 
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Open tiff file - returns file handle (channel)
   ========================================================================== */
      TIFSIP_open_tiff(out_img_name, 'w', &channel, status_code);    
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Writing of basic parameters and internal data
   ========================================================================== */
      TIFSIP_store_blockinfo(channel, image, status_code);   
      ERRSIM_on_err_goto_exit(*status_code );

/* ==========================================================================
      Store the image annotations on output file
   ========================================================================== */
      IANNIP_PUTP_ImageAnnot(channel, image, out_ima_num, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Opening of image write mode
   ========================================================================== */
      if(mode == PMDSIE_FullResolutionMode)
      {
         TIFSIP_open_line(channel, image, 'x', 0, out_bpar.imagewidth - 1,
            status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }

   } /* End of instructions only for the first volume (tape) */ 

/* ==========================================================================
   Check if data has to be written in full resolutiom mode
   ========================================================================== */
   if(mode == PMDSIE_FullResolutionMode)
   {

      if( PMDSPV_input.media_type == DEVSIE_mt_exa )
      {
         lines_to_be_read = record_num;
      }
      else
      {
         lines_to_be_read = (record_skipped + record_kept);
      }

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
      SRVSIP_set_comp( (INTx4) (record_skipped + record_kept),
         &log_status_code );

/* ==========================================================================
   Loop on image lines
   ========================================================================== */
      for(line = 0; line < lines_to_be_read && !(*image_completed); line++)
      {

         SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
         Reading line
   ========================================================================== */
         bytes_read = PMDSPF_ReadProdRec(record_data_size, 
                                         imgline,
                                         status_code);
         ERRSIM_on_err_goto_exit( *status_code );

         if(bytes_read > record_data_size)
         {
            sprintf(msg,
               "Internal buffer size is %d, but read %d bytes.",
               record_data_size, bytes_read);
            ERRSIM_set_error( status_code, ERRSID_PMDS_defo_prod, msg );
         }

/* ==========================================================================
         Check if data is into the selected window
   ========================================================================== */
         if((line >= record_skipped) && (line < (record_skipped + record_kept)))
         {
/* ==========================================================================
            Cut header data from the full image record
   ========================================================================== */
            tmp_imageline = (UINTx1*)imgline;
            tmp_imageline += PMDSPV_prod_image.bytes_skip;
            tmp_imageline += (width_skipped *
               ((out_bpar.sampleperpixel * out_bpar.bitspersample[0]) / 8));

/* ==========================================================================
            Adjust image line
   ========================================================================== */
            PMDSPP_AdjustImageLine ( tmp_imageline,
                                     (width_kept *
                                      ((out_bpar.sampleperpixel *
                                       out_bpar.bitspersample[0]) / 8)),
                                     PMDSPV_prod_data_type );

/* ==========================================================================
            Writing line
   ========================================================================== */
            TIFSIP_write_line( channel, image, line - record_skipped,
               (void *)tmp_imageline, status_code);
            ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
            fprintf( stdout, "Lines written = %d/%d\r", line - record_skipped, record_kept);
#endif

         }
/* ==========================================================================
   Break from the img loop
   ========================================================================== */
         if( line >= (record_skipped + record_kept - 1) ) {
            *image_completed = TRUE;
         }
      }

   }
/* ==========================================================================
   Check if data has to be written in quick look mode
   ========================================================================== */
   else if(mode == PMDSIE_QuickLookMode)
   {
      if(PMDSPV_input.media_type == DEVSIE_mt_exa)
      {
         strcpy(inp_io.val.exa.media, PMDSPV_input.name );
         inp_io.type = GIOSIE_device;
         inp_io.chan = PMDSPV_input.media_pointer.exa;
         inp_io.val.exa.curr_start_line = -1;
         inp_io.val.exa.curr_end_line = -1;
      }
      else if(PMDSPV_input.media_type == DEVSIE_mt_cdrom)
      {
         strcpy(inp_io.val.fil.fname, "CDROM");
         inp_io.type = GIOSIE_file;
         inp_io.chan = (UINTx4) PMDSPV_input.media_pointer.fp;
         inp_io.val.fil.fp = PMDSPV_input.media_pointer.fp;
         inp_io.val.fil.curr_start_line = -1;
         inp_io.val.fil.curr_end_line = -1;
      }
      else
      {
         ERRSIM_set_error( status_code, ERRSID_PMDS_error_not_allowed,
            "PMDSPV_input.media_type" );
      }
      inp_io.mode = 'r';
      inp_io.bps  = PMDSPV_prod_image.bits_per_sample;
      inp_io.spp  = PMDSPV_prod_image.sample_per_pix;
 
#ifdef __GENERIC__
      switch( inp_io.bps ) {
         case 1:
            switch( inp_io.spp ) {
               case  8:
                  inp_io.dt   = LDEFIE_dt_UINTx1;
                  break;
               case 16:
                  inp_io.dt   = LDEFIE_dt_UINTx2;
                  break;
               case 32:
                  inp_io.dt   = LDEFIE_dt_float;
                  break;
               default:
                  ERRSIM_set_error( status_code, ERRSID_PMDS_defo_prod,
                     "Unknown product type" );
                  break;
            }
            break;

         case 2:
            switch( inp_io.spp ) {
               case  8:
                  inp_io.dt   = LDEFIE_dt_2_UINTx1;
                  break;
               case 16:
                  inp_io.dt   = LDEFIE_dt_2_INTx2;
                  break;
               case 32:
                  inp_io.dt   = LDEFIE_dt_2_float;
                  break;
               default:
                  ERRSIM_set_error( status_code, ERRSID_PMDS_defo_prod,
                     "Unknown product type" );
                  break;
            }
            break;

      }
#endif

      switch(PMDSPV_product_type)
      {
         case PMDSIE_raw_prod:
            inp_io.dt   = LDEFIE_dt_2_UINTx1;
            break;
         case PMDSIE_slc_prod:
         case PMDSIE_slci_prod:
            inp_io.dt   = LDEFIE_dt_2_INTx2;
            break;
         case PMDSIE_pri_prod:
         case PMDSIE_gec_prod:
         case PMDSIE_gtc_prod:
            inp_io.dt   = LDEFIE_dt_UINTx2;
            break;
         default:
            ERRSIM_set_error( status_code, ERRSID_PMDS_defo_prod,
               "Unknown product type" );
      }
      data_size       = (((PMDSPV_prod_image.sample_per_pix *
         PMDSPV_prod_image.bits_per_sample) / 8 *
         PMDSPV_prod_image.image_width) + PMDSPV_prod_image.bytes_skip);

/* ==========================================================================
      Set tiff data
   ========================================================================== */
      memcpy( (void *) &(out_io.val.tif.bpar), 
              (void *) &out_bpar,
              sizeof( TIFSIT_basicpar ) );
      strcpy(out_io.val.tif.name, out_img_name);
      out_io.type         = GIOSIE_tif;
      out_io.mode         = 'w';
      out_io.val.tif.nimg = 1;
      out_io.val.tif.npar = npar;
      out_io.img          = 0;
      out_io.chan         = channel;
      out_io.bps          = 32;
      out_io.spp          = 1;
      out_io.dt           = LDEFIE_dt_float;

#ifdef __TRACE__
      fprintf(stderr, "Quick Look Mode\n");
      fprintf(stderr, "-------------------------------------------------------\n");
#endif

/* ==========================================================================
      Compute data
   ========================================================================== */
      step_col = (double) SRVSIM_step( width_kept, win_width, ql_width );
      step_row = (double) SRVSIM_step( record_kept, win_height, ql_height );

#ifdef __TRACE__

fprintf(stderr, "Debug:    BYTES_SKIPPED = <%d>\n", PMDSPV_prod_image.bytes_skip);
fprintf(stderr, "Debug:   SAMPLE_PER_PIX = <%d>\n", PMDSPV_prod_image.sample_per_pix);
fprintf(stderr, "Debug:  BITS_PER_SAMPLE = <%d>\n", PMDSPV_prod_image.bits_per_sample);
fprintf(stderr, "Debug:      IMAGE_WIDTH = <%d>\n", PMDSPV_prod_image.image_width);
fprintf(stderr, "Debug:        data_size = <%d>\n", data_size);
fprintf(stderr, "Debug:      image_width = <%d>\n", width_kept);
fprintf(stderr, "Debug:     image_height = <%d>\n", record_kept);
fprintf(stderr, "Debug:  new image_width = <%d>\n", out_bpar.imagewidth);
fprintf(stderr, "Debug: new image_height = <%d>\n", out_bpar.imagelength);
fprintf(stderr, "Debug:         ql_width = <%d>\n", ql_width);
fprintf(stderr, "Debug:        ql_height = <%d>\n", ql_height);
fprintf(stderr, "Debug:        win_width = <%d>\n", win_width);
fprintf(stderr, "Debug:       win_height = <%d>\n", win_height);
fprintf(stderr, "Debug:         step_row = <%g>\n", step_row);
fprintf(stderr, "Debug:         step_col = <%g>\n", step_col);

#endif

/* ==========================================================================
      Allocate memory
   ========================================================================== */
      win_data = (float **) MEMSIP_alloc (win_height * sizeof(float *));
      for(iitem = 0; iitem < win_height; iitem++)
      {
         win_data[iitem] = (float *) MEMSIP_alloc (win_width * sizeof(float));
      }

      for(iitem = 0; iitem < win_height; iitem++)
      {
         for(jitem = 0; jitem < win_width; jitem++)
         {
            win_data[iitem][jitem] =
               (float)(1. / (float)(win_width * win_height));
         }
      }

/* ==========================================================================
      Read from input image and write to output one
   ========================================================================== */
      OVLSIP_OverlapAndSave( &inp_io,                     /* GIOSIT_io        */
                              inp_ima_num,                /* UINTx1           */
                              0,                          /* UINTx4           */
                              0,                          /* UINTx4           */
                              record_kept,                /* UINTx4           */
                              width_kept,                 /* UINTx4           */
                              0,                          /* UINTx4           */
                             (MATHIT_RC *) NULL,          /* MATHIT_RC        */
                              win_data,                   /* float            */
                              win_height,                 /* UINTx4           */
                              win_width,                  /* UINTx4           */
                              step_row,                   /* double           */
                              step_col,                   /* double           */
                             &out_io,                     /* GIOSIT_io        */
                              (UINTx4) ql_height,         /* UINTx4           */
                              (UINTx4) ql_width,          /* UINTx4           */
                              core_func,                  /* PMDSIT_core_func */
                              (float)(PMDSPV_prod_image.bytes_skip), 
                                                          /* float            */
                              data_size,                  /* INTx4            */
                              status_code);               /* ERRSIT_status    */
      ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
      fprintf(stderr, "OVLSIP_OverlapAndSave completed.\n");
#endif

/* ==========================================================================
      Get the current input image file pointer (maybe the tape)
   ========================================================================== */
      PMDSPV_input.media_pointer.exa = inp_io.chan;
      channel                        = out_io.chan;

#ifdef __TRACE__
      fprintf(stderr, "OK !\n");
#endif

   }

/* ==========================================================================
   Close write mode
   ========================================================================== */
   if( ((mode == PMDSIE_FullResolutionMode) && (*image_completed == TRUE)) ||
       ((mode == PMDSIE_QuickLookMode) && 
        ((vol_id == PMDSPD_last_vol) || (vol_id == PMDSPD_single_vol))
       ) ) {
      if(mode != PMDSIE_QuickLookMode)
      {
         TIFSIP_close_line(channel, image, status_code);
         ERRSIM_on_err_goto_exit( *status_code );
      }

/* ==========================================================================
      Close tiff file
   ========================================================================== */
#ifdef __TRACE__
      fprintf(stderr, "Close tiff file.\n");
#endif

      TIFSIP_close_tiff( channel, status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

error_exit:;

   MEMSIP_free( (void **) &imgline );
   for(iitem = 0; iitem < win_height; iitem++)
   {
      MEMSIP_free( (void **) &(win_data[iitem]));
   }
   MEMSIP_free( (void **) &win_data);

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_GenerateTifImage */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_DeformatGrpProdRecord

        $TYPE         PROCEDURE

        $INPUT        curr_rec_size   : record size
                      grp_rec_repeat  : group of record
                      mode            : deformatting mode
                      vol_id          : current volume (tape) id
                      start_row       : starting row
                      start_col       : starting column
                      end_row         : end row
                      end_col         : end column
                      ql_width        : width of the output quick look
                      ql_height       : height of the output quick look
                      win_width       : width of the window to be used
                      win_height      : height of the window to be used
                      tif_ann_file    : tif annotation file name
                      tif_output_file : output tiff file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Deformat a group of record

        $WARNING      NONE
                         
   $EH
   ========================================================================== */
void PMDSPP_DeformatGrpProdRecord
                        (/*IN    */ INTx4                data_size,
                         /*IN    */ PMDSPT_cfg_grp_rec  *grp_rec_ptr,
                         /*IN    */ PMDSIT_deformat_mode mode,
                         /*IN    */ LDEFIT_boolean       is_img,
                         /*IN    */ INTx4                vol_id,
                         /*IN    */ INTx4                start_row,
                         /*IN    */ INTx4                start_col,
                         /*IN    */ INTx4                end_row,
                         /*IN    */ INTx4                end_col,
                         /*IN    */ INTx4                ql_width,
                         /*IN    */ INTx4                ql_height,
                         /*IN    */ UINTx4               win_width,
                         /*IN    */ UINTx4               win_height,
                         /*IN    */ char                *tif_ann_file,
                         /*IN OUT*/ char                *tif_output_file,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx1               out_ima_num,
                         /*IN    */ INTx4                nb_rec_field,
                         /*   OUT*/ LDEFIT_boolean      *image_completed,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_DeformatGrpProdRecord";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i, j;
   PMDSPT_cfg_rec         *cur_rec;
   PMDSPT_cfg_field       *cur_field;
   INTx4                  out_rec_size;
   char                   out_rec_str[100];

   INTx4                  record_num;
   INTx4                  record_skipped;
   INTx4                  record_kept;
   INTx4                  width_skipped;
   INTx4                  width_kept;
   INTx4                  start_pos;
   INTx4                  last_pos;

   INTx4                  prod_image_nb = 0;

   char                   note2[256];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

#ifdef __TRACE__
   printf("Repeating loop of %d iteration(s)\n", grp_rec_ptr->max_repeat);
   printf("Repeating %d record(s)\n", grp_rec_ptr->max_rec);
#endif

/* ==========================================================================
   Check if the record is an IMAGE record
   ========================================================================== */
   if( is_img )
   {
      cur_rec = grp_rec_ptr->cfg_rec[0];

      for (i = 0; i < cur_rec->max_field; i++)
      {

         cur_field = cur_rec->cfg_field[i];

         switch(cur_field->format)
         {
            case 'R' : /* SLC,PRI, GEC, GTC Products */
            case 'r' :
               PMDSPV_prod_data_type = PMDSPE_data_1_unsigned16;
               break;
            case 'V' : /* SLC,PRI, GEC, GTC Products */
            case 'v' :
               PMDSPV_prod_data_type = PMDSPE_data_1_unsigned16_nodec;
               break;
            case 'C' : /* RAW Product */
            case 'c' :
               PMDSPV_prod_data_type = PMDSPE_data_1_signed8;
               break;
            default  : /* Invalid products */
               PMDSPV_prod_data_type = PMDSPE_data_none;
               break;
         }

/* ==========================================================================
         Get data needed by the image deformatting procedure
   ========================================================================== */
         if (PMDSPV_prod_data_type != PMDSPE_data_none)
         {

/* ==========================================================================
               Fill prod_image using the variable
   ========================================================================== */
	    PMDSPV_prod_image.bytes_skip = cur_field->byte_start - 1;

            if( (vol_id == PMDSPD_single_vol) || 
                (vol_id == PMDSPD_first_vol) ) {

#ifdef __TRACE__
               ERRSIM_print_warning( "First volume" );
#endif
   	       PMDSPP_GetVar( "IMG_REC_NO",
			      out_rec_str,
		  	      status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       PMDSPV_prod_image.image_height = atoi(out_rec_str);

	       PMDSPP_GetVar( "SAMPLE_PER_PIX", 
	 		      out_rec_str, 
	 		      status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       PMDSPV_prod_image.sample_per_pix  = atoi( out_rec_str );

	       PMDSPP_GetVar( "BITS_PER_SAMPLE", 
			      out_rec_str, 
			      status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       PMDSPV_prod_image.bits_per_sample = atoi( out_rec_str );

            }

	    PMDSPP_GetVar( "IMG_REC_SZ",
			   out_rec_str,
			   status_code );
	    ERRSIM_on_err_goto_exit( *status_code );

	    out_rec_size = atoi(out_rec_str);

	    PMDSPV_prod_image.bytes_keep =
               out_rec_size - PMDSPV_prod_image.bytes_skip;

	    PMDSPV_prod_image.image_width =
	      (INTx4)(PMDSPV_prod_image.bytes_keep /
	      (INTx4)((PMDSPV_prod_image.sample_per_pix *
	       PMDSPV_prod_image.bits_per_sample) / 8));

/* ==========================================================================
   Get current image start / end line
   ========================================================================== */
            PMDSPP_GetVar( "START_LINE",
                           out_rec_str, 
                           status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            start_pos = atoi( out_rec_str );

            PMDSPP_GetVar( "END_LINE",
                           out_rec_str, 
                           status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            last_pos = atoi( out_rec_str );

            prod_image_nb++;
            break;

         }

      }

/* ==========================================================================
      Get the number of the line as the number of repeat
   ========================================================================== */
      record_num     = grp_rec_ptr->max_repeat;

      if( record_num != (last_pos - start_pos + 1) ) {
         ERRSIM_print_warning( "The number of lines specified as the number of \
repeat is different from START_LINE / END_LINE values" );
         last_pos = record_num + start_pos - 1;
      }

      if( mode == PMDSIE_FullResolutionMode ) {
/* ==========================================================================
      Check if current image volume is outside the request aoi
   ========================================================================== */
         if((start_row < 0) ||
            (start_col < 0) ||
            (end_row >= record_num) ||
            (end_col >= PMDSPV_prod_image.image_width))
         {
            record_skipped = 0;
            record_kept    = last_pos - start_pos + 1;
            width_skipped  = 0;
            width_kept     = PMDSPV_prod_image.image_width;
         }
         else
         {
            record_skipped = start_row;
            record_kept    = end_row - start_row + 1;
            width_skipped  = start_col;
            width_kept     = end_col - start_col + 1;
         }
      }
      else
      {
         record_skipped = 0;
         record_kept    = last_pos - start_pos + 1;
         width_skipped  = 0;
         width_kept     = PMDSPV_prod_image.image_width;
      }
   }

/* ==========================================================================
   Write image
   ========================================================================== */
   if ( (prod_image_nb) &&
        (mode != PMDSIE_HeaderDecodeMode) ) 
   {
      PMDSPP_GenerateTifImage( data_size,
                               mode,
                               record_num,
                               record_skipped,
                               record_kept,
                               width_skipped,
                               width_kept,
                               ql_width,
                               ql_height,
                               win_width,
                               win_height,
                               vol_id,
                               tif_ann_file,    /* annotaion file name */
                               tif_output_file, /* output image file name */
                               inp_ima_num,
                               out_ima_num,
                               image_completed,
                               status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }
   else
   {
      LDEFIT_boolean annotate = TRUE;
      if( (prod_image_nb) && 
          (mode == PMDSIE_HeaderDecodeMode) )
      {
         annotate = FALSE;
      } 

      if( (grp_rec_ptr->max_repeat == 0) && (nb_rec_field > 0) ) {

         strcpy(note2, "--------------------------------------------------");
         strcat(note2, "--------------------------------------------------");
         strcat(note2, "--------------------------------------------------");

         PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                                PMDSPE_ANNF_DataType,
                                NULL,
                                (void*) " *** EMPTY RECORD ***",
                                status_code);
         ERRSIM_on_err_goto_exit( *status_code );

         PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                                PMDSPE_ANNF_DataType,
                                NULL,
                                (void*)note2,
                                status_code);
         ERRSIM_on_err_goto_exit( *status_code );
      }

/* ==========================================================================
      Write group of record to file
   ========================================================================== */
      for (i = 0; i < grp_rec_ptr->max_repeat; i++)
      {
         for (j = 0; j < grp_rec_ptr->max_rec; j++)
         {
            PMDSPP_DeformatProdRecord( data_size,
                                       mode,
                                       grp_rec_ptr->cfg_rec[j],
                                       annotate,
                                       nb_rec_field,
                                       status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_DeformatGrpProdRecord */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_DeformatFile

        $TYPE              PROCEDURE

        $INPUT        cur_prod_file_name  : product file name
                      volume_type         : file extension
                      mode                : deformatting mode
                      fpCfg               : pointer to CFG file
                      vol_id              : current volume (tape) id
                      start_row           : starting row
                      start_col           : starting column
                      end_row             : end row
                      end_col             : end column
                      ql_width            : width of the output quick look
                      ql_height           : height of the output quick look
                      win_width           : width of the window to be used
                      win_height          : height of the window to be used
                      tif_ann_file        : tif annotation file name
                      tif_output_file     : output tiff file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Deformat the product file

        $WARNING      NONE

   $EH
   ========================================================================== */
void PMDSPP_DeformatFile  (/*IN    */ char                *prod_file_name,
                           /*IN    */ UINTx1               inp_ima_num,
                           /*IN    */ UINTx1               out_ima_num,
                           /*IN    */ PMDSPT_volume_type   volume_type,
                           /*IN    */ PMDSIT_deformat_mode mode,
                           /*IN    */ FILE                *fpCfg,
                           /*IN    */ INTx4                vol_id,
                           /*IN    */ INTx4                start_row,
                           /*IN    */ INTx4                start_col,
                           /*IN    */ INTx4                end_row,
                           /*IN    */ INTx4                end_col,
                           /*IN    */ INTx4                ql_width,
                           /*IN    */ INTx4                ql_height,
                           /*IN    */ UINTx4               win_width,
                           /*IN    */ UINTx4               win_height,
                           /*IN    */ char                *tif_ann_file,
                           /*IN OUT*/ char                *tif_output_file,
                           /*   OUT*/ LDEFIT_boolean      *image_completed,
                           /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSPP_DeformatFile";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  ichar;
   INTx4                  curr_rec;
   INTx4                  curr_rec_size;
   INTx4                  nb_rec_field;
   PMDSPT_marker          marker;
   PMDSPT_tmp_buf         marker_val_str;
   PMDSPT_cfg_rec         cfg_rec;
   PMDSPT_cfg_grp_rec     cfg_repeat;

   PMDSPT_parm_value      out_var;
   char                   record_name[256];
   char                   note2[256];
   LDEFIT_boolean         is_img;
   char                  *err_msg = "The product media could not match the format description file";

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Initialize curr_rec counter
   ========================================================================== */
   curr_rec = 0;

   do
   {
/* ==========================================================================
   Seek next marker
   ========================================================================== */
      PMDSPP_SeekNextMarker(  fpCfg,
                             &marker,
                              marker_val_str,
                              status_code );
      ERRSIM_on_err_goto_exit( *status_code );


/* ==========================================================================
   Write annotation file
   ========================================================================== */
      if( (mode == PMDSIE_HeaderDecodeMode) &&
          (marker.type == PMDSPE_mrk_record_begin) )
      {
         strcpy(record_name, marker_val_str);
         for(ichar = (strlen(record_name) - 1); ichar >= 0; ichar--)
         {
            if(record_name[ichar] == '\n')
            {
               record_name[ichar] = '\0';
               break;
            }
         }

         fprintf( stdout, "%s\n", record_name );

         strcpy(note2, "--------------------------------------------------");
         strcat(note2, "--------------------------------------------------");
         strcat(note2, "--------------------------------------------------");

         PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                                PMDSPE_ANNF_DataType,
                                "Record name................: ",
                                (void*)record_name,
                                status_code);
         ERRSIM_on_err_goto_exit( *status_code );

         PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                                PMDSPE_ANNF_HeaderType,
                                NULL,
                                NULL,
                                status_code);
         ERRSIM_on_err_goto_exit( *status_code );

         PMDSIP_ANNF_SetAnnFile(PMDSPE_ANNF_FileNameWrite,
                                PMDSPE_ANNF_DataType,
                                NULL,
                                (void*)note2,
                                status_code);
         ERRSIM_on_err_goto_exit( *status_code );
      }

/* ==========================================================================
   Check found marker
   ========================================================================== */
      if(marker.type == PMDSPE_mrk_file_end)
      {
         /* exit from do-while */
         break;
      }
      if(marker.type == PMDSPE_mrk_skip_next_block_if_more_vol)
      {
         /* ignored */
         continue;
      }

      switch(marker.type)
      {
         case PMDSPE_mrk_assign:
/* ==========================================================================
   Execute simple assignment @VAR = [@VAR|CONST] +/- [@VAR|CONST] +/- ...
   ========================================================================== */
            PMDSPP_EvalAssign( marker_val_str, status_code );
            if( *status_code != STC( ERRSID_normal ) ) {
               ERRSIM_set_error( status_code, ERRSID_PMDS_bad_in_cfg, err_msg );
            }
               
            break;

         case PMDSPE_mrk_record_begin:
/* ==========================================================================
   Set current record
   ========================================================================== */
            curr_rec++;
            PMDSPV_gm.cur_rec_num = curr_rec;

/* ==========================================================================
   Get the record size of current record
   ========================================================================== */
            curr_rec_size = PMDSPF_GetCurrRecordSize( status_code );
            if( *status_code != STC( ERRSID_normal ) ) {
               ERRSIM_set_error( status_code, ERRSID_PMDS_bad_in_cfg, err_msg );
            }

/* ==========================================================================
            Reset the nb_rec_field value
   ========================================================================== */
            nb_rec_field = 0;

/* ==========================================================================
   Get CFG record of current record
   ========================================================================== */
            cfg_rec.max_repeat = 1;
            PMDSPP_ReadCurrRec(fpCfg, &cfg_rec, &nb_rec_field, status_code );
            if( *status_code != STC( ERRSID_normal ) ) {
               ERRSIM_set_error( status_code, ERRSID_PMDS_bad_in_cfg, err_msg );
            }

/* ==========================================================================
   Deformat and write
   ========================================================================== */
            PMDSPP_DeformatProdRecord( curr_rec_size,
                                       mode,
                                      &cfg_rec,
                                       TRUE, /* always annotate */
                                       nb_rec_field,
                                       status_code );
            if( *status_code != STC( ERRSID_normal ) ) {
               ERRSIM_set_error( status_code, ERRSID_PMDS_bad_in_cfg, err_msg );
            }

            if( nb_rec_field == 0 ) {
               PMDSPV_gm.cur_rec_num--;
               curr_rec--;
            }

#ifdef __TRACE__
            printf("\n\n");
#endif

/* ==========================================================================
   Freeze record
   ========================================================================== */
            PMDSPP_FreeRec( &cfg_rec,
                             status_code );
            if( *status_code != STC( ERRSID_normal ) ) {
               ERRSIM_set_error( status_code, ERRSID_PMDS_bad_in_cfg, err_msg );
            }

            break;

         case PMDSPE_mrk_repeat_begin:
         case PMDSPE_mrk_img_begin:

/* ==========================================================================
   Set current record
   ========================================================================== */
            curr_rec++;
            PMDSPV_gm.cur_rec_num = curr_rec;

/* ==========================================================================
   Get the max cicle
   ========================================================================== */
            if (marker_val_str[0] == '@')
            {
               char *new_line;
/* ==========================================================================
   ... from a variable   
   ========================================================================== */
               marker_val_str[ strlen( marker_val_str ) -1 ] = '\0';
               if( (new_line = strchr( marker_val_str, '\n' )) != ((char *) NULL))
               {
                  *new_line = '\0';
               }

               PMDSPP_GetVar(marker_val_str+1, out_var, status_code );
               if( *status_code != STC( ERRSID_normal ) ) {
                  ERRSIM_set_error( status_code, ERRSID_PMDS_bad_in_cfg, err_msg );
               }

               cfg_repeat.max_repeat = atoi(out_var);
            } 
            else
            {
/* ==========================================================================
   ... as written
   ========================================================================== */
               cfg_repeat.max_repeat = atoi(marker_val_str);
            }
 
/* ==========================================================================
            Reset the nb_rec_field value
   ========================================================================== */
            nb_rec_field = 0;

/* ==========================================================================
   Get the repeat records
   ========================================================================== */
            PMDSPP_ReadCurrRepeat( fpCfg, 
                                   mode, 
                                  &cfg_repeat, 
                                  &nb_rec_field, 
                                   status_code );
            if( *status_code != STC( ERRSID_normal ) ) {
               ERRSIM_set_error( status_code, ERRSID_PMDS_bad_in_cfg, err_msg );
            }

/* ==========================================================================
   The repeat has a negative number: the record does not exists!
   ========================================================================== */
            if( (cfg_repeat.max_repeat <= 0) || (nb_rec_field == 0) ) {
               PMDSPV_gm.cur_rec_num--;
               curr_rec--;
            }
            else {
/* ==========================================================================
   Get the record size of current record
   ========================================================================== */
               curr_rec_size = PMDSPF_GetCurrRecordSize( status_code );
               if( *status_code != STC( ERRSID_normal ) ) {
                  ERRSIM_set_error( status_code, ERRSID_PMDS_bad_in_cfg, err_msg );
               }
            }

/* ==========================================================================
   Set is_img flag
   ========================================================================== */
            is_img = FALSE;
            if( marker.type == PMDSPE_mrk_img_begin ) {
               is_img = TRUE;
/* ==========================================================================
   Set the computation target value
   ========================================================================== */
               SRVSIP_set_comp( 
                  (INTx4) cfg_repeat.max_rec*cfg_repeat.max_repeat, 
                  &log_status_code );
            }

/* ==========================================================================
   Deformat the repeat records
   ========================================================================== */
            PMDSPP_DeformatGrpProdRecord( curr_rec_size,
                                         &cfg_repeat,
                                          mode,
                                          is_img,
                                          vol_id,
                                          start_row,
                                          start_col,
                                          end_row,
                                          end_col,
                                          ql_width,
                                          ql_height,
                                          win_width,
                                          win_height,
                                          tif_ann_file,
                                          tif_output_file,
                                          inp_ima_num,
                                          out_ima_num,
                                          nb_rec_field,
                                          image_completed,
                                          status_code );
            if( *status_code != STC( ERRSID_normal ) ) {
               ERRSIM_set_error( status_code, ERRSID_PMDS_bad_in_cfg, err_msg );
            }

/* ==========================================================================
   Freeze the repeat record
   ========================================================================== */
            PMDSPP_FreeGrpRec(&cfg_repeat, status_code );
            if( *status_code != STC( ERRSID_normal ) ) {
               ERRSIM_set_error( status_code, ERRSID_PMDS_bad_in_cfg, err_msg );
            }

            break;
      }

   } while( TRUE );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSPP_DeformatFile */
