/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_EUND

      $FUNCTION          ERMAPPER Interface for IMAGE SPECKLE FILTERING

      $ROUTINE           stbx_speckle_init
                         stbx_speckle
                         stbx_speckle_final

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       25-FEB-98     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include FIIS_INTF_H
#include SPKF_INTF_H
#include STBX_INTF_H
#include STBX_PGLB_H

#if defined(__WIN95__) && defined(__CODEWARRIOR__)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

/* ==========================================================================
                      STATIC VARIABLE DECLARATION SECTION
   ========================================================================== */
static float         **InpWin;
static float           look_no;
static UINTx4          Kr, Kc;
static LDEFIT_boolean  error;
static SPKFIT_mask    *mask = (SPKFIT_mask *) NULL;
static UINTx4          mask_no = 0;

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_speckle_init

        $TYPE         PROCEDURE

        $INPUT        nr_rows            : row size of filtering
                      nr_cols            : column size of filtering
                      user_code_params   : additional parameters

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This is the SPECKLE FILTER initialisation function for the
                      ERMAPPER interface. It is called once before any 
                      processing is done.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
EXPORT void stbx_speckle_init
                        (/*IN    */ int                  nr_rows,
                         /*IN    */ int                  nr_cols,
                         /*IN    */ char                *user_code_params )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_SPKF";
#else
   const ERRSIT_proc_class proc_class   = "spkf";
#endif
   const ERRSIT_proc_name routine_name = "stbx_speckle_init";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   FILSIT_file_name       ini_file;
   FILSIT_file_name       maskFileName;
   float                  pfa;
   float                  line_th, edge_th, scatter_th;
   char                 **section_name = (char **) NULL;
   UINTx4                 section_no;
   STBXPT_task            task;
   UINTx4                 i, ipar;
   INTx4                  edge_th_parnum, line_th_parnum, 
                          look_no_parnum, mask_file_parnum;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class,
                              &log_status_code );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_speckle_filtering_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );

/* ==========================================================================
   Get ini file
   ========================================================================== */
   if( sscanf( user_code_params, "%s",  ini_file ) == 0 ) {
      ERRSIM_set_error( &status_code, ERRSID_STBX_parm_not_defined,
                         "ini file name" );
   }

/* ==========================================================================
   Extract from INI file all the section included
   ========================================================================== */
   FIISIP_GETS_get_sections(  ini_file,
                             &section_no,
                             &section_name,
                             &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Call the appropriate task procedure corresponding to the first section 
   contained in the INI file, checking if the task name is one of this tool
   ========================================================================== */
   if( strcmp( section_name[ 0 ], STBXPD_speckle_filter ) ) {
      ERRSIM_set_error( &status_code,
                         ERRSID_STBX_section_invalid,
                         section_name[ 0 ] );
   }

/* ==========================================================================
   Init input parameters and global vars corresponding to, if any 
   ========================================================================== */
   look_no = 0.0;
   edge_th = 0.0;
   line_th = 0.0;
   sprintf( maskFileName, "" );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, STBXPD_speckle_filter );
   task.parmNo = 6;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( &status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_mask_file_name );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( maskFileName );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) maskFileName;
   mask_file_parnum = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_pfa );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &pfa;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_look_no );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &look_no;
   look_no_parnum = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_edge_threshold );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &edge_th;
   edge_th_parnum = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_line_threshold );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &line_th;
   line_th_parnum = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_scatter_threshold );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &scatter_th;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( ipar=0; ipar<task.parmNo; ipar++ ) {
      FIISIP_GETS_get_info( ini_file,
                            task.name,
                            (UINTx4) 1, /* first section */
                           &(task.parm[ ipar ]),
                           &status_code );
      ERRSIM_on_err_goto_exit( status_code );
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( ipar=0; ipar<task.parmNo; ipar++ ) {
      if( ( !task.parm[ ipar ].founded ) && ( task.parm[ ipar ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ ipar ].name);
#endif
         ERRSIM_set_error( &status_code,
                            ERRSID_STBX_parm_not_defined,
                            task.parm[ ipar ].name );
      }
   }

/* ==========================================================================
   Check input thresholds
   ========================================================================== */
   if( (task.parm[ mask_file_parnum ].founded == TRUE) &&
       ( (task.parm[ edge_th_parnum ].founded == FALSE) ||
         (task.parm[ line_th_parnum ].founded == FALSE) ) ) {
      ERRSIM_set_error( &status_code, ERRSID_STBX_parm_invalid,
         "Edge and line threshold mandatory for a user mask file");
   }

   if( (task.parm[ edge_th_parnum ].founded == TRUE) &&
       ( edge_th == 0.0 ) ) {
      ERRSIM_set_error( &status_code, 
                         ERRSID_STBX_parm_invalid,
                         STBXPD_edge_threshold );
   }
   if( (task.parm[ line_th_parnum ].founded == TRUE) &&
       ( line_th == 0.0 ) ) {
      ERRSIM_set_error( &status_code, 
                         ERRSID_STBX_parm_invalid,
                         STBXPD_line_threshold );
   }
   if( scatter_th == 0.0 ) {
      ERRSIM_set_error( &status_code, 
                         ERRSID_STBX_parm_invalid,
                         STBXPD_scatter_threshold );
   }

/* ==========================================================================
   Set Kr and Kc
   ========================================================================== */
   Kr = (UINTx4) nr_rows;
   Kc = (UINTx4) nr_cols;

/* ==========================================================================
   Allocate InpWin
   ========================================================================== */
   if ( ( InpWin = (float **)MEMSIP_alloc(
	      (size_t)( Kr * sizeof(float *)) ) ) == (float **)NULL ) {
      ERRSIM_set_error( &status_code, ERRSID_STBX_err_mem_alloc, "InpWin" );
   }


   for ( i=0; i<Kr; i++ ) {
      InpWin[ i ] = (float *) NULL;
      if ( ( InpWin[ i ] = (float *)MEMSIP_alloc(
              (size_t)( Kc * sizeof(float) ) ) ) == (float *)NULL ) {
         ERRSIM_set_error( &status_code, ERRSID_STBX_err_mem_alloc, "InpWin" );
      }
   }

/* ==========================================================================
   Set a global var for the mask file in order to open in the SPKFPP_core
   ========================================================================== */
   strcpy( SPKFIV_mask_file, maskFileName );

/* ==========================================================================
   Set global vars for edge line and scatter threshold
   ========================================================================== */
   SPKFIV_edge_th    = edge_th;
   SPKFIV_line_th    = line_th;
   SPKFIV_scatter_th = scatter_th;

/* ==========================================================================
   Load mask
   ========================================================================== */
   SPKFIP_load_masks(  InpWin, LDEFIE_dt_float, Kr, Kc,
                      &mask_no, &mask, &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Set mask thresholds
   ========================================================================== */
   SPKFIP_mask_set_thresh(  mask_no, mask, pfa, Kr, Kc, look_no,
                           &status_code );
   ERRSIM_on_err_goto_exit( status_code );

error_exit:;

/* ==========================================================================
   Freeze memory
   ========================================================================== */
   if( section_name != (char **) NULL )
   {
      for( i = 0; i < section_no; i++ )
      {
         MEMSIP_free( (void **) &(section_name[ i ]) );
      }
      MEMSIP_free( (void **) &section_name );
   }
   MEMSIP_free( (void **) &task.parm );


   if( status_code != STC( ERRSID_normal ) ) {
      error = TRUE;
   }
   else {
      error = FALSE;
   }

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

}/* stbx_speckle_init */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_speckle

        $TYPE         PROCEDURE

        $INPUT        nr_rows            : row size of filtering
                      nr_cols            : column size of filtering
                      array              : matrix of image pixels

        $MODIFIED     NONE

        $OUTPUT       out_value          : computed image value

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This is the SPECKLE FILTER processing function for the
                      ERMAPPER interface. It is called once for each output 
                      value.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
EXPORT double stbx_speckle
                        (/*IN    */ int                  nr_rows,
                         /*IN    */ int                  nr_cols,
                         /*IN    */ double             **array )
{
   const ERRSIT_proc_name routine_name = "stbx_speckle";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double                 out_value;
   float                  tmp_float;
   UINTx1                 tmp_uintx1;
   UINTx4                 i, j;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check if not error in stbx_speckle_init
   ========================================================================== */
   if( error == FALSE ) {

/* ==========================================================================
      Copy current mask into InpWin
   ========================================================================== */
      for( i=0; i<Kr; i++ ) {
         for( j=0; j<Kc; j++ ) {
            InpWin[ i ][ j ] = (float) array[ i ][ j ];
         }
      }

/* ==========================================================================
      Select the mask
   ========================================================================== */
      SPKFIP_AUTO_select_mask(  InpWin, Kr, Kc,
                                mask_no, mask, look_no,
                               &tmp_float,
#ifdef __TRACE__
                               &tmp_uintx1,
#endif
                               &status_code );
      ERRSIM_on_err_goto_exit( status_code );

      out_value = (double) tmp_float;
   }
   else {
      out_value = array[ nr_rows/2 ][ nr_cols/2 ];
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   return( out_value );

}/* stbx_speckle */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_speckle_final

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This is the SPECKLE FILTER finalisation function for the
                      ERMAPPER interface. It is called after all processing 
                      has been done.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
EXPORT void stbx_speckle_final
                        ( void )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_SPKF";
#else
   const ERRSIT_proc_class proc_class   = "spkf";
#endif
   const ERRSIT_proc_name routine_name = "stbx_speckle_final";
   ERRSIT_status          log_status_code;
   ERRSIT_status          status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code     = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Free variables of AUTOMA
   ========================================================================== */
   SPKFIP_AUTO_free( &log_status_code );

error_exit:;

/* ==========================================================================
   Free InpWin
   ========================================================================== */
   if( InpWin != (float **) NULL ) {
      for ( i=0; i<Kr; i++ ) {
         MEMSIP_free( (void **) &(InpWin[ i ]) );
      }
      MEMSIP_free( (void **) &InpWin );
   }

/* ==========================================================================
   Free mask of SPKFIP_load_masks
   ========================================================================== */
   for( i=0; i<mask_no; i++ ) {
      switch( mask[ i ].type ) {
 
         case SPKFIE_mt_all:
            MEMSIP_free( (void **) &(mask[ i ].val.all.vect) );
            break;
         case SPKFIE_mt_scatter:
            MEMSIP_free( (void **) &(mask[ i ].val.scatter.clutter) );
            MEMSIP_free( (void **) &(mask[ i ].val.scatter.buffer) );
            MEMSIP_free( (void **) &(mask[ i ].val.scatter.mailobe) );
            break;
         case SPKFIE_mt_edgline:
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.edge1) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.edge2) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.buff1) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.buff2) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.line) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.edgbuff1) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.edgbuff2) );
            break;
      }
   }
   MEMSIP_free( (void **) &mask );



   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          status_code,
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class,
                                  &log_status_code );

}/* stbx_speckle_final */
