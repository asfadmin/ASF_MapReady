/* ==========================================================================
   $MODULE_HEADER

      $NAME              LDEF_IDMP

      $FUNCTION          Dump the struct defined in LDEF_INTF.H

      $ROUTINE           LDEF_IDMP_tree_node

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       03-jun-93     AD       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <string.h>
#include <stdio.h>

#include "defl_libname_intf.h"
#include ERRS_INTF_H
#include LDEF_INTF_H

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEF_IDMP_tree_node

        $DESCRIPTION  Dump the LDEFIT_tree_node struct.

        $TYPE         Procedure

        $INPUT        var_string                : variable name
                      variable                  : Variable to dump
                      verbose                   : Verbose flag
                      ind                       : Indentation level

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void LDEFIP_IDMP_tree_node
                       ( /*IN    */ char               *var_string,
                         /*IN    */ LDEFIT_tree_node   *variable,
                         /*IN    */ LDEFIT_boolean      verbose,
                         /*IN    */ INTx4               ind )
{
   ERRSIT_status log_status_code;
   char temp_str[512];
   char ind_str[512];

   memset( ind_str, ' ', sizeof( ind_str ));
   ind_str[ind] = '\0';

   sprintf( temp_str,
            "%s%s : left = %u ",
            ind_str,
            var_string,
            variable->left );
   ERRSIP_HPEL_trace_proc_err_log(  temp_str,
                                   &log_status_code );

   sprintf( temp_str,
            "%s%s : right = %u ",
            ind_str,
            var_string,
            variable->right );
   ERRSIP_HPEL_trace_proc_err_log(  temp_str,
                                   &log_status_code );

   sprintf( temp_str,
            "%s%s : key = %f ",
            ind_str,
            var_string,
            variable->key );
   ERRSIP_HPEL_trace_proc_err_log(  temp_str,
                                   &log_status_code );

   sprintf( temp_str,
            "%s%s : record = %u ",
            ind_str,
            var_string,
            variable->record );
   ERRSIP_HPEL_trace_proc_err_log(  temp_str,
                                   &log_status_code );
}/* LDEF_IDMP_tree_node */

