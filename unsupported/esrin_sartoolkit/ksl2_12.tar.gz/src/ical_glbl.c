/* ==========================================================================
   $MODULE_HEADER

      $NAME          ICAL_GLBL

      $FUNCTION      Global variable intf

      $ROUTINE       NONE

      $HISTORY

            SCR NO.      DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       14-MAR-98     AG       Initial Release

    $EH
   ========================================================================== */


/* ==========================================================================
                          INCLUDE DECLARATION SECTION
   ========================================================================== */
#define ICAL_GLBL ICAL_GLBL

#include "defl_libname_intf.h"
#include ICAL_INTF_H
#include ICAL_PGLB_H

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME             ICALPF_GLBL_set_error;

      $FUNCTION         Return global error from the package error. On first 
			call the package message array is registered.

      $INPUT            local_status_code    : local package status code.

      $MODIFIED         NONE

      $OUTPUT           Global status code. 

      $GLOBAL           NONE

      $RET_STATUS       NONE

      $DESCRIPTION      Return global error from the package error. On first
                        call the package message array is registered.

      $WARNING          NONE


   ========================================================================== */
INTx4 ICALPF_GLBL_set_error( /*IN    */ ERRSIT_status  local_status_code )
{
   INTx4                       out_package_code;
   static INTx4                package_code =  -1;

   if( package_code == -1 )
   {
      package_code = ERRSIF_HMSG_register_error_msgs
                                                ( ICALIV_ERRS_error_message );
   }

   if ( local_status_code > ERRSID_error )
   {
      out_package_code = package_code + local_status_code;
   }
   else
   {
      out_package_code = local_status_code;
   }

error_exit:;

   return out_package_code;
}

