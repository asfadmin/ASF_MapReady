/* ==========================================================================
   $MODULE_HEADER

      $NAME              ICAL_IMAG

      $FUNCTION          Image Calibration task routine

      $ROUTINE           ICALIP_IMAG_backscattering
                         ICALIP_IMAG_gamma
                         ICALIP_IMAG_adc_saturation

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       18-MAR-98     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include SRVS_INTF_H
#include FILS_INTF_H
#include GIOS_INTF_H
#include IANN_INTF_H
#include ICAL_INTF_H
#include ICAL_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALIP_IMAG_backscattering

        $TYPE         PROCEDURE

        $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                      inp_ima_num
                                : number identifing the image inside the tool
                      TLRow     : the row image coordinate in the full
                                  reference frame of the image
                      TLCol     : the column image coordinate in the full
                                  reference frame of the image
                      nrow_inp  : number of rows of the image
                      ncol_inp  : number of columns of the images
                      ant_patt_lut_direct
                                : LUT direction of antenna pattern
                      antenna_pattern_file
                                : antenna pattern file name
                      use_antenna_patt_file
                               : TRUE if antenna_pattern_file has to be used
                      ran_spre_loss_lut_direct
                                : LUT direction of range spreading loss
                      calib_const_lut_direct
                                : LUT direction of calibration constant
                      in_calib_const
                                : user defined calibration constant
                      use_calib_const
                                : TRUE if this value override the annotation
                      replica_power_lut_direct
                                : LUT direction of replica power
                      ref_replica_power
                                : reference replica power
                      ref_chirp_average
                                : reference chirp average
                      adc_lut_direction
                                : LUT direction of ADC
                      adc_io    : structure with the IO basic parameters of the
                                  LUT file 
                      adc_ima_num
                                : number identifing the ADC image inside the tool
                      out_io    : structure with the IO basic parameters of the
                                  output image
                      out_ima_scale
                                : scale type of output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine drives the creation of the BACKSCATTERING
                      calibrated image

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void ICALIP_IMAG_backscattering
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ ICALIT_lut_direct    ant_patt_lut_direct,
                         /*IN    */ char                *antenna_pattern_file,
                         /*IN    */ LDEFIT_boolean       use_antenna_patt_file,
                         /*IN    */ ICALIT_lut_direct    ran_spre_loss_lut_direct,
                         /*IN    */ ICALIT_lut_direct    calib_const_lut_direct,
                         /*IN    */ float                in_calib_const,
                         /*IN    */ LDEFIT_boolean       use_calib_const,
                         /*IN    */ ICALIT_lut_direct    replica_power_lut_direct,
                         /*IN    */ float               *ref_replica_power,
                         /*IN    */ float               *ref_chirp_average,
                         /*IN    */ ICALIT_lut_direct    adc_lut_direction,
                         /*IN    */ GIOSIT_io           *adc_io,
                         /*IN    */ UINTx1               adc_ima_num,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ IANNIT_ImageScale    out_ima_scale,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALIP_IMAG_backscattering";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task variables
   ========================================================================== */
   float                  *look_angle = (float *) NULL;
   float                  *incidence_angle = (float *) NULL;
   float                  *slant_range = (float *) NULL;

   double                 *antenna_pattern_lut;
   FILSIT_file_name        antenna_pattern;
   float                   in_boresight_angle = 0.0;
   LDEFIT_boolean          use_bore_angle = FALSE;
   
   double                 *range_spread_loss_lut;
   float                   in_ref_slant_range = 0.0;
   LDEFIT_boolean          use_ref_sl = FALSE;

   double                 *calib_const_lut;
   float                   ref_incid_angle = 23.0;

   double                 *replica_power_lut;
   float                   replica_power_value;
   float                   chirp_average_value;
   double                 *backscattering_lut;
   UINTx4                  i;
   INTx4                   target;
#ifdef __TRACE__
   FILE                   *fp;
   INTx4                   bytes_written;
   FILSIT_file_name        file_name;
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check limits for ADC Lut image
   ========================================================================== */
   if( adc_lut_direction == ICALIE_lut_apply ) {

      UINTx4     full_nrow_inp, full_ncol_inp;
      UINTx4     full_tlrow, full_tlcol, full_brcol, full_brrow;
      UINTx4     full_adc_nrow, full_adc_ncol;
      UINTx4     full_adc_tlrow, full_adc_tlcol, full_adc_brcol, full_adc_brrow;
      UINTx4     adc_subimagetopleftrow, adc_subimagetopleftcol;
   
      if( strcmp( IANNIV_ImageAnnot[ inp_ima_num ].SceneReferenceNumbers,
                  IANNIV_ImageAnnot[ adc_ima_num ].SceneReferenceNumbers) ) {
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut, 
            "scene is not the same" );
      }

      full_tlcol = (UINTx4)
         ROUND( ((float) TLCol / 
                 IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor) ) +
         IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol;

      full_brcol =  (UINTx4)
         ROUND( ((float) (TLCol + ncol_inp - 1) /
                 IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor) ) + 
         IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol;

      full_ncol_inp = full_brcol - full_tlcol + 1;

      full_tlrow = (UINTx4)
         ROUND( ((float) TLRow / 
                 IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor) ) +
         IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow;

      full_brrow =  (UINTx4)
         ROUND( ((float) (TLRow + nrow_inp - 1) /
                 IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor) ) + 
         IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow;

      full_nrow_inp = full_brrow - full_tlrow + 1;

#ifdef __TRACE1__
      fprintf( stderr, "full_tlrow=%0d full_brrow=%0d\n", 
         full_tlrow, full_brrow );
      fprintf( stderr, "full_tlcol=%0d full_brcol=%0d\n", 
         full_tlcol, full_brcol );
      fprintf( stderr, "full_nrow_inp=%0d full_ncol_inp=%0d\n",
         full_nrow_inp, full_ncol_inp );
#endif

      adc_subimagetopleftcol = 
         IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol -
         IANNIV_ImageAnnot[ adc_ima_num ].ColTransient;

      full_adc_tlcol = (UINTx4)
         ROUND( ((float) 0 / 
                 IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) ) +
         adc_subimagetopleftcol;

      full_adc_brcol =  (UINTx4)
         ROUND( ((float) (IANNIV_ImageAnnot[ adc_ima_num ].ImageWidth - 1) /
                 IANNIV_ImageAnnot[ adc_ima_num ].XScalingFactor) ) + 
         IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftCol +
         IANNIV_ImageAnnot[ adc_ima_num ].ColTransient -
         1;

      full_adc_ncol = full_adc_brcol - full_adc_tlcol + 1;

      adc_subimagetopleftrow =
         IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftRow -
         IANNIV_ImageAnnot[ adc_ima_num ].RowTransient;

      full_adc_tlrow = (UINTx4)
         ROUND( ((float) 0 / 
                 IANNIV_ImageAnnot[ adc_ima_num ].YScalingFactor) ) +
         adc_subimagetopleftrow;

      full_adc_brrow =  (UINTx4)
         ROUND( ((float) (IANNIV_ImageAnnot[ adc_ima_num ].ImageLength - 1) /
                 IANNIV_ImageAnnot[ adc_ima_num ].YScalingFactor) ) + 
         IANNIV_ImageAnnot[ adc_ima_num ].SubImageTopLeftRow +
         IANNIV_ImageAnnot[ adc_ima_num ].RowTransient -
         1;

      full_adc_nrow = full_adc_brrow - full_adc_tlrow + 1;

#ifdef __TRACE1__
      fprintf( stderr, "full_adc_tlrow=%0d full_adc_brrow=%0d\n", 
         full_adc_tlrow, full_adc_brrow );
      fprintf( stderr, "full_adc_tlcol=%0d full_adc_brcol=%0d\n", 
         full_adc_tlcol, full_adc_brcol );
      fprintf( stderr, "full_adc_nrow=%0d full_adc_ncol=%0d\n",
         full_adc_nrow, full_adc_ncol );
#endif

      if( (full_tlrow < adc_subimagetopleftrow) ||
          (full_tlcol < adc_subimagetopleftcol) ||
          ( (full_tlrow + full_nrow_inp) > 
            (adc_subimagetopleftrow + full_adc_nrow) ) ||
          ( (full_tlcol + full_ncol_inp) > 
            (adc_subimagetopleftcol + full_adc_ncol) ) ) {
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_adc_lut, 
            "coorners coordinates outside the ADC compensation image" );
      }

   }

/* ==========================================================================
   Check for existence of antenna pattern file
   ========================================================================== */
   if( ant_patt_lut_direct != ICALIE_lut_none ) {
      GIOSIT_io              pat_io;

      if( use_antenna_patt_file ) {
         sprintf( antenna_pattern, "%s%s", LDEFIV_inp_dir, antenna_pattern_file );
      }
      else {
         switch( IANNIV_ImageAnnot[ inp_ima_num ].ProductType ) {
            case IANNIE_prod_ERS1_RAW:
            case IANNIE_prod_ERS1_SLC:
            case IANNIE_prod_ERS1_SLCI:
            case IANNIE_prod_ERS1_PRI:
            case IANNIE_prod_ERS1_GEC:
            case IANNIE_prod_ERS1_GTC:
               sprintf( antenna_pattern, "%s%s", LDEFIV_cfg_dir, "apers1.SDf" );
               break;

            case IANNIE_prod_ERS2_RAW:
            case IANNIE_prod_ERS2_SLC:
            case IANNIE_prod_ERS2_SLCI:
            case IANNIE_prod_ERS2_PRI:
            case IANNIE_prod_ERS2_GEC:
            case IANNIE_prod_ERS2_GTC:
               sprintf( antenna_pattern, "%s%s", LDEFIV_cfg_dir, "apers2.SDf" );
               break;
         }         
      }

/* ==========================================================================
   Open input TIFF antenna pattern file to check for existence
   ========================================================================== */
      pat_io.type = GIOSIE_tif;
      pat_io.mode = 'r';
      strcpy( pat_io.val.tif.name, antenna_pattern );
      pat_io.img = 0;
      GIOSIP_open_io( &pat_io,
                       status_code);
      ERRSIM_on_err_goto_exit( *status_code );

   }
  
/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   target = 0;
   if( (ant_patt_lut_direct != ICALIE_lut_none) ||
       (ran_spre_loss_lut_direct != ICALIE_lut_none) ||
       (calib_const_lut_direct != ICALIE_lut_none) ) {
/* ==========================================================================
   ... for range and slante angle evaluation   
   ========================================================================== */
      target += (INTx4) ncol_inp;
   }
/* ==========================================================================
   ... for LUT pass   
   ========================================================================== */
   target += nrow_inp;

   SRVSIP_set_comp( (INTx4) target, &log_status_code );

/* ==========================================================================
   Call look_angle, incidence_angle and slant_range computation
   ========================================================================== */
   if( (ant_patt_lut_direct != ICALIE_lut_none) ||
       (ran_spre_loss_lut_direct != ICALIE_lut_none) ||
       (calib_const_lut_direct != ICALIE_lut_none) ) {

      ICALPP_COMP_info( inp_ima_num, TLRow, TLCol, nrow_inp, ncol_inp,
		       &look_angle, &incidence_angle, &slant_range,
			status_code);
      ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
      sprintf( file_name, "%s%s", LDEFIV_temp_dir, "look.raw");
      FILSIP_open( file_name, "wb", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      
      bytes_written = FILSIF_write( fp, sizeof(float)*ncol_inp, 
                         (void *) look_angle, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( bytes_written < (sizeof(float)*ncol_inp) ) {
         ERRSIM_set_error( status_code, ERRSID_error,
            "Error writing look.raw file" );
      }
      FILSIP_close( &fp, &log_status_code );

      sprintf( file_name, "%s%s", LDEFIV_temp_dir, "incid.raw");
      FILSIP_open( file_name, "wb", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      
      bytes_written = FILSIF_write( fp, sizeof(float)*ncol_inp, 
                         (void *) incidence_angle, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( bytes_written < (sizeof(float)*ncol_inp) ) {
         ERRSIM_set_error( status_code, ERRSID_error,
            "Error writing look.raw file" );
      }
      FILSIP_close( &fp, &log_status_code );

      sprintf( file_name, "%s%s", LDEFIV_temp_dir, "slant.raw");
      FILSIP_open( file_name, "wb", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      
      bytes_written = FILSIF_write( fp, sizeof(float)*ncol_inp, 
                         (void *) slant_range, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( bytes_written < (sizeof(float)*ncol_inp) ) {
         ERRSIM_set_error( status_code, ERRSID_error,
            "Error writing look.raw file" );
      }
      FILSIP_close( &fp, &log_status_code );

#endif

   }

/* ==========================================================================
   Allocate antenna_pattern_lut
   ========================================================================== */
   if( ( antenna_pattern_lut = 
           (double *) MEMSIP_alloc( (size_t) ncol_inp * sizeof(double) ) ) ==
       (double *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc,
         "antenna_pattern_lut" );
   }

/* ==========================================================================
   Init the antenna_pattern_lut to 1.0
   ========================================================================== */
   for( i=0; i<ncol_inp; i++ ) {
      antenna_pattern_lut[ i ] = 1.0;
   }

/* ==========================================================================
   Compute antenna pattern lut
   ========================================================================== */
   if( ant_patt_lut_direct != ICALIE_lut_none ) {

/* ==========================================================================
   Generate the antenna pattern correction LUT
   ========================================================================== */
      ICALPP_GLUT_antenna_pattern(  look_angle, ncol_inp, in_boresight_angle, 
                                    use_bore_angle, inp_ima_num, antenna_pattern,
                                    ant_patt_lut_direct, antenna_pattern_lut, 
                                    status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

#ifdef __TRACE__
   sprintf( file_name, "%s%s", LDEFIV_temp_dir, "aplut.raw");
   FILSIP_open( file_name, "wb", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   
   bytes_written = FILSIF_write( fp, sizeof(double)*ncol_inp, 
		      (void *) antenna_pattern_lut, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( bytes_written < (sizeof(double)*ncol_inp) ) {
      ERRSIM_set_error( status_code, ERRSID_error,
	 "Error writing look.raw file" );
   }
   FILSIP_close( &fp, &log_status_code );
#endif

/* ==========================================================================
   Allocate range_spread_loss_lut
   ========================================================================== */
   if( ( range_spread_loss_lut = 
           (double *) MEMSIP_alloc( (size_t) ncol_inp * sizeof(double) ) ) ==
       (double *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc,
         "range_spread_loss_lut" );
   }

/* ==========================================================================
   Init the range_spread_loss_lut to 1.0
   ========================================================================== */
   for( i=0; i<ncol_inp; i++ ) {
      range_spread_loss_lut[ i ] = 1.0;
   }

   if( ran_spre_loss_lut_direct != ICALIE_lut_none ) {

/* ==========================================================================
   Generate the range spreading loss compensation LUT
   ========================================================================== */
      ICALPP_GLUT_range_spread_loss( slant_range, ncol_inp, 0.0, FALSE, 
                                     inp_ima_num, ran_spre_loss_lut_direct, 
                                     range_spread_loss_lut, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

   }

#ifdef __TRACE__
   sprintf( file_name, "%s%s", LDEFIV_temp_dir, "rsllut.raw");
   FILSIP_open( file_name, "wb", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   
   bytes_written = FILSIF_write( fp, sizeof(double)*ncol_inp, 
		      (void *) range_spread_loss_lut, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( bytes_written < (sizeof(double)*ncol_inp) ) {
      ERRSIM_set_error( status_code, ERRSID_error,
	 "Error writing look.raw file" );
   }
   FILSIP_close( &fp, &log_status_code );
#endif

/* ==========================================================================
   Allocate calib_const_lut
   ========================================================================== */
   if( ( calib_const_lut = 
           (double *) MEMSIP_alloc( (size_t) ncol_inp * sizeof(double) ) ) ==
       (double *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc,
         "calib_const_lut" );
   }

/* ==========================================================================
   Init the calib_const_lut to 1.0
   ========================================================================== */
   for( i=0; i<ncol_inp; i++ ) {
      calib_const_lut[ i ] = 1.0;
   }

   if( calib_const_lut_direct != ICALIE_lut_none ) {

/* ==========================================================================
   Generate the calibration constant compensation LUT
   ========================================================================== */
      ICALPP_GLUT_calib_const( incidence_angle, ncol_inp, 23.0, 0.0, FALSE,
                               inp_ima_num, calib_const_lut_direct, 
                               calib_const_lut, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

   }

#ifdef __TRACE__
   sprintf( file_name, "%s%s", LDEFIV_temp_dir, "cclut.raw");
   FILSIP_open( file_name, "wb", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   
   bytes_written = FILSIF_write( fp, sizeof(double)*ncol_inp, 
		      (void *) calib_const_lut, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( bytes_written < (sizeof(double)*ncol_inp) ) {
      ERRSIM_set_error( status_code, ERRSID_error,
	 "Error writing look.raw file" );
   }
   FILSIP_close( &fp, &log_status_code );
#endif

/* ==========================================================================
   Allocate replica_power_lut
   ========================================================================== */
   if( ( replica_power_lut = 
           (double *) MEMSIP_alloc( (size_t) ncol_inp * sizeof(double) ) ) ==
       (double *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc,
         "replica_power_lut" );
   }

/* ==========================================================================
   Init the replica_power_lut to 1.0
   ========================================================================== */
   for( i=0; i<ncol_inp; i++ ) {
      replica_power_lut[ i ] = 1.0;
   }

   if( replica_power_lut_direct != ICALIE_lut_none ) {

/* ==========================================================================
   Select ERS1 or ERS2 Reference Replica Power and Chirp Average Density value
   ========================================================================== */
      switch( IANNIV_ImageAnnot[ inp_ima_num ].ProductType ) {
         case IANNIE_prod_ERS1_RAW:
         case IANNIE_prod_ERS1_SLC:
         case IANNIE_prod_ERS1_SLCI:
         case IANNIE_prod_ERS1_PRI:
         case IANNIE_prod_ERS1_GEC:
         case IANNIE_prod_ERS1_GTC:
            replica_power_value = ref_replica_power[ 0 ];
            chirp_average_value = ref_chirp_average[ 0 ];
            break;

         case IANNIE_prod_ERS2_RAW:
         case IANNIE_prod_ERS2_SLC:
         case IANNIE_prod_ERS2_SLCI:
         case IANNIE_prod_ERS2_PRI:
         case IANNIE_prod_ERS2_GEC:
         case IANNIE_prod_ERS2_GTC:
            replica_power_value = ref_replica_power[ 1 ];
            chirp_average_value = ref_chirp_average[ 1 ];
            break;

      }

/* ==========================================================================
   Generate the replica power compensation LUT
   ========================================================================== */
      ICALPP_GLUT_replica_power( replica_power_value, chirp_average_value,
                                 ncol_inp, inp_ima_num, replica_power_lut_direct, 
                                 replica_power_lut, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

   }

#ifdef __TRACE__
   sprintf( file_name, "%s%s", LDEFIV_temp_dir, "rplut.raw");
   FILSIP_open( file_name, "wb", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   
   bytes_written = FILSIF_write( fp, sizeof(double)*ncol_inp, 
		      (void *) replica_power_lut, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( bytes_written < (sizeof(double)*ncol_inp) ) {
      ERRSIM_set_error( status_code, ERRSID_error,
	 "Error writing look.raw file" );
   }
   FILSIP_close( &fp, &log_status_code );
#endif

/* ==========================================================================
   Allocate backscattering_lut
   ========================================================================== */
   if( ( backscattering_lut = 
            (double *) MEMSIP_alloc( (size_t) ncol_inp * sizeof(double) ) ) ==
       (double *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc,
         "backscattering_lut" );
   }

/* ==========================================================================
   Compute backscattering_lut
   ========================================================================== */
   for( i=0; i<ncol_inp; i++ ) {
      backscattering_lut[ i ] = 
         ( antenna_pattern_lut[ i ] * range_spread_loss_lut[ i ] *
           calib_const_lut[ i ] * replica_power_lut[ i ] );
   }

/* ==========================================================================
   LUT PASS
   ========================================================================== */
   ICALPP_COMP_lut_pass(  inp_io,
                          inp_ima_num,
                          TLRow,
                          TLCol,
                          nrow_inp,
                          ncol_inp,
                          out_io,
                          out_ima_scale,
                          backscattering_lut,
                          adc_lut_direction,
                          adc_io,
                          adc_ima_num,
                          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze memories
   ========================================================================== */
   MEMSIP_free((void *) &look_angle);
   MEMSIP_free((void *) &incidence_angle);
   MEMSIP_free((void *) &slant_range);
   MEMSIP_free((void *) &antenna_pattern_lut);
   MEMSIP_free((void *) &range_spread_loss_lut);
   MEMSIP_free((void *) &calib_const_lut);
   MEMSIP_free((void *) &replica_power_lut);
   MEMSIP_free((void *) &backscattering_lut);

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALIP_IMAG_backscattering */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALIP_IMAG_gamma

        $TYPE         PROCEDURE

        $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                      inp_ima_num
                                : number identifing the image inside the tool
                      TLRow     : the row image coordinate in the full
                                  reference frame of the image
                      TLCol     : the column image coordinate in the full
                                  reference frame of the image
                      nrow_inp  : number of rows of the image
                      ncol_inp  : number of columns of the images
                      out_io    : structure with the IO basic parameters of the
                                  output image
                      out_ima_scale
                                : scale type of output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine drives the creation of the GAMMA IMAGE
                      calibrated image

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void ICALIP_IMAG_gamma
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ IANNIT_ImageScale    out_ima_scale,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALIP_IMAG_gamma";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task variables
   ========================================================================== */
   float                  *look_angle;
   float                  *incidence_angle;
   float                  *slant_range;

   double                 *gamma_image_lut;
   UINTx4                  i;
#ifdef __TRACE__
   FILE                   *fp;
   INTx4                   bytes_written;
   FILSIT_file_name        file_name;
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) ncol_inp+nrow_inp, &log_status_code );

/* ==========================================================================
   Call look_angle, incidence_angle and slant_range computation
   ========================================================================== */
   ICALPP_COMP_info( inp_ima_num, TLRow, TLCol, nrow_inp, ncol_inp,
                    &look_angle, &incidence_angle, &slant_range,
                     status_code);
   ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__

   sprintf( file_name, "%s%s", LDEFIV_temp_dir, "look.raw");
   FILSIP_open( file_name, "wb", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   
   bytes_written = FILSIF_write( fp, sizeof(float)*ncol_inp, 
		      (void *) look_angle, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( bytes_written < (sizeof(float)*ncol_inp) ) {
      ERRSIM_set_error( status_code, ERRSID_error,
	 "Error writing look.raw file" );
   }
   FILSIP_close( &fp, &log_status_code );

   sprintf( file_name, "%s%s", LDEFIV_temp_dir, "incid.raw");
   FILSIP_open( file_name, "wb", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   
   bytes_written = FILSIF_write( fp, sizeof(float)*ncol_inp, 
		      (void *) incidence_angle, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( bytes_written < (sizeof(float)*ncol_inp) ) {
      ERRSIM_set_error( status_code, ERRSID_error,
	 "Error writing look.raw file" );
   }
   FILSIP_close( &fp, &log_status_code );

   sprintf( file_name, "%s%s", LDEFIV_temp_dir, "slant.raw");
   FILSIP_open( file_name, "wb", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   
   bytes_written = FILSIF_write( fp, sizeof(float)*ncol_inp, 
		      (void *) slant_range, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( bytes_written < (sizeof(float)*ncol_inp) ) {
      ERRSIM_set_error( status_code, ERRSID_error,
	 "Error writing look.raw file" );
   }
   FILSIP_close( &fp, &log_status_code );

#endif

/* ==========================================================================
   Allocate antenna_pattern_lut
   ========================================================================== */
   if( ( gamma_image_lut = 
           (double *) MEMSIP_alloc( (size_t) ncol_inp * sizeof(double) ) ) ==
       (double *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_ICAL_err_mem_alloc,
         "gamma_image_lut" );
   }

/* ==========================================================================
   Init the gamma_image_lut to 1.0
   ========================================================================== */
   for( i=0; i<ncol_inp; i++ ) {
      gamma_image_lut[ i ] = 1.0;
   }

/* ==========================================================================
   Generate the gamma image LUT
   ========================================================================== */
   ICALPP_GLUT_gamma_image(  incidence_angle, ncol_inp,
                             inp_ima_num, gamma_image_lut,
                             status_code);
   ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
   sprintf( file_name, "%s%s", LDEFIV_temp_dir, "gamma.raw");
   FILSIP_open( file_name, "wb", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   
   bytes_written = FILSIF_write( fp, sizeof(double)*ncol_inp, 
		      (void *) gamma_image_lut, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( bytes_written < (sizeof(double)*ncol_inp) ) {
      ERRSIM_set_error( status_code, ERRSID_error,
	 "Error writing look.raw file" );
   }
   FILSIP_close( &fp, &log_status_code );
#endif

/* ==========================================================================
   LUT PASS
   ========================================================================== */
   ICALPP_COMP_lut_pass(  inp_io,
                          inp_ima_num,
                          TLRow,
                          TLCol,
                          nrow_inp,
                          ncol_inp,
                          out_io,
                          out_ima_scale,
                          gamma_image_lut,
                          ICALIE_lut_none, /* no ADC compensation */
                          (GIOSIT_io *) NULL,
                          (UINTx1) 0,
                          status_code );
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze memories
   ========================================================================== */
   MEMSIP_free((void *) &look_angle);
   MEMSIP_free((void *) &incidence_angle);
   MEMSIP_free((void *) &slant_range);
   MEMSIP_free((void *) &gamma_image_lut);

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALIP_IMAG_gamma */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALIP_IMAG_adc_saturation

        $TYPE         PROCEDURE

        $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                      inp_ima_num
                                : number identifing the image inside the tool
                      TLRow     : the row image coordinate in the full
                                  reference frame of the image
                      TLCol     : the column image coordinate in the full
                                  reference frame of the image
                      nrow_inp  : number of rows of the image
                      ncol_inp  : number of columns of the images
                      in_calib_const
                                : user defined calibration constant
                      use_calib_const
                                : TRUE if this value override the annotation
                      out_io    : structure with the IO basic parameters of the
                                  output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine drives the creation of the ADC SATURATION
                      CORRECTION image

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void ICALIP_IMAG_adc_saturation
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ float                in_calib_const,
                         /*IN    */ LDEFIT_boolean       use_calib_const,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "ICALIP_IMAG_adc_saturation";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task variables
   ========================================================================== */
   FILSIT_file_name        adc_correct_lut_name;
   ICALPT_pattern         *adc_correct_lut;
   UINTx4                  adc_correct_lut_no;
   IANNIT_AnnotState       state = IANNIE_state_ok;
   float                   calib_const;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set calib_const
   ========================================================================== */
   if( use_calib_const == TRUE ) {
      calib_const = in_calib_const;
   }
   else {
/* ==========================================================================
   Look for ABSOLUTE_CALIB_K state                       
   ========================================================================== */
      IANNIP_GETP_AnnotState( inp_ima_num,
                              (UINTx4) ABSOLUTE_CALIB_K,
                             &state,
                              status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( state == IANNIE_state_ok ) {
         calib_const =
            IANNIV_ImageAnnot[ inp_ima_num ].CalibrationConstant;
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_ICAL_inv_annot,
            "CalibrationConstant" );
      }
   }

/* ==========================================================================
   Set the ADC LUT file name
   ========================================================================== */
   switch( IANNIV_ImageAnnot[ inp_ima_num ].ProductType ) {
      case IANNIE_prod_ERS1_RAW:
      case IANNIE_prod_ERS1_SLC:
      case IANNIE_prod_ERS1_SLCI:
      case IANNIE_prod_ERS1_PRI:
      case IANNIE_prod_ERS1_GEC:
      case IANNIE_prod_ERS1_GTC:
         sprintf( adc_correct_lut_name, "%s%s", LDEFIV_cfg_dir, "adcers1.SDf" );
         break;

      case IANNIE_prod_ERS2_RAW:
      case IANNIE_prod_ERS2_SLC:
      case IANNIE_prod_ERS2_SLCI:
      case IANNIE_prod_ERS2_PRI:
      case IANNIE_prod_ERS2_GEC:
      case IANNIE_prod_ERS2_GTC:
         sprintf( adc_correct_lut_name, "%s%s", LDEFIV_cfg_dir, "adcers2.SDf" );
         break;
   }         

/* ==========================================================================
   Load ADC Correction LUT
   ========================================================================== */
   ICALPP_COMP_load_pattern(  adc_correct_lut_name,
                             &adc_correct_lut,
                             &adc_correct_lut_no,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow_inp, &log_status_code );

/* ==========================================================================
   Compute ADC Lut
   ========================================================================== */
   ICALPP_COMP_adc_comp( inp_io,
                         inp_ima_num,
                         TLRow,
                         TLCol,
                         nrow_inp,
                         ncol_inp,
                         calib_const,
                         adc_correct_lut,
                         adc_correct_lut_no,
                         out_io,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze memories
   ========================================================================== */

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* ICALIP_IMAG_adc_saturation */
