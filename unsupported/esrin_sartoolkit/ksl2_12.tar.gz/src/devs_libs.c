/* ==========================================================================
   $MODULE_HEADER

      $NAME              DEVS_LIBS

      $FUNCTION          Device Access Service exported function

      $ROUTINE           DEVSIP_open_read
                         DEVSIP_mount
                         DEVSIF_read
                         DEVSIP_read_block
                         DEVSIP_dismount
                         DEVSIP_close

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       21-MAR-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#ifdef __VMS__
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/errno.h>
#endif

#ifdef __UNIX__
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/errno.h>
#ifdef __IBM__
#include <sys/tape.h>
#else
#include <sys/mtio.h>
#endif
#endif

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include DEVS_INTF_H
#include DEVS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIP_open_read

      $TYPE	    PROCEDURE

      $INPUT        media_name

      $MODIFIED     NONE

      $OUTPUT       descriptor

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure open a descriptor to read the specified
                    media.

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
void DEVSIP_open_read   (/*IN    */ char                *media_name,
                         /*   OUT*/ INTx4               *descriptor,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "DEVSIP_open_read";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

#if defined(__UNIX__) || defined(__VMS__)
   INTx4                  status;
   char                   sys_msg[ 132 ];
   char                   sys_cmd[ 132 ];
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

#ifdef __VMS__
/* ==========================================================================
   Mount the tape on VMS platforms
   ========================================================================== */
   sprintf( sys_cmd, "mount %s /foreign/blocksize=65534", media_name );
   fprintf( stdout, "\nDoing %s ...\n", sys_cmd );
   system( sys_cmd );
#endif

/* ==========================================================================
   Open function is implemented according the target machine
   ========================================================================== */
#if defined(__UNIX__) || defined(__VMS__)

   *descriptor = open( media_name, O_RDONLY );

/* ==========================================================================
   Check any errors
   ========================================================================== */
   if( *descriptor < 0 ) {
      sprintf( sys_msg, "%s (errno = %0d)", media_name, errno );
      ERRSIM_set_error( status_code,
                        ERRSID_DEVS_err_opn_in_read,
                        sys_msg );
   }

#endif

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* DEVSIP_open_read */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIP_mount

      $TYPE	    PROCEDURE

      $INPUT        descriptor

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure mount the media specified by the descriptor
                    and rewind it.

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
void DEVSIP_mount       (/*IN    */ char                *media_name,
                         /*IN    */ INTx4                descriptor,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "DEVSIP_mount";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                   sys_cmd[ 132 ];
#if defined(__UNIX__) || defined(__VMS__)
   INTx4                  status;
   char                   sys_msg[ 132 ];
#if defined(__UNIX__)
#if defined(__IBM__)
   struct stop            st_command;
#else
   struct mtop            mt_command;
#endif
#endif
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check input
   ========================================================================== */
   if( descriptor < 0 ) {
         ERRSIM_set_error( status_code,
                           ERRSID_DEVS_err_in_mount,
                           "Descriptor not open" );
   }


/* ==========================================================================
   Open function is implemented according the target machine
   ========================================================================== */
#ifdef __VMS__
   sprintf( sys_cmd, "set magtape %s /rewind", media_name );
   fprintf( stdout, "\nDoing %s ...", sys_cmd );
   system( sys_cmd );
#endif

#ifdef __UNIX__
#ifdef __IBM__
   st_command.st_op = STREW;
   st_command.st_count = 0;
   status = ioctl( descriptor, STIOCTOP, &st_command );
#else
   mt_command.mt_op = MTREW;
   mt_command.mt_count = 0;
   status = ioctl( descriptor, MTIOCTOP, &mt_command );
#endif

/* ==========================================================================
   Check if the MTREW is not supported
   ========================================================================== */
   if( errno == ENOTTY ) {
      ERRSIM_print_warning( "Magnetic tape rewind not supported" );
#ifdef __NOT_USEFUL__
      sprintf( sys_cmd, "mt -f %s rewind", media_name );
      fprintf( stdout, "Doing %s ...", sys_cmd );
      system( sys_cmd );
#endif
   }
   else if( status != 0 ) {
      sprintf( sys_msg, "Unable to rewind the tape (errno = %0d)", errno );
      ERRSIM_set_error( status_code, 
                        ERRSID_DEVS_err_in_mount, 
                        sys_msg );
   }
#endif

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* DEVSIP_mount */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIF_read_block

      $TYPE         Procedure

      $INPUT        descriptor   :  pointer to the media to be read
                    data_size    :  size of the buffer to be read
                    no_lines     :  number of lines

      $MODIFIED     data_ptr     :  pointer where store the bytes read

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure read a set lines from an open media and
                    store the data_size bytes in the data_ptr.

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
void DEVSIP_read_block  (/*IN    */ INTx4                descriptor,
                         /*IN    */ INTx4                data_size,
                         /*IN    */ INTx4                no_lines,
                         /*IN OUT*/ void               **data_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "DEVSIP_read_block";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  bytes_read = 0;
   INTx4                  line;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   
   for ( line=0; line<no_lines; line++ ) {

/* ==========================================================================
   Read the line
   ========================================================================== */
      bytes_read = DEVSIF_read( descriptor,
                                data_size,
                                data_ptr[ line ],
                                status_code );
      ERRSIM_on_err_goto_exit( *status_code );

   }
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* DEVSIP_read_block */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIF_read

      $TYPE         Procedure

      $INPUT        descriptor   :  pointer to the media to be read
                    data_size    :  size of the buffer to be read

      $MODIFIED     data_ptr     :  pointer where store the bytes read

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure read from an open media and store the 
                    data_size bytes in the data_ptr. Returns the effective
                    number of bytes read. 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
INTx4 DEVSIF_read       (/*IN    */ INTx4                descriptor,
                         /*IN    */ INTx4                data_size,
                         /*IN OUT*/ void                *data_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "DEVSIF_read";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  bytes_read = 0;
   char                   sys_msg[ 132 ];
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check input
   ========================================================================== */
   if( descriptor < 0 ) {
      ERRSIM_set_error( status_code,
			ERRSID_DEVS_err_in_read,
			"Descriptor not open" );
   }


/* ==========================================================================
   Read from media
   ========================================================================== */
#if defined(__UNIX__) || defined(__VMS__)

   bytes_read = read( descriptor, data_ptr, data_size );

/* ==========================================================================
   Check if error
   ========================================================================== */
   if( bytes_read < 0 ) {
      sprintf( sys_msg, "Access denied (errno = %0d)", errno );
      ERRSIM_set_error( status_code,
                        ERRSID_DEVS_err_in_read,
                        sys_msg );
   }

/* ==========================================================================
   Signal incomplete reads
   ========================================================================== */
   if( (bytes_read < data_size) && (data_size != DEVSID_max_read_size) ) {
      sprintf( sys_msg, "Incomplete read of %0d bytes (expected %0d)", 
         bytes_read, data_size );
      ERRSIM_print_warning( sys_msg );
   }

#endif

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return( bytes_read );

}/* DEVSIF_read */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIP_dismount

      $TYPE	    PROCEDURE

      $INPUT        descriptor

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure rewind the media specified by the descriptor
                    and dismount it.

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
void DEVSIP_dismount    (/*IN    */ char                *media_name,
                         /*IN    */ INTx4                descriptor,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "DEVSIP_dismount";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

#if defined(__UNIX__) || defined(__VMS__)
   INTx4                  status;
   char                   sys_cmd[ 132 ];
#if defined(__UNIX__)
#if defined(__IBM__)
   struct stop            st_command;
#else
   struct mtop            mt_command;
#endif
#endif
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check input
   ========================================================================== */
   if( descriptor < 0 ) {
         ERRSIM_set_error( status_code,
                           ERRSID_DEVS_err_in_dismount,
                           "Descriptor not open" );
   }


/* ==========================================================================
   Close function is implemented according the target machine
   ========================================================================== */

#ifdef __VMS__
/* ==========================================================================
   Dismount the tape on VMS platforms
   ========================================================================== */
   sprintf( sys_cmd, "dismount %s", media_name );
   fprintf( stdout, "\nDoing %s ...", sys_cmd );
   system( sys_cmd );
#endif

#ifdef __UNIX__
#ifdef __IBM__
   st_command.st_op = STOFFL;
   st_command.st_count = 0;
   status = ioctl( descriptor, STIOCTOP, &st_command );
#else
   mt_command.mt_op = MTOFFL;
   mt_command.mt_count = 0;
   status = ioctl( descriptor, MTIOCTOP, &mt_command );
#endif
   if( status != 0 ) {
      ERRSIM_print_warning( "Unable to execute MTOFFL" );
   }
#endif

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* DEVSIP_dismount */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIP_close

      $TYPE	    PROCEDURE

      $INPUT        NONE

      $MODIFIED     descriptor

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure closes the descriptor to the media and
                    zeros it.

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
void DEVSIP_close       (/*IN OUT*/ INTx4               *descriptor,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "DEVSIP_close";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Open function is implemented according the target machine
   ========================================================================== */
#if defined(__UNIX__) || defined(__VMS__)
   close( *descriptor );
#endif

/* ==========================================================================
   Set the descriptor to zero
   ========================================================================== */
   *descriptor = 0;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* DEVSIP_close */
