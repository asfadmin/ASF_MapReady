/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_XSTB

      $FUNCTION          Main module for sequencing tools

      $ROUTINE           STBX_MAIN_main

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
	   N/A        20-OCT-97     RZ       Initial Release
   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#if defined  __MC68K__ || defined __POWERPC__
#include <console.h>
#endif

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include FIIS_INTF_H
#include STBX_PGLB_H
#include STBX_INTF_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

static void trace_in( INTx4   argc,
                      char   *argv[] )
{                                                        
   ERRSIT_status log_status_code;                   
   char          tmp_str[256];
   INTx4         i;
    
   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);
   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);

   sprintf(tmp_str,"%s%d","argc       : ",argc);
   ERRSIP_HPEL_trace_proc_err_log(tmp_str, &log_status_code);
   for(i = 0; i < argc; i++ )
   {
      sprintf(tmp_str,"argv[%02d] : %s",i,argv[i]);
      ERRSIP_HPEL_trace_proc_err_log(tmp_str, &log_status_code);
   }
}                                                        

/* ==========================================================================

   $ROUTINE_HEADER

        $XSTA         STBX_XSTB_main

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Module main driver for sequencing tools

        $WARNING      NONE

        $PDL	      NONE

   $EH
   ========================================================================== */
main( INTx4 argc, char *argv[] )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_XSTB";
#else
   const ERRSIT_proc_class proc_class   = "stbx";
#endif
   const ERRSIT_proc_name  routine_name = "STBX_XSTB_main";
   
   ERRSIT_status           log_status_code;
   ERRSIT_status           status_code;
   ERRSIT_flag             process_flag;

/* ==========================================================================
   Section variables
   ========================================================================== */
   char                  **section_name = (char **) NULL;
   UINTx4                  count_section, section_no;
   INTx4                   task_no;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code      = STC( ERRSID_normal );
   log_status_code  = STC( ERRSID_normal );

   ERRSIP_HPEL_process_init(  proc_class,
                             &log_status_code );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,   
                        &log_status_code);

/* ==========================================================================
   Inizializzation for MAC console.
   ========================================================================== */                        
#if defined __MC68K__ || defined __POWERPC__
	argc=ccommand(&argv);
#endif

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in( argc, argv );
   }

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_sar_toolbox_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );
 
/* ==========================================================================
   Check the existence of at least the "-if file" parms
   ========================================================================== */
   if( argc < 3 ) 
   {
      ERRSIM_set_error( &status_code, ERRSID_STBX_not_if_parm, "");
   }

/* ==========================================================================
   Check that the first arg is "-if"
   ========================================================================== */
   if( strcmp( argv[1], STBXPD_if_arg ) ) 
   {
      ERRSIM_set_error( &status_code, ERRSID_STBX_not_if_parm, "");
   }

/* ==========================================================================
   Extract from INI file all the section included
   ========================================================================== */
   FIISIP_GETS_get_sections(  argv[ 2 ],
                             &section_no,
                             &section_name,
                             &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Call the appropriate task procedure corresponding to the first section 
   contained in the INI file, checking if the task name is one of this tool
   ========================================================================== */
   for( count_section=0; count_section<section_no; count_section++ ) {

      task_no = STBXPF_task_no(  section_name[ count_section ],
                                &status_code );
      ERRSIM_on_err_goto_exit( status_code );

      if( *STBXPC_toolbox_func[ task_no ] != NULL ) {

        ( *STBXPC_toolbox_func[ task_no ] ) (  section_name[ count_section ],
                                               count_section + 1,
                                               argc,
                                               argv,
                                              &status_code );
         ERRSIM_on_err_goto_exit( status_code );

         STBXPM_reset_global;

      }

   }
   
error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   if( section_name != (char **) NULL ) 
   {
      for( count_section=0; count_section<section_no; count_section++ ) 
      {
         MEMSIP_free( (void **) &(section_name[ count_section ]) );
      }
      MEMSIP_free( (void **) &section_name );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                           status_code, 
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown(  proc_class,
                                 &log_status_code );

}/* STBX_XSTB_main */
