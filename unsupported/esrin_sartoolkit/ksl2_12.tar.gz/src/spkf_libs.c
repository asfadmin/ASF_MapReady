/* ==========================================================================
   $MODULE_HEADER

      $NAME              SPKF_LIBS

      $FUNCTION          SPECKLE FILTER library module

      $ROUTINE           SPKFPP_core
                         SPKFIP_filter

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       20-OCT-97     AN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <math.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include FILS_INTF_H
#include GIOS_INTF_H
#include SRVS_INTF_H
#include IANN_INTF_H
#include OVLS_INTF_H
#include SPKF_INTF_H
#include SPKF_PGLB_H

/* ==========================================================================
                            LOCAL STATIC VARIABLE
   ========================================================================== */
static float         **InpWin = (float **) NULL;
static SPKFIT_mask    *mask = (SPKFIT_mask *) NULL;
static UINTx4          mask_no = 0;
static LDEFIT_boolean  first = TRUE;

/* ==========================================================================
                      LOCAL ROUTINE DECLARATION SECTION
   ========================================================================== */
static void SPKFLP_load_scatter_mask
                       ( /*IN    */ FILE                  *fpMask,
                         /*IN    */ char                  *mask_file,
                         /*IN    */ UINTx4                 row_size,
                         /*IN    */ UINTx4                 col_size,
                         /*IN    */ float                **inp_win,
                         /*IN    */ LDEFIT_data_type       inp_data_type,
                         /*IN OUT*/ SPKFIT_scatter_mask   *scatter,
                         /*   OUT*/ ERRSIT_status         *status_code )
{
   const ERRSIT_proc_name routine_name = "SPKFLP_load_scatter_mask";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, col, index;
   char                   buffMask[ 132 ];
   char                  *null_char;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Init buffers
   ========================================================================== */
   scatter->clutter = (float **) NULL;
   scatter->buffer  = (float **) NULL;
   scatter->mailobe = (float **) NULL;
   scatter->ncl     = 0;
   scatter->nbf     = 0;
   scatter->nml     = 0;

   fprintf(stdout, "%s...\n", SPKFPD_spk_scatter);

/* ==========================================================================
   Loop on rows
   ========================================================================== */
   for( row=0; row<row_size; row++ ) {

/* ==========================================================================
   Skip blank lines
   ========================================================================== */
      do  {
         if( fgets( buffMask, sizeof( buffMask ), fpMask ) == 
             (char *) NULL ) {
            ERRSIM_set_error( status_code,
                              ERRSID_SPKF_eof_loading_mask,
                              mask_file );
         }
         if( (null_char = strchr( buffMask, '\n' )) != (char *) NULL ) {
            *null_char = '\0';
         }
      } while( !strcmp( buffMask, "" ) );

/* ==========================================================================
   Loop on columns   
   ========================================================================== */
      col=0; index=0;
      while( (col<col_size) && (index<sizeof( buffMask )) ) {

         switch( buffMask[ index ] ) {

	    case SPKFPD_scatter_clutter:
	       (scatter->ncl)++;
	       scatter->clutter = (float **)
			MEMSIP_realloc( (void *) scatter->clutter, 
					(size_t) scatter->ncl * sizeof(float *) );
               if( scatter->clutter == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "scatter->clutter" );
               }
	       scatter->clutter[ scatter->ncl - 1 ] = 
                                                 &(inp_win[ row ][ col ]);
               col++;
               index++;
	       break;
	    case SPKFPD_scatter_buffer:
	       (scatter->nbf)++;
	       scatter->buffer = (float **)
		  MEMSIP_realloc( (void *) scatter->buffer, 
				  (size_t) scatter->nbf * sizeof(float *) );
               if( scatter->buffer == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "scatter->buffer" );
               }
	       scatter->buffer[ scatter->nbf - 1 ] = 
				                 &(inp_win[ row ][ col ]);
               col++;
               index++;
	       break;
	    case SPKFPD_scatter_mailobe:
	       (scatter->nml)++;
	       scatter->mailobe = (float **)
		  MEMSIP_realloc( (void *) scatter->mailobe, 
				  (size_t) scatter->nml * sizeof(float *) );
               if( scatter->mailobe == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "scatter->mailobe" );
               }
	       scatter->mailobe[ scatter->nml - 1 ] = 
				                 &(inp_win[ row ][ col ]);
               col++;
               index++;
	       break;
            case ' ':
               index++;
               break;
	    default:
	       ERRSIM_set_error( status_code, 
                                 ERRSID_SPKF_inv_speckle_char, 
                                 mask_file );
	 }
      }
   }

/* ==========================================================================
   Check the topology of the mask
   ========================================================================== */
   if( (scatter->nml == 0) || (scatter->ncl == 0) ) {
      ERRSIM_set_error( status_code,
                        ERRSID_SPKF_eof_loading_mask,
                        mask_file );
   }

#ifdef __TRACE__
   fprintf(stdout, "%d %d\n", scatter->clutter, scatter->ncl);
   fprintf(stdout, "%d %d\n", scatter->buffer, scatter->nbf);
   fprintf(stdout, "%d %d\n", scatter->mailobe, scatter->nml);
#endif

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SPKFLP_load_scatter_mask */

static void SPKFLP_load_edgline_mask
                       ( /*IN    */ FILE                  *fpMask,
                         /*IN    */ char                  *mask_file,
                         /*IN    */ UINTx4                 row_size,
                         /*IN    */ UINTx4                 col_size,
                         /*IN    */ float                **inp_win,
                         /*IN    */ LDEFIT_data_type       inp_data_type,
                         /*IN OUT*/ SPKFIT_edgline_mask   *edgline,
                         /*   OUT*/ ERRSIT_status         *status_code )
{
   const ERRSIT_proc_name routine_name = "SPKFLP_load_edgline_mask";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, col, index;
   char                   buffMask[ 132 ];
   char                  *null_char;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Init buffers
   ========================================================================== */
   edgline->edge1     = (float **) NULL;
   edgline->nedge1    = 0;
   edgline->edge2     = (float **) NULL;
   edgline->nedge2    = 0;
   edgline->buff1     = (float **) NULL;
   edgline->nbf1      = 0;
   edgline->buff2     = (float **) NULL;
   edgline->nbf2      = 0;
   edgline->line      = (float **) NULL;
   edgline->nline     = 0;
   edgline->edgbuff1  = (float **) NULL;
   edgline->nedgbuff1 = 0;
   edgline->edgbuff2  = (float **) NULL;
   edgline->nedgbuff2 = 0;

   fprintf(stdout, "%s...\n", SPKFPD_spk_edgline);

/* ==========================================================================
   Loop on rows
   ========================================================================== */
   for( row=0; row<row_size; row++ ) {

/* ==========================================================================
   Skip blank lines
   ========================================================================== */
      do  {
         if( fgets( buffMask, sizeof( buffMask ), fpMask ) == 
             (char *) NULL ) {
            ERRSIM_set_error( status_code,
                              ERRSID_SPKF_eof_loading_mask,
                              mask_file );
         }
         if( (null_char = strchr( buffMask, '\n' )) != (char *) NULL ) {
            *null_char = '\0';
         }
      } while( !strcmp( buffMask, "" ) );

/* ==========================================================================
   Loop on line
   ========================================================================== */
      col=0; index=0;
      while( (col<col_size) && (index<sizeof( buffMask )) ) {

	 switch( buffMask[ index ] ) {

	    case SPKFPD_edgline_edge1:
	       (edgline->nedge1)++;
	       edgline->edge1 = (float **)
		  MEMSIP_realloc( (void *) edgline->edge1, 
				  (size_t) edgline->nedge1 * sizeof(float *) );
               if( edgline->edge1 == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "edgline->edge1" );
               }
	       edgline->edge1[ edgline->nedge1 - 1 ] = 
                                                    &(inp_win[ row ][ col ]);
	       (edgline->nedgbuff1)++;
	       edgline->edgbuff1 = (float **)
		  MEMSIP_realloc( (void *) edgline->edgbuff1, 
				  (size_t) edgline->nedgbuff1 * sizeof(float *) );
               if( edgline->edgbuff1 == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "edgline->edgbuff1" );
               }
	       edgline->edgbuff1[ edgline->nedgbuff1 - 1 ] = 
                                                    &(inp_win[ row ][ col ]);
               col++;
               index++;
	       break;

	    case SPKFPD_edgline_edge2:
	       (edgline->nedge2)++;
	       edgline->edge2 = (float **)
		  MEMSIP_realloc( (void *) edgline->edge2, 
				  (size_t) edgline->nedge2 * sizeof(float *) );
               if( edgline->edge2 == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "edgline->edge2" );
               }
	       edgline->edge2[ edgline->nedge2 - 1 ] = 
                                                    &(inp_win[ row ][ col ]);
	       (edgline->nedgbuff2)++;
	       edgline->edgbuff2 = (float **)
		  MEMSIP_realloc( (void *) edgline->edgbuff2, 
				  (size_t) edgline->nedgbuff2 * sizeof(float *) );
               if( edgline->edgbuff2 == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "edgline->edgbuff2" );
               }
	       edgline->edgbuff2[ edgline->nedgbuff2 - 1 ] = 
                                                    &(inp_win[ row ][ col ]);
               col++;
               index++;
	       break;

	    case SPKFPD_edgline_buffer1:
	       (edgline->nbf1)++;
	       edgline->buff1 = (float **)
		  MEMSIP_realloc( (void *) edgline->buff1, 
				  (size_t) edgline->nbf1 * sizeof(float *) );
               if( edgline->buff1 == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "edgline->buff1" );
               }
	       edgline->buff1[ edgline->nbf1 - 1 ] = 
                                                    &(inp_win[ row ][ col ]);
	       (edgline->nedgbuff1)++;
	       edgline->edgbuff1 = (float **)
		  MEMSIP_realloc( (void *) edgline->edgbuff1, 
				  (size_t) edgline->nedgbuff1 * sizeof(float *) );
               if( edgline->edgbuff1 == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "edgline->edgbuff1" );
               }
	       edgline->edgbuff1[ edgline->nedgbuff1 - 1 ] = 
                                                    &(inp_win[ row ][ col ]);
               col++;
               index++;
	       break;

	    case SPKFPD_edgline_buffer2:
	       (edgline->nbf2)++;
	       edgline->buff2 = (float **)
		  MEMSIP_realloc( (void *) edgline->buff2, 
				  (size_t) edgline->nbf2 * sizeof(float *) );
               if( edgline->buff2 == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "edgline->buff2" );
               }
	       edgline->buff2[ edgline->nbf2 - 1 ] = 
                                                    &(inp_win[ row ][ col ]);
	       (edgline->nedgbuff2)++;
	       edgline->edgbuff2 = (float **)
		  MEMSIP_realloc( (void *) edgline->edgbuff2, 
				  (size_t) edgline->nedgbuff2 * sizeof(float *) );
               if( edgline->edgbuff2 == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "edgline->edgbuff2" );
               }
	       edgline->edgbuff2[ edgline->nedgbuff2 - 1 ] = 
                                                    &(inp_win[ row ][ col ]);
               col++;
               index++;
	       break;

	    case SPKFPD_edgline_line:
	       (edgline->nline)++;
	       edgline->line = (float **)
		  MEMSIP_realloc( (void *) edgline->line, 
				  (size_t) edgline->nline * sizeof(float *) );
               if( edgline->line == (float **) NULL ) {
                  ERRSIM_set_error( status_code, 
                                    ERRSID_SPKF_err_mem_alloc, 
                                    "edgline->line" );
               }
	       edgline->line[ edgline->nline - 1 ] = 
                                                    &(inp_win[ row ][ col ]);
               col++;
               index++;
	       break;
            case ' ':
               index++;
	       break;
	    default:
	       ERRSIM_set_error( status_code,
                                 ERRSID_SPKF_inv_speckle_char,
                                 mask_file );
	 }
      }
   }

/* ==========================================================================
   Check the topology of the mask
   ========================================================================== */
   if( (edgline->nedge1 == 0) || (edgline->nedge2 == 0) || 
       (edgline->nline == 0) ) {
      ERRSIM_set_error( status_code,
                        ERRSID_SPKF_eof_loading_mask,
                        mask_file );
   }

#ifdef __TRACE__
   fprintf(stdout, "%d %d\n", edgline->edge1, edgline->nedge1);
   fprintf(stdout, "%d %d\n", edgline->edge2, edgline->nedge2);
   fprintf(stdout, "%d %d\n", edgline->buff1, edgline->nbf1);
   fprintf(stdout, "%d %d\n", edgline->buff2, edgline->nbf2);
   fprintf(stdout, "%d %d\n", edgline->line, edgline->nline);
#endif


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SPKFLP_load_edgline_mask */

static void SPKFLP_set_all_mask
                       ( /*IN    */ UINTx4                 row_size,
                         /*IN    */ UINTx4                 col_size,
                         /*IN    */ float                **inp_win,
                         /*IN    */ LDEFIT_data_type       inp_data_type,
                         /*IN OUT*/ SPKFIT_all_mask       *all,
                         /*   OUT*/ ERRSIT_status         *status_code )
{
   const ERRSIT_proc_name routine_name = "SPKFLP_set_all_mask";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Init buffers
   ========================================================================== */
   all->vect   = (float **) NULL;
   all->n      = 0;

/* ==========================================================================
   Loop on rows
   ========================================================================== */
   for( row=0; row<row_size; row++ ) {

/* ==========================================================================
   Loop on columns   
   ========================================================================== */
      for( col=0; col<col_size; col++ ) {

         (all->n)++;
	 all->vect = (float **)
		  MEMSIP_realloc( (void *) all->vect, 
				  (size_t) all->n * sizeof(float *) );
         if( all->vect == (float **) NULL ) {
            ERRSIM_set_error( status_code, 
                              ERRSID_SPKF_err_mem_alloc, 
                              "all->vect" );
         }
         all->vect[ all->n - 1 ] = &(inp_win[ row ][ col ]);
      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SPKFLP_set_all_mask */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SPKFIP_load_masks

      $TYPE	    PROCEDURE

      $INPUT        inp_win         : window image matrix
                    inp_data_type   : input data type
                    row_size        : row window size
                    col_size        : column window size

      $MODIFIED     NONE

      $OUTPUT       mask_no         : number of loaded masks
                    mask            : array of mask

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure load the mask into memory 
 
      $WARNING      NONE

   $EH
   ========================================================================== */
void SPKFIP_load_masks
                       ( /*IN    */ float              **inp_win,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ UINTx4               row_size,
                         /*IN    */ UINTx4               col_size,
                         /*IN    */ UINTx4              *mask_no,
                         /*   OUT*/ SPKFIT_mask        **mask,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "SPKFIP_load_masks";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   FILSIT_file_name       mask_file;
   char                   mask_type[ 132 ];
   char                  *null_char;
   FILE                  *fpMask;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Build KER file name
   ========================================================================== */
   if( !strcmp( SPKFIV_mask_file, "" ) ) {
      sprintf( mask_file, "%s%s%0d_%0d.%s", 
               LDEFIV_cfg_dir, SPKFPD_spk_ker_prefix, row_size, col_size,
               SPKFPD_spk_ker_suffix );
   }
   else {
      strcpy( mask_file, SPKFIV_mask_file );
   }
                                 
/* ==========================================================================
   Load mask file
   ========================================================================== */
   fprintf(stdout, "Loading %s mask file...\n", mask_file);

/* ==========================================================================
   Open KER file name
   ========================================================================== */
   FILSIP_open( mask_file, "r", 0, &fpMask, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Loop on KERNELs
   ========================================================================== */
   while( fgets(mask_type, sizeof( mask_type ), fpMask) != (char *) NULL ) {

/* ==========================================================================
   Null the \n character
   ========================================================================== */
      if( (null_char = strchr( mask_type, '\n' )) != (char *) NULL ) {
         *null_char = '\0';
      }

/* ==========================================================================
   Skip blan lines
   ========================================================================== */
      while( !strcmp( mask_type, "" ) ) {
         if( fgets(mask_type, sizeof( mask_type ), fpMask) == (char *) NULL ) {
            ERRSIM_set_error( status_code, 
                              ERRSID_SPKF_eof_loading_mask, 
                              mask_file );
         }

/* ==========================================================================
   Null the \n character
   ========================================================================== */
         if( (null_char = strchr( mask_type, '\n' )) != (char *) NULL ) {
            *null_char = '\0';
         }

      }

      (*mask_no)++;
      *mask = (SPKFIT_mask *) 
                MEMSIP_realloc( (void *) *mask,
                                (size_t) (*mask_no) * sizeof(SPKFIT_mask) );
      if( *mask == (SPKFIT_mask *) NULL ) {
         ERRSIM_set_error( status_code, ERRSID_SPKF_err_mem_alloc, "mask" );
      }

/* ==========================================================================
   Check if this mask is of scatter type or edgline type
   ========================================================================== */
      if( strstr( mask_type, SPKFPD_spk_scatter ) != (char *) NULL ) {
         (*mask)[ *mask_no - 1 ].type = SPKFIE_mt_scatter;
         SPKFLP_load_scatter_mask(  fpMask, mask_file, row_size, col_size, 
                                    inp_win, inp_data_type,
                                   &((*mask)[ *mask_no - 1 ].val.scatter),
                                    status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
      else if( strstr( mask_type, SPKFPD_spk_edgline ) != (char *) NULL ) {
         (*mask)[ *mask_no - 1 ].type = SPKFIE_mt_edgline;
         SPKFLP_load_edgline_mask(  fpMask, mask_file, row_size, col_size,
                                    inp_win, inp_data_type,
                                   &((*mask)[ *mask_no - 1 ].val.edgline),
                                    status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_SPKF_inv_speckle_mask, "mask" );
      }
      
   }

/* ==========================================================================
   Close the KER file
   ========================================================================== */
   FILSIP_close( &fpMask, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set a mask for all the window
   ========================================================================== */
   (*mask_no)++;
   *mask = (SPKFIT_mask *) 
	     MEMSIP_realloc( (void *) *mask,
			      (size_t) (*mask_no) * sizeof(SPKFIT_mask) );
   if( *mask == (SPKFIT_mask *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_SPKF_err_mem_alloc, "mask" );
   }

   (*mask)[ *mask_no - 1 ].type = SPKFIE_mt_all;
   SPKFLP_set_all_mask(  row_size, col_size,
			 inp_win, inp_data_type,
		        &((*mask)[ *mask_no - 1 ].val.all),
			 status_code );
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SPKFIP_load_masks */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SPKFIP_mask_set_thresh

      $TYPE	    PROCEDURE

      $INPUT        mask_no         : number of loaded masks
                    mask            : array of mask
                    pfa             : input probability
                    row_size        : row window size
                    col_size        : column window size
                    looks_no        : image number of looks

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure load the mask into memory 
 
      $WARNING      NONE

   $EH
   ========================================================================== */
void SPKFIP_mask_set_thresh
                       ( /*IN    */ UINTx4               mask_no,
                         /*IN OUT*/ SPKFIT_mask         *mask,
                         /*IN    */ float                pfa,
                         /*IN    */ UINTx4               row_size,
                         /*IN    */ UINTx4               col_size,
                         /*IN    */ float                looks_no,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "SPKFIP_mask_set_thresh";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   FILSIT_file_name       coeff_file;
   char                   line[ 512 ];
   char                   msg[ 132 ];
   FILE                  *fpCoeff;
   char                  *null_char;
   UINTx4                 i, istart, n1, n2, rn1, rn2;
   double                 a[ 10 ], x, y;
   LDEFIT_boolean         found;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Compute x and y
   ========================================================================== */
   x = log( (double) looks_no );
   y = log( (double) pfa );

/* ==========================================================================
   Build Coefficient file name
   ========================================================================== */
   sprintf( coeff_file, "%s%s.%s", LDEFIV_cfg_dir, "speckle", "coe" );

/* ==========================================================================
   Looks for the first SPKFIE_mt_edgline
   ========================================================================== */
   for( i=0; i<mask_no; i++ ) {
      if( mask[ i ].type == SPKFIE_mt_edgline ) break;
   }
   istart = i;

   if( SPKFIV_edge_th == 0.0 ) {
/* ==========================================================================
   Extract n1,n2 for edge mask
   ========================================================================== */
      n1 = mask[ istart ].val.edgline.nedge1 +
           mask[ istart ].val.edgline.nbf1;
      n2 = mask[ istart ].val.edgline.nedge2 +
           mask[ istart ].val.edgline.nbf2;

/* ==========================================================================
   Look in coeffiecient files for n1,n2
   ========================================================================== */
      FILSIP_open( coeff_file, "r", 0, &fpCoeff, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      found = FALSE;
      while( (fgets(line, sizeof( line ), fpCoeff) != (char *) NULL) &&
             !found ) {
/* ==========================================================================
   Null the \n character
   ========================================================================== */
         if( (null_char = strchr( line, '\n' )) != (char *) NULL ) {
            *null_char = '\0';
         }

/* ==========================================================================
   Skip blank lines
   ========================================================================== */
         if( strcmp( line, "" ) ) {
            if( (sscanf(line, "%d %d", &rn1, &rn2) == 2) &&
                (rn1 == n1) && (rn2 == n2) ) {
               if( sscanf(line, "%d %d %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf", 
                          &rn1, &rn2,
                          &(a[0]), &(a[1]), &(a[2]), &(a[3]), &(a[4]),
                          &(a[5]), &(a[6]), &(a[7]), &(a[8]), &(a[9]) ) != 12) {
                  ERRSIM_set_error( status_code, ERRSID_SPKF_eof_loading_coeff,
                                    coeff_file );
               }
               else {
                  found = TRUE;
               }
            }
         }

      }

/* ==========================================================================
   Close coeff file
   ========================================================================== */
      FILSIP_close( &fpCoeff, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      if( found ) {
/* ==========================================================================
   Compute threshold edge 
   ========================================================================== */
         mask[ 0 ].the = (float) ( a[0]+a[1]*x+a[2]*y+a[3]*x*x+a[4]*x*y+
                                   a[5]*y*y+a[6]*x*x*x+a[7]*x*x*y+a[8]*x*y*y+
                                   a[9]*y*y*y );
      }
      else {
         sprintf( msg, "coefficient file not found for edge (%0d %0d)",
            n1, n2 );
         ERRSIM_set_error( status_code,
                           ERRSID_SPKF_inv_threshold,
                           msg );
      }
   }
   else {
      mask[ 0 ].the = SPKFIV_edge_th;
   }
   fprintf(stdout, "Edge Threshold = %f\n", mask[ 0 ].the);


   if( SPKFIV_line_th == 0.0 ) {
/* ==========================================================================
   Extract n1,n2 for line mask
   ========================================================================== */
      n1 = mask[ istart ].val.edgline.nline;
      n2 = mask[ istart ].val.edgline.nedge1 +
           mask[ istart ].val.edgline.nedge2;

/* ==========================================================================
   Look in coeffiecient files for n1,n2
   ========================================================================== */
      FILSIP_open( coeff_file, "r", 0, &fpCoeff, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      found = FALSE;
      while( (fgets(line, sizeof( line ), fpCoeff) != (char *) NULL) &&
             !found ) {
/* ==========================================================================
   Null the \n character
   ========================================================================== */
         if( (null_char = strchr( line, '\n' )) != (char *) NULL ) {
            *null_char = '\0';
         }

/* ==========================================================================
   Skip blank lines
   ========================================================================== */
         if( strcmp( line, "" ) ) {
            if( (sscanf(line, "%d %d", &rn1, &rn2) == 2) &&
                (rn1 == n1) && (rn2 == n2) ) {
               if( sscanf(line, "%d %d %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf", 
                          &rn1, &rn2,
                          &(a[0]), &(a[1]), &(a[2]), &(a[3]), &(a[4]),
                          &(a[5]), &(a[6]), &(a[7]), &(a[8]), &(a[9]) ) != 12) {
                  ERRSIM_set_error( status_code, ERRSID_SPKF_eof_loading_coeff,
                                    coeff_file );
               }
               else {
                  found = TRUE;
               }
            }
         }

      }

/* ==========================================================================
   Close coeff file
   ========================================================================== */
      FILSIP_close( &fpCoeff, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      
      if( found ) {
/* ==========================================================================
   Compute threshold line 
   ========================================================================== */
         mask[ 0 ].thl = (float) ( a[0]+a[1]*x+a[2]*y+a[3]*x*x+a[4]*x*y+
                                   a[5]*y*y+a[6]*x*x*x+a[7]*x*x*y+a[8]*x*y*y+
                                   a[9]*y*y*y );
      }
      else {
         sprintf( msg, "coefficient file not found for line (%0d %0d)",
            n1, n2 );
         ERRSIM_set_error( status_code,
                           ERRSID_SPKF_inv_threshold,
                           msg );
      }
   }
   else {
      mask[ 0 ].thl = SPKFIV_line_th;
   }

    fprintf(stdout, "Line Threshold = %f\n", mask[ 0 ].thl);

/* ==========================================================================
   Set value for scatter threshold
   ========================================================================== */
   if( SPKFIV_scatter_th != 0.0 ) {
      mask[ 0 ].ths = SPKFIV_scatter_th;
   }
   else {
      ERRSIM_set_error( status_code,
                        ERRSID_SPKF_inv_threshold,
                        "scatter" );
   }
   fprintf(stdout, "Scatter Threshold = %f\n", mask[ 0 ].ths);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SPKFIP_mask_set_thresh */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SPKFPP_core     

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_io 	    : IO structure of the output image
                      pfa           : PFA user's value
                      inp_ima_num   : annotation index of the input image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_SPKF_kernel_dim_high
		      ERRSID_SPKF_bad_steps
		      ERRSID_SPKF_bad_write_size
		      ERRSID_SPKF_err_mem_alloc
		      ERRSID_SPKF_data_type_not_allow

        $DESCRIPTION  

        $WARNING      The output structure must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Loop on the rows' steps
                         - Loop on the columns' steps
                            - Reset the index of start and stop
                            - End columns' loop
                         - Write the output row in the output file
                      - End rows' loop

   $EH
   ========================================================================== */
void SPKFPP_core        
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
			 /*IN    */ float                pfa,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "SPKFPP_core";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 rs;
   UINTx4                 cs;
   UINTx4                 RStart;
   UINTx4                 RStop;
   UINTx4                 CStart;
   UINTx4                 CStop;
   REGISTER UINTx4	  row, col;
#ifdef __TRACE__
   UINTx1                *AccIma = (UINTx1 *)NULL;
   FILE                  *fAcc;
   FILSIT_file_name       accFile;
#endif
   float                 *OutIma = (float *)NULL;
   MATHIT_RC              point;
   INTx4                  in_out;
   float		  k;
   REGISTER UINTx2        i;
   REGISTER UINTx2        j;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the kernel sizes consistency
   ========================================================================== */
   if ( ( Kr >= nrow_inp ) || ( Kc >= ncol_inp ) )
      ERRSIM_set_error( status_code, ERRSID_SPKF_kernel_dim_high, "" );

/* ==========================================================================
   Check the steps values
   ========================================================================== */
   if ( ( StepR <= 0.0 ) || ( StepC <= 0.0 ) )
      ERRSIM_set_error( status_code, ERRSID_SPKF_bad_steps, "" );

/* ==========================================================================
   Check the writing counters
   ========================================================================== */
   if ( RStartW >= RStopW )
      ERRSIM_set_error( status_code, ERRSID_SPKF_bad_write_size, "" );

/* ==========================================================================
   Check inp_data_type
   ========================================================================== */
   if( inp_data_type != LDEFIE_dt_float ) {
      ERRSIM_set_error( status_code, ERRSID_SPKF_data_type_not_allow, "");
   }

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
   if ( ( OutIma = (float *)
	   MEMSIP_alloc((size_t)(ncol_out * sizeof(float))) ) ==
	(float *)NULL) {
      ERRSIM_set_error( status_code, ERRSID_SPKF_err_mem_alloc, "OutIma" );
   }

#ifdef __TRACE__

   sprintf( accFile, "%s%s", LDEFIV_out_dir, "speckle.raw" );
   FILSIP_open( accFile, "w", 0, &fAcc, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if ( ( AccIma = (UINTx1 *)
	   MEMSIP_alloc((size_t)(ncol_out * sizeof(UINTx1))) ) ==
	(UINTx1 *)NULL) {
      ERRSIM_set_error( status_code, ERRSID_SPKF_err_mem_alloc, "AccIma" );
   }

#endif

/* ==========================================================================
   Correlate the pointer of InpIma with the mask
   ========================================================================== */
   if( first ) {

      if ( ( InpWin = (float **)MEMSIP_alloc(
	      (size_t)( Kr * sizeof(float *)) ) ) == (float **)NULL ) {
	 ERRSIM_set_error( status_code, ERRSID_SPKF_err_mem_alloc, "InpWin" );
      }

      for ( i=0; i<Kr; i++ ) {
	 InpWin[ i ] = (float *)NULL;
	 if ( ( InpWin[ i ] = (float *)MEMSIP_alloc(
		 (size_t)( Kc * sizeof(float) ) ) ) == (float *)NULL ) {
	    ERRSIM_set_error( status_code, ERRSID_SPKF_err_mem_alloc, "InpWin" );
	 }
      }

      mask_no = 0;
      SPKFIP_load_masks(  InpWin, inp_data_type, Kr, Kc,
                         &mask_no, &mask, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      SPKFIP_mask_set_thresh( mask_no, mask, pfa, Kr, Kc,
                              IANNIV_ImageAnnot[ inp_ima_num ].LooksNumber,
                              status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      first = FALSE;

   }

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
   for ( rs=RStartW; rs<=RStopW; rs++ ) {

      SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
      for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
	 RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
	 CStart = (UINTx4) ROUND( cs * StepC );
	 RStop = RStart + Kr - 1;
	 CStop = CStart + Kc - 1;

/* ==========================================================================
   Copy the current window in InpWin
   ========================================================================== */
	 for ( i=0; i<Kr; i++ ) {
	    memcpy( (void *) InpWin[ i ],
		    (void *) &( ((float **) InpIma)[ RStart + i ][ CStart ]),
		    Kc * sizeof( float ) );
         }

#ifdef __PLAPLA__
         for ( i=0; i<Kr; i++ ) {
            for( j=0; j<Kc; j++ ) {
               printf("InpWin[%0d][%0d]=%f\n", i, j, InpWin[ i ][ j ]);
            }
         }
         for( i=0; i<mask[0].val.scatter.ncl; i++ ) {
            printf("val[%0d]=%f\n", i, *(mask[0].val.scatter.clutter[ i ]) );
         }
         for( i=0; i<mask[1].val.edgline.nedge1; i++ ) {
            printf("val[%0d]=%f\n", i, *(mask[0].val.edgline.edge1[ i ]) );
         }
#endif

/* ==========================================================================
   Select the mask and fill the output vector
   ========================================================================== */
         SPKFIP_AUTO_select_mask(  
            InpWin, Kr, Kc, mask_no, mask, 
            IANNIV_ImageAnnot[ inp_ima_num ].LooksNumber,
           &(OutIma[ cs ]),
#ifdef __TRACE__
           &(AccIma[ cs ]), 
#endif
            status_code );
         ERRSIM_on_err_goto_exit( *status_code );
 
      }

/* ==========================================================================
   Write the output line
   ========================================================================== */
      GIOSIP_write_line( out_io, rs, (void *)OutIma,
                         status_code );
      ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
      FILSIF_write( fAcc,
                    ncol_out*sizeof(UINTx1),
                    (void *)AccIma,
                    status_code );
      ERRSIM_on_err_goto_exit( *status_code );
#endif

   }

#ifdef __TRACE__
   FILSIP_close( &fAcc, &log_status_code );
#endif

error_exit:;

/* ==========================================================================
   Free the output vector memory
   ========================================================================== */
   MEMSIP_free( (void **)(&OutIma) );
#ifdef __TRACE__
   MEMSIP_free( (void **)(&AccIma) );
#endif

/* ==========================================================================
   Free global variables of automa
   ========================================================================== */
   SPKFIP_AUTO_free( &log_status_code );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SPKFPP_core */


/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SPKFIP_filter   

      $TYPE	    PROCEDURE

      $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                    imanum    : number identifing the image inside the tool
                    TLRow     : the row image coordinate in the full
                                reference frame of the image
                    TLCol     : the column image coordinate in the full
                                reference frame of the image
                    nrow_inp  : number of rows of the image
                    ncol_inp  : number of columns of the images
		    win_sizes : size of the window (row, col)
	            mask_file : user's mask file, NULL if not
                    pfa       : PFA user's value
                    edge_th   : user's edge threshold
                    line_th   : user's line threshold
                    scatter_th: user's scatter threshold
                    out_io    : structure with the IO basic parameters of the
                                output image
                    nrow_out  : number of rows of the output image block
                    ncol_out  : number of columns of the output image block


      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure executes the SPECKLE FILTERING of a
                    power image
 
      $WARNING      The input and the output files shall be already opened.

      $PDL          - Build kernel (just the sizes)
		    - Call Overlap & Save windowing image method

   $EH
   ========================================================================== */
void SPKFIP_filter     ( /*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ INTx4               *win_sizes,
                         /*IN    */ FILSIT_file_name     mask_file,
                         /*IN    */ float                pfa,
                         /*IN    */ float                edge_th,
                         /*IN    */ float                line_th,
                         /*IN    */ float                scatter_th,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "SPKFIP_filter";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 vertex_no = 0;
   MATHIT_RC             *vertex = (MATHIT_RC *) NULL;
   float                **Kern = (float **) NULL;
   UINTx4                 Kr, Kc, i, j;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_SPKF_imanum_not_allow, "");
   }

/* ==========================================================================
   Set a global var for the mask file in order to open in the SPKFPP_core
   ========================================================================== */
   strcpy( SPKFIV_mask_file, mask_file );

/* ==========================================================================
   Set global vars for edge line and scatter threshold
   ========================================================================== */
   SPKFIV_edge_th    = edge_th;
   SPKFIV_line_th    = line_th;
   SPKFIV_scatter_th = scatter_th;

/* ==========================================================================
   Set just the kernel size (the kernel values are selected by the core
   function)
   ========================================================================== */
   Kr = win_sizes[ 0 ];
   Kc = win_sizes[ 1 ];

/* ==========================================================================
   Call the OVERLAP & SAVE routine
   ========================================================================== */
   OVLSIP_OverlapAndSave( inp_io, imanum, TLRow, TLCol, 
                          nrow_inp, ncol_inp, vertex_no, vertex,
                          Kern, Kr, Kc, 1.0, 1.0, out_io, nrow_out, ncol_out,
                          SPKFPP_core, pfa, (INTx4) 0, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   first = TRUE;

error_exit:;

/* ==========================================================================
   Free InpWin of SPKFPP_core
   ========================================================================== */
   if( InpWin != (float **) NULL ) {
      for ( i=0; i<Kr; i++ ) {
         MEMSIP_free( (void **) &(InpWin[ i ]) );
      }
      MEMSIP_free( (void **) &InpWin );
   }

/* ==========================================================================
   Free mask of SPKFIP_load_masks
   ========================================================================== */
   for( i=0; i<mask_no; i++ ) {
      switch( mask[ i ].type ) {

         case SPKFIE_mt_all:
            MEMSIP_free( (void **) &(mask[ i ].val.all.vect) );
            break;
         case SPKFIE_mt_scatter:
            MEMSIP_free( (void **) &(mask[ i ].val.scatter.clutter) );
            MEMSIP_free( (void **) &(mask[ i ].val.scatter.buffer) );
            MEMSIP_free( (void **) &(mask[ i ].val.scatter.mailobe) );
            break;
         case SPKFIE_mt_edgline:
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.edge1) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.edge2) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.buff1) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.buff2) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.line) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.edgbuff1) );
            MEMSIP_free( (void **) &(mask[ i ].val.edgline.edgbuff2) );
            break;
      }
   }
   MEMSIP_free( (void **) &mask );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SPKFIP_filter */
