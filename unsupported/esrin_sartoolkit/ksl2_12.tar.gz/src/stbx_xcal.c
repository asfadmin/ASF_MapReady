/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_XCAL

      $FUNCTION          Main module for CALIBRATION Tool
			 Tasks:

      $ROUTINE           STBX_MAIN_main

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       21-OCT-97     RZ       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#if defined __MC68K__ || defined __POWERPC__
#include <console.h>
#endif

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include FIIS_INTF_H
#include STBX_PGLB_H
#include STBX_INTF_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

static void trace_in( INTx4   argc,
                      char   *argv[] )
{                                            
   ERRSIT_status log_status_code;                   
   char          tmp_str[256];
   INTx4         i;
    
   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);
   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);

   sprintf(tmp_str,"%s%d","argc       : ",argc);
   ERRSIP_HPEL_trace_proc_err_log(tmp_str, &log_status_code);
   for(i = 0; i < argc; i++ )
   {
      sprintf(tmp_str,"argv[%02d] : %s",i,argv[i]);
      ERRSIP_HPEL_trace_proc_err_log(tmp_str, &log_status_code);
   }
}                                                        

/* ==========================================================================

   $ROUTINE_HEADER

        $XSTA         STBX_XCAL_main

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Module main driver for CALIBRATION TOOL

        $WARNING      NONE

        $PDL	      - Get all sections from INI file

   $EH
   ========================================================================== */
   
main( INTx4 argc, char *argv[] )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_XCAL";
#else
   const ERRSIT_proc_class proc_class   = "clbr";
#endif
   const ERRSIT_proc_name  routine_name = "STBX_XCAL_main";
   
   ERRSIT_status           log_status_code;
   ERRSIT_status           status_code;
   ERRSIT_flag             process_flag;

/* ==========================================================================
   Section variables
   ========================================================================== */
   char                  **section_name = (char **) NULL;
   UINTx4                  section_no;
   INTx4                   i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code      = STC( ERRSID_normal );
   log_status_code  = STC( ERRSID_normal );

   ERRSIP_HPEL_process_init(  proc_class,
                              &log_status_code );

   ERRSIM_init_routine(  routine_name,
                         &process_flag,   
                         &log_status_code);

/* ==========================================================================
   Inizializzation for MAC console.
   ========================================================================== */                        
#if defined __MC68K__ || defined __POWERPC__
   argc=ccommand(&argv);
#endif

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in( argc, argv );
   }

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version( STBXPD_calibration_tool_version );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config(  LDEFIV_cfg_dir,
                      &log_status_code );
 
/* ==========================================================================
   Check the existence of at least the "-if file" parms
   ========================================================================== */
   if( argc < 3 ) 
   {
      ERRSIM_set_error( &status_code, ERRSID_STBX_not_if_parm, "");
   }

/* ==========================================================================
   Check that the first arg is "-if"
   ========================================================================== */
   if( strcmp( argv[1], STBXPD_if_arg ) ) 
   {
      ERRSIM_set_error( &status_code, ERRSID_STBX_not_if_parm, "");
   }

/* ==========================================================================
   Extract from INI file all the section included
   ========================================================================== */
   FIISIP_GETS_get_sections(  argv[ 2 ],
                             &section_no,
                             &section_name,
                             &status_code );
   ERRSIM_on_err_goto_exit( status_code );

/* ==========================================================================
   Call the appropriate task procedure corresponding to the first section 
   contained in the INI file, checking if the task name is one of this tool
   ========================================================================== */
   if( !strcmp( section_name[ 0 ], STBXPD_image_backscattering ) ) {
      STBXPP_CALI_Backscattering(  section_name[ 0 ],
                                   (UINTx4) 1, /* first section */
                                   argc,
                                   argv,
                                  &status_code );
      ERRSIM_on_err_goto_exit( status_code );
   }
   else if( !strcmp( section_name[ 0 ], STBXPD_image_gamma ) ) {
      STBXPP_CALI_Gamma(  section_name[ 0 ],
                          (UINTx4) 1, /* first section */
                          argc,
                          argv,
                         &status_code );
      ERRSIM_on_err_goto_exit( status_code );
   }
   else if( !strcmp( section_name[ 0 ], STBXPD_image_adc_sat ) ) {
      STBXPP_CALI_AdcSaturation(  section_name[ 0 ],
                                  (UINTx4) 1, /* first section */
                                  argc,
                                  argv,
                                 &status_code );
      ERRSIM_on_err_goto_exit( status_code );
   }
   else {
      ERRSIM_set_error( &status_code,
                         ERRSID_STBX_section_invalid,
                         section_name[ 0 ] );
   }
   
error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   if( section_name != (char **) NULL ) 
   {
      for( i=0; i<section_no; i++ ) 
      {
         MEMSIP_free( (void **) &(section_name[ i ]) );
      }
      MEMSIP_free( (void **) &section_name );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                           status_code, 
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown(  proc_class,
                                 &log_status_code );
                              
}/* STBX_XSTA_main */
