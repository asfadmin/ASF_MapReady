/* ==========================================================================
   $MODULE_HEADER

      $NAME              IANN_GETP

      $FUNCTION          Contains the procedures to extract the image
                         annotations from a Toolbox file, check and store them
                         for future use

      $ROUTINE           IANNIP_GETP_ImageAnnot
                         IANNIP_GETP_AnnotDump
                         IANNIP_GETP_CopyAnnot
                         IANNIP_GETP_DoppCentFreqEval
			 IANNPP_GETP_TagsCheck
                         IANNPP_GETP_BasicTagsCheck
                         IANNPP_GETP_SetDateString
                         IANNIP_GETP_AnnotState
                         IANNPP_GETP_CheckValidTag

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       13-MAY-97     GRV       Initial Release
            N/A       23-MAR-97     AG        Add for Reqs B10/B18

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>
#include <string.h>
#include <math.h>

#include "defl_libname_intf.h"
#include IANN_TAGS_H

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include TIFS_INTF_H
#include MATH_INTF_H
#include IANN_INTF_H
#include IANN_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_GETP_ImageAnnot

        $TYPE         PROCEDURE

        $INPUT        chan	    : the open TIFF file channel from which the
                                      parameters must be read
                      img	    : the image number in the TIFF file
                      imanum	    : progressive number of the image (more
                                      than one images can be simultaneously
                                      handled)
                      task_descr    : flag describing the task that call the
                                      reading image annotation procedure
                      bpar	    : basic parameters of the input file

        $MODIFIED     NONE

        $OUTPUT       The global structure with the <imanum> image annotations
                      stored

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the image
                                                  annotations that must be
                                                  filled

        $RET_STATUS   ERRSID_IANN_not_allow_imanum
                      ERRSID_IANN_tag_not_found
                      ERRSID_IANN_tag_invalid

        $DESCRIPTION  This procedure fills the global structure
                      <IANNIV_ImageAnnot[i]> with the annotations read from the
                      Toolbox file of which <chan> and <img> refers

        $WARNING      NONE

   $EH
   ========================================================================== */

void IANNIP_GETP_ImageAnnot
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx1               task_descr,
                         /*IN    */ TIFSIT_basicpar      bpar,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNIP_GETP_ImageAnnot";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   TIFSIT_par             param;
   INTx4                  i;
   INTx4                  j;
   INTx4                  comp = -1;
   UINTx4                 tag_notf = 0;
   UINTx4                 tag_notv = 0;
   char                  *ptr = NULL;
   char                   tag_num[ LDEFID_char_line ] = "";
   char                   sst[ LDEFID_char_num ];
   char                   numb[ 4 ] = "";
   INTx4                  int_bool = 0;
   float                  new_pixel_spacing = 0.;
   LDEFIT_boolean         fill_flag_1;
   LDEFIT_boolean         fill_flag_2;
   LDEFIT_boolean         valid_flag;
   INTx4                  cc;
   char                  *pt;
   INTx4                  nchar;
   UINTx1                 proj_descr = 0;

/* ==========================================================================
   Constant declarations
   ========================================================================== */
   char ell[][ 4 ] = {
      "GEM",                /* string to mathc for GEM6 ellipsoid */
      "WGS",                /* string to mathc for WGS84 ellipsoid */
      "INT"                 /* string to mathc for International 1909 */
                            /* ellipsoid */
   };

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image index
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) {
      sprintf( numb, "%0u", imanum );
      ERRSIM_set_error( status_code, ERRSID_IANN_not_allow_imanum, numb );
   }

/* ==========================================================================
   Initialize the vetcor of tags not found ...
   ========================================================================== */
   memset( (void *)IANNIV_NotFoundTags[ imanum ], 0, 
           sizeof( UINTx4 ) * IANNID_ImageAnnotMaxNumber );

/* ==========================================================================
   ... and that of valid tags
   ========================================================================== */
   memset( (void *)IANNIV_InvalidTags[ imanum ], 0,
           sizeof( UINTx4 ) * IANNID_ImageAnnotMaxNumber );

/* ==========================================================================
   Initialize the structure with the image annotations
   ========================================================================== */
   memset( &IANNIV_ImageAnnot[ imanum ], 0, 
            (size_t)sizeof( IANNIT_ImageAnnot ) );

/* ==========================================================================
   Fill the basic parameters section of the image annotation
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum ].ImageWidth = (INTx4)bpar.imagewidth;
   IANNIV_ImageAnnot[ imanum ].ImageLength = (INTx4)bpar.imagelength;
   IANNIV_ImageAnnot[ imanum ].SamplePerPixel = (INTx2)bpar.sampleperpixel;
   for ( i=0;i<IANNIV_ImageAnnot[ imanum ].SamplePerPixel;i++ )
      IANNIV_ImageAnnot[ imanum ].BitsPerSample[ i ] =
         (INTx2)bpar.bitspersample[ 0 ];
   for (i=0;i<IANNIV_ImageAnnot[ imanum ].SamplePerPixel;i++)
      IANNIV_ImageAnnot[ imanum ].SampleFormat[ i ] =
         (INTx1)bpar.sampleformat[ 0 ];

/* ==========================================================================
   Check the validity of the basic parameters (mandatory !)
   ========================================================================== */
   IANNPP_GETP_BasicTagsCheck( imanum, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   All the sequent annotations are stored as string.
   General info section
   ========================================================================== */
   param.tag = LOG_VOL_ID;            /* product type */
   IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_undef;
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = LOG_VOL_ID;
      *status_code = STC( ERRSID_normal );
   }
   else {
      ptr = param.val;
      strupr( ptr );

      comp = -1;
      comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_sat[0], ptr, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == 0 ) {

         /* ERS1 product */
         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[0], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* RAW product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS1_RAW;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[1], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* SLC product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS1_SLC;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[2], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* SLCI product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS1_SLCI;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[3], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* PRI product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS1_PRI;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[4], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* GEC product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS1_GEC;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[5], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* GTC product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS1_GTC;
      }
      else if ( comp == -2 ) {
         memset ( sst, '\0', LDEFID_char_num );
         sprintf ( sst, "%s%s%0u", LDEFIV_ERRS_error_message[
                   ERRSID_LDEF_first_longer ], " for the tag: ", LOG_VOL_ID );
         ERRSIM_print_warning ( sst );
      }

      comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_sat[1], ptr, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == 0 ) {

         /* ERS2 product */
         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[0], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* RAW product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS2_RAW;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[1], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* SLC product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS2_SLC;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[2], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* SLCI product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS2_SLCI;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[3], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* PRI product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS2_PRI;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[4], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* GEC product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS2_GEC;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_prod[5], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                              /* GTC product */
            IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_ERS2_GTC;
      }
      else if ( comp == -2 ) {
         memset ( sst, '\0', LDEFID_char_num );
         sprintf ( sst, "%s%s%0u", LDEFIV_ERRS_error_message[
                   ERRSID_LDEF_first_longer ], " for the tag: ", LOG_VOL_ID );
         ERRSIM_print_warning ( sst );
      }

/* ==========================================================================
   Control if some memories has been allocated and deallocate them
   ========================================================================== */
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = DATA_FORMAT;             /* media data format */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = DATA_FORMAT;
      *status_code = STC( ERRSID_normal );
   }
   else {
      sprintf( IANNIV_ImageAnnot[ imanum ].dataFormat,
	       (char *)param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = SOURCE_ID;             /* media source */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = SOURCE_ID;
      *status_code = STC( ERRSID_normal );
   }
   else {
      sprintf( IANNIV_ImageAnnot[ imanum ].sourceId,
	       (char *)param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = NUMBER_OF_VOLUMES;      /* null lines */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = NUMBER_OF_VOLUMES;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].numberOfVolumes= (INTx4)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = SCENE_REF_NUM;             /* number of orbit and frame */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = SCENE_REF_NUM;
      *status_code = STC( ERRSID_normal );
   }
   else {
      sprintf( IANNIV_ImageAnnot[ imanum ].SceneReferenceNumbers,
	       (char *)param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = PROCESSING_PAF;                    /* processing PAFs */
   IANNIV_ImageAnnot[ imanum ].ProcessingPAF = IANNIE_proc_undef;

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   TIFSIP_get_par( chan, img, &param, status_code );
   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = PROCESSING_PAF;
      *status_code = STC( ERRSID_normal );
   }
   else {
      ptr = param.val;
      strupr( ptr );

      comp = -1;
      comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_proc[ 0 ], ptr, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == -2 ) {
#ifdef __PLAPLA__
         memset ( sst, '\0', LDEFID_char_num );
         sprintf ( sst, "%s%s%0u", LDEFIV_ERRS_error_message[
                   ERRSID_LDEF_first_longer ], " for the tag: ",
                   PROCESSING_PAF );
         ERRSIM_print_warning ( sst );
#endif
      }
      else {
         if ( comp == 0 )
            IANNIV_ImageAnnot[ imanum ].ProcessingPAF = IANNIE_proc_CPAF;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_proc[ 1 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )
            IANNIV_ImageAnnot[ imanum ].ProcessingPAF = IANNIE_proc_DPAF;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_proc[ 2 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )
            IANNIV_ImageAnnot[ imanum ].ProcessingPAF = IANNIE_proc_UPAF;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_proc[ 3 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )
            IANNIV_ImageAnnot[ imanum ].ProcessingPAF = IANNIE_proc_IPAF;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_proc[ 4 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )
            IANNIV_ImageAnnot[ imanum ].ProcessingPAF = IANNIE_proc_APAF;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_proc[ 5 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )
            IANNIV_ImageAnnot[ imanum ].ProcessingPAF = IANNIE_proc_SPAF;

      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/*
   param.tag = PROCESSOR_NAME; */ /* ID of the SW processing the image */
/*
   IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_undef;
   TIFSIP_get_par( chan, img, &param, status_code );
   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = PROCESSOR_NAME;
      *status_code = STC( ERRSID_normal );
   }
   else {
      ptr = param.val;
      strupr( ptr );

      comp = -1;
      comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_swproc[ 0 ], ptr,
                                    status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == -2 ) {
         memset ( sst, '\0', LDEFID_char_num );
         sprintf ( sst, "%s%s%0u", LDEFIV_ERRS_error_message[
                   ERRSID_LDEF_first_longer ], " for the tag: ",
                   PROCESSOR_NAME );
         ERRSIM_print_warning ( sst );
      }
      else {
         if ( comp == 0 )
            IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_VMP;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_swproc[ 1 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )
            IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_ESAR;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_swproc[ 2 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )
            IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_Bangkok;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }
*/

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = PROCESSOR_NAME;           /* ID of the SW processing the image */
   IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_undef;
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = PROCESSOR_NAME;
      *status_code = STC ( ERRSID_normal );
   }
   else {
      ptr = param.val;
      strupr ( ptr );

      comp = -1;
      comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_swproc[ 2 ], ptr,
                                     status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == -2 ) {
#ifdef __PLAPLA__
         memset ( sst, '\0', LDEFID_char_num );
         sprintf ( sst, "%s%s%0u", LDEFIV_ERRS_error_message[
                   ERRSID_LDEF_first_longer ], " for the tag: ",
                   PROCESSOR_NAME );
         ERRSIM_print_warning ( sst );
#endif
      }
      else {
         if ( comp == 0 ) {
            IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_ESAR;
         }
         else {
            ERRSIM_print_warning ( "Processor name set to VMP" );
            IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_VMP;
         }
      }
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Calibration section
   ========================================================================== */
   param.tag = ABSOLUTE_CALIB_K;      /* constant calibration */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ABSOLUTE_CALIB_K;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].CalibrationConstant =
	 (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = INCID_ANGLE_CENTRE_RANGE;      /* incidence angle */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = INCID_ANGLE_CENTRE_RANGE;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].IncidenceAngleAtMiddleRange_deg =
         (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/*
   param.tag = ANTENNA_BORESIGHT;   */         /* boresight angle */
/*
   TIFSIP_get_par( chan, img, &param, status_code );
*/

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

#ifdef __NOT_HARDCODED__
   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ANTENNA_BORESIGHT;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].BoresightAngle_deg = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }
#endif

/* ==========================================================================
   Set the antenna boresight to the default value
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum ].BoresightAngle_deg = IANNPD_boresigth_angle_deg;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Corners coordinates section
   ========================================================================== */
   param.tag = TOP_LEFT_LAT;      /* top left latitude*/
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = TOP_LEFT_LAT;    
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].TopLeftLat_deg = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = TOP_LEFT_LON;      /* top left longitude */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = TOP_LEFT_LON;    
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg = (float)atof( param.val );
      if( IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg > 180.0 ) {
         IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg = 
            IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg - 360.0;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = TOP_RIGHT_LAT;      /* top right latitude*/
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = TOP_RIGHT_LAT;   
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].TopRightLat_deg = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = TOP_RIGHT_LON;      /* top right longitude */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = TOP_RIGHT_LON;    
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].TopRightLon_deg = (float)atof( param.val );
      if( IANNIV_ImageAnnot[ imanum ].TopRightLon_deg > 180.0 ) {
         IANNIV_ImageAnnot[ imanum ].TopRightLon_deg = 
            IANNIV_ImageAnnot[ imanum ].TopRightLon_deg - 360.0;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = BOTTOM_LEFT_LAT;      /* bottom left latitude*/
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = BOTTOM_LEFT_LAT; 
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = BOTTOM_LEFT_LON;      /* bottom left longitude */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = BOTTOM_LEFT_LON; 
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg = (float)atof( param.val );
      if( IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg > 180.0 ) {
         IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg = 
            IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg - 360.0;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = BOTTOM_RIGHT_LAT;      /* bottom right latitude*/
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = BOTTOM_RIGHT_LAT;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].BottomRightLat_deg = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = BOTTOM_RIGHT_LON;      /* bottom right longitude */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = BOTTOM_RIGHT_LON;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg = (float)atof( param.val );
      if( IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg > 180.0 ) {
         IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg = 
            IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg - 360.0;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CENTRE_GEODETIC_LAT;    /* latitude of the image center */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = CENTRE_GEODETIC_LAT;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg =
	 (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CENTRE_GEODETIC_LON;    /* longitude of the image center */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = CENTRE_GEODETIC_LON;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg =
	 (float)atof( param.val );
      if( IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg > 180.0 ) {
         IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg = 
            IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg - 360.0;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = EARLY_ZERO_FILL_RECORD_NUMBER;      /* null lines */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = EARLY_ZERO_FILL_RECORD_NUMBER;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].TopZeroFilledLines = (INTx4)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = LATE_ZERO_FILL_RECORD_NUMBER;      /* null lines */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = LATE_ZERO_FILL_RECORD_NUMBER;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].BottomZeroFilledLines =
         (INTx4)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = NEAR_ZERO_FILL_PIXEL_NUMBER;      /* null pixels */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = NEAR_ZERO_FILL_PIXEL_NUMBER;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].LeftZeroFilledPixels =
         (INTx4)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = FAR_ZERO_FILL_PIXEL_NUMBER;      /* null pixels */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = FAR_ZERO_FILL_PIXEL_NUMBER;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].RightZeroFilledPixels =
         (INTx4)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   MAP Projection section
   ========================================================================== */
   param.tag = MAP_PROJ_DESCR;    /* MAP projection descr. */
   IANNIV_ImageAnnot[ imanum ].MapProjectionType = IANNIE_proj_undef;
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC( ERRSID_normal );
   }
   else {
      ptr = param.val;
      strupr( ptr );

      comp = -1;

      /* UTM Map projection */
      comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_map[0], ptr, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == -2 ) {
         memset ( sst, '\0', LDEFID_char_num );
         sprintf ( sst, "%s%s%0u", LDEFIV_ERRS_error_message[
                   ERRSID_LDEF_first_longer ], " for the tag: ",
                   MAP_PROJ_DESCR );
         ERRSIM_print_warning ( sst );
      }
      else {

         if ( comp == 0 ) {
            IANNIV_ImageAnnot[ imanum ].MapProjectionType = IANNIE_proj_UTM;
         }
         else {

            /* alternative UTM Map projection descriptor content */
            comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_map[ 1 ], ptr,
                                          status_code );
            ERRSIM_on_err_goto_exit ( *status_code );
            if ( comp == 0 ) {
               IANNIV_ImageAnnot[ imanum ].MapProjectionType = IANNIE_proj_UTM;
            }
         }

         /* UPS Map projection */
         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_map[2], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 ) IANNIV_ImageAnnot[ imanum ].MapProjectionType =
            IANNIE_proj_UPS;

         /* ground projected image */
         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_map[3], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 ) IANNIV_ImageAnnot[ imanum ].MapProjectionType =
            IANNIE_proj_ground;

         /* slant projected image */
         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_map[4], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 ) IANNIV_ImageAnnot[ imanum ].MapProjectionType =
            IANNIE_proj_slant;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Switch on the map projection types
   ========================================================================== */
   switch ( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {

      case IANNIE_proj_UTM:

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 /* UTM Projection */
	 param.tag = UTM_SCALE_FACTOR;   /* scale factor */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

	 if ( *status_code != ERRSID_normal ) {
	    IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = UTM_SCALE_FACTOR;
	    *status_code = STC( ERRSID_normal );
	 }
	 else {
	    IANNIV_ImageAnnot[ imanum ].ProjectionScaleFactor =
	       (float)atof( param.val );
	    if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
	 }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 param.tag = UTM_CENTER_PROJ_LAT;      /* central parallel */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

	 if ( *status_code != ERRSID_normal ) {
	    IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = UTM_CENTER_PROJ_LAT;
	 *status_code = STC( ERRSID_normal );
	 }
	 else {
	    IANNIV_ImageAnnot[ imanum ].ProjectionCentralParallel_deg =
	       (float)atof( param.val );
	    if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
	 }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 param.tag = UTM_CENTER_PROJ_LON;      /* central meridian */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

	 if ( *status_code != ERRSID_normal ) {
	    IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = UTM_CENTER_PROJ_LON;
	 *status_code = STC( ERRSID_normal );
	 }
	 else {
	    IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg =
	       (float)atof( param.val );
            if( IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg > 
                180.0 ) {
               IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg = 
                  IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg - 360.0;
            }
	    if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
	 }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 param.tag = TOP_LEFT_EAST;         /* UTM top left coord */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

	 if ( *status_code != ERRSID_normal ) {
	    IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = TOP_LEFT_EAST;   
	    *status_code = STC( ERRSID_normal );
	 }
	 else {
	    IANNIV_ImageAnnot[ imanum ].TopLeftEast_m =
	       (float)atof( param.val );
	    if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
	 }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 param.tag = TOP_LEFT_NORTH;         /* UTM top left coord */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

	 if ( *status_code != ERRSID_normal ) {
	    IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = TOP_LEFT_NORTH;  
	    *status_code = STC( ERRSID_normal );
	 }
	 else {
	    IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m =
	       (float)atof( param.val );
	    if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
	 }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 param.tag = UTM_FALSE_EAST;        /* UTM zone origin */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

	 if ( *status_code != ERRSID_normal ) {
	    IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = UTM_FALSE_EAST;  
	    *status_code = STC( ERRSID_normal );
	 }
	 else {
	    IANNIV_ImageAnnot[ imanum ].FalseEast_m =
	       (float)atof( param.val );
	    if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
	 }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 param.tag = UTM_FALSE_NORTH;       /* UTM zone origin */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

	 if ( *status_code != ERRSID_normal ) {
	    IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = UTM_FALSE_NORTH; 
	    *status_code = STC( ERRSID_normal );
	 }
	 else {
	    IANNIV_ImageAnnot[ imanum ].FalseNorth_m =
	       (float)atof( param.val );
	    if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
	 }
	 break;

      case IANNIE_proj_UPS:

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 /* UPS Projection */
	 param.tag = UPS_SCALE_FACTOR;   /* scale factor */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

	 if ( *status_code != ERRSID_normal ) {
	    IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = UPS_SCALE_FACTOR;
	    *status_code = STC( ERRSID_normal );
	 }
	 else {
	    IANNIV_ImageAnnot[ imanum ].ProjectionScaleFactor =
	       (float)atof( param.val );
	    if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
	 }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 param.tag = UPS_CENTER_PROJ_LAT;	/* central parallel */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = UPS_CENTER_PROJ_LAT;
            *status_code = STC( ERRSID_normal );
         }
         else {
            IANNIV_ImageAnnot[ imanum ].ProjectionCentralParallel_deg =
               (float)atof( param.val );
            if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
         }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 param.tag = UPS_CENTER_PROJ_LON;      /* central meridian */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

	 if ( *status_code != ERRSID_normal ) {
	    IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = UPS_CENTER_PROJ_LON;
	    *status_code = STC( ERRSID_normal );
	 }
	 else {
	    IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg =
	       (float)atof( param.val );
            if( IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg > 
                180.0 ) {
               IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg = 
                  IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg - 360.0;
            }
	    if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
	 }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 param.tag = TOP_LEFT_EAST;         /* UTM top left coord */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

	 if ( *status_code != ERRSID_normal ) {
	    IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = TOP_LEFT_EAST;   
	    *status_code = STC( ERRSID_normal );
	 }
	 else {
	    IANNIV_ImageAnnot[ imanum ].TopLeftEast_m =
	       (float)atof( param.val );
	    if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
	 }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

	 param.tag = TOP_LEFT_NORTH;         /* UTM top left coord */
	 TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

	 if ( *status_code != ERRSID_normal ) {
	    IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = TOP_LEFT_NORTH;
	    *status_code = STC( ERRSID_normal );
	 }
	 else {
	    IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m =
	       (float)atof( param.val );
	    if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
	       MEMSIP_free( &param.val );
	 }

/* ==========================================================================
   Define the False origin for the UPS reference system
   ========================================================================== */
	 IANNIV_ImageAnnot[ imanum ].FalseEast_m = IANNPD_UPSFalseEast_m;
	 IANNIV_ImageAnnot[ imanum ].FalseNorth_m = IANNPD_UPSFalseNorth_m;

	 break;

      case IANNIE_proj_ground:
      case IANNIE_proj_slant:
	 break;

      case IANNIE_proj_undef:

/* ==========================================================================
   Search the rigth projection looking for the Logical Volume ID
   ========================================================================== */
	 switch ( IANNIV_ImageAnnot[ imanum ].ProductType ) {
	    case IANNIE_prod_ERS1_RAW:                         /* RAW product */
	    case IANNIE_prod_ERS2_RAW:
	    case IANNIE_prod_ERS1_SLC:                         /* SLC product */
	    case IANNIE_prod_ERS2_SLC:
	    case IANNIE_prod_ERS1_SLCI:                       /* SLCI product */
	    case IANNIE_prod_ERS2_SLCI:
	       IANNIV_ImageAnnot[ imanum ].MapProjectionType =
		  IANNIE_proj_slant;
	    break;
	    case IANNIE_prod_ERS1_PRI:                         /* PRI product */
	    case IANNIE_prod_ERS2_PRI:
               IANNIV_ImageAnnot[ imanum ].MapProjectionType =
                  IANNIE_proj_ground;
            break;
	    case IANNIE_prod_ERS1_GEC:                         /* GEC product */
	    case IANNIE_prod_ERS2_GEC:
	    case IANNIE_prod_ERS1_GTC:                         /* GTC product */
	    case IANNIE_prod_ERS2_GTC:
	    case IANNIE_prod_undef:                        /* product unknown */
	       IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = MAP_PROJ_DESCR;  
	    break;
	 }
      break;
   }

/* ==========================================================================
   Set projection index to IANNPC_necessary_tag
   ========================================================================== */
   if( IANNIV_ImageAnnot[ imanum ].MapProjectionType == IANNIE_proj_undef ) {

      if( task_descr == IANNID_IANN ) {
         ERRSIM_print_warning( "Map Projection tag not found. \
No checks of necessary tags will be performed" );
         proj_descr = 0;
      }
      else {
         ERRSIM_set_error( status_code, 
                           ERRSID_IANN_tag_not_found,
                           "Map Projection" );
      }
   }
   else {
      proj_descr = ((UINTx1) IANNIV_ImageAnnot[ imanum ].MapProjectionType) - 
                   1;
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Spacing section
   ========================================================================== */
   param.tag = LINE_SPACING;      /* spacing in rows direction */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = LINE_SPACING;    
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].LineSpacing_m = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = PIXEL_SPACING;      /* spacing in the col direction */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = PIXEL_SPACING;   
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].PixelSpacing_m = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Timing section
   ========================================================================== */
   param.tag = YEAR_DATA_POINT;        /* year of the first state vector time */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = YEAR_DATA_POINT; 
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].FirstSTVectYear =
         (INTx2)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = MONTH_DATA_POINT;   /* month of the first state vector time */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = MONTH_DATA_POINT;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth =
         (INTx2)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }
   
/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = DAY_DATA_POINT;   /* day of the first state vector time */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = DAY_DATA_POINT;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].FirstSTVectDay =
         (INTx2)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = SECOND_OF_DAY;            /* seconds in the day */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = SECOND_OF_DAY;   
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds =
         (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = ZERO_DOPP_AZIM_FIRST_TIME;     /* time of the first image line */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC( ERRSID_normal );

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

/* ==========================================================================
   Look for an alternative tag
   ========================================================================== */
      param.tag = RAW_FIRST_LINE_UTC_TIME;
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ZERO_DOPP_AZIM_FIRST_TIME;
         *status_code = STC( ERRSID_normal );
      }
      else {
         sprintf( IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                  (char *)param.val );

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

/* ==========================================================================
   Set the right date
   ========================================================================== */
         IANNPP_GETP_SetDateString ( IANNIV_ImageAnnot[
                                     imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                                     status_code );
/* ==========================================================================
   Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ZERO_DOPP_AZIM_FIRST_TIME;
            *status_code = STC( ERRSID_normal );
         }
         if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
            MEMSIP_free( &param.val );
      }
   }
   else {

      pt = param.val;
      nchar = strlen( pt );
      for ( cc=0, fill_flag_1=FALSE; cc<nchar; cc++ ) {
         if ( pt[ cc ] != ' ' ) {
            fill_flag_1 = TRUE;
            break;
         }
      }

      if ( fill_flag_1 ) {
         sprintf( IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                  (char *)param.val );

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         IANNPP_GETP_SetDateString ( IANNIV_ImageAnnot[
                                     imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                                     status_code );
/* ==========================================================================
   Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ZERO_DOPP_AZIM_FIRST_TIME;
            *status_code = STC( ERRSID_normal );
         }
         if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
            MEMSIP_free( &param.val );
      }
      else {

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

/* ==========================================================================
   Look for an alternative tag
   ========================================================================== */
         param.tag = RAW_FIRST_LINE_UTC_TIME;
         TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ZERO_DOPP_AZIM_FIRST_TIME;
            *status_code = STC( ERRSID_normal );
         }
         else {
            sprintf( IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                     (char *)param.val );

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
            ERRSIV_dump_error = 0;

/* ==========================================================================
   Set the right date
   ========================================================================== */
            IANNPP_GETP_SetDateString ( IANNIV_ImageAnnot[
                                        imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                                        status_code );
/* ==========================================================================
   Reset dumping
   ========================================================================== */
            ERRSIV_dump_error = 1;

            if ( *status_code != ERRSID_normal ) {
               IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ZERO_DOPP_AZIM_FIRST_TIME;
               *status_code = STC( ERRSID_normal );
            }
            if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
         }
      }
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = ZERO_DOPP_AZIM_LAST_TIME;       /* time of the last image line */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ZERO_DOPP_AZIM_LAST_TIME;
      *status_code = STC( ERRSID_normal );
   }
   else {
      sprintf( IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthLastLine_UTC,
               (char *)param.val );
/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      IANNPP_GETP_SetDateString ( IANNIV_ImageAnnot[
                                  imanum ].ZeroDopplerAzimuthLastLine_UTC,
                                  status_code );
/* ==========================================================================
   Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ZERO_DOPP_AZIM_LAST_TIME;
         *status_code = STC( ERRSID_normal );
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = RADAR_WAVELEN;      /* radar lambda */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = RADAR_WAVELEN;   
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].RadarWaveLength_m = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = SAMPLING_RATE;      /* sampling rate */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = SAMPLING_RATE;   
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz =
         (float)atof( param.val ) * (1.e+6);                       /* from MHz to Hz */
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = ZERO_DOPP_RANGE_FIRST_TIME;                /* first range time */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC( ERRSID_normal );

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = RANGE_GATE_AT_EARLY_EDGE;
      TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ZERO_DOPP_RANGE_FIRST_TIME;
         *status_code = STC( ERRSID_normal );
      }
      else {
         IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec =
            (float)atof( param.val ) * (1.e-6);       /* from microsec to sec */
         if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
            MEMSIP_free( &param.val );
      }
   }
   else {

      pt = param.val;
      nchar = strlen( pt );
      for ( cc=0, fill_flag_1=FALSE; cc<nchar; cc++ ) {
         if ( pt[ cc ] != ' ' ) {
            fill_flag_1 = TRUE;
            break;
         }
      }

      if ( fill_flag_1 ) {
         IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec =
            (float)atof( param.val ) * (1.e-3);     /* from millisec to sec */
         if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
            MEMSIP_free( &param.val );
      }
      else {

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         param.tag = RANGE_GATE_AT_EARLY_EDGE;
         TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ZERO_DOPP_RANGE_FIRST_TIME;
            *status_code = STC( ERRSID_normal );
         }
         else {
            IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec =
               (float)atof( param.val ) * (1.e-6);    /* from microsec to sec */
            if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
               MEMSIP_free( &param.val );
         }
      }
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = PRF;      /* pulse rep. freq. */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = PRF;             
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz =
	 (float) atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = PRF_EQUIVALENT;     /* equivalent prf */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC( ERRSID_normal );

      pt = IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthFirstLine_UTC;
      nchar = strlen( pt );
      for ( cc=0, fill_flag_1=FALSE; cc<nchar; cc++ ) {
         if ( pt[ cc ] != ' ' ) {
            fill_flag_1 = TRUE;
            break;
         }
      }
      pt = IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthLastLine_UTC;
      nchar = strlen( pt );
      for ( cc=0, fill_flag_2=FALSE; cc<nchar; cc++ ) {
         if ( pt[ cc ] != ' ' ) {
            fill_flag_2 = TRUE;
            break;
         }
      }

      if ( fill_flag_1 && fill_flag_2 ) {
	 double                 tStart;
	 double                 tEnd;

/* ==========================================================================
   Evaluate the equivalent PRF for real data
   ========================================================================== */
         LDEFIP_DATE_JDate( IANNIV_ImageAnnot[
				imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                            &tStart, status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
	 tStart *= 86400.0;

	 LDEFIP_DATE_JDate( IANNIV_ImageAnnot[
				imanum ].ZeroDopplerAzimuthLastLine_UTC,
			    &tEnd, status_code );
	 ERRSIM_on_err_goto_exit( *status_code );
	 tEnd *= 86400.0;

	 IANNIV_ImageAnnot[ imanum ].EquivalentPulseRepetitionFreq_Hz = (float)
	    ( (float)( IANNIV_ImageAnnot[ imanum ].ImageLength - 1.0 ) /
	      ( tEnd - tStart ) );
      }
      else {
	 IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = PRF_EQUIVALENT;
      }
   }
   else {
      IANNIV_ImageAnnot[ imanum ].EquivalentPulseRepetitionFreq_Hz =
	 (float) atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CROSS_DOPP_FREQ_CONST; /* first coeff. of the doppler centr. */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = CROSS_DOPP_FREQ_CONST;
      *status_code = STC( ERRSID_normal );
   }
   else {

/* ==========================================================================
   Check the validity of the string
   ========================================================================== */
      IANNPP_GETP_CheckValidTag ( param.val, &valid_flag, status_code );
      if ( valid_flag ) {
         IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ 0 ] =
            (float)atof( param.val );
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CROSS_DOPP_FREQ_LINEAR; /* second coeff. of the doppler centr. */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = CROSS_DOPP_FREQ_LINEAR;
      *status_code = STC( ERRSID_normal );
   }
   else {

/* ==========================================================================
   Check the validity of the string
   ========================================================================== */
      IANNPP_GETP_CheckValidTag ( param.val, &valid_flag, status_code );
      if ( valid_flag ) {
         IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ 1 ] =
            (float)atof( param.val );
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CROSS_DOPP_FREQ_QUAD; /* third coeff. of the doppler centr. */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = CROSS_DOPP_FREQ_QUAD;
      *status_code = STC( ERRSID_normal );
   }
   else {

/* ==========================================================================
   Check the validity of the string
   ========================================================================== */
      IANNPP_GETP_CheckValidTag ( param.val, &valid_flag, status_code );
      if ( valid_flag ) {
         IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ 2 ] =
            (float)atof( param.val );
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = DOPPL_CENTR_CUB_COEFF;  /* fourth coeff. of the doppler centr. */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = DOPPL_CENTR_CUB_COEFF;
      *status_code = STC( ERRSID_normal );
   }
   else {

/* ==========================================================================
   Check the validity of the string
   ========================================================================== */
      IANNPP_GETP_CheckValidTag ( param.val, &valid_flag, status_code );
      if ( valid_flag ) {
         IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ 3 ] =
            (float)atof( param.val );
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Ellipsoid section
   ========================================================================== */
/* GRV - 15-jul-97 Eliminated the EllipsoidType read */
/*
   param.tag = ELLIPSOID_DESIGNATOR; */     /* ellipsoid name */
/*
   TIFSIP_get_par( chan, img, &param, status_code );
   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ELLIPSOID_DESIGNATOR;
      *status_code = STC( ERRSID_normal );
   }
   else {
      ptr = param.val;
      strupr ( ptr );

      IANNIV_ImageAnnot[ imanum ].EllipsoidType = IANNIE_ell_undef;
      comp = -1;
*/
      /* GEM6 ellipsoid */
/*
      comp = LDEFIF_UTIL_strnmatch( ell[ 0 ], ptr, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == 0 )
         IANNIV_ImageAnnot[ imanum ].EllipsoidType = IANNIE_ell_GEM6;
*/
      /* WGS84 ellipsoid */
/*
      comp = LDEFIF_UTIL_strnmatch( ell[ 1 ], ptr, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == 0 )
         IANNIV_ImageAnnot[ imanum ].EllipsoidType = IANNIE_ell_WGS84;
*/
      /* International 1909 ellipsoid */
/*
      comp = LDEFIF_UTIL_strnmatch( ell[ 2 ], ptr, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == 0 )
         IANNIV_ImageAnnot[ imanum ].EllipsoidType = IANNIE_ell_International;
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }
*/

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = ELLIPSOID_SEMIMAJOR_AXIS;    /* semimaj. axis */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ELLIPSOID_SEMIMAJOR_AXIS;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m =
         (float)atof( param.val ) * ( 1.e+3 );                  /* from km to meters */
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = ELLIPSOID_SEMIMINOR_AXIS;                  /* semimin. axis */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ELLIPSOID_SEMIMINOR_AXIS;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m =
         (float)atof( param.val ) * ( 1.e+3 );                  /* from km to meters */
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   State vectors section
   ========================================================================== */
   param.tag = TIME_INTERVAL_DATA_POINT;       /* state vectors time interval */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = TIME_INTERVAL_DATA_POINT;  
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec =
	 (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = NB_DATA_POINTS;      /* number of state vectors */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = NB_DATA_POINTS;  
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].NStateVectors = (INTx1)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

   if ( IANNIV_ImageAnnot[ imanum ].NStateVectors > 0 ) {

      /* retrive the state vectors */
      for (i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++) {

/* ==========================================================================
         Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         /* x state vectors */
         param.tag = (X_SAT_1+i);            /* satellites x position */
         TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = (X_SAT_1+i);     
            *status_code = STC( ERRSID_normal );
         }
         else {
            IANNIV_ImageAnnot[ imanum ].X_STVec_m[ i ] = atof( param.val );
            if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
	       MEMSIP_free( &param.val );
         }
      }
      for (i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++) {


/* ==========================================================================
         Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         /* y state vectors */
         param.tag = (Y_SAT_1+i);            /* satellites y position */
         TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = (Y_SAT_1+i);     
            *status_code = STC( ERRSID_normal );
         }
         else {
            IANNIV_ImageAnnot[ imanum ].Y_STVec_m[ i ] = atof( param.val );
            if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
	       MEMSIP_free( &param.val );
         }
      }
      for (i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++) {


/* ==========================================================================
         Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         /* z state vectors */
         param.tag = (Z_SAT_1+i);            /* satellites z position */
         TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = (Z_SAT_1+i);     
            *status_code = STC( ERRSID_normal );
         }
         else {
            IANNIV_ImageAnnot[ imanum ].Z_STVec_m[ i ] = atof( param.val );
            if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
	       MEMSIP_free( &param.val );
         }
      }
      for (i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++) {


/* ==========================================================================
         Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         /* vx state vectors */
         param.tag = (VX_SAT_1+i);            /* satellites x velocity */
         TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = (VX_SAT_1+i);    
            *status_code = STC( ERRSID_normal );
         }
         else {
            IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[ i ] = atof( param.val );
            if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
	       MEMSIP_free( &param.val );
         }
      }
      for (i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++) {


/* ==========================================================================
         Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         /* vy state vectors */
         param.tag = (VY_SAT_1+i);            /* satellites y velocity */
         TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = (VY_SAT_1+i);    
            *status_code = STC( ERRSID_normal );
         }
         else {
            IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[ i ] = atof( param.val );
            if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
	       MEMSIP_free( &param.val );
         }
      }
      for (i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++) {


/* ==========================================================================
         Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         /* vz state vectors */
         param.tag = (VZ_SAT_1+i);            /* satellites z velocity */
         TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = (VZ_SAT_1+i);    
            *status_code = STC( ERRSID_normal );
         }
         else {
            IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[ i ] = atof( param.val );
            if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
	       MEMSIP_free( &param.val );
         }
      }
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Resampling factors
   ========================================================================== */
   param.tag = X_SCALE_FACTOR;      /* zoom factor in the column direction */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = X_SCALE_FACTOR;
      *status_code = STC( ERRSID_normal );
      IANNIV_ImageAnnot[ imanum ].XScalingFactor = (float) 1.;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].XScalingFactor = (float) atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }
   
/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = Y_SCALE_FACTOR;      /* zoom factor in the row direction */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = Y_SCALE_FACTOR;
      *status_code = STC( ERRSID_normal );
      IANNIV_ImageAnnot[ imanum ].YScalingFactor = (float) 1.;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].YScalingFactor = (float) atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Ground to slant parameters section
   ========================================================================== */
   if ( IANNIV_ImageAnnot[ imanum ].MapProjectionType == IANNIE_proj_ground ) {

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = GR_SR_POL_DEGREE;      /* degree of the polynomial */
      TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
	 IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = GR_SR_POL_DEGREE;
	 *status_code = STC( ERRSID_normal );
      }
      else {
	 IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree =
	    (INTx1)atoi( param.val );
	 if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
	    MEMSIP_free( &param.val );

	 if ( IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree > 0 ) {

/* ==========================================================================
   Search for the coefficients
   ========================================================================== */
	    for ( i=0; i<=IANNIV_ImageAnnot[imanum].GroundToSlantDegree;i++ ) {

/* ==========================================================================
               Do not dump errors to terminal, if any
   ========================================================================== */
               ERRSIV_dump_error = 0;

	       /* ground to slant coeff of polynomials */
	       param.tag = (GR_SR_COEFF_1+i);
	       TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
               Reset dumping
   ========================================================================== */
               ERRSIV_dump_error = 1;

	       if ( *status_code != ERRSID_normal ) {
		  IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = (GR_SR_COEFF_1+i);
		  *status_code = STC( ERRSID_normal );
	       }
	       else {

/* ==========================================================================
   Check the validity of the string
   ========================================================================== */
                  IANNPP_GETP_CheckValidTag ( param.val, &valid_flag,
                                              status_code );
                  if ( valid_flag ) {

                     /* read the parameter */
                     IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff[ i ] =
                        (double)atof( param.val );
	          }
		  if ( (TIFSIV_Size[ param.type ] * param.length) > 4 ) {
		     MEMSIP_free( &param.val );
                  }
	       }
	    }
	 }
      }
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Sub image coordinates of the top left image corner
   ========================================================================== */
   param.tag = SUBIMG_TOP_LEFT_ROW;              /* row coordinate */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = SUBIMG_TOP_LEFT_ROW;  
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow =
         (INTx4)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = SUBIMG_TOP_LEFT_COL;              /* col coordinate */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = SUBIMG_TOP_LEFT_COL;  
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol =
         (INTx4)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Processing info
   ========================================================================== */
   param.tag = PIXEL_TYPE;                     /* pixel type indicator */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {

/* ==========================================================================
   Switch over the image type
   ========================================================================== */
      switch ( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {
         case IANNIE_proj_UTM:
         case IANNIE_proj_UPS:
         case IANNIE_proj_ground:
            IANNIV_ImageAnnot[ imanum ].PixelType = IANNIE_pixt_amplitude;
         break;
         case IANNIE_proj_slant:
            IANNIV_ImageAnnot[ imanum ].PixelType = IANNIE_pixt_complex;
         break;
         default:
            IANNIV_ImageAnnot[ imanum ].PixelType = IANNIE_pixt_undef;
            IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = PIXEL_TYPE;
            *status_code = STC( ERRSID_normal );
      }
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = PIXEL_TYPE;
      *status_code = STC( ERRSID_normal );
   }
   else {
      ptr = param.val;
      strupr( ptr );

      IANNIV_ImageAnnot[ imanum ].PixelType = IANNIE_pixt_undef;
      comp = -1;
      comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_pixt[ 0 ], ptr, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == -2 ) {
         memset ( sst, '\0', LDEFID_char_num );
         sprintf ( sst, "%s%s%0u", LDEFIV_ERRS_error_message[
                   ERRSID_LDEF_first_longer ], " for the tag: ",
                   PIXEL_TYPE );
         ERRSIM_print_warning ( sst );
      }
      else {

         if ( comp == 0 )                /* complex product */
            IANNIV_ImageAnnot[ imanum ].PixelType = IANNIE_pixt_complex;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_pixt[ 1 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                /* complex product */
            IANNIV_ImageAnnot[ imanum ].PixelType = IANNIE_pixt_amplitude;

         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_pixt[ 2 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 )                /* complex product */
            IANNIV_ImageAnnot[ imanum ].PixelType = IANNIE_pixt_power;
      }
      if ( (TIFSIV_Size[ param.type ]*param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = SCALING_FACTOR;                    /* scaling factor */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = SCALING_FACTOR;
      *status_code = STC( ERRSID_normal );
      IANNIV_ImageAnnot[ imanum ].ScalingFactor = (float) 1.;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].ScalingFactor = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = NOM_NB_LOOKS_AZIM;               /* azimuth looks number */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = NOM_NB_LOOKS_AZIM;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].LooksNumber = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = NORMALISATION_REF_RANGE;         /* reference slant range */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

#ifdef __NOT_HARDCODED__
   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = NORMALISATION_REF_RANGE;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].ReferenceSlantRange_m =
         (float)atof( param.val ) * ( 1.e+3 );                      /* from km to m  */
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }
#endif

/* ==========================================================================
   Set the Reference Slant Range to the default value
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum ].ReferenceSlantRange_m = 
      IANNPD_reference_slant_range_m;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = REPLICA_POWER;                   /* Pulse Replica Power */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = REPLICA_POWER;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].ProductReplicaPower = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CHIRP_AVERAGE_DENSITY;           /* chirp average density */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = CHIRP_AVERAGE_DENSITY;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].ChirpAverageDensity = (float)atof( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = PROC_HISTORY;                    /* processing history */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = PROC_HISTORY;
      *status_code = STC( ERRSID_normal );
      memset( IANNIV_ImageAnnot[ imanum ].ProcessingHistory, '\0',
	      (size_t)(IANNID_histo_sect * IANNID_sect_size * sizeof( char )) );
   }
   else {
      strcpy( IANNIV_ImageAnnot[ imanum ].ProcessingHistory,
              (char *)param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Flags about the processing steps
   ========================================================================== */
   param.tag = ANTENNA_ELEVATION_GAIN_FLAG;          /* antenna pattern appl. */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ANTENNA_ELEVATION_GAIN_FLAG;
      *status_code = STC( ERRSID_normal );
   }
   else {
      int_bool = 0;
      IANNIV_ImageAnnot[ imanum ].AntennaPatternCorrectionFlag = -1;
      if ( sscanf( (char *)param.val, "%d", &int_bool ) == 1 ) {
	 IANNIV_ImageAnnot[ imanum ].AntennaPatternCorrectionFlag = int_bool;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = SPREAD_LOSS_COMP_FLAG;           /* range spreading loss appl. */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = SPREAD_LOSS_COMP_FLAG;
      *status_code = STC( ERRSID_normal );
   }
   else {
      int_bool = 0;
      IANNIV_ImageAnnot[ imanum ].RangeSpreadingLossCompensationFlag = -1;
      if ( sscanf( (char *)param.val, "%d", &int_bool ) == 1 ) {
	 IANNIV_ImageAnnot[ imanum ].RangeSpreadingLossCompensationFlag = int_bool;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CALIB_CONST_APPLI_FLAG;          /* calibration constant appl. */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = CALIB_CONST_APPLI_FLAG;
      *status_code = STC( ERRSID_normal );
   }
   else {
      int_bool = 0;
      IANNIV_ImageAnnot[ imanum ].CalibrationConstantApplicationFlag = -1;
      if ( sscanf( (char *)param.val, "%d", &int_bool ) == 1 ) {
	 IANNIV_ImageAnnot[ imanum ].CalibrationConstantApplicationFlag =
	    int_bool;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = ADC_SATUR_COMPENS_FLAG;                /* ADC saturation comp. */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ADC_SATUR_COMPENS_FLAG;
      *status_code = STC( ERRSID_normal );
   }
   else {
      int_bool = 0;
      IANNIV_ImageAnnot[ imanum ].ADCSaturationCompensationFlag = -1;
      if ( sscanf( (char *)param.val, "%d", &int_bool ) == 1) {
	 IANNIV_ImageAnnot[ imanum ].ADCSaturationCompensationFlag = int_bool;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = REPLICA_POWER_COMP_FLAG;                /* Replica Powert comp. */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      /* set to not applied */
      IANNIV_ImageAnnot[ imanum ].ReplicaPowerCompensationFlag = FALSE;
      *status_code = STC( ERRSID_normal );
   }
   else {
      int_bool = 0;
      IANNIV_ImageAnnot[ imanum ].ReplicaPowerCompensationFlag = -1;
      if ( sscanf( (char *)param.val, "%d", &int_bool ) == 1) {
	 IANNIV_ImageAnnot[ imanum ].ReplicaPowerCompensationFlag = int_bool;
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Co-registration INFO
   ========================================================================== */
   param.tag = MASTER_REFERENCE_NUMBER;      /* orbit and frame of the master */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = MASTER_REFERENCE_NUMBER;
      *status_code = STC( ERRSID_normal );
   }
   else {
      sprintf( IANNIV_ImageAnnot[ imanum ].MasterSceneReference,
	       (char *)param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Get IMAGE_SCALE tag
   ========================================================================== */
   param.tag = IMAGE_SCALE;
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_ImageAnnot[ imanum ].ImageScale = IANNIE_iscale_linear;
   }
   else {
      ptr = param.val;
      strupr( ptr );

      IANNIV_ImageAnnot[ imanum ].ImageScale = IANNIE_iscale_undef;
      comp = -1;
      comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_iscale[ 0 ], ptr, status_code );
      ERRSIM_on_err_goto_exit ( *status_code ); 
      if( comp == 0 ) {
         IANNIV_ImageAnnot[ imanum ].ImageScale = IANNIE_iscale_linear;
      }
      else {
         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_iscale[ 1 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if( comp == 0 ) {
            IANNIV_ImageAnnot[ imanum ].ImageScale = IANNIE_iscale_db;
         }
      }
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Sub image coordinates of the top left image corner
   ========================================================================== */
   param.tag = ROW_TRANSIENT;              /* row transient */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = ROW_TRANSIENT;  
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].RowTransient=
         (INTx4)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = COL_TRANSIENT;              /* column transient */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_NotFoundTags[ imanum ][ tag_notf++ ] = COL_TRANSIENT;  
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].ColTransient=
         (INTx4)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Get PRESENTATION tag
   ========================================================================== */
   param.tag = PRESENTATION;
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNIV_ImageAnnot[ imanum ].Presentation = IANNIE_pres_normal;
      *status_code = STC( ERRSID_normal );
   }
   else {
      ptr = param.val;
      strupr( ptr );

      IANNIV_ImageAnnot[ imanum ].Presentation = IANNIE_pres_undef;
      comp = -1;
      comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_pres[ 0 ], ptr, status_code );
      ERRSIM_on_err_goto_exit ( *status_code ); 
      if( comp == 0 ) {
         IANNIV_ImageAnnot[ imanum ].Presentation = IANNIE_pres_normal;
      }
      else {
         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_pres[ 1 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if( comp == 0 ) {
            IANNIV_ImageAnnot[ imanum ].Presentation = IANNIE_pres_geo;
         }
      }
   }

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Get ORBIT_DIRECTION tag
   ========================================================================== */
   param.tag = ORBIT_DIRECTION;
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      if( IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[ 0 ] > 0.0 ) {
         IANNIV_ImageAnnot[ imanum ].OrbitDirection = IANNIE_orbit_ascend;
      }
      else {
         IANNIV_ImageAnnot[ imanum ].OrbitDirection = IANNIE_orbit_descend;
      }
      *status_code = STC( ERRSID_normal );
   }
   else {
      ptr = param.val;
      strupr( ptr );

      IANNIV_ImageAnnot[ imanum ].OrbitDirection = IANNIE_orbit_undef;
      comp = -1;
      comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_orbdir[ 0 ], ptr, status_code );
      ERRSIM_on_err_goto_exit ( *status_code ); 
      if( comp == 0 ) {
         IANNIV_ImageAnnot[ imanum ].OrbitDirection = IANNIE_orbit_ascend;
      }
      else {
         comp = LDEFIF_UTIL_strnmatch( (char *)IANNPC_orbdir[ 1 ], ptr, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if( comp == 0 ) {
            IANNIV_ImageAnnot[ imanum ].OrbitDirection = IANNIE_orbit_descend;
         }
      }
   }

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

/* ==========================================================================
   Check the tags values in their range of validity
   ========================================================================== */
   IANNPP_GETP_TagsCheck( imanum, &tag_notv, IANNIV_InvalidTags[ imanum ], status_code );
   ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
   fprintf ( stdout, "\n\n\n *** Not Founded Tags:\n\n" );
   for ( i=0; i<tag_notf; i++ ) {
      fprintf ( stdout, "\n Tag number: %d", IANNIV_NotFoundTags[ imanum ][ i ] );
   }
   fprintf ( stdout, "\n\n\n *** Invalid tags:\n\n" );
   for ( i=0; i<tag_notv; i++ ) {
      fprintf ( stdout, "\n Tag number: %d", IANNIV_InvalidTags[ imanum ][ i ] );
   }
#endif

/* ==========================================================================
   Check if the tags not found are necessary to the calling tool
   ========================================================================== */
   for ( j=1;j<=IANNPC_necessary_tag[ task_descr ][ proj_descr ][ 0 ];j++ ) {


      /* not found tags */
      for ( i=0;i<tag_notf;i++ ) {
         if ( IANNIV_NotFoundTags[ imanum ][ i ] == 
              IANNPC_necessary_tag[ task_descr ][ proj_descr ][ j ] ) {
            sprintf( tag_num, "%u", 
               IANNPC_necessary_tag[ task_descr ][ proj_descr ][ j ]);
            ERRSIM_set_error( status_code, ERRSID_IANN_tag_not_found,
                              tag_num );
         }
      }

      /* invalid tags */
      for ( i=0; i<tag_notv; i++ ) {
         if ( IANNIV_InvalidTags[ imanum ][ i ] == 
              IANNPC_necessary_tag[ task_descr ][ proj_descr ][ j ] ) {
            sprintf( tag_num, "%u", 
               IANNPC_necessary_tag[ task_descr ][ proj_descr ][ j ]);
            ERRSIM_set_error( status_code, ERRSID_IANN_tag_invalid,
                              tag_num );
         }
      }
   }

error_exit:;


/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

/* ==========================================================================
   Free the eventually param structure left allocated
   ========================================================================== */
   MEMSIP_free( &param.val );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IANNIP_GETP_ImageAnnot */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_GETP_TagsCheck

        $TYPE         PROCEDURE

        $INPUT        imanum	    : number of the image among that of the
                                      tool

        $MODIFIED     NONE

        $OUTPUT       invalid_tags  : pointer to the array with the tags that
                                      are invalid in their range of variation
                      count	    : counter of the invalid tags

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the image
                                                  annotations

        $RET_STATUS   ERRSID_IANN_not_allow_imanum

        $DESCRIPTION  This procedure checks if the tags annotated are in their
                      range of validity

        $WARNING      The check has no validity for the tags that are not
                      found; so the use of the vector of invalid tags must
                      always follow the check on the found tags

   $EH
   ========================================================================== */

void IANNPP_GETP_TagsCheck
                        (/*IN    */ UINTx1               imanum,
                         /*   OUT*/ UINTx4              *count,
                         /*   OUT*/ UINTx4              *invalid_tags,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNPP_GETP_TagsCheck";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 tag;
   char                   numb[ 4 ] = "";
   char			  FirstDateStr[ 25 ] = "27-JUL-1991 21:40:47.000";
   char			  LastDateStr[ 25 ] = "31-DEC-2050 23:59:59.0000";
   char                   FirstSTVectDate[ 25 ] = "";
   double		  DeltaTime = 0;
   double		  FirstSTVectDeltaTime_1 = 0;
   double		  FirstSTVectDeltaTime_2 = 0;
   double		  FirstDeltaTime = 0;
   double		  LastDeltaTime = 0;
   LDEFIT_boolean	  flag_tag_1 = FALSE;
   LDEFIT_boolean	  flag_tag_2 = FALSE;
   INTx2                  Hour;
   INTx2                  Min;
   float                  Sec;
   INTx4                  cc;
   char                  *pt = (char *)NULL;
   INTx4                  nchar;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image index
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) {
      sprintf( numb, "%u", imanum );
      ERRSIM_set_error( status_code, ERRSID_IANN_not_allow_imanum, numb );
   }

/* ==========================================================================
   General INFO section
   ========================================================================== */
   if ( IANNIV_ImageAnnot[ imanum ].ProductType == IANNIE_prod_undef )
      invalid_tags[ (*count)++ ] = LOG_VOL_ID;

   if( !strcmp( IANNIV_ImageAnnot[ imanum ].SceneReferenceNumbers, "" ) )
      invalid_tags[ (*count)++ ] = SCENE_REF_NUM;

   if ( IANNIV_ImageAnnot[ imanum ].ProcessingPAF == IANNIE_proc_undef )
      invalid_tags[ (*count)++ ] = PROCESSING_PAF;

   if ( IANNIV_ImageAnnot[ imanum ].ProcessorName == IANNIE_sproc_undef )
      invalid_tags[ (*count)++ ] = PROCESSOR_NAME;

/* ==========================================================================
   Calibration section
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ imanum ].CalibrationConstant < 1.e+4 ) ||
        ( IANNIV_ImageAnnot[ imanum ].CalibrationConstant > 2.e+6 ) )
      invalid_tags[ (*count)++ ] = ABSOLUTE_CALIB_K;

   if ( ( IANNIV_ImageAnnot[ imanum ].IncidenceAngleAtMiddleRange_deg < 19. ) ||
        ( IANNIV_ImageAnnot[ imanum ].IncidenceAngleAtMiddleRange_deg > 26. ) )
      invalid_tags[ (*count)++ ] = INCID_ANGLE_CENTRE_RANGE;

   if ( ( IANNIV_ImageAnnot[ imanum ].BoresightAngle_deg < 19. ) ||
        ( IANNIV_ImageAnnot[ imanum ].BoresightAngle_deg > 22. ) )
      invalid_tags[ (*count)++ ] = ANTENNA_BORESIGHT;

/* ==========================================================================
   Corners coordinates section
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ imanum ].TopLeftLat_deg < -90. ) ||
        ( IANNIV_ImageAnnot[ imanum ].TopLeftLat_deg > 90. ) )
      invalid_tags[ (*count)++ ] = TOP_LEFT_LAT;

   if ( ( IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg < -180. ) ||
        ( IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg > 180. ) )
      invalid_tags[ (*count)++ ] = TOP_LEFT_LON;

   if ( ( IANNIV_ImageAnnot[ imanum ].TopRightLat_deg < -90. ) ||
        ( IANNIV_ImageAnnot[ imanum ].TopRightLat_deg > 90. ) )
      invalid_tags[ (*count)++ ] = TOP_RIGHT_LAT;

   if ( ( IANNIV_ImageAnnot[ imanum ].TopRightLon_deg < -180. ) ||
        ( IANNIV_ImageAnnot[ imanum ].TopRightLon_deg > 180. ) )
      invalid_tags[ (*count)++ ] = TOP_RIGHT_LON;

   if ( ( IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg < -90. ) ||
        ( IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg > 90. ) )
      invalid_tags[ (*count)++ ] = BOTTOM_LEFT_LAT;

   if ( ( IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg < -180. ) ||
        ( IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg > 180. ) )
      invalid_tags[ (*count)++ ] = BOTTOM_LEFT_LON;

   if ( ( IANNIV_ImageAnnot[ imanum ].BottomRightLat_deg < -90. ) ||
        ( IANNIV_ImageAnnot[ imanum ].BottomRightLat_deg > 90. ) )
      invalid_tags[ (*count)++ ] = BOTTOM_RIGHT_LAT;

   if ( ( IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg < -180. ) ||
        ( IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg > 180. ) )
      invalid_tags[ (*count)++ ] = BOTTOM_RIGHT_LON;

   if ( ( IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg < -90. ) ||
        ( IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg > 90. ) )
      invalid_tags[ (*count)++ ] = CENTRE_GEODETIC_LAT;

   if ( ( IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg < -180. ) ||
        ( IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg > 180. ) )
      invalid_tags[ (*count)++ ] = CENTRE_GEODETIC_LON;

   if ( IANNIV_ImageAnnot[ imanum ].TopZeroFilledLines > 1000 )
      invalid_tags[ (*count)++ ] = EARLY_ZERO_FILL_RECORD_NUMBER;

   if ( IANNIV_ImageAnnot[ imanum ].BottomZeroFilledLines > 1000 )
      invalid_tags[ (*count)++ ] = LATE_ZERO_FILL_RECORD_NUMBER;

   if ( IANNIV_ImageAnnot[ imanum ].LeftZeroFilledPixels > 1000 )
      invalid_tags[ (*count)++ ] = NEAR_ZERO_FILL_PIXEL_NUMBER;

   if ( IANNIV_ImageAnnot[ imanum ].RightZeroFilledPixels > 1000 )
      invalid_tags[ (*count)++ ] = FAR_ZERO_FILL_PIXEL_NUMBER;

/* ==========================================================================
   MAP Projection section
   ========================================================================== */
   switch ( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {
      case IANNIE_proj_UTM:
         if ( ( IANNIV_ImageAnnot[ imanum ].ProjectionScaleFactor < 0. ) ||
              ( IANNIV_ImageAnnot[ imanum ].ProjectionScaleFactor > 1. ) )
            invalid_tags[ (*count)++ ] = UTM_SCALE_FACTOR;
         if ( ( IANNIV_ImageAnnot[ imanum ].ProjectionCentralParallel_deg <
                -90. ) ||
              ( IANNIV_ImageAnnot[ imanum ].ProjectionCentralParallel_deg >
                90. ) )
            invalid_tags[ (*count)++ ] = UTM_CENTER_PROJ_LAT;
         if ( ( IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg <
                -180. ) ||
              ( IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg >
                180. ) )
            invalid_tags[ (*count)++ ] = UTM_CENTER_PROJ_LON;
      break;
      case IANNIE_proj_UPS:
         if ( ( IANNIV_ImageAnnot[ imanum ].ProjectionScaleFactor < 0. ) ||
              ( IANNIV_ImageAnnot[ imanum ].ProjectionScaleFactor > 1. ) )
            invalid_tags[ (*count)++ ] = UPS_SCALE_FACTOR;
         if ( ( IANNIV_ImageAnnot[ imanum ].ProjectionCentralParallel_deg <
                -90. ) ||
              ( IANNIV_ImageAnnot[ imanum ].ProjectionCentralParallel_deg >
                90. ) )
            invalid_tags[ (*count)++ ] = UPS_CENTER_PROJ_LAT;
         if ( ( IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg <
                -180. ) ||
              ( IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg >
                180. ) )
            invalid_tags[ (*count)++ ] = UPS_CENTER_PROJ_LON;
      break;
      case IANNIE_proj_undef:
         invalid_tags[ (*count)++ ] = MAP_PROJ_DESCR;
      break;
   }

/* ==========================================================================
   Spacing
   ========================================================================== */
   if ( IANNIV_ImageAnnot[ imanum ].LineSpacing_m < 0. )
      invalid_tags[ (*count)++ ] = LINE_SPACING;

   if ( IANNIV_ImageAnnot[ imanum ].PixelSpacing_m < 0. )
      invalid_tags[ (*count)++ ] = PIXEL_SPACING;

/* ==========================================================================
   Timing section
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ imanum ].FirstSTVectYear < 1991 ) ||
        ( IANNIV_ImageAnnot[ imanum ].FirstSTVectYear > 2050 ) )
      invalid_tags[ (*count)++ ] = YEAR_DATA_POINT;

   if ( ( IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth < 1 ) ||
	( IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth > 12 ) )
      invalid_tags[ (*count)++ ] = MONTH_DATA_POINT;

   if ( ( IANNIV_ImageAnnot[ imanum ].FirstSTVectDay < 1 ) ||
        ( IANNIV_ImageAnnot[ imanum ].FirstSTVectDay > 31 ) )
      invalid_tags[ (*count)++ ] = DAY_DATA_POINT;

   if ( ( IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds < 0. ) ||
        ( IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds > 8.64e+4 ) )
      invalid_tags[ (*count)++ ] = SECOND_OF_DAY;

   /* check on the first stvect time */
   if ( ( ( IANNIV_ImageAnnot[ imanum ].FirstSTVectYear >= 1991 ) &&
          ( IANNIV_ImageAnnot[ imanum ].FirstSTVectYear <= 2050 ) ) &&
        ( ( IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth >= 1 ) &&
          ( IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth <= 12 ) ) &&
	( ( IANNIV_ImageAnnot[ imanum ].FirstSTVectDay >= 1 ) &&
          ( IANNIV_ImageAnnot[ imanum ].FirstSTVectDay <= 31 ) ) &&
        ( ( IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds >= 0. ) &&
        ( IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds <= 8.64e+4 ) ) ) {

      /* evaluate the hour, min and sec */
      Hour = (INTx2)(IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds / 3600.);
      Min = (INTx2)(( (float)(IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds /
	 3600.) - (float)Hour ) * 60);
      Sec = IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds -
	 (float)(Hour * 3600.) - (float)(Min * 60.);

      if( Sec < 1.e-3 ) {
         Sec = 0.0;
      }
 
      /* write the date in a string */
      sprintf( FirstSTVectDate, "%02d-%3s-%4d %02d:%02d:%06.3f",
	       IANNIV_ImageAnnot[ imanum ].FirstSTVectDay,  /* day */
	       LDEFIC_MonName[ ( IANNIV_ImageAnnot[ 
		  imanum ].FirstSTVectMonth - 1 ) ],	    /* month */
	       IANNIV_ImageAnnot[ imanum ].FirstSTVectYear, /* Year */
	       Hour, Min, Sec );			    /* hh:mm:ss.sss */

      /* evaluate the difference WRT the first valid time ... */
      LDEFIP_DATE_DiffDate( FirstSTVectDate, FirstDateStr,
			    &FirstSTVectDeltaTime_1, status_code );

      /* ... and the last */
      LDEFIP_DATE_DiffDate( LastDateStr, FirstSTVectDate,
                            &FirstSTVectDeltaTime_2, status_code );

      /* check the time range */
      if ( ( FirstSTVectDeltaTime_1 < 0. ) ||
	   ( FirstSTVectDeltaTime_2 < 0. ) ) {
	 invalid_tags[ (*count)++ ] = YEAR_DATA_POINT;
	 invalid_tags[ (*count)++ ] = MONTH_DATA_POINT;
	 invalid_tags[ (*count)++ ] = DAY_DATA_POINT;
	 invalid_tags[ (*count)++ ] = SECOND_OF_DAY;
      }
   }

   pt = IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthFirstLine_UTC;
   nchar = strlen( pt );
   for ( cc=0, flag_tag_1=FALSE; cc<nchar; cc++ ) {
      if ( pt[ cc ] != ' ' ) {
         flag_tag_1= TRUE;
         break;
      }
   }

   if( flag_tag_1 ) {

      /* evaluate the days from start */
      LDEFIP_DATE_DiffDate(
         IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthFirstLine_UTC,
         FirstDateStr, &FirstDeltaTime, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      /* evaluates the days to end ! */
      LDEFIP_DATE_DiffDate( LastDateStr,
       			    IANNIV_ImageAnnot[
			       imanum ].ZeroDopplerAzimuthFirstLine_UTC,
		           &LastDeltaTime, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      /* check */
      if ( ( FirstDeltaTime < 0. ) || ( LastDeltaTime < 0. ) )
         invalid_tags[ (*count)++ ] = ZERO_DOPP_AZIM_FIRST_TIME;

   }
   else {
      invalid_tags[ (*count)++ ] = ZERO_DOPP_AZIM_FIRST_TIME;
   }

   pt = IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthLastLine_UTC;
   nchar = strlen( pt );
   for ( cc=0, flag_tag_1=FALSE; cc<nchar; cc++ ) {
      if ( pt[ cc ] != ' ' ) {
         flag_tag_1 = TRUE;
         break;
      }
   }

   if( flag_tag_1 ) {

      /* evaluate the days from start */
      LDEFIP_DATE_DiffDate(
         IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthLastLine_UTC,
         FirstDateStr, &FirstDeltaTime, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      /* evaluates the days to end ! */
      LDEFIP_DATE_DiffDate( LastDateStr,
   			    IANNIV_ImageAnnot[
			       imanum ].ZeroDopplerAzimuthLastLine_UTC,
		            &LastDeltaTime, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      /* check */
      if ( ( FirstDeltaTime < 0. ) || ( LastDeltaTime < 0. ) )
         invalid_tags[ (*count)++ ] = ZERO_DOPP_AZIM_LAST_TIME;
   }
   else 
      invalid_tags[ (*count)++ ] = ZERO_DOPP_AZIM_LAST_TIME;

   pt = IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthFirstLine_UTC;
   nchar = strlen ( pt );
   for ( cc=0, flag_tag_1=FALSE; cc<nchar; cc++ ) {
      if ( pt[ cc ] != ' ' ) {
         flag_tag_1 = TRUE;
         break;
      }
   }
   pt = IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthLastLine_UTC;
   nchar = strlen ( pt );
   for ( cc=0, flag_tag_2=FALSE; cc<nchar; cc++ ) {
      if ( pt[ cc ] != ' ' ) {
         flag_tag_2 = TRUE;
         break;
      }
   }

   if( flag_tag_1 && flag_tag_2 ) {

      /* check the consistency between first and last time */
      LDEFIP_DATE_DiffDate( IANNIV_ImageAnnot[
			      imanum ].ZeroDopplerAzimuthLastLine_UTC,
			    IANNIV_ImageAnnot[
                               imanum ].ZeroDopplerAzimuthFirstLine_UTC,
			    &DeltaTime, status_code );

      /* check the consistency between first and last time */
      if ( DeltaTime <= 0 ) {
         for ( tag=0; tag<(*count); tag++ ) {
	    if ( invalid_tags[ tag ] == ZERO_DOPP_AZIM_FIRST_TIME )
	       flag_tag_1 = TRUE;
         }
         if ( !( flag_tag_1 ) )
	    invalid_tags[ (*count)++ ] = ZERO_DOPP_AZIM_FIRST_TIME;

         flag_tag_1 = FALSE;
         for ( tag=0; tag<(*count); tag++ ) {
	    if ( invalid_tags[ tag ] == ZERO_DOPP_AZIM_LAST_TIME )
	       flag_tag_1 = TRUE;
         }
         if ( !( flag_tag_1 ) )
	    invalid_tags[ (*count)++ ] = ZERO_DOPP_AZIM_LAST_TIME;
      }
   }

   if ( ( IANNIV_ImageAnnot[ imanum ].RadarWaveLength_m < 5.5e-2 ) ||
        ( IANNIV_ImageAnnot[ imanum ].RadarWaveLength_m > 5.8e-2 ) )
      invalid_tags[ (*count)++ ] = RADAR_WAVELEN;

   if ( ( IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz < 18.95e+6 ) ||
        ( IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz > 18.97e+6 ) )
      invalid_tags[ (*count)++ ] = SAMPLING_RATE;

   if ( ( IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec < 4.e-3 ) ||
        ( IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec > 7.e-3 ) )
      invalid_tags[ (*count)++ ] = ZERO_DOPP_RANGE_FIRST_TIME;

   if ( ( IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz < 1.e+3 ) ||
        ( IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz > 2.e+3 ) ) {
      IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz /= 1000.0;
      if ( ( IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz < 1.e+3 ) ||
           ( IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz > 2.e+3 ) ) {
         invalid_tags[ (*count)++ ] = PRF;
         IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz *= 1000.0;
      }
   }


   if ( ( IANNIV_ImageAnnot[imanum].EquivalentPulseRepetitionFreq_Hz< 0. ) ||
        ( IANNIV_ImageAnnot[imanum].EquivalentPulseRepetitionFreq_Hz> 2.e+3 ) )
      invalid_tags[ (*count)++ ] = PRF_EQUIVALENT;

/* ==========================================================================
   Doppler centroide coeff.
   ========================================================================== */

   if ( ( ( IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz >= 1.e+3 ) &&
          ( IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz <= 2.e+3 ) ) &&
        ( IANNIV_ImageAnnot[ imanum ].PixelSpacing_m > 0. ) ) {
      UINTx1     deg;
      double     time;
      UINTx4     col;
      UINTx2     Npoints  = 500;
      UINTx2     Step;
      double     freq;
      double     min_freq = 1.e+30;
      double     max_freq = -1.e+30;

      /* evaluate the loop step */
      Step = (UINTx2)( IANNIV_ImageAnnot[ imanum ].ImageWidth /
                       ( Npoints + 1 ) );

      /* fill the frequency vector */
      for ( col=0; col<Npoints; col++ ) {
         time =
            2.0 *                                            /* two ways time */
            ((double)( col * Step ) ) *                     /* wanted columns */
            ( IANNIV_ImageAnnot[imanum].PixelSpacing_m /CVEL ); /* delta time */

         /* polynomial evaluation */
         POLY( time, 3, IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec,
               freq );

         /* evaluate min and max */
         if ( freq < min_freq ) min_freq = freq;
         if ( freq > max_freq ) max_freq = freq;
      }

/* ==========================================================================
   Check the doppler coeff. validity
   ========================================================================== */
      if ( ( min_freq <
             -10. * IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz ) ||
           ( max_freq >
             10. * IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz ) ) {

/* ==========================================================================
   Set the fourth coefficient to invalid and try without it
   ========================================================================== */
         invalid_tags[ (*count)++ ] = DOPPL_CENTR_CUB_COEFF;

         /* fill the frequency vector */
         for ( col=0; col<Npoints; col++ ) {
            time =
               2.0 *                                         /* two ways time */
               ((double)( col * Step ) ) *                  /* wanted columns */
               ( IANNIV_ImageAnnot[imanum].PixelSpacing_m /     /* delta time */
               CVEL );

            /* polynomial evaluation */
            POLY( time, 2, IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec,
                  freq );

            /* evaluate min and max */
            if ( freq < min_freq ) min_freq = freq;
            if ( freq > max_freq ) max_freq = freq;
         }

/* ==========================================================================
   Check the doppler coeff. validity
   ========================================================================== */
         if ( ( min_freq <
                -10. * IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz ) ||
              ( max_freq >
                10. * IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz ) ) {
            invalid_tags[ (*count)++ ] = CROSS_DOPP_FREQ_QUAD;
            invalid_tags[ (*count)++ ] = CROSS_DOPP_FREQ_LINEAR;
            invalid_tags[ (*count)++ ] = CROSS_DOPP_FREQ_CONST;
         }
         else {

/* ==========================================================================
   Put to zero the fourth parameter
   ========================================================================== */
            IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ 3 ] = (float)0;
         }
      }
   }

/* ==========================================================================
   Ellipsoid section
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m < 6.3e+6 ) ||
        ( IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m > 6.4e+6 ) )
      invalid_tags[ (*count)++ ] = ELLIPSOID_SEMIMAJOR_AXIS;

   if ( ( IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m < 6.3e+6 ) ||
        ( IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m > 6.4e+6 ) )
      invalid_tags[ (*count)++ ] = ELLIPSOID_SEMIMINOR_AXIS;

/* ==========================================================================
   State vectors section
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec < 1.e-4 ) ||
        ( IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec > 1.e+2 ) )
      invalid_tags[ (*count)++ ] = TIME_INTERVAL_DATA_POINT;

   if ( ( IANNIV_ImageAnnot[ imanum ].NStateVectors < 2 ) ||
        ( IANNIV_ImageAnnot[ imanum ].NStateVectors > IANNID_NSTVECMAX ) )
      invalid_tags[ (*count)++ ] = NB_DATA_POINTS;

   if ( ( IANNIV_ImageAnnot[ imanum ].NStateVectors >=2 ) &&
        ( IANNIV_ImageAnnot[ imanum ].NStateVectors <= IANNID_NSTVECMAX ) ) {

      for ( tag=0; tag<IANNIV_ImageAnnot[ imanum ].NStateVectors; tag++ ) {
         float      norm = 0.;
         float      velo = 0.;

         /* check position state vector in its range of validity */
         norm = sqrt( POW( IANNIV_ImageAnnot[ imanum ].X_STVec_m[ tag ], 2. ) +
                      POW( IANNIV_ImageAnnot[ imanum ].Y_STVec_m[ tag ], 2. ) +
                      POW( IANNIV_ImageAnnot[ imanum ].Z_STVec_m[ tag ], 2. ) );

#ifdef __TRACE__
fprintf( stderr, "%f %f %f norm=%f\n", IANNIV_ImageAnnot[ imanum ].X_STVec_m[ tag ],
   IANNIV_ImageAnnot[ imanum ].Y_STVec_m[ tag ], IANNIV_ImageAnnot[ imanum ].Z_STVec_m[ tag ], norm );

         /* check position state vector in its range of validity */
         norm = sqrt( (IANNIV_ImageAnnot[ imanum ].X_STVec_m[ tag ] *
                       IANNIV_ImageAnnot[ imanum ].X_STVec_m[ tag ]) +
                      (IANNIV_ImageAnnot[ imanum ].Y_STVec_m[ tag ] *
                       IANNIV_ImageAnnot[ imanum ].Y_STVec_m[ tag ]) +
                      (IANNIV_ImageAnnot[ imanum ].Z_STVec_m[ tag ] *
                       IANNIV_ImageAnnot[ imanum ].Z_STVec_m[ tag ]) );

fprintf( stderr, "norm=%f\n", norm );
#endif


         if ( ( norm < 7.e+6 ) || ( norm > 7.3e+6 ) ) {
             invalid_tags[ (*count)++ ] = ( X_SAT_1 + tag );
             invalid_tags[ (*count)++ ] = ( Y_SAT_1 + tag );
             invalid_tags[ (*count)++ ] = ( Z_SAT_1 + tag );
         }

         /* check velocity state vectors in its range of validity */
         velo = sqrt( POW( IANNIV_ImageAnnot[
                              imanum ].VX_STVec_m_sec[ tag ], 2. ) +
                      POW( IANNIV_ImageAnnot[
                              imanum ].VY_STVec_m_sec[ tag ], 2. ) +
                      POW( IANNIV_ImageAnnot[
                              imanum ].VZ_STVec_m_sec[ tag ], 2. ) );

         if ( ( velo < 4.e+3 ) || ( velo > 8.e+3 ) ) {
            invalid_tags[ (*count)++ ] = ( VX_SAT_1 + tag );
            invalid_tags[ (*count)++ ] = ( VY_SAT_1 + tag );
            invalid_tags[ (*count)++ ] = ( VZ_SAT_1 + tag );
         }
      }
   }

/* ==========================================================================
   Ground to slant section
   ========================================================================== */
   if ( IANNIV_ImageAnnot[ imanum ].MapProjectionType == IANNIE_proj_ground ) {
      if ( ( IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree < 1 ) ||
           ( IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree >
             ( IANNID_GRSRMAX - 1 ) ) )  {
         invalid_tags[ (*count)++ ] = GR_SR_POL_DEGREE;
      }

      if ( ( ( IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree >= 1 ) &&
             ( IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree <=
               ( IANNID_GRSRMAX - 1 ) ) ) &&
           ( ( IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz >= 18.95e+6 ) &&
             ( IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz <= 18.97e+6 ) ) &&
           ( ( IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec >= 4.e-3 ) &&
             ( IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec <= 7.e-3 ) ) &&
           ( IANNIV_ImageAnnot[ imanum ].ProcessorName != IANNIE_sproc_undef ) ) {
         UINTx4      col;
         UINTx2      Npoints = 500;
         UINTx2      Step;
         double      slant;
         double      min_slant = 1.e+30;
         double      max_slant = -1.e+30;

         /* evaluate the loop step */
         Step = (UINTx2)( IANNIV_ImageAnnot[ imanum ].ImageWidth /
            ( Npoints + 1 ) );

         for ( col=0; col<Npoints; col++ ) {
	    slant = 0.;

            switch ( IANNIV_ImageAnnot[ imanum ].ProcessorName ) {
               case IANNIE_sproc_VMP: {
                  double x;

                  x = col * Step * IANNIV_ImageAnnot[ imanum ].PixelSpacing_m *
                     IANNIV_ImageAnnot[ imanum ].XScalingFactor;
                  POLY( x, IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree,
                        IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff, slant );
                  slant = ( CVEL / 2. ) *
                     ( IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec +
                     ( 1. / IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz ) *
                     slant );
               }
               break;
               case IANNIE_sproc_Bangkok: {
                  double x;

                  x = col * Step * IANNIV_ImageAnnot[ imanum ].PixelSpacing_m *
                     IANNIV_ImageAnnot[ imanum ].XScalingFactor;
                  POLY( x, IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree,
                        IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff, slant );
                  slant += CVEL * IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec /
                     2.;
               }
               break;
               case IANNIE_sproc_ESAR:
                  POLY( ( col * Step / 1.e+3 ),
                        IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree,
                        IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff, slant );
                  slant = ( CVEL / 2. ) *
                     ( IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec +
                     ( 1. / IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz ) *
                     slant );
               break;
            }
            if ( slant < min_slant ) min_slant = slant;
            if ( slant > max_slant ) max_slant = slant;
         }

         if ( ( min_slant < 7.3e+5 ) || ( max_slant > 1.01e+6 ) ) {
	    for ( tag=0; tag<=IANNIV_ImageAnnot[imanum].GroundToSlantDegree;
                  tag++ ) {
               invalid_tags[ (*count)++ ] = ( GR_SR_COEFF_1 + tag );
            }
         }
      }
   }

/* ==========================================================================
   Image processing INFO
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow < -30000 ) ||
        ( IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow > 30000) )
      invalid_tags[ (*count)++ ] = SUBIMG_TOP_LEFT_ROW;

   if ( ( IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol < -15000 ) ||
        ( IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol > 15000 ) )
      invalid_tags[ (*count)++ ] = SUBIMG_TOP_LEFT_COL;

   if ( IANNIV_ImageAnnot[ imanum ].PixelType == IANNIE_pixt_undef )
      invalid_tags[ (*count)++ ] = PIXEL_TYPE;

   if ( ( IANNIV_ImageAnnot[ imanum ].LooksNumber < 1. ) ||
        ( IANNIV_ImageAnnot[ imanum ].LooksNumber > 4. ) )
      invalid_tags[ (*count)++ ] = NOM_NB_LOOKS_AZIM;

   if ( ( IANNIV_ImageAnnot[ imanum ].ReferenceSlantRange_m < 7.3e+4 ) ||
        ( IANNIV_ImageAnnot[ imanum ].ReferenceSlantRange_m > 1.01e+6 ) )
      invalid_tags[ (*count)++ ] = NORMALISATION_REF_RANGE;

   if ( ( IANNIV_ImageAnnot[ imanum ].ProductReplicaPower < 1.e+5 ) ||
        ( IANNIV_ImageAnnot[ imanum ].ProductReplicaPower > 3.e+5 ) )
      invalid_tags[ (*count)++ ] = REPLICA_POWER;

   if ( ( IANNIV_ImageAnnot[ imanum ].ChirpAverageDensity < 1.e+5 ) ||
        ( IANNIV_ImageAnnot[ imanum ].ChirpAverageDensity > 3.e+5 ) ) {
      IANNIV_ImageAnnot[ imanum ].ChirpAverageDensity *= 1000.0;
      if ( ( IANNIV_ImageAnnot[ imanum ].ChirpAverageDensity < 1.e+5 ) ||
           ( IANNIV_ImageAnnot[ imanum ].ChirpAverageDensity > 3.e+5 ) ) {
         invalid_tags[ (*count)++ ] = CHIRP_AVERAGE_DENSITY;
         IANNIV_ImageAnnot[ imanum ].ChirpAverageDensity /= 1000.0;
      }
   }


   if ( ( IANNIV_ImageAnnot[ imanum ].AntennaPatternCorrectionFlag != TRUE ) &&
        ( IANNIV_ImageAnnot[ imanum ].AntennaPatternCorrectionFlag != FALSE ) )
      invalid_tags[ (*count)++ ] = ANTENNA_ELEVATION_GAIN_FLAG;

   if ((IANNIV_ImageAnnot[imanum].RangeSpreadingLossCompensationFlag != TRUE) &&
       (IANNIV_ImageAnnot[imanum].RangeSpreadingLossCompensationFlag != FALSE) )
      invalid_tags[ (*count)++ ] = SPREAD_LOSS_COMP_FLAG;

   if ((IANNIV_ImageAnnot[imanum].CalibrationConstantApplicationFlag != TRUE) &&
       (IANNIV_ImageAnnot[imanum].CalibrationConstantApplicationFlag != FALSE) )
      invalid_tags[ (*count)++ ] = CALIB_CONST_APPLI_FLAG;

   if ( ( IANNIV_ImageAnnot[ imanum ].ADCSaturationCompensationFlag != TRUE ) &&
        ( IANNIV_ImageAnnot[ imanum ].ADCSaturationCompensationFlag != FALSE ) )
      invalid_tags[ (*count)++ ] = ADC_SATUR_COMPENS_FLAG;

/* ==========================================================================
   Resampling factors
   ========================================================================== */
   if ( IANNIV_ImageAnnot[ imanum ].XScalingFactor <= 0. ) {
      invalid_tags[ (*count)++ ] = X_SCALE_FACTOR;
   }

   if ( IANNIV_ImageAnnot[ imanum ].YScalingFactor <= 0. ) {
      invalid_tags[ (*count)++ ] = Y_SCALE_FACTOR;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNPP_GETP_TagsCheck */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_GETP_BasicTagsCheck

        $TYPE         PROCEDURE

        $INPUT        imanum	: number of the image among that of the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the image
                                                  annotations

        $RET_STATUS   ERRSID_IANN_not_allow_imanum
                      ERRSID_IANN_basic_tag_invalid

        $DESCRIPTION  This procedure checks if the basic image tags are in their
                      range of validity

        $WARNING      NONE

   $EH
   ========================================================================== */

void IANNPP_GETP_BasicTagsCheck
                        (/*IN    */ UINTx1               imanum,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNPP_GETP_BasicTagsCheck";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   char                   tag_num[ LDEFID_char_line ] = "";
   char                   numb[ 4 ] = "";

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image index
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) {
      sprintf( numb, "%0u", imanum );
      ERRSIM_set_error( status_code, ERRSID_IANN_not_allow_imanum, numb );
   }

/* ==========================================================================
   Image sizes
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ imanum ].ImageLength < 1 ) ||
        ( IANNIV_ImageAnnot[ imanum ].ImageLength > 30000 ) ) {
      sprintf( tag_num, "%0u", IMAGE_LENGTH );
      ERRSIM_set_error( status_code, ERRSID_IANN_basic_tag_invalid, tag_num );
   }

   if ( ( IANNIV_ImageAnnot[ imanum ].ImageWidth < 1 ) ||
        ( IANNIV_ImageAnnot[ imanum ].ImageWidth > 15000 ) ) {
      sprintf( tag_num, "%0u", IMAGE_WIDTH );
      ERRSIM_set_error( status_code, ERRSID_IANN_basic_tag_invalid, tag_num );
   }

/* ==========================================================================
   Pixel type INFO
   ========================================================================== */
   if ( ( IANNIV_ImageAnnot[ imanum ].SamplePerPixel < 1 ) ||
        ( IANNIV_ImageAnnot[ imanum ].SamplePerPixel > 3 ) ) {
      sprintf( tag_num, "%0u", SAMPLE_PER_PIXEL );
      ERRSIM_set_error( status_code, ERRSID_IANN_basic_tag_invalid, tag_num );
   }

   if ( ( IANNIV_ImageAnnot[ imanum ].BitsPerSample[ 0 ] !=
          sizeof( UINTx1 ) * LDEFID_byte_size ) &&                /* RAW data */
        ( IANNIV_ImageAnnot[ imanum ].BitsPerSample[ 0 ] !=
          sizeof( INTx2 ) * LDEFID_byte_size ) &&              /* SLC(I) data */
        ( IANNIV_ImageAnnot[ imanum ].BitsPerSample[ 0 ] !=
          sizeof( UINTx2 ) * LDEFID_byte_size ) &&               /* real data */
        ( IANNIV_ImageAnnot[ imanum ].BitsPerSample[ 0 ] !=
          sizeof( float ) * LDEFID_byte_size ) ) {     /* floating point data */
      sprintf( tag_num, "%0u", BITS_PER_SAMPLE );
      ERRSIM_set_error( status_code, ERRSID_IANN_basic_tag_invalid, tag_num );
   }

   if ( ( IANNIV_ImageAnnot[ imanum ].SampleFormat[ 0 ] != TIFSID_uintdata ) &&
        ( IANNIV_ImageAnnot[ imanum ].SampleFormat[ 0 ] != TIFSID_sintdata ) &&
        ( IANNIV_ImageAnnot[ imanum ].SampleFormat[ 0 ] != TIFSID_float ) ) {
      sprintf( tag_num, "%0u", SAMPLE_FORMAT );
      ERRSIM_set_error( status_code, ERRSID_IANN_basic_tag_invalid, tag_num );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IANNPP_GETP_BasicTagsCheck */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_GETP_AnnotDump

        $TYPE         PROCEDURE

        $INPUT        imanum : ID number of the image
                      fpt    : output file pointer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure dumps the annotations stored in the
                      image annotations structure

        $WARNING      NONE

   $EH
   ========================================================================== */

void IANNIP_GETP_AnnotDump
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ FILE                *fpt,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNIP_GETP_AnnotDump";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  tag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Print out the structure
   ========================================================================== */
   fprintf ( fpt, "\n ImageLength:                         %d",
             IANNIV_ImageAnnot[ imanum ].ImageLength );
   fprintf ( fpt, "\n ImageWidth:                          %d",
             IANNIV_ImageAnnot[ imanum ].ImageWidth );
   fprintf ( fpt, "\n SamplePerPixel:                      %d",
             IANNIV_ImageAnnot[ imanum ].SamplePerPixel );
   fprintf ( fpt, "\n BitsPerSample[0]:                    %d",
             IANNIV_ImageAnnot[ imanum ].BitsPerSample[0] );
   switch ( IANNIV_ImageAnnot[ imanum ].SampleFormat[ 0 ] ) {
      case TIFSID_sintdata:
         fprintf ( fpt, "\n SampleFormat[0]:                     TIFSID_sintdata" );
      break;
      case TIFSID_uintdata:
         fprintf ( fpt, "\n SampleFormat[0]:                     TIFSID_uintdata" );
      break;
      case TIFSID_float:
         fprintf ( fpt, "\n SampleFormat[0]:                     TIFSID_float" );
      break;
      case TIFSID_IEEEdata:
         fprintf ( fpt, "\n SampleFormat[0]:                     TIFSID_IEEEdata" );
      break;
      default:
         fprintf ( fpt, "\n SampleFormat[0]:                     ###############" );
   }
   switch ( IANNIV_ImageAnnot[ imanum ].ProductType ) {
      case IANNIE_prod_ERS1_RAW:
         fprintf ( fpt, "\n ProductType:                         ERS1.RAW" );
      break;
      case IANNIE_prod_ERS1_SLC:
         fprintf ( fpt, "\n ProductType:                         ERS1.SLC" );
      break;
      case IANNIE_prod_ERS1_SLCI:
         fprintf ( fpt, "\n ProductType:                         ERS1.SLCI" );
      break;
      case IANNIE_prod_ERS1_PRI:
         fprintf ( fpt, "\n ProductType:                         ERS1.PRI" );
      break;
      case IANNIE_prod_ERS1_GEC:
         fprintf ( fpt, "\n ProductType:                         ERS1.GEC" );
      break;
      case IANNIE_prod_ERS1_GTC:
         fprintf ( fpt, "\n ProductType:                         ERS1.GTC" );
      break;
      case IANNIE_prod_ERS2_RAW:
         fprintf ( fpt, "\n ProductType:                         ERS2.RAW" );
      break;
      case IANNIE_prod_ERS2_SLC:
         fprintf ( fpt, "\n ProductType:                         ERS2.SLC" );
      break;
      case IANNIE_prod_ERS2_SLCI:
         fprintf ( fpt, "\n ProductType:                         ERS2.SLCI" );
      break;
      case IANNIE_prod_ERS2_PRI:
         fprintf ( fpt, "\n ProductType:                         ERS2.PRI" );
      break;
      case IANNIE_prod_ERS2_GEC:
         fprintf ( fpt, "\n ProductType:                         ERS2.GEC" );
      break;
      case IANNIE_prod_ERS2_GTC:
         fprintf ( fpt, "\n ProductType:                         ERS2.GTC" );
      break;
      default:
         fprintf ( fpt, "\n ProductType:                         ###############" );
   }
   fprintf ( fpt, "\n SceneReferenceNumbers:               %s",
             IANNIV_ImageAnnot[ imanum ].SceneReferenceNumbers );
   switch ( IANNIV_ImageAnnot[ imanum ].ProcessingPAF ) {
      case IANNIE_proc_CPAF:
         fprintf ( fpt, "\n ProcessingPAF:                       Central - PAF" );
      break;
      case IANNIE_proc_DPAF:
         fprintf ( fpt, "\n ProcessingPAF:                       German - PAF" );
      break;
      case IANNIE_proc_UPAF:
         fprintf ( fpt, "\n ProcessingPAF:                       U. K. - PAF" );
      break;
      case IANNIE_proc_IPAF:
         fprintf ( fpt, "\n ProcessingPAF:                       Italian - PAF" );
      break;
      case IANNIE_proc_APAF:
         fprintf ( fpt, "\n ProcessingPAF:                       U.S.A. - PAF" );
      break;
      case IANNIE_proc_SPAF:
         fprintf ( fpt, "\n ProcessingPAF:                       Singapore - PAF" );
      break;
      default:
         fprintf ( fpt, "\n ProcessingPAF:                       ###############" );
   }

   switch ( IANNIV_ImageAnnot[ imanum ].ProcessorName ) {
      case IANNIE_sproc_VMP:
         fprintf ( fpt, "\n ProcessorName:                       VMP" );
      break;
      case IANNIE_sproc_ESAR:
         fprintf ( fpt, "\n ProcessorName:                       E-SAR" );
      break;
      case IANNIE_sproc_Bangkok:
         fprintf ( fpt, "\n ProcessorName:                       Bangkok" );
      break;
      default:
         fprintf ( fpt, "\n ProcessorName:                       ###############" );
   }

   fprintf ( fpt, "\n CalibrationConstant:                 %f",
             IANNIV_ImageAnnot[ imanum ].CalibrationConstant );
   fprintf ( fpt, "\n IncidenceAngleAtMiddleRange_deg:     %f",
             IANNIV_ImageAnnot[ imanum ].IncidenceAngleAtMiddleRange_deg );
   fprintf ( fpt, "\n BoresightAngle_deg:                  %f",
             IANNIV_ImageAnnot[ imanum ].BoresightAngle_deg );

   fprintf ( fpt, "\n TopLeftLat_deg:                      %f",
             IANNIV_ImageAnnot[ imanum ].TopLeftLat_deg );
   fprintf ( fpt, "\n TopLeftLon_deg:                      %f",
             IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg );
   fprintf ( fpt, "\n TopRightLat_deg:                     %f",
             IANNIV_ImageAnnot[ imanum ].TopRightLat_deg );
   fprintf ( fpt, "\n TopRightLon_deg:                     %f",
             IANNIV_ImageAnnot[ imanum ].TopRightLon_deg );
   fprintf ( fpt, "\n BottomLeftLat_deg:                   %f",
             IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg );
   fprintf ( fpt, "\n BottomLeftLon_deg:                   %f",
             IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg );
   fprintf ( fpt, "\n BottomRightLat_deg:                  %f",
             IANNIV_ImageAnnot[ imanum ].BottomRightLat_deg );
   fprintf ( fpt, "\n BottomRightLon_deg:                  %f",
             IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg );
   fprintf ( fpt, "\n CentreGeodeticLat_deg:               %f",
             IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg );
   fprintf ( fpt, "\n CentreGeodeticLon_deg:               %f",
             IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg );

   fprintf ( fpt, "\n TopZeroFilledLines:                  %d",
             IANNIV_ImageAnnot[ imanum ].TopZeroFilledLines );
   fprintf ( fpt, "\n BottomZeroFilledLines:               %d",
             IANNIV_ImageAnnot[ imanum ].BottomZeroFilledLines );
   fprintf ( fpt, "\n LeftZeroFilledPixels:                %d",
             IANNIV_ImageAnnot[ imanum ].LeftZeroFilledPixels );
   fprintf ( fpt, "\n RightZeroFilledPixels:               %d",
             IANNIV_ImageAnnot[ imanum ].RightZeroFilledPixels );

   switch ( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {
      case IANNIE_proj_UTM:
         fprintf ( fpt, "\n MapProjectionType:                   UTM" );
      break;
      case IANNIE_proj_UPS:
         fprintf ( fpt, "\n MapProjectionType:                   UPS" );
      break;
      case IANNIE_proj_ground:
         fprintf ( fpt, "\n MapProjectionType:                   Ground range" );
      break;
      case IANNIE_proj_slant:
         fprintf ( fpt, "\n MapProjectionType:                   Slant range" );
      break;
      default:
         fprintf ( fpt, "\n MapProjectionType:                   ###############" );
   }

   fprintf ( fpt, "\n ProjectionScaleFactor:               %f",
             IANNIV_ImageAnnot[ imanum ].ProjectionScaleFactor );
   fprintf ( fpt, "\n ProjectionCentralMeridian_deg:       %f",
             IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg );
   fprintf ( fpt, "\n ProjectionCentralParallel_deg:       %f",
             IANNIV_ImageAnnot[ imanum ].ProjectionCentralParallel_deg );
   fprintf ( fpt, "\n TopLeftEast_m:                       %f",
             IANNIV_ImageAnnot[ imanum ].TopLeftEast_m );
   fprintf ( fpt, "\n TopLeftNorth_m:                      %f",
             IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m );
   fprintf ( fpt, "\n FalseEast_m:                         %f",
             IANNIV_ImageAnnot[ imanum ].FalseEast_m );
   fprintf ( fpt, "\n FalseNorth_m:                        %f",
             IANNIV_ImageAnnot[ imanum ].FalseNorth_m );

   fprintf ( fpt, "\n LineSpacing_m:                       %f",
             IANNIV_ImageAnnot[ imanum ].LineSpacing_m );
   fprintf ( fpt, "\n PixelSpacing_m:                      %f",
             IANNIV_ImageAnnot[ imanum ].PixelSpacing_m );

   fprintf ( fpt, "\n FirstSTVectYear:                     %d",
             IANNIV_ImageAnnot[ imanum ].FirstSTVectYear );
   fprintf ( fpt, "\n FirstSTVectMonth:                    %d",
             IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth );
   fprintf ( fpt, "\n FirstSTVectDay:                      %d",
             IANNIV_ImageAnnot[ imanum ].FirstSTVectDay );
   fprintf ( fpt, "\n FirstSTVectSeconds:                  %f",
             IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds );
   fprintf ( fpt, "\n ZeroDopplerAzimuthFirstLine_UTC:     %s",
             IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthFirstLine_UTC );
   fprintf ( fpt, "\n ZeroDopplerAzimuthLastLine_UTC:      %s",
             IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthLastLine_UTC );
   fprintf ( fpt, "\n RadarWaveLength_m:                   %f",
             IANNIV_ImageAnnot[ imanum ].RadarWaveLength_m );
   fprintf ( fpt, "\n SamplingRate_Hz:                     %g",
             IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz );
   fprintf ( fpt, "\n RangeFirstTime_sec:                  %g",
             IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec );
   fprintf ( fpt, "\n PulseRepetitionFreq_Hz:              %f",
             IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz );
   fprintf ( fpt, "\n EquivalentPulseRepetitionFreq_Hz:    %f",
             IANNIV_ImageAnnot[ imanum ].EquivalentPulseRepetitionFreq_Hz );
   for ( tag=0; tag<4; tag++ ) {
      fprintf ( fpt, "\n DopplerFreqCoeff_Hz_sec[%d]:          %g", tag,
                IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ tag ] );
   }

   fprintf ( fpt, "\n SemiMajorAxis_m:                     %f",
             IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m );
   fprintf ( fpt, "\n SemiMinorAxis_m:                     %f",
             IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m );

   fprintf ( fpt, "\n STVectIntervalTime_sec:              %f",
             IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec );
   fprintf ( fpt, "\n NStateVectors:                       %d",
             IANNIV_ImageAnnot[ imanum ].NStateVectors );
   for ( tag=0; tag<5; tag++ ) {
      fprintf ( fpt, "\n X_STVec_m[%d]:                        %f", tag,
                IANNIV_ImageAnnot[ imanum ].X_STVec_m[ tag ] );
   }
   for ( tag=0; tag<5; tag++ ) {
      fprintf ( fpt, "\n Y_STVec_m[%d]:                        %f", tag,
                IANNIV_ImageAnnot[ imanum ].Y_STVec_m[ tag ] );
   }
   for ( tag=0; tag<5; tag++ ) {
      fprintf ( fpt, "\n Z_STVec_m[%d]:                        %f", tag,
                IANNIV_ImageAnnot[ imanum ].Z_STVec_m[ tag ] );
   }
   for ( tag=0; tag<5; tag++ ) {
      fprintf ( fpt, "\n VX_STVec_m[%d]:                       %f", tag,
                IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[ tag ] );
   }
   for ( tag=0; tag<5; tag++ ) {
      fprintf ( fpt, "\n VY_STVec_m[%d]:                       %f", tag,
                IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[ tag ] );
   }
   for ( tag=0; tag<5; tag++ ) {
      fprintf ( fpt, "\n VZ_STVec_m[%d]:                       %f", tag,
                IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[ tag ] );
   }

   fprintf ( fpt, "\n GroundToSlantDegree:                 %d",
             IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree );
   for ( tag=0; tag<IANNID_GRSRMAX; tag++ ) {
      fprintf ( fpt, "\n GroundToSlantCoeff[%d]:               %g", tag,
                IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff[ tag ] );
   }

   fprintf ( fpt, "\n SubImageTopLeftRow:                  %d",
             IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow );
   fprintf ( fpt, "\n SubImageTopLeftCol:                  %d",
             IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol );
   switch ( IANNIV_ImageAnnot[ imanum ].PixelType ) {
      case IANNIE_pixt_complex:
         fprintf ( fpt, "\n PixelType:                           COMPLEX" );
      break;
      case IANNIE_pixt_amplitude:
         fprintf ( fpt, "\n PixelType:                           AMPLITUDE" );
      break;
      case IANNIE_pixt_power:
         fprintf ( fpt, "\n PixelType:                           POWER" );
      break;
      default:
         fprintf ( fpt, "\n PixelType:                           ###############" );
   }
   fprintf ( fpt, "\n ScalingFactor:                       %f",
             IANNIV_ImageAnnot[ imanum ].ScalingFactor );
   fprintf ( fpt, "\n LooksNumber:                         %f",
             IANNIV_ImageAnnot[ imanum ].LooksNumber );
   fprintf ( fpt, "\n ReferenceSlantRange_m:               %f",
             IANNIV_ImageAnnot[ imanum ].ReferenceSlantRange_m );
   fprintf ( fpt, "\n ProductReplicaPower:                 %f",
             IANNIV_ImageAnnot[ imanum ].ProductReplicaPower );
   fprintf ( fpt, "\n ChirpAverageDensity:                 %f",
             IANNIV_ImageAnnot[ imanum ].ChirpAverageDensity );
   if ( strcmp ( IANNIV_ImageAnnot[ imanum ].ProcessingHistory, "" ) ) {
      fprintf ( fpt, "\n ProcessingHistory:                   %s",
                IANNIV_ImageAnnot[ imanum ].ProcessingHistory );
   }
   else {
      fprintf ( fpt, "\n ProcessingHistory:                   ###############" );
   }

   fprintf ( fpt, "\n AntennaPatternCorrectionFlag:        %d",
             IANNIV_ImageAnnot[ imanum ].AntennaPatternCorrectionFlag );
   fprintf ( fpt, "\n RangeSpreadingLossCompensationFlag:  %d",
             IANNIV_ImageAnnot[ imanum ].RangeSpreadingLossCompensationFlag );
   fprintf ( fpt, "\n CalibrationConstantApplicationFlag:  %d",
             IANNIV_ImageAnnot[ imanum ].CalibrationConstantApplicationFlag );
   fprintf ( fpt, "\n ADCSaturationCompensationFlag:       %d",
             IANNIV_ImageAnnot[ imanum ].ADCSaturationCompensationFlag );

   if ( strcmp ( IANNIV_ImageAnnot[ imanum ].MasterSceneReference, "" ) ) {
      fprintf ( fpt, "\n MasterSceneReference:                %s",
                IANNIV_ImageAnnot[ imanum ].MasterSceneReference );
   }
   else {
      fprintf ( fpt, "\n MasterSceneReference:                ###############"
                /* , IANNIV_ImageAnnot[ imanum ].MasterSceneReference */ );
   }

   fprintf ( fpt, "\n XScalingFactor:                      %f",
             IANNIV_ImageAnnot[ imanum ].XScalingFactor );
   fprintf ( fpt, "\n YScalingFactor:                      %f",
             IANNIV_ImageAnnot[ imanum ].YScalingFactor );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNIP_GETP_AnnotDump */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_GETP_CopyAnnot

        $TYPE         PROCEDURE

        $INPUT        inp_ima_num : ID number of the input image annotation
                      out_ima_num : ID number of the output image annotation

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot, IANNIV_NotFoundTags, IANNIV_InvalidTags

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure copy the annotations stored in the
                      image annotations structure

        $WARNING      NONE

   $EH
   ========================================================================== */

void IANNIP_GETP_CopyAnnot
                        (/*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNIP_GETP_CopyAnnot";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 iAnnot;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check inp_ima_num and out_ima_num
   ========================================================================== */
   if ( inp_ima_num >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_IANN_not_allow_imanum, "" );
   }
   if ( out_ima_num >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_IANN_not_allow_imanum, "" );
   }


/* ==========================================================================
   Copy IANNIV_ImageAnnot, IANNIV_NotFoundTags, IANNIV_InvalidTags
   ========================================================================== */
   memcpy( &IANNIV_ImageAnnot[ out_ima_num ], 
	   &IANNIV_ImageAnnot[ inp_ima_num ],
	   (size_t)sizeof( IANNIT_ImageAnnot ) );

   for( iAnnot=0; iAnnot<IANNID_ImageAnnotMaxNumber; iAnnot++ ) {
      IANNIV_NotFoundTags[ out_ima_num ][ iAnnot ] =
                       IANNIV_NotFoundTags[ inp_ima_num ][ iAnnot ];
      IANNIV_InvalidTags[ out_ima_num ][ iAnnot ] =
                       IANNIV_InvalidTags[ inp_ima_num ][ iAnnot ];
   }


error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNIP_GETP_CopyAnnot */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_GETP_SetDateString

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     str : string to modify

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IANN_invalid_date

        $DESCRIPTION  This procedure converts a string with a UTC date in the
                      exact format: DD-MMM-YYYY HH:MM:SS.SSSS putting the
                      character '0' where it's loose

        $WARNING      NONE

   $EH
   ========================================================================== */

void IANNPP_GETP_SetDateString
                        (/*IN    */ char                *str,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNPP_GETP_SetDateString";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   char			 *p = (char *)NULL;
   char                   tmp[ LDEFID_char_num ];
   INTx4                  count = 0;
   INTx4                  i;
   INTx4                  n;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Zero the tmp string
   ========================================================================== */
   memset ( tmp, '\0', (size_t)LDEFID_char_num );

/* ==========================================================================
   Search the first character '-' in the string
   ========================================================================== */
   if ( ( p = strtok ( str, "-" ) ) == NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IANN_invalid_date, str );
   }

/* ==========================================================================
   Set the Day DD
   ========================================================================== */
   if ( strlen ( p ) == 2 ) {
      tmp[ count++ ] = ( *p == ' ' ) ? '0' : *p;
      tmp[ count++ ] = *(++p);
      tmp[ count ++ ] = '-';
   }
   else {
      ERRSIM_set_error ( status_code, ERRSID_IANN_invalid_date, str );
   }

/* ==========================================================================
   Search for the second '-'
   ========================================================================== */
   if ( ( p = strtok ( '\0', "-" ) ) == NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IANN_invalid_date, str );
   }

/* ==========================================================================
   Copy the Month MMM
   ========================================================================== */
   if ( strlen ( p ) == 3 ) {
      p--;
      for ( i=0; i<3; i++ ) {
         tmp[ count++ ] = *(++p);
      }
      tmp[ count++ ] = '-';
   }
   else {
      ERRSIM_set_error ( status_code, ERRSID_IANN_invalid_date, str );
   }

/* ==========================================================================
   Search for the space ' '
   ========================================================================== */
   if ( ( p = strtok ( '\0', " " ) ) == NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IANN_invalid_date, str );
   }

/* ==========================================================================
   Copy the Year YYYY
   ========================================================================== */
   if ( strlen ( p ) == 4 ) {
      p--;
      for ( i=0; i<4; i++ ) {
         tmp[ count++ ] = *(++p);
      }
      tmp[ count++ ] = ' ';
   }
   else {
      ERRSIM_set_error ( status_code, ERRSID_IANN_invalid_date, str );
   }

/* ==========================================================================
   Search for the first ':' character
   ========================================================================== */
   if ( ( p = strtok ( '\0', ":" ) ) == NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IANN_invalid_date, str );
   }

/* ==========================================================================
   Copy the Hour HH
   ========================================================================== */
   n = strlen ( p );
   if ( n > 2 ) {
      for ( i=0; i<(n-2); i++ ) {
         p++;
      }
   }

   tmp[ count++ ] = ( !isdigit( *p ) ) ? '0' : *(p);
   tmp[ count++ ] = *(++p);
   tmp[ count++ ] = ':';

/* ==========================================================================
   Search for the second ':' character
   ========================================================================== */
   if ( ( p = strtok ( '\0', ":" ) ) == NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IANN_invalid_date, str );
   }

/* ==========================================================================
   Copy the Minutes MM
   ========================================================================== */
   if ( strlen ( p ) == 2 ) {
      p--;
      for ( i=0; i<2; i++ ) {
         tmp[ count++ ] = ( !isdigit( *(++p) ) ) ? '0' : *(p);
      }
      tmp[ count++ ] = ':';
   }
   else {
      ERRSIM_set_error ( status_code, ERRSID_IANN_invalid_date, str );
   }

/* ==========================================================================
   Search for the '.' character
   ========================================================================== */
   if ( ( p = strtok ( '\0', "." ) ) == NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IANN_invalid_date, str );
   }

/* ==========================================================================
   Copy the integer part of the seconds SS
   ========================================================================== */
   if ( strlen ( p ) == 2 ) {
      p--;
      for ( i=0; i<2; i++ ) {
         tmp[ count++ ] = ( !isdigit( *(++p) ) ) ? '0' : *(p);
      }
      tmp[ count++ ] = '.';
   }
   else {
      ERRSIM_set_error ( status_code, ERRSID_IANN_invalid_date, str );
   }

/* ==========================================================================
   Increments the pointer in the string
   ========================================================================== */
   for ( i=0; i<2; i++ ) {
      p++;
   }

/* ==========================================================================
   Copy the fractionary part of the seconds
   ========================================================================== */
   n = strlen ( p );
   p--;
   for ( i=0; i<n; i++ ) {
      tmp[ count++ ] = ( !isdigit( *(++p) ) ) ? '0' : *(p);
   }

/* ==========================================================================
   Reset the string
   ========================================================================== */
   strcpy ( str, tmp );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNPP_GETP_SetDateString */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_GETP_DoppCentFreqEval

        $TYPE         PROCEDURE

        $INPUT        imanum    : the number identified the image among all
                                  that treated in the tool
                      start_col : the actual starting column of the image in
                                  the full resolution image
                      stop_col  : the actual last column of the image in the
                                  full resolution image

        $MODIFIED     NONE

        $OUTPUT       fdc       : the array with the doppler centroid
                                  frequencies evaluated

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_IRES_imanum_not_allow
                      ERRSID_IRES_start_stop_col_err

        $DESCRIPTION  This procedure evaluates the doppler centroid frequencies
                      of the image numerated by <imanum> for the columns indices
                      starting with start_col and ending with stop_col

        $WARNING      The column indices passed in input are in the full
                      reference frame

   $EH
   ========================================================================== */

void IANNIP_GETP_DoppCentFreqEval
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ INTx4                start_col,
                         /*IN    */ INTx4                stop_col,
                         /*   OUT*/ float               *fdc,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNIP_GETP_DoppCentFreqEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 deg;               /* degree counter */
   double                 time;              /* acquisition time */
   UINTx4                 col;               /* columns counter */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_IANN_imanum_not_allow, "");

/* ==========================================================================
   Check the starting and ending columns
   ========================================================================== */
   if ( ( start_col < 0 ) ||
        ( stop_col < start_col ) ||
        ( stop_col >
             IANNIV_ImageAnnot[ imanum ].ImageWidth +
             IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol ) ) {
      ERRSIM_set_error( status_code, ERRSID_IANN_start_stop_col_err, "" );
   }

/* ==========================================================================
   Column loop
   ========================================================================== */
   for ( col=0; col<=stop_col-start_col; col++ ) {

/* ==========================================================================
   Apply the IPAF algorithm for the doppler frequency centroid estimation.
   Time evaluation
   ========================================================================== */
      time = 2.0 * ((double)( col + start_col ) ) *
         ( IANNIV_ImageAnnot[ imanum ].PixelSpacing_m / CVEL );

/* ==========================================================================
   Polynomial evaluation
   ========================================================================== */
      POLY( time, 2, IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec,
            fdc[ col ] );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNIP_GETP_DoppCentFreqEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_GETP_AnnotState

        $TYPE         PROCEDURE

        $INPUT        imanum    : the number identified the image among all
                                  that treated in the tool
                      annotation: annotation number

        $MODIFIED     NONE

        $OUTPUT       state     : state of the annotation for that imanum

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_IRES_imanum_not_allow

        $DESCRIPTION  This procedure check inside IANNIV_ImageAnnot[imanum]
                      is the annotation is not found or is invalid 

        $WARNING      NONE

   $EH
   ========================================================================== */
void IANNIP_GETP_AnnotState
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               annotation,
                         /*   OUT*/ IANNIT_AnnotState   *state,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNIP_GETP_AnnotState";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 i;               /* annot counter */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_IANN_imanum_not_allow, "");

/* ==========================================================================
   Set initial state
   ========================================================================== */
   *state = IANNIE_state_undef;

/* ==========================================================================
   Look in IANNIV_NotFoundTags
   ========================================================================== */
   for( i=0; ( (*state == IANNIE_state_undef) &&
               (IANNIV_NotFoundTags[ imanum ][ i ] != 0) &&
               (i<=IANNID_ImageAnnotMaxNumber) ); i++) {
      if( IANNIV_NotFoundTags[ imanum ][ i ] == annotation) {
         *state = IANNIE_state_notfound;
      }
   }

/* ==========================================================================
   Look in IANNIV_InvalidTags
   ========================================================================== */
   for( i=0; ( (*state == IANNIE_state_undef) &&
               (IANNIV_InvalidTags[ imanum ][ i ] != 0) ||
               (i<=IANNID_ImageAnnotMaxNumber) ); i++) {
      if( IANNIV_InvalidTags[ imanum ][ i ] == annotation ) {
         *state = IANNIE_state_invalid;
      }
   }

/* ==========================================================================
   If yet IANNIE_state_undef set to IANNIE_state_ok
   ========================================================================== */
   if( *state == IANNIE_state_undef ) {
      *state = IANNIE_state_ok;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNIP_GETP_AnnotState */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_GETP_CheckValidTag

        $TYPE         PROCEDURE

        $INPUT        tag        : string tag to check

        $MODIFIED     NONE

        $OUTPUT       valid_flag : flag to indicate the validity of the tag

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure checks if a tag is a valid or has an
                      invalid value as a certain number of numbers 9

        $WARNING      NONE

   $EH
   ========================================================================== */
void IANNPP_GETP_CheckValidTag
                        (/*IN    */ char                *tag,
                         /*   OUT*/ LDEFIT_boolean      *valid_flag,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNPP_GETP_CheckValidTag";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx2                 i;
   INTx4                  nchar;
   INTx4                  n;
   const char             zero = '0';

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Set the flag to invalid
   ========================================================================== */
   *valid_flag = FALSE;

/* ==========================================================================
   Check the string 
   ========================================================================== */
   nchar = strlen ( tag );
   for ( i=0; i<nchar; i++ ) {
      if ( ( isdigit ( tag[ i ] ) ) && ( ( tag[ i ] - zero ) != 9 ) ) {
         *valid_flag = TRUE;
         break;
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNPP_GETP_CheckValidTag */
