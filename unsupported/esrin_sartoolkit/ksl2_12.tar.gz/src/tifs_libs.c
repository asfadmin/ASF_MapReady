/* ==========================================================================
   $MODULE_HEADER

      $NAME              TIFS_LIBS

      $FUNCTION          TIFF LIBrary Service (exported)

      $ROUTINE           

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       03-JAN-97     AG       Initial Release
                      15-MAJ-97     GRV      The tag sampleformat has been
                                             added to the TIFF basic structure
   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include FILS_INTF_H
#include TIFS_INTF_H
#include TIFS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_open_tiff

        $TYPE	      PROCEDURE

        $INPUT        namefile: TIFF file name
                      mode: open mode r/w/u

        $MODIFIED     NONE

        $OUTPUT       chout: out channel

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Open TIFF file in a given mode and returns a channel
                      to it

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_open_tiff  ( /*IN    */ char                *namefile,
                         /*IN    */ char                 mode,
                         /*   OUT*/ INTx4               *chout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_open_tiff";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4          i=0,j,l,chan;
   UINTx4         next_ifd=1;
   UINTx1        *tagbase;
   UINTx4         count;
   UINTx2         type;
   UINTx2         tiff_vers = 42;
   UINTx2         ii_byte_order = 18761;
   UINTx2         mm_byte_order = 19789;
   UINTx4         size;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Open in read
   ========================================================================== */
   if(tolower(mode)=='r') {

      /* assign a gid */
      for(chan=0;chan<MAX_FILES;chan++) {
         if(TIFSPV_gid[chan].used==0) {
            TIFSPV_gid[chan].used=1;
            strcpy(TIFSPV_gid[chan].name,namefile);
            break;
         }
      }

      /* no free channels */
      if(chan==MAX_FILES) {
	 ERRSIM_set_error( status_code,
		           ERRSID_TIFS_err_max_tif_opn,
                           namefile );
      }

      /* open the file */
      FILSIP_open( namefile, "rb", 0, &(TIFSPV_gid[chan].tf), status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      /* check file */
      TIFSPP_check_tiff( chan, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      TIFSPV_gid[chan].mode ='r'; /* marca il file in lettura */

/* ==========================================================================
   Set tif to FALSE 
   ========================================================================== */
      for( i=0; i<MAX_IMAGES; i++ ) TIFSPV_gid[chan].tif[i] = 0;

      i=0;
      while(next_ifd) {	/* per tutte le immagini */

         TIFSPF_readandswap((void *) &TIFSPV_gid[chan].npar[i], 2, 1,
                            TIFSPV_gid[chan].tf, TIFSPV_gid[chan].swap_byte);
                                           /* legge il numero di parametri */

         /* alloca la memoria */
	 if((TIFSPV_gid[chan].imgpar[i]=
                  (UINTx1 *)MEMSIP_alloc(12*TIFSPV_gid[chan].npar[i]))==0){
	    TIFSPV_gid[chan].used=0; /* frees the channel 'cause is not really used */ 
	    ERRSIM_set_error( status_code,
		              ERRSID_TIFS_err_not_ifd_mem_r,
                              namefile );
	 }


	 tagbase = TIFSPV_gid[chan].imgpar[i];
	 for(l=0; l<TIFSPV_gid[chan].npar[i]; l++, tagbase +=12) {
	    TIFSPF_readandswap((void *) tagbase, 2, 1, 
                          TIFSPV_gid[chan].tf, TIFSPV_gid[chan].swap_byte);
	    TIFSPF_readandswap((void *) (tagbase+2), 2, 1, 
                          TIFSPV_gid[chan].tf, TIFSPV_gid[chan].swap_byte);
	    TIFSPF_readandswap((void *) (tagbase+4), 4, 1, 
                          TIFSPV_gid[chan].tf, TIFSPV_gid[chan].swap_byte);
	    TIFSPF_readandswap((void *) (tagbase+8), 4, 1, 
                          TIFSPV_gid[chan].tf, TIFSPV_gid[chan].swap_byte);

/* ==========================================================================
   Unswap bytes
   ========================================================================== */
            count = *((UINTx4 *) (tagbase + 4));
            type = *((UINTx2 *) (tagbase + 2));
            if( (TIFSPV_gid[chan].swap_byte == 1) && 
                (count <= 2) && 
                (type == TYPE_USHORT) ) {
	       char tmp;
	       tmp = ((char *) tagbase)[ 8 ];
	       ((char *) tagbase)[ 8 ] = ((char *) tagbase)[ 10 ];
	       ((char *) tagbase)[ 10 ] = tmp;
	       tmp = ((char *) tagbase)[ 9 ];
	       ((char *) tagbase)[ 9 ] = ((char *) tagbase)[ 11 ];
	       ((char *) tagbase)[ 11 ] = tmp;
	    }

            if( (TIFSPV_gid[chan].swap_byte == 1) &&
                (count <= 4) &&
                ( (type == TYPE_ASCII) ||
                  (type == TYPE_UBYTE) ) ) {
               char tmp;
               tmp = ((char *) tagbase)[ 8 ];
               ((char *) tagbase)[ 8 ] = ((char *) tagbase)[ 11 ];
               ((char *) tagbase)[ 11 ] = tmp;
               tmp = ((char *) tagbase)[ 9 ];
               ((char *) tagbase)[ 9 ] = ((char *) tagbase)[ 10 ];
               ((char *) tagbase)[ 10 ] = tmp;
            }

	 }

         /* legge il next ifd offset */
         TIFSPF_readandswap((void *) &next_ifd, 4 , 1,
                            TIFSPV_gid[chan].tf, TIFSPV_gid[chan].swap_byte); 

         if( fseek(TIFSPV_gid[chan].tf, (INTx8) next_ifd, 0) ) {
	     ERRSIM_set_error( status_code,
			       ERRSID_TIFS_err_on_fseek,
			       TIFSPV_gid[chan].name );
	 }
	 i++;
      }

      TIFSPV_gid[chan].nimg=i;
      *chout=chan; /* restituisce il canale */
   }
/* ==========================================================================
   Open in write
   ========================================================================== */
   else if(tolower(mode)=='w') {

      TIFSPP_find_chan(namefile,&chan,status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      /* controlla che per ogni immagine sia stato settato il numero di 
         parametri */
      for(i=0;i<TIFSPV_gid[chan].nimg;i++) {
         if(TIFSPV_gid[chan].npar[i]==0) {
   	    ERRSIM_set_error( status_code,
		              ERRSID_TIFS_err_no_par_num,
                              namefile );
	 }
      }

      /* compute the size in Kb of this file */
      for(size=0, i=0;i<TIFSPV_gid[chan].nimg;i++) {
         size += 
            ( ( TIFSPV_gid[chan].imgcol[i] * TIFSPV_gid[chan].imgrig[i] *
              TIFSPV_gid[chan].sampix[i] * TIFSPV_gid[chan].bitsam[i][0]/8 ) /
              1024 ) + LDEFID_ann_kbytes;
      }
      /* open the file */
      FILSIP_open( namefile, "w+b", size, &(TIFSPV_gid[chan].tf), status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set tif to false
   ========================================================================== */
      for( i=0; i<MAX_IMAGES; i++ ) TIFSPV_gid[chan].tif[i] = 0;

      /* alloca la memoria per la area di descrizione parametri relativi a 
         tutte le immagini */
      for(i=0;i<TIFSPV_gid[chan].nimg;i++) { /* per tutte le immagini */
	 if((TIFSPV_gid[chan].imgpar[i]=
	       (UINTx1 *)MEMSIP_alloc(12*TIFSPV_gid[chan].npar[i]))==0) {
	    ERRSIM_set_error( status_code,
		              ERRSID_TIFS_err_not_ifd_mem_w,
                              namefile );
         }
         /* azzera l'area descrizione parametri */
         for(j=0;j<12*TIFSPV_gid[chan].npar[i];j++) *(TIFSPV_gid[chan].imgpar[i]+j)=0;
      }

      /* scrive l'header TIFF e riserva lo spazio per il puntatore alla IFD */
#if __SWAP__ 
      if( fwrite((char *) &mm_byte_order, sizeof(UINTx2), 1, TIFSPV_gid[chan].tf) < 1 ) {
         ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
            TIFSPV_gid[chan].name );
      }
#else
      if( fwrite((char *) &ii_byte_order, sizeof(UINTx2), 1, TIFSPV_gid[chan].tf) < 1 )  {
         ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
            TIFSPV_gid[chan].name );
      }
#endif

      if( fwrite((char *) &tiff_vers, sizeof(UINTx2), 1, TIFSPV_gid[chan].tf) < 1 ) {
         ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
            TIFSPV_gid[chan].name );
      }

      if( fseek(TIFSPV_gid[chan].tf, (INTx8) 8, 0) ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_on_fseek,
			   TIFSPV_gid[chan].name );
      }
      TIFSPV_gid[chan].freeptr+=8; /* posiziona il puntatore al prossimo byte libero */

     *chout=chan; /* restituisce il canale */
   }
/* ==========================================================================
   Open in update
   ========================================================================== */
   else if(tolower(mode)=='u') { /* apertura in update */
      for(chan=0;chan<MAX_FILES;chan++) {
	 if(TIFSPV_gid[chan].used==0) {
	    TIFSPV_gid[chan].used=1;
	    strcpy(TIFSPV_gid[chan].name,namefile);
	    break;
	 }
      }

      if(chan==MAX_FILES) {
	 ERRSIM_set_error( status_code,
		           ERRSID_TIFS_err_max_tif_opn,
                           namefile );
      }

      /* open the file */
      FILSIP_open( namefile, "r+b", 0, &(TIFSPV_gid[chan].tf), status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      /* controlla che sia TIFF */
      TIFSPP_check_tiff(chan, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      TIFSPV_gid[chan].mode='u'; /* marca il file in update */

      /* la prossima posizione libera (usata nell'update di parametri con nuova
         lunghezza maggiore della originaria) in modo update e' all'inizio 
         della IFD */
      TIFSPV_gid[chan].freeptr=ftell(TIFSPV_gid[chan].tf);  

      while(next_ifd) {	/* per tutte le immagini */

	 fread(&TIFSPV_gid[chan].npar[i],2,1,TIFSPV_gid[chan].tf); /* legge il numero di parametri */

	 if((TIFSPV_gid[chan].imgpar[i]=(UINTx1 *)MEMSIP_alloc(12*TIFSPV_gid[chan].npar[i]))==0){
						/* alloca la mem per la IFD */
	    ERRSIM_set_error( status_code,
			      ERRSID_TIFS_err_not_ifd_mem_r,
			      namefile );
	 }

	 fread(TIFSPV_gid[chan].imgpar[i],12,TIFSPV_gid[chan].npar[i],TIFSPV_gid[chan].tf); /* legge la area ifd */
	 fread(&next_ifd,4,1,TIFSPV_gid[chan].tf); /* legge il next IFD offset */
         /* si posiziona sulla prossima IFD */
	 if( fseek(TIFSPV_gid[chan].tf, (INTx8) next_ifd, 0) ) {
	     ERRSIM_set_error( status_code,
			       ERRSID_TIFS_err_on_fseek,
			       TIFSPV_gid[chan].name );
	 }
	 i++;
      }

      TIFSPV_gid[chan].nimg=i;

      *chout=chan; /* restituisce il canale */
   }
   else
   {
      ERRSIM_set_error( status_code,
			ERRSID_error,
			"Unrecognized open mode" );
   }
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_open_tiff */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_init_filedata

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Set the TIFSPV_gid global structure

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_init_filedata
                       ( /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_init_filedata";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i,j;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

  for(i=0;i<MAX_FILES;i++) {     /* per ogni file */
    TIFSPV_gid[i].used=0;           /* azzera il flag di used */
    TIFSPV_gid[i].freeptr=0;        /* azzera il puntatore al prossimo byte libero su disco*/
    TIFSPV_gid[i].actptr=0;         /* azzera il puntatore alla posizione attuale nel file su disco*/
    for(j=0;j<MAX_IMAGES;j++) {  /* per ogni immagine nel file */
      TIFSPV_gid[i].ifd[j]=0;       /* azzera il puntatore alla prossima IFD */
      TIFSPV_gid[i].blockoffs[j]=0; /* azzera il puntatore agli offset di blocco (usato come flag in close_tiff) */
      TIFSPV_gid[i].blocksize[j]=0; /* azzera il puntatore ai size di blocco (usato come flag in close_tiff) */
      TIFSPV_gid[i].bitsam[j]=0;    /* azzera il puntatore ai volori di bit per sample (usato come flag in close_tiff) */
    }
  }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_init_filedata */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_close_tiff

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF file channel to be closed

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Chiude un file TIFF liberando la memoria e resettando 
		      l'area filedata associati in scrittura riordina la IFD 
                      e la salva su file

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_close_tiff ( /*IN    */ INTx4                chan,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_close_tiff";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4        img;
   UINTx4       first_ifd,next_ifd;
   INTx4        i;
   UINTx2       tag;
   UINTx2       length;
   UINTx4       offs; 
   UINTx2       npar_actw; /* number of tags written effectively; can be less 
                              than TIFSPV_gid[chan].npar[img] if less tags are 
                              stored respect the number specified with set_parnum;
                              used for TTFF files in write mode only */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);


   if(TIFSPV_gid[chan].used!=1) {
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_not_opn_tif,
			"" );
   }

   /* File aperto in scrittura */
   if(TIFSPV_gid[chan].mode == 'w') {

      /* Se c'e' compressione salva blocksize e blockoffset nella posizione
	 allocata durante store_blockinfo */
      /* Se non c'e' compressione tali parametri sono stati gia' salvati e non 
	 e' necessario fare niente altro */

			   
      for(img=0;img<TIFSPV_gid[chan].nimg;img++) {  /* per tutte le immagini */

	 /* libera il vettore di flags blocco gia' salvato usato in writeline */
	 MEMSIP_free( (void **) &(TIFSPV_gid[chan].blkflag[img]) );

	 if(TIFSPV_gid[chan].compression[img]!=1) {  /* con compressione */

	    /* Parametro blocksize */
	    /* rintraccia l'offset dove e' stato salvato blocksize */
	    for(i=0;i<TIFSPV_gid[chan].npar[img];i++) { /* ricerca lineare del tag */
	       tag= *(UINTx2 *)(TIFSPV_gid[chan].imgpar[img]+12*i);
	       if(tag==TILEBYTECOUNT) {
		  break;
	       }
	    }

	    if(i==TIFSPV_gid[chan].npar[img]) {  /* controllo se il parametro e' stato salvato precedentemente */
	       ERRSIM_set_error( status_code,
				 ERRSID_TIFS_err_no_param,
				 TIFSPV_gid[chan].name );
	    }

	    length= *(UINTx4 *)(TIFSPV_gid[chan].imgpar[img]+12*i+4);

	    if(length==1) {  /* caso di un solo blocco */
	     /* salva blocksize nella IFD */
	       *(UINTx4 *)(TIFSPV_gid[chan].imgpar[img]+12*i+8) = 
						   *TIFSPV_gid[chan].blocksize[img];
	    }
	    else {  /* caso di piu' blocchi */
	       /* salva nella posizione gia' allocata su disco */
	       offs= *(UINTx4 *)(TIFSPV_gid[chan].imgpar[img]+12*i+8);
	       if( fseek(TIFSPV_gid[chan].tf, (INTx8) offs, 0) ) {
		  ERRSIM_set_error( status_code,
				    ERRSID_TIFS_err_on_fseek,
				    TIFSPV_gid[chan].name );
	       }
	       if( fwrite(TIFSPV_gid[chan].blocksize[img],4*length,1,TIFSPV_gid[chan].tf) < 1 ) {
                  ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
                     TIFSPV_gid[chan].name );
               }
	       TIFSPV_gid[chan].actptr=offs+4*length;
	    }

	    /* Parametro blockoffset */
	    /* rintraccia l'offset dove e' stato salvato blockoffs */
	    for(i=0;i<TIFSPV_gid[chan].npar[img];i++) { /* ricerca lineare del tag */
	       tag= *(UINTx2 *)(TIFSPV_gid[chan].imgpar[img]+12*i);
	       if(tag==TILEOFFSET) {
		  break;
	       }
	    }

	    if(i==TIFSPV_gid[chan].npar[img]) { /* controllo se il parametro e' stato salvato precedentemente */
	       ERRSIM_set_error( status_code,
				 ERRSID_TIFS_err_no_param,
				 TIFSPV_gid[chan].name );
	    }

	    length= *(UINTx4 *)(TIFSPV_gid[chan].imgpar[img]+12*i+4);

	    if(length==1) {  /* caso di un solo blocco */
	       /* salva blockoffs nella IFD */
	       *(TIFSPV_gid[chan].imgpar[img]+12*i+8)= *TIFSPV_gid[chan].blockoffs[img];
	    }
	    else {  /* caso di piu' blocchi */
	       /* salva nella posizione gia' allocata su disco */
	       offs= *(UINTx4 *)(TIFSPV_gid[chan].imgpar[img]+12*i+8);
	       if( fseek(TIFSPV_gid[chan].tf, (INTx8) offs, 0) ) {
		  ERRSIM_set_error( status_code,
				    ERRSID_TIFS_err_on_fseek,
				    TIFSPV_gid[chan].name );
	       }
	       if( fwrite(TIFSPV_gid[chan].blockoffs[img],4*length,1,TIFSPV_gid[chan].tf) < 1 ) {
                  ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
                     TIFSPV_gid[chan].name );
               }
	       TIFSPV_gid[chan].actptr=offs+4*length;
	    }
	 }
      }

      TIFSPP_ifd_reorder( chan, status_code ); /* reorder lineare */
      ERRSIM_on_err_goto_exit( *status_code );

      /* si posiziona sul prossimo byte libero */
      if( fseek(TIFSPV_gid[chan].tf, (INTx8) TIFSPV_gid[chan].freeptr, 0) ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_on_fseek,
			   TIFSPV_gid[chan].name );
      }
      TIFSPV_gid[chan].actptr=TIFSPV_gid[chan].freeptr;    

      first_ifd=ftell(TIFSPV_gid[chan].tf);

/* ==========================================================================
      modified 23.09.97 by EL to avoid that in a TTFF file in write mode, are
      stored tags set to zero, when the number of tag effectilvely written is
      less that the number of parameters specified with set_parnum; the true
      number of parameters is TIFSPV_gid[chan].ifd[img]
   ========================================================================== */

      for(img=0;img<TIFSPV_gid[chan].nimg;img++) {
         npar_actw=TIFSPV_gid[chan].ifd[img]; /* this is the true number of stored tags */
	 if( fwrite(&npar_actw,2,1,TIFSPV_gid[chan].tf) < 1 ) {
            ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
               TIFSPV_gid[chan].name );
         }
	 if( fwrite(TIFSPV_gid[chan].imgpar[img],12,npar_actw,TIFSPV_gid[chan].tf) < npar_actw )  {
            ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
               TIFSPV_gid[chan].name );
         }
	 next_ifd=ftell(TIFSPV_gid[chan].tf)+4;
	 if( fwrite(&next_ifd,4,1,TIFSPV_gid[chan].tf) < 1 ) {
            ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
               TIFSPV_gid[chan].name );
         }
	 TIFSPV_gid[chan].actptr+=2+12*npar_actw+4;
      }

      next_ifd=0; /* last ifd */
      if( fseek(TIFSPV_gid[chan].tf,(INTx8) -4, 1) ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_on_fseek,
			   TIFSPV_gid[chan].name );
      }
      if( fwrite(&next_ifd,4,1,TIFSPV_gid[chan].tf) < 1 ) {
         ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
            TIFSPV_gid[chan].name );
      }

      /* (-4) + (+4) = 0 quindi TIFSPV_gid[chan].actptr non e' variato */

      if( fseek(TIFSPV_gid[chan].tf,(INTx8) 4, 0) ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_on_fseek,
			   TIFSPV_gid[chan].name );
      }
      if( fwrite(&first_ifd,4,1,TIFSPV_gid[chan].tf) < 1 ) {
         ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
            TIFSPV_gid[chan].name );
      }

      TIFSPV_gid[chan].actptr=8;
   }
   else if(TIFSPV_gid[chan].mode == 'u') { /* chiusura del file in update */
      /* si posiziona sul prossimo byte libero */
      if( fseek(TIFSPV_gid[chan].tf,(INTx8) TIFSPV_gid[chan].freeptr, 0) ) { 
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_on_fseek,
			   TIFSPV_gid[chan].name );
      }
      TIFSPV_gid[chan].actptr=TIFSPV_gid[chan].freeptr;    

      first_ifd=ftell(TIFSPV_gid[chan].tf);

      for(img=0;img<TIFSPV_gid[chan].nimg;img++) {
	 if( fwrite(&TIFSPV_gid[chan].npar[img],2,1,TIFSPV_gid[chan].tf) < 1 ) {
            ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
               TIFSPV_gid[chan].name );
         }
	 if( fwrite(TIFSPV_gid[chan].imgpar[img],12,TIFSPV_gid[chan].npar[img],TIFSPV_gid[chan].tf) < 
             TIFSPV_gid[chan].npar[img] )  {
            ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
               TIFSPV_gid[chan].name );
         }

	 next_ifd=ftell(TIFSPV_gid[chan].tf)+4;
	 if( fwrite(&next_ifd,4,1,TIFSPV_gid[chan].tf) < 1 ) {
            ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
               TIFSPV_gid[chan].name );
         }

	 TIFSPV_gid[chan].actptr+=2+12*TIFSPV_gid[chan].npar[img]+4;
      }

      next_ifd=0; /* last ifd */
      if( fseek(TIFSPV_gid[chan].tf,(INTx8) -4, 1) ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_on_fseek,
			   TIFSPV_gid[chan].name );
      }
      if( fwrite(&next_ifd,4,1,TIFSPV_gid[chan].tf) < 1 ) {
         ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
            TIFSPV_gid[chan].name );
      }

      /* (-4) + (+4) = 0 quindi TIFSPV_gid[chan].actptr non e' variato */

      if( fseek(TIFSPV_gid[chan].tf,(INTx8) 4, 0) ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_on_fseek,
			   TIFSPV_gid[chan].name );
      }
      if( fwrite(&first_ifd,4,1,TIFSPV_gid[chan].tf) < 1 ) {
         ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
            TIFSPV_gid[chan].name );
      }

      TIFSPV_gid[chan].actptr=8;
   }


   for(img=0;img<TIFSPV_gid[chan].nimg;img++) {

      MEMSIP_free( (void **) &(TIFSPV_gid[chan].imgpar[img]) );
      TIFSPV_gid[chan].ifd[img]=0;

      if(TIFSPV_gid[chan].compression[img]!=1)
	 MEMSIP_free( (void **) &(TIFSPV_gid[chan].lzwbuf[img]) );
/* ==========================================================================
   BY AG: blocksize and blockoffset are always malloc when the image is open
   in write, while they are malloc when the image is open in read and it
   has more than 1 block.
   ========================================================================== */

/* OLD CODE
      if(TIFSPV_gid[chan].blockoffs[img]) {
         if( TIFSPV_gid[chan].nblock[img] > 1 ) {
            MEMSIP_free( (void **) &(TIFSPV_gid[chan].blockoffs[img]) );
         }
         TIFSPV_gid[chan].blockoffs[img]=0;
      }

      if(TIFSPV_gid[chan].blocksize[img]) {
	 if( TIFSPV_gid[chan].nblock[img] > 1 ) {
            MEMSIP_free( (void **) &(TIFSPV_gid[chan].blocksize[img]) );
         }
	 TIFSPV_gid[chan].blocksize[img]=0;
      }
*/


      if( TIFSPV_gid[chan].mode == 'w' ) {
	 if( TIFSPV_gid[chan].blockoffs[img] ) {
	    MEMSIP_free( (void **) &(TIFSPV_gid[chan].blockoffs[img]) );
	 }
      }
      else if ( ( TIFSPV_gid[chan].mode == 'r' ) ||
                ( TIFSPV_gid[chan].mode == 'u' ) ) {
	 if( TIFSPV_gid[chan].nblock[img] > 1 ) {
            if( TIFSPV_gid[chan].blockoffs[img] ) {
	       MEMSIP_free( (void **) &(TIFSPV_gid[chan].blockoffs[img]) );
	    }
	 }
      }
	    
      if( TIFSPV_gid[chan].mode == 'w' ) {
	 if( TIFSPV_gid[chan].blocksize[img] ) {
	    MEMSIP_free( (void **) &(TIFSPV_gid[chan].blocksize[img]) );
	 }
      }
      else if ( ( TIFSPV_gid[chan].mode == 'r' ) ||
                ( TIFSPV_gid[chan].mode == 'u' ) ) {
	 if( TIFSPV_gid[chan].nblock[img] > 1 ) {
            if( TIFSPV_gid[chan].blocksize[img] ) {
	       MEMSIP_free( (void **) &(TIFSPV_gid[chan].blocksize[img]) );
	    }
	 }
      }     

      if(TIFSPV_gid[chan].bitsam[img]) {
         MEMSIP_free( (void **) &(TIFSPV_gid[chan].bitsam[img]) );
         TIFSPV_gid[chan].bitsam[img]=0;
      }

      if(TIFSPV_gid[chan].sampleformat[img]) {
         MEMSIP_free( (void **) &(TIFSPV_gid[chan].sampleformat[img]) );
         TIFSPV_gid[chan].sampleformat[img] = 0;
      }
   }

   TIFSPV_gid[chan].used=0;
   TIFSPV_gid[chan].freeptr=0;
   TIFSPV_gid[chan].actptr=0;
   fclose(TIFSPV_gid[chan].tf);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_close_tiff */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_set_tif

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img:  image 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Trova il numero di immagini presenti in un file TIFF

        $WARNING      NONE

   $EH
   ========================================================================== */
void TIFSIP_set_tif
                       ( /*IN    */ INTx4	         chan,
                         /*IN    */ INTx4                img,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_set_tif";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check input
   ========================================================================== */
   if(TIFSPV_gid[chan].used!=1) {
      ERRSIM_set_error( status_code,
		        ERRSID_TIFS_err_not_opn_tif,
			"" );
   }

/* ==========================================================================
   Set to tif the img image
   ========================================================================== */
   TIFSPV_gid[chan].tif[img] = 1;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_set_tif */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_get_imgnum

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel

        $MODIFIED     NONE

        $OUTPUT       nimg: number of images in TIFF file

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Trova il numero di immagini presenti in un file TIFF

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_get_imgnum ( /*IN    */ INTx4	         chan,
                         /*   OUT*/ INTx4               *nimg,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_get_imgnum";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   if(TIFSPV_gid[chan].used!=1) {
      ERRSIM_set_error( status_code,
		        ERRSID_TIFS_err_not_opn_tif,
			"" );
   }

   *nimg = TIFSPV_gid[chan].nimg;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_get_imgnum */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_get_parnum

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number

        $MODIFIED     NONE

        $OUTPUT       npar: number of parameters

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Trova il numero di parametri di una immagine 
                      in un file TIFF 

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_get_parnum ( /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*   OUT*/ UINTx2              *npar,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_get_parnum";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);


   if(TIFSPV_gid[chan].used!=1) {
      ERRSIM_set_error( status_code,
                        ERRSID_TIFS_err_not_opn_tif,
                        "" );
   }

   if(img>=TIFSPV_gid[chan].nimg) {
      ERRSIM_set_error( status_code,
                        ERRSID_TIFS_err_no_img_num,
                        TIFSPV_gid[chan].name );
   }

   *npar=TIFSPV_gid[chan].npar[img];

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_get_parnum */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_dir_par

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number

        $MODIFIED     NONE

        $OUTPUT       tag: parameters

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Elenca i parametri di una immagine in un file TIFF 

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_dir_par ( /*IN    */ INTx4                chan,
                      /*IN    */ INTx4                img,
                      /*   OUT*/ UINTx2              *tag,
                      /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);


   if(TIFSPV_gid[chan].used!=1) {
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_not_opn_tif,
			"" );
   }

   if(img>=TIFSPV_gid[chan].nimg) {
      ERRSIM_set_error( status_code,
		        ERRSID_TIFS_err_no_img_num,
			TIFSPV_gid[chan].name );
   }

   for(i=0;i<TIFSPV_gid[chan].npar[img];i++) {
      tag[i]= *(UINTx2 *)(TIFSPV_gid[chan].imgpar[img]+12*i);
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* TIFSIP_dir_par */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_get_par

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number

        $MODIFIED     NONE

        $OUTPUT       p: parameter structure

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Estrae un parametro di una immagine in un file TIFF 
                      in un buffer void

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_get_par    ( /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*   OUT*/ TIFSIT_par          *p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_get_par";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4		  i;
   UINTx2                 tag;
   UINTx4                 nsize;
   UINTx4                 offs;
   char                   err_msg[132];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);


   if( TIFSPV_gid[chan].used != 1 ) {
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_not_opn_tif,
			"" );
   }

   if( img >= TIFSPV_gid[chan].nimg ) {
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_no_img_num,
			TIFSPV_gid[chan].name );
   }

   for(i=0;i<TIFSPV_gid[chan].npar[img];i++) { /* ricerca lineare del tag */
      tag= *(UINTx2 *)(TIFSPV_gid[chan].imgpar[img]+12*i);
      if( tag == p->tag ) {
	 break;
      }
   }

   if(i==TIFSPV_gid[chan].npar[img]) {
      sprintf(err_msg,"Param=%0d Img=%s", p->tag, TIFSPV_gid[chan].name);
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_no_param,
			err_msg );
   }

   p->type= *(UINTx2 *)(TIFSPV_gid[chan].imgpar[img]+12*i+2);
   p->length= *(UINTx4 *)(TIFSPV_gid[chan].imgpar[img]+12*i+4);

   nsize=TIFSIV_Size[p->type]*p->length;
   if(nsize<=4) {
      p->val=(TIFSPV_gid[chan].imgpar[img]+12*i+8);
   }
   else {
      if((p->val=MEMSIP_alloc(nsize))==0){  /* alloca il buffer del parametro */
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_not_tag_mem,
			   TIFSPV_gid[chan].name );
      }

      offs= *(UINTx4 *)(TIFSPV_gid[chan].imgpar[img]+12*i+8);
      if( fseek(TIFSPV_gid[chan].tf, (INTx8) offs,0) ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_on_fseek,
			   TIFSPV_gid[chan].name );
      }
      /* fread(p->val,TIFSIV_Size[p->type],p->length,TIFSPV_gid[chan].tf); */
      TIFSPF_readandswap((void *) (p->val), TIFSIV_Size[p->type], p->length, 
                         TIFSPV_gid[chan].tf, TIFSPV_gid[chan].swap_byte);
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* TIFSIP_get_par */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_set_imgnum

        $TYPE	      PROCEDURE

        $INPUT        namefile: TIFF file name
                      nimg: number of images

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Setta il numero di immagini in un file TIFF 

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_set_imgnum ( /*IN    */ char                *namefile,
                         /*IN    */ INTx4                nimg,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_set_imgnum";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4 chan;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

  /* alloca una entry nella area di descrizione file
     (in lettura questa operazione viene svolta  nella open_tiff) */
   for(chan=0;chan<MAX_FILES;chan++) {
      if(TIFSPV_gid[chan].used==0) {
	 TIFSPV_gid[chan].used=1;
	 strcpy(TIFSPV_gid[chan].name,namefile);
	 break;
      }
   }

   if(chan==MAX_FILES) {
      ERRSIM_set_error( status_code,
                        ERRSID_TIFS_err_max_tif_opn,
                        namefile );
   }

   TIFSPV_gid[chan].mode = 'w'; /* marca il file in scrittura */

   TIFSPV_gid[chan].nimg=nimg; /* setta il numero di immagini */

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_set_imgnum */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_set_parnum

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number
                      npar: number of parameters

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Set the number of parameters in a TTFF file in write mode.
                      The number of parameters effectively stored can be less than
		      this. The extra parameters sized but not stored are cut.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_set_parnum ( /*IN    */ char                *namefile,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx2               npar,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_set_parnum";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4 chan;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   TIFSPP_find_chan(namefile,&chan,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   this is the foreseen number of parameters; the actual number of parameters
   is counted in TIFSPV_gid[chan].ifd[img] (modified 23.09.97 in TIFSPP_ifd_reorder
   and in TIFSPP_close_tiff)
   ========================================================================== */
   TIFSPV_gid[chan].npar[img]=npar;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* TIFSIP_set_parnum */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_store_par

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number
                      p: pointer to parameter structure

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Scrive il parametro specificato nella struttura par 
                      del file

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_store_par  ( /*IN    */ INTx4                 chan,
                         /*IN OUT*/ INTx4                 img,
                         /*   OUT*/ TIFSIT_par           *p,
                         /*   OUT*/ ERRSIT_status        *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_store_par";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4      	    i, index_tag, nb;
   UINTx2           tag;
   INTx4	    length_diff;
   TIFSIT_par	   *old_par = (TIFSIT_par *) NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);


   if(TIFSPV_gid[chan].used!=1) {
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_not_opn_tif,
                        "");
   }

   if(TIFSPV_gid[chan].ifd[img]>=TIFSPV_gid[chan].npar[img]) {
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_no_more_par_w,
                        TIFSPV_gid[chan].name );
   }

   nb=TIFSIV_Size[p->type]*p->length;
/********************************************************************************/
/******	    AGGIUNTA 7/2/94 PER L'OVERWRITE DEI PARAMETRI    ********************/
/********************************************************************************/
   old_par = NULL;
   length_diff = 0;
   /* ricerca lineare del tag */
   for( index_tag = 0; index_tag < TIFSPV_gid[chan].npar[img]; index_tag++ ) {
      if ( (tag = *((UINTx2 *)(TIFSPV_gid[chan].imgpar[img] + 12*index_tag))) == 
           p->tag ) {
	 old_par = (TIFSIT_par *)(TIFSPV_gid[chan].imgpar[img] + 12*index_tag);
	 break;
      }
   }

   if ( old_par != NULL ) {  /******  OVERWRITE DEL PARAMETRO  **************************/
      if ( p->type != old_par->type ) {
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_no_ovr_par,
			   TIFSPV_gid[chan].name );
      }
      else {
	 if ( p->length > old_par->length ) {
	    length_diff = 1;/* copia la lunghezza del parametro in ingresso
			       alla routine*/
	 }
	 old_par->length = p->length;

	 if ( nb <= 4 ) {
            for(i=0;i<nb;i++) {
	       *(((char *)old_par) + i + 8)= *((char *)p->val+i);
            }
	 }
	 else {
	    if ( length_diff ) {
	       if( fseek( TIFSPV_gid[chan].tf, (INTx8) TIFSPV_gid[chan].freeptr, 0 ) ) {
		  ERRSIM_set_error( status_code,
				    ERRSID_TIFS_err_on_fseek,
				    TIFSPV_gid[chan].name );
	       }
	       old_par->val = (void *)TIFSPV_gid[chan].freeptr;
	       TIFSPV_gid[chan].freeptr += nb;    
	       TIFSPV_gid[chan].actptr = TIFSPV_gid[chan].freeptr;
	    }
	    else {
	       if( fseek(TIFSPV_gid[chan].tf, (INTx8)old_par->val, 0 ) ) {
		  ERRSIM_set_error( status_code,
				    ERRSID_TIFS_err_on_fseek,
				    TIFSPV_gid[chan].name );
	       }
	       TIFSPV_gid[chan].actptr = (UINTx4)( old_par->val) + nb;
	    }
	    if( fwrite(p->val,nb,1,TIFSPV_gid[chan].tf) < 1 ) {
                  ERRSIM_set_error( status_code,
                                    ERRSID_TIFS_err_wr_bas_par,
                                    TIFSPV_gid[chan].name );
            }
	 }
      }
   }
   else  {
      if( TIFSPV_gid[chan].mode == 'u' ) {
         ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_no_more_par_w,
                           TIFSPV_gid[chan].name );
      }

   /* copia la IFD in ingresso alla routine nell'area descrizione parametri */
/******************************************************************************
      for(i=0;i<8;i++)
         *(TIFSPV_gid[chan].imgpar[img] +TIFSPV_gid[chan].ifd[img]*12 +i)= *((char *)p+i);
*********************************************************************************/
/***********	modifica 20/5/94  usa il riferimento diretto ai membri della struttura
		puntata da p (per evitare problemi di member_alignment 
********************************************************************************************/
      *(UINTx2 *)(TIFSPV_gid[chan].imgpar[img] +TIFSPV_gid[chan].ifd[img]*12)= 
                                                                       p->tag;
      *(UINTx2 *)(TIFSPV_gid[chan].imgpar[img] +TIFSPV_gid[chan].ifd[img]*12 + 2)= 
                                                                      p->type;
      *(UINTx4 *)(TIFSPV_gid[chan].imgpar[img] +TIFSPV_gid[chan].ifd[img]*12 + 4)= 
                                                                    p->length;

      /* scrive il parametro sulla area descrizione o sul file (nel qual caso
	 scrive l'offset a cui e' locato) */
      if(nb<=4) {
         for(i=0;i<nb;i++) {
	    *(TIFSPV_gid[chan].imgpar[img] +TIFSPV_gid[chan].ifd[img]*12 +i +8)= 
							  *((char *)p->val+i);
         }
      }
      else {
	 if( fseek(TIFSPV_gid[chan].tf,(INTx8) TIFSPV_gid[chan].freeptr,0) ) {
	    ERRSIM_set_error( status_code,
			      ERRSID_TIFS_err_on_fseek,
			      TIFSPV_gid[chan].name );
	 }
	 *(UINTx4 *)(TIFSPV_gid[chan].imgpar[img] +TIFSPV_gid[chan].ifd[img]*12 +8) = 
                                             (UINTx4)ftell(TIFSPV_gid[chan].tf);
	 if( fwrite(p->val,nb,1,TIFSPV_gid[chan].tf) < 1 ) {
            ERRSIM_set_error( status_code, ERRSID_TIFS_err_on_fwrite,
               TIFSPV_gid[chan].name );
         }
	 TIFSPV_gid[chan].actptr=TIFSPV_gid[chan].freeptr+nb;
	 TIFSPV_gid[chan].freeptr+=nb;    
      }

      TIFSPV_gid[chan].ifd[img]++; /* incrementa l'indice della prossima IFD */
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* TIFSIP_store_par */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_get_blockinfo

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number
                      bpar: pointer to basic parameter structure

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Legge le informazioni di descrizione dei blocchi

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_get_blockinfo ( /*IN    */ INTx4                chan,
                            /*IN OUT*/ INTx4                img,
                            /*   OUT*/ TIFSIT_basicpar     *bpar,
                            /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_get_blockinfo";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   TIFSIT_par             param;
   INTx4 		  i, nb;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag=TILEOFFSET; /* tile offset */
   TIFSIP_get_par(chan,img,&param,status_code);  

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if( *status_code != ERRSID_normal ) {
      *status_code = STC( ERRSID_normal );
      param.tag=BLOCKOFFSET; /* block offset for Blocked TIFF */
      TIFSIP_get_par(chan,img,&param,status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }  

   if( param.type == TYPE_USHORT ) {
      TIFSPV_gid[chan].blockoffs[img]= (UINTx4 *)param.val;
   }
   else if( param.type == TYPE_UINT ) {
      TIFSPV_gid[chan].blockoffs[img]= (UINTx4 *)param.val;
   }
   else {
      ERRSIM_set_error( status_code, ERRSID_TIFS_not_allow_data_type,
         "TILEOFFSET or BLOCKOFFSET" );
   }

   TIFSPV_gid[chan].nblock[img]=param.length; /* numero di blocchi presenti */

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag=COMPRESSION; /* compression */
   TIFSIP_get_par(chan,img,&param,status_code);

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if( *status_code != ERRSID_normal ) {
      *status_code = STC( ERRSID_normal );
      /* se manca si assume no compression */
      TIFSPV_gid[chan].compression[img]=1;
   } 
   else {
      TIFSPV_gid[chan].compression[img]= *(UINTx2 *)param.val;
   }
   bpar->compression=TIFSPV_gid[chan].compression[img];

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag=TILEBYTECOUNT; /* tile size in bytes come su disco */
   TIFSIP_get_par(chan,img,&param,status_code);

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if( *status_code != ERRSID_normal ) {
      *status_code = STC( ERRSID_normal );
      param.tag=BLOCKBYTECOUNT; /* block size in bytes come su disco per BTIFF*/
      TIFSIP_get_par(chan,img,&param,status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }  
   if( param.type == TYPE_USHORT ) {
      TIFSPV_gid[chan].blocksize[img] = (UINTx4 *)param.val;
   }
   else if( param.type == TYPE_UINT ) {
      TIFSPV_gid[chan].blocksize[img] = (UINTx4 *)param.val;
   }
   else {
      ERRSIM_set_error( status_code, ERRSID_TIFS_not_allow_data_type,
         "TILEBYTECOUNT or BLOCKBYTECOUNT" );
   }

   param.tag=IMAGEWIDTH; /* numero di colonne nell'immagine */
   TIFSIP_get_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   if( param.type == TYPE_USHORT ) {
      TIFSPV_gid[chan].imgcol[img]= (UINTx4) (*((UINTx2 *)param.val));
   }
   else if( param.type == TYPE_UINT ) {
      TIFSPV_gid[chan].imgcol[img]= (*((UINTx4 *)param.val));
   }
   else {
      ERRSIM_set_error( status_code, ERRSID_TIFS_not_allow_data_type,
         "IMAGEWIDTH" );
   }
   bpar->imagewidth=TIFSPV_gid[chan].imgcol[img];

   param.tag=IMAGELENGTH; /* numero di righe dell'immagine */
   TIFSIP_get_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   if( param.type == TYPE_USHORT ) {
      TIFSPV_gid[chan].imgrig[img]= (UINTx4) (*((UINTx2 *)param.val));   
   }
   else if( param.type == TYPE_UINT ) {
      TIFSPV_gid[chan].imgrig[img]= (*((UINTx4 *)param.val));
   }
   else {
      ERRSIM_set_error( status_code, ERRSID_TIFS_not_allow_data_type, 
         "IMAGELENGTH" );
   }
   bpar->imagelength=TIFSPV_gid[chan].imgrig[img];

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag=TILELENGTH; /* numero di righe nel tile */
   TIFSIP_get_par(chan,img,&param,status_code);

   if( *status_code != ERRSID_normal ) {

      *status_code = STC( ERRSID_normal );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      param.tag=ROWSPERBLOCK; /* numero di righe nel blocco per BTIFF/TIF */
      TIFSIP_get_par(chan,img,&param,status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      if( param.type == TYPE_USHORT ) {
         TIFSPV_gid[chan].blockrig[img]= (UINTx4) (*((UINTx2 *)param.val));
      }
      else if( param.type == TYPE_UINT ) {
         TIFSPV_gid[chan].blockrig[img]= (*((UINTx4 *)param.val));
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_TIFS_not_allow_data_type,
            "ROWSPERBLOCK" );
      }
   }  
   else {
      if( param.type == TYPE_USHORT ) {
         TIFSPV_gid[chan].blockrig[img]= (UINTx4) (*((UINTx2 *)param.val));
      }
      else if( param.type == TYPE_UINT ) {
         TIFSPV_gid[chan].blockrig[img]= (*((UINTx4 *)param.val));
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_TIFS_not_allow_data_type,
            "TILELENGTH" );
      }
   }
   bpar->rowsperblock=TIFSPV_gid[chan].blockrig[img];

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag=TILEWIDTH; /* numero di colonne nel tile */
   TIFSIP_get_par(chan,img,&param,status_code);

   if( *status_code != ERRSID_normal ) {
      *status_code = STC( ERRSID_normal );
      param.tag=COLUMNSPERBLOCK; /* numero di righe nel blocco per BTIFF*/
      TIFSIP_get_par(chan,img,&param,status_code);
      /* se manca si assume pari all' image width */
      if( *status_code != ERRSID_normal ) {
	 *status_code = STC( ERRSID_normal );
         param.type=TYPE_UINT;
	 param.val=(void *)&bpar->imagewidth; /* nel tiff standard il blocco coincide con la strip */
      }
   }
   if( param.type == TYPE_USHORT ) {
      TIFSPV_gid[chan].blockcol[img] = (UINTx4) (*((UINTx2 *)param.val));
   }
   else if( param.type == TYPE_UINT ) {
      TIFSPV_gid[chan].blockcol[img] = (*((UINTx4 *)param.val)); 
   }
   else {
      ERRSIM_set_error( status_code, ERRSID_TIFS_not_allow_data_type,
         "TILEWIDTH or COLUMNSPERBLOCK" );
   }
   bpar->columnsperblock=TIFSPV_gid[chan].blockcol[img];

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;


   param.tag=SAMPLEPERPIXEL; /* numero di campioni per un pixel */
   TIFSIP_get_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   TIFSPV_gid[chan].sampix[img]= *(UINTx2 *)param.val; 
   bpar->sampleperpixel=TIFSPV_gid[chan].sampix[img];

   /* crea il vettore bitspersample (short) */
   if((TIFSPV_gid[chan].bitsam[img]=
                 (UINTx2 *)MEMSIP_alloc(2*bpar->sampleperpixel))==0) {
      ERRSIM_set_error( status_code,
                        ERRSID_TIFS_err_not_tag_mem,
                        TIFSPV_gid[chan].name );
   }
  
   param.tag=BITSPERSAMPLE; /* numero di bits usati per un campione */
   TIFSIP_get_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   for(i=0;i<bpar->sampleperpixel;i++) {
      TIFSPV_gid[chan].bitsam[img][i]=((UINTx2 *)param.val)[i];
      bpar->bitspersample[i]=TIFSPV_gid[chan].bitsam[img][i];
   }

   if( TIFSIV_Size[param.type]*param.length > 4 ) {
      MEMSIP_free( (void **) &param.val );
   }

   param.tag=PHOTOMETRICINTERPRETATION; /* specifica il tipo di immagine (es. palette,RGB) ecc... */
   TIFSIP_get_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   TIFSPV_gid[chan].photometricinterpretation[img]= *(UINTx2 *)param.val;
   bpar->photometricinterpretation=TIFSPV_gid[chan].photometricinterpretation[img];

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag=XRESOLUTION; /* risoluzione lungo X */
   TIFSIP_get_par(chan,img,&param,status_code);


/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if( *status_code != ERRSID_normal ) {
      /* se manca si assume 300 */
      *status_code = STC( ERRSID_normal );
      *(UINTx4 *)param.val=300;
      *((UINTx4 *)param.val + 1)=1;
   }
   TIFSPV_gid[chan].xresolution[img][0]= *(UINTx4 *)param.val;
   TIFSPV_gid[chan].xresolution[img][1]= *((UINTx4 *)param.val + 1);
   if( TIFSIV_Size[param.type]*param.length > 4 ) {
      MEMSIP_free( (void **) &param.val );
   }
   bpar->xresolution[0]=TIFSPV_gid[chan].xresolution[img][0];
   bpar->xresolution[1]=TIFSPV_gid[chan].xresolution[img][1];

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag=YRESOLUTION; /* risoluzione lungo Y */
   TIFSIP_get_par(chan,img,&param,status_code);

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if( *status_code != ERRSID_normal ) {
      /* se manca si assume 300 */
      *status_code = STC( ERRSID_normal );
      *(UINTx4 *)param.val=300;
      *((UINTx4 *)param.val + 1)=1;
   }
   TIFSPV_gid[chan].yresolution[img][0]= *(UINTx4 *)param.val;
   TIFSPV_gid[chan].yresolution[img][1]= *((UINTx4 *)param.val + 1);
   if( TIFSIV_Size[param.type]*param.length > 4 ) {
      MEMSIP_free( (void **) &param.val );
   }
   bpar->yresolution[0]=TIFSPV_gid[chan].yresolution[img][0];
   bpar->yresolution[1]=TIFSPV_gid[chan].yresolution[img][1];

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag=RESOLUTIONUNIT; /* unita' in cui e' misurata la risoluzione */
   TIFSIP_get_par(chan,img,&param,status_code);

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if( *status_code != ERRSID_normal ) {
      /* se manca si assume inch */
      *status_code = STC( ERRSID_normal );
      *(UINTx4 *)param.val=2;
   }
   TIFSPV_gid[chan].resolutionunit[img]= *(UINTx2 *)param.val;
   bpar->resolutionunit=TIFSPV_gid[chan].resolutionunit[img];

   /* allocates the array for sampleformat */
   if ( (TIFSPV_gid[chan].sampleformat[img] =
         (UINTx2 *)MEMSIP_alloc(sizeof(UINTx2)*bpar->sampleperpixel))==0) {
      ERRSIM_set_error( status_code,
                        ERRSID_TIFS_err_not_tag_mem,
                        TIFSPV_gid[chan].name );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag=SAMPLEFORMAT;        /* pixel data type*/
   TIFSIP_get_par(chan,img,&param,status_code);

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if( *status_code != ERRSID_normal ) {

/* ==========================================================================
   Set a default for not founded value. The default is based on the standard
   products RAW, PRI, GEC, GTC, SLC, SLCI and floating point internal product
   of Toolbox. This is necessary only when the data are not deformatted from
   CEOS
   ========================================================================== */
      *status_code = STC( ERRSID_normal );
      switch ( bpar->sampleperpixel ) {
         case 1:

            /* real data */
            switch ( bpar->bitspersample[ 0 ] ) {
               case  8:
                  /* it is a standard TIFF file */
                  TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] = TIFSID_uintdata;

               case 16:

		  /* PRI, GEC and GTC data */
		  TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] = TIFSID_uintdata;
               break;
               case 32:

                  /* products in internal floating format */
                  TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] = TIFSID_float;
               break;
            }
         break;
         case 2:

            /* complex data */
            switch ( bpar->bitspersample[ 0 ] ) {
               case 8:

                  /* RAW data */
		  TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] = TIFSID_uintdata;
		  TIFSPV_gid[ chan ].sampleformat[ img ][ 1 ] = TIFSID_uintdata;
               break;
               case 16:

		  /* SLC data */
		  TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] = TIFSID_sintdata;
		  TIFSPV_gid[ chan ].sampleformat[ img ][ 1 ] = TIFSID_sintdata;
               break;
               case 32:

                  /* products in internal floating format */
                  TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] = TIFSID_float;
                  TIFSPV_gid[ chan ].sampleformat[ img ][ 1 ] = TIFSID_float;
               break;
            }
         break;
      }
      for (i=0;i<bpar->sampleperpixel;i++) {
         bpar->sampleformat[i] = TIFSPV_gid[chan].sampleformat[img][i];
      }
   } else {

      /* fills the array of pointers with the founded value */
      for (i=0;i<bpar->sampleperpixel;i++) {
         TIFSPV_gid[chan].sampleformat[img][i] = ( (UINTx2 *)param.val)[i];
         bpar->sampleformat[i] = TIFSPV_gid[chan].sampleformat[img][i];
      }
      if( TIFSIV_Size[param.type]*param.length > 4 ) {
	 MEMSIP_free( (void **) &param.val );
      }
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag=DISPOSITION; /* disposizione dei blocchi su disk per BTIFF */
   TIFSIP_get_par(chan,img,&param,status_code);

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if( *status_code != ERRSID_normal ) {
      /* se manca si assume x */	
      *status_code = STC( ERRSID_normal );
      *(char *)param.val='x';
   }
   TIFSPV_gid[chan].disp[img]= *(char *)param.val;
   
#ifdef TIFS_XY
   bpar->disposition=TIFSPV_gid[chan].disp[img];
#endif

   /* se l'immagine e' compressa crea il buffer per il compressore (2 volte la dimensione del blocco per sicurezza */
   if(TIFSPV_gid[chan].compression[img]==5) {
      /* numero di byte per blocco non compresso */
      nb=bpar->columnsperblock*bpar->rowsperblock*bpar->sampleperpixel
	 *(bpar->bitspersample[0]/8);
      if((TIFSPV_gid[chan].lzwbuf[img]= (UINTx1 *)MEMSIP_alloc(2*nb))==0) {
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_no_mem_lzw,
			   TIFSPV_gid[chan].name );
      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_get_blockinfo */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_set_blockinfo

        $TYPE	      PROCEDURE

        $INPUT        namefile: TIFF file name
                      img: image number
                      bpar: pointer to basic parameter structure

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Setta le informazioni fondamentali di una immagine 
                      in un file TIFF 

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_set_blockinfo ( /*IN    */ char                *namefile,
                            /*IN    */ INTx4                img,
                            /*   OUT*/ TIFSIT_basicpar     *bpar,
                            /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_set_blockinfo";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4 chan,i,nblock,xnblock,ynblock,nb;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   TIFSPP_find_chan(namefile,&chan,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   if((bpar->compression!=1)&&(bpar->compression!=5)) {
      ERRSIM_set_error( status_code,
                        ERRSID_error,
                        namefile );
   }

   /* calcolo del numero di blocchi nell' immagine (serve per allocare la memoria per blockoffset e blocksize) */
   xnblock=(bpar->imagewidth+bpar->columnsperblock - 1)/bpar->columnsperblock;
   ynblock=(bpar->imagelength+bpar->rowsperblock - 1)/bpar->rowsperblock;
   nblock=xnblock*ynblock;
   TIFSPV_gid[chan].nblock[img]=nblock;

   /* numero di byte per blocco non compresso */
   nb=bpar->columnsperblock*bpar->rowsperblock*bpar->sampleperpixel
			     *(bpar->bitspersample[0]/8);
  
   /* alloca la memoria per il vettore di block offset */
   if( (TIFSPV_gid[chan].blockoffs[img]=(UINTx4 *)MEMSIP_alloc(nblock*4))==0) {
      ERRSIM_set_error( status_code,
                        ERRSID_TIFS_err_no_mem_blk,
                        namefile );
   }
    
   /* alloca la memoria per il vettore di block size */
   if( (TIFSPV_gid[chan].blocksize[img]=(UINTx4 *)MEMSIP_alloc(nblock*4))==0) {
      ERRSIM_set_error( status_code,
                        ERRSID_TIFS_err_no_mem_blk,
                        namefile );
   }

   if(bpar->compression==5) {
   /* crea il buffer per il compressore. Per sicurezza (espansione) 2 volte la dimensione del blocco*/
      if((TIFSPV_gid[chan].lzwbuf[img]=(UINTx1 *)MEMSIP_alloc(2*nb))==0) {
	 ERRSIM_set_error( status_code,
			   ERRSID_TIFS_err_no_mem_lzw,
			   namefile );
      }
   }

   /* memorizzazione nella struttura globale dei parametri basilari */
   TIFSPV_gid[chan].imgcol[img]=bpar->imagewidth;
   TIFSPV_gid[chan].imgrig[img]=bpar->imagelength;
   TIFSPV_gid[chan].blockcol[img]=bpar->columnsperblock;
   TIFSPV_gid[chan].blockrig[img]=bpar->rowsperblock;
   TIFSPV_gid[chan].sampix[img]=bpar->sampleperpixel;
   TIFSPV_gid[chan].photometricinterpretation[img]=bpar->photometricinterpretation;
   TIFSPV_gid[chan].xresolution[img][0]=bpar->xresolution[0];
   TIFSPV_gid[chan].xresolution[img][1]=bpar->xresolution[1];
   TIFSPV_gid[chan].yresolution[img][0]=bpar->yresolution[0];
   TIFSPV_gid[chan].yresolution[img][1]=bpar->yresolution[1];
   TIFSPV_gid[chan].resolutionunit[img]=bpar->resolutionunit;
   TIFSPV_gid[chan].compression[img]=bpar->compression;
#ifdef TIFS_XY
   TIFSPV_gid[chan].disp[img]=bpar->disposition;
#else
   TIFSPV_gid[chan].disp[img]='x';
#endif

   /* crea il vettore bitspersample (short) */
   if((TIFSPV_gid[chan].bitsam[img]=
                 (UINTx2 *)MEMSIP_alloc(sizeof(UINTx2)*bpar->sampleperpixel))==0) {
      ERRSIM_set_error( status_code,
                        ERRSID_TIFS_err_not_tag_mem,
                        namefile );
   }
  
   /* copia il vettore bitpersample */
   for(i=0;i<bpar->sampleperpixel;i++) {
      TIFSPV_gid[chan].bitsam[img][i]=bpar->bitspersample[i];
   }

   /* crea il vettore sampleformat */
   if ((TIFSPV_gid[chan].sampleformat[img] =
          (UINTx2 *)MEMSIP_alloc(sizeof(UINTx2)*bpar->sampleperpixel)) == 0 ) {
      ERRSIM_set_error( status_code,
                        ERRSID_TIFS_err_not_tag_mem,
                        namefile );
   }

   /* copia il vettore sampleformat */
   for (i=0;i<bpar->sampleperpixel;i++)
      TIFSPV_gid[chan].sampleformat[img][i] = bpar->sampleformat[i];

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* TIFSIP_set_blockinfo */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_store_blockinfo

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Scrive i parametri fondamentali dell' immagine

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_store_blockinfo ( /*IN    */ INTx4                chan,
                              /*IN    */ INTx4                img,
                              /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_store_blockinfo";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;


   TIFSIT_par   param;
   UINTx4       nb;
   UINTx4       i;
  
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);


   param.tag=IMAGEWIDTH; /* Numero di colonne dell'immagine */
   param.type=4;  /* Long */
   param.length=1;
   param.val=(void *)&TIFSPV_gid[chan].imgcol[img];
   TIFSIP_store_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   param.tag=IMAGELENGTH; /* Numero di righe dell'immagine */
   param.type=4;  /* Long */
   param.length=1;
   param.val=(void *)&TIFSPV_gid[chan].imgrig[img];
   TIFSIP_store_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   param.tag=BITSPERSAMPLE; /* Bits per Sample */
   param.type=3;  /* Short*/
   param.length=TIFSPV_gid[chan].sampix[img];
   param.val=(void *)TIFSPV_gid[chan].bitsam[img];
   TIFSIP_store_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   if( TIFSPV_gid[chan].tif[img] == 0 ) {
      param.tag=SAMPLEFORMAT; /* pixel data type */
      param.type=3;  /* Short*/
      param.length=TIFSPV_gid[chan].sampix[img];
      param.val=(void *)TIFSPV_gid[chan].sampleformat[img];
      TIFSIP_store_par(chan,img,&param,status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

   param.tag=COMPRESSION; /* Tipo di compressione */
   param.type=3;  /* Short */
   param.length=1;
   param.val=(void *)&TIFSPV_gid[chan].compression[img];
   TIFSIP_store_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   param.tag=PHOTOMETRICINTERPRETATION; /*  */
   param.type=3;  /* Short */
   param.length=1;
   param.val=(void *)&TIFSPV_gid[chan].photometricinterpretation[img];
   TIFSIP_store_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   param.tag=SAMPLEPERPIXEL; /* Samples per Pixel */
   param.type=3;  /* Short */
   param.length=1;
   param.val=(void *)&TIFSPV_gid[chan].sampix[img];
   TIFSIP_store_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   /* Store del TILELENGTH */
   if( TIFSPV_gid[chan].tif[img] == 0 ) {
      param.tag=TILELENGTH; /* number of rows per block for tiled tiff */ 
   }
   else {
      param.tag=ROWSPERBLOCK; /* number of rows per block STRIP TIFF */
   }     
   param.type=4;  /* Long */
   param.length=1;
   param.val=(void *)&TIFSPV_gid[chan].blockrig[img];
   TIFSIP_store_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   param.tag=XRESOLUTION; /* Risoluzione lungo X */
   param.type=5;  /* Rational */
   param.length=1;
   param.val=(void *) TIFSPV_gid[chan].xresolution[img];
   TIFSIP_store_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   param.tag=YRESOLUTION; /* Risoluzione lungo Y */
   param.type=5;  /* Rational */
   param.length=1;
   param.val=(void *) TIFSPV_gid[chan].yresolution[img];
   TIFSIP_store_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   param.tag=RESOLUTIONUNIT; /* Unita' in cui la risoluzione e' misurata */
   param.type=3;  /* Short */
   param.length=1;
   param.val=(void *)&TIFSPV_gid[chan].resolutionunit[img];
   TIFSIP_store_par(chan,img,&param,status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   /* Store del TILEWIDTH */
   if( TIFSPV_gid[chan].tif[img] == 0 ) {
      param.tag=TILEWIDTH; /* Numero di colonne per blocco */
      param.type=4;  /* Long */
      param.length=1;
      param.val=(void *)&TIFSPV_gid[chan].blockcol[img];
      TIFSIP_store_par(chan,img,&param,status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

#ifdef TIFS_XY
   if( TIFSPV_gid[chan].tif[img] == 0 ) {
      param.tag=DISPOSITION; /* Disposizione dei blocchi su nastro o disco */
      param.type=2;  /* ASCII */
      param.length=1;
      param.val=(void *)&TIFSPV_gid[chan].disp[img];
      TIFSIP_store_par(chan,img,&param,status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }
#endif

   /* Se non c'e' compressione calcola il blockoffset, salvalo e riserva alla 
      fine del parametro lo spazio per l'immagine */

   if(TIFSPV_gid[chan].compression[img]==1) {  /* Niente compressione */
      /* calcolo blocksize */
      /* numero bytes per blocco non compresso */
      nb=TIFSPV_gid[chan].blockcol[img]*TIFSPV_gid[chan].blockrig[img]*
	       TIFSPV_gid[chan].sampix[img]*(TIFSPV_gid[chan].bitsam[img][0]/8);

      for(i=0;i<TIFSPV_gid[chan].nblock[img];i++) { /* setta blocksize */
	 TIFSPV_gid[chan].blocksize[img][i]=nb;
      }

      /* Store del TILEBYTECOUNT */
      if( TIFSPV_gid[chan].tif[img] == 0 ) {
         param.tag=TILEBYTECOUNT; /* blocks size in bytes for tiled tiff */ 
      }
      else {
         param.tag=BLOCKBYTECOUNT; /* blocks size in bytes as STRIP TIFF*/
      }     
      param.type=4;  /* Long */
      param.length=TIFSPV_gid[chan].nblock[img];
      param.val=(void *)TIFSPV_gid[chan].blocksize[img];
      TIFSIP_store_par(chan,img,&param,status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      /* calcolo blockoffset a seconda della disposizione */
      TIFSPP_disp_evaluate( chan, 
                            img,
                            status_code ); 
      ERRSIM_on_err_goto_exit( *status_code );

      /* Store del TILEOFFSET */
      if( TIFSPV_gid[chan].tif[img] == 0 ) {
         param.tag=TILEOFFSET; /* blocks offset as TILED TIFF*/ 
      }
      else {
         param.tag=BLOCKOFFSET; /* blocks offset as STRIP TIFF*/
      }     
      param.type=4;  /* Long */
      param.length=TIFSPV_gid[chan].nblock[img];
      param.val=(void *)TIFSPV_gid[chan].blockoffs[img];
      TIFSIP_store_par(chan,img,&param,status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      /* riserva lo spazio per l'immagine */
      TIFSPV_gid[chan].freeptr+=nb*TIFSPV_gid[chan].nblock[img];
  }

   /* Se c'e' compressione salva blockoffset e blocksize (anche se non contengono
      nulla) per riservare lo spazio per tali parametri. Al close del file verra' 
      salvato il valore corretto, nell'area allocata ora */
  else {

      /* Dummy store del TILEBYTECOUNT per riservare l'area su disco */
      param.tag=TILEBYTECOUNT; /* blocks size in bytes */
      param.type=4;  /* Long */
      param.length=TIFSPV_gid[chan].nblock[img];
      param.val=(void *)TIFSPV_gid[chan].blocksize[img];
      TIFSIP_store_par(chan,img,&param,status_code);
      ERRSIM_on_err_goto_exit( *status_code );
    
      /* Dummy store del TILEOFFSET per riservare l'area su disco */
      param.tag=TILEOFFSET; /* blocks offset */
      param.type=4;  /* Long */
      param.length=TIFSPV_gid[chan].nblock[img];
      param.val=(void *)TIFSPV_gid[chan].blockoffs[img];
      TIFSIP_store_par(chan,img,&param,status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

  /* alloca il vettore di flags blocco gia' salvato usato in writeline*/
   if((TIFSPV_gid[chan].blkflag[img]=
    (UINTx1 *)MEMSIP_alloc(TIFSPV_gid[chan].nblock[img]))==0) { /* vettore di flags blocco gia' salvato */
      ERRSIM_set_error( status_code,
		        ERRSID_TIFS_err_no_mem_flg,
                        TIFSPV_gid[chan].name );
   }
   for(i=0;i<TIFSPV_gid[chan].nblock[img];i++) {
      TIFSPV_gid[chan].blkflag[img][i]=0; /* flag=0 cioe' blocco non salvato */
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_store_blockinfo */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_open_line

        $TYPE	      PROCEDURE

        $INPUT        chan        : TIFF channel
		      img         : image number
		      direction   : 'x' or 'y'
		      samplestart : first sample in line
		      sampleend   : last sample in line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       TIFSPV_gid[ chan ]

        $RET_STATUS   ERRSID_TIFS_max_chan
                      ERRSID_TIFS_max_img
                      ERRSID_TIFS_err_no_mem_bufl
                      ERRSID_TIFS_memory_alloc_failure
                      ERRSID_TIFS_not_allow_data_type
                      ERRSID_TIFS_mode_not_set

        $DESCRIPTION  This procedure opens the reading or the writing of a line.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_open_line
                       (/*IN    */ INTx4                chan,
                        /*IN    */ INTx4                img,
                        /*IN    */ char                 direction,
                        /*IN    */ UINTx4               samplestart,
                        /*IN    */ UINTx4               sampleend,
                        /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_open_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4      	          i;
   UINTx4                 linebufsize;
   UINTx4                 blockbufsize;
   UINTx4                 linebufoffs;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code);

/* ==========================================================================
   Check the channel number
   ========================================================================== */
   if ( chan >= MAX_FILES ) {
      ERRSIM_set_error ( status_code, ERRSID_TIFS_max_chan, "" );
   }

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( img >= MAX_IMAGES ) {
      ERRSIM_set_error ( status_code, ERRSID_TIFS_max_img, "" );
   }

/* ==========================================================================
   TIFF file channel
   ========================================================================== */
   /* numero di blocchi nella direzione x nell'immagine */
   TIFSPV_gid[chan].nblkx[img]=
      (TIFSPV_gid[chan].imgcol[img]+TIFSPV_gid[chan].blockcol[img]-1)/TIFSPV_gid[chan].blockcol[img];

   /* size in bytes della linea */
   TIFSPV_gid[chan].linesize[img]=(sampleend-samplestart+1)*
	    TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;

   if(tolower(direction)=='x') { /* lettura linea lungo x */
      /* coordinata x del blocco iniziale */
      TIFSPV_gid[chan].blkstart[img]=
	 (samplestart+TIFSPV_gid[chan].blockcol[img])/TIFSPV_gid[chan].blockcol[img]-1;

      /* coordinata x del blocco finale  */
      TIFSPV_gid[chan].blkend[img]=
	 (sampleend+TIFSPV_gid[chan].blockcol[img])/TIFSPV_gid[chan].blockcol[img]-1;

      /* dimensione in numero di bytes, del buffer di blocco nella direzione x */
      TIFSPV_gid[chan].blkbufdim[img]=
	 TIFSPV_gid[chan].blockcol[img]*
		      TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
    
      /* dimensione in numero di bytes del buffer di linea nella direzione x */
      TIFSPV_gid[chan].linebufdim[img]=
    (TIFSPV_gid[chan].blkend[img]-TIFSPV_gid[chan].blkstart[img]+1)*TIFSPV_gid[chan].blockcol[img]*
     TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;

      /* dimensione in numero di bytes del buffer di linea */
      linebufsize=TIFSPV_gid[chan].linebufdim[img]*TIFSPV_gid[chan].blockrig[img];

      /* numero di bytes di offset del primo campione (relativo cioe' a samplestart) della prima linea del buffer di linea */ 
      linebufoffs=
	 (samplestart-TIFSPV_gid[chan].blkstart[img]*TIFSPV_gid[chan].blockcol[img])*
	  TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;

   }

   else if(tolower(direction)=='y') { /* lettura linea lungo y */
      /* coordinata y del blocco iniziale */
      TIFSPV_gid[chan].blkstart[img]=
	 (samplestart+TIFSPV_gid[chan].blockrig[img])/TIFSPV_gid[chan].blockrig[img]-1;

      /* coordinata y del blocco finale  */
      TIFSPV_gid[chan].blkend[img]=
	 (sampleend+TIFSPV_gid[chan].blockrig[img])/TIFSPV_gid[chan].blockrig[img]-1;
    
      /* dimensione in numero di bytes, del buffer di blocco nella direzione y */
      TIFSPV_gid[chan].blkbufdim[img]=
       TIFSPV_gid[chan].blockrig[img]*TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;

      /* dimensione in numero di bytes del buffer di linea nella direzione y */
      TIFSPV_gid[chan].linebufdim[img]=
      (TIFSPV_gid[chan].blkend[img]-TIFSPV_gid[chan].blkstart[img]+1)*TIFSPV_gid[chan].blockrig[img]*
       TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;

      /* dimensione in numero di bytes del buffer di linea */
      linebufsize=TIFSPV_gid[chan].linebufdim[img]*TIFSPV_gid[chan].blockcol[img];

      /* numero di bytes di offset del primo campione (relativo cioe' a 
	 samplestart) della prima linea del buffer di linea */ 
      linebufoffs=
	 (samplestart-TIFSPV_gid[chan].blkstart[img]*TIFSPV_gid[chan].blockrig[img])*
	 TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
   }

   /* alloca buffer linee (piu' blocchi) */
   if((TIFSPV_gid[chan].linebuf[img]=(UINTx1 *)MEMSIP_alloc(linebufsize))==0) { 
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_no_mem_bufl,
			TIFSPV_gid[chan].name );
   }

   TIFSPV_gid[chan].linebufbase[img]=TIFSPV_gid[chan].linebuf[img]+linebufoffs;

   blockbufsize=
      TIFSPV_gid[chan].blockrig[img]*TIFSPV_gid[chan].blockcol[img]*
	 TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;

   /* alloca buffer per 1 blocco */
   if((TIFSPV_gid[chan].blockbuf[img]=(UINTx1 *)MEMSIP_alloc(blockbufsize))==0) {
      ERRSIM_set_error( status_code,
			ERRSID_TIFS_err_no_mem_bufb,
			TIFSPV_gid[chan].name );
   }

   TIFSPV_gid[chan].minline[img]=LINEMAX; /* reset di minline */
   TIFSPV_gid[chan].direction[img]=direction;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_open_line */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_read_line

        $TYPE	      PROCEDURE

        $INPUT        chan       : TIFF channel
		      img        : image number
                      linenumber : line to be read

        $MODIFIED     NONE

        $OUTPUT       bufout     : address of pointer to void buffer

        $GLOBAL       TIFSPV_gid[ chan ]

        $RET_STATUS   ERRSID_TIFS_max_chan

        $DESCRIPTION  This procedure reads a line from a TIFF file.

        $WARNING      NONE

   $EH
   ========================================================================== */
void TIFSIP_read_line
                      ( /*IN    */ INTx4                chan,
                        /*IN    */ INTx4                img,
                        /*IN    */ UINTx4               linenumber,
                        /*   OUT*/ void               **bufout,
                        /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_read_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4      		  i,x,y,blkx,blky,remain,block,block1,block2;
   UINTx4                 blocky,remain1,remain2;
   UINTx1                *plin;
   UINTx1                *plinbase;
   UINTx1                *pblk;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image channel
   ========================================================================== */
   if ( chan >= MAX_FILES ) {
      ERRSIM_set_error ( status_code, ERRSID_TIFS_max_chan, "" );
   }

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( img >= MAX_IMAGES ) {
      ERRSIM_set_error ( status_code, ERRSID_TIFS_max_img, "" );
   }

/* ==========================================================================
   TIFF file channel
   ========================================================================== */
   if(tolower(TIFSPV_gid[chan].direction[img])=='x') { /* lettura linea lungo x */
      /* linea non presente in memoria */
      if((linenumber<TIFSPV_gid[chan].minline[img])||
	 (linenumber>(TIFSPV_gid[chan].minline[img]+TIFSPV_gid[chan].blockrig[img]-1))) {
	 /* numero di blocco nella direzione y cui appartiene la linea da leggere */
	 blky=(linenumber+TIFSPV_gid[chan].blockrig[img])/TIFSPV_gid[chan].blockrig[img]-1;
	 /* numero di bytes di differenza tra la lunghezza del buffer di linea e di blocco nella direzione di lettura */
	 remain=TIFSPV_gid[chan].linebufdim[img]-TIFSPV_gid[chan].blkbufdim[img];

	 block1=TIFSPV_gid[chan].blkstart[img]+blky*TIFSPV_gid[chan].nblkx[img];
	 block2=TIFSPV_gid[chan].blkend[img]+blky*TIFSPV_gid[chan].nblkx[img];
	 for(block=block1;block<=block2;block++) {
	    TIFSPF_get_block(chan,img,block,
			     TIFSPV_gid[chan].blockbuf[img],status_code);
	    ERRSIM_on_err_goto_exit( *status_code );

	    /* copia buffer di un blocco nel buffer di linea */
	    plin = TIFSPV_gid[chan].linebuf[img]+(block-block1)*
	       TIFSPV_gid[chan].blkbufdim[img]; /* setta il puntatore nel 
					    buffer di linea all'inizio */
	    pblk=TIFSPV_gid[chan].blockbuf[img]; /* setta il puntatore nel blocco 
					     all'inizio */
	    for(y=0;y<TIFSPV_gid[chan].blockrig[img];y++) { /* loop sulle righe del blocco */
	       for(x=0;x<TIFSPV_gid[chan].blkbufdim[img];x++) { /* loop sulle colonne del blocco */
		  *plin = *pblk;
		  pblk++;
		  plin++;
	       }
	       plin += remain;
	    }
	 }
	 TIFSPV_gid[chan].minline[img] = blky*TIFSPV_gid[chan].blockrig[img];
      }
   }
   else if(tolower(TIFSPV_gid[chan].direction[img])=='y') { /* lettura linea lungo y */
      /* linea non presente in memoria */
      if((linenumber<TIFSPV_gid[chan].minline[img])||
	 (linenumber>(TIFSPV_gid[chan].minline[img]+TIFSPV_gid[chan].blockcol[img]-1))) {
	 /* numero di blocco nella direzione x cui appartiene la linea da leggere */
	 blkx=(linenumber+TIFSPV_gid[chan].blockcol[img])/TIFSPV_gid[chan].blockcol[img]-1;
	 /* dimensione del buffer di linea nella direzione di lettura -1 sample */
	 remain= TIFSPV_gid[chan].linebufdim[img];
	 remain1=TIFSPV_gid[chan].linebufdim[img]*TIFSPV_gid[chan].blockcol[img]-
			   TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
	 remain2=TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
	 blocky=0;
	 block1=blkx+TIFSPV_gid[chan].blkstart[img]*TIFSPV_gid[chan].nblkx[img];
	 block2=blkx+TIFSPV_gid[chan].blkend[img]*TIFSPV_gid[chan].nblkx[img];
	 for(block=block1;block<=block2;block+=TIFSPV_gid[chan].nblkx[img]) {
	    TIFSPF_get_block(chan,img,block,
			     TIFSPV_gid[chan].blockbuf[img],status_code);
	    ERRSIM_on_err_goto_exit( *status_code );

	    /* loop sui bytes di un sample */
	    for(i=0;i<TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;i++) { 
	       plin=TIFSPV_gid[chan].linebuf[img]+blocky*TIFSPV_gid[chan].blockrig[img]* 
		      TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8 + i;
	       /* setta il puntatore nel blocco all'inizio */
	       pblk=TIFSPV_gid[chan].blockbuf[img] + i; 
	       /* copia buffer di un blocco nel buffer di linea */
	       for(y=0;y<TIFSPV_gid[chan].blockrig[img];y++) { /* loop sulle righe del blocco */
		  for(x=0;x<TIFSPV_gid[chan].blockcol[img];x++) { /* loop sulle colonne del blocco */
		     *plin = *pblk;
		     pblk+=remain2;
		     plin += remain;
		  }
		  plin -= remain1;
	       }
	    }
	    blocky++;
	 }
	 TIFSPV_gid[chan].minline[img] = blkx*TIFSPV_gid[chan].blockcol[img];
      }
   }

   *bufout=
      (void *)(TIFSPV_gid[chan].linebufbase[img]+
      (linenumber-TIFSPV_gid[chan].minline[img])*TIFSPV_gid[chan].linebufdim[img]);


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_read_line */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_write_line

        $TYPE	      PROCEDURE

        $INPUT        chan       : TIFF channel
		      img        : image number
                      linenumber : line to be read
                      bufin      : pointer to void buffer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       TIFSPV_gid[ chan ] 

        $RET_STATUS   ERRSID_TIFS_max_chan

        $DESCRIPTION  This procedure writes a line from a TIFF file.

        $WARNING      NONE

   $EH
   ========================================================================== */
void TIFSIP_write_line ( /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx4               linenumber,
                         /*   OUT*/ void                *bufin,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_write_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i,blkx,blky,blocky,block,block1,block2,x,y;
   UINTx4                 remain,remain1,remain2;
   UINTx1                *plin;
   UINTx1                *pblk;
   UINTx1                *pin;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);
      
/* ==========================================================================
   Check the TIFF channel
   ========================================================================== */
   if ( chan >= MAX_FILES ) {
      ERRSIM_set_error ( status_code, ERRSID_TIFS_max_chan, "" );
   }

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( img >= MAX_IMAGES ) {
      ERRSIM_set_error ( status_code, ERRSID_TIFS_max_img, "" );
   }

/* ==========================================================================
   TIFF file channel
   ========================================================================== */
   if(tolower(TIFSPV_gid[chan].direction[img])=='x') { /* scrittura linea lungo x */
      /* La prima linea scritta e' sicuramente dentro al buffer. Modifica
	 minline in modo che sia la linea base del blocco a cui appartiene 
	 la linea attuale. Verifica anche che il buffer non sia costituito
	 da blocchi gia' salvati, nel qual caso caricali */
      if(TIFSPV_gid[chan].minline[img]==LINEMAX) { /* solo per la prima volta */
	 blky=(linenumber+TIFSPV_gid[chan].blockrig[img])/TIFSPV_gid[chan].blockrig[img]-1;
	 remain=TIFSPV_gid[chan].linebufdim[img]-TIFSPV_gid[chan].blkbufdim[img];
	 TIFSPV_gid[chan].minline[img]=blky*TIFSPV_gid[chan].blockrig[img];

	 /* nel caso la linea che si vuole scrivere appartiene a blocks gia' 
	    salvati allora caricali */
	 block1=TIFSPV_gid[chan].blkstart[img]+blky*TIFSPV_gid[chan].nblkx[img];
	 block2=TIFSPV_gid[chan].blkend[img]+blky*TIFSPV_gid[chan].nblkx[img];
	 /* verifica su tutti i blocks */
	 for(block=block1;block<=block2;block++) {
	    if(TIFSPV_gid[chan].blkflag[img][block]==1) {
	       TIFSPF_get_block(chan,img,block,
				TIFSPV_gid[chan].blockbuf[img],status_code);
	       ERRSIM_on_err_goto_exit( *status_code );

	       /* copia buffer di un blocco nel buffer di linea */
	       plin=TIFSPV_gid[chan].linebuf[img]+
				 (block-block1)*TIFSPV_gid[chan].blkbufdim[img]; 
					   /* setta il puntatore 
					      nel buffer di linea all'inizio */
	       pblk=TIFSPV_gid[chan].blockbuf[img];  /* setta il puntatore nel blocco 
						 all'inizio */
	       for(y=0;y<TIFSPV_gid[chan].blockrig[img];y++) { /* loop sulle righe del blocco */
		  for(x=0;x<TIFSPV_gid[chan].blkbufdim[img];x++) { /* loop sulle colonne del blocco */
		     *plin = *pblk;
		     pblk++;
		     plin++;
		  }
		  plin += remain;
	       }
	    }
	 }
      }

      /* verifica se la linea e' fuori dal buffer  */
      if((linenumber<TIFSPV_gid[chan].minline[img])||
	 (linenumber>(TIFSPV_gid[chan].minline[img]+TIFSPV_gid[chan].blockrig[img]-1))) {

	 /* la linea e' fuori dal buffer: salva il buffer dividendolo a blocks */
	 /* numero di blocco nella direzione y cui appartiengono le linee del buffer */
	 blky=(TIFSPV_gid[chan].minline[img]+TIFSPV_gid[chan].blockrig[img])/
					       TIFSPV_gid[chan].blockrig[img]-1;
	 /* numero di bytes di differenza tra la lunghezza del buffer di linea e di blocco nella direzione di lettura */
	 remain=TIFSPV_gid[chan].linebufdim[img]-TIFSPV_gid[chan].blkbufdim[img];
	 block1=TIFSPV_gid[chan].blkstart[img]+blky*TIFSPV_gid[chan].nblkx[img];
	 block2=TIFSPV_gid[chan].blkend[img]+blky*TIFSPV_gid[chan].nblkx[img];
	 for(block=block1;block<=block2;block++) {
	    /* copia buffer di linea nel buffer di blocco */
	    plin=TIFSPV_gid[chan].linebuf[img]+
	       (block-block1)*TIFSPV_gid[chan].blkbufdim[img]; /* setta il puntatore 
					      nel buffer di linea all'inizio */
	    pblk=TIFSPV_gid[chan].blockbuf[img]; /* setta il puntatore nel blocco 
					     all'inizio */
	    for(y=0;y<TIFSPV_gid[chan].blockrig[img];y++) { /* loop sulle righe del blocco */
	       for(x=0;x<TIFSPV_gid[chan].blkbufdim[img];x++) { /* loop sulle colonne del blocco */
		  *pblk = *plin;
		  pblk++;
		  plin++;
	       }
	       plin += remain;
	    }
	    TIFSPF_store_block(chan,img,block,
			       TIFSPV_gid[chan].blockbuf[img],status_code);
	    ERRSIM_on_err_goto_exit( *status_code );

	    TIFSPV_gid[chan].blkflag[img][block]=1; /* setta il flag indicando che 
						il blocco e' stato salvato */
	 }

	 /* nel caso la linea che si vuole scrivere appartiene a blocks gia' 
	    salvati allora caricali */
	 blky=(linenumber+TIFSPV_gid[chan].blockrig[img])/TIFSPV_gid[chan].blockrig[img]-1;
	 block1=TIFSPV_gid[chan].blkstart[img]+blky*TIFSPV_gid[chan].nblkx[img];
	 block2=TIFSPV_gid[chan].blkend[img]+blky*TIFSPV_gid[chan].nblkx[img];
	 /* verifica su tutti i blocks */
	 for(block=block1;block<=block2;block++) {
	    if(TIFSPV_gid[chan].blkflag[img][block]==1) {
	       TIFSPF_get_block(chan,img,block,
				TIFSPV_gid[chan].blockbuf[img],status_code);
	       ERRSIM_on_err_goto_exit( *status_code );

	       /* copia buffer di un blocco nel buffer di linea */
	       plin=TIFSPV_gid[chan].linebuf[img]+
		     (block-block1)*TIFSPV_gid[chan].blkbufdim[img];/* setta il puntatore 
					      nel buffer di linea all'inizio */
	       pblk=TIFSPV_gid[chan].blockbuf[img]; /* setta il puntatore nel blocco 
						all'inizio */
	       for(y=0;y<TIFSPV_gid[chan].blockrig[img];y++) { /* loop sulle righe del blocco */
		  for(x=0;x<TIFSPV_gid[chan].blkbufdim[img];x++) { /* loop sulle colonne del blocco */
		     *plin = *pblk;
		     pblk++;
		     plin++;
		  }
		  plin += remain;
	       }
	    }
	 }

	 /* minline e' settata all'inizio del buffer a cui appartiene linenumber */
	 TIFSPV_gid[chan].minline[img] = blky*TIFSPV_gid[chan].blockrig[img];

	 /* copia la linea nel buffer */
	 plin= (UINTx1 *)(TIFSPV_gid[chan].linebufbase[img]+
	       (linenumber-TIFSPV_gid[chan].minline[img])*TIFSPV_gid[chan].linebufdim[img]);
	 pin=(UINTx1 *)bufin;
	 for(i=0;i<TIFSPV_gid[chan].linesize[img];i++) {
	    *plin= *pin;
	    plin++;
	    pin++;
	 }
      }
      else {  /* la linea e' nel buffer */
	 /* copia la linea nel buffer */
	 plin= (UINTx1 *)(TIFSPV_gid[chan].linebufbase[img]+
	       (linenumber-TIFSPV_gid[chan].minline[img])*TIFSPV_gid[chan].linebufdim[img]);
	 pin=(UINTx1 *)bufin;
	 for(i=0;i<TIFSPV_gid[chan].linesize[img];i++) {
	    *plin= *pin;
	    plin++;
	    pin++;
	 }
      }      
   }
   else if(tolower(TIFSPV_gid[chan].direction[img])=='y') { /* scrittura linea lungo y */

      /* La prima linea scritta e' sicuramente dentro al buffer. Modifica
	 minline in modo che sia la linea base del blocco a cui appartiene 
	 la linea attuale. Verifica anche che il buffer non sia costituito
	 da blocchi gia' salvati, nel qual caso caricali */
      if(TIFSPV_gid[chan].minline[img]==LINEMAX) { /* solo per la prima volta */
	 /* numero di blocco nella direzione x cui appartiene la linea da leggere */
	 blkx=(linenumber+TIFSPV_gid[chan].blockcol[img])/TIFSPV_gid[chan].blockcol[img]-1;
	 /* dimensione del buffer di linea nella direzione di lettura -1 sample */
	 TIFSPV_gid[chan].minline[img] = blkx*TIFSPV_gid[chan].blockcol[img];
	 /* nel caso la linea che si vuole scrivere appartiene a blocks gia' 
	    salvati allora caricali */
	 block1=blkx+TIFSPV_gid[chan].blkstart[img]*TIFSPV_gid[chan].nblkx[img];
	 block2=blkx+TIFSPV_gid[chan].blkend[img]*TIFSPV_gid[chan].nblkx[img];
	 /* verifica su tutti i blocks */
	 remain=TIFSPV_gid[chan].linebufdim[img];
	 remain1=TIFSPV_gid[chan].linebufdim[img]*TIFSPV_gid[chan].blockcol[img]-
			    TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
	 remain2=TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
	 for(block=block1;block<=block2;block+=TIFSPV_gid[chan].nblkx[img]) {
	    if(TIFSPV_gid[chan].blkflag[img][block]==1) {
	       /* valuta la posizione del blocco da caricare rispetto al buffer di linea */
	       blocky=block/TIFSPV_gid[chan].nblkx[img]-TIFSPV_gid[chan].blkstart[img];
	       TIFSPF_get_block(chan,img,block,
				TIFSPV_gid[chan].blockbuf[img],status_code);
	       ERRSIM_on_err_goto_exit( *status_code );

	       /* loop sui bytes di un sample */
	       for(i=0;i<TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;i++){
		  plin=TIFSPV_gid[chan].linebuf[img]+blocky*TIFSPV_gid[chan].blockrig[img]* 
			TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8 + i;
		  /* setta il puntatore nel blocco all'inizio */
		  pblk=TIFSPV_gid[chan].blockbuf[img] + i; 
		  /* copia buffer di un blocco nel buffer di linea */
		  for(y=0;y<TIFSPV_gid[chan].blockrig[img];y++) { /* loop sulle righe del blocco */
		     for(x=0;x<TIFSPV_gid[chan].blockcol[img];x++) { /* loop sulle colonne del blocco */
			*plin = *pblk;
			pblk+=remain2;
			plin+=remain;
		     }
		     plin-=remain1;
		  }
	       }
	    }
	 }
      }

      /* verifica se la linea e' fuori dal buffer  */
      if((linenumber<TIFSPV_gid[chan].minline[img])||
	 (linenumber>(TIFSPV_gid[chan].minline[img]+TIFSPV_gid[chan].blockcol[img]-1))) {
	 /* la linea e' fuori dal buffer: salva il buffer dividendolo a blocks */
	 /* numero di blocco nella direzione x cui appartiene la linea da leggere */
	 blkx=(TIFSPV_gid[chan].minline[img]+TIFSPV_gid[chan].blockcol[img])/TIFSPV_gid[chan].blockcol[img]-1;
	 /* dimensione del buffer di linea nella direzione di lettura -1 sample */
	 remain= TIFSPV_gid[chan].linebufdim[img];
	 remain1=TIFSPV_gid[chan].linebufdim[img]*TIFSPV_gid[chan].blockcol[img]-
		     TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
	 remain2=TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
	 blocky=0;
	 block1=blkx+TIFSPV_gid[chan].blkstart[img]*TIFSPV_gid[chan].nblkx[img];
	 block2=blkx+TIFSPV_gid[chan].blkend[img]*TIFSPV_gid[chan].nblkx[img];
	 for(block=block1;block<=block2;block+=TIFSPV_gid[chan].nblkx[img]) {
	    /* loop sui bytes di un sample */
	    for(i=0;i<TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;i++) {
	       plin=TIFSPV_gid[chan].linebuf[img]+blocky*TIFSPV_gid[chan].blockrig[img]* 
			TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8 + i;
	       /* setta il puntatore nel blocco all'inizio */
	       pblk=TIFSPV_gid[chan].blockbuf[img] + i; 
	       /* copia buffer di un blocco nel buffer di linea */
	       for(y=0;y<TIFSPV_gid[chan].blockrig[img];y++) { /* loop sulle righe del blocco */
		  for(x=0;x<TIFSPV_gid[chan].blockcol[img];x++) { /* loop sulle colonne del blocco */
		     *pblk = *plin;
		     pblk+=remain2;
		     plin+=remain;
		  }
		  plin-=remain1;
	       }
	    }
	    TIFSPF_store_block(chan,img,block,
			       TIFSPV_gid[chan].blockbuf[img],status_code);
	    ERRSIM_on_err_goto_exit( *status_code );

	    TIFSPV_gid[chan].blkflag[img][block]=1; /* setta il flag indicando che il blocco e' stato salvato */
	    blocky++; 
	 }

	 /* nel caso la linea che si vuole scrivere appartiene a blocks gia' 
	    salvati allora caricali */
	 blkx=(linenumber+TIFSPV_gid[chan].blockcol[img])/TIFSPV_gid[chan].blockcol[img]-1;
	 /* dimensione del buffer di linea nella direzione di lettura -1 sample */
	 block1=blkx+TIFSPV_gid[chan].blkstart[img]*TIFSPV_gid[chan].nblkx[img];
	 block2=blkx+TIFSPV_gid[chan].blkend[img]*TIFSPV_gid[chan].nblkx[img];
	 remain=TIFSPV_gid[chan].linebufdim[img];
	 remain1=TIFSPV_gid[chan].linebufdim[img]*TIFSPV_gid[chan].blockcol[img]-
		     TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
	 remain2=TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
	 for(block=block1;block<=block2;block+=TIFSPV_gid[chan].nblkx[img]) {
	    if(TIFSPV_gid[chan].blkflag[img][block]==1) {
	       /* valuta la posizione del blocco da caricare rispetto al buffer di linea */
	       blocky=block/TIFSPV_gid[chan].nblkx[img]-TIFSPV_gid[chan].blkstart[img];
	       TIFSPF_get_block(chan,img,block,
				TIFSPV_gid[chan].blockbuf[img],status_code);
	       ERRSIM_on_err_goto_exit( *status_code );

	       /* loop sui bytes di un sample */
	       for(i=0;i<TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;i++){
		  plin=TIFSPV_gid[chan].linebuf[img]+blocky*TIFSPV_gid[chan].blockrig[img]* 
			TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8 + i;
		  pblk=TIFSPV_gid[chan].blockbuf[img] + i; /* setta il puntatore nel blocco all'inizio */
		  /* copia buffer di un blocco nel buffer di linea */
		  for(y=0;y<TIFSPV_gid[chan].blockrig[img];y++) { /* loop sulle righe del blocco */
		     for(x=0;x<TIFSPV_gid[chan].blockcol[img];x++) { /* loop sulle colonne del blocco */
			*plin = *pblk;
			pblk+=remain2;
			plin+=remain;
		     }
		     plin-=remain1;
		  }
	       }
	    }
	 }

	 /* minline e' settata all'inizio del buffer a cui appartiene linenumber */
	 TIFSPV_gid[chan].minline[img] = blkx*TIFSPV_gid[chan].blockcol[img];

	 /* copia la linea nel buffer */
	 plin= (UINTx1 *)(TIFSPV_gid[chan].linebufbase[img]+
	       (linenumber-TIFSPV_gid[chan].minline[img])*TIFSPV_gid[chan].linebufdim[img]);
	 pin=(UINTx1 *)bufin;
	 for(i=0;i<TIFSPV_gid[chan].linesize[img];i++) {
	    *plin= *pin;
	    plin++;
	    pin++;
	 }
      }
      else {  /* la linea e' nel buffer */
	 /* copia la linea nel buffer */
	 plin= (UINTx1 *)(TIFSPV_gid[chan].linebufbase[img]+
	       (linenumber-TIFSPV_gid[chan].minline[img])*TIFSPV_gid[chan].linebufdim[img]);
	 pin=(UINTx1 *)bufin;
	 for(i=0;i<TIFSPV_gid[chan].linesize[img];i++) {
	    *plin= *pin;
	    plin++;
	    pin++;
	 }
      }      
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_write_line */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_read_block

        $TYPE	      PROCEDURE

        $INPUT        chan	 : channel of the input opened TIFF file
                      img	 : number of the image in the TIFF file
                      firstline	 : first line (in the rows or columns direction)
                                   to read
                      lastline	 : last line to read
                      outtype	 : type of the output buffer

        $MODIFIED     NONE

        $OUTPUT       buff	 : double pointer to the output block

        $GLOBAL       TIFSPV_gid[chan] : the global structure used in the TIFF
                                         package

        $RET_STATUS   ERRSID_TIFS_bad_dimensions
                      ERRSID_TIFS_err_no_block
                      ERRSID_TIFS_not_allow_data_type
                      ERRSID_TIFS_undef_data_type

        $DESCRIPTION  This procedure read a block of lines ( in rows or columns
                      direction ) from a previously initialised TIFF file

        $WARNING      The read line operation must be initialised before calling
                      this procedure opening the TIFF file and the read mode
                      of the line

   $EH
   ========================================================================== */
void TIFSIP_read_block
                       ( /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx4               firstline,
                         /*IN    */ UINTx4               lastline,
                         /*IN    */ DATA_TYPEIT          outtype,
                         /*IN OUT*/ void               **buff,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_read_block";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 line;               /* line counter */
   UINTx4                 elem;               /* element counter */
   UINTx4                 NElem = 0;          /* number of elements in a line */
   void                  *imgline = NULL;     /* read buffer pointer */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the TIFF channel
   ========================================================================== */
   if ( chan >= MAX_FILES ) {
      ERRSIM_set_error ( status_code, ERRSID_TIFS_max_chan, "" );
   }

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( img >= MAX_IMAGES ) {
      ERRSIM_set_error ( status_code, ERRSID_TIFS_max_img, "" );
   }

/* ==========================================================================
   Check start and stop line consistency
   ========================================================================== */
   if ( lastline < firstline )
      ERRSIM_set_error( status_code, ERRSID_TIFS_bad_dimensions, "" );

/* ==========================================================================
   Evaluate the number of elements of the line
   ========================================================================== */
   NElem = TIFSPV_gid[ chan ].linesize[ img ] *         /* line size in bytes */
      LDEFID_byte_size /                                         /* byte size */
      TIFSPV_gid[ chan ].bitsam[ img ][ 0 ];               /* bits per sample */

/* ==========================================================================
   Switch between the two possible directions
   ========================================================================== */
   switch ( tolower( TIFSPV_gid[ chan ].direction[ img ] ) ) {
      case 'x':

/* ==========================================================================
   Read by rows
   ========================================================================== */
         if ( lastline > TIFSPV_gid[ chan ].imgrig[ img ] )
            ERRSIM_set_error( status_code, ERRSID_TIFS_err_no_block, "" );

         for ( line=firstline; line<=lastline; line++ ) {

/* ==========================================================================
   Read the line
   ========================================================================== */
            TIFSIP_read_line( chan, img, line, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Copy the line in an output one
   ========================================================================== */
            /* select the output data type */
            switch( outtype ) {
               case DATA_TYPE_UINTx1:

                  /* select the input data type */
                  switch( TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] ) {
                     case TIFSID_uintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 8:
                              memcpy( (void *)((UINTx1 **)buff)[line-firstline],
                                      (void *)imgline,
                                      (size_t)( NElem * sizeof( UINTx1 ) ) );
                           break;
                           case 16:
			      for ( elem=0; elem<NElem; elem++ )
				 ( (UINTx1 **)buff)[ line-firstline ][ elem ] =
				    ( (UINTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_sintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 16:
                              for ( elem=0; elem<NElem; elem++ )
                                 ( (UINTx1 **)buff)[ line-firstline ][ elem ] =
                                    ( (INTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_float:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 32:
                              for ( elem=0; elem<NElem; elem++ )
                                 ( (UINTx1 **)buff)[ line-firstline ][ elem ] =
                                    ( (float *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                               ERRSID_TIFS_not_allow_data_type,
                                               "" );
                        }
                     break;
                     case TIFSID_undef:
                        ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                  }
               break;
               case DATA_TYPE_UINTx2:
                  switch( TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] ) {
                     case TIFSID_uintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 8:
			      for ( elem=0; elem<NElem; elem++ )
				 ( (UINTx2 **)buff)[ line-firstline ][ elem ] =
				    ( (UINTx1 *)imgline)[ elem ];
                           break;
                           case 16:
                              memcpy( (void *)((UINTx2 **)buff)[line-firstline],
                                      (void *)imgline,
                                      (size_t)( NElem * sizeof( UINTx2 ) ) );
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_sintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 16:
                              for ( elem=0; elem<NElem; elem++ )
                                 ( (UINTx2 **)buff)[ line-firstline ][ elem ] =
                                    ( (INTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_float:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 32:
                              for ( elem=0; elem<NElem; elem++ )
                                 ( (UINTx2 **)buff)[ line-firstline ][ elem ] =
                                    ( (float *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_undef:
                        ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                  }
               break;
               case DATA_TYPE_INTx1:
                  switch( TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] ) {
                     case TIFSID_uintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 8:
			      for ( elem=0; elem<NElem; elem++ )
				 ( (INTx1 **)buff)[ line-firstline ][ elem ] =
				    ( (UINTx1 *)imgline)[ elem ];
                           break;
                           case 16:
			      for ( elem=0; elem<NElem; elem++ )
				 ( (INTx1 **)buff)[ line-firstline ][ elem ] =
				    ( (UINTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_sintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 16:
                              for ( elem=0; elem<NElem; elem++ )
                                 ( (INTx1 **)buff)[ line-firstline ][ elem ] =
                                    ( (INTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_float:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 32:
			       for ( elem=0; elem<NElem; elem++ )
				  ( (INTx1 **)buff)[ line-firstline ][ elem ] =
				     ( (float *)imgline)[ elem ];
			    break;
			    default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_undef:
                        ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                  }
               break;
               case DATA_TYPE_INTx2:
                  switch( TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] ) {
                     case TIFSID_uintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 8:
			      for ( elem=0; elem<NElem; elem++ )
				 ( (INTx2 **)buff)[ line-firstline ][ elem ] =
				    ( (UINTx1 *)imgline)[ elem ];
                           break;
                           case 16:
			      for ( elem=0; elem<NElem; elem++ )
				 ( (INTx2 **)buff)[ line-firstline ][ elem ] =
				    ( (UINTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_sintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 16:
                              memcpy( (void *)((INTx2 **)buff)[line-firstline],
                                      (void *)imgline,
                                      (size_t)( NElem * sizeof( INTx2 ) ) );
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_float:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
			    case 32:
			       for ( elem=0; elem<NElem; elem++ )
				  ( (INTx2 **)buff)[ line-firstline ][ elem ] =
				     ( (float *)imgline)[ elem ];
			    break;
			    default:
				  ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_undef:
                        ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                  }
               break;
               case DATA_TYPE_float:
                  switch( TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] ) {
                     case TIFSID_uintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 8:
			      for ( elem=0; elem<NElem; elem++ )
				 ( (float **)buff)[ line-firstline ][ elem ] =
				    ( (UINTx1 *)imgline)[ elem ];
                           break;
                           case 16:
			      for ( elem=0; elem<NElem; elem++ )
				 ( (float **)buff)[ line-firstline ][ elem ] =
				    ( (UINTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_sintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 16:
			      for ( elem=0; elem<NElem; elem++ )
				 ( (float **)buff)[ line-firstline ][ elem ] =
				    ( (INTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_float:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
			    case 32:
			       memcpy( (void *)((float **)buff)[line-firstline],
				       (void *)imgline,
				       (size_t)( NElem * sizeof( float ) ) );
			    break;
			    default:
				  ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_undef:
                        ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                  }
               break;
               default:
                  ERRSIM_set_error( status_code, ERRSID_TIFS_undef_data_type,
                                    "" );
            }

/* ==========================================================================
   Reset the line pointer
   ========================================================================== */
            imgline = NULL;
         }


      break;
      case 'y':

/* ==========================================================================
   Read by columns
   ========================================================================== */
         if ( lastline > TIFSPV_gid[ chan ].imgcol[ img ] )
            ERRSIM_set_error( status_code, ERRSID_TIFS_err_no_block, "" );

         for ( line=firstline; line<=lastline; line++ ) {

/* ==========================================================================
   Read the line
   ========================================================================== */
            TIFSIP_read_line( chan, img, line, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Copy the line in an output one
   ========================================================================== */
            /* select the output data type */
            switch( outtype ) {
               case DATA_TYPE_UINTx1:

                  /* select the input data type */
                  switch( TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] ) {
                     case TIFSID_uintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 8: {
                              UINTx4      nc_elem;

                              /* RAW data */
                              nc_elem = NElem /
                                 TIFSPV_gid[ chan ].sampix[ img ];
                              for ( elem=0; elem<nc_elem; elem++ ) {
                                 ( (UINTx1 **)buff)[elem][ 2*(line-firstline)]=
                                    ( (UINTx1 *)imgline)[ 2*elem ];
                                 ( (UINTx1 **)buff)[elem][2*(line-firstline)+1]=
                                    ( (UINTx1 *)imgline)[ 2*elem+1 ];
                              }
                           }
                           break;
                           case 16:

                              /* real data (PRI, GEC, GTC) */
			      for ( elem=0; elem<NElem; elem++ )
				 ( (UINTx1 **)buff)[ elem ][ line-firstline ] =
				    ( (UINTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_sintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 16: {
                              UINTx4      nc_elem;

                              /* SLC data */
                              nc_elem = NElem /
                                 TIFSPV_gid[ chan ].sampix[ img ];
                              for ( elem=0; elem<nc_elem; elem++ ) {
                                 ( (UINTx1 **)buff)[elem][ 2*(line-firstline)]=
                                    ( (INTx2 *)imgline)[ 2*elem ];
                                 ( (UINTx1 **)buff)[elem][2*(line-firstline)+1]=
                                    ( (INTx2 *)imgline)[ 2*elem+1 ];
                              }
                           }
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_float:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
			    case 32:
			       switch ( TIFSPV_gid[ chan ].sampix[ img ] ) {
				  case 1:
				     for ( elem=0; elem<NElem; elem++ )
					( (UINTx1 **)buff)[elem][line-firstline] =
					   ( (float *)imgline)[ elem ];
				  break;
				  case 2: {
				     UINTx4      nc_elem;

				     /* complex data */
				     nc_elem = NElem /
					TIFSPV_gid[ chan ].sampix[ img ];
				     for ( elem=0; elem<nc_elem; elem++ ) {
					((UINTx1 **)buff)[elem][2*(line-firstline)]=
					   ( (float *)imgline)[ 2*elem ];
					( (UINTx1 **)buff)[elem]
					   [2*(line-firstline)+1]=
					   ( (float *)imgline)[ 2*elem+1 ];
				     }
				  }
			       }
			    break;
			    default:
				  ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_undef:
                        ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                  }
               break;
               case DATA_TYPE_UINTx2:
                  switch( TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] ) {
                     case TIFSID_uintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 8: {
                              UINTx4      nc_elem;

                              /* RAW data */
                              nc_elem = NElem /
                                 TIFSPV_gid[ chan ].sampix[ img ];
                              for ( elem=0; elem<nc_elem; elem++ ) {
                                 ( (UINTx2 **)buff)[elem][ 2*(line-firstline)]=
                                    ( (UINTx1 *)imgline)[ 2*elem ];
                                 ( (UINTx2 **)buff)[elem][2*(line-firstline)+1]=
                                    ( (UINTx1 *)imgline)[ 2*elem+1 ];
                              }
                           }
                           break;
                           case 16:

                              /* real data (PRI, GEC, GTC) */
			      for ( elem=0; elem<NElem; elem++ )
				 ( (UINTx2 **)buff)[ elem ][ line-firstline ] =
				    ( (UINTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_sintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 16: {
                              UINTx4      nc_elem;

                              /* SLC data */
                              nc_elem = NElem /
                                 TIFSPV_gid[ chan ].sampix[ img ];
                              for ( elem=0; elem<nc_elem; elem++ ) {
                                 ( (UINTx2 **)buff)[elem][ 2*(line-firstline)]=
                                    ( (INTx2 *)imgline)[ 2*elem ];
                                 ( (UINTx2 **)buff)[elem][2*(line-firstline)+1]=
                                    ( (INTx2 *)imgline)[ 2*elem+1 ];
                              }
                           }
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_float:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
			    case 32:
			       switch ( TIFSPV_gid[ chan ].sampix[ img ] ) {
				  case 1:
				     for ( elem=0; elem<NElem; elem++ )
					( (UINTx2 **)buff)[elem][line-firstline] =
					   ( (float *)imgline)[ elem ];
				  break;
				  case 2: {
				     UINTx4      nc_elem;

				     /* complex data */
				     nc_elem = NElem /
					TIFSPV_gid[ chan ].sampix[ img ];
				     for ( elem=0; elem<nc_elem; elem++ ) {
					((UINTx2 **)buff)[elem][2*(line-firstline)]=
					   ( (float *)imgline)[ 2*elem ];
					( (UINTx2 **)buff)[elem]
					   [2*(line-firstline)+1]=
					   ( (float *)imgline)[ 2*elem+1 ];
				     }
				  }
			       }
			    break;
			    default:
				  ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_undef:
                        ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                  }
               break;
               case DATA_TYPE_INTx1:
                  switch( TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] ) {
                     case TIFSID_uintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 8: {
                              UINTx4      nc_elem;

                              /* RAW data */
                              nc_elem = NElem /
                                 TIFSPV_gid[ chan ].sampix[ img ];
                              for ( elem=0; elem<nc_elem; elem++ ) {
                                 ( (INTx1 **)buff)[elem][ 2*(line-firstline)]=
                                    ( (UINTx1 *)imgline)[ 2*elem ];
                                 ( (INTx1 **)buff)[elem][2*(line-firstline)+1]=
                                    ( (UINTx1 *)imgline)[ 2*elem+1 ];
                              }
                           }
                           break;
                           case 16:

                              /* real data (PRI, GEC, GTC) */
			      for ( elem=0; elem<NElem; elem++ )
				 ( (INTx1 **)buff)[ elem ][ line-firstline ] =
				    ( (UINTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_sintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 16: {
                              UINTx4      nc_elem;

                              /* SLC data */
                              nc_elem = NElem /
                                 TIFSPV_gid[ chan ].sampix[ img ];
                              for ( elem=0; elem<nc_elem; elem++ ) {
                                 ( (INTx1 **)buff)[elem][ 2*(line-firstline)]=
                                    ( (INTx2 *)imgline)[ 2*elem ];
                                 ( (INTx1 **)buff)[elem][2*(line-firstline)+1]=
                                    ( (INTx2 *)imgline)[ 2*elem+1 ];
                              }
                           }
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_float:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
			    case 32:
			       switch ( TIFSPV_gid[ chan ].sampix[ img ] ) {
				  case 1:
				     for ( elem=0; elem<NElem; elem++ )
					( (INTx1 **)buff)[elem][line-firstline] =
					   ( (float *)imgline)[ elem ];
				  break;
				  case 2: {
				     UINTx4      nc_elem;

				     /* complex data */
				     nc_elem = NElem /
					TIFSPV_gid[ chan ].sampix[ img ];
				     for ( elem=0; elem<nc_elem; elem++ ) {
					( (INTx1 **)buff)[elem][2*(line-firstline)]=
					   ( (float *)imgline)[ 2*elem ];
					( (INTx1 **)buff)[elem]
					   [2*(line-firstline)+1]=
					   ( (float *)imgline)[ 2*elem+1 ];
				     }
				  }
			       }
			    break;
			    default:
				  ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_undef:
                        ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                  }
               break;
               case DATA_TYPE_INTx2:
                  switch( TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] ) {
                     case TIFSID_uintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 8: {
                              UINTx4      nc_elem;

                              /* RAW data */
                              nc_elem = NElem /
                                 TIFSPV_gid[ chan ].sampix[ img ];
                              for ( elem=0; elem<nc_elem; elem++ ) {
                                 ( (INTx2 **)buff)[elem][ 2*(line-firstline)]=
                                    ( (UINTx1 *)imgline)[ 2*elem ];
                                 ( (INTx2 **)buff)[elem][2*(line-firstline)+1]=
                                    ( (UINTx1 *)imgline)[ 2*elem+1 ];
                              }
                           }
                           break;
                           case 16:

                              /* real data (PRI, GEC, GTC) */
			      for ( elem=0; elem<NElem; elem++ )
				 ( (INTx2 **)buff)[ elem ][ line-firstline ] =
				    ( (UINTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_sintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 16: {
                              UINTx4      nc_elem;

                              /* SLC data */
                              nc_elem = NElem /
                                 TIFSPV_gid[ chan ].sampix[ img ];
                              for ( elem=0; elem<nc_elem; elem++ ) {
                                 ( (INTx2 **)buff)[elem][ 2*(line-firstline)]=
                                    ( (INTx2 *)imgline)[ 2*elem ];
                                 ( (INTx2 **)buff)[elem][2*(line-firstline)+1]=
                                    ( (INTx2 *)imgline)[ 2*elem+1 ];
                              }
                           }
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_float:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
			    case 32:
			       switch ( TIFSPV_gid[ chan ].sampix[ img ] ) {
				  case 1:
				     for ( elem=0; elem<NElem; elem++ )
					( (INTx2 **)buff)[elem][line-firstline] =
					   ( (float *)imgline)[ elem ];
				  break;
				  case 2: {
				     UINTx4      nc_elem;

				     /* complex data */
				     nc_elem = NElem /
					TIFSPV_gid[ chan ].sampix[ img ];
				     for ( elem=0; elem<nc_elem; elem++ ) {
					( (INTx2 **)buff)[elem][2*(line-firstline)]=
					   ( (float *)imgline)[ 2*elem ];
					( (INTx2 **)buff)[elem]
					   [2*(line-firstline)+1]=
					   ( (float *)imgline)[ 2*elem+1 ];
				     }
				  }
			       }
			    break;
			    default:
				  ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_undef:
                        ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                  }
               break;
               case DATA_TYPE_float:
                  switch( TIFSPV_gid[ chan ].sampleformat[ img ][ 0 ] ) {
                     case TIFSID_uintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 8: {
                              UINTx4      nc_elem;

                              /* RAW data */
                              nc_elem = NElem /
                                 TIFSPV_gid[ chan ].sampix[ img ];
                              for ( elem=0; elem<nc_elem; elem++ ) {
                                 ( (float **)buff)[elem][ 2*(line-firstline)]=
                                    ( (UINTx1 *)imgline)[ 2*elem ];
                                 ( (float **)buff)[elem][2*(line-firstline)+1]=
                                    ( (UINTx1 *)imgline)[ 2*elem+1 ];
                              }
                           }
                           break;
                           case 16:

                              /* real data (PRI, GEC, GTC) */
			      for ( elem=0; elem<NElem; elem++ )
				 ( (float **)buff)[ elem ][ line-firstline ] =
				    ( (UINTx2 *)imgline)[ elem ];
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_sintdata:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
                           case 16: {
                              UINTx4      nc_elem;

                              /* SLC data */
                              nc_elem = NElem /
                                 TIFSPV_gid[ chan ].sampix[ img ];
                              for ( elem=0; elem<nc_elem; elem++ ) {
                                 ( (float **)buff)[elem][ 2*(line-firstline)]=
                                    ( (INTx2 *)imgline)[ 2*elem ];
                                 ( (float **)buff)[elem][2*(line-firstline)+1]=
                                    ( (INTx2 *)imgline)[ 2*elem+1 ];
                              }
                           }
                           break;
                           default:
                              ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_float:
                        switch( TIFSPV_gid[ chan ].bitsam[ img ][ 0 ] ) {
			    case 32:
			       switch ( TIFSPV_gid[ chan ].sampix[ img ] ) {
				  case 1:
				     for ( elem=0; elem<NElem; elem++ )
					( (float **)buff)[elem][line-firstline] =
					   ( (float *)imgline)[ elem ];
				  break;
				  case 2: {
				     UINTx4      nc_elem;

				     /* complex data */
				     nc_elem = NElem /
					TIFSPV_gid[ chan ].sampix[ img ];
				     for ( elem=0; elem<nc_elem; elem++ ) {
					( (float **)buff)[elem][2*(line-firstline)]=
					   ( (float *)imgline)[ 2*elem ];
					( (float **)buff)[elem]
					   [2*(line-firstline)+1]=
					   ( (float *)imgline)[ 2*elem+1 ];
				     }
				  }
			       }
			    break;
			    default:
				  ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                        }
                     break;
                     case TIFSID_undef:
                        ERRSIM_set_error( status_code,
                                          ERRSID_TIFS_not_allow_data_type, "" );
                  }
               break;
               default:
                  ERRSIM_set_error( status_code, ERRSID_TIFS_undef_data_type,
                                    "" );
            }

/* ==========================================================================
   Reset the line pointer
   ========================================================================== */
            imgline = NULL;
         }
      break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_read_block */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_close_line

        $TYPE	      PROCEDURE

        $INPUT        chan : TIFF channel
		      img  : image number

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       TIFSPV_gid[ chan ] 

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure close the reading or writing of a line.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_close_line
                       ( /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_close_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4      		  i,blkx,blky,blocky,block,block1,block2,x,y;
   UINTx4      		  remain,remain1,remain2;
   UINTx1                *plin;
   UINTx1                *pblk;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the channel number
   ========================================================================== */
   if ( chan >= MAX_FILES ) {
      ERRSIM_set_error ( status_code, ERRSID_TIFS_max_chan, "" );
   }

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( img >= MAX_IMAGES ) {
      ERRSIM_set_error ( status_code, ERRSID_TIFS_max_img, "" );
   }

   /* nel caso di scrittura salva il buffer 
      relativo all'ultima linea scritta dividendolo a blocks */
   if(TIFSPV_gid[chan].mode == 'w') {
      /* salva il buffer relativo a minline (che sicuramente non e' stato salvato:
	 il salvataggio avviene infatti solo con la richiesta di scrittura di 
	 una linea non appartenente al blocco */

      if(tolower(TIFSPV_gid[chan].direction[img])=='x') { /* scrittura lungo x */
	 /* numero di blocco nella direzione y cui appartiengono le linee del buffer */
	 blky=(TIFSPV_gid[chan].minline[img]+TIFSPV_gid[chan].blockrig[img])/TIFSPV_gid[chan].blockrig[img]-1;
	 /* numero di bytes di differenza tra la lunghezza del buffer di linea e di blocco nella direzione di lettura */
	 remain=TIFSPV_gid[chan].linebufdim[img]-TIFSPV_gid[chan].blkbufdim[img];
	 block1=TIFSPV_gid[chan].blkstart[img]+blky*TIFSPV_gid[chan].nblkx[img];
	 block2=TIFSPV_gid[chan].blkend[img]+blky*TIFSPV_gid[chan].nblkx[img];
	 for(block=block1;block<=block2;block++) {
	 /* copia buffer di linea nel buffer di blocco */
	    plin=TIFSPV_gid[chan].linebuf[img]+
		    (block-block1)*TIFSPV_gid[chan].blkbufdim[img]; /* setta il 
				    puntatore nel buffer di linea all'inizio */
	    pblk=TIFSPV_gid[chan].blockbuf[img]; /* setta il puntatore 
						       nel blocco all'inizio */
	    for(y=0;y<TIFSPV_gid[chan].blockrig[img];y++) { /* loop sulle righe del blocco */
	       for(x=0;x<TIFSPV_gid[chan].blkbufdim[img];x++) { /* loop sulle colonne del blocco */
		  *pblk = *plin;
		  pblk++;
		  plin++;
	       }
	       plin += remain;
	    }
	    TIFSPF_store_block(chan,img,block,
			       TIFSPV_gid[chan].blockbuf[img],status_code);
	    ERRSIM_on_err_goto_exit( *status_code );

	    TIFSPV_gid[chan].blkflag[img][block]=1; /* setta il flag indicando che il blocco e' stato salvato */
	 }
      }

      else if(tolower(TIFSPV_gid[chan].direction[img])=='y') { /* scrittura lungo y */
	 /* numero di blocco nella direzione x cui appartiene la linea da leggere */
	 blkx=(TIFSPV_gid[chan].minline[img]+TIFSPV_gid[chan].blockcol[img])/TIFSPV_gid[chan].blockcol[img]-1;
	 /* dimensione del buffer di linea nella direzione di lettura -1 sample */
	 remain=TIFSPV_gid[chan].linebufdim[img];
	 remain1=TIFSPV_gid[chan].linebufdim[img]*TIFSPV_gid[chan].blockcol[img]-
		     TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
	 remain2=TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;
	 blocky=0;
	 block1=blkx+TIFSPV_gid[chan].blkstart[img]*TIFSPV_gid[chan].nblkx[img];
	 block2=blkx+TIFSPV_gid[chan].blkend[img]*TIFSPV_gid[chan].nblkx[img];
	 for(block=block1;block<=block2;block+=TIFSPV_gid[chan].nblkx[img]) {
	    /* loop sui bytes di un sample */
	    for(i=0;i<TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8;i++) { 
	       plin=TIFSPV_gid[chan].linebuf[img]+blocky*TIFSPV_gid[chan].blockrig[img]* 
			TIFSPV_gid[chan].sampix[img]*TIFSPV_gid[chan].bitsam[img][0]/8 + i;
	       pblk=TIFSPV_gid[chan].blockbuf[img] + i; /* setta il puntatore nel blocco all'inizio */
	       /* copia buffer di un blocco nel buffer di linea */
	       for(y=0;y<TIFSPV_gid[chan].blockrig[img];y++) { /* loop sulle righe del blocco */
		  for(x=0;x<TIFSPV_gid[chan].blockcol[img];x++) { /* loop sulle colonne del blocco */
		     *pblk = *plin;
		     pblk+=remain2;
		     plin+=remain;
		  }
		  plin-=remain1;
	       }
	    }
	    TIFSPF_store_block(chan,img,block,
			       TIFSPV_gid[chan].blockbuf[img],status_code);
	    ERRSIM_on_err_goto_exit( *status_code );

	    TIFSPV_gid[chan].blkflag[img][block]=1; /* setta il flag indicando che il blocco e' stato salvato */
	    blocky++; 
	 }
      }
   }
  
   MEMSIP_free( (void **) &(TIFSPV_gid[chan].blockbuf[img]) );
   MEMSIP_free( (void **) &(TIFSPV_gid[chan].linebuf[img]) );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_close_line */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_fill_tag_vet

        $TYPE	      PROCEDURE

        $INPUT        file_name : the name of the file containing the tag 
                                  names (.h)

        $MODIFIED     NONE

        $OUTPUT       tag_vet   : an array of structures containing the tag 
                                  names and numbers
                      tot_tag   : the number of founded tags

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Fills the structure containing the tag names and numbers
                      starting from the .h file containing the various #define

        $WARNING      NONE

        $PDL	      

   $EH
   ========================================================================== */
void TIFSIP_fill_tag_vet
                        (/*IN    */ char                *filename,
                         /*   OUT*/ UINTx4              *tot_tag,
                         /*   OUT*/ TIFSIT_tag_elem    **tag_vet,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_fill_tag_vet";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility Variables
   ========================================================================== */
   FILE			  *fp;
   char			  buffer[REPLINELEN];
   char			  number[REPLINELEN];
   char			  define[REPLINELEN];
   char			  tagname[REPLINELEN];
   char			  tagnumber[REPLINELEN];
   char			  *eoflag;
   UINTx4		  i;
   UINTx4		  j;
   UINTx4		  nfields;
   char			  msg[255];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Open tags file
   ========================================================================== */
   FILSIP_open( filename, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   i = 0;
   while ( fgets( buffer, REPLINELEN, fp ) != NULL ) {

      nfields=sscanf(buffer,"%s %s %s",define,tagname,tagnumber);

      if ( (strcmp("#define", define) != 0) || (nfields !=3) ) continue;
    
      *tag_vet = (TIFSIT_tag_elem *) 
             MEMSIP_realloc( *tag_vet, (i+1) * sizeof( TIFSIT_tag_elem ) );
      if( *tag_vet == (TIFSIT_tag_elem *) NULL ) {
         ERRSIM_set_error(status_code, ERRSID_TIFS_memory_alloc_failure,
            "*tag_vet" );
      }
      strcpy( (*tag_vet)[i].name, tagname);
      (*tag_vet)[i].num = atoi(tagnumber);

      i++;

   };

/* ==========================================================================
   Close tags file
   ========================================================================== */
   FILSIP_close( &fp, &log_status_code );

   *tot_tag=i;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_fill_tag_vet */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_get_tag_name   

        $TYPE         FUNCTION

        $INPUT        tag_vet  : the array of structures containing the tag 
                                 numbers and names
		      tot_tag  : the size of the tag structure (quantity of 
                                 tags)
		      tag_num  : the searched tag number

        $MODIFIED     NONE

        $OUTPUT       tag_name : a string containing the name of the tag, 
                                 searched by its number

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Obtain the tag name from the tag number searching in the
                      tag array of structure

        $WARNING      NONE

   $EH
   ========================================================================== */
void TIFSIP_get_tag_name
                        (/*IN    */ TIFSIT_tag_elem     *tag_vet,
                         /*IN    */ UINTx2              tot_tag,
                         /*IN    */ UINTx2              tag_num,
                         /*   OUT*/ char                *tag_name,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_get_tag_name";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility Variables
   ========================================================================== */
   UINTx4                 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Init null
   ========================================================================== */
   strcpy(tag_name,"");

/* ==========================================================================
   Looks for the tag name from the tag number
   ========================================================================== */
   for ( i = 0; i < tot_tag; i++ ) {
      if ( tag_vet[i].num == tag_num ) {
         strcpy(tag_name,tag_vet[i].name);
      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* TIFSIP_get_tag_name */

#ifdef __SUBS__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure ...

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void TIFSIP_
                       ( /*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "TIFSIP_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code);

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* TIFSIP_ */
#endif
