/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_XREG

      $FUNCTION          Main module for the IMAGE CO-REGISTRATION tool

      $ROUTINE           STBX_MAIN_main

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       14-MAR-98     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#if defined  __MC68K__ || defined __POWERPC__
#include <console.h>
#endif

#include <string.h>
#include <stdio.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include STBX_PGLB_H
#include STBX_INTF_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

static void trace_in( INTx4   argc,
                      char   *argv[] )
{                                                        
   ERRSIT_status log_status_code;                   
   char          tmp_str[256];
   INTx4         i;
    
   ERRSIP_HPEL_trace_proc_err_log("INPUT PARAMETER:", &log_status_code);
   ERRSIP_HPEL_trace_proc_err_log(" ", &log_status_code);

   sprintf(tmp_str,"%s%d","argc       : ",argc);
   ERRSIP_HPEL_trace_proc_err_log(tmp_str, &log_status_code);
   for(i = 0; i < argc; i++ )
   {
      sprintf(tmp_str,"argv[%02d] : %s",i,argv[i]);
      ERRSIP_HPEL_trace_proc_err_log(tmp_str, &log_status_code);
   }
}                                                        

/* ==========================================================================

   $ROUTINE_HEADER

        $XREG         STBX_XREG

        $TYPE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

main( INTx4 argc, char *argv[] )
{
#ifdef __VMS__
   const ERRSIT_proc_class proc_class   = "STBX_XREG";
#else
   const ERRSIT_proc_class proc_class   = "regi";
#endif
   const ERRSIT_proc_name  routine_name = "STBX_XREG_main";
   
   ERRSIT_status           log_status_code;
   ERRSIT_status           status_code;
   ERRSIT_flag             process_flag;

/* ==========================================================================
   Section variables
   ========================================================================== */
   char                  **section_name = (char **) NULL;
   UINTx4                  section_no;
   INTx4                   i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   status_code      = STC ( ERRSID_normal );
   log_status_code  = STC ( ERRSID_normal );

   ERRSIP_HPEL_process_init ( proc_class, &log_status_code );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
    Inizializzation for MAC console.
   ========================================================================== */
#if defined __MC68K__ || defined __POWERPC__
   if ( argc == 0 ) {
      argc = ccommand ( &argv );
   }
#endif

   if ( ERRSIM_in_parms ( process_flag ) ) {
      trace_in ( argc, argv );
   }

/* ==========================================================================
   Log version
   ========================================================================== */
   STBXPM_log_version ( STBXPD_coregistr_tool_version );

/* ==========================================================================
   Check the existence of at least the "-if file" parms
   ========================================================================== */
   if ( argc < 3 ) {
      ERRSIM_set_error ( &status_code, ERRSID_STBX_not_if_parm, "" );
   }

/* ==========================================================================
   Check that the first arg is "-if"
   ========================================================================== */
   if ( strcmp ( argv[1], STBXPD_if_arg ) ) {
      ERRSIM_set_error ( &status_code, ERRSID_STBX_not_if_parm, "" );
   }

 /* ==========================================================================
   Extract from INI file all the section included
   ========================================================================== */
   FIISIP_GETS_get_sections( argv[ 2 ], &section_no, &section_name,
                             &status_code );
   ERRSIM_on_err_goto_exit ( status_code );

/* ==========================================================================
   Set configuration dir
   ========================================================================== */
   STBXPP_set_config ( LDEFIV_cfg_dir, &log_status_code );

/* ==========================================================================
   Execute always the first section
   ========================================================================== */
   if ( !strcmp ( section_name[ 0 ], STBXPD_image_coregistration ) ) {
      STBXPP_REGI_Registrator ( section_name[ 0 ], 
                                (UINTx4) 1, 
                                argc, argv,
                                &status_code );
      ERRSIM_on_err_goto_exit ( status_code );
   }
   else if ( !strcmp ( section_name[ 0 ], STBXPD_coherence_image_generation) ) {
      STBXPP_REGI_CoherImaGenerator ( section_name[ 0 ],
                                      (UINTx4) 1, /* first section */
                                      argc, argv, &status_code );
      ERRSIM_on_err_goto_exit ( status_code );
   }
   else {
      ERRSIM_set_error ( &status_code, ERRSID_STBX_section_invalid,
                         section_name[ 0 ] );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, status_code, 
                          &log_status_code );

   ERRSIP_HPEL_process_shutdown ( proc_class, &log_status_code );

}/* STBX_XREG_main */

