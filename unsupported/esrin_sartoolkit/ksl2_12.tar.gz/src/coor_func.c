/* ==========================================================================
   $MODULE_HEADER

      $NAME              COOR_FUNC

      $FUNCTION          This module contains the ancillary procedures to
			 the coordinates conversions from image ( row, col )
			 to cartesian ( x, y, z ) that are solved by solving
			 systems of non linear equations

      $ROUTINE           COORPP_FUNC_Newton_rc_xyz
			 COORPP_FUNC_Newton_xyz_rc

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       16-JUL-97     MC       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include COOR_INTF_H
#include COOR_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_FUNC_Newton_rc_xyz

        $TYPE         PROCEDURE

        $INPUT        x	      : current point array

        $MODIFIED     alpha   : matrix with the values of the first derivatives 
			        of the three functions WRT the three variables
				in the current point <x>
		      beta    : array with the values of the functions ( with
			        the minus sign ) in the current point <x>

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need
                      COORPV_ImgNum		: number of the current image
						  among the other in the tool

        $RET_STATUS   ERRSID_COOR_null_dist_sp_target

        $DESCRIPTION  This procedure is ancillary to the coordinates conversion
		      procedure that transforms from image to cartesian
		      coordinates. It's used by the procedure MATH_ROOF_Newton
		      for the resolution of systems of non linear equations

        $WARNING      NONE

   $EH
   ========================================================================== */
void COORPP_FUNC_Newton_rc_xyz
			(/*IN    */ double              *x,
                         /*IN OUT*/ double             **alpha,
                         /*IN OUT*/ double              *beta,
			 /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "COORPP_FUNC_Newton_rc_xyz";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   COORIT_conv           *DataConv;
   MATHIT_XYZ		  dSP;
   double                 Rsp;
   double                 prScal;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Point to the global structures
   ========================================================================== */
   DataConv = ( COORIV_conv + COORPV_ImgNum );

/* ==========================================================================
   Spacecraft - Target vector
   ========================================================================== */
   dSP.x = ( DataConv->SP.x - *(x + 1) );
   dSP.y = ( DataConv->SP.y - *(x + 2) );
   dSP.z = ( DataConv->SP.z - *(x + 3) );

/* ==========================================================================
   Spacecraft - Target modulus
   ========================================================================== */
   Rsp = sqrt( dSP.x * dSP.x + dSP.y * dSP.y + dSP.z * dSP.z );

/* ==========================================================================
   Evaluate the scalar product spacecraft-target vs velocity
   ========================================================================== */
   prScal = DataConv->SV.x * dSP.x + DataConv->SV.y * dSP.y +
      DataConv->SV.z * dSP.z ;

   if ( Rsp == 0 )
      ERRSIM_set_error( status_code, ERRSID_COOR_null_dist_sp_target, "" );

/* ==========================================================================
   Fill the first derivative matrix
   ========================================================================== */
   /* first derivative of the slant range equation, ... */
   alpha[ 1 ][ 1 ] = - dSP.x / Rsp;
   alpha[ 1 ][ 2 ] = - dSP.y / Rsp;
   alpha[ 1 ][ 3 ] = - dSP.z / Rsp;

   /* ... ellipsoid equation ... */
   alpha[ 2 ][ 1 ] = 2.0 * (*(x + 1) ) /
      ( IANNIV_ImageAnnot[ COORPV_ImgNum ].SemiMajorAxis_m *
	IANNIV_ImageAnnot[ COORPV_ImgNum ].SemiMajorAxis_m );
   alpha[ 2 ][ 2 ] = 2.0 * (*(x + 2) ) /
      ( IANNIV_ImageAnnot[ COORPV_ImgNum ].SemiMajorAxis_m *
        IANNIV_ImageAnnot[ COORPV_ImgNum ].SemiMajorAxis_m );
   alpha[ 2 ][ 3 ] = 2.0 * (*(x + 3) ) /
      ( IANNIV_ImageAnnot[ COORPV_ImgNum ].SemiMinorAxis_m *
        IANNIV_ImageAnnot[ COORPV_ImgNum ].SemiMinorAxis_m );

   /* ... and zero doppler frequency equation */
   alpha[ 3 ][ 1 ] = - 2.0 * (DataConv->SV.x *  Rsp * Rsp - dSP.x * prScal)/
      (Rsp * Rsp * Rsp * IANNIV_ImageAnnot[ COORPV_ImgNum ].RadarWaveLength_m);
   alpha[ 3 ][ 2 ] = - 2.0 * (DataConv->SV.y *  Rsp * Rsp - dSP.y * prScal )/
      (Rsp * Rsp * Rsp * IANNIV_ImageAnnot[ COORPV_ImgNum ].RadarWaveLength_m);
   alpha[ 3 ][ 3 ] = - 2.0 * ( DataConv->SV.z *  Rsp * Rsp - dSP.z * prScal)/
      (Rsp * Rsp * Rsp * IANNIV_ImageAnnot[ COORPV_ImgNum ].RadarWaveLength_m);

/* ==========================================================================
   Fill the function matrix ( see comments before )
   ========================================================================== */
   beta[ 1 ] = DataConv->slant - Rsp;
   beta[ 2 ] = 1.0 - ( (*(x + 1)) * (*(x + 1)) + (*(x + 2)) * (*(x + 2)) ) /
		        ( IANNIV_ImageAnnot[ COORPV_ImgNum ].SemiMajorAxis_m *
                          IANNIV_ImageAnnot[ COORPV_ImgNum ].SemiMajorAxis_m ) -
               (*(x+3)) * (*(x+3)) /
	          ( IANNIV_ImageAnnot[ COORPV_ImgNum ].SemiMinorAxis_m *
                    IANNIV_ImageAnnot[ COORPV_ImgNum ].SemiMinorAxis_m ) ;
   beta[ 3 ] = - 2.0 * prScal /
		  ( IANNIV_ImageAnnot[ COORPV_ImgNum ].RadarWaveLength_m *
		  Rsp );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

}/* COORPP_FUNC_Newton_rc_xyz */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORPP_FUNC_Newton_xyz_rc

        $TYPE         PROCEDURE

        $INPUT        x       : current point array

        $MODIFIED     alpha   : matrix with the values of the first derivatives
                                of the two functions WRT the two variables
                                in the current point <x>
		      beta    : array with the values of the functions ( with
                                the minus sign ) in the current point <x>

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  image annotations
                      COORIV_conv[imanum]       : the structure with all
                                                  the global variables that
                                                  the coordinates conversions
                                                  need
                      COORPV_ImgNum             : number of the current image
                                                  among the other in the tool

        $RET_STATUS   ERRSID_COOR_null_dist_sp_target

        $DESCRIPTION  This procedure is ancillary to the coordinates conversion
                      procedure that transforms from cartesian to image
		      coordinates. It's used by the procedure MATH_ROOF_Newton
		      for the resolution of systems of non linear equations

        $WARNING      NONE

   $EH
   ========================================================================== */
void COORPP_FUNC_Newton_xyz_rc
			(/*IN    */ double              *x,
                         /*IN OUT*/ double             **alpha,
                         /*IN OUT*/ double              *beta,
			 /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "COORPP_FUNC_Newton_xyz_rc";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Pointers to the global structures
   ========================================================================== */
   IANNIT_ImageAnnot     *ImgAnno;
   COORIT_conv           *DataConv;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   MATHIT_XYZ             dSP;
   double                 a,b;
   double                 lambda;
   double                 t_row;
   double                 Rsp;
   double                 prScal;
   double                 Sxdr,Sydr,Szdr;
   double                 Vxdr,Vydr,Vzdr;
   double                 Slantdc;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Point to the global structures
   ========================================================================== */
   ImgAnno = ( IANNIV_ImageAnnot + COORPV_ImgNum );
   DataConv = ( COORIV_conv + COORPV_ImgNum );

/* ==========================================================================
   Utility variables
   ========================================================================== */
   a = ImgAnno->SemiMajorAxis_m;
   b = ImgAnno->SemiMinorAxis_m;
   lambda = ImgAnno->RadarWaveLength_m;

/* ==========================================================================
   Evaluate the time corresponding to the current row
   ========================================================================== */
   t_row = DataConv->dt + (*(x + 1) / DataConv->prf );

/* ==========================================================================
   Spacecraft Position evaluation 
   ========================================================================== */
/*
   MATHIP_SPLN_splint( &DataConv->ST_time[ 0 ], &ImgAnno->X_STVec_m[ 0 ],
		       &DataConv->X_STVec_2D[ 0 ], ImgAnno->NStateVectors,
		       t_row, &DataConv->SP.x, status_code );
*/
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->X_STVec_m,
                              ImgAnno->NStateVectors, t_row,
                              DataConv->X_STVec_2D, &DataConv->SP.x,
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/*
   MATHIP_SPLN_splint( &DataConv->ST_time[ 0 ], &ImgAnno->Y_STVec_m[ 0 ],
		       &DataConv->Y_STVec_2D[ 0 ], ImgAnno->NStateVectors,
		       t_row, &DataConv->SP.y, status_code );
*/
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->Y_STVec_m,
                              ImgAnno->NStateVectors, t_row,
                              DataConv->Y_STVec_2D, &DataConv->SP.y,
                              status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/*
   MATHIP_SPLN_splint( &DataConv->ST_time[ 0 ], &ImgAnno->Z_STVec_m[ 0 ],
		       &DataConv->Z_STVec_2D[ 0 ], ImgAnno->NStateVectors,
		       t_row, &DataConv->SP.z, status_code );
*/
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->Z_STVec_m,
                              ImgAnno->NStateVectors, t_row,
                              DataConv->Z_STVec_2D, &DataConv->SP.z,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Spacecraft Velocity evaluation 
   ========================================================================== */
/*
   MATHIP_SPLN_splint( &DataConv->ST_time[ 0 ], &ImgAnno->VX_STVec_m_sec[ 0 ],
		       &DataConv->VX_STVec_2D[ 0 ], ImgAnno->NStateVectors,
		       t_row, &DataConv->SV.x, status_code );
*/
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->VX_STVec_m_sec,
                              ImgAnno->NStateVectors, t_row,
                              DataConv->VX_STVec_2D, &DataConv->SV.x,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/*
   MATHIP_SPLN_splint( &DataConv->ST_time[ 0 ], &ImgAnno->VY_STVec_m_sec[ 0 ],
		       &DataConv->VY_STVec_2D[ 0 ], ImgAnno->NStateVectors,
		       t_row, &DataConv->SV.y, status_code );
*/
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->VY_STVec_m_sec,
                              ImgAnno->NStateVectors, t_row,
                              DataConv->VY_STVec_2D, &DataConv->SV.y,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/*
   MATHIP_SPLN_splint( &DataConv->ST_time[ 0 ], &ImgAnno->VZ_STVec_m_sec[ 0 ],
		       &DataConv->VZ_STVec_2D[ 0 ], ImgAnno->NStateVectors,
		       t_row, &DataConv->SV.z, status_code );
*/
   COORPP_CONV_Interpolator ( DataConv->ST_time, ImgAnno->VZ_STVec_m_sec,
                              ImgAnno->NStateVectors, t_row,
                              DataConv->VZ_STVec_2D, &DataConv->SV.z,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Slant range evaluation
   ========================================================================== */
   COORIP_CONV_SlantRangeEval( *(x + 2), COORPV_ImgNum, &DataConv->slant,
			       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Spacecraft-Target vector evaluation
   ========================================================================== */
   dSP.x = ( DataConv->SP.x - DataConv->xyz_C.x );
   dSP.y = ( DataConv->SP.y - DataConv->xyz_C.y );
   dSP.z = ( DataConv->SP.z - DataConv->xyz_C.z );

/* ==========================================================================
   Spacecraft-Target modulus
   ========================================================================== */
   Rsp = sqrt( dSP.x * dSP.x + dSP.y * dSP.y + dSP.z * dSP.z );

/* ==========================================================================
   Evaluate the scalar product velocity vs Spacecraft-Target vector
   ========================================================================== */
   prScal = DataConv->SV.x * dSP.x + DataConv->SV.y * dSP.y +
      DataConv->SV.z * dSP.z ;

   if ( Rsp == 0 )
      ERRSIM_set_error( status_code, ERRSID_COOR_null_dist_sp_target, "" );

/* ==========================================================================
   Compute the first derivatives
   ========================================================================== */

   /* X state vector ... */
/*
   COORPP_CONV_SplineFirstDeriv( t_row, ImgAnno->NStateVectors,
				 DataConv->ST_time, ImgAnno->X_STVec_m,
				 DataConv->X_STVec_2D, &Sxdr, status_code );
*/
   COORPP_CONV_FirstDeriv ( t_row, ImgAnno->NStateVectors, DataConv->ST_time,
                            ImgAnno->X_STVec_m, DataConv->X_STVec_2D, &Sxdr,
                            status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* ... Y ... */
/*
   COORPP_CONV_SplineFirstDeriv( t_row, ImgAnno->NStateVectors,
                                 DataConv->ST_time, ImgAnno->Y_STVec_m,
                                 DataConv->Y_STVec_2D, &Sydr, status_code );
*/
   COORPP_CONV_FirstDeriv ( t_row, ImgAnno->NStateVectors, DataConv->ST_time,
                            ImgAnno->Y_STVec_m, DataConv->Y_STVec_2D, &Sydr,
                            status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* ... and Z */
/*
   COORPP_CONV_SplineFirstDeriv( t_row, ImgAnno->NStateVectors,
                                 DataConv->ST_time, ImgAnno->Z_STVec_m,
                                 DataConv->Z_STVec_2D, &Szdr, status_code );
*/
   COORPP_CONV_FirstDeriv ( t_row, ImgAnno->NStateVectors, DataConv->ST_time,
                            ImgAnno->Z_STVec_m, DataConv->Z_STVec_2D, &Szdr,
                            status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* Velocity state vectors, VX, VY, VZ */
/*
   COORPP_CONV_SplineFirstDeriv( t_row, ImgAnno->NStateVectors,
                                 DataConv->ST_time, ImgAnno->VX_STVec_m_sec,
                                 DataConv->VX_STVec_2D, &Vxdr, status_code );
*/
   COORPP_CONV_FirstDeriv ( t_row, ImgAnno->NStateVectors, DataConv->ST_time,
                            ImgAnno->VX_STVec_m_sec, DataConv->VX_STVec_2D,
                            &Vxdr, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
/*
   COORPP_CONV_SplineFirstDeriv( t_row, ImgAnno->NStateVectors,
                                 DataConv->ST_time, ImgAnno->VY_STVec_m_sec,
                                 DataConv->VY_STVec_2D, &Vydr, status_code );
*/
   COORPP_CONV_FirstDeriv ( t_row, ImgAnno->NStateVectors, DataConv->ST_time,
                            ImgAnno->VY_STVec_m_sec, DataConv->VY_STVec_2D,
                            &Vydr, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
/*
   COORPP_CONV_SplineFirstDeriv( t_row, ImgAnno->NStateVectors,
                                 DataConv->ST_time, ImgAnno->VZ_STVec_m_sec,
                                 DataConv->VZ_STVec_2D, &Vzdr, status_code );
*/
   COORPP_CONV_FirstDeriv ( t_row, ImgAnno->NStateVectors, DataConv->ST_time,
                            ImgAnno->VZ_STVec_m_sec, DataConv->VZ_STVec_2D,
                            &Vzdr, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Rescale the first derivatives by the PRF to take into account the
   derivative of time WRT row
   ========================================================================== */
   Sxdr /= DataConv->prf;
   Sydr /= DataConv->prf;
   Szdr /= DataConv->prf;
   Vxdr /= DataConv->prf;
   Vydr /= DataConv->prf;
   Vzdr /= DataConv->prf;

/* ==========================================================================
   Evaluate the coefficient to take into account the derivative of the
   slant range WRT the column
   ========================================================================== */
   Slantdc = 1.0;

   if ( DataConv->imaflg == 1 ) {
      UINTx2                 deg;
      double                 w;

/* ==========================================================================
   For ground data evaluate the first derivative of the polynomial to go from
   ground to slant column
   ========================================================================== */
      Slantdc = 0.0;

/* ==========================================================================
   Switch over the processors
   ========================================================================== */
      switch ( ImgAnno->ProcessorName ) {
         case IANNIE_sproc_VMP:
            w = *(x + 2) * DataConv->col_spa;
            for ( deg=1; deg<=ImgAnno->GroundToSlantDegree; deg++ ) {
               Slantdc +=
                  deg * ImgAnno->GroundToSlantCoeff[ deg ] *
                  POW( w, ( deg - 1) );
            }
            Slantdc *= DataConv->col_spa;
         break;
         case IANNIE_sproc_Bangkok:
            w = *(x + 2) * DataConv->col_spa;
            for ( deg=1; deg<=ImgAnno->GroundToSlantDegree; deg++ ) {
               Slantdc +=
                  deg * ImgAnno->GroundToSlantCoeff[ deg ] *
                  POW( w, ( deg - 1) );
            }
         break;
         case IANNIE_sproc_ESAR:
            w = *(x + 2) * 1.e-03;
            for ( deg=1; deg<=ImgAnno->GroundToSlantDegree; deg++ ) {
               Slantdc +=
                  deg * ImgAnno->GroundToSlantCoeff[ deg ] *
                  POW( w, ( deg - 1) );
            }
            Slantdc *= 1.e-03;
         break;
         default:
            ERRSIM_set_error ( status_code, ERRSID_COOR_proc_name_unknown, "" );
      }
   }

/* ==========================================================================
   Fills the first derivative matrix
   ========================================================================== */
   /* first derivatives of the first equation */
   alpha[ 1 ][ 1 ] = ( dSP.x * Sxdr + dSP.y * Sydr + dSP.z * Szdr) / Rsp;
   alpha[ 1 ][ 2 ] = - DataConv->SRCoeff  * Slantdc;

   /* first derivatives of the second equation */
   alpha[ 2 ][ 1 ] = ( ( Vxdr * dSP.x + DataConv->SV.x * Sxdr +
      Vydr * dSP.y + DataConv->SV.y * Sydr + Vzdr * dSP.z +
      DataConv->SV.z * Szdr )* Rsp -
      alpha [ 1 ][ 1 ] * prScal ) * 2.0  / ( Rsp * Rsp * lambda ) ;
   alpha[ 2 ][ 2 ] =  0.0 ;

/* ==========================================================================
   Fill the functions array
   ========================================================================== */
   beta[ 1 ] = DataConv->slant  - Rsp;
   beta[ 2 ] = - ( 2.0 * prScal ) / ( lambda * Rsp );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

}/* COORPP_FUNC_Newton_xyz_rc */


#ifdef SUBS
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_CONV_

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE
 
        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  

        $WARNING      

        $PDL

   $EH
   ========================================================================== */
void COORIP_CONV_
			(/*IN    */
			 /*IN OUT*/
			 /*   OUT*/ ERRSIT_status	*status_code )
{
   const ERRSIT_proc_name routine_name = "COORIP_CONV_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* COORIP_CONV_ */
#endif

