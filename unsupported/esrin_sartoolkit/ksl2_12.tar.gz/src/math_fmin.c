/* ==========================================================================
   $MODULE_HEADER

      $NAME              MATH_FMIN

      $FUNCTION		 This module contains the routines for function
                         minimization. They are masks to use the Numerical
                         Recipes routines.

      $ROUTINE           MATHIP_FMIN_amoeba

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       08-APR-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_NREC_H
#include MATH_INTF_H
#include MATH_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_FMIN_amoeba

        $TYPE         PROCEDURE

        $INPUT        ndim  : the number of dimensions of the independent
                              variable X of the function to minimize
                      ftol  : the fractional convergence tolerance value for
                              the function
                      vtol  : the convergence tolerance value for the variables
                              to evaluate
                      funk  : pointer to the function to minimize

        $MODIFIED     p     : an [ndim+1][ndim] array in which each one of the
                              ndim+1 rows contains the ndim dimensional vectors
                              with the coordinates of the starting simplex
                      y     : an [ndim+1] vector that contains the values of the
                              function to minimize in the simplex vertices

        $OUTPUT       nfunk : counter of the number of times the function funk
                              is called

        $GLOBAL       NONE

        $RET_STATUS   ERRSIM_MATH_err_mem_alloc
                      ERRSID_MATH_num_err

        $DESCRIPTION  This procedure initializes the variables to pass to the
                      Numerical Recipes's procedure amoeba, that minimizes the
                      multivariate function funk

        $WARNING

        $PDL

   $EH
   ========================================================================== */

void MATHIP_FMIN_amoeba
                        (/*IN    */ INTx4                ndim,
                         /*IN    */ double               ftol,
                         /*IN    */ double               vtol,
                         /*IN    */ double             (*funk)(),
                         /*IN OUT*/ double              *p,
                         /*IN OUT*/ double              *y,
                         /*   OUT*/ INTx4               *nfunk,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_FMIN_amoeba";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  i;
   INTx4                  status;
   double               **tmp = (double **)NULL;
   double               **pp = (double **)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Error variable initialization
   ========================================================================== */
   status = 0;

/* ==========================================================================
   Allocate the necessary memories
   ========================================================================== */
   if ( ( pp = (double **)MEMSIP_alloc ( (size_t)(( ndim + 1 ) *
                                         sizeof (double)) ) ) ==
        (double **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc, "" );
   }

/* ==========================================================================
   Save the pointer
   ========================================================================== */
   tmp = pp;

/* ==========================================================================
   Creates the one-offset matrix for the Num. Rec. routine damoeba
   ========================================================================== */
   pp -= 1;
   for ( i=1; i<=ndim+1; i++ ) {
      pp[ i ] = &p[ ( i - 1 ) * ndim ];
      pp[ i ] -= 1;
   }

/* ==========================================================================
   Calls the damoeba routine
   ========================================================================== */
   damoeba ( pp, y - 1, ndim, ftol, vtol, funk, nfunk, &status );
   if ( status ) {
      if ( status == 2 ) {               /* memory allocation error */
         ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc, "" );
      }
      else {                       /* Too many iterations in amoeba */
         ERRSIM_set_error ( status_code, ERRSID_MATH_num_err,
                            "Too much iterations" );
      }
   }

error_exit:;

/* ==========================================================================
   Free memories
   ========================================================================== */
   MEMSIP_free( (void **) &tmp );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code,
                          &log_status_code );

}/* MATHIP_FMIN_amoeba */
