/* ==========================================================================
   $MODULE_HEADER

      $NAME         ERRS_LODT

      $FUNCTION     Get system date and time

      $ROUTINE      ERRSIF_LODT_out_date

      $HISTORY

                SCR NO.      DATE        INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
                N/A       02-JAN-1997       AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <time.h>

#include "defl_libname_intf.h"
#include ERRS_INTF_H
#include ERRS_PGLB_H


/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIF_LODT_out_date

      $FUNCTION     Get the date time in output format

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       out_date_time             : Is the pointer to an empty
                                                string of 25 char.

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This function get the system date and time.
                    The time is returned  in the output standard format:

                       DD-MON-YYYY HH:MM:SS.CCC

                    The function return the pointer to the data time and the
                    null pointer if an error occur.

      $WARNING      It is necessary that the space for the out_data_time
                    string is already allocated.

   $EH
   ========================================================================== */
char *ERRSIF_LODT_out_date
                  (/*  OUT*/ char *out_date_time)
{
   time_t tm;

/* ==========================================================================
   Get the internal system time
   ========================================================================== */
   tm = time( (time_t) NULL );


/* ==========================================================================
   Format the internal date time as DD-MON-YYYY HH:MM:SS.CCC
   ========================================================================== */
   strftime( out_date_time, 25, "%d-%b-%Y %H:%M:%S.000", localtime( &tm ) );

   return out_date_time;


   error_exit: return(NULL);


} /* ERRSIF_LODT_out_date() */

