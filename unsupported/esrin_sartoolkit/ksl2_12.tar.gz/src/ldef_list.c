/* ==========================================================================

   $MODULE_HEADER

   $NAME          LDEF_LIST

   $FUNCTION      Handle linked list.

   $ROUTINE       LDEFIP_LIST_insert_list_elem
                  LDEFIP_LIST_delete_list_elem

   $HISTORY

            PR         DATE       INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A        07-FEB-94  CM/MBC     Initial Release

    $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdlib.h>

#include "defl_libname_intf.h"
#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H

/* ==========================================================================

   $ROUTINE_HEADER
 
        $NAME         LDEFIP_LIST_insert_list_elem

        $DESCRIPTION  Insert one element in the specified linked list at the
                      given position. LDEFID_at_last specify the last position.
                      LDEFID_at_first specify the first position.
 
        $TYPE	       PROCEDURE

        $INPUT        list_elem        : ponter to the new element
                      position         : position in the list
                      
        $MODIFIED     list_pointer     : poineter to the linked list

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE
                       
        $WARNING      NONE
  
        $PDL

           ROUTINE LDEFIP_LIST_insert_list_elem

              IF the position is LDEFID_at_last 
                 add the element at the end of the list;
              ELSE
                 add the element in the specified position;
              ENDIF

           ENDROUTINE LDEFIP_LIST_insert_list_elem

   $EH
   ========================================================================== */
void LDEFIP_LIST_insert_list_elem( /*IN    */ void       *list_elem,
                                   /*IN    */ INTx4       position,
                                   /*IN OUT*/ void      **list_pointer )
{
   INTx4      *next;
   INTx4      *current;
   INTx4      current_position=0;

   next    = *list_pointer;
   current = *list_pointer;

   if ( next == NULL )
   {
      *list_pointer = list_elem;
      ((INTx4 *)list_elem)[0] = (int) NULL;
   }
   else 
   {
      switch (position)
      {
         case LDEFID_at_first:
         {
            *list_pointer = list_elem;
            ((INTx4 *)list_elem)[0] = (int) current;
            break;
         }
         case LDEFID_at_last:
         {
            while ( next[0] != (int) NULL )
            {
               current = next;
               next = (INTx4 *) next[0];   
            }
            next[0] = (int) list_elem;
            ((INTx4 *)list_elem)[0] = (int) NULL;
            break;
         }
         default:
         {
            do
            {
               current = next;
               next = (INTx4 *) next[0];
               current_position++;
            } 
            while ( ( next != NULL ) && ( current_position < position ) );

            if ( next == NULL )
            { 
               current[0] = (int) list_elem;
               ((INTx4 *)list_elem)[0] = (int) NULL;
            }
            else
            {
                current[0] = (int) list_elem;
               ((INTx4 *)list_elem)[0] = (int) next;
            }
            break;
         }
      }
   }
   

}/* LDEFIP_LIST_insert_list_elem */


/* ==========================================================================

   $ROUTINE_HEADER
 
        $NAME         LDEFIP_LIST_delete_list_elem

        $DESCRIPTION  Delete one element in the specified linked list at the
                      given position. LDEFID_at_last specify the last position.
                      LDEFID_at_first specify the first position.
 
        $TYPE	      PROCEDURE

        $INPUT        position         : position in the list
                      
        $MODIFIED     list_pointer     : poineter to the linked list

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE
                       
        $WARNING      NONE
  
        $PDL

           ROUTINE LDEFIP_LIST_delete_list_elem

              IF the position is LDEFID_at_last 
                 delete the element at the end of the list;
              ELSE
                 delete the element in the specified position;
              ENDIF

           ENDROUTINE LDEFIP_LIST_delete_list_elem

   $EH
   ========================================================================== */
void LDEFIP_LIST_delete_list_elem( /*IN    */ INTx4   position,
                                   /*IN OUT*/ void  **list_pointer )
{
   INTx4      *next;
   INTx4      *current;
   INTx4      current_position=0;

   next    = *list_pointer;
   current = *list_pointer;


   if ( next != NULL )
   {
      switch (position)
      {
         case LDEFID_at_first:
         {
            *list_pointer = (INTx4 *)(next[0]);
            MEMSIP_free( (void **) &current );
            break;
         }
         case LDEFID_at_last:
         {
            while ( next[0] != (int) NULL )
            {
               current = next;
               next = (INTx4 *) next[0];   
            }
            if ( next != current )
            {
               current[0] = (int) NULL;
               MEMSIP_free( (void **) &next );
               break;
            }
            else
            {
               *list_pointer = NULL;
               MEMSIP_free( (void **) &current );
               break;
            }
         }
         default:
         {
            do
            {
               current = next;
               next = (INTx4 *) next[0];
               current_position++;
            } 
            while ( ( next != NULL ) && ( current_position < position ) );

            if ( next != NULL )
            { 
                current[0] = next[0];
                MEMSIP_free( (void **) &next );
            }
            break;
         }
      }
   }

}/* LDEFIP_LIST_delete_list_elem */


