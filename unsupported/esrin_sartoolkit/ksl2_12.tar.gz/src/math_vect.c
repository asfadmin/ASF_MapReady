/* ==========================================================================
   $MODULE_HEADER

      $NAME              MATH_VECT

      $FUNCTION          This module contains the procedures to handle the
                         arrays of mathematical objects created as new types
                         to vectorialize the SW developing of STBX.

      $ROUTINE           MATHIP_VECT_Make
                         MATHIP_VECT_Free
                         MATHIP_VECT_Copy
                         MATHIP_VECT_SubCopy
                         MATHIP_VECT_Sum
                         MATHIP_VECT_Subt
                         MATHIP_VECT_ConstMult
                         MATHIP_VECT_Prod
                         MATHIP_VECT_Pow
                         MATHIP_VECT_Extract
                         MATHIP_VECT_Size
                         MATHIP_VECT_Total
                         MATHIP_VECT_Mean
                         MATHIP_VECT_Sigma
                         MATHIP_VECT_FillConst
                         MATHIP_VECT_FillArray
                         MATHIP_VECT_ToFloat
                         MATHIP_VECT_ToUChar
                         MATHIP_VECT_ToInt
                         MATHIP_VECT_ToUInt
                         MATHIP_VECT_Complex
                         MATHIP_VECT_Conj
                         MATHIP_VECT_Modul
                         MATHIP_VECT_Real
                         MATHIP_VECT_Imaginary
                         MATHIP_VECT_Phase
                         MATHIP_VECT_CTo2Float
                         MATHIP_VECT_2FloatToC
                         MATHIP_VECT_Exp
                         MATHIP_VECT_MatrixProduct

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       23-APR-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <string.h>
#include <math.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include MATH_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Make

        $TYPE         PROCEDURE

        $INPUT        nelem : the wanted number of elements of the array
                      atype : the wanted array type

        $MODIFIED     NONE

        $OUTPUT       array : the pointer to the array we want to fill

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_err_mem_alloc

        $DESCRIPTION  This procedure allocates the wanted array of the wanted
                      type, setting to zero the values of its elements

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Make
                        (/*IN    */ INTx4                nelem,
                         /*IN    */ MATHIT_arr_type      atype,
                         /*   OUT*/ MATHIT_array        *array,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Make";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Fill the structure fields
   ========================================================================== */
   array->nelem = nelem;
   array->atype = atype;

/* ==========================================================================
   Allocate the requested memory
   ========================================================================== */
   switch (atype) {
      case MATHIE_float:

         /* float allocation */
         array->ap = (float *)MEMSIP_alloc( (size_t)(nelem*sizeof(float)) );
         if ( array->ap == NULL )
           ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");

         /* zeroes the array */
         memset( (void *)array->ap , 0, (size_t)(nelem*sizeof(float)) );
         break;

      case MATHIE_uchar:

         /* unsigned byte allocation ... see comments above */
         array->ap = (UINTx1 *)MEMSIP_alloc( (size_t)(nelem*sizeof(UINTx1)) );
         if ( array->ap == NULL )
           ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");
         memset( (void *)array->ap , 0, (size_t)(nelem*sizeof(UINTx1)) );
         break;

      case MATHIE_uintx2:

         /* unsigned intx2 allocation ... see comments above */
         array->ap = (UINTx2 *)MEMSIP_alloc( (size_t)(nelem*sizeof(UINTx2)) );
         if ( array->ap == NULL )
           ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");
         memset( (void *)array->ap , 0, (size_t)(nelem*sizeof(UINTx2)) );
         break;

      case MATHIE_uintx4:

         /* unsigned int allocation ... see comments above */
         array->ap = (UINTx4 *)MEMSIP_alloc( (size_t)(nelem*sizeof(UINTx4)) );
         if ( array->ap == NULL )
           ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");
         memset( (void *)array->ap , 0, (size_t)(nelem*sizeof(UINTx4)) );
         break;

      case MATHIE_sintx4:

         /* signed int allocation ... see comments above */
         array->ap = (INTx4 *)MEMSIP_alloc( (size_t)(nelem*sizeof(INTx4)) );
         if ( array->ap == NULL )
           ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");
         memset( (void *)array->ap , 0, (size_t)(nelem*sizeof(INTx4)) );
         break;

      case MATHIE_complex:

         /* complex allocation ... see comments above */
         array->ap = (MATHIT_complex *)
	    MEMSIP_alloc( (size_t)( nelem * sizeof( MATHIT_complex ) ) );
         if ( array->ap == NULL )
           ERRSIM_set_error( status_code, ERRSID_MATH_err_mem_alloc, "" );
         memset ( (void *)array->ap , (INTx4)0,
		  (size_t)( nelem * sizeof( MATHIT_complex ) ) );
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Make */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Free

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     array : the pointer to the array we want to free

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure free the allocated memory of the passed
                      array

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Free
                        (/*IN OUT*/ MATHIT_array        *array,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Free";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Free the memory
   ========================================================================== */
   if ( array->ap != NULL )
      MEMSIP_free( &(array->ap) );

/* ==========================================================================
   Fill the structure fields
   ========================================================================== */
   array->nelem = 0;
   array->atype = MATHIE_undef;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Free */





/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_SetZero

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     array      : the array to set zero

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure set all arry elements to zero

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_SetZero
                        (/*IN OUT*/ MATHIT_array        *array,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_SetZero";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Zeroes the array according its type
   ========================================================================== */
   switch (array->atype) {
      case MATHIE_float:
         memset( (void *)array->ap , 0, (size_t)(array->nelem*sizeof(float)) );
         break;

      case MATHIE_uchar:
         memset( (void *)array->ap , 0, (size_t)(array->nelem*sizeof(UINTx1)) );
         break;

      case MATHIE_sintx4:

         memset( (void *)array->ap , 0, (size_t)(array->nelem*sizeof(INTx4)) );
         break;

      case MATHIE_uintx4:

         memset( (void *)array->ap , 0, (size_t)(array->nelem*sizeof(UINTx4)) );
         break;

      case MATHIE_uintx2:

         memset( (void *)array->ap , 0, (size_t)(array->nelem*sizeof(UINTx2)) );
         break;

      case MATHIE_complex:

         memset ( array->ap , 0,
                  (size_t)( array->nelem * sizeof( MATHIT_complex ) ) );
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_SetZero */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Copy

        $TYPE         PROCEDURE

        $INPUT        source	: the source array to copy

        $MODIFIED     NONE

        $OUTPUT       target	: the target array in which the source must
                                  be copied

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure copies an array into another

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Copy
                        (/*IN    */ MATHIT_array         source,
                         /*   OUT*/ MATHIT_array        *target,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Copy";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4 i;
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of source and target arrays
   ========================================================================== */
   if ( source.nelem != target->nelem ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements of the target array");
   }
   if ( source.atype != target->atype) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different type of target array");
   }

/* ==========================================================================
   Copy the array
   ========================================================================== */
   switch (target->atype) {
      case MATHIE_float:

         /* float copy */
         memcpy( (void *)(target->ap), (const void *)(source.ap),
                 (size_t)(source.nelem*sizeof(float)));
         break;

      case MATHIE_uchar:

         /* unsigned byte copy */
         memcpy( (void *)(target->ap), (const void *)(source.ap),
                 (size_t)(source.nelem*sizeof(INTx1)));
         break;

      case MATHIE_sintx4:

         /* signed int copy */
         memcpy( (void *)(target->ap), (const void *)(source.ap),
                 (size_t)(source.nelem*sizeof(INTx4)));

         break;

      case MATHIE_uintx4:

         /* unsigned intx4 copy */
         memcpy( (void *)(target->ap), (const void *)(source.ap),
                 (size_t)(source.nelem*sizeof(UINTx4)));
         break;

      case MATHIE_uintx2:

         /* unsigned intx2 copy */
         memcpy( (void *)(target->ap), (const void *)(source.ap),
                 (size_t)(source.nelem*sizeof(UINTx2)));
         break;

      case MATHIE_complex:

         /* complex copy */
         memcpy ( target->ap, (const void *)(source.ap),
                 (size_t)( source.nelem * sizeof( MATHIT_complex ) ) );
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Copy */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_SubCopy

        $TYPE         PROCEDURE

        $INPUT        source	: the source array to copy
                      start_in	: the index of the elements of the source
                                  array from which start to copy the sub array
                      nelem	: the number of elements to copy
                      start_out	: the index of the element of the target array
                                  from which start to fill

        $MODIFIED     target	: the target array in which the source must
                                  be copied

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure copies a part of an array into another in
                      the indicated position

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_SubCopy
                        (/*IN    */ MATHIT_array         source,
                         /*IN    */ INTx4                start_in,
                         /*IN    */ INTx4                nelem,
                         /*IN OUT*/ MATHIT_array        *target,
                         /*IN    */ INTx4                start_out,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_SubCopy";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of source and target arrays
   ========================================================================== */
   if ( source.nelem < start_in+nelem-1 )
      ERRSIM_set_error(status_code,ERRSID_MATH_no_suff_arr_elem,
         "source array");

   if ( target->nelem < start_out+nelem-1 )
      ERRSIM_set_error(status_code,ERRSID_MATH_no_suff_arr_elem,
                       "target array");

   if ( target->atype != source.atype )
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different type of target array");

/* ==========================================================================
   Copy the array
   ========================================================================== */
   switch (target->atype) {
      case MATHIE_float:

         /* float copy */
         memcpy( (void *)( (float *)target->ap+start_out), 
                 (const void *)( (float *)source.ap+start_in),
                 (size_t)(nelem*sizeof(float)));
         break;

      case MATHIE_uchar:

         /* unsigned byte copy */
         memcpy( (void *)( (UINTx1 *)target->ap+start_out),
                 (const void *)( (UINTx1 *)source.ap+start_in),
                 (size_t)(nelem*sizeof(INTx1)));
         break;

      case MATHIE_sintx4:

         /* signed int copy */
         memcpy( (void *)( (INTx4 *)target->ap+start_out),
                 (const void *)( (INTx4 *)source.ap+start_in),
                 (size_t)(nelem*sizeof(INTx4)));

         break;

      case MATHIE_uintx4:

         /* unsigned int copy */
         memcpy( (void *)( (UINTx4 *)target->ap+start_out),
                 (const void *)( (UINTx4 *)source.ap+start_in),
                 (size_t)(nelem*sizeof(UINTx4)));
         break;

      case MATHIE_uintx2:

         /* unsigned intx2 copy */
         memcpy( (void *)( (UINTx2 *)target->ap+start_out),
                 (const void *)( (UINTx2 *)source.ap+start_in),
                 (size_t)(nelem*sizeof(UINTx2)));
         break;

      case MATHIE_complex:

         /* complex copy */
         memcpy ( (void *)( (MATHIT_complex *)target->ap + start_out ),
                  (const void *)( (MATHIT_complex *)source.ap + start_in ),
                  (size_t)( nelem * sizeof( MATHIT_complex ) ) );
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_SubCopy */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Sum

        $TYPE         PROCEDURE

        $INPUT        arr1	: first array to sum
                      arr2	: second array to sum

        $MODIFIED     NONE

        $OUTPUT       arrout	: array sum of the two passed in input

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure sums together two array

        $WARNING      No checks of overflowing problems are done

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Sum
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ MATHIT_array         arr2,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Sum";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the arrays
   ========================================================================== */
   if ( arr1.nelem != arr2.nelem ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements");
   }
   if ( arr1.atype != arr2.atype) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different type of arrays");
   }
   if (arrout->nelem != arr1.nelem) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements of the target array");
   }
   if (arrout->atype != arr1.atype) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different type of target array");
   }

/* ==========================================================================
   Sum element by element
   ========================================================================== */
   switch (arr1.atype) {
      case MATHIE_float:

         /* sum float numbers */
         for (i=0;i<arrout->nelem;i++) {
            *( (float *)(arrout->ap)+i) =
               *( (float *)(arr1.ap)+i) +
               *( (float *)(arr2.ap)+i);
         }
         break;

      case MATHIE_uchar:

         /* sum unsigned byte */
         for (i=0;i<arrout->nelem;i++) {
            *( (INTx1 *)(arrout->ap)+i) =
               *( (INTx1 *)(arr1.ap)+i) +
               *( (INTx1 *)(arr2.ap)+i);
         }
         break;

     case MATHIE_sintx4:

         /* sum signed int */
         for (i=0;i<arrout->nelem;i++) {
            *( (INTx4 *)(arrout->ap)+i) =
               *( (INTx4 *)(arr1.ap)+i) +
               *( (INTx4 *)(arr2.ap)+i);
         }
         break;

      case MATHIE_uintx4:

         /* sum unsigned int */
         for (i=0;i<arrout->nelem;i++) {
            *( (UINTx4 *)(arrout->ap)+i) =
               *( (UINTx4 *)(arr1.ap)+i) +
               *( (UINTx4 *)(arr2.ap)+i);
         }
         break;

      case MATHIE_uintx2:

         /* sum unsigned intx2 */
         for (i=0;i<arrout->nelem;i++) {
            *( (UINTx2 *)(arrout->ap)+i) =
               *( (UINTx2 *)(arr1.ap)+i) +
               *( (UINTx2 *)(arr2.ap)+i);
         }
         break;

      case MATHIE_complex:

         /* sum complex */
         for ( i=0; i<arrout->nelem; i++ ) {
            (((MATHIT_complex *)(arrout->ap))[ i ]).rea =
               (((MATHIT_complex *)arr1.ap)[ i ]).rea +
               (((MATHIT_complex *)arr2.ap)[ i ]).rea;
            (((MATHIT_complex *)(arrout->ap))[ i ]).ima =
               (((MATHIT_complex *)arr1.ap)[ i ]).ima +
               (((MATHIT_complex *)arr2.ap)[ i ]).ima;
         }
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Sum */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Subt

        $TYPE         PROCEDURE

        $INPUT        arr1	: first array
                      arr2	: array to subtract

        $MODIFIED     NONE

        $OUTPUT       arrout	: array difference of the input given two

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure subtract the elements of one array from
                      another

        $WARNING      No checks of overflowing problems are done

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Subt
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ MATHIT_array         arr2,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Subt";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the input array consistency
   ========================================================================== */
   if ( arr1.nelem != arr2.nelem ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements");
   }
   if ( arr1.atype != arr2.atype) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different type of arrays");
   }
   if (arrout->nelem != arr1.nelem) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements of the target array");
   }
   if (arrout->atype != arr1.atype) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different type of target array");
   }

/* ==========================================================================
   Subtract the array elements
   ========================================================================== */
   switch (arr1.atype) {
      case MATHIE_float:

         /* subtract float numbers */
         for (i=0;i<arrout->nelem;i++) {
            *( (float *)(arrout->ap)+i) =
               *( (float *)(arr1.ap)+i) -
               *( (float *)(arr2.ap)+i);
         }
         break;

      case MATHIE_uchar:

         /* subtract unsigned byte */
         for (i=0;i<arrout->nelem;i++) {
            *( (INTx1 *)(arrout->ap)+i) =
               *( (INTx1 *)(arr1.ap)+i) -
               *( (INTx1 *)(arr2.ap)+i);
         }
         break;

     case MATHIE_sintx4:

         /* subtract signed int */
         for (i=0;i<arrout->nelem;i++) {
            *( (INTx4 *)(arrout->ap)+i) =
               *( (INTx4 *)(arr1.ap)+i) -
               *( (INTx4 *)(arr2.ap)+i);
         }
         break;

      case MATHIE_uintx4:

         /* subtract unsigned int */
         for (i=0;i<arrout->nelem;i++) {
            *( (UINTx4 *)(arrout->ap)+i) =
               *( (UINTx4 *)(arr1.ap)+i) -
               *( (UINTx4 *)(arr2.ap)+i);
         }
         break;

      case MATHIE_uintx2:

         /* subtract unsigned intx2 */
         for (i=0;i<arrout->nelem;i++) {
            *( (UINTx2 *)(arrout->ap)+i) =
               *( (UINTx2 *)(arr1.ap)+i) -
               *( (UINTx2 *)(arr2.ap)+i);
         }
         break;

      case MATHIE_complex:

         /* subtract complex */
         for ( i=0; i<arrout->nelem; i++ ) {
            (((MATHIT_complex *)arrout->ap)[ i ]).rea =
               (((MATHIT_complex *)arr1.ap)[ i ]).rea -
               (((MATHIT_complex *)arr2.ap)[ i ]).rea;
            (((MATHIT_complex *)arrout->ap)[ i ]).ima =
               (((MATHIT_complex *)arr1.ap)[ i ]).ima -
               (((MATHIT_complex *)arr2.ap)[ i ]).ima;
         }
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Subt */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ConstMult

        $TYPE         PROCEDURE

        $INPUT        fconst	: a constant double value
                      arrinp	: the array to multiply

        $MODIFIED     NONE

        $OUTPUT       arrout	: the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes a multiplication of an array by
                      a constant

        $WARNING      No check of oferflowing problems is done

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_ConstMult
                        (/*IN    */ double               fconst,
                         /*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_ConstMult";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check for the output array consistency
   ========================================================================== */
   if ( arrout->nelem != arrinp.nelem ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_arr_uncomp,
                         "different number of elements of the target array" );
   }
   if ( arrout->atype != arrinp.atype) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_arr_uncomp,
                         "different type of target array" );
   }

/* ==========================================================================
   Multiply the array
   ========================================================================== */
   switch ( arrinp.atype ) {
      case MATHIE_float:

         /* float multiplication */
         for ( i=0; i<arrinp.nelem; i++ ) {
            *( (float *)arrout->ap + i ) = 
               (float)(fconst * ( *( (float *)arrinp.ap + i ) ));
         }
         break;

      case MATHIE_uchar:

         /* unsigned byte multiplication */
         for ( i=0; i<arrinp.nelem; i++ ) {
            *( (UINTx1 *)arrout->ap + i) = 
               (UINTx1)(fconst * ( *( (UINTx1 *)arrinp.ap + i ) ));
         }
         break;

      case MATHIE_sintx4:

         /* signed int multiplication */
         for ( i=0; i<arrinp.nelem; i++ ) {
            *( (INTx4 *)arrout->ap + i ) = 
               (INTx4)(fconst * ( *( (INTx4 *)arrinp.ap + i ) ));
         }
         break;

      case MATHIE_uintx4:

         /* unsigned int multiplication */
         for ( i=0; i<arrinp.nelem; i++ ) {
            *( (UINTx4 *)arrout->ap + i ) = 
               (UINTx4)(fconst * ( *( (UINTx4 *)arrinp.ap + i ) ));
         }
         break;

      case MATHIE_uintx2:

         /* unsigned int multiplication */
         for ( i=0; i<arrinp.nelem; i++ ) {
            *( (UINTx2 *)arrout->ap + i ) = 
               (UINTx2)(fconst * ( *( (UINTx2 *)arrinp.ap + i ) ));
         }
         break;

      case MATHIE_complex:

         /* complex multiplication */
         for ( i=0; i<arrinp.nelem; i++ ) {
            (((MATHIT_complex *)arrout->ap)[ i ]).rea =
               (float)( fconst *
               ( (((MATHIT_complex *)arrout->ap)[ i ]).rea ) );
            (((MATHIT_complex *)arrout->ap)[ i ]).ima =
               (float)( fconst *
               ( (((MATHIT_complex *)arrout->ap)[ i ]).ima ) );
         }

/*
         for ( i=0;i<2*arrinp.nelem;i++ ) {
            *( (float *)arrout->ap + i ) = 
               (float)( fconst * (*( (float *)arrinp.ap + i ) ) );
         }
*/
         break;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_ConstMult */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ConstAdd

        $TYPE         PROCEDURE

        $INPUT        fconst	: a constant double value
                      arrinp	: the array to be added

        $MODIFIED     NONE

        $OUTPUT       arrout	: the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure adds an array by a constant

        $WARNING      No check of oferflowing problems is done

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_ConstAdd
                        (/*IN    */ double               fconst,
                         /*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_ConstAdd";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the output array consistency
   ========================================================================== */
   if ( arrout->nelem != arrinp.nelem ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements of the target array");
   }
   if ( arrout->atype != arrinp.atype) {
      ERRSIM_set_error(status_code, ERRSID_MATH_arr_uncomp,
                       "different type of target array");
   }

/* ==========================================================================
   Add the array
   ========================================================================== */
   switch (arrinp.atype) {
      case MATHIE_float:

         /* float addition */
         for (i=0;i<arrinp.nelem;i++) {
            *( (float *)arrout->ap + i) = 
               (float)(fconst+(*( (float *)arrinp.ap + i)));
         }
         break;

      case MATHIE_uchar:

         /* unsigned byte addition */
         for (i=0;i<arrinp.nelem;i++) {
            *( (UINTx1 *)arrout->ap + i) = 
               (UINTx1)(fconst+(*( (UINTx1 *)arrinp.ap + i)));
         }
         break;

      case MATHIE_sintx4:

         /* signed int addition */
         for (i=0;i<arrinp.nelem;i++) {
            *( (INTx4 *)arrout->ap + i) = 
               (INTx4)(fconst+(*( (INTx4 *)arrinp.ap + i)));
         }
         break;

      case MATHIE_uintx4:

         /* unsigned int addition */
         for (i=0;i<arrinp.nelem;i++) {
            *( (UINTx4 *)arrout->ap + i) = 
               (UINTx4)(fconst+(*( (UINTx4 *)arrinp.ap + i)));
         }
         break;

      case MATHIE_uintx2:

         /* unsigned int addition */
         for (i=0;i<arrinp.nelem;i++) {
            *( (UINTx2 *)arrout->ap + i) = 
               (UINTx2)(fconst+(*( (UINTx2 *)arrinp.ap + i)));
         }
         break;

      case MATHIE_complex:
	 ERRSIM_set_error( status_code,
			   ERRSID_MATH_arr_uncomp,
                           "unimplemented type" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_ConstAdd */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Prod

        $TYPE         PROCEDURE

        $INPUT        arr1	: the first array of the product
                      arr2	: the second array of the product

        $MODIFIED     NONE

        $OUTPUT       arrout	: the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes the product element by element of
                      two vectors

        $WARNING      No check of overflowing problems is done

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Prod
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ MATHIT_array         arr2,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Prod";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the input array consistency
   ========================================================================== */
   if ( arr1.nelem != arr2.nelem ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements");
   }
   if ( arr1.atype != arr2.atype) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different type of arrays");
   }
   if (arrout->nelem != arr1.nelem) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements of the target array");
   }
   if (arrout->atype != arr1.atype) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different type of target array");
   }

/* ==========================================================================
   Make the product
   ========================================================================== */
   switch (arr1.atype) {
      case MATHIE_float:

         /* float multiplication */
         for (i=0;i<arrout->nelem;i++) {
            *( (float *)arrout->ap + i) =
               (*( (float *)arr1.ap + i)) *
               (*( (float *)arr2.ap + i));
         }
         break;

      case MATHIE_uchar:

         /* unsigned byte multiplication */
         for (i=0;i<arrout->nelem;i++) {
            *( (UINTx1 *)arrout->ap + i) =
               (*( (UINTx1 *)arr1.ap + i)) *
               (*( (UINTx1 *)arr2.ap + i));
         }
         break;

      case MATHIE_sintx4:

         /* signed int multiplication */
         for (i=0;i<arrout->nelem;i++) {
            *((INTx4 *)arrout->ap + i) =
               (*( (INTx4 *)arr1.ap + i)) *
               (*( (INTx4 *)arr2.ap + i));
         }
         break;

      case MATHIE_uintx4:

         /* unsigned int multiplication */
         for (i=0;i<arrout->nelem;i++) {
            *( (UINTx4 *)arrout->ap + i) =
               (*( (UINTx4 *)arr1.ap + i)) *
               (*( (UINTx4 *)arr2.ap + i));
         }
         break;

      case MATHIE_uintx2:

         /* unsigned int multiplication */
         for (i=0;i<arrout->nelem;i++) {
            *( (UINTx2 *)arrout->ap + i) =
               (*( (UINTx2 *)arr1.ap + i)) *
               (*( (UINTx2 *)arr2.ap + i));
         }
         break;

      case MATHIE_complex:

         /* complex multiplication */
         for ( i=0; i<arrout->nelem; i++ ) {
            (((MATHIT_complex *)arrout->ap)[ i ]).rea =
               (((MATHIT_complex *)arr1.ap)[ i ]).rea *
                  (((MATHIT_complex *)arr2.ap)[ i ]).rea -
               (((MATHIT_complex *)arr1.ap)[ i ]).ima *
                  (((MATHIT_complex *)arr2.ap)[ i ]).ima;
            (((MATHIT_complex *)arrout->ap)[ i ]).ima =
               (((MATHIT_complex *)arr1.ap)[ i ]).rea *
                  (((MATHIT_complex *)arr2.ap)[ i ]).ima +
               (((MATHIT_complex *)arr1.ap)[ i ]).ima *
                  (((MATHIT_complex *)arr2.ap)[ i ]).rea;
         }
         break;
   }


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Prod */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_HeterProd

        $TYPE         PROCEDURE

        $INPUT        arr1	: the first array of the product
                      arr2	: the second array of the product

        $MODIFIED     NONE

        $OUTPUT       arrout	: the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes the product element by element of
                      two vectors of different type

        $WARNING      No check of overflowing problems is done

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_HeterProd
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ MATHIT_array         arr2,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_HeterProd";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the input array consistency
   ========================================================================== */
   if ( arr1.nelem != arr2.nelem ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements");
   }
   if (arrout->nelem != arr1.nelem) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements of the target array");
   }
   if( (arr1.atype == MATHIE_complex) ||
       (arr2.atype == MATHIE_complex) ||
       (arrout->atype == MATHIE_complex) ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "unimplemented type for array products");
   }

/* ==========================================================================
   Make the product
   ========================================================================== */
   switch (arrout->atype) {
      case MATHIE_float:
	 switch (arr1.atype) {
	    case MATHIE_float:
	       switch (arr2.atype) {
		  case MATHIE_float:
		     /* float = float * float multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (float *)arr1.ap + i)) *
			      (*( (float *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uchar:
		     /* float = float * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (float *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* float = float * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (float *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
		     /* float = float * uintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (float *)arr1.ap + i)) *
			      (*( (UINTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx2:
		     /* float = float * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (float *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	    case MATHIE_uchar:
	       switch (arr2.atype) {
		  case MATHIE_float:
		     /* float = uchar * float multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (float *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uchar:
		     /* float = uchar * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* float = uchar * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
		     /* float = uchar * uintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (UINTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx2:
		     /* float = uchar * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	    case MATHIE_sintx4:
	       switch (arr2.atype) {
		  case MATHIE_float:
		     /* float = sintx4 * float multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (float *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uchar:
		     /* float = sintx4 * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* float = sintx4 * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
		     /* float = sintx4 * uintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (UINTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx2:
		     /* float = sintx4 * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	    case MATHIE_uintx4:
	       switch (arr2.atype) {
		  case MATHIE_float:
		     /* float = uintx4 * float multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx4 *)arr1.ap + i)) *
			      (*( (float *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uchar:
		     /* float = uintx4 * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx4 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* float = uintx4 * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx4 *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
		     /* float = uintx4 * uintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx4 *)arr1.ap + i)) *
			      (*( (UINTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx2:
		     /* float = uintx4 * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx4 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
            case MATHIE_uintx2:
	       switch (arr2.atype) {
		  case MATHIE_float:
		     /* float = uintx2 * float multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (float *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uchar:
		     /* float = uintx2 * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* float = uintx2 * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
		     /* float = uintx2 * uintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (UINTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx2:
		     /* float = uintx2 * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (float *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	 }
         break;

      case MATHIE_uchar:
	 switch (arr1.atype) {
	    case MATHIE_float:
	       switch (arr2.atype) {
		  case MATHIE_float:
		  case MATHIE_uchar:
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
		  case MATHIE_uintx2:
		     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
				      "incompatible type for array products");
	       }
	       break;
	    case MATHIE_uchar:
	       switch (arr2.atype) {
		  case MATHIE_float:
		     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
				      "incompatible type for array products");
		  case MATHIE_uchar:
		     /* uchar = uchar * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx1 *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
		  case MATHIE_uintx2:
		     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
				      "incompatible type for array products");
	       }
	       break;
	    case MATHIE_sintx4:
	       switch (arr2.atype) {
		  case MATHIE_float:
		  case MATHIE_uchar:
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
		  case MATHIE_uintx2:
		     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
				      "incompatible type for array products");
	       }
	       break;
	    case MATHIE_uintx4:
	       switch (arr2.atype) {
		  case MATHIE_float:
		  case MATHIE_uchar:
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
		  case MATHIE_uintx2:
		     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
				      "incompatible type for array products");
	       }
	       break;
            case MATHIE_uintx2:
	       switch (arr2.atype) {
		  case MATHIE_float:
		  case MATHIE_uchar:
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
		  case MATHIE_uintx2:
		     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
				      "incompatible type for array products");
               }
	       break;
	 }
         break;

      case MATHIE_sintx4:
	 switch (arr1.atype) {
	    case MATHIE_float:
	       switch (arr2.atype) {
		  case MATHIE_float:
		  case MATHIE_uchar:
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
		  case MATHIE_uintx2:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
	       }
	       break;
	    case MATHIE_uchar:
	       switch (arr2.atype) {
		  case MATHIE_float:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uchar:
		     /* sintx4 = uchar * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (INTx4 *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* sintx4 = uchar * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (INTx4 *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uintx2:
		     /* sintx4 = uchar * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (INTx4 *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	    case MATHIE_sintx4:
	       switch (arr2.atype) {
		  case MATHIE_float:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uchar:
		     /* sintx4 = sintx4 * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (INTx4 *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* sintx4 = sintx4 * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (INTx4 *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uintx2:
		     /* sintx4 = sintx4 * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (INTx4 *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	    case MATHIE_uintx4:
	       switch (arr2.atype) {
		  case MATHIE_float:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uchar:
		     /* sintx4 = uintx4 * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (INTx4 *)arrout->ap + i) =
			      (*( (UINTx4 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
		  case MATHIE_uintx2:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
	       }
	       break;
            case MATHIE_uintx2:
	       switch (arr2.atype) {
		  case MATHIE_float:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uchar:
		     /* sintx4 = uintx2 * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (INTx4 *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* sintx4 = uintx2 * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (INTx4 *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uintx2:
		     /* sintx4 = uintx2 * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (INTx4 *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	 }
         break;

      case MATHIE_uintx4:
	 switch (arr1.atype) {
	    case MATHIE_float:
	       switch (arr2.atype) {
		  case MATHIE_float:
		  case MATHIE_uchar:
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
		  case MATHIE_uintx2:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
	       }
	       break;
	    case MATHIE_uchar:
	       switch (arr2.atype) {
		  case MATHIE_float:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uchar:
		     /* uintx4 = uchar * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* uintx4 = uchar * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
		     /* uintx4 = uchar * uintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (UINTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx2:
		     /* uintx4 = uchar * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	    case MATHIE_sintx4:
	       switch (arr2.atype) {
		  case MATHIE_float:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uchar:
		     /* uintx4 = sintx4 * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* uintx4 = sintx4 * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
		     /* uintx4 = sintx4 * uintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (UINTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx2:
		     /* uintx4 = sintx4 * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (INTx4 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	    case MATHIE_uintx4:
	       switch (arr2.atype) {
		  case MATHIE_float:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uchar:
		     /* uintx4 = uintx4 * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx4 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* uintx4 = uintx4 * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx4 *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
		     /* uintx4 = uintx4 * uintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx4 *)arr1.ap + i)) *
			      (*( (UINTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx2:
		     /* uintx4 = uintx4 * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx4 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
            case MATHIE_uintx2:
	       switch (arr2.atype) {
		  case MATHIE_float:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uchar:
		     /* uintx4 = uintx2 * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		     /* uintx4 = uintx2 * sintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (INTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx4:
		     /* uintx4 = uintx2 * uintx4 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (UINTx4 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_uintx2:
		     /* uintx4 = uintx2 * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx4 *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	 }
         break;
      case MATHIE_uintx2:
	 switch (arr1.atype) {
	    case MATHIE_float:
	       switch (arr2.atype) {
		  case MATHIE_float:
		  case MATHIE_uchar:
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
		  case MATHIE_uintx2:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
	       }
	       break;
	    case MATHIE_uchar:
	       switch (arr2.atype) {
		  case MATHIE_float:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uchar:
		     /* uintx2 = uchar * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx2 *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uintx2:
		     /* uintx2 = uchar * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx2 *)arrout->ap + i) =
			      (*( (UINTx1 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	    case MATHIE_sintx4:
	       switch (arr2.atype) {
		  case MATHIE_float:
		  case MATHIE_uchar:
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
		  case MATHIE_uintx2:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
	       }
	       break;
	    case MATHIE_uintx4:
	       switch (arr2.atype) {
		  case MATHIE_float:
		  case MATHIE_uchar:
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
		  case MATHIE_uintx2:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
	       }
	       break;
            case MATHIE_uintx2:
	       switch (arr2.atype) {
		  case MATHIE_float:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uchar:
		     /* uintx2 = uintx2 * uchar multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx2 *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (UINTx1 *)arr2.ap + i));
		     }
		     break;
		  case MATHIE_sintx4:
		  case MATHIE_uintx4:
                     ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                                      "incompatible type for array products");
		  case MATHIE_uintx2:
		     /* uintx2 = uintx2 * uintx2 multiplication */
		     for (i=0;i<arrout->nelem;i++) {
			*( (UINTx2 *)arrout->ap + i) =
			      (*( (UINTx2 *)arr1.ap + i)) *
			      (*( (UINTx2 *)arr2.ap + i));
		     }
		     break;
	       }
	       break;
	 }
         break;

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_HeterProd */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_HeterInnerProd

        $TYPE         PROCEDURE

        $INPUT        arr1	: the first array of the product
                      arr2	: the second array of the product

        $MODIFIED     NONE

        $OUTPUT       val    	: the output value

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes the inner products of
                      two vectors of different type

        $WARNING      No check of overflowing problems is done

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_HeterInnerProd
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ MATHIT_array         arr2,
                         /*   OUT*/ double              *val,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_HeterInnerProd";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the input array consistency
   ========================================================================== */
   if ( arr1.nelem != arr2.nelem ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements");
   }

   if( (arr1.atype == MATHIE_complex) ||
       (arr2.atype == MATHIE_complex) ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "unimplemented type for array products");
   }

/* ==========================================================================
   Zeros output value
   ========================================================================== */
   *val = 0.0;

/* ==========================================================================
   Make the product
   ========================================================================== */
   switch (arr1.atype) {
      case MATHIE_float:
	 switch (arr2.atype) {
	    case MATHIE_float:
	       /* float = float * float multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (float *)arr1.ap + i)) *
			(*( (float *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uchar:
	       /* float = float * uchar multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (float *)arr1.ap + i)) *
			(*( (UINTx1 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_sintx4:
	       /* float = float * sintx4 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (float *)arr1.ap + i)) *
			(*( (INTx4 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uintx4:
	       /* float = float * uintx4 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (float *)arr1.ap + i)) *
			(*( (UINTx4 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uintx2:
	       /* float = float * uintx2 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (float *)arr1.ap + i)) *
			(*( (UINTx2 *)arr2.ap + i));
	       }
	       break;
	 }
	 break;
      case MATHIE_uchar:
	 switch (arr2.atype) {
	    case MATHIE_float:
	       /* float = uchar * float multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx1 *)arr1.ap + i)) *
			(*( (float *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uchar:
	       /* float = uchar * uchar multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx1 *)arr1.ap + i)) *
			(*( (UINTx1 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_sintx4:
	       /* float = uchar * sintx4 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx1 *)arr1.ap + i)) *
			(*( (INTx4 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uintx4:
	       /* float = uchar * uintx4 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx1 *)arr1.ap + i)) *
			(*( (UINTx4 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uintx2:
	       /* float = uchar * uintx2 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx1 *)arr1.ap + i)) *
			(*( (UINTx2 *)arr2.ap + i));
	       }
	       break;
	 }
	 break;
      case MATHIE_sintx4:
	 switch (arr2.atype) {
	    case MATHIE_float:
	       /* float = sintx4 * float multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (INTx4 *)arr1.ap + i)) *
			(*( (float *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uchar:
	       /* float = sintx4 * uchar multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (INTx4 *)arr1.ap + i)) *
			(*( (UINTx1 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_sintx4:
	       /* float = sintx4 * sintx4 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (INTx4 *)arr1.ap + i)) *
			(*( (INTx4 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uintx4:
	       /* float = sintx4 * uintx4 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (INTx4 *)arr1.ap + i)) *
			(*( (UINTx4 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uintx2:
	       /* float = sintx4 * uintx2 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (INTx4 *)arr1.ap + i)) *
			(*( (UINTx2 *)arr2.ap + i));
	       }
	       break;
	 }
	 break;
      case MATHIE_uintx4:
	 switch (arr2.atype) {
	    case MATHIE_float:
	       /* float = uintx4 * float multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx4 *)arr1.ap + i)) *
			(*( (float *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uchar:
	       /* float = uintx4 * uchar multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx4 *)arr1.ap + i)) *
			(*( (UINTx1 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_sintx4:
	       /* float = uintx4 * sintx4 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx4 *)arr1.ap + i)) *
			(*( (INTx4 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uintx4:
	       /* float = uintx4 * uintx4 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx4 *)arr1.ap + i)) *
			(*( (UINTx4 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uintx2:
	       /* float = uintx4 * uintx2 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx4 *)arr1.ap + i)) *
			(*( (UINTx2 *)arr2.ap + i));
	       }
	       break;
	 }
	 break;
      case MATHIE_uintx2:
	 switch (arr2.atype) {
	    case MATHIE_float:
	       /* float = uintx2 * float multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx2 *)arr1.ap + i)) *
			(*( (float *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uchar:
	       /* float = uintx2 * uchar multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx2 *)arr1.ap + i)) *
			(*( (UINTx1 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_sintx4:
	       /* float = uintx2 * sintx4 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx2 *)arr1.ap + i)) *
			(*( (INTx4 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uintx4:
	       /* float = uintx2 * uintx4 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx2 *)arr1.ap + i)) *
			(*( (UINTx4 *)arr2.ap + i));
	       }
	       break;
	    case MATHIE_uintx2:
	       /* float = uintx2 * uintx2 multiplication */
	       for (i=0;i<arr1.nelem;i++) {
                  *val +=
			(*( (UINTx2 *)arr1.ap + i)) *
			(*( (UINTx2 *)arr2.ap + i));
	       }
	       break;
	 }
	 break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_HeterInnerProd */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Pow

        $TYPE         PROCEDURE

        $INPUT        arrin     : the array to be powered
                      exp	: the exponent of power

        $MODIFIED     arrout    : the array powered (alway float)

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes the power element by element

        $WARNING      No check of overflowing problems is done

        $PDL

   $EH
   ========================================================================== */
void MATHIP_VECT_Pow
                        (/*IN    */ MATHIT_array         arrin,
                         /*IN    */ double               exp,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Pow";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the input array consistency
   ========================================================================== */
   if ( arrin.nelem != arrout->nelem ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements");
   }
   if ( arrout->atype != MATHIE_float) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "output type of arrays always float");
   }

/* ==========================================================================
   Make the power
   ========================================================================== */
   switch (arrin.atype) {
      case MATHIE_float:

         /* float multiplication */
         for (i=0;i<arrout->nelem;i++) {
            *( (float *)arrout->ap + i) = (float)
               POW((double)(*( (float *)arrin.ap + i)), exp);
         }
         break;

      case MATHIE_uchar:

         /* unsigned byte multiplication */
         for (i=0;i<arrout->nelem;i++) {
            *( (float *)arrout->ap + i) = (float)
               POW((double)(*( (UINTx1 *)arrin.ap + i)), exp);
         }
         break;

      case MATHIE_sintx4:

         /* signed int multiplication */
         for (i=0;i<arrout->nelem;i++) {
            *( (float *)arrout->ap + i) = (float)
               POW((double)(*( (INTx4 *)arrin.ap + i)), exp);
         }
         break;

      case MATHIE_uintx4:

         /* unsigned int multiplication */
         for (i=0;i<arrout->nelem;i++) {
            *( (float *)arrout->ap + i) = (float)
               POW((double)(*( (UINTx4 *)arrin.ap + i)), exp);
         }
         break;

      case MATHIE_uintx2:

         /* unsigned int multiplication */
         for (i=0;i<arrout->nelem;i++) {
            *( (float *)arrout->ap + i) = (float)
               POW((double)(*( (UINTx2 *)arrin.ap + i)), exp);
         }
         break;
      default:
         ERRSIM_set_error(status_code, ERRSID_MATH_arr_uncomp,
                       "function not implemented for this type");
   }


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Pow */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Extract

        $TYPE         PROCEDURE

        $INPUT        source	: the array from which extract the new array
                      start	: index from which start in the subarray
                                  extraction
                      nelem	: number of elements to extract

        $MODIFIED     NONE

        $OUTPUT       subarr	: the target array for the extraction

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure extracts a subarray of the wanted
                      dimensions starting from the wanted position from an
                      array given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Extract
                        (/*IN    */ MATHIT_array         source,
                         /*IN    */ INTx4                start,
                         /*IN    */ INTx4                nelem,
                         /*   OUT*/ MATHIT_array        *subarr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Extract";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the input-output arrays consistency
   ========================================================================== */
   if ( subarr->atype != source.atype ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different type of target array");
   }
   if ( subarr->nelem < nelem ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "target array too small");
   }
   if ( (start+nelem) > source.nelem ) {
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       " not compatible target - source dimensions");
   }

/* ==========================================================================
   Copy the array
   ========================================================================== */
   switch (source.atype) {
      case MATHIE_float:

         /* float copy */
         memcpy( (void *)(subarr->ap),
            (void *)( ( (float *)source.ap + start) ),
            (size_t)(nelem*sizeof(float)) );
         break;

      case MATHIE_uchar:

         /* unsigned byte copy */
         memcpy( (void *)(subarr->ap),
            (void *)( ( (UINTx1 *)source.ap + start) ),
            (size_t)(nelem*sizeof(UINTx1)) );
         break;

      case MATHIE_sintx4:

         /* signed int copy */
         memcpy( (void *)(subarr->ap),
            (void *)( ( (INTx4 *)source.ap + start) ),
            (size_t)(nelem*sizeof(INTx4)) );
         break;

      case MATHIE_uintx4:

         /* unsigned int copy */
         memcpy( (void *)(subarr->ap),
            (void *)( ( (UINTx4 *)source.ap + start) ),
            (size_t)(nelem*sizeof(UINTx4)) );
         break;

      case MATHIE_uintx2:

         /* unsigned intx2 copy */
         memcpy( (void *)(subarr->ap),
            (void *)( ( (UINTx2 *)source.ap + start) ),
            (size_t)(nelem*sizeof(UINTx2)) );
         break;

      case MATHIE_complex:

         /* complex copy */
         memcpy ( subarr->ap,
                  (void *)( ( (MATHIT_complex *)source.ap + start ) ),
                  (size_t)( nelem * sizeof( MATHIT_complex ) ) );
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Extract */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Size

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the input array of which we want to know
                                  the size

        $MODIFIED     NONE

        $OUTPUT       Nelements	: the number of elements of the array

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure returns the number of elements of the array
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Size
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ INTx4               *Nelements,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Size";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Copy the information in the output variable
   ========================================================================== */
   *(Nelements) = arrinp.nelem;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Size */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Total

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the array of which we want know the sum of
                                  the elements

        $MODIFIED     NONE

        $OUTPUT       sum	: the sum of the input array' s elements

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure returns the evaluated sum of the elements
                      of the array passed in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Total
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ double              *sum,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Total";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp.nelem < 1 )     /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Zeroes the sum
   ========================================================================== */
   if ( arrinp.atype == MATHIE_complex ) sum[0] = sum[1] = 0.;
   else  *(sum) = 0.;

/* ==========================================================================
   Sum all the elements
   ========================================================================== */
   switch (arrinp.atype) {
      case MATHIE_float:

         /* float array elements */
         for (i=0;i<arrinp.nelem;i++)
            *(sum) += *( (float *)arrinp.ap + i);
         break;
      case MATHIE_uchar:

         /* unsigned char array */
         for (i=0;i<arrinp.nelem;i++)
            *(sum) += *( (UINTx1 *)arrinp.ap + i);
         break;
      case MATHIE_sintx4:

         /* signed int array */
         for (i=0;i<arrinp.nelem;i++)
            *(sum) += *( (INTx4 *)arrinp.ap + i);
         break;
      case MATHIE_uintx2:

         /* unsigned int array */
         for (i=0;i<arrinp.nelem;i++)
            *(sum) += *( (UINTx2 *)arrinp.ap + i);
         break;
      case MATHIE_uintx4:

         /* unsigned int array */
         for (i=0;i<arrinp.nelem;i++)
            *(sum) += *( (UINTx4 *)arrinp.ap + i);
         break;
      case MATHIE_complex:

         /* complex array elements */
         for ( i=0; i<arrinp.nelem; i++ ) {
            sum[0] += (((MATHIT_complex *)arrinp.ap)[ i ]).rea;
            sum[1] += (((MATHIT_complex *)arrinp.ap)[ i ]).ima;
         }
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_VECT_Total */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_MinMax

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the array of which we want know the sum of
                                  the elements
                      mask      : the array of UINTx1 element to be used (1)
                                  or not (0)

        $MODIFIED     NONE

        $OUTPUT       min	: the min value of the input array' s elements
                      max       : the max value of the input array' s elements

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure returns the min and the max of the elements
                      of the array passed in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_MinMax
                        (/*IN    */ MATHIT_array         arrinp,
                         /*IN    */ MATHIT_array         mask,
                         /*   OUT*/ float               *min,
                         /*   OUT*/ float               *max,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_MinMax";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp.nelem < 1 )     /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

   if( mask.atype != MATHIE_uchar ) {
      ERRSIM_set_error( status_code, ERRSID_MATH_arr_uncomp, "mask");
   }

/* ==========================================================================
   Sum all the elements
   ========================================================================== */
   switch (arrinp.atype) {
      case MATHIE_float:

         /* float array elements */
         *min = (float)  1.e+38;
         *max = (float) -1.e+38;
         for (i=0;i<arrinp.nelem;i++) {
            if( (((UINTx1 *)mask.ap)[ i ]) == 1) {
               if( ((float *)arrinp.ap)[ i ] < *min ) {
                  *min = ((float *)arrinp.ap)[ i ];
               }
               if( ((float *)arrinp.ap)[ i ] > *max ) {
                  *max = ((float *)arrinp.ap)[ i ];
               }
            }
         }
         break;
      case MATHIE_uchar:

         /* unsigned char array */
         *min = (float) UINTx1_MAX;
         *max = (float) 0;
         for (i=0;i<arrinp.nelem;i++) {
            if( (((UINTx1 *)mask.ap)[ i ]) == 1) {
               if( ((float) ((UINTx1 *)arrinp.ap)[ i ]) < *min ) {
                  *min = (float) ((UINTx1 *)arrinp.ap)[ i ];
               }
               if( ((float) ((UINTx1 *)arrinp.ap)[ i ]) > *max ) {
                  *max = (float) ((UINTx1 *)arrinp.ap)[ i ];
               }
            }
         }
         break;
      case MATHIE_sintx4:

         /* signed int array */
         *min = (float) INTx4_MAX;
         *max = (float) INTx4_MIN;
         for (i=0;i<arrinp.nelem;i++) {
            if( (((UINTx1 *)mask.ap)[ i ]) == 1) {
               if( ((float) ((INTx4 *)arrinp.ap)[ i ]) < *min ) {
                  *min = (float) ((INTx4 *)arrinp.ap)[ i ];
               }
               if( ((float) ((INTx4 *)arrinp.ap)[ i ]) > *max ) {
                  *max = (float) ((INTx4 *)arrinp.ap)[ i ];
               }
            }
         }
         break;
      case MATHIE_uintx2:

         /* unsigned int array */
         *min = (float) UINTx2_MAX;
         *max = (float) 0;
         for (i=0;i<arrinp.nelem;i++) {
            if( ((float) ((UINTx2 *)arrinp.ap)[ i ]) < *min ) {
               *min = (float) ((UINTx2 *)arrinp.ap)[ i ];
            }
            if( ((float) ((UINTx2 *)arrinp.ap)[ i ]) > *max ) {
               *max = (float) ((UINTx2 *)arrinp.ap)[ i ];
            }
         }
         break;
      case MATHIE_uintx4:

         /* unsigned int array */
         *min = (float) ((UINTx4 *)arrinp.ap)[ 0 ];
         *max = (float) ((UINTx4 *)arrinp.ap)[ 0 ];
         for (i=0;i<arrinp.nelem;i++) {
            if( (((UINTx1 *)mask.ap)[ i ]) == 1) {
               if( ((float) ((UINTx4 *)arrinp.ap)[ i ]) < *min ) {
                  *min = (float) ((UINTx4 *)arrinp.ap)[ i ];
               }
               if( ((float) ((UINTx4 *)arrinp.ap)[ i ]) > *max ) {
                  *max = (float) ((UINTx4 *)arrinp.ap)[ i ];
               }
            }
         }
         break;
      case MATHIE_complex:

         /* complex array elements */
         ERRSIM_set_error(status_code, ERRSID_MATH_arr_uncomp, "");
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_VECT_MinMax */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Mean

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the array to which the mean value must be
                                  done

        $MODIFIED     NONE

        $OUTPUT       mean	: the mean value of the array elements

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the mean value of the elements
                      of the array passed in input

        $WARNING      No check of overflowing problems must be done

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Mean
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ double              *mean,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Mean";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   double                 sum[2];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Evaluates the sum of the elements
   ========================================================================== */
   MATHIP_VECT_Total(arrinp,sum,status_code);
   ERRSIM_on_err_goto_exit(*status_code);

/* ==========================================================================
   Divide for the number of elements of the array
   ========================================================================== */
   if ( arrinp.atype == MATHIE_complex) {
      mean[0] = sum[0] / arrinp.nelem;
      mean[1] = sum[1] / arrinp.nelem;
   } else *(mean) = sum[0] / arrinp.nelem;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Mean */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Sigma

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the array of which the sigma must be
                                  evaluated
                      nconst	: the number of constraints to consider in
                                  the count

        $MODIFIED     NONE

        $OUTPUT       sigma	: the sigma value. It's the standard deviation
                                  with nconst = 1, or the RMS WRT the mean value
                                  with nconst = 0

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure evaluates the root sum of square of the
                      elements of the input array minus their mean value,
                      divided by the number of elements of the array decreased
                      by the number of constraints imposed to the data

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Sigma
                        (/*IN    */ MATHIT_array         arrinp,
                         /*IN    */ INTx4                nconst,
                         /*   OUT*/ double              *sigma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Sigma";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  i;
   double                 mean[ 2 ];
   double                 uti;
   MATHIT_complex         sum_res;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, &process_flag, &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp.nelem - nconst < 1 ) {

      /* no sufficient points in the array */
      ERRSIM_set_error ( status_code, ERRSID_MATH_null_arr, "" );
   }

/* ==========================================================================
   Zero the sum
   ========================================================================== */
   memset ( (void *)&sum_res, '\0', sizeof (MATHIT_complex) );

/* ==========================================================================
   Evaluate the mean array elements value
   ========================================================================== */
   MATHIP_VECT_Mean ( arrinp, mean, status_code );

/* ==========================================================================
   Sum the residual square
   ========================================================================== */
   switch ( arrinp.atype ) {
      case MATHIE_float:

         /* float array */
         for ( i=0; i<arrinp.nelem; i++ ) {
            uti = (double)(*( (UINTx1 *)arrinp.ap + i ) - mean[ 0 ]);
            sum_res.rea += POW ( uti, 2. );
         }
         break;
      case MATHIE_uchar:

         /* unsigned char array ... see comment above */
         for ( i=0; i<arrinp.nelem; i++ ) {
            uti = (double)(*( (UINTx1 *)arrinp.ap + i ) - mean[ 0 ]);
            sum_res.rea += POW ( uti, 2. );
         }
         break;
      case MATHIE_sintx4:

         /* signed int array */
         for ( i=0; i<arrinp.nelem; i++ ) {
            uti = (double)(*( (INTx4 *)arrinp.ap + i ) - mean[ 0 ]);
            sum_res.rea += POW ( uti, 2. );
         }
         break;
      case MATHIE_uintx4:

         /* unsigned int array */
         for ( i=0; i<arrinp.nelem; i++ ) {
            uti = (double)(*( (UINTx4 *)arrinp.ap + i ) - mean[ 0 ]);
            sum_res.rea += POW ( uti, 2. );
         }
         break;
      case MATHIE_uintx2:

         /* unsigned intx2 array */
         for ( i=0; i<arrinp.nelem; i++ ) {
            uti = (double)(*( (UINTx2 *)arrinp.ap + i ) - mean[ 0 ]);
            sum_res.rea += POW ( uti, 2. );
         }
         break;
      case MATHIE_complex:

         /* complex array */
         for ( i=0; i<arrinp.nelem; i++ ) {
            uti = (double)
               ((((MATHIT_complex *)arrinp.ap)[ i ]).rea - mean[ 0 ]);
            sum_res.rea += POW ( uti, 2. );
            uti = (double)
               ((((MATHIT_complex *)arrinp.ap)[ i ]).ima - mean[ 1 ]);
            sum_res.ima += POW ( uti, 2. );
         }
         break;
   }

/* ==========================================================================
   Divide by the number of degree of freedom and extract the square root
   ========================================================================== */
   MATHIP_STYP_CConstMult ( ( (double)1. / arrinp.nelem ), sum_res, &sum_res,
                            status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   if ( arrinp.atype == MATHIE_complex) {
      if ( nconst < 1 ) {
         sigma[ 0 ] = sqrt ( sum_res.rea );
         sigma[ 1 ] = sqrt ( sum_res.ima );
      }
      else {
         sigma[ 0 ] = sqrt ( ( sum_res.rea ) * arrinp.nelem /
            ( arrinp.nelem - nconst ) );
         sigma[ 1 ] = sqrt ( ( sum_res.ima ) * arrinp.nelem /
            ( arrinp.nelem - nconst ) );
      }
   } 
   else {
      if ( nconst < 1 ) {
         *sigma = sqrt ( sum_res.rea );
      }
      else {
         *sigma = sqrt ( ( sum_res.rea ) * arrinp.nelem /
            ( arrinp.nelem - nconst ) );
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* MATHIP_VECT_Sigma */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_FillConst

        $TYPE         PROCEDURE

        $INPUT        const	: the value to assign to the array elements

        $MODIFIED     arrinp	: the input array to fill

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure assignes a value user defined to the
                      elements of the input array

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_FillConst
                        (/*IN    */ void                *k,
                         /*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_FillConst";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp->nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Set the array elements to the required value
   ========================================================================== */
   switch (arrinp->atype) {
      case MATHIE_float:

         /* float values */
         for (i=0;i<arrinp->nelem;i++)
            *( (float *)arrinp->ap + i) = *( (float *)k );
         break;
      case MATHIE_uchar:

         /* unsigned char values */
         for (i=0;i<arrinp->nelem;i++)
            *( (UINTx1 *)arrinp->ap + i) = *( (UINTx1 *)k );
         break;
      case MATHIE_sintx4:

         /* signed int values */
         for (i=0;i<arrinp->nelem;i++)
            *( (INTx4 *)arrinp->ap + i) = *( (INTx4 *)k );
         break;
      case MATHIE_uintx2:

         /* unsigned int values */
         for (i=0;i<arrinp->nelem;i++)
            *( (UINTx2 *)arrinp->ap + i) = *( (UINTx2 *)k );
      break;
      case MATHIE_uintx4:

         /* unsigned int values */
         for (i=0;i<arrinp->nelem;i++)
            *( (UINTx4 *)arrinp->ap + i) = *( (UINTx4 *)k );
      break;
      case MATHIE_complex: {
         MATHIT_complex           const_val;

         /* complex values */
         const_val.rea = ((float *)k)[ 0 ];
         const_val.ima = ((float *)k)[ 1 ];
         for ( i=0; i<arrinp->nelem; i++ ) {
            memcpy ( (void *)&(((MATHIT_complex *)arrinp->ap)[ i ]),
                     (void *)&const_val, sizeof (MATHIT_complex) );
         }
      }
      break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_FillConst */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_FillArray

        $TYPE         PROCEDURE

        $INPUT        inp_array_p    : pointer to the input array
                      n_elem         : number of elements of the input array
                      inp_data_type  : input data type among that defined by:
                                       LDEFIE_dt_type:
                                       - LDEFIE_dt_UINTx1    ( byte data )
                                       - LDEFIE_dt_UINTx2    ( real data )
                                       - LDEFIE_dt_2_INTx2   ( complex data )
                                       - LDEFIE_dt_float     ( real floating )
                                       - LDEFIE_dt_2_float   ( complex
                                                               floating )

        $MODIFIED     out_array      : output array to fill

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_arr_uncomp
                      ERRSID_MATH_no_conv
                      ERRSID_MATH_arr_undef

        $DESCRIPTION  This procedure fills the array in output with the
                      elements of the buffer pointed by the passed pointer
                      <inp_array_p>

        $WARNING      THE ARRAY OF OUTPUT MUST BE CREATED BEFORE.
                      NOT ALL THE POSSIBLE CONVERSIONS ARE HANDLED

   $EH
   ========================================================================== */

void MATHIP_VECT_FillArray
                        (/*IN    */ void                *inp_array_p,
                         /*IN    */ INTx4                n_elem,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN OUT*/ MATHIT_array        *out_array,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_FillArray";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 el;          /* counter of the elements */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the number of elements
   ========================================================================== */
   if ( n_elem > out_array->nelem ) {
      ERRSIM_set_error( status_code, ERRSID_MATH_no_suff_arr_elem, "" );
   }

/* ==========================================================================
   Switch the output array type
   ========================================================================== */
   switch ( out_array->atype ) {
      case MATHIE_uchar:

/* ==========================================================================
   Switch the input data type
   ========================================================================== */
         switch ( inp_data_type ) {
            case LDEFIE_dt_UINTx1:

/* ==========================================================================
   Same sizes array copy
   ========================================================================== */
               memcpy( out_array->ap, inp_array_p,
                       (size_t)( n_elem * sizeof( UINTx1 ) ) );
            break;
            case LDEFIE_dt_UINTx2:
            case LDEFIE_dt_float:

/* ==========================================================================
   Conversion not allowed
   ========================================================================== */
               ERRSIM_set_error( status_code, ERRSID_MATH_arr_uncomp, "" );
            case LDEFIE_dt_2_UINTx1:
            case LDEFIE_dt_2_INTx2:
            case LDEFIE_dt_2_float:

/* ==========================================================================
   Conversion not possible
   ========================================================================== */
               ERRSIM_set_error( status_code, ERRSID_MATH_no_conv, "" );
         }
      break;
      case MATHIE_uintx2:

/* ==========================================================================
   Switch the input data type ... see comment above
   ========================================================================== */
         switch ( inp_data_type ) {
            case LDEFIE_dt_UINTx1:
               for ( el=0;el<n_elem;el++ ) {
                  ((UINTx2 *)out_array->ap)[ el ] =
                     (UINTx2)((UINTx1 *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_UINTx2:
               memcpy ( out_array->ap, inp_array_p,
                        (size_t)( n_elem * sizeof(UINTx2) ) );
            break;
            case LDEFIE_dt_float:
               for ( el=0;el<n_elem;el++ ) {
                  ((UINTx2 *)out_array->ap)[ el ] =
                     (UINTx2)((float *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_2_UINTx1:
            case LDEFIE_dt_2_INTx2:
            case LDEFIE_dt_2_float:
               ERRSIM_set_error( status_code, ERRSID_MATH_no_conv, "" );
         }
      break;
      case MATHIE_uintx4:

/* ==========================================================================
   Switch the input data type ... see comment above
   ========================================================================== */
         switch ( inp_data_type ) {
            case LDEFIE_dt_UINTx1:
               for ( el=0;el<n_elem;el++ ) {
                  ((UINTx4 *)out_array->ap)[ el ] =
                     (UINTx4)((UINTx1 *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_UINTx2:
               for ( el=0;el<n_elem;el++ ) {
                  ((UINTx4 *)out_array->ap)[ el ] =
                     (UINTx4)((UINTx2 *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_float:
               for ( el=0;el<n_elem;el++ ) {
                  ((UINTx4 *)out_array->ap)[ el ] =
                     (UINTx4)((float *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_2_UINTx1:
            case LDEFIE_dt_2_INTx2:
            case LDEFIE_dt_2_float:
               ERRSIM_set_error( status_code, ERRSID_MATH_no_conv, "" );
         }
      break;
      case MATHIE_sintx4:

/* ==========================================================================
   Switch the input data type ... see comment above
   ========================================================================== */
         switch ( inp_data_type ) {
            case LDEFIE_dt_UINTx1:
               for ( el=0;el<n_elem;el++ ) {
                  ((INTx4 *)out_array->ap)[ el ] =
                     (INTx4)((UINTx1 *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_UINTx2:
               for ( el=0;el<n_elem;el++ ) {
                  ((INTx4 *)out_array->ap)[ el ] =
                     (INTx4)((UINTx2 *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_float:
               for ( el=0;el<n_elem;el++ ) {
                  ((INTx4 *)out_array->ap)[ el ] =
                     (INTx4)((float *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_2_UINTx1:
            case LDEFIE_dt_2_INTx2:
            case LDEFIE_dt_2_float:
               ERRSIM_set_error( status_code, ERRSID_MATH_no_conv, "" );
         }
      break;
      case MATHIE_float:

/* ==========================================================================
   Switch the input data type ... see comment above
   ========================================================================== */
         switch ( inp_data_type ) {
            case LDEFIE_dt_UINTx1:
               for ( el=0;el<n_elem;el++ ) {
                  ((float *)out_array->ap)[ el ] =
                     (float)((UINTx1 *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_UINTx2:
               for ( el=0;el<n_elem;el++ ) {
                  ((float *)out_array->ap)[ el ] =
                     (float)((UINTx2 *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_float:
               memcpy ( out_array->ap, inp_array_p,
                        (size_t)( n_elem * sizeof( float ) ) );
            break;
            case LDEFIE_dt_2_UINTx1:
            case LDEFIE_dt_2_INTx2:
            case LDEFIE_dt_2_float:
               ERRSIM_set_error( status_code, ERRSID_MATH_no_conv, "" );
         }
      break;
      case MATHIE_complex:

/* ==========================================================================
   Switch the input data type ... see comment above
   ========================================================================== */
         switch ( inp_data_type ) {
            case LDEFIE_dt_UINTx1:
               for ( el=0;el<n_elem;el++ ) {
                  ((MATHIT_complex *)out_array->ap)[ el ].rea =
                     (float)((UINTx1 *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_UINTx2:
               for ( el=0;el<n_elem;el++ ) {
                  ((MATHIT_complex *)out_array->ap)[ el ].rea =
                     (float)((UINTx2 *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_float:
               for ( el=0;el<n_elem;el++ ) {
                  ((MATHIT_complex *)out_array->ap)[ el ].rea =
                     (float)((float *)inp_array_p)[ el ];
               }
            break;
            case LDEFIE_dt_2_UINTx1:
               for ( el=0;el<n_elem;el++ ) {
                  ((MATHIT_complex *)out_array->ap)[ el ].rea =
                     (float)((UINTx1 *)inp_array_p)[ el * 2 ];
                  ((MATHIT_complex *)out_array->ap)[ el ].ima =
                     (float)((UINTx1 *)inp_array_p)[ el * 2 + 1 ];
               }
            break;
            case LDEFIE_dt_2_INTx2:
               for ( el=0;el<n_elem;el++ ) {
                  ((MATHIT_complex *)out_array->ap)[ el ].rea =
                     (float)((INTx2 *)inp_array_p)[ el * 2 ];
                  ((MATHIT_complex *)out_array->ap)[ el ].ima =
                     (float)((INTx2 *)inp_array_p)[ el * 2 + 1 ];
               }
            break;
            case LDEFIE_dt_2_float:
               for ( el=0;el<n_elem;el++ ) {
                  ((MATHIT_complex *)out_array->ap)[ el ].rea =
                     ((float *)inp_array_p)[ el * 2 ];
                  ((MATHIT_complex *)out_array->ap)[ el ].ima =
                     ((float *)inp_array_p)[ el * 2 + 1 ];
               }
            break;
         }
      break;
      default:
         ERRSIM_set_error( status_code, ERRSID_MATH_arr_undef, "" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_FillArray */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ToFloat

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     arrinp	: the array to cast

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_no_conv

        $DESCRIPTION  This procedure makes a cast of an array to float type

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_ToFloat
                        (/*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_ToFloat";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;
   float                 *buff = NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp->nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Allocate the temporary memory
   ========================================================================== */
   if ( arrinp->atype != MATHIE_float ) {

      /* allocate the memory */
      buff = (float *)MEMSIP_alloc( (size_t)(arrinp->nelem*sizeof(float)) );
      if ( buff == NULL )                         /* error check */
         ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");


      switch (arrinp->atype) {
	 case MATHIE_uchar:

	    /* from unsigned char to float */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (float)(*( (UINTx1 *)arrinp->ap+i));
	    break;
	 case MATHIE_sintx4:

	    /* from integer to float */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (float)(*( (INTx4 *)arrinp->ap+i));
	    break;
	 case MATHIE_uintx4:

	    /* from unsigned integer to float */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (float)(*( (UINTx4 *)arrinp->ap+i));
	    break;
	 case MATHIE_uintx2:

	    /* from unsigned integer to float */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (float)(*( (UINTx2 *)arrinp->ap+i));
	    break;
	 case MATHIE_complex:

	    /* no conversion is possible */
	    ERRSIM_set_error(status_code,ERRSID_MATH_no_conv,
			     "from complex to float");
      }

/* ==========================================================================
   Free the array memory ...
   ========================================================================== */
      if ( arrinp->ap != NULL) MEMSIP_free( &(arrinp->ap) );

/* ==========================================================================
   ... and repoint to the new array
   ========================================================================== */
      arrinp->ap = buff;

/* ==========================================================================
   Changes the array descriptors
   ========================================================================== */
      arrinp->atype = MATHIE_float;

   } 

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_ToFloat */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ToUChar

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     arrinp	: the array to cast

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_no_conv

        $DESCRIPTION  This procedure makes a cast of an array to type unsigned
                      character

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_ToUChar
                        (/*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_ToUChar";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                   i;
   UINTx1                 *buff;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp->nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Allocate the temporary memory
   ========================================================================== */
   if (arrinp->atype != MATHIE_uchar ) {

      /* allocates the memory */
      buff = (UINTx1 *)MEMSIP_alloc( (size_t)(arrinp->nelem*sizeof(UINTx1)) );
      if ( buff == NULL )                         /* error check */
         ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");

/* ==========================================================================
   Copy the memory in the temporary buffer
   ========================================================================== */
      switch (arrinp->atype) {
	 case MATHIE_float:

	    /* from float to unsigned char */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (UINTx1)(*( (float *)arrinp->ap+i));
	    break;
	 case MATHIE_sintx4:

	    /* from integer to unsigned char */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (UINTx1)(*( (INTx4 *)arrinp->ap+i));
	    break;
	 case MATHIE_uintx4:

	    /* from unsigned integer to unsigned char */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (UINTx1)(*( (UINTx4 *)arrinp->ap+i));
	    break;
	 case MATHIE_uintx2:

	    /* from unsigned integerx2 to unsigned char */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (UINTx1)(*( (UINTx2 *)arrinp->ap+i));
	    break;
	 case MATHIE_complex:

	    /* no conversion is possible */
	    ERRSIM_set_error(status_code,ERRSID_MATH_no_conv,
			     "from complex to unsigned char");
      }

/* ==========================================================================
   Free the array memory ...
   ========================================================================== */
      if ( arrinp->ap != NULL) MEMSIP_free( &(arrinp->ap) );

/* ==========================================================================
   ... and repoint to the new array
   ========================================================================== */
      arrinp->ap = buff;

/* ==========================================================================
   Changes the array descriptors
   ========================================================================== */
      arrinp->atype = MATHIE_uchar;

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_ToUChar */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ToInt

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     arrinp	: the array to cast

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_no_conv

        $DESCRIPTION  This procedure makes a cast of an array to type int

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_ToInt
                        (/*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_ToInt";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;
   INTx4                 *buff;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp->nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Allocate the temporary memory
   ========================================================================== */
   if ( arrinp->atype != MATHIE_sintx4 ) {

      /* allocate the memory */
      buff = (INTx4 *)MEMSIP_alloc( (size_t)(arrinp->nelem*sizeof(INTx4)) );
      if ( buff == NULL )                         /* error check */
         ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");

/* ==========================================================================
   Copy the memory in the temporary buffer
   ========================================================================== */
      switch (arrinp->atype) {
	 case MATHIE_uchar:

	    /* from unsigned char to signed int */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (INTx4)(*( (UINTx1 *)arrinp->ap+i));
	    break;

	 case MATHIE_float:

	    /* from float to signed int */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (INTx4)(*( (float *)arrinp->ap+i));
	    break;

	 case MATHIE_uintx4:

	    /* from unsigned integer to signed int */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (INTx4)(*( (UINTx4 *)arrinp->ap+i));
	    break;

	 case MATHIE_uintx2:

	    /* from unsigned integer to signed int */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (INTx4)(*( (UINTx2 *)arrinp->ap+i));
	    break;

	 case MATHIE_complex:

	    /* no conversion is possible */
	    ERRSIM_set_error(status_code,ERRSID_MATH_no_conv,
			     "from complex to signed int");
      }

/* ==========================================================================
   Free the array memory ...
   ========================================================================== */
      if ( arrinp->ap != NULL) MEMSIP_free( &(arrinp->ap) );

/* ==========================================================================
   ... and repoint to the new array
   ========================================================================== */
      arrinp->ap = buff;

/* ==========================================================================
   Changes the array descriptors
   ========================================================================== */
      arrinp->atype = MATHIE_sintx4;

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_ToInt */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ToIntFloor

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     arrinp	: the array to cast

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_no_conv
                      ERRSID_MATH_err_mem_alloc

        $DESCRIPTION  This procedure makes a cast of an array to type int
                      with floor conventions for float numbers

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_ToIntFloor
                        (/*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_ToIntFloor";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;
   INTx4                 *buff = (INTx4 *) NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp->nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Allocate the temporary memory
   ========================================================================== */
   if ( arrinp->atype != MATHIE_sintx4 ) {

      /* allocate the memory */
      buff = (INTx4 *)MEMSIP_alloc( (size_t)(arrinp->nelem*sizeof(INTx4)) );
      if ( buff == NULL )                         /* error check */
         ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");

/* ==========================================================================
   Copy the memory in the temporary buffer
   ========================================================================== */
      switch (arrinp->atype) {
	 case MATHIE_uchar:

	    /* from unsigned char to signed int */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (INTx4)(*( (UINTx1 *)arrinp->ap+i));
	    break;

	 case MATHIE_float:

	    /* from float to signed int */
	    for (i=0;i<arrinp->nelem;i++) {
	       if( (*( (float *)arrinp->ap+i))<0 ) {
		  buff[i] = (INTx4)((*( (float *)arrinp->ap+i))-1.0);
	       }
	       else {
		  buff[i] = (INTx4)(*( (float *)arrinp->ap+i));
	       }
	    }
	    break;

	 case MATHIE_uintx4:

	    /* from unsigned integer to signed int */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (INTx4)(*( (UINTx4 *)arrinp->ap+i));
	    break;

	 case MATHIE_uintx2:

	    /* from unsigned integer to signed int */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (INTx4)(*( (UINTx2 *)arrinp->ap+i));
	    break;

	 case MATHIE_complex:

	    /* no conversion is possible */
	    ERRSIM_set_error(status_code,ERRSID_MATH_no_conv,
			     "from complex to signed int");
      }

/* ==========================================================================
   Free the array memory ...
   ========================================================================== */
      if ( arrinp->ap != NULL) MEMSIP_free( &(arrinp->ap) );

/* ==========================================================================
   ... and repoint to the new array
   ========================================================================== */
      arrinp->ap = buff;

/* ==========================================================================
   Changes the array descriptors
   ========================================================================== */
      arrinp->atype = MATHIE_sintx4;

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_ToIntFloor */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ToUInt

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     arrinp	: the array to cast

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_no_conv

        $DESCRIPTION  This procedure makes a cast of an array to type unsigned
                      int

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_ToUInt
                        (/*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_ToUInt";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;
   UINTx4                *buff;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp->nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Allocate the temporary memory
   ========================================================================== */
   if ( arrinp->atype != MATHIE_sintx4 ) {

      /* allocate the memory */
      buff = (UINTx4 *)MEMSIP_alloc( (size_t)(arrinp->nelem*sizeof(UINTx4)) );
      if ( buff == NULL )                         /* error check */
         ERRSIM_set_error(status_code,ERRSID_MATH_err_mem_alloc,"");

/* ==========================================================================
   Copy the memory in the temporary buffer
   ========================================================================== */
      switch (arrinp->atype) {
	 case MATHIE_uchar:

	    /* from unsigned char to unsigned int */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (UINTx4)(*( (UINTx1 *)arrinp->ap+i));
	    break;
	 case MATHIE_float:

	    /* from float to unsigned int */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (UINTx4)(*( (float *)arrinp->ap+i));
	    break;
	 case MATHIE_uintx4:

	    /* from unsigned integer to unsigned int */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (UINTx4)(*( (UINTx4 *)arrinp->ap+i));
	    break;
	 case MATHIE_uintx2:

	    /* from unsigned integerx2 to unsigned int */
	    for (i=0;i<arrinp->nelem;i++)
	       buff[i] = (UINTx4)(*( (UINTx2 *)arrinp->ap+i));
	    break;
	 case MATHIE_complex:

	    /* no conversion is possible */
	    ERRSIM_set_error(status_code,ERRSID_MATH_no_conv,
			     "from complex to unsigned int");
      }

/* ==========================================================================
   Free the array memory ...
   ========================================================================== */
      if ( arrinp->ap != NULL) MEMSIP_free( &(arrinp->ap) );

/* ==========================================================================
   ... and repoint to the new array
   ========================================================================== */
      arrinp->ap = buff;

/* ==========================================================================
   Changes the array descriptors
   ========================================================================== */
      arrinp->atype = MATHIE_sintx4;

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_ToUInt */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Complex

        $TYPE         PROCEDURE

        $INPUT        arrea	: the array with the real part of the complex
                                  output array
                      arima	: the array with the imaginary part of the
                                  complex output array

        $MODIFIED     NONE

        $OUTPUT       arrout	: the complex array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_no_complex

        $DESCRIPTION  This procedure makes a complex array with the real and
                      the imaginary part equals to that given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Complex
                        (/*IN    */ float               *arrea,
                         /*IN    */ float               *arima, 
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Complex";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrout->nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Check for the output array type
   ========================================================================== */
   if ( arrout->atype != MATHIE_complex )
      ERRSIM_set_error(status_code,ERRSID_MATH_no_complex,"");

/* ==========================================================================
   Create the complex array
   ========================================================================== */
   for ( i=0; i<arrout->nelem; i++ ) {
      (((MATHIT_complex *)arrout->ap)[ i ]).rea = arrea[ i ];
      (((MATHIT_complex *)arrout->ap)[ i ]).ima = arima[ i ];
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Complex */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Conj

        $TYPE         PROCEDURE

        $INPUT        arrinp    : the array to conjugate

        $MODIFIED     NONE

        $OUTPUT       arrout	: the array conjugate

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes the complex conjugation of a complex
                      array

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Conj
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Conj";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp.nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

   if ( arrout->nelem != arrinp.nelem ) /* different number of elements */
      ERRSIM_set_error(status_code,ERRSID_MATH_arr_uncomp,
                       "different number of elements of the target array");

/* ==========================================================================
   Check the array to be complex
   ========================================================================== */
   if ( arrinp.atype != MATHIE_complex ) {

      /* copy the type ... */
      arrout->atype = arrinp.atype;

      /* ... and point to the same array */
      arrout->ap = arrinp.ap;
   }
   else {
/* ==========================================================================
   Make the conjuge
   ========================================================================== */
      for (i=0;i<arrinp.nelem;i++) {

	 /* copies the real part */
	 (((MATHIT_complex *)arrout->ap)[ i ]).rea =
	    (((MATHIT_complex *)arrinp.ap)[ i ]).rea; 

	 /* change sign to the imaginary part */
	 (((MATHIT_complex *)arrout->ap)[ i ]).ima =
	    - (((MATHIT_complex *)arrinp.ap)[ i ]).ima;
      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Conj */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Modul

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the input array

        $MODIFIED     NONE

        $OUTPUT       modul	: the array of module of each element of the 
                                  input array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure evaluates the modulus of the elemens of
                      the input array

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Modul
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ float               *modul,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Modul";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp.nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Evaluates the modulus
   ========================================================================== */
   switch ( arrinp.atype ) {
      case MATHIE_float:

         /* float input */
         for ( i=0; i<arrinp.nelem; i++ ) {
            modul[ i ] = ((float *)arrinp.ap)[ i ];
         }
      break;
      case MATHIE_uchar:

         /* unsigned char input */
         for ( i=0; i<arrinp.nelem; i++ ) {
            modul[ i ] = (float)(((UINTx1 *)arrinp.ap)[ i ]);
         }
      break;
      case MATHIE_sintx4:

         /* signed int input */
         for ( i=0; i<arrinp.nelem; i++ ) {
            modul[ i ] = (float)(((INTx4 *)arrinp.ap)[ i ]);
         }
      break;
      case MATHIE_uintx4:

         /* unsigned int input */
         for ( i=0; i<arrinp.nelem; i++ ) {
            modul[ i ] = (float)(((UINTx4 *)arrinp.ap)[ i ]);
         }
      break;
      case MATHIE_uintx2:

         /* unsigned int input */
         for ( i=0; i<arrinp.nelem; i++ ) {
            modul[ i ] = (float)(((UINTx2 *)arrinp.ap)[ i ]);
         }
      break;
      case MATHIE_complex:

         /* complex input */
         for ( i=0; i<arrinp.nelem; i++ ) {
            modul[ i ] = (float)
               (sqrt ( POW ( (((MATHIT_complex *)arrinp.ap)[ i ]).rea, 2. ) +
                      POW ( (((MATHIT_complex *)arrinp.ap)[ i ]).ima, 2. ) ));
         }
      break;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* MATHIP_VECT_Modul */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Real

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the input array

        $MODIFIED     NONE

        $OUTPUT       rearr	: the array with the real part of the elements
                                  of the input one

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure evaluates the real part of the array 
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Real
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ float               *rearr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Real";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp.nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Make the extraction of the real part
   ========================================================================== */
   switch (arrinp.atype) {
      case MATHIE_float:

         /* float input */
         for (i=0;i<arrinp.nelem;i++)
            rearr[i] = *( (float *)arrinp.ap+i);
         break;
      case MATHIE_uchar:

         /* unsigned char input */
         for (i=0;i<arrinp.nelem;i++)
            rearr[i] = (float)(*( (UINTx1 *)arrinp.ap+i));
         break;
      case MATHIE_sintx4:

         /* signed int input */
         for (i=0;i<arrinp.nelem;i++)
            rearr[i] = (float)(*( (INTx4 *)arrinp.ap+i));
         break;
      case MATHIE_uintx4:

         /* unsigned int input */
         for (i=0;i<arrinp.nelem;i++)
            rearr[i] = (float)(*( (UINTx4 *)arrinp.ap+i));
         break;
      case MATHIE_uintx2:

         /* unsigned int input */
         for (i=0;i<arrinp.nelem;i++)
            rearr[i] = (float)(*( (UINTx2 *)arrinp.ap+i));
         break;
      case MATHIE_complex:

         /* complex input */
         for ( i=0; i<arrinp.nelem; i++ ) {
            rearr[ i ] = (((MATHIT_complex *)arrinp.ap)[ i ]).rea;
         }
         break;
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Real */




/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Imaginary

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the input array

        $MODIFIED     NONE

        $OUTPUT       rearr	: the array with the imaginary part of the 
                                  elements of the input one

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure evaluates the imaginary part of the array 
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Imaginary
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ float               *imarr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Imaginary";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp.nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Make the extraction of the imaginary part
   ========================================================================== */
   if ( arrinp.atype == MATHIE_complex ) {

      /* complex array */
      for ( i=0; i<arrinp.nelem; i++ ) {
         imarr[ i ] = (((MATHIT_complex *)arrinp.ap)[ i ]).ima;
      }
   }
   else {

      /* real array: zeroes the output */
      memset ( (void *)imarr, '\0', (size_t)(arrinp.nelem *
               sizeof (MATHIT_complex)) );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Imaginary */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Phase

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the input array

        $MODIFIED     NONE

        $OUTPUT       phase	: the array with the phase of the elements
                                  of the input array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure evaluates the phase of the elements of
                      the array given in input. The phase is defined in the
                      range - pi , + pi

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_Phase
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ double              *phase,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Phase";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check for the number of elements
   ========================================================================== */
   if ( arrinp.nelem < 1 )    /* no points in the array */
      ERRSIM_set_error(status_code,ERRSID_MATH_null_arr,"");

/* ==========================================================================
   Evaluate the phase
   ========================================================================== */
   if ( arrinp.atype == MATHIE_complex ) {

      /* complex array */
      for ( i=0; i<arrinp.nelem; i++ ) {
         phase[ i ] = atan2 ( (((MATHIT_complex *)arrinp.ap)[ i ]).ima,
                              (((MATHIT_complex *)arrinp.ap)[ i ]).rea );
      }
   }
   else {

      /* real array: zeroes the output */
      memset ( (void *)phase, '\0', (size_t)(arrinp.nelem *
               sizeof (MATHIT_complex)) );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_Phase */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_CTo2Float

        $TYPE         PROCEDURE

        $INPUT        inp_arr : array to cast

        $MODIFIED     NONE

        $OUTPUT       out_arr : transformed array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_wrong_type

        $DESCRIPTION  This procedure copies a complex array into a 2 float one

        $WARNING      NONE

        $PDL          - Checks if the types of array are the right ones
                      - Checks if the number of elements are compatible
                      - If they aren't compatible
                            - Set the new number of elements
                            - Re-allocates the output array
                      - Endif
                      - Loop over the elements of the input array
                            - Copies the real part
                            - Copies the imaginary part
                      - End loop

   $EH
   ========================================================================== */

void MATHIP_VECT_CTo2Float
                        (/*IN    */ MATHIT_array         inp_arr,
                         /*   OUT*/ MATHIT_array        *out_arr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_CTo2Float";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 elem;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the array type
   ========================================================================== */
   if ( inp_arr.atype != MATHIE_complex ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_wrong_type, "for the input" );
   }
   if ( out_arr->atype != MATHIE_float ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_wrong_type, "for the output");
   }

/* ==========================================================================
   Check the output array dimensions
   ========================================================================== */
   if ( out_arr->nelem < (INTx4)(2 * inp_arr.nelem) ) {
      ERRSIM_print_warning ( MATHIV_ERRS_error_message[
                                ERRSID_MATH_change_nelem ] );

/* ==========================================================================
   Re-allocate the output array
   ========================================================================== */
      MATHIP_VECT_Free ( out_arr, status_code );
      MATHIP_VECT_Make ( (INTx4)(2 * inp_arr.nelem), MATHIE_float, out_arr,
                         status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Copy the input array into the output one
   ========================================================================== */
   for ( elem=0; elem<inp_arr.nelem; elem++ ) {
      ((float *)out_arr->ap)[ 2 * elem ] =
         (((MATHIT_complex *)inp_arr.ap)[ elem ]).rea;
      ((float *)out_arr->ap)[ 2 * elem + 1 ] =
         (((MATHIT_complex *)inp_arr.ap)[ elem ]).ima;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_VECT_CTo2Float */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_2FloatToC

        $TYPE         PROCEDURE

        $INPUT        inp_arr : array to cast

        $MODIFIED     NONE

        $OUTPUT       out_arr : transformed array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_wrong_type

        $DESCRIPTION  This procedure copies a 2 float array into a complex one

        $WARNING      NONE

        $PDL          - Checks if the types of array are the right ones
                      - Checks if the number of elements are compatible
                      - If they aren't compatible
                            - Set the new number of elements
                            - Re-allocates the output array
                      - Endif
                      - Loop over the elements of the input array
                            - Copies the real part
                            - Copies the imaginary part
                      - End loop

   $EH
   ========================================================================== */

void MATHIP_VECT_2FloatToC
                        (/*IN    */ MATHIT_array         inp_arr,
                         /*   OUT*/ MATHIT_array        *out_arr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_2FloatToC";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 elem;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the array type
   ========================================================================== */
   if ( inp_arr.atype != MATHIE_float ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_wrong_type, "for the input" );
   }
   if ( out_arr->atype != MATHIE_complex ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_wrong_type, "for the output");
   }

/* ==========================================================================
   Check the output array dimensions
   ========================================================================== */
   if ( out_arr->nelem < (INTx4)(inp_arr.nelem / 2) ) {
      ERRSIM_print_warning ( MATHIV_ERRS_error_message[
                                ERRSID_MATH_change_nelem ] );

/* ==========================================================================
   Re-allocate the output array
   ========================================================================== */
      MATHIP_VECT_Free ( out_arr, status_code );
      MATHIP_VECT_Make ( (INTx4)(inp_arr.nelem / 2), MATHIE_complex, out_arr,
                         status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Copy the input array into the output one
   ========================================================================== */
   for ( elem=0; elem<out_arr->nelem; elem++ ) {
      (((MATHIT_complex *)out_arr->ap)[ elem ]).rea =
         ((float *)inp_arr.ap)[ 2 * elem ];
      (((MATHIT_complex *)out_arr->ap)[ elem ]).ima =
         ((float *)inp_arr.ap)[ 2 * elem + 1 ];
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_VECT_2FloatToC */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Exp

        $TYPE         PROCEDURE

        $INPUT        phase   : array with the phase values

        $MODIFIED     NONE

        $OUTPUT       exp_arr : array with the exponential of the phase

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp
                      ERRSID_MATH_no_complex

        $DESCRIPTION  This procedure evaluates an array with the exponential
                      of the phase given in input

        $WARNING      NONE

        $PDL          - Checks the number of elements of the two arrays
                      - Checks the output array type
                      - Loop over the phase array elements
                            - Evaluates the real part of the exponential value
                              of the phase
                            - Evaluates the imaginary  part of the exponential
                              value of the phase
                      - End loop

   $EH
   ========================================================================== */

void MATHIP_VECT_Exp
                        (/*IN    */ MATHIT_array         phase,
                         /*   OUT*/ MATHIT_array        *exp_arr,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_Exp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 elem;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Checks the number of elements of the input and output arrays
   ========================================================================== */
   if ( exp_arr->nelem  < phase.nelem ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_arr_uncomp, "" );
   }

/* ==========================================================================
   Checks the output array type
   ========================================================================== */
   if ( exp_arr->atype != MATHIE_complex ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_no_complex, "" );
   }

/* ==========================================================================
   Evaluate the exponential array
   ========================================================================== */
   for ( elem=0; elem<phase.nelem; elem++ ) {
      (((MATHIT_complex *)exp_arr->ap)[ elem ]).rea = (float)
         (cos ( (double)(((float *)phase.ap)[ elem ]) ));
      (((MATHIT_complex *)exp_arr->ap)[ elem ]).ima = (float)
         (sin ( (double)(((float *)phase.ap)[ elem ]) ));
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code,
                          &log_status_code );

}/* MATHIP_VECT_Exp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_MatrixProduct

        $TYPE         PROCEDURE

        $INPUT        arr1    : array to multiply from left
                      NRow    : Number of rows of the first matrix to
                                multiply
                      arr2    : array to multiply from rigth
                      NCol    : Number of columns of the second matrix to
                                multiply

        $MODIFIED     NONE

        $OUTPUT       arr_out : output array with the rows columns product of
                                the two 2D array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_dim
                      ERRSID_MATH_arr_uncomp
                      ERRSID_MATH_arr_undef
                      ERRSID_MATH_wrong_dim
                      ERRSID_MATH_no_suff_arr_elem

        $DESCRIPTION  This procedure evaluates the rows by columns product of
                      two matrix written as array monodimensional

        $WARNING      THE RESULT IS ALWAYS A FLOATING POINT ARRAY WITH THE
                      RESULT STORED BY ROWS SEQUENTIALLY

        $PDL          - Checks the input array
                      - Checks the consistency od the array
                      - Checks mutually consistency of input and output
                      - Evaluates the internal number of rows and columns
                      - Switches over the different input data type
                            - Makes the rows by columns products of two
                              matrices
                      - End Switch

   $EH
   ========================================================================== */

void MATHIP_VECT_MatrixProduct
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ MATHIT_array         arr2,
                         /*IN    */ INTx4                NCol,
                         /*   OUT*/ MATHIT_array        *arr_out,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_MatrixProduct";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;
   INTx4                  i;
   INTx4                  NumRow;
   INTx4                  NumCol;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the input array consistency
   ========================================================================== */
   if ( ( arr1.nelem < 1 ) || ( arr2.nelem < 1 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_null_dim, "" );
   }
   if ( arr1.atype != arr2.atype ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_arr_uncomp, "" );
   }
   if ( arr1.atype == MATHIE_undef ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_arr_undef, "" );
   }
   if ( ( ((float)arr1.nelem / NRow) - (float)((INTx4)(arr1.nelem / NRow)) ) !=
        (float)0 ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_wrong_dim,
                         "in the column direction" );
   }
   if ( ( ((float)arr2.nelem / NCol) - (float)((INTx4)(arr2.nelem / NCol)) ) !=
        (float)0 ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_wrong_dim,
                         "in the column direction" );
   }

/* ==========================================================================
   Evaluate the number of columns of the first matrix
   ========================================================================== */
   NumCol = (INTx4)(arr1.nelem / NRow);

/* ==========================================================================
   Evaluate the number of rows of the second matrix
   ========================================================================== */
   NumRow = (INTx4)(arr2.nelem / NCol);

/* ==========================================================================
   Check the number of internal dimensions
   ========================================================================== */
   if ( NumCol != NumRow ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_arr_uncomp, "" );
   }

/* ==========================================================================
   Check the output array consistency
   ========================================================================== */
   if ( arr_out->nelem < ( NRow * NCol )) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_no_suff_arr_elem,
                         "in output" );
   }
   if ( arr_out->atype == MATHIE_undef ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_arr_undef, "" );
   }

/* ==========================================================================
   Check the input output consistency
   ========================================================================== */
   if ( ( arr1.atype == MATHIE_complex ) &&
        ( arr_out->atype != MATHIE_complex ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_arr_uncomp, "" );
   }
   if ( ( arr1.atype != MATHIE_complex ) &&
        ( arr_out->atype != MATHIE_float ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_arr_uncomp, "" );
   }

/* ==========================================================================
   Make the rows times columns product
   ========================================================================== */
   switch ( arr_out->atype ) {
      case MATHIE_uchar:
         for ( row=0; row<NRow; row++ ) {
            for ( col=0; col<NCol; col++ ) {
               ((float *)arr_out->ap)[ row * NCol + col ] = 0.;
               for ( i=0; i<NumCol; i++ ) {
                  ((float *)arr_out->ap)[ row * NCol + col ] +=
                     (float)(((UINTx1 *)arr1.ap)[ row * NumCol + i ]) *
                     (float)(((UINTx1 *)arr2.ap)[ i * NCol + col ]);
               }
            }
         }
      break;
      case MATHIE_uintx2:
         for ( row=0; row<NRow; row++ ) {
            for ( col=0; col<NCol; col++ ) {
               ((float *)arr_out->ap)[ row * NCol + col ] = 0.;
               for ( i=0; i<NumCol; i++ ) {
                  ((float *)arr_out->ap)[ row * NCol + col ] +=
                     (float)(((UINTx2 *)arr1.ap)[ row * NumCol + i ]) *
                     (float)(((UINTx2 *)arr2.ap)[ i * NCol + col ]);
               }
            }
         }
      break;
      case MATHIE_uintx4:
         for ( row=0; row<NRow; row++ ) {
            for ( col=0; col<NCol; col++ ) {
               ((float *)arr_out->ap)[ row * NCol + col ] = 0.;
               for ( i=0; i<NumCol; i++ ) {
                  ((float *)arr_out->ap)[ row * NCol + col ] +=
                     (float)(((UINTx4 *)arr1.ap)[ row * NumCol + i ]) *
                     (float)(((UINTx4 *)arr2.ap)[ i * NCol + col ]);
               }
            }
         }
      break;
      case MATHIE_sintx4:
         for ( row=0; row<NRow; row++ ) {
            for ( col=0; col<NCol; col++ ) {
               ((float *)arr_out->ap)[ row * NCol + col ] = 0.;
               for ( i=0; i<NumCol; i++ ) {
                  ((float *)arr_out->ap)[ row * NCol + col ] +=
                     (float)(((INTx4 *)arr1.ap)[ row * NumCol + i ]) *
                     (float)(((INTx4 *)arr2.ap)[ i * NCol + col ]);
               }
            }
         }
      break;
      case MATHIE_float:
         for ( row=0; row<NRow; row++ ) {
            for ( col=0; col<NCol; col++ ) {
               ((float *)arr_out->ap)[ row * NCol + col ] = 0.;
               for ( i=0; i<NumCol; i++ ) {
                  ((float *)arr_out->ap)[ row * NCol + col ] +=
                     ((float *)arr1.ap)[ row * NumCol + i ] *
                     ((float *)arr2.ap)[ i * NCol + col ];
               }
            }
         }
      break;
      case MATHIE_complex: {
         MATHIT_complex  z;

         for ( row=0; row<NRow; row++ ) {
            for ( col=0; col<NCol; col++ ) {
               (((MATHIT_complex *)arr_out->ap)[ row * NCol + col ]).rea = 0.;
               (((MATHIT_complex *)arr_out->ap)[ row * NCol + col ]).ima = 0.;
               for ( i=0; i<NumCol; i++ ) {
                  MATHIP_STYP_CProd ( ((MATHIT_complex *)arr1.ap)[ row *
                                      NumCol + i ],
                                      ((MATHIT_complex *)arr2.ap)[ i * NCol +
                                      col ], &z, status_code );
                  MATHIP_STYP_CSum ( ((MATHIT_complex *)arr_out->ap)[ row *
                                     NCol + col ], z,
                                     &(((MATHIT_complex *)arr_out->ap)[ row *
                                     NCol + col ]), status_code );
                  ERRSIM_on_err_goto_exit ( *status_code );
               }
            }
         }
      }
   }

error_exit:;

   ERRSIM_close_routine( routine_name, &process_flag, *status_code, 
                         &log_status_code );

} /* MATHIP_VECT_MatrixProduct */

#ifdef SUBS
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure 

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_
                        (/*IN    */
                         /*IN OUT*/
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_VECT_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_VECT_ */
#endif
