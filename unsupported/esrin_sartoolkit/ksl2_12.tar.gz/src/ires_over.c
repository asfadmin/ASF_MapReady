/* ==========================================================================
   $MODULE_HEADER

      $NAME              IRES_OVER

      $FUNCTION          This module contains the procedures to oversample the
                         images with the FFT and the zero-padding

      $ROUTINE           IRESIP_OVER_Interpolate
                         IRESIP_OVER_DoppCentFreqEval
                         IRESIP_OVER_FdcToIndx
                         IRESIP_OVER_InterpolateRowCol
                         IRESIP_OVER_InterpolateRow
                         IRESIP_OVER_InterpolateCol
                         IRESPP_OVER_LinesInterpolate
                         IRESPP_OVER_ZeroPad
                         IRESPP_OVER_WriteLine

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       09-MAY-97     GRV       Initial Release
            SCR#16    02-DEC-97     GRV       The number of rows and columns
                                              of output cannot be lesser then
                                              the input ones
            SCR#17    02-DEC-97     GRV       The static memories allocated
                                              between the interpolation via
                                              FFT by rows and by columns are
                                              reset

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include FILS_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include SRVS_INTF_H
#include IANN_INTF_H
#include IRES_INTF_H
#include IRES_PGLB_H



/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_OVER_Interpolate

        $TYPE         PROCEDURE

        $INPUT        inp_io  	: structure with the IO parameters of the
                                  input image
                      imanum	: number identifing the image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow_inp	: number of rows of the input image
                      ncol_inp	: number of columns of the input image
                      out_io    : structure with the IO parameters of the
                                  output image
                      nrow_out	: number of rows of the output interpolated
                                  image
                      ncol_out	: number of columns of the output interpolated
                                  image
                      tmp_io    : structure with the IO parameters of the
                                  intermediate image

        $MODIFIED     The output image file is filled with the interpolated
                      image

        $OUTPUT       

        $GLOBAL       IANNID_IRES   : the flag that indicates the tool type

        $RET_STATUS   ERRSID_IRES_fact_not_good
                      ERRSID_IRES_no_undersampling
                      ERRSID_IRES_no_interp_req
                      ERRSID_IRES_start_stop_col_err
                      ERRSID_IRES_err_mem_alloc
                      ERRSID_IRES_log_vol_id_undef

        $DESCRIPTION  This procedure is the main one for the oversampling task

        $WARNING      NONE

        $PDL          - Evaluate the doppler centroide frequencies for all the
                        columns of the required subimage
                      - Transform the doppler centroide frequencies in spectrum
                        index
                      - Interpolate the image

   $EH
   ========================================================================== */
void IRESIP_OVER_Interpolate
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN OUT*/ GIOSIT_io           *tmp_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIP_OVER_Interpolate";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double                 *doppler_freq = NULL;
   UINTx4                 *index = NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow_inp > IANNIV_ImageAnnot[ imanum ].ImageLength ) ||
        ( TLCol + ncol_inp > IANNIV_ImageAnnot[ imanum ].ImageWidth ) )
      ERRSIM_set_error( status_code, ERRSID_IRES_start_stop_col_err, "" );

/* ==========================================================================
   doppler frequencies array storage allocation ...
   ========================================================================== */
   doppler_freq = (double *)
      MEMSIP_alloc( (size_t)( ncol_inp*sizeof(double) ) );
   if ( doppler_freq == NULL )
      ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc,
                       "doppler frequencies vector");

/* ==========================================================================
   ... and index array
   ========================================================================== */
   index = (UINTx4 *)
      MEMSIP_alloc( (size_t)(ncol_inp*sizeof(UINTx4)));
   if ( index == NULL )
      ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc,
                       "doppler frequencies index vector");

/* ==========================================================================
   Fill the arrays
   ========================================================================== */
   IRESIP_OVER_DoppCentFreqEval( imanum, 
                                 TLCol +
                                  IANNIV_ImageAnnot[ 0 ].SubImageTopLeftCol,
                                 TLCol +
                                  IANNIV_ImageAnnot[ 0 ].SubImageTopLeftCol +
                                 ncol_inp - 1,
                                 doppler_freq,
                                 status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   IRESIP_OVER_FdcToIndx( imanum,
                          doppler_freq,
                          ncol_inp,
                          nrow_inp,
                          index,
                          status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check the output sizes
   ========================================================================== */
   if ( nrow_out < nrow_inp ) {
      ERRSIM_set_error ( status_code, ERRSID_IRES_no_undersampling,
                         "in the row direction" );
   }
   if ( ncol_out < ncol_inp ) {
      ERRSIM_set_error ( status_code, ERRSID_IRES_no_undersampling,
                         "in the column direction" );
   }

/* ==========================================================================
   Interpolate the image
   ========================================================================== */
   if ( nrow_out > nrow_inp ) {
      if ( ncol_out > ncol_inp ) {

/* ==========================================================================
   Interpolate in the row and column directions
   ========================================================================== */
         IRESIP_OVER_InterpolateRowCol( inp_io, nrow_inp, ncol_inp,
                                        nrow_out, ncol_out, index,
                                        TLRow, TLCol,
                                        out_io, tmp_io, status_code);
         ERRSIM_on_err_goto_exit( *status_code );
      }
      else {

/* ==========================================================================
   Interpolation in the row direction
   ========================================================================== */
         IRESIP_OVER_InterpolateCol ( inp_io, nrow_inp,
                                      ncol_inp, nrow_out, 
                                      index, TLRow, TLCol,
                                      out_io, status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
   }
   else {
      if ( ncol_out > ncol_inp ) {

/* ==========================================================================
   Interpolate in the column direction
   ========================================================================== */
         IRESIP_OVER_InterpolateRow ( inp_io, nrow_inp, ncol_inp, ncol_out, 
                                      TLRow, TLCol, out_io, status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_IRES_no_interp_req,"");
      }
   }

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void *) &doppler_freq );
   MEMSIP_free( (void *) &index );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IRESIP_OVER_Interpolate */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_OVER_DoppCentFreqEval

        $TYPE         PROCEDURE

        $INPUT        imanum	: the number identified the image among all
                                  that treated in the tool
                      start_col	: the actual starting column of the image in
                                  the full resolution image
                      stop_col	: the actual last column of the image in the
                                  full resolution image

        $MODIFIED     NONE

        $OUTPUT       fdc	: the array with the doppler centroid
                                  frequencies evaluated

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_IRES_imanum_not_allow
                      ERRSID_IRES_start_stop_col_err

        $DESCRIPTION  This procedure evaluates the doppler centroid frequencies
                      of the image numerated by <imanum> for the columns indices
                      starting with start_col and ending with stop_col

        $WARNING      The column indices passed in input are in the full
                      reference frame

   $EH
   ========================================================================== */

void IRESIP_OVER_DoppCentFreqEval
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ INTx4                start_col,
                         /*IN    */ INTx4                stop_col,
                         /*   OUT*/ double              *fdc,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIP_OVER_DoppCentFreqEval";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 deg;               /* degree counter */
   double                 time;              /* acquisition time */
   UINTx4                 col;               /* columns counter */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) 
      ERRSIM_set_error( status_code, ERRSID_IRES_imanum_not_allow, "");

/* ==========================================================================
   Check the starting and ending columns
   ========================================================================== */
   if ( ( start_col < 0 ) ||
        ( stop_col < start_col ) ||
        ( stop_col >
             IANNIV_ImageAnnot[ imanum ].ImageWidth + 
             IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol ) ) {
      ERRSIM_set_error( status_code, ERRSID_IRES_start_stop_col_err, "");
   }

/* ==========================================================================
   Column loop
   ========================================================================== */
   for ( col=0; col<=stop_col-start_col; col++ ) {

/* ==========================================================================
   Apply the IPAF algorithm for the doppler frequency centroid estimation.
   Time evaluation
   ========================================================================== */
      time = 2.0 * ((double)( col + start_col ) ) *
         ( IANNIV_ImageAnnot[ imanum ].PixelSpacing_m / CVEL );

/* ==========================================================================
   Polynomial evaluation
   ========================================================================== */
      POLY( time, 2, IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec,
            fdc[ col ] );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IRESIP_OVER_DoppCentFreqEval */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_OVER_FdcToIndx

        $TYPE	      PROCEDURE

        $INPUT        imanum	: the number with which the image is identified
                                  among the others of the tool
                      fdc	: the pointer to the array with the doppler
                                  centroid frequency
                      fdc_len	: the length of the fdc array
                      fftlen	: the normalizing factor (it's the length of the
                                  array of which the FFT must be evaluated with
                                  the zero padding at the index that must be
                                  evaluated by the procedure 
                      

        $MODIFIED     NONE

        $OUTPUT       min_indx	: the array index of the spectrum at which the
                                  minimum is reached

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the global variable containing
                                                  the image annotations of the
                                                  imanum image

        $RET_STATUS   ERRSID_IRES_imanum_not_allow
                      ERRSID_IRES_zero_size_par
                      ERRSID_IRES_not_allowed_prod

        $DESCRIPTION  This procedure evaluates from the doppler centroid
                      frequency the corresponding index in the spectrum

        $WARNING      NONE

   $EH
   ========================================================================== */
void IRESIP_OVER_FdcToIndx
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ double              *fdc,
                         /*IN    */ UINTx4               fdc_len,
                         /*IN    */ UINTx4               fftlen,
                         /*   OUT*/ UINTx4              *min_indx,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIP_OVER_FdcToIndx";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   double                 prf;         /* variable to store the PRF */
   UINTx4                 col;         /* columns' counter */
   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) 
      ERRSIM_set_error( status_code, ERRSID_IRES_imanum_not_allow, "" );

/* ==========================================================================
   Check the length parameters
   ========================================================================== */
   if ( fftlen == 0 )
      ERRSIM_set_error( status_code, ERRSID_IRES_zero_size_par, "fftlen" );
   if ( fdc_len == 0 )
      ERRSIM_set_error( status_code, ERRSID_IRES_zero_size_par, "fdc_len" );

/* ==========================================================================
   Switch the product types
   ========================================================================== */
   switch ( IANNIV_ImageAnnot[ imanum ].SamplePerPixel ) {
      case 1:

/* ==========================================================================
   Real data
   ========================================================================== */
         for ( col=0; col<fdc_len; col++ )
            min_indx[ col ] = fftlen / 2;

      break;
      case 2:

/* ==========================================================================
   Complex data
   If the Fdc is outside ]-PRF/2,PRF/2[ extract the value of Fdc modulus the
   PRF, in the range ]-PRF/2,PRF/2[
   ========================================================================== */
         prf = IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz;
         for ( col=0; col<fdc_len; col++ ) {
            fdc[ col ] = ( fdc[ col ] >= 0 ) ?
               fdc[ col ] - prf * ( (INTx4)(( fdc[ col ] + prf / 2 ) / prf )) :
               fdc[ col ] - prf * ( (INTx4)(( fdc[ col ] - prf / 2 ) / prf ));

/* ==========================================================================
   Retrieve the sample index corresponding to Fdc using this scale
                  negative freq              positive freq
   Fdc:  -PRF/2 .....................   0   ...............PRF/2
   Idx:  fftlen/2 ...........fftlen-1   0   1............fftlen/2
   ========================================================================== */
            min_indx[ col ] = ( fdc[ col ] >= 0 ) ?
               (INTx4)( fdc[ col ] * fftlen / prf) :
               fftlen - 1 + (INTx4)( fdc[ col ] * fftlen / prf);

/* ==========================================================================
   Evaluate the minimum of the spectrum sample
   ========================================================================== */
            min_indx[ col ] = ( min_indx[ col ] <= (INTx4)( fftlen / 2) ) ?
               min_indx[ col ] + (INTx4)( fftlen / 2 ) :
               min_indx[ col ] - (INTx4)( fftlen / 2 );
         }
         break;
      default:

         /* undefined case */
         ERRSIM_set_error( status_code, ERRSID_IRES_not_allowed_prod, "" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IRESIP_OVER_FdcToIndx */

/* ==========================================================================
   
        $NAME         IRESIP_OVER_InterpolateRowCol

        $TYPE         PROCEDURE

        $INPUT        inp_io  	: structure with the IO parameters of the
                                  input image
                      nrow_inp	: number of rows of the input image to
                                  interpolate
                      ncol_inp	: number of columns of the input image to
                                  interpolate
                      nrow_out	: number of rows of the output interpolated
                                  image
                      ncol_out	: number of columns of the output interpolated
                                  image
                      TLRow	: the row image coordinate of the first image
                                  pixel in the full reference frame
                      TLCol	: the column image coordinate of the first image
                                  pixel in the full reference frame
                      min_indx	: array of indices of the minimum spectrum
                                  values
                      out_io    : structure with the IO parameters of the
                                  output image
                      tmp_io    : structure with the IO parameters of the
                                  intermediate image

        $MODIFIED     The output file filled with the interpolated image

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the image
                                                  annotations of the imanum
                                                  image

        $RET_STATUS   ERRSID_IRES_indx_array_empty
                      ERRSID_IRES_incorrect_rows_cols
                      ERRSID_IRES_no_undersampling
                      ERRSID_IRES_incorrect_rows_cols
                      ERRSID_IRES_err_mem_alloc
                      ERRSID_IRES_data_type_not_allow
                      ERRSID_IRES_not_allowed_prod

        $DESCRIPTION  This procedure interpolates the input image with the
                      FFT and zero-padding method

        $WARNING      The input and the output files must be only opened before
                      the calling of this procedure. The opening of the read or
                      the write mode and subsequent operations must be done in
                      the procedure

   ========================================================================== */
void IRESIP_OVER_InterpolateRowCol
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ UINTx4              *min_indx,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN OUT*/ GIOSIT_io           *tmp_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIP_OVER_InterpolateRowCol";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx1                  flag;                           /* flag for the FFT */
   UINTx1                 dc = 0;                         /* utility variable */
   UINTx4                *indx = (UINTx4 *)NULL;       /* array of the minima */
                                                          /* indices in range */
   INTx4                  i;
   MATHIT_array           arr;
   float                 *rbuff = (float *)NULL;  /* array to store real data */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the array of indices
   ========================================================================== */
   if ( min_indx == NULL )
      ERRSIM_set_error( status_code, ERRSID_IRES_indx_array_empty, "" );

/* ==========================================================================
   Check the number of rows and columns required
   ========================================================================== */
   if ( ( nrow_inp <= 1 ) || ( ncol_inp <= 1 ) )
      ERRSIM_set_error( status_code, ERRSID_IRES_incorrect_rows_cols, "" );
   if ( ( nrow_out < nrow_inp ) || ( ncol_out < ncol_out ) )
      ERRSIM_set_error( status_code, ERRSID_IRES_no_undersampling, "" );

/* ==========================================================================
   Allocates a buffer to store the real part of the output image line
   ========================================================================== */
   if ( inp_io->spp == 1 ) {
      if ( ( rbuff = (float *)
             MEMSIP_alloc ( (size_t)( nrow_out * sizeof( float )) ) ) ==
           (float *) NULL ) {
         ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc, "" );
      }
   }

/* ==========================================================================
   Open the read mode for the input file
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'y', TLRow, TLRow + nrow_inp - 1, 
                     status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open the write mode for the intermediate file
   ========================================================================== */
   GIOSIP_open_line( tmp_io, 'y', 0, nrow_out - 1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) ncol_inp+nrow_out, &log_status_code );

/* ==========================================================================
   Make the interpolation and the zero-padding by columns
   ========================================================================== */
   dc = 0;
   IRESPP_OVER_LinesInterpolate ( inp_io, TLCol, ncol_inp, nrow_inp, min_indx,
                                  dc, nrow_out, rbuff, tmp_io, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the intermediate image
   ========================================================================== */
   GIOSIP_close_line( tmp_io, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the intermediate file
   ========================================================================== */
   GIOSIP_close_io( tmp_io, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Clean up all the FFT's memories
   ========================================================================== */
   MATHIP_VECT_Make ( 1, MATHIE_complex, &arr, status_code );

   flag = -1;
   MATHIP_DFFT_1D ( arr, arr.nelem, flag, &arr, status_code );

/* ==========================================================================
   Reopen intermediate IO for reading
   ========================================================================== */
   tmp_io->mode = 'r';
   tmp_io->img = 0;
   GIOSIP_open_io( tmp_io,
                   status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the read mode of the intermediate file in the row direction
   ========================================================================== */
   GIOSIP_open_line( tmp_io, 'x', 0, ncol_inp-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the write mode of the output file in the row direction
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol_out-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Evaluate the counter to discriminate between even and odd cases
   ========================================================================== */
   if ( ncol_inp % 2 ) dc = 1;

/* ==========================================================================
   Allocate the array of indices
   ========================================================================== */
   if ( ( indx = (UINTx4 *)
           MEMSIP_alloc ( (size_t)( nrow_out * sizeof( UINTx4 ) ) ) ) ==
        (UINTx4 *) NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IRES_err_mem_alloc, "" );
   }

/* ==========================================================================
   Fill the array of indices with the half column value
   ========================================================================== */
   for ( i=0; i<nrow_out; i++ ) {
      indx[ i ] = (UINTx4) ( ncol_inp / 2 ) - 1;
   }

/* ==========================================================================
   Reallocates the buffer to store the real part of the output image line
   ========================================================================== */
   if ( inp_io->spp == 1 ) {
      if ( ( rbuff = (float *)
             MEMSIP_realloc ( (void *) rbuff,
                              (size_t)( ncol_out * sizeof( float ) ) ) ) ==
           (float *) NULL ) {
         ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc, "" );
      }
   }

/* ==========================================================================
   Interpolate by rows
   ========================================================================== */
   IRESPP_OVER_LinesInterpolate ( tmp_io, (UINTx4) 0,
                                  nrow_out, ncol_inp, indx, dc, ncol_out,
                                  rbuff, out_io, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Close the read mode of the intermediate image
   ========================================================================== */
   GIOSIP_close_line( tmp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the intermediate file
   ========================================================================== */
   GIOSIP_close_io( tmp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **) &rbuff );
   MEMSIP_free ( (void **) &indx );

/* ==========================================================================
   Clean up all the FFT's memories
   ========================================================================== */
   flag = -1;
   MATHIP_DFFT_1D ( arr, arr.nelem, flag, &arr, &log_status_code);
   MATHIP_VECT_Free ( &arr, &log_status_code);

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* IRESIP_OVER_InterpolateRowCol */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_OVER_InterpolateRow

        $TYPE         PROCEDURE

        $INPUT        inp_chan	: channel of the opened TIFF input file
                      inp_img	: number of the image in the input TIFF file
                      inp_bpar	: structure with the basic parameters of the
                                  input image
                      nrow_inp	: number of rows of the input image to
                                  interpolate
                      ncol_inp	: number of columns of the input image to
                                  interpolate
                      ncol_out	: number of columns of the output interpolated
                                  image
                      TLRow	: the row image coordinate of the first image
                                  pixel in the full reference frame
                      TLCol	: the column image coordinate of the first image
                                  pixel in the full reference frame
                      out_chan	: channel of the opened output TIFF file that
                                  will contain the interpolated output image
                      out_img	: number of the output image in the output
                                  TIFF file
                      out_bpar  : structure with the basic parameters of the
                                  output image

        $MODIFIED     The output file filled with the interpolated image

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_incorrect_rows_cols
                      ERRSID_IRES_no_undersampling
                      ERRSID_IRES_err_mem_alloc

        $DESCRIPTION  This procedure interpolates the input image with the
                      FFT and zero-padding method in the rows direction

        $WARNING      The input and the output files must be only opened before
                      the calling of this procedure. The opening of the read or
                      the write mode and subsequent operations must be done in
                      the procedure

   $EH
   ========================================================================== */

void IRESIP_OVER_InterpolateRow
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIP_OVER_InterpolateRow";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                 dc = 0;           /* even odd selector */
   INTx1                  flag;             /* flag for the FFT choice */
   float                 *rbuff = (float *)NULL;    /* buffer to contain the  */
						    /* real part of a complex */
						    /* line		      */
   UINTx4                *indx = (UINTx4 *)NULL;       /* array of the minima */
                                                          /* indices in range */
   INTx4                  i;
   MATHIT_array           arr;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the number of rows and columns required
   ========================================================================== */
   if ( ( nrow_inp == 0 ) || ( ncol_inp <= 1 ) )
      ERRSIM_set_error(status_code, ERRSID_IRES_incorrect_rows_cols,"");
   if ( ncol_out < ncol_inp )
      ERRSIM_set_error(status_code, ERRSID_IRES_no_undersampling,"");

/* ==========================================================================
   Allocates a buffer to store the real part of the output image row
   ========================================================================== */
   if ( out_io->spp == 1 ) {
      if ( ( rbuff = (float *)
                MEMSIP_alloc( (size_t)(ncol_out*sizeof(float)))) == NULL )
         ERRSIM_set_error(status_code, ERRSID_IRES_err_mem_alloc,"");
   }

/* ==========================================================================
   Open the read mode for the input file
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol+ncol_inp-1,
                     status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open the write mode of the output file in the column direction
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol_out-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Evaluate the counter to discriminate between even and odd cases
   ========================================================================== */
   if ( ncol_inp % 2 ) dc = 1;

/* ==========================================================================
   Allocate the array of indices
   ========================================================================== */
   if ( ( indx = (UINTx4 *)
           MEMSIP_alloc ( (size_t)( nrow_inp * sizeof( UINTx4 ) ) ) ) ==
        (UINTx4 *) NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IRES_err_mem_alloc, "" );
   }

/* ==========================================================================
   Fill the array of indices with the half column value
   ========================================================================== */
   for ( i=0; i<nrow_inp; i++ ) {
      indx[ i ] = (UINTx4) (ncol_inp / 2 ) - 1;
   }

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow_inp, &log_status_code );

/* ==========================================================================
   Interpolate by rows
   ========================================================================== */
   IRESPP_OVER_LinesInterpolate ( inp_io, TLRow, nrow_inp,
                                  ncol_inp, indx, dc, ncol_out, rbuff,
                                  out_io, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Free the real storing buffer
   ========================================================================== */
   MEMSIP_free( (void *) &rbuff );
   MEMSIP_free ( (void **) &indx );

/* ==========================================================================
   Clean up all the FFT's memories
   ========================================================================== */
   MATHIP_VECT_Make ( 1, MATHIE_complex, &arr, &log_status_code );

   flag = -1;
   MATHIP_DFFT_1D ( arr, arr.nelem, flag, &arr, &log_status_code );
   MATHIP_VECT_Free ( &arr, &log_status_code );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* IRESIP_OVER_InterpolateRow */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_OVER_InterpolateCol

        $TYPE         PROCEDURE


        $INPUT        inp_chan	: channel of the opened TIFF input file
                      inp_img	: number of the image in the input TIFF file
                      inp_bpar	: structure with the basic parameters of the
                                  input image
                      nrow_inp	: number of rows of the input image to
                                  interpolate
                      ncol_inp	: number of columns of the input image to
                                  interpolate
                      nrow_out	: number of rows of the output interpolated
                                  image
                      TLRow	: the row image coordinate of the first image
                                  pixel in the full reference frame
                      TLCol	: the column image coordinate of the first image
                                  pixel in the full reference frame
                      min_indx	: array of indices of the minimum spectrum
                                  values
                      out_chan	: channel of the opened output TIFF file that
                                  will contain the interpolated output image
                      out_img	: number of the output image in the output
                                  TIFF file
                      out_bpar  : structure with the basic parameters of the
                                  output image

        $MODIFIED     The output file filled with the interpolated image

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_indx_array_empty
                      ERRSID_IRES_incorrect_rows_cols
                      ERRSID_IRES_no_undersampling
                      ERRSID_IRES_err_mem_alloc

        $DESCRIPTION  This procedure interpolates the input image with the
                      FFT and zero-padding method in the columns direction

        $WARNING      The input and the output files must be only opened before
                      the calling of this procedure. The opening of the read or
                      the write mode and subsequent operations must be done in
                      the procedure

   $EH
   ========================================================================== */

void IRESIP_OVER_InterpolateCol
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4              *min_indx,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIP_OVER_InterpolateCol";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx1                  flag;             /* flag for the FFT choice */
   UINTx1                 dc = 0;                         /* utility variable */
   MATHIT_array           arr;
   float                 *rbuff = (float *)NULL;    /* buffer to contain the  */
						    /* real part of a complex */
						    /* line		      */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the array of indices
   ========================================================================== */
   if ( min_indx == NULL )
      ERRSIM_set_error(status_code, ERRSID_IRES_indx_array_empty,"");

/* ==========================================================================
   Check the number of rows and columns required
   ========================================================================== */
   if ( ( nrow_inp <= 1 ) || ( ncol_inp == 0 ) )
      ERRSIM_set_error(status_code, ERRSID_IRES_incorrect_rows_cols,"");
   if ( nrow_out < nrow_inp ) {
      ERRSIM_set_error(status_code, ERRSID_IRES_no_undersampling,"");
   }

/* ==========================================================================
   Allocates a buffer to store the real part of the output image column
   ========================================================================== */
   if ( out_io->spp == 1 ) {
      if ( ( rbuff = (float *)
                MEMSIP_alloc( (size_t)(nrow_out*sizeof(float)))) == NULL )
         ERRSIM_set_error(status_code, ERRSID_IRES_err_mem_alloc,"");
   }

/* ==========================================================================
   Open the read mode for the input file
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'y', TLRow, TLRow+nrow_inp-1,
                     status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open the write mode of the output file in the column direction
   ========================================================================== */
   GIOSIP_open_line( out_io, 'y', 0, nrow_out-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) ncol_inp, &log_status_code );

/* ==========================================================================
   Make the interpolation and the zero-padding by columns
   ========================================================================== */
   dc = 0;
   IRESPP_OVER_LinesInterpolate ( inp_io, TLCol, ncol_inp,
                                  nrow_inp, min_indx, dc, nrow_out, rbuff,
                                  out_io, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **) &rbuff );

/* ==========================================================================
   Clean up all the FFT's memories
   ========================================================================== */
   MATHIP_VECT_Make ( 1, MATHIE_complex, &arr, &log_status_code );

   flag = -1;
   MATHIP_DFFT_1D ( arr, arr.nelem, flag, &arr, &log_status_code );
   MATHIP_VECT_Free ( &arr, &log_status_code );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

/* ==========================================================================
   Free the real storing buffer
   ========================================================================== */
   MEMSIP_free( (void *) &rbuff );

}/* IRESIP_OVER_InterpolateCol */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESPP_OVER_LinesInterpolate

        $TYPE         PROCEDURE

        $INPUT        inp_chan  : channel of the input TIFF file
                      inp_img   : number identifying the input image
                      inp_bpar  : descriptor of the input image basic parameters
                      Start     : starting element of the line
                      NElements : number of elements of the line
                      NLines    : number of lines
                      min_indx  : array of the index of the minima spectra value
                      NLinesOut : number of output lines
                      rbuff     : pointer to a buffer alocated if the image is
                                  real to store the real part of the inverse
                                  FFT of the zero padded line to write
                      out_chan  : channel of the output TIFF file
                      out_img   : number identifying the output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_indx_array_empty
                      ERRSID_IRES_incorrect_rows_cols
                      ERRSID_IRES_no_undersampling

        $DESCRIPTION  This procedure evaluates the interpolation via zero
                      padding of a certain number of lines

        $WARNING      NONE

   $EH
   ========================================================================== */
void IRESPP_OVER_LinesInterpolate
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx4               Start,
                         /*IN    */ UINTx4               NLines,
                         /*IN    */ UINTx4               NElements,
                         /*IN    */ UINTx4              *min_indx,
                         /*IN    */ UINTx1               dc,
                         /*IN    */ UINTx4               NElementsOut,
                         /*IN    */ float               *rbuff,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESPP_OVER_LinesInterpolate";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 line;
   void                  *imgline = (void *) NULL;
   LDEFIT_data_type       DataType = LDEFIE_dt_undef;
   MATHIT_array           spectrum;
   MATHIT_array           spectrum_zp;
   INTx1                  flag;

   MATHIT_complex min_val, max_val;
   UINTx4 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Array initialization
   ========================================================================== */
   MATHIM_init_array( spectrum );
   MATHIM_init_array( spectrum_zp );

/* ==========================================================================
   Check the array of indices
   ========================================================================== */
   if ( min_indx == NULL )
      ERRSIM_set_error( status_code, ERRSID_IRES_indx_array_empty, "" );

/* ==========================================================================
   Check the number of rows and columns required
   ========================================================================== */
   if ( ( NElements <= 1 ) || ( NLines <= 1 ) )
      ERRSIM_set_error ( status_code, ERRSID_IRES_incorrect_rows_cols, "" );
   if ( NElementsOut < NElements )
      ERRSIM_set_error( status_code, ERRSID_IRES_no_undersampling, "" );

/* ==========================================================================
   Allocate space for the spectrum of image column and of zero-padded image
   column
   ========================================================================== */
   MATHIP_VECT_Make( NElements, MATHIE_complex, &spectrum, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   MATHIP_VECT_Make( NElementsOut, MATHIE_complex, &spectrum_zp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the type of data equal to that of input source
   ========================================================================== */
   DataType = inp_io->dt;

/* ==========================================================================
   Start the line loop
   ========================================================================== */
   for ( line=Start; line<Start+NLines; line++ ) {

      SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the line
   ========================================================================== */
      GIOSIP_read_line( inp_io, line, 0, &imgline, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the array
   ========================================================================== */
      MATHIP_VECT_FillArray ( imgline, (INTx4) NElements, DataType, &spectrum,
                              status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Make the direct FFT of the line
   ========================================================================== */
      flag = 0;
      MATHIP_DFFT_1D ( spectrum, spectrum.nelem, flag, &spectrum, status_code);
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Zero pad the line
   ========================================================================== */
      IRESPP_OVER_ZeroPad ( spectrum, spectrum.nelem, spectrum_zp.nelem,
                            min_indx[ line - Start ], dc, &spectrum_zp,
                            status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Make the inverse FFT of the zero padded line
   ========================================================================== */
      flag = 1;
      MATHIP_DFFT_1D ( spectrum_zp, spectrum_zp.nelem, flag, &spectrum_zp,
                       status_code);
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Write spectrum_zp on intermediate file
   ========================================================================== */
      IRESPP_OVER_WriteLine ( out_io,
                              (UINTx4)(line - Start), spectrum_zp, rbuff,
                              status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

/* ==========================================================================
   Deallocate the vectors memories
   ========================================================================== */
   MATHIP_VECT_Free ( &spectrum, &log_status_code );
   MATHIP_VECT_Free ( &spectrum_zp, &log_status_code );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* IRESPP_OVER_LinesInterpolate */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESPP_OVER_ZeroPad

        $TYPE         PROCEDURE

        $INPUT        inp_array    : array to zero pad
                      NElements    : number of elements of the input array
                      NElementsOut : number of elements of the output array
                                     after the zero padding
                      ind          : index of the minimum spectrum value
                      dc           : value to add at the middle spectrum

        $MODIFIED     NONE

        $OUTPUT       zp_array     : zero padded array

        $GLOBAL       NONE

        $RET_STATUS   From the called subprocedures

        $DESCRIPTION  This procedure fills a vector enlarged WRT the input one
                      with zeros at a determinated index

        $WARNING      NONE

        $PDL          - Zeroes the output vector
                      - Copies the first part of the input vector into the
                        zero padded one
                      - Copies the last part of the input vector into the
                        zero padded one

   $EH
   ========================================================================== */
void IRESPP_OVER_ZeroPad
                        (/*IN    */ MATHIT_array         inp_array,
                         /*IN    */ UINTx4               NElements,
                         /*IN    */ UINTx4               NElementsOut,
                         /*IN    */ UINTx4               ind,
                         /*IN    */ UINTx1               dc,
                         /*   OUT*/ MATHIT_array        *zp_array,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESPP_OVER_ZeroPad";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Zero the zero padded array
   ========================================================================== */
   MATHIP_VECT_SetZero ( zp_array, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   First half of the vector:
      - zp_array[ 0 : ind ] =  inp_array[ 0 : ind ]
   ========================================================================== */
   MATHIP_VECT_SubCopy ( inp_array, 0, ind + 1, zp_array, 0, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Second half of the vector:
      - zp_array[ NElementsOut-NElements + ind + dc + 1: NElementsOut - 1] =
           spectrum[ ind + dc + 1: NElements - 1 ]
   ========================================================================== */
   MATHIP_VECT_SubCopy ( inp_array, (INTx4)(ind + dc + 1),
                         (INTx4)(NElements - ind - dc - 1),
                         zp_array,
                         (INTx4)(NElementsOut - NElements + ind + dc + 1),
                         status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* IRESPP_OVER_ZeroPad */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESPP_OVER_WriteLine

        $TYPE         PROCEDURE

        $INPUT        chan    : channel of the TIFF file to fill
                      img     : image identifier
                      bpar    : basic parameters descriptor
                      ind     : index of the line to write in the output file
                      imgline : array containing the image line
                      rbuff   : pointer to a buffer alocated if the image is
                                real to store the real part of the inverse
                                FFT of the zero padded line to write

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_not_allowed_prod

        $DESCRIPTION  This procedure writes an image line in the output file
                      at the right index

        $WARNING      NONE

   $EH
   ========================================================================== */
void IRESPP_OVER_WriteLine
                        (/*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ind,
                         /*IN    */ MATHIT_array         imgline,
                         /*IN    */ float               *rbuff,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESPP_OVER_WriteLine";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Switch over the cases of output image types
   ========================================================================== */
   switch ( out_io->spp ) {
      case 1: {

/* ==========================================================================
   Copy the real part of the array
   ========================================================================== */
         MATHIP_VECT_Real ( imgline, rbuff, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Write the line
   ========================================================================== */
         GIOSIP_write_line( out_io, ind, (void *) rbuff, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
      break;
      case 2:

/* ==========================================================================
   Complex data
   ========================================================================== */
         GIOSIP_write_line( out_io, ind, (void *) imgline.ap, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      break;
      default:

/* ==========================================================================
   Data type not allowed
   ========================================================================== */
         ERRSIM_set_error ( status_code, ERRSID_IRES_not_allowed_prod, "" );
      }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* IRESPP_OVER_WriteLine */

#ifdef SUBS
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_OVER_

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure ... 

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void IRESIP_OVER_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIP_OVER_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Place the code hereinafter
   ========================================================================== */

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* IRESIP_OVER_ */
#endif
