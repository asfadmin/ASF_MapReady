/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_RSMP

      $FUNCTION          This module contains the task procedure for
                         the Sar Toolbox IMAGE RESAMPLING TOOL

      $ROUTINE           STBXPP_RSMP_oversam
                         STBXPP_RSMP_undrsam


   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       22-AUG-97     AG       Initial Release
           SCR # 21   17-DEC-97     AG       Changed computation of
                                             SubImageTopLeftRow and
                                             SubImageTopLeftCol in output image
                                             annotation of STBXPP_RSMP_undrsam

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>
#include <string.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include FILS_INTF_H
#include FIIS_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include SRVS_INTF_H
#include IANN_INTF_H
#include IRES_INTF_H
#include COOR_INTF_H
#include STBX_PGLB_H
#include STBX_INTF_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_RSMP_oversam

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_not_poly_aoi
                      ERRSID_STBX_parm_not_negative

        $DESCRIPTION  This routine executes the IMAGE OVERSAMPLING task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Open the input file
                      - Get the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of output image
                      - Initialize output file TIFF parameters
                      - Open output file
                      - Call IRESIP_OVER_Interpolate routine
		      - Update the processing history of output file
		      - Set the image annotations of the output file
                      - Close input and output files
                      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_RSMP_oversam
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_RSMP_oversam";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   INI file variables
   ========================================================================== */
   STBXPT_task             task;
   FIISIT_parm             tmpParm;
   FIISIT_parm_name        tmpParmName;
   INTx4                   i;
   INTx4                   j;
   LDEFIT_boolean	   real_aoi;

/* ==========================================================================
   Tiff variables
   ========================================================================== */
   UINTx2                  npar = 0;         /* total number of parameters */
   GIOSIT_io               inp_io;
   GIOSIT_io               tmp_io;
   GIOSIT_io               out_io;
   FILE                   *fp = (FILE *) NULL;
   char                    tag[ LDEFID_char_line ] = "";
   FILSIT_file_name        inImage, outImage, tmpImage;
   FILSIT_file_name        inImageName, outImageName;
   INTx4                   outImageSize[ 2 ];
   float                   outImageRatio[ 2 ];
   UINTx4                  ipar, outImageSizeParNo, outImageRatioParNo;
   char                    err_msg[ 256 ];

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1		   inp_ima_num = 0;
   const UINTx1		   out_ima_num = 1;

/* ==========================================================================
   algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   LDEFIT_boolean	   out_open = FALSE;


/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 4 + STBXPD_default_parm_no;
   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) outImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image_size );
   task.parm[ ipar ].type = FIISIE_tt_int;
   task.parm[ ipar ].size = sizeof( INTx4 );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value = (void *) outImageSize;
   outImageSizeParNo = ipar;
   
   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image_ratio );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value = (void *) outImageRatio;
   outImageRatioParNo = ipar;
   
/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                           status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			       status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   printf( "Input Image : %s\n", inImageName);
   printf( "Output Image : %s\n", outImageName);
   printf( "%s : ", STBXPD_output_image_size );
   for( i=0; i<task.parm[ outImageSizeParNo ].number; i++ ) {
      printf("%d ", outImageSize[ i ]);
   }
   printf("\n");
   printf( "%s : ", STBXPD_output_image_ratio );
   for( i=0; i<task.parm[ outImageRatioParNo ].number; i++ ) {
      printf("%f ", outImageRatio[ i ]);
   }
   printf("\n");
#endif

/* ==========================================================================
   Check that at least one of Output Image Size and Output Image Ratio has been
   specfied
   ========================================================================== */
   if( ( !task.parm[ outImageSizeParNo ].founded ) &&
       ( !task.parm[ outImageRatioParNo ].founded ) ) {
      sprintf( err_msg, "%s or %s", STBXPD_output_image_size,
         STBXPD_output_image_ratio );
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_defined, err_msg );
   }

   if( ( task.parm[ outImageSizeParNo ].founded ) &&
       ( task.parm[ outImageRatioParNo ].founded ) ) {
      sprintf( err_msg, "%s and %s both defined", STBXPD_output_image_size,
         STBXPD_output_image_ratio );
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, err_msg );
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );

/* ==========================================================================
   TIFF initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImage
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

/* ==========================================================================
   Open the input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
                           IANNID_IRES_OVER, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
                            task.name,
                            section_no,
                            inp_ima_num,
                           &TLRow, &TLCol, &BRRow, &BRCol,
                           &vertex_no, &vertex, 
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Polygonal AOI are not accepted
   ========================================================================== */
   if( real_aoi == TRUE ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_not_poly_aoi,
                        task.name );
   }

/* ==========================================================================
   Compute nrow_inp/ncol_inp and nrow_out/ncol_out
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

   if( task.parm[ outImageSizeParNo ].founded ) {

      if( outImageSize[ 0 ] < 0 ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_negative,
                           task.parm[ outImageSizeParNo ].name );
      }
      nrow_out = (UINTx4) outImageSize[ 0 ];

      if( task.parm[ outImageSizeParNo ].number >  1 ) {
         if( outImageSize[ 1 ] < 0 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_negative,
                              task.parm[ outImageSizeParNo ].name );
         }
         ncol_out = (UINTx4) outImageSize[ 1 ];
      }
      else {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ outImageSizeParNo ].name );
      }

   }
   else if( task.parm[ outImageRatioParNo ].founded ) {

      if( outImageRatio[ 0 ] <= 1.0 ) {
         sprintf( err_msg, "%s should be greater than 1.0",
            task.parm[ outImageRatioParNo ].name );
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_invalid,
                           err_msg );
      }
      nrow_out = (UINTx4) ROUND(((float) nrow_inp) * outImageRatio[ 0 ]);

      if( task.parm[ outImageRatioParNo ].number >  1 ) {
         if( outImageRatio[ 1 ] <= 1.0 ) {
            sprintf( err_msg, "%s should be greater than 1.0",
               task.parm[ outImageRatioParNo ].name );
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_invalid,
                              err_msg );
         }
         ncol_out = (UINTx4) ROUND(((float) ncol_inp) * outImageRatio[ 1 ]);
      }
      else {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ outImageRatioParNo ].name );
      }
      fprintf( stdout, "Computed Output Image Size: %0d, %0d\n", nrow_out,
         ncol_out );

   }


/* ==========================================================================
   Build full name of output image
   ========================================================================== */
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         ((inp_io.val.tif.bpar.sampleperpixel == 1) ?
                          LDEFIE_dt_float : LDEFIE_dt_2_float),
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters outImage   
   ========================================================================== */
   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = inp_io.val.tif.bpar.sampleperpixel;
   out_io.val.tif.bpar.bitspersample[0] = (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   if ( out_io.val.tif.bpar.sampleperpixel == 2 ) {
      out_io.val.tif.bpar.bitspersample[1] = 
         out_io.val.tif.bpar.bitspersample[0];
      out_io.val.tif.bpar.sampleformat[1] = TIFSID_float;
   }
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open the output file
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Open INTERMEDIATE file (tmpImage)
   ========================================================================== */
   if ( nrow_out > nrow_inp ) {
      if ( ncol_out > ncol_inp ) {
         STBXPP_open_temp_comp_file(  tmpImage,
                                      nrow_out, ncol_inp,
                                      'x',
                                     &tmp_io,
                                      status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
   }

/* ==========================================================================
   Call the IMAGE OVERSAMPLING TASK
   ========================================================================== */
   IRESIP_OVER_Interpolate( &inp_io,
			     inp_ima_num,
			     TLRow,
			     TLCol,
			     nrow_inp,
			     ncol_inp,
			    &out_io,
			     nrow_out,
			     ncol_out,
                           &tmp_io,
 			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength =
      out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
         IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[ 0 ] =
            out_io.val.tif.bpar.bitspersample[ 0 ];
         IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[ 0 ] =
            out_io.val.tif.bpar.sampleformat[ 0 ];
      break;
      case 2:
         IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] = 
            out_io.val.tif.bpar.bitspersample[0];
         IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
            out_io.val.tif.bpar.bitspersample[1];
         IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
            out_io.val.tif.bpar.sampleformat[0];
         IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
            out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Spacing section
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].LineSpacing_m =
      IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m / 
      ( (float) nrow_out/ nrow_inp );
   IANNIV_ImageAnnot[ out_ima_num ].PixelSpacing_m =
      IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m / 
      ( (float) ncol_out/ ncol_inp );

/* ==========================================================================
   Scale factors
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].XScalingFactor *=
      (float)ncol_out / ncol_inp;
   IANNIV_ImageAnnot[ out_ima_num ].YScalingFactor *=
      (float)nrow_out / nrow_inp;

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset */
      ROUND( ( TLRow + ((double)nrow_inp / nrow_out - 1.) / 2.)/
                IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset */
      ROUND( ( TLCol + ((double)ncol_inp / ncol_out - 1.) / 2.)/
                IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
                                  task.name,
				  "",
                                  status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot( out_io.chan,
                           out_io.img,
                           out_ima_num,
                           status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   ... and the output one
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete the intermediate file
   ========================================================================== */
   if ( nrow_out > nrow_inp ) {
      if ( ncol_out > ncol_inp ) {
         FILSIP_delete( tmpImage, &log_status_code );
      }
   }

/* ==========================================================================
   Close and delete the output file if an error occurs
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_RSMP_oversam */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_RSMP_undrsam

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_not_poly_aoi
                      ERRSID_STBX_parm_not_negative

        $DESCRIPTION  This routine executes the IMAGE UNDERSAMPLING task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Open the input file
                      - Get the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of output image
                      - Initialize output file TIFF parameters
                      - Open output file
                      - Call IRESIP_UNDR_Interpolate routine
		      - Update the processing history of output file
		      - Set the image annotations of the output file
                      - Close input and output files
                      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_RSMP_undrsam
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_RSMP_undrsam";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   INI file variables
   ========================================================================== */
   STBXPT_task             task;
   FIISIT_parm             tmpParm;
   FIISIT_parm_name        tmpParmName;
   INTx4                   i;
   INTx4                   j;
   LDEFIT_boolean	   real_aoi;

/* ==========================================================================
   Tiff variables
   ========================================================================== */
   UINTx2                  npar = 0;         /* total number of parameters */
   GIOSIT_io               inp_io;
   GIOSIT_io               out_io;
   FILE                   *fp = (FILE *) NULL;
   char                    tag[ LDEFID_char_line ] = "";
   FILSIT_file_name        inImage, outImage, filterFile;
   FILSIT_file_name        inImageName, outImageName, filterFileName;
   INTx4                   outImageSize[ 2 ];
   float                   outImageRatio[ 2 ];
   UINTx4                  ipar, outImageSizeParNo, outImageRatioParNo;
   char                    err_msg[ 256 ];

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1		   inp_ima_num = 0;
   const UINTx1		   out_ima_num = 1;

/* ==========================================================================
   algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   LDEFIT_boolean	   out_open = FALSE;

/* ==========================================================================
   SCR #21
   ========================================================================== */
   double                  StepR;
   double                  StepC;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 5 + STBXPD_default_parm_no;
   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) outImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image_size );
   task.parm[ ipar ].type = FIISIE_tt_int;
   task.parm[ ipar ].size = sizeof( INTx4 );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value = (void *) outImageSize;
   outImageSizeParNo = ipar;
   
   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image_ratio );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value = (void *) outImageRatio;
   outImageRatioParNo = ipar;
   
   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_filter_name );
   task.parm[ ipar ].type = FIISIE_tt_string;
   task.parm[ ipar ].size = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory = TRUE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) filterFileName;
   
/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                           status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			       status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   printf( "Input Image : %s\n", inImageName);
   printf( "Output Image : %s\n", outImageName);
   printf( "%s : ", STBXPD_output_image_size );
   for( i=0; i<task.parm[ outImageSizeParNo ].number; i++ ) {
      printf("%d ", outImageSize[ i ]);
   }
   printf("\n");
   printf( "%s : ", STBXPD_output_image_ratio );
   for( i=0; i<task.parm[ outImageRatioParNo ].number; i++ ) {
      printf("%f ", outImageRatio[ i ]);
   }
   printf("\n");
   printf( "Filter File Name : %s\n", filterFileName);
#endif

/* ==========================================================================
   Check that at least one of Output Image Size and Output Image Ratio has been
   specfied
   ========================================================================== */
   if( ( !task.parm[ outImageSizeParNo ].founded ) &&
       ( !task.parm[ outImageRatioParNo ].founded ) ) {
      sprintf( err_msg, "%s or %s", STBXPD_output_image_size,
         STBXPD_output_image_ratio );
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_defined, err_msg );
   }

   if( ( task.parm[ outImageSizeParNo ].founded ) &&
       ( task.parm[ outImageRatioParNo ].founded ) ) {
      sprintf( err_msg, "%s and %s both defined", STBXPD_output_image_size,
         STBXPD_output_image_ratio );
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid, err_msg );
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );

/* ==========================================================================
   TIFF initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters inImage
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Check if filter exists in current dir
   ========================================================================== */
   sprintf( filterFile, "%s", filterFileName );
   FILSIP_open( filterFile, "r", 0, &fp, &log_status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

/* ==========================================================================
   If the filter does not exists
   ========================================================================== */
   if( log_status_code != ERRSID_normal ) {

/* ==========================================================================
   Try in the configuration dir
   ========================================================================== */
      sprintf( filterFile, "%s%s", LDEFIV_cfg_dir, filterFileName );
      FILSIP_open( filterFile, "r", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      FILSIP_close( &fp, &log_status_code );

   }

/* ==========================================================================
   Open the input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
                           IANNID_IRES_UNDR, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
                            task.name,
                            section_no,
                            inp_ima_num,
                           &TLRow, &TLCol, &BRRow, &BRCol,
                           &vertex_no, &vertex, 
                           &real_aoi,
                            status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Polygonal AOI are not accepted
   ========================================================================== */
   if( real_aoi == TRUE ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_not_poly_aoi,
                        task.name );
   }

/* ==========================================================================
   Compute nrow_inp/ncol_inp and nrow_out/ncol_out
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

   if( task.parm[ outImageSizeParNo ].founded ) {

      if( outImageSize[ 0 ] < 0 ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_negative,
                           task.parm[ outImageSizeParNo ].name );
      }
      nrow_out = (UINTx4) outImageSize[ 0 ];

      if( task.parm[ outImageSizeParNo ].number >  1 ) {
         if( outImageSize[ 1 ] < 0 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_negative,
                              task.parm[ outImageSizeParNo ].name );
         }
         ncol_out = (UINTx4) outImageSize[ 1 ];
      }
      else {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ outImageSizeParNo ].name );
      }

   }
   else if( task.parm[ outImageRatioParNo ].founded ) {

      if( ( outImageRatio[ 0 ] <= 0.0 ) ||
          ( outImageRatio[ 0 ] >= 1.0 ) ) {
         sprintf( err_msg, "%s should be greater than 0.0 and less than 1.0",
            task.parm[ outImageRatioParNo ].name );
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_invalid,
                           err_msg );
      }
      nrow_out = (UINTx4) ROUND(((float) nrow_inp) * outImageRatio[ 0 ]);

      if( task.parm[ outImageRatioParNo ].number >  1 ) {
         if( ( outImageRatio[ 1 ] <= 0.0 ) ||
             ( outImageRatio[ 1 ] >= 1.0 ) ) {
            sprintf( err_msg, "%s should be greater than 0.0 and less than 1.0",
               task.parm[ outImageRatioParNo ].name );
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_invalid,
                              err_msg );
         }
         ncol_out = (UINTx4) ROUND(((float) ncol_inp) * outImageRatio[ 1 ]);
      }
      else {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ outImageRatioParNo ].name );
      }
      fprintf( stdout, "Computed Output Image Size: %0d, %0d\n", nrow_out,
         ncol_out );

   }

/* ==========================================================================
   Build full name of output image
   ========================================================================== */
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         ((inp_io.val.tif.bpar.sampleperpixel == 1) ?
                          LDEFIE_dt_float : LDEFIE_dt_2_float),
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters outImage
   ========================================================================== */
   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = inp_io.val.tif.bpar.sampleperpixel;
   out_io.val.tif.bpar.bitspersample[0] = (UINTx2)(sizeof(float)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
   if ( out_io.val.tif.bpar.sampleperpixel == 2 ) {
      out_io.val.tif.bpar.bitspersample[1] = 
         out_io.val.tif.bpar.bitspersample[0];
      out_io.val.tif.bpar.sampleformat[1] = TIFSID_float;
   }
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call the IMAGE UNDERSAMPLING routine
   ========================================================================== */
   IRESIP_UNDR_Interpolate( &inp_io,
			     inp_ima_num,
			     TLRow,
			     TLCol,
			     nrow_inp,
			     ncol_inp,
			    &out_io,
			     nrow_out,
			     ncol_out,
			     filterFile,
			     status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
         IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] = 
					    out_io.val.tif.bpar.bitspersample[0];
         IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
					    out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
         IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] = 
                                                  out_io.val.tif.bpar.bitspersample[0];
         IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
                                                  out_io.val.tif.bpar.bitspersample[1];
         IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
                                                  out_io.val.tif.bpar.sampleformat[0];
         IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
                                                  out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Steps evaluation
   ========================================================================== */
   StepR = (double) SRVSIM_step( nrow_inp, IRESIV_FilterSizeRow, nrow_out );
   StepC = (double) SRVSIM_step( ncol_inp, IRESIV_FilterSizeCol, ncol_out );

/* ==========================================================================
   Spacing section
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].LineSpacing_m *= (float)StepR;
   IANNIV_ImageAnnot[ out_ima_num ].PixelSpacing_m *= (float)StepC;

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND((TLRow + (float)(IRESIV_FilterSizeRow - 1)/2.0) /
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);
 
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND((TLCol + (float)(IRESIV_FilterSizeCol - 1)/2.0) /
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);


/* ==========================================================================
   Scale factors
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].YScalingFactor /= (float)StepR;
   IANNIV_ImageAnnot[ out_ima_num ].XScalingFactor /= (float)StepC;

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
                                  task.name,
				  "",
                                  status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
                            out_io.img,
                            out_ima_num,
                           status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   ... and the output one
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Close and delete the output file if an error occurs
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_RSMP_undrsam */

#ifdef __SUBS__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXIP_RSMP_

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure ... 

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void STBXIP_RSMP_
                        (/*IN    */ 
                         /*IN OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXIP_RSMP_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

} /* STBXIP_RSMP_ */
#endif
