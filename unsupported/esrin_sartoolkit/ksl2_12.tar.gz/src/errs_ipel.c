/* ==========================================================================
   $MODULE_HEADER

      $NAME         ERRS_IPEL

      $FUNCTION     Write an intialization message in the process error log

      $ROUTINE      ERRSIP_IPEL_init_proc_err_log

      $HISTORY

                SCR NO.      DATE        INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
                N/A       07-OCT-1992       DD       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <stdlib.h>

#include "defl_libname_intf.h"
#include ERRS_INTF_H
#include ERRS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */
 
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_IPEL_init_proc_err_log

      $FUNCTION     Write an initialization message in the PROCESS ERROR LOG

      $INPUT        routine_name              : routine name

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid
                    ERRSPV_level

      $RET_STATUS   ERRSID_err_file_write_error

      $DESCRIPTION  This routine writes in the process error log an 
                    initialization string containing the routine name and the
                    start time.  This routine uses the nesting level.

      $WARNING      NONE

   $EH
   ========================================================================== */
   void ERRSIP_IPEL_init_proc_err_log
                        ( /*IN    */ const ERRSIT_proc_name  proc_name,
                          /*   OUT*/ ERRSIT_status    *status_code )

{
   const ERRSIT_proc_name routine_name = "ERRSIP_IPEL_init_proc_err_log";

   char         date_time[25];

   *status_code = ERRSID_normal;

/* ==========================================================================
   Write a startup message.   
   ========================================================================== */
   if( ERRSPV_proc_err_log_fid != NULL )
   {

      fprintf(ERRSPV_proc_err_log_fid,"\n%03d %s Started : ",ERRSIV_level,
                                                             proc_name );

/* ==========================================================================
   Get current date and write it to the process error log.
   ========================================================================== */
      fprintf(ERRSPV_proc_err_log_fid,"%s\n", ERRSIF_LODT_out_date(date_time) );

   } /* if ERRSPV_proc_err_log_fid != NULL */

error_exit:;

}/* end ERRSIP_IPEL_init_proc_err_log */
