/* ==========================================================================
   $MODULE_HEADER

      $NAME              SPKF_AUTO

      $FUNCTION          SPECKLE FILTERING AUTOMATA IMPLEMENTATION

      $ROUTINE           SPKFIP_AUTO_select_mask
                         SPKFIP_AUTO_free

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       22-OCT-97     AN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <math.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include SPKF_INTF_H
#include SPKF_PGLB_H

/* ==========================================================================
                        GLOBAL VAR DECLARATION SECTION
   ========================================================================== */
static float                    st_outval;
#ifdef __TRACE__
static UINTx1                   st_accval;
#endif
static float                    st_RDe, st_RDl, st_RDs;
static UINTx4                   st_sel_edgline_mask_no, st_sel_edge, 
                                st_sel_scatter_mask_no;
static float                    st_cmin, st_cmax;
static float                    st_central_pixel;
static float                   *st_RDei, *st_RDli, *st_RDsi;

static float                  **st_inp_win;
static float                    st_looks_no;
static UINTx4                   st_row_size;
static UINTx4                   st_col_size;
static UINTx4                   st_mask_no;
static SPKFIT_mask             *st_mask;
static LDEFIT_boolean           first = TRUE;

/* ==========================================================================
                      LOCAL DEFINE DECLARATION SECTION
   ========================================================================== */
#define SPKFLD_infinity_float  1.0e+20
#define SPKFLD_zero_float      1.0e-10

/* ==========================================================================
                     LOCAL ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   Automata state functions prototypes
   ========================================================================== */
static SPKFPT_state SPKFLF_fun_start( void );
static SPKFPT_state SPKFLF_fun_is_uniform_0( void );
static SPKFPT_state SPKFLF_fun_is_heterogeneus( void );
static SPKFPT_state SPKFLF_fun_can_beedge_0( void );
static SPKFPT_state SPKFLF_fun_can_be_line_0( void );
static SPKFPT_state SPKFLF_fun_can_be_edge_1( void );
static SPKFPT_state SPKFLF_fun_can_be_line_1( void );
static SPKFPT_state SPKFLF_fun_edge_texture( void );
static SPKFPT_state SPKFLF_fun_line_texture( void );
static SPKFPT_state SPKFLF_fun_can_be_scat( void );
static SPKFPT_state SPKFLF_fun_is_edge( void );
static SPKFPT_state SPKFLF_fun_is_line( void );
static SPKFPT_state SPKFLF_fun_is_uniform_1( void );
static SPKFPT_state SPKFLF_fun_is_uniform_2( void );
static SPKFPT_state SPKFLF_fun_can_be_scat_2( void );
static SPKFPT_state SPKFLF_fun_can_be_scat_3( void );
static SPKFPT_state SPKFLF_fun_is_scat( void );
static SPKFPT_state SPKFLF_fun_is_scat_0( void );
static SPKFPT_state SPKFLF_fun_is_scat_1( void );
static SPKFPT_state SPKFLF_fun_is_not_scat( void );
static SPKFPT_state SPKFLF_fun_is_not_scat_0( void );
static SPKFPT_state SPKFLF_fun_is_not_scat_1( void );


static float SPKFLF_map ( /*IN    */  float               mean,
                          /*IN    */  float               sigma,
                          /*IN    */  float               looks_no,
                          /*IN    */  float               central_pixel )
{
   float               tmpFloat = 0.0, alpha, c, term;

#ifdef __TRACE__
   fprintf( stderr, "Computing map ...\n");
#endif
   if( mean < SPKFLD_zero_float ) {
      c = SPKFLD_infinity_float;
   }
   else {
      c = sigma/mean;
   }

#ifdef __OLD__
   alpha = 1/(c * c);
#endif
   alpha = (looks_no + 1)/((looks_no*c*c) - 1);
   term = alpha - looks_no - 1;
   tmpFloat = ( ( term * mean ) + 
                ( (float) sqrt((double) ( (mean*mean*term*term) + 
                                          (4*alpha*mean*looks_no*central_pixel) )
                              )
                )
              ) / ( 2 * alpha );

#ifdef __TRACE__
   fprintf( stderr, "Computed map ...\n");
#endif

   return( tmpFloat );
}

static float SPKFLF_mean( /*IN    */ float              **vect,
                          /*IN    */ UINTx4               n )
{
   float               tmpFloat = 0.0;
   REGISTER UINTx4     i;
#ifdef __TRACE__
   fprintf( stderr, "Computing mean ...\n");
#endif
   for( tmpFloat = 0.0, i=0; i<n; i++ ) {
      tmpFloat += *(vect[ i ]) ;
   }

   if( n == 0 ) {
      fprintf( stdout, "Divide by 0\n" );
      return( 0.0 );
   }
   else {
#ifdef __TRACE__
   fprintf( stderr, "Computed mean.\n");
#endif
      return( (tmpFloat/((float) n)) );
   }
}

static float SPKFLF_sigma( /*IN    */ float              **vect,
                           /*IN    */ UINTx4               n,
                           /*IN    */ float                mean )
{
   float               tmpFloat = 0.0;
   REGISTER UINTx4     i;

#ifdef __TRACE__
   fprintf( stderr, "Computing sigma ...\n");
#endif

   for( tmpFloat = 0.0, i=0; i<n; i++ ) {
      tmpFloat += (float) POW( ((double) (*(vect[ i ]) - mean)),
                               ((double) 2.0));
   }

   if( n == 1 ) {
      fprintf( stdout, "Divide by 0\n" );
      return( 0.0 );
   }
   else {
#ifdef __TRACE__
   fprintf( stderr, "Computed sigma.\n");
#endif
      return( (float) sqrt((double) (tmpFloat/((float) n-1)) ) );
   }
}

static SPKFPT_state SPKFLF_fun_start( void )
{
   SPKFPT_state new_state;
   float        c;

   st_mask[ st_mask_no - 1 ].val.all.mean =  
		  SPKFLF_mean( st_mask[ st_mask_no - 1 ].val.all.vect,
			       st_mask[ st_mask_no - 1 ].val.all.n );
/* st_mask[ st_mask_no - 1 ].val.all.mean_computed = TRUE;*/

   if( st_mask[ st_mask_no - 1 ].val.all.mean == 0.0 ) {
      st_outval = st_central_pixel;
#ifdef __TRACE__
      st_accval = 255;
#endif
      return( SPKFPE_st_end );
   }

   st_mask[ st_mask_no - 1 ].val.all.sigma = 
	   SPKFLF_sigma( st_mask[ st_mask_no - 1 ].val.all.vect,
			 st_mask[ st_mask_no - 1 ].val.all.n,
			 st_mask[ st_mask_no - 1 ].val.all.mean );
/* st_mask[ st_mask_no - 1 ].val.all.sigma_computed =TRUE;*/

   if( st_mask[ st_mask_no - 1 ].val.all.mean < SPKFLD_zero_float ) {
      c = SPKFLD_infinity_float;
   }
   else {
      c = st_mask[ st_mask_no - 1 ].val.all.sigma /
          st_mask[ st_mask_no - 1 ].val.all.mean;
   }

   st_cmin = 1/((float) sqrt((double) st_looks_no ));
#ifdef __PLAPLA__
   st_cmin *= 1.25;
#endif
   st_cmax = ((float) sqrt((double) 2.0)) * st_cmin;

   if( c < st_cmin ) {
      new_state = SPKFPE_st_is_uniform_0;
   }
   else if( c > st_cmax ) {
      new_state = SPKFPE_st_can_be_scat;
   }
   else {
      new_state = SPKFPE_st_is_heterogeneus;
   }
   return( new_state );
}

static SPKFPT_state SPKFLF_fun_is_uniform_0( void )
{
   st_outval = st_mask[ st_mask_no - 1 ].val.all.mean;
#ifdef __TRACE__
   st_accval = 0;
#endif
   return( SPKFPE_st_end );
}

static SPKFPT_state SPKFLF_fun_is_heterogeneus( void )
{
   UINTx4       i, sel_edge_mask_no, sel_line_mask_no;
   float        meanE1, meanE2, meanEB1, meanEB2,
                meanB1, meanB2, meanL, meanEB1EB2;
   SPKFPT_state new_state;

   for( i=0; i<st_mask_no-1; i++) {

      if( st_mask[ i ].type == SPKFIE_mt_edgline ) {

	 meanE1 = st_mask[ i ].val.edgline.edge1_mean =
	    SPKFLF_mean( st_mask[ i ].val.edgline.edge1,
			 st_mask[ i ].val.edgline.nedge1 );
/*	 st_mask[ i ].val.edgline.edge1_mean_computed = TRUE;*/

	 meanE2 = st_mask[ i ].val.edgline.edge2_mean =
	    SPKFLF_mean( st_mask[ i ].val.edgline.edge2,
			 st_mask[ i ].val.edgline.nedge2 );
/*	 st_mask[ i ].val.edgline.edge2_mean_computed = TRUE;*/

         meanB1 = st_mask[ i ].val.edgline.buff1_mean =
            SPKFLF_mean( st_mask[ i ].val.edgline.buff1,
                         st_mask[ i ].val.edgline.nbf1 );

         meanB2 = st_mask[ i ].val.edgline.buff2_mean =
            SPKFLF_mean( st_mask[ i ].val.edgline.buff2,
                         st_mask[ i ].val.edgline.nbf2 );

	 meanL = st_mask[ i ].val.edgline.line_mean = 
	    SPKFLF_mean( st_mask[ i ].val.edgline.line,
			 st_mask[ i ].val.edgline.nline );
/*	 st_mask[ i ].val.edgline.line_mean_computed = TRUE;*/

         meanEB1 = st_mask[ i ].val.edgline.edgbuff1_mean =
            ((meanE1*st_mask[ i ].val.edgline.nedge1) +
             (meanB1*st_mask[ i ].val.edgline.nbf1))/
            (st_mask[ i ].val.edgline.nedge1+
             st_mask[ i ].val.edgline.nbf1);
/*	 st_mask[ i ].val.edgline.edgbuff1_mean_computed = TRUE;*/

         meanEB2 = st_mask[ i ].val.edgline.edgbuff2_mean =
            ((meanE2*st_mask[ i ].val.edgline.nedge2) +
             (meanB2*st_mask[ i ].val.edgline.nbf2))/
            (st_mask[ i ].val.edgline.nedge2+
             st_mask[ i ].val.edgline.nbf2);
/*	 st_mask[ i ].val.edgline.edgbuff2_mean_computed = TRUE;*/

#ifdef __OLD__
    	 st_RDei[ i ] = MIN( meanE1/meanE2,
                             meanE2/meanE1 );
#endif
         if( (meanEB1 < SPKFLD_zero_float) && (meanEB2 < SPKFLD_zero_float) ) {
            st_RDei[ i ] = SPKFLD_infinity_float;
         }
         else if( meanEB1 < SPKFLD_zero_float ) {
            st_RDei[ i ] = meanEB1/meanEB2;
         }
         else if( meanEB2 < SPKFLD_zero_float ) {
            st_RDei[ i ] = meanEB2/meanEB1;
         }
         else {
    	    st_RDei[ i ] = MIN( meanEB1/meanEB2,
                                meanEB2/meanEB1 );
         }

	 meanEB1EB2 = 
	 ( (meanEB1 * ((float) st_mask[ i ].val.edgline.nedge1 +
                               st_mask[ i ].val.edgline.nbf1)) +
	   (meanEB2 * ((float) st_mask[ i ].val.edgline.nedge2 +
                               st_mask[ i ].val.edgline.nbf2)) ) /
	 ((float) st_mask[ i ].val.edgline.nedge1 + 
                  st_mask[ i ].val.edgline.nbf1 +
                  st_mask[ i ].val.edgline.nedge2 +
                  st_mask[ i ].val.edgline.nbf2);

         if( (meanL < SPKFLD_zero_float) && (meanEB1EB2 < SPKFLD_zero_float) ) {
            st_RDli[ i ] = SPKFLD_infinity_float;
         }
         else if( meanL < SPKFLD_zero_float ) {
            st_RDli[ i ] = meanL/meanEB1EB2;
         }
         else if( meanEB1EB2 < SPKFLD_zero_float ) {
            st_RDli[ i ] = meanEB1EB2/meanL;
         }
         else {
            st_RDli[ i ] = MIN( meanL/meanEB1EB2, meanEB1EB2/meanL );
         }

      }

   }

   st_RDe = 99999999.99999999; st_RDl = 99999999.99999999;
   sel_edge_mask_no = 10000;   sel_line_mask_no = 10000;
   for( i=0; i<st_mask_no-1; i++) {
      if( st_mask[ i ].type == SPKFIE_mt_edgline ) {
	 if( st_RDei[ i ] < st_RDe ) {
	    st_RDe = st_RDei[ i ];
	    sel_edge_mask_no = i;
	 }
	 if( st_RDli[ i ] < st_RDl ) { 
	    st_RDl = st_RDli[ i ];
	    sel_line_mask_no = i;
	 }
      }
   }

   if( st_RDe < st_RDl ) {
      new_state = SPKFPE_st_can_be_edge_0;
      st_sel_edgline_mask_no = sel_edge_mask_no;
   }
   else  {
      new_state = SPKFPE_st_can_be_line_0;
      st_sel_edgline_mask_no = sel_line_mask_no;
   }

   return( new_state );

}

static SPKFPT_state SPKFLF_fun_can_be_edge_0( void ) 
{
   SPKFPT_state new_state;

   if( st_RDe < st_mask[ 0 ].the  ) {
/* if( st_RDe < 0.82 ) { */
      new_state = SPKFPE_st_can_be_edge_1;
   }
   else {
      new_state = SPKFPE_st_edge_texture;
   }
   return( new_state );
}

static SPKFPT_state SPKFLF_fun_can_be_line_0( void )
{
   SPKFPT_state new_state;

   if( st_RDl < st_mask[ 0 ].thl  ) {
/* if( st_RDl < 0.87 ) { */
      new_state = SPKFPE_st_can_be_line_1;
   }
   else {
      new_state = SPKFPE_st_line_texture;
   }
   return( new_state );
}

static SPKFPT_state SPKFLF_fun_can_be_edge_1( void )
{
   float          Cer;
   SPKFPT_state   new_state;

   if( ABS( st_mask[ st_sel_edgline_mask_no ].val.edgline.edge1_mean -
	    st_mask[ st_sel_edgline_mask_no ].val.edgline.line_mean ) <
       ABS( st_mask[ st_sel_edgline_mask_no ].val.edgline.edge2_mean - 
	    st_mask[ st_sel_edgline_mask_no ].val.edgline.line_mean ) ) {
#ifdef __OLD__
      Cer = SPKFLF_sigma( st_mask[ st_sel_edgline_mask_no ].val.edgline.edge1,
			  st_mask[ st_sel_edgline_mask_no ].val.edgline.nedge1,
			  st_mask[ st_sel_edgline_mask_no ].val.edgline.edge1_mean ) /
	    st_mask[ st_sel_edgline_mask_no ].val.edgline.edge1_mean;
#endif
      if( st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff1_mean <
          SPKFLD_zero_float ) {
         Cer = SPKFLD_infinity_float;
      }
      else {
         Cer = SPKFLF_sigma( st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff1,
			     st_mask[ st_sel_edgline_mask_no ].val.edgline.nedgbuff1,
			     st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff1_mean ) /
	       st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff1_mean;
      }
      st_sel_edge = 1;
   }
   else {
#ifdef __OLD__
      Cer = SPKFLF_sigma( st_mask[ st_sel_edgline_mask_no ].val.edgline.edge2,
			  st_mask[ st_sel_edgline_mask_no ].val.edgline.nedge2,
			  st_mask[ st_sel_edgline_mask_no ].val.edgline.edge2_mean ) /
	    st_mask[ st_sel_edgline_mask_no ].val.edgline.edge2_mean;
#endif
      if( st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff2_mean <
          SPKFLD_zero_float ) {
         Cer = SPKFLD_infinity_float;
      }
      else {
         Cer = SPKFLF_sigma( st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff2,
			     st_mask[ st_sel_edgline_mask_no ].val.edgline.nedgbuff2,
			     st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff2_mean ) /
	       st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff2_mean;
      }
      st_sel_edge = 2;
   }
   if( Cer > st_cmax ) {
      new_state = SPKFPE_st_can_be_scat_2;
   }
   else if( Cer < st_cmin ) {
      new_state = SPKFPE_st_is_uniform_1;
   }
   else {
      new_state = SPKFPE_st_is_edge;
   }
   return( new_state );
}

static SPKFPT_state SPKFLF_fun_can_be_line_1( void )
{
   float        Clr;
   SPKFPT_state new_state;

   if( st_mask[ st_sel_edgline_mask_no ].val.edgline.line_mean <
       SPKFLD_zero_float ) {
      Clr = SPKFLD_infinity_float;
   }
   else {
      Clr = SPKFLF_sigma( st_mask[ st_sel_edgline_mask_no ].val.edgline.line,
		          st_mask[ st_sel_edgline_mask_no ].val.edgline.nline,
		          st_mask[ st_sel_edgline_mask_no ].val.edgline.line_mean ) /
	       st_mask[ st_sel_edgline_mask_no ].val.edgline.line_mean;
   }

   if( Clr > st_cmax ) {
      new_state = SPKFPE_st_can_be_scat_3;
   }
   else if( Clr < st_cmin ) {
      new_state = SPKFPE_st_is_uniform_2;
   }
   else {
      new_state = SPKFPE_st_is_line;
   }
   return( new_state );
}

static SPKFPT_state SPKFLF_fun_edge_texture( void )
{
   st_outval = SPKFLF_map( st_mask[ st_mask_no - 1].val.all.mean,
			   st_mask[ st_mask_no - 1].val.all.sigma,
			   st_looks_no,
			   st_central_pixel );
#ifdef __TRACE__
   st_accval = 20;
#endif
   return( SPKFPE_st_end );
}

static SPKFPT_state SPKFLF_fun_line_texture( void )
{
   st_outval = SPKFLF_map( st_mask[ st_mask_no - 1].val.all.mean,
			   st_mask[ st_mask_no - 1].val.all.sigma,
			   st_looks_no,
			   st_central_pixel );
#ifdef __TRACE__
   st_accval = 40;
#endif
   return( SPKFPE_st_end );
}

static SPKFPT_state SPKFLF_fun_can_be_scat( void )
{
   UINTx4       i;
   SPKFPT_state new_state;

   for( i=0; i<st_mask_no-1; i++) {
      if( st_mask[ i ].type == SPKFIE_mt_scatter ) {
	 st_mask[ i ].val.scatter.clutter_mean = 
	    SPKFLF_mean( st_mask[ i ].val.scatter.clutter,
			 st_mask[ i ].val.scatter.ncl );
/*	 st_mask[ i ].val.scatter.clutter_mean_computed = TRUE;*/
	 st_mask[ i ].val.scatter.mailobe_mean =
	    SPKFLF_mean( st_mask[ i ].val.scatter.mailobe,
			 st_mask[ i ].val.scatter.nml );

#ifdef __TRACE__
   fprintf( stderr, "mailobe_mean=%f\n", st_mask[ i ].val.scatter.mailobe_mean );
#endif

         if( st_mask[ i ].val.scatter.mailobe_mean <
             SPKFLD_zero_float ) {
            st_RDsi[ i ] = SPKFLD_infinity_float;
         }
         else {
	    st_RDsi[ i ] = st_mask[ i ].val.scatter.clutter_mean /
   	 	           st_mask[ i ].val.scatter.mailobe_mean;
         }
      }
   }

   st_RDs = 99999999.99999999;
   for( i=0; i<st_mask_no-1; i++) {
      if( st_mask[ i ].type == SPKFIE_mt_scatter ) {
	 if( st_RDsi[ i ] < st_RDs ) {
	    st_RDs = st_RDsi[ i ];
	    st_sel_scatter_mask_no = i;
	 }
      }
   }

/* if( st_RDs < 0.57 ) { */
   if( st_RDs < st_mask[ 0 ].ths) { 
      new_state = SPKFPE_st_is_scat;
   }
   else {
      new_state = SPKFPE_st_is_not_scat;
   }
   return( new_state );
}

static SPKFPT_state SPKFLF_fun_is_edge( void )
{
   float    sigma;
   if( st_sel_edge == 1) {
#ifdef __OLD__
      sigma = SPKFLF_sigma( st_mask[ st_sel_edgline_mask_no ].val.edgline.edge1,
			    st_mask[ st_sel_edgline_mask_no ].val.edgline.nedge1,
			    st_mask[ st_sel_edgline_mask_no ].val.edgline.edge1_mean );
      st_outval = SPKFLF_map( st_mask[ st_sel_edgline_mask_no ].val.edgline.edge1_mean,
			      sigma,
			      st_looks_no,
			      st_central_pixel );
#endif
      sigma = SPKFLF_sigma( st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff1,
			    st_mask[ st_sel_edgline_mask_no ].val.edgline.nedgbuff1,
			    st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff1_mean );
      st_outval = SPKFLF_map( st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff1_mean,
			      sigma,
			      st_looks_no,
			      st_central_pixel );
#ifdef __TRACE__
      st_accval = 60 + st_sel_edgline_mask_no;
#endif
   }
   else {
#ifdef __OLD__
      sigma = SPKFLF_sigma( st_mask[ st_sel_edgline_mask_no ].val.edgline.edge2,
			    st_mask[ st_sel_edgline_mask_no ].val.edgline.nedge2,
			    st_mask[ st_sel_edgline_mask_no ].val.edgline.edge2_mean );
      st_outval = SPKFLF_map( st_mask[ st_sel_edgline_mask_no ].val.edgline.edge2_mean,
			      sigma,
			      st_looks_no,
			      st_central_pixel );
#endif
      sigma = SPKFLF_sigma( st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff2,
			    st_mask[ st_sel_edgline_mask_no ].val.edgline.nedgbuff2,
			    st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff2_mean );
      st_outval = SPKFLF_map( st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff2_mean,
			      sigma,
			      st_looks_no,
			      st_central_pixel );
#ifdef __TRACE__
      st_accval = 80 + st_sel_edgline_mask_no;
#endif
   }
   return( SPKFPE_st_end );
   
}



static SPKFPT_state SPKFLF_fun_is_line( void )
{
   float    sigma;
   sigma = SPKFLF_sigma( st_mask[ st_sel_edgline_mask_no ].val.edgline.line,
			 st_mask[ st_sel_edgline_mask_no ].val.edgline.nline,
			 st_mask[ st_sel_edgline_mask_no ].val.edgline.line_mean );
   st_outval = SPKFLF_map( st_mask[ st_sel_edgline_mask_no ].val.edgline.line_mean,
			   sigma,
			   st_looks_no,
			   st_central_pixel );
#ifdef __TRACE__
   st_accval = 100 + st_sel_edgline_mask_no;
#endif
   return( SPKFPE_st_end );
}

static SPKFPT_state SPKFLF_fun_is_uniform_1( void )
{
   if( st_sel_edge == 1) {

#ifdef __OLD__
      st_outval = st_mask[ st_sel_edgline_mask_no ].val.edgline.edge1_mean;
#endif
      st_outval = st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff1_mean;
#ifdef __TRACE__
      st_accval = 120 + st_sel_edgline_mask_no;
#endif
   }
   else {
#ifdef __OLD__
      st_outval = st_mask[ st_sel_edgline_mask_no ].val.edgline.edge2_mean;
#endif
      st_outval = st_mask[ st_sel_edgline_mask_no ].val.edgline.edgbuff2_mean;
#ifdef __TRACE__
      st_accval = 140 + st_sel_edgline_mask_no;
#endif
   }
   return( SPKFPE_st_end );
}

static SPKFPT_state SPKFLF_fun_is_uniform_2( void )
{
   st_outval = st_mask[ st_sel_edgline_mask_no ].val.edgline.line_mean;
#ifdef __TRACE__
   st_accval = 160 + st_sel_edgline_mask_no;
#endif
   return( SPKFPE_st_end );
}

static SPKFPT_state SPKFLF_fun_can_be_scat_2( void )
{
   SPKFPT_state new_state;

/* if( st_RDe < 0.57 ) { */
   if( st_RDe < st_mask[ 0 ].ths) { 
      new_state = SPKFPE_st_is_scat_0;
   }
   else {
      new_state = SPKFPE_st_is_not_scat_0;
   }
   return( new_state );
}

static SPKFPT_state SPKFLF_fun_can_be_scat_3( void )
{
   SPKFPT_state new_state;

/* if( st_RDl < 0.57 ) { */
   if( st_RDl < st_mask[ 0 ].ths) { 
      new_state = SPKFPE_st_is_scat_1;
   }
   else {
      new_state = SPKFPE_st_is_not_scat_1;
   }
   return( new_state );
}


static SPKFPT_state SPKFLF_fun_is_scat( void )
{
   st_outval = st_central_pixel;
#ifdef __TRACE__
   st_accval = 180;
#endif
   return( SPKFPE_st_end );
}

static SPKFPT_state SPKFLF_fun_is_scat_0( void )
{
   st_outval = st_central_pixel;
#ifdef __TRACE__
   st_accval = 200;
#endif
   return( SPKFPE_st_end );
}

static SPKFPT_state SPKFLF_fun_is_scat_1( void )
{
   st_outval = st_central_pixel;
#ifdef __TRACE__
   st_accval = 210;
#endif
   return( SPKFPE_st_end );
}

static SPKFPT_state SPKFLF_fun_is_not_scat( void )
{
   st_outval = SPKFLF_map( st_mask[ st_mask_no - 1].val.all.mean,
                           st_mask[ st_mask_no - 1].val.all.sigma,
                           st_looks_no,
                           st_central_pixel );
#ifdef __TRACE__
   st_accval = 220;
#endif
   return( SPKFPE_st_end );
}

static SPKFPT_state SPKFLF_fun_is_not_scat_0( void )
{
   st_outval = SPKFLF_map( st_mask[ st_mask_no - 1].val.all.mean,
                           st_mask[ st_mask_no - 1].val.all.sigma,
                           st_looks_no,
                           st_central_pixel );
#ifdef __TRACE__
   st_accval = 230;
#endif
   return( SPKFPE_st_end );
}


static SPKFPT_state SPKFLF_fun_is_not_scat_1( void )
{
   st_outval = SPKFLF_map( st_mask[ st_mask_no - 1].val.all.mean,
			   st_mask[ st_mask_no - 1].val.all.sigma,
			   st_looks_no,
			   st_central_pixel );
#ifdef __TRACE__
   st_accval = 240;
#endif
   return( SPKFPE_st_end );
}

#ifndef __SGI__
/* ==========================================================================
   State Transition global variable
   ========================================================================== */
static SPKFPT_state_func transition[] =  
{ SPKFLF_fun_start,
  SPKFLF_fun_is_uniform_0,
  SPKFLF_fun_is_heterogeneus,
  SPKFLF_fun_can_be_edge_0,
  SPKFLF_fun_can_be_line_0,
  SPKFLF_fun_can_be_edge_1,
  SPKFLF_fun_can_be_line_1,
  SPKFLF_fun_edge_texture,
  SPKFLF_fun_line_texture,
  SPKFLF_fun_can_be_scat,
  SPKFLF_fun_is_edge,
  SPKFLF_fun_is_line,
  SPKFLF_fun_is_uniform_1,
  SPKFLF_fun_is_uniform_2,
  SPKFLF_fun_can_be_scat_2,
  SPKFLF_fun_can_be_scat_3,
  SPKFLF_fun_is_scat,
  SPKFLF_fun_is_scat_0,
  SPKFLF_fun_is_scat_1,
  SPKFLF_fun_is_not_scat,
  SPKFLF_fun_is_not_scat_0,
  SPKFLF_fun_is_not_scat_1 };
#endif

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SPKFIP_AUTO_select_mask

        $TYPE         PROCEDURE

        $INPUT        inp_win   : image window on which to select the mask
                      row_size  : row size of the window
                      col_size  : column size of the window
                      mask      : masks descriptor
                      pfa       : PFA user's value

        $MODIFIED     NONE

        $OUTPUT       value     : output value of the inp_win with the selected
                                  mask

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_SPKF_err_mem_alloc
                      ERRSID_SPKF_err_comp_mask
                      
        $DESCRIPTION  

        $WARNING      NONE

        $PDL          - If called for the first time, init the global variables
                      - Init the global variable having the central pixel value
                      - Start the automa
                      - Returns the output value

   $EH
   ========================================================================== */
void SPKFIP_AUTO_select_mask
                      ( /*IN    */ float              **inp_win,
                        /*IN    */ UINTx4               row_size,
                        /*IN    */ UINTx4               col_size,
                        /*IN    */ UINTx4               mask_no,
                        /*IN    */ SPKFIT_mask         *mask,
                        /*IN    */ float                looks_no,
                        /*   OUT*/ float               *value,
#ifdef __TRACE__
                        /*   OUT*/ UINTx1              *acc,
#endif
                        /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "SPKFIP_AUTO_select_mask";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   SPKFPT_state           state;
   UINTx4                 i;

#ifdef __SGI__
   SPKFPT_state_func      transition[ 22 ];
   transition[ 0 ]  = &SPKFLF_fun_start;
   transition[ 1 ]  = &SPKFLF_fun_is_uniform_0;
   transition[ 2 ]  = &SPKFLF_fun_is_heterogeneus;
   transition[ 3 ]  = &SPKFLF_fun_can_be_edge_0;
   transition[ 4 ]  = &SPKFLF_fun_can_be_line_0;
   transition[ 5 ]  = &SPKFLF_fun_can_be_edge_1;
   transition[ 6 ]  = &SPKFLF_fun_can_be_line_1;
   transition[ 7 ]  = &SPKFLF_fun_edge_texture;
   transition[ 8 ]  = &SPKFLF_fun_line_texture;
   transition[ 9 ]  = &SPKFLF_fun_can_be_scat;
   transition[ 10 ] = &SPKFLF_fun_is_edge;
   transition[ 11 ] = &SPKFLF_fun_is_line;
   transition[ 12 ] = &SPKFLF_fun_is_uniform_1;
   transition[ 13 ] = &SPKFLF_fun_is_uniform_2;
   transition[ 14 ] = &SPKFLF_fun_can_be_scat_2;
   transition[ 15 ] = &SPKFLF_fun_can_be_scat_3;
   transition[ 16 ] = &SPKFLF_fun_is_scat;
   transition[ 17 ] = &SPKFLF_fun_is_scat_0;
   transition[ 18 ] = &SPKFLF_fun_is_scat_1;
   transition[ 19 ] = &SPKFLF_fun_is_not_scat;
   transition[ 20 ] = &SPKFLF_fun_is_not_scat_0;
   transition[ 21 ] = &SPKFLF_fun_is_not_scat_1;
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set global var
   ========================================================================== */
   if( first ) {
      st_inp_win = inp_win;
      st_looks_no = looks_no;
      st_row_size = row_size;
      st_col_size = col_size;
      st_mask_no = mask_no;
      st_mask = mask;
      if( (st_RDei = (float *) MEMSIP_alloc( st_mask_no * sizeof(float) )) ==
          (float *) NULL ) {
         ERRSIM_set_error( status_code, ERRSID_SPKF_err_mem_alloc, "st_RDei" );
      }
      if( (st_RDli = (float *) MEMSIP_alloc( st_mask_no * sizeof(float) )) ==
          (float *) NULL ) {
         MEMSIP_free( (void **) &st_RDei );
         ERRSIM_set_error( status_code, ERRSID_SPKF_err_mem_alloc, "st_RDli" );
      }
      if( (st_RDsi = (float *) MEMSIP_alloc( st_mask_no * sizeof(float) )) ==
          (float *) NULL ) {
         MEMSIP_free( (void **) &st_RDei );
         MEMSIP_free( (void **) &st_RDli );
         ERRSIM_set_error( status_code, ERRSID_SPKF_err_mem_alloc, "st_RDsi" );
      }
      first = FALSE;
   }

#ifdef __PLAPLA__

/* ==========================================================================
   Reset mask flags
   ========================================================================== */
   for( i=0; i<st_mask_no; i++ ) {
      switch( st_mask[ i ].type ) {
         case SPKFPE_mt_all:
            st_mask[ i ].val.all.mean_computed  = FALSE;
	    st_mask[ i ].val.all.sigma_computed = FALSE;
	    break;
	 case SPKFPE_mt_scatter:
            st_mask[ i ].val.scatter.clutter_mean_computed = FALSE;
            st_mask[ i ].val.scatter.buffer_mean_computed  = FALSE;
	    st_mask[ i ].val.scatter.mailobe_mean_computed = FALSE;
	    break;
	 case SPKFPE_mt_edgline:
            st_mask[ i ].val.edgline.edge1_mean_computed = FALSE;
            st_mask[ i ].val.edgline.edge2_mean_computed = FALSE;
            st_mask[ i ].val.edgline.buff1_mean_computed = FALSE;
            st_mask[ i ].val.edgline.buff2_mean_computed = FALSE;
            st_mask[ i ].val.edgline.line_mean_computed  = FALSE;
	    break;
      }
   }
#endif

/* ==========================================================================
   Set central pixel
   ========================================================================== */
   st_central_pixel = inp_win[ (row_size-1)/2 ][ (col_size-1)/2 ];

/* ==========================================================================
   Main loop
   ========================================================================== */
   state = SPKFPE_st_start;
   do {

#ifdef __TRACE1__
      printf("%0d \n", state);
#endif

#ifdef __OLD__
      state = (*transition[ state ])();  
#endif
      state = (transition[ state ])();  

   } while ( ( state != SPKFPE_st_end ) && ( state != SPKFPE_st_error ) );

#ifdef __TRACE1__
   printf("\n\n\n");
#endif

   if( state == SPKFPE_st_error ) {
      ERRSIM_set_error( status_code, ERRSID_SPKF_err_comp_mask, "" );
   }
   *value = st_outval;

#ifdef __TRACE__
   *acc = st_accval;
#endif

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SPKFIP_AUTO_select_mask */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SPKFIP_AUTO_free

        $TYPE         PROCEDURE

        $INPUT        NONE 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE
                      
        $DESCRIPTION  

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void SPKFIP_AUTO_free
                      ( /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "SPKFIP_AUTO_free";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Free global var
   ========================================================================== */
   MEMSIP_free((void **) &st_RDei );
   MEMSIP_free((void **) &st_RDli );
   MEMSIP_free((void **) &st_RDsi );
   first = TRUE;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* SPKFIP_AUTO_free */
