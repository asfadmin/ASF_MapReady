/* ==========================================================================
   $MODULE_HEADER

      $NAME              ERRS_HPEL

      $FUNCTION          Handle the error logging 

      $ROUTINE           

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       24-MAY-94  DD/AD/FR/AG Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#ifdef __WIN95__
#include <process.h>
#else
#include <unistd.h>
#endif

#include "defl_libname_intf.h"
#include ERRS_INTF_H
#include ERRS_PGLB_H
#if defined(__MC68K__) || defined(__POWERPC__)
#if defined(__HAVEIDL__)
#include IDLI_INTF_H
#endif
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */
#define max_reclen 256         /* Maximum number of char for flagfile line */
  

/* ==========================================================================
                        LOCAL ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSLP_dump_unique_id

      $FUNCTION     Dump

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
static void ERRSLP_dump_unique_id
                       ( /*IN    */ char             *var_string,
                         /*IN    */ ERRSIT_unique_id  variable,
                         /*IN    */ INTx4             ind )
{

   ERRSIT_status status_code;
   char temp_str[512];
   char ind_str[512];

   memset( ind_str, ' ', sizeof( ind_str ));
   ind_str[ind] = '\0';

   sprintf( temp_str, "%s%s%d", ind_str, var_string, variable );

   ERRSIP_HPEL_trace_proc_err_log(  temp_str,
                                   &status_code );

}


/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSLP_dump_proc_name

      $FUNCTION     Dump

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
static void ERRSLP_dump_proc_name
                       ( /*IN    */ char                   *var_string,
                         /*IN    */ const ERRSIT_proc_name  variable,
                         /*IN    */ INTx4                   ind )
{

   ERRSIT_status status_code;

   char temp_str[512];
   char ind_str[512];

   memset( ind_str, ' ', sizeof( ind_str ));
   ind_str[ind] = '\0';

   sprintf( temp_str, "%s%s%s", ind_str, var_string, variable );

   ERRSIP_HPEL_trace_proc_err_log(  temp_str,
                                   &status_code );


}

static void trace_in_1(const ERRSIT_proc_class  proc_class)
{
   ERRSIT_status log_status_code;
   ERRSIP_HPEL_trace_proc_err_log( "INPUT PARAMETER:",
                                   &log_status_code );
   ERRSLP_dump_proc_name( "proc_string : ", proc_class, 0 );
   ERRSIP_HPEL_trace_proc_err_log( " ", &log_status_code );
}

static void trace_out_1()
{
   ERRSIT_status log_status_code;

   ERRSIP_HPEL_trace_proc_err_log( " ",&log_status_code );
   ERRSIP_HPEL_trace_proc_err_log( "OUTPUT PARAMETER: ",
                                   &log_status_code );
   ERRSIP_HPEL_trace_proc_err_log( "NO PARAMETERS",
                                   &log_status_code );
}


static void trace_in_2( )
{
   ERRSIT_status log_status_code;

   ERRSIP_HPEL_trace_proc_err_log( "INPUT PARAMETER:", &log_status_code );
   ERRSIP_HPEL_trace_proc_err_log( "NO PARAMETERS", &log_status_code );
   ERRSIP_HPEL_trace_proc_err_log( " ", &log_status_code );
}

static void trace_out_2( ERRSIT_unique_id  unique_id )
{
   ERRSIT_status log_status_code;

   ERRSIP_HPEL_trace_proc_err_log( " ",&log_status_code );
   ERRSIP_HPEL_trace_proc_err_log( "OUTPUT PARAMETER:", &log_status_code );
   ERRSLP_dump_unique_id( "unique_id : ", unique_id, 0 );
}

static void trace_in_3( const ERRSIT_proc_class  proc_class)
{
   ERRSIT_status log_status_code;
   ERRSIP_HPEL_trace_proc_err_log( "INPUT PARAMETER:", &log_status_code );
   ERRSLP_dump_proc_name( "proc_string : ",proc_class, 0 );
   ERRSIP_HPEL_trace_proc_err_log( " ",&log_status_code );
}

static void trace_out_3()
{
   ERRSIT_status log_status_code;
   ERRSIP_HPEL_trace_proc_err_log( " ",&log_status_code );
   ERRSIP_HPEL_trace_proc_err_log( "OUTPUT PARAMETER: ", &log_status_code );
   ERRSIP_HPEL_trace_proc_err_log( "NO PARAMETERS", &log_status_code );
}

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ERRSLM_abs
                    ( (*IN    *) x )

      $DESCRIPTION  Returns the abs of _x

   $EH
   ========================================================================== */
#define ERRSLM_abs( _x ) ( (_x) > 0 ? (_x) : -(_x) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSLP_get_unique_id

      $FUNCTION     Generate an unique id  for the current process.

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       unique_id                 : unique id

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  Generates an unique id  for the current process.

      $WARNING      NONE

   $EH
   ========================================================================== */
static void ERRSLP_get_unique_id
                        (/*   OUT*/ ERRSIT_unique_id  *unique_id,
                         /*   OUT*/ ERRSIT_status     *status_code )
{
   const ERRSIT_proc_name routine_name = "ERRSLP_get_unique_id";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   time_t                 start_time;
   time_t                 curr_time;
   double                 diff_time;
   char                   numb[ 256 ];
   char                   numb5[ 6 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code     = ERRSID_normal;
   log_status_code  = ERRSID_normal;

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in_2( );
   }

/* ==========================================================================
   Initialize the utility strings
   ========================================================================== */
   memset(numb,'\0',256);
   memset(numb5,'\0',6);

/* ==========================================================================
   Compute the difference between current time and start time.
   ========================================================================== */
   start_time = (time_t) ERRSPD_start_time;
   time( &curr_time );
#ifdef __UNIX__
   diff_time = curr_time - start_time;
#endif

#ifdef __VMS__
   diff_time = difftime( curr_time, start_time );
#endif

#ifdef __WIN95__
   diff_time = difftime( curr_time, start_time );
#endif

#ifdef __DOS__
   diff_time = difftime( curr_time, start_time );
#endif

#if defined __MC68K__ || defined __POWERPC__
   diff_time =difftime( curr_time, start_time );
#endif

   *unique_id = ERRSLM_abs( (int) diff_time);

/* ==========================================================================
   Verify that the unique ID length is less than 6 char.
   ========================================================================== */
   sprintf(numb,"%u",*(unique_id));
#ifdef __VMS__
   memcpy(numb5,numb+strlen(numb)-5,5);
#else
   memcpy(numb5,numb+strlen(numb)-4,4);
   numb5[ 5 ] = '\0';
#endif
   *(unique_id) = (ERRSIT_unique_id)atol(numb5);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

}/* ERRSLP_get_unique_id */
 
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSLP_open_proc_err_log

      $FUNCTION     Open the process error log

      $INPUT        proc_err_log_dir       : directory containing the PEL
                    proc_err_log_name      : PEL name
                    proc_err_log_ext       : PEL extension

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid;
                    ERRSIV_level

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure creates a new process error log. Initialize
                    the nesing level to -1 so that the main level is always 0.
                    If there is an error opening the log file open it with a
                    default file name in the current dir.

      $WARNING      NONE

   $EH
   ========================================================================== */
static void ERRSLP_open_proc_err_log
                        (/* IN   */ char            proc_err_log_dir[256],
                         /* IN   */ char            proc_err_log_name[256],
                         /* IN   */ char            proc_err_log_ext[41],
                         /*   OUT*/ ERRSIT_status  *status_code )
{
   const ERRSIT_proc_name proc_name = "ERRSLP_open_proc_err_log";

   INTx4        i;
   char         date_time[25];
   char         proc_err_log[256];

   char         prcname[ 16 ];

#if defined(__WIN95__) || defined(__MC68K__) || defined(__POWERPC__)
   UINTx4       pid;
#else
   pid_t        pid;
#endif

   *status_code = ERRSID_normal;

/* ==========================================================================
   Initialize the nesting level to -1.
   ========================================================================== */
   ERRSIV_level = -1;

/* ==========================================================================
   Create the process error log filespec.
   ========================================================================== */
   if ( ( sizeof(proc_err_log) - 1 ) <
        ( sizeof(proc_err_log_dir)                   +
          sizeof(proc_err_log_name)                  +
          sizeof(proc_err_log_ext) ))
   {
      *status_code = ERRSID_error;
      goto error_exit;
   }/* endif ( ( sizeof(ERRSIT_proc_err_log_filespec) */

   /* add the directory */
   strcpy(proc_err_log, proc_err_log_dir);

   /* add the file name */
   strcat(proc_err_log, proc_err_log_name);

   /* add the extension */
   strcat(proc_err_log, proc_err_log_ext);

/* ==========================================================================
   Open the process error log.
   ========================================================================== */
   ERRSPV_proc_err_log_fid = fopen( proc_err_log,
                                    "w" );

   if (ERRSPV_proc_err_log_fid == NULL)
   {
/* ==========================================================================
   If there were an error opening the file try using the default file name in
   the current dir.
   ========================================================================== */
      ERRSPV_proc_err_log_fid = fopen( "ERRORLOG.PEL",
                                       "w" );
      if (ERRSPV_proc_err_log_fid == NULL)
      {
         *status_code = ERRSID_error;
         goto error_exit;
      }
   }

/* ==========================================================================
   Get the PID and the process_name.
   ========================================================================== */
#if defined(__WIN95__) && defined(__CODEWARRIOR__)
   pid = 0;
#else
   pid = getpid();
#endif   
   sprintf(prcname, "MAIN PROC");

/* ==========================================================================
   Initialize the PEL.
   ========================================================================== */
   for (i=0;i<64;i++)
   {
      fprintf( ERRSPV_proc_err_log_fid,"**" );
   }

   fprintf( ERRSPV_proc_err_log_fid,"\n" );

   fprintf( ERRSPV_proc_err_log_fid,"%s Started : ",proc_err_log_name );

   fprintf( ERRSPV_proc_err_log_fid, "%s ", ERRSIF_LODT_out_date( date_time ));

   fprintf( ERRSPV_proc_err_log_fid," PID %X ",pid );
   fprintf( ERRSPV_proc_err_log_fid," proc name  %s \n",prcname );

   for ( i=0; i<64; i++ )
   {
      fprintf( ERRSPV_proc_err_log_fid, "**" );
   }

   fprintf( ERRSPV_proc_err_log_fid,"\n\n" );

   fflush( ERRSPV_proc_err_log_fid );

error_exit:;

} /* ERRSLP_open_proc_err_log */ 

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSLP_close_proc_err_log

      $FUNCTION     Close the process error log

      $INPUT        proc_name           : the process name

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid;
                    ERRSIV_level

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure closes the process error log.

      $WARNING      NONE

   $EH
   ========================================================================== */
static void ERRSLP_close_proc_err_log
                  (/*IN    */ const ERRSIT_proc_name proc_name,
                   /*   OUT*/ ERRSIT_status         *status_code )
{

   const ERRSIT_proc_name routine_name = "ERRSLP_close_proc_err_log";

   INTx4          i;
   char           date_time[25];
   ERRSIT_status  close_status;

   *status_code = ERRSID_normal;

/* ==========================================================================
   Check that the process error log has been successfully opened.
   ========================================================================== */
   if(  ERRSPV_proc_err_log_fid != NULL )
   {

/* ==========================================================================
   Write message in the process error log
   ========================================================================== */

      fprintf( ERRSPV_proc_err_log_fid,"\n" );

      for ( i=0; i<64; i++)
      {
         fprintf( ERRSPV_proc_err_log_fid,"**" );
      }

      fprintf( ERRSPV_proc_err_log_fid,"\n" );

      fprintf( ERRSPV_proc_err_log_fid,"    %s Ended : ",proc_name );

      fprintf( ERRSPV_proc_err_log_fid,"%s \n",ERRSIF_LODT_out_date(date_time));

      for ( i=0; i<64; i++ )
      {
         fprintf( ERRSPV_proc_err_log_fid,"**" );
      }

      fprintf( ERRSPV_proc_err_log_fid,"\n" );

      close_status = fclose( ERRSPV_proc_err_log_fid );

      if ( close_status != 0 )
      {
         *status_code = ERRSID_error;
         goto error_exit;
      }
   }/* if ERRSPV_proc_err_log_fid != NULL */

   ERRSIV_level = -1;

error_exit:;


} /* ERRSLP_close_proc_err_log*/

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSLP_parse

      $FUNCTION     Parse the flagfile entry

      $INPUT        buffer                    : read buffer

      $MODIFIED     NONE

      $OUTPUT       flag_struct               : flag structure

      $GLOBAL       NONE

      $RET_STATUS   ERRSID_error

      $DESCRIPTION  Perform the parse of the input string to identify the
                    routine name and relevant flag

      $WARNING      This procedure returns error status if a COMMENT LINE or
                    a incorrect line is found.

   $EH
   ========================================================================== */
static void ERRSLP_parse
                 ( /*IN    */ char               *buffer,
                   /*   OUT*/ ERRSPT_flag_struct *flag_struct,
                   /*   OUT*/ ERRSIT_status      *status_code )
{

   char          error;
   char          exit;
   char          comment;
   UINTx1        i;
   UINTx1        j;
   UINTx1        shift_register;
   char          status;

/* ==========================================================================
   Initialize variables.
   ========================================================================== */
   *status_code = ERRSID_normal;

   exit           = 0;
   status         = 0;
   error          = 0;
   comment        = 0;
   shift_register = 0x80;
   i              = 0;
   j              = 0;

   flag_struct->proc_id[0] = '\0';
   flag_struct->flag = 0;

   do
   {
      switch(status)
      {
         case 0:
         {
            if ( buffer[i] != '!' )
            {
               if ( ( buffer[i] == ' ') || (buffer[i] == 0x09 /* TAB */ ))
               {
                  i++;
               }
               else if(isprint(buffer[i]) && (buffer[i] != ' '))
               {
                  flag_struct->proc_id[j] = buffer[i];
                  i++;
                  j++;
                  status = 1;
               }
               else
               {
                  error = 1;
                  exit = 1;
               }
            }
            else
            {
               /* if the first char is a '!' it is a comment to skip */
               comment = 1;
               status = 7;
            }
            break;
         }
         case 1:
         {
            if(isprint(buffer[i]) && (buffer[i] != ' '))
            {
               flag_struct->proc_id[j] = buffer[i];
               i++;
               j++;
            }
            else if( ( buffer[i] == ' ' ) || (buffer[i] == 0x09 /* TAB */ ))
            {
               flag_struct->proc_id[j] = '\0';
               i++;
               status = 8;
            }
            else
            {
               exit = 1;
               error = 1;
            };

            break;
         }
         case 2:
         {
            if ( ( buffer[i] == ' ' ) || (buffer[i] == 0x09 /* TAB */ ))
            {
               i++;
            }
            else if ( toupper(buffer[i]) == 'O' )
            {
               i++;
               status = 3;
            }
            else if ( buffer[i] == '\0' )
            {
               error = 0;
               exit = 1;
            }
            else
            {
               exit = 1;
               error = 1;
            };

            break;
         }
         case 3:
         {
            if ( toupper(buffer[i]) == 'N' )
            {
               i++;
               status = 4;
            }
            else if ( toupper(buffer[i]) == 'F' )
            {
               i++;
               status = 5;
            }
            else
            {
               error = 1;
               exit = 1;
            };

            break;
         }
         case 4:
         {
            if ( ( buffer[i] == ' ' ) || (buffer[i] == 0x09 /* TAB */ ))
            {
               /* if there are more than 8 flag exit with error */
               if ( shift_register != 0 )
               {
                  flag_struct->flag = flag_struct->flag | shift_register;
                  shift_register = shift_register >> 1;
                  i++;
                  status = 2;
               }
               else
               {
                  error = 1;
                  exit = 1;
               }
            }
            else if ( buffer[i] == '\0' )
            {
               /* if there are more than 8 flag exit with error */
               if ( shift_register != 0 )
               {
                  status = 7;
                  flag_struct->flag = flag_struct->flag | shift_register;
                  shift_register = shift_register >> 1;
               }
               else
               {
                  error = 1;
                  exit  = 1;
               }
            }
            else
            {
               exit = 1;
               error = 1;
            };

            break;
         }
         case 5:
         {
            if ( toupper(buffer[i]) == 'F' )
            {
               i++;
               status = 6;
            }
            else
            {
               exit = 1;
               error = 1;
            };
            break;
         }
         case 6:
         {
            if ( ( buffer[i] == ' ' ) || (buffer[i] == 0x09 /* TAB */ ))
            {
               /* if there are more than 8 flag exit with error */
               if ( shift_register != 0 )
               {
                  i++;
                  shift_register = shift_register >> 1;
                  status = 2;
               }
               else
               {
                  error = 1;
                  exit = 1;
               }
            }
            else if ( buffer[i] == '\0' )
            {
               status = 7;
               shift_register = shift_register >> 1;
            }
            else
            {
               exit = 1;
               error = 1;
            };

            break;
         }
         case 7:
         {
            exit = 1;
            error = 0;
            break;
         }
         case 8:
         {
            if ( ( buffer[i] == ' ' ) || (buffer[i] == 0x09 /* TAB */ ))
            {
               i++;
            }
            else if ( toupper(buffer[i]) == 'O' )
            {
               i++;
               status = 3;
            }
            else
            {
               error = 1;
               exit = 1;
            }
            break;
         }
         default:
         {
            exit = 1;
            error = 1;
         }

      } /* switch (status) */

   }while(exit == 0);

   /* If less than 8 flag have been found, exit with error */
   if ( shift_register != 0 )
   {
      error = 1;
   }

   if (( error == 1 ) || ( comment == 1) )
   {
      if ( comment != 1 )
      {
         /* Log the error message */
      }
      *status_code = ERRSID_error;

   }
}/* end ERRSLP_parse */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSLP_get_flag

      $FUNCTION     Read the flagfile

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_global_flag

      $RET_STATUS   NONE

      $DESCRIPTION  Read the FLAGFILE file to read the selected flag setting
                    for the current proc. The red flags are inserted in a
                    global variable pointed by ERRSPV_global_flag.

                    If the ERRSPV_global_flag is NULL the FLAGFILE is empty
                    and no flag has been set.

                    This procedure is really crucial so it is quite enough
                    robust to handle difficult situations.

      $WARNING      NONE

   $EH
   ========================================================================== */
static void ERRSLP_get_flag
                 ( /*   OUT*/ ERRSIT_status *status_code )
{

   const ERRSIT_proc_name routine_name = "ERRSLP_get_flag";
   ERRSIT_status          log_status_code;

   UINTx4        str_status;
   UINTx4        i;


   char          read_char[max_reclen] = "";
   char          flagfile[ 256 ];
   INTx4         struct_no;
   FILE         *flagfile_id;

   ERRSPT_flag_struct   flag_struct;
   ERRSPT_flag_struct  *tmp_flag;

#if defined(__MC68K__) || defined(__POWERPC__)
#if defined(__HAVEIDL__)
   IDL_VPTR                     home_dir;
   char                        *home_dir_idl_var_name = "stbxhome";
   int                          ienter = 0;
#endif
#endif

   *status_code = ERRSID_normal;

/* ==========================================================================
   Reset the pointer used for the flag array, so at the first call realloc will
   act as malloc.
   ========================================================================== */
   ERRSPV_global_flag = NULL;
   tmp_flag           = NULL;

   /* Number of allocated structure is 0 */
   struct_no = 0;

/* ==========================================================================
   Open (readonly) the FLAGFILE.
   ========================================================================== */
#if defined(__UNIX__) || defined(__WIN95__) || defined(__DOS__)
   sprintf( flagfile, "%s", getenv( ERRSIC_flagfile ) );
#elif defined(__MC68K__) || defined(__POWERPC__)
#if defined(__HAVEIDL__)
   home_dir = IDL_FindNamedVariable( home_dir_idl_var_name, ienter );
   if( (home_dir != (IDL_VPTR) NULL) && (home_dir->type == IDL_TYP_STRING) ) {
      sprintf( flagfile, "%s%s%s",
               IDL_STRING_STR( &(home_dir->value.str) ), 
               ERRSID_dir_separator, ERRSIC_flagfile );
   }
   else {
      sprintf( flagfile, "%s", ERRSIC_flagfile );
   }
#else
   sprintf( flagfile, "%s", ERRSIC_flagfile );
#endif
#else
   sprintf( flagfile, "%s", ERRSIC_flagfile );
#endif

   flagfile_id = fopen( flagfile,
                        "r" );

   if (flagfile_id == NULL) {

      /* reset the status to normal before exit because an error on flagfile
         don't break the process */
      *status_code = ERRSID_normal;
      goto error_exit;
   }

/* ==========================================================================
   Read each FLAGFILE records.
   ========================================================================== */
   do
   {
      /* reset the record content */
      read_char[0] = '\0';
      i=0;
      do
      {
         read_char[i++] = getc(flagfile_id);

      }while ((read_char[i-1] != 0x0A /* LF */) &&
              ( i < max_reclen )            &&
              (!feof(flagfile_id)));

      /* if the structure of flagfile is not correct an error occour */
      if ( i >= max_reclen )
      {
         /* clear the flag array */
         ERRSIP_WPEL_write( routine_name,
                            "Error Reading FLAGFILE ",
                             status_code );

         /* reset the status to normal */
         *status_code = ERRSID_normal;

         goto error_exit;
      }

/* ==========================================================================
   Remove the last LF byte of each record.
   ========================================================================== */

      read_char[i-1] = '\0';

/* ==========================================================================
   Convert the record in a flag structure.
   ========================================================================== */

      if (!feof(flagfile_id))
      {
         ERRSLP_parse( read_char,
                      &flag_struct,
                       status_code );

/* ==========================================================================
   If the record has been correctly parsed, copy it into the global variable.
   If the flag are all OFF we skip this entry.
   ========================================================================== */
         if ((*status_code == ERRSID_normal) &&
             (flag_struct.flag > 0 ))
         {
            struct_no += 1;
            if( ERRSPV_global_flag == NULL ) {
	       tmp_flag = (ERRSPT_flag_struct *) malloc( struct_no * sizeof(ERRSPT_flag_struct));
            }
            else {
	       tmp_flag = (ERRSPT_flag_struct *) realloc( ERRSPV_global_flag,
				   struct_no * sizeof(ERRSPT_flag_struct));
            }

/* ==========================================================================
   If the new entry has not been allocated use the last entry to hold the
   terminator. The terminator must always be present so we delete an entry.
   ========================================================================== */
            if (tmp_flag == NULL)
            {
               if (ERRSPV_global_flag != NULL)
               {
                  *status_code = ERRSID_error;

                  /* the content of the last allocated record will lost and
                     last record will be the terminator */
                  ERRSPV_global_flag[struct_no-2].proc_id[0] = '\0';
                  ERRSPV_global_flag[struct_no-2].flag       = 0;

                  /* Reset the status code to normal*/
                  *status_code = ERRSID_normal;
                  goto error_exit;
               }
               else
               {
                  /* Reset the status code to normal*/
                  *status_code = ERRSID_normal;
                  goto error_exit;
               }
            }

            ERRSPV_global_flag = tmp_flag;

/* ==========================================================================
   Convert the string to uppercase
   ========================================================================== */

            strcpy(ERRSPV_global_flag[struct_no-1].proc_id,flag_struct.proc_id);
            ERRSPV_global_flag[struct_no-1].flag    = flag_struct.flag;

         } /* if *status_code == ERRSID_normal */
         /* reset the status, don't care if there were error in the flagfile */
         *status_code = ERRSID_normal;
      } /* if !feof(flagfile_id) */
   }
   while (!feof(flagfile_id));

/* ==========================================================================
   Allocate some space for a terminator.
   ========================================================================== */
   struct_no += 1;
   tmp_flag = (ERRSPT_flag_struct *) realloc( ERRSPV_global_flag,
                       struct_no * sizeof(ERRSPT_flag_struct));

/* ==========================================================================
   If the terminator has not been allocated use the last entry to hold the
   terminator. The terminator must always be present so we delete an entry.
   ========================================================================== */
   if ( ERRSPV_global_flag != NULL )
   {

      if ( tmp_flag == NULL )
      {
         *status_code = ERRSID_error;
         ERRSPV_global_flag[struct_no-2].proc_id[0] = '\0';
         ERRSPV_global_flag[struct_no-2].flag       = 0;

         /* Reset the status code to normal*/
         *status_code = ERRSID_normal;
         goto error_exit;
      }
      else /* if (tmp_flag != NULL) */
      {
         ERRSPV_global_flag = tmp_flag;

/* ==========================================================================
   If the memory has been allocated use the last entry to hold the array
   terminator (0).
   ========================================================================== */
         ERRSPV_global_flag[struct_no-1].proc_id[0] = '\0';
         ERRSPV_global_flag[struct_no-1].flag       = 0;

      }/* endelse (tmp_flag != NULL) */

   }/* endif (ERRSPV_global_flag != NULL) */

error_exit:;


   if (flagfile_id != NULL)
   {
      fclose(flagfile_id);
   }

} /* ERRSLP_get_flag */

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_HPEL_process_init

      $FUNCTION     Initialize a process

      $INPUT        Proc_class                 : Process Class xxxv_Xmmm

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure performs all initialization activities.

      $WARNING      NONE

   $EH
   ========================================================================== */
void ERRSIP_HPEL_process_init
                        ( /*IN    */ const ERRSIT_proc_class  proc_class,
                          /*   OUT*/ ERRSIT_status           *status_code )

{
   const ERRSIT_proc_name routine_name = "ERRSIP_HPEL_process_init";
   ERRSIT_unique_id             unique_id;
   ERRSIT_status                log_status_code;
   ERRSIT_flag                  process_flag;

   char                         proc_err_log_dir[256];
   char                         proc_err_log_name[256];
   char                         proc_err_log_ext[41];
   UINTx4                       i;
#if defined(__MC68K__) || defined(__POWERPC__)
#if defined(__HAVEIDL__)
   IDL_VPTR                     home_dir;
   char                        *home_dir_idl_var_name = "stbxhome";
   int                          ienter = 0;
#endif
#endif

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = ERRSID_normal;
   log_status_code = ERRSID_normal;

/* ==========================================================================
   Obtain an unique id for the process.
   ========================================================================== */
   ERRSLP_get_unique_id( &unique_id,
                          status_code );
   if ( *status_code != ERRSID_normal )
   {
       goto error_exit;
   }

/* ==========================================================================
   Define the PROCESS_ERROR_LOG file specification
   ========================================================================== */
#ifdef __VMS__
   sprintf(proc_err_log_name,"%s%c%05u", proc_class, '_', unique_id);
#else
   sprintf(proc_err_log_name,"%s%04u", proc_class, unique_id);
#endif

#ifdef __VMS__
   sprintf( proc_err_log_dir, "%s",  ERRSPD_proc_log_dir );
#elif defined(__MC68K__) || defined(__POWERPC__)
#if defined(__HAVEIDL__)
   home_dir = IDL_FindNamedVariable( home_dir_idl_var_name, ienter );
   if( (home_dir != (IDL_VPTR) NULL) && (home_dir->type == IDL_TYP_STRING) ) {
      sprintf( proc_err_log_dir, "%s%s%s%s",
               IDL_STRING_STR( &(home_dir->value.str) ), 
               ERRSID_dir_separator, ERRSPD_proc_log_dir, ERRSID_dir_separator );
   }
   else {
      sprintf( proc_err_log_dir, "%s%s%s",
               ERRSID_dir_separator, ERRSPD_proc_log_dir, ERRSID_dir_separator );
   }
#else
   sprintf( proc_err_log_dir, "%s%s%s",
            ERRSID_dir_separator, ERRSPD_proc_log_dir, ERRSID_dir_separator );
#endif
#else
   sprintf( proc_err_log_dir, "%s%s%s%s",
            getenv( ERRSID_stbxhome ), ERRSID_dir_separator,
            ERRSPD_proc_log_dir, ERRSID_dir_separator );
#endif

   sprintf( proc_err_log_ext, "%c%s", '.', "log");

/* ==========================================================================
   Open the process log.
   ========================================================================== */
   ERRSLP_open_proc_err_log( proc_err_log_dir,
                             proc_err_log_name,
                             proc_err_log_ext,
                             status_code );
   if ( *status_code != ERRSID_normal )
   {
      goto error_exit;
   }

/* ==========================================================================
   Read the flagfile. Ignore all error.
   ========================================================================== */
   ERRSLP_get_flag( status_code );
   if (*status_code != ERRSID_normal)
   {
      *status_code = ERRSID_normal;
   }

/* ==========================================================================
   Register the name of the main
   ========================================================================== */
   ERRSIV_level++;
   strcpy( ERRSIV_routine_stack[ ERRSIV_level ], proc_class );

/* ==========================================================================
   Initialize this routine (ERRSIP_HPEL_process_init)
   ========================================================================== */
   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code );

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in_1( proc_class);
   }


   if( ERRSIM_out_parms( process_flag ))
   {
      trace_out_1();
   }

   ERRSPF_GLBL_set_error( ERRSID_error );

error_exit:;

   ERRSIM_close_routine(  routine_name,
                         &process_flag,
                         *status_code,
                         &log_status_code );

} /* ERRSIP_HPEL_process_init */
 
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_HPEL_process_shutdown

      $FUNCTION     Close a process

      $INPUT        Proc_name                 : Process name

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure performs all closing activities. No
                     strong error checking is done.

      $WARNING      NONE

   $EH
   ========================================================================== */
void ERRSIP_HPEL_process_shutdown
                        ( /*IN    */ const ERRSIT_proc_class  proc_class,
                          /*   OUT*/ ERRSIT_status           *status_code )

{
   const ERRSIT_proc_name routine_name = "ERRSIP_HPEL_process_shutdown";
   ERRSIT_status                log_status_code;
   ERRSIT_flag                  process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code      = ERRSID_normal;
   log_status_code  = ERRSID_normal;

/* ==========================================================================
   Initialize this routine (ERRSIP_HPEL)
   ========================================================================== */
   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code );

   if( ERRSIM_in_parms( process_flag ))
   {
      trace_in_3( proc_class);
   }

   if( ERRSIM_out_parms ( process_flag ))
   {
      trace_out_3();
   }

   ERRSIM_close_routine(  routine_name,
                         &process_flag,
                         *status_code,
                         &log_status_code );

/* ==========================================================================
   Close the process log.
   ========================================================================== */
   ERRSLP_close_proc_err_log(  proc_class,
                              &log_status_code );

} /* ERRSIP_HPEL_process_shutdown */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_HPEL_trace_proc_err_log

      $FUNCTION     Write a string into the process error log

      $INPUT        string_parameter          : pointer to the string to print

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       ERRSPV_proc_err_log_fid;

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure writes a line into the process error log.

      $WARNING      If a single character without terminator has been passed
                    as input a runtime error may occour. If a string with
                    length > 1024 has been passed as input a message will be
                    written in the process_error_log and the string will not
                    be written.

   $EH
   ========================================================================== */
   void ERRSIP_HPEL_trace_proc_err_log
                        ( /*IN    */ char           *string_parameter,
                          /*   OUT*/ ERRSIT_status  *status_code )
{

   const ERRSIT_proc_name proc_name = "ERRSIP_HPEL_trace_proc_err_log";
   const INTx4	block_size = 70;

   INTx4        start_addr;
   INTx4        block_no;
   INTx4        i;
   INTx4        j;

   char        *last_char;
   char         saved_char;
   UINTx4       str_status;

   *status_code = ERRSID_normal;

   if ( ERRSPV_proc_err_log_fid != NULL )
   {

/* ==========================================================================
   If the string length is > 1024 then exit.
   ========================================================================== */
      if ( strlen(string_parameter) > 1024 )
      {
         fprintf(ERRSPV_proc_err_log_fid,
         "    ERROR : PARAMETER EXCEEDES 1024 CHARACTER \n");
         *status_code = ERRSID_normal;
         goto error_exit;
      }

/* ==========================================================================
   Format the output if the output strig length is greather than the block size.
   ========================================================================== */
      /* Indent of 4 */
      fprintf(ERRSPV_proc_err_log_fid,"    ");

      if (strlen(string_parameter) > block_size + 4)
      {
         i = 1;

         /* Calculate the block number to write */
         block_no = strlen(string_parameter)/block_size;

         /* Replace with '\0' and save the last char content of the
            current block to write */
         /* 4 is the indent length */
         start_addr = block_size + 4;
         saved_char = string_parameter[start_addr];
         string_parameter[start_addr] = '\0';

         /* Print the current block */
         fprintf(ERRSPV_proc_err_log_fid,"%s\n",
                 string_parameter );

         /* Replace the last char of the current block with the original content */
         string_parameter[start_addr] = saved_char;

         /* Repeat the previous operation until the last block */
         for ( i = 2; i <= block_no; i++)
         {
            saved_char = string_parameter[start_addr + block_size*(i-1)];

            string_parameter[start_addr + block_size*(i-1)] = '\0';

            fprintf(ERRSPV_proc_err_log_fid,"%s",
                    "        ");

            fprintf(ERRSPV_proc_err_log_fid,"%s\n",
                    &string_parameter[start_addr + block_size*(i-2)] );

            string_parameter[start_addr + block_size*(i-1)] = saved_char;
         }

         /* Repeat the previous operation for the remaind */
         if ( strlen(string_parameter) > block_size * block_no )
         {
            fprintf(ERRSPV_proc_err_log_fid,"%s",
                    "        ");
            fprintf(ERRSPV_proc_err_log_fid,"%s\n",
                    &string_parameter[start_addr + block_size*(i-2)] );
         }
      }
      else /* if(strlen(string_parameter) <= block_size +4 ) */
      {
         fprintf(ERRSPV_proc_err_log_fid,"%s\n", string_parameter );
      }
   }

error_exit:;

} /* ERRSIP_HPEL_trace_proc_err_log */
    
