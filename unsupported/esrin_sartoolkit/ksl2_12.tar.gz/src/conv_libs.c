/* ==========================================================================
   $MODULE_HEADER

      $NAME              CONV_LIBS

      $FUNCTION          This module contains the procedures for convert
                         image 
                      
      $ROUTINE           CONVIP_amp2pow
                         CONVIP_pow2amp
                         CONVIP_complex2amp
                         CONVIP_gaincvs
                         CONVIP_ugaincvs
                         CONVIP_sgaincvs
                         CONVIP_int2float
                         CONVIP_tiffgen
                         CONVIP_bilgen
                         CONVIP_dumpannot
                         CONVIP_impraster
                         CONVIP_lin2db

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A        21-OCT-97    RZ       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <math.h>
#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include FILS_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include SRVS_INTF_H
#include IANN_INTF_H
#include CONV_INTF_H
#include CONV_PGLB_H

/* ==========================================================================
                       LOCAL DEFINE DECLARATION SECTION
   ========================================================================== */
#define CONVLD_overflow_float  1.0e+30
#define CONVLD_underflow_float 1.0e-30

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_amp2pow

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of AMPLITUDE TO POWER convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_amp2pow
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_amp2pow";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, column;
   void                  *imgline = (void *) NULL;
   float                 *outline;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow > IANNIV_ImageAnnot[ inp_ima_num ].ImageLength ) ||
        ( TLCol + ncol > IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth ) )
      ERRSIM_set_error( status_code, ERRSID_CONV_start_stop_col_err, "" );

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
   if( (outline = (float *) MEMSIP_alloc( (size_t) ncol * 
                                                   sizeof(float) )) ==
       (float *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
   }
   
/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow, &log_status_code );

/* ==========================================================================
   Switch according to input image type
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_UINTx1:
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = (float)
                            (((UINTx1 *) imgline)[ column ]) *
                            (((UINTx1 *) imgline)[ column ]);
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_2_UINTx1:
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = (float)
                       ( (((UINTx1 *) imgline)[ 2*column ]) *
                         (((UINTx1 *) imgline)[ 2*column ]) ) +
                       ( (((UINTx1 *) imgline)[ 2*column + 1 ]) *
                         (((UINTx1 *) imgline)[ 2*column + 1 ]) );
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_UINTx2:
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = (float)
                          (((UINTx2 *) imgline)[ column ]) *
                          (((UINTx2 *) imgline)[ column ]);
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_2_INTx2:
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = (float)
                       ( (((INTx2 *) imgline)[ 2*column ]) *
                         (((INTx2 *) imgline)[ 2*column ]) ) +
                       ( (((INTx2 *) imgline)[ 2*column + 1 ]) *
                         (((INTx2 *) imgline)[ 2*column + 1 ]) );
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_float:
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = (float)
                          (((float *) imgline)[ column ]) *
                          (((float *) imgline)[ column ]);
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_2_float:
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = (float)
                       ( (((float *) imgline)[ 2*column ]) *
                         (((float *) imgline)[ 2*column ]) ) +
                       ( (((float *) imgline)[ 2*column + 1 ]) *
                         (((float *) imgline)[ 2*column + 1 ]) );
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &outline );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_amp2pow */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_pow2amp

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of POWER TO AMPLITUDE
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_pow2amp
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_pow2amp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, column;
   void                  *imgline = (void *) NULL;
   float                 *outline;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow > IANNIV_ImageAnnot[ inp_ima_num ].ImageLength ) ||
        ( TLCol + ncol > IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth ) )
      ERRSIM_set_error( status_code, ERRSID_CONV_start_stop_col_err, "" );

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
   if( (outline = (float *) MEMSIP_alloc( (size_t) ncol * 
                                                   sizeof(float) )) ==
       (float *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
   }
   
/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow, &log_status_code );

/* ==========================================================================
   Switch according to input image type
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_float:
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = (float)
                          sqrt((double) ((float *) imgline)[ column ]);
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &outline );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_pow2amp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_complex2amp

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of COMPLEX TO AMPLITUDE
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_complex2amp
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_complex2amp";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, column;
   void                  *imgline = (void *) NULL;
   float                 *outline;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow > IANNIV_ImageAnnot[ inp_ima_num ].ImageLength ) ||
        ( TLCol + ncol > IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth ) )
      ERRSIM_set_error( status_code, ERRSID_CONV_start_stop_col_err, "" );

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
   if( (outline = (float *) MEMSIP_alloc( (size_t) ncol * 
                                                   sizeof(float) )) ==
       (float *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
   }
   
/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow, &log_status_code );

/* ==========================================================================
   Switch according to input image type
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_2_float:
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = (float)
                  sqrt( ( ((double) (((float *) imgline)[ 2 * column ])) *
                          ((double) (((float *) imgline)[ 2 * column ])) ) +
                        ( ((double) (((float *) imgline)[ 2 * column + 1])) *
                          ((double) (((float *) imgline)[ 2 * column + 1])) )
                      );
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_2_INTx2:
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = (float)
                  sqrt( ( ((double) (((INTx2 *) imgline)[ 2 * column ])) *
                          ((double) (((INTx2 *) imgline)[ 2 * column ])) ) +
                        ( ((double) (((INTx2 *) imgline)[ 2 * column + 1])) *
                          ((double) (((INTx2 *) imgline)[ 2 * column + 1])) )
                      );
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &outline );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_complex2amp */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_int2float

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of INTEGER TO FLOAT
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_int2float
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_int2float";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, column;
   void                  *imgline = (void *) NULL;
   float                 *outline;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow > IANNIV_ImageAnnot[ inp_ima_num ].ImageLength ) ||
        ( TLCol + ncol > IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth ) )
      ERRSIM_set_error( status_code, ERRSID_CONV_start_stop_col_err, "" );

/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow, &log_status_code );

/* ==========================================================================
   Switch according to input image type
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_UINTx1:

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
         if( (outline = (float *) MEMSIP_alloc( (size_t) ncol * 
                                                   sizeof(float) )) ==
             (float *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
         }
   
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = 
                  (float) (((UINTx1 *) imgline)[ column ]);

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_INTx2:

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
         if( (outline = (float *) MEMSIP_alloc( (size_t) ncol * 
                                                   sizeof(float) )) ==
             (float *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
         }
   
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = 
                  (float) (((INTx2 *) imgline)[ column ]);

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_UINTx2:

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
         if( (outline = (float *) MEMSIP_alloc( (size_t) ncol * 
                                                   sizeof(float) )) ==
             (float *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
         }
   
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = 
                  (float) (((UINTx2 *) imgline)[ column ]);

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_INTx4:

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
         if( (outline = (float *) MEMSIP_alloc( (size_t) ncol * 
                                                   sizeof(float) )) ==
             (float *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
         }
   
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = 
                  (float) (((INTx4 *) imgline)[ column ]);

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_UINTx4:

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
         if( (outline = (float *) MEMSIP_alloc( (size_t) ncol * 
                                                   sizeof(float) )) ==
             (float *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
         }
   
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ column ] = 
                  (float) (((UINTx4 *) imgline)[ column ]);

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_2_UINTx1:

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
         if( (outline = (float *) MEMSIP_alloc( (size_t) 2 * ncol * 
                                                   sizeof(float) )) ==
             (float *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
         }
   
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ 2 * column ] = 
                  (float) (((UINTx1 *) imgline)[ 2 * column ]);
               outline[ 2 * column + 1 ] = 
                  (float) (((UINTx1 *) imgline)[ 2 * column + 1 ]);

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_2_INTx2:

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
         if( (outline = (float *) MEMSIP_alloc( (size_t) 2 * ncol * 
                                                   sizeof(float) )) ==
             (float *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
         }
   
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               outline[ 2 * column ] = 
                  (float) (((INTx2 *) imgline)[ 2 * column ]);
               outline[ 2 * column + 1 ] = 
                  (float) (((INTx2 *) imgline)[ 2 * column + 1 ]);

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &outline );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_int2float */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_gaincvs

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      min_perc  : minimum percentage 
                      max_perc  : maximum percentage
                      no_black  : number of black
                      no_black_found
                                : TRUE if the value of no_black has been 
                                  found in the INI file
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of GAIN convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_gaincvs
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ float                min_perc,
                         /*IN    */ float                max_perc,
                         /*IN    */ LDEFIT_boolean       no_black_found,
                         /*IN    */ float                no_black,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_gaincvs";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, column, total;
   void                  *imgline = (void *) NULL;
   UINTx1                *outline;
   UINTx4                *histo;
   double                *dhisto;
   UINTx4                 histo_range, index, i;
   INTx4                  start;
   const UINTx4           def_histo_range = 65536;
   double                 min, max, val, delta, 
                          norm, low, high;
   double                 dminperc, dmaxperc, dnorm;
   LDEFIT_boolean         min_found, max_found;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow > IANNIV_ImageAnnot[ inp_ima_num ].ImageLength ) ||
        ( TLCol + ncol > IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth ) )
      ERRSIM_set_error( status_code, ERRSID_CONV_start_stop_col_err, "" );

/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Switch according to input image to set the completion target
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_UINTx1:
      case LDEFIE_dt_INTx2:
      case LDEFIE_dt_UINTx2:

         SRVSIP_set_comp( (INTx4) 2*nrow, &log_status_code );
         break;

      case LDEFIE_dt_INTx4:
      case LDEFIE_dt_UINTx4:
      case LDEFIE_dt_float:

         SRVSIP_set_comp( (INTx4) 3*nrow, &log_status_code );
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }

/* ==========================================================================
   Switch according to input image type to find out histogram range
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_UINTx1:
/* ==========================================================================
   Set histo_range to the max value
   ========================================================================== */
         min = 0.0; max = 255.0;
         histo_range = 256;
         
         break;

      case LDEFIE_dt_INTx2:
/* ==========================================================================
   Set histo_range to the max value
   ========================================================================== */
         min = 0.0; max = 65535.0;
         histo_range = 65536;
         
         break;

      case LDEFIE_dt_UINTx2:
/* ==========================================================================
   Set histo_range to the max value
   ========================================================================== */
         min = 0.0; max = 65535.0;
         histo_range = 65536;
         
         break;

      case LDEFIE_dt_INTx4:

/* ==========================================================================
   Search min and max
   ========================================================================== */
         min = (double) UINTx8_MAX; max = 0.0; 
         
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((INTx4 *) imgline)[ column ]));
               min = MIN( val, min );
               max = MAX( val, max );

            }
         }

/* ==========================================================================
   Set histogam range
   ========================================================================== */
         histo_range = def_histo_range;

         break;

      case LDEFIE_dt_UINTx4:

/* ==========================================================================
   Search min and max
   ========================================================================== */
         min = (double) UINTx8_MAX; max = 0.0; 
         
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((UINTx4 *) imgline)[ column ]));
               min = MIN( val, min );
               max = MAX( val, max );

            }
         }
/* ==========================================================================
   Compute histogam range
   ========================================================================== */
         histo_range = def_histo_range;

         break;

      case LDEFIE_dt_float:

/* ==========================================================================
   Search min and max
   ========================================================================== */
         min = (double) UINTx8_MAX; max = 0.0; 

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = (double) (((float *) imgline)[ column ]);
               min = MIN( val, min );
               max = MAX( val, max );

            }
         }

/* ==========================================================================
   Compute histogam range
   ========================================================================== */
         histo_range = def_histo_range;

         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }


/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute delta of input image
   ========================================================================== */
   delta = (max - min)/((double) (def_histo_range-1));

/* ==========================================================================
   Reopen read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Switch according to input image type to compute the histogram
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_UINTx1:

/* ==========================================================================
   Alloc histo, dhisto and set to 0
   ========================================================================== */
         histo = (UINTx4 *) MEMSIP_alloc(histo_range * sizeof(UINTx4));
         if( histo == (UINTx4 *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "histo" );
         }
         memset( (void *) histo, 0, (size_t) histo_range * sizeof(UINTx4) );
         dhisto = (double *) MEMSIP_alloc(histo_range * sizeof(double));
         if( dhisto == (double *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "dhisto" );
         }
         memset( (void *) dhisto, 0, (size_t) histo_range * sizeof(double) );

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((UINTx1 *) imgline)[ column ]));
               index = (UINTx4) ((val - min)/delta);
               histo[ index ]++;

            }
         }
         break;

      case LDEFIE_dt_INTx2:

/* ==========================================================================
   Alloc histo, dhisto and set to 0
   ========================================================================== */
         histo = (UINTx4 *) MEMSIP_alloc(histo_range * sizeof(UINTx4));
         if( histo == (UINTx4 *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "histo" );
         }
         memset( (void *) histo, 0, (size_t) histo_range * sizeof(UINTx4) );
         dhisto = (double *) MEMSIP_alloc(histo_range * sizeof(double));
         if( dhisto == (double *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "dhisto" );
         }
         memset( (void *) dhisto, 0, (size_t) histo_range * sizeof(double) );

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((INTx2 *) imgline)[ column ]));
               index = (UINTx4) ((val - min)/delta);
               histo[ index ]++;

            }
         }
         break;

      case LDEFIE_dt_UINTx2:

/* ==========================================================================
   Alloc histo, dhisto and set to 0
   ========================================================================== */
         histo = (UINTx4 *) MEMSIP_alloc(histo_range * sizeof(UINTx4));
         if( histo == (UINTx4 *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "histo" );
         }
         memset( (void *) histo, 0, (size_t) histo_range * sizeof(UINTx4) );
         dhisto = (double *) MEMSIP_alloc(histo_range * sizeof(double));
         if( dhisto == (double *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "dhisto" );
         }
         memset( (void *) dhisto, 0, (size_t) histo_range * sizeof(double) );

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((UINTx2 *) imgline)[ column ]));
               index = (UINTx4) ((val - min)/delta);
               histo[ index ]++;

            }
         }
         break;

      case LDEFIE_dt_INTx4:

/* ==========================================================================
   Alloc histo, dhisto and set to 0
   ========================================================================== */
         histo = (UINTx4 *) MEMSIP_alloc(histo_range * sizeof(UINTx4));
         if( histo == (UINTx4 *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "histo" );
         }
         memset( (void *) histo, 0, (size_t) histo_range * sizeof(UINTx4) );
         dhisto = (double *) MEMSIP_alloc(histo_range * sizeof(double));
         if( dhisto == (double *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "dhisto" );
         }
         memset( (void *) dhisto, 0, (size_t) histo_range * sizeof(double) );

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((INTx4 *) imgline)[ column ]));
               index = (UINTx4) ((val - min)/delta);
               histo[ index ]++;

            }
         }
         break;

      case LDEFIE_dt_UINTx4:

/* ==========================================================================
   Alloc histo, dhisto and set to 0
   ========================================================================== */
         histo = (UINTx4 *) MEMSIP_alloc(histo_range * sizeof(UINTx4));
         if( histo == (UINTx4 *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "histo" );
         }
         memset( (void *) histo, 0, (size_t) histo_range * sizeof(UINTx4) );
         dhisto = (double *) MEMSIP_alloc(histo_range * sizeof(double));
         if( dhisto == (double *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "dhisto" );
         }
         memset( (void *) dhisto, 0, (size_t) histo_range * sizeof(double) );

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((UINTx4 *) imgline)[ column ]));
               index = (UINTx4) ((val - min)/delta);
               histo[ index ]++;

            }
         }
         break;

      case LDEFIE_dt_float:

/* ==========================================================================
   Alloc histo, dhisto and set to 0
   ========================================================================== */
         histo = (UINTx4 *) MEMSIP_alloc(histo_range * sizeof(UINTx4));
         if( histo == (UINTx4 *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "histo" );
         }
         memset( (void *) histo, 0, (size_t) histo_range * sizeof(UINTx4) );
         dhisto = (double *) MEMSIP_alloc(histo_range * sizeof(double));
         if( dhisto == (double *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "dhisto" );
         }
         memset( (void *) dhisto, 0, (size_t) histo_range * sizeof(double) );

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = (double) (((float *) imgline)[ column ]);
               index = (UINTx4) ((val - min)/delta);
               histo[ index ]++;

            }
         }
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }


   for( index=0, total=0; index<histo_range; index++) total+=histo[ index ];



/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Normalize histogram
   ========================================================================== */
   if( no_black_found == FALSE ) {
      start = -1;
   }
   else {
      if( no_black < min ) {
         ERRSIM_print_warning( "Input parameter Number of Black ignored as less than minimum histogram range ");
         start = -1;
      }
      else {
         start = ROUND((no_black-min)/delta);
         if( start >= histo_range ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_inv_param_val, 
               "Input parameter Number of Black greather than histogram range" );
         }
      }
   }

   for( i = start+1, dnorm = 0.0; i<histo_range; i++ ) {
      dnorm += ((double) (histo[ i ]));
   }

   if( start != -1 ) {
      for( i = 0; i<=start; i++ ) {
         dhisto[ i ] = 0.0;
      }
   }

   for( i = start+1; i<histo_range; i++ ) {
      dhisto[ i ] = (((double) (histo[ i ]))/dnorm);
   }

/* ==========================================================================
   Search for low and high transformation value
   ========================================================================== */
   dminperc = min_perc/100.0; dmaxperc = max_perc/100.0;
   min_found = FALSE; max_found = FALSE;
   for( dnorm = 0.0, i = start+1; 
       (i<histo_range) && (!min_found || !max_found);
        i++ ) {
      dnorm += dhisto[ i ];
      if( !min_found && (dnorm > dminperc) ) {
         low = min + ((double) i) * delta;
         min_found = TRUE;
      }
      if( !max_found && (dnorm > dmaxperc) ) {
         high = min + ((double) i) * delta;
         max_found = TRUE;
      }
   }

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Reopen read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Alloc output image line
   ========================================================================== */
   if( (outline = 
        (UINTx1 *) MEMSIP_alloc( ncol * sizeof(UINTx1) )) ==
       (UINTx1 *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
   }

/* ==========================================================================
   Switch according to input image type to compute the histogram
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_UINTx1:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((UINTx1 *) imgline)[ column ]));
               if( val < low ) {
                  outline[ column ] = (UINTx1) 0;
               }
               else if( val > high ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1)(255.0*(val - low)/(high-low));
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_INTx2:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((INTx2 *) imgline)[ column ]));
               if( val < low ) {
                  outline[ column ] = (UINTx1) 0;
               }
               else if( val > high ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1)(255.0*(val - low)/(high-low));
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_UINTx2:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((UINTx2 *) imgline)[ column ]));
               if( val < low ) {
                  outline[ column ] = (UINTx1) 0;
               }
               else if( val > high ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1)(255.0*(val - low)/(high-low));
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_INTx4:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((INTx4 *) imgline)[ column ]));
               if( val < low ) {
                  outline[ column ] = (UINTx1) 0;
               }
               else if( val > high ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1)(255.0*(val - low)/(high-low));
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_UINTx4:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((double) (((UINTx4 *) imgline)[ column ]));
               if( val < low ) {
                  outline[ column ] = (UINTx1) 0;
               }
               else if( val > high ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1)(255.0*(val - low)/(high-low));
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_float:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {


               val = (double) (((float *) imgline)[ column ]);

               if( val < low ) {
                  outline[ column ] = (UINTx1) 0;
               }
               else if( val > high ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1)((255.0*(val - low))/(high-low));
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &outline );
   MEMSIP_free( (void **) &histo );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_gaincvs */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_ugaincvs

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      user_lut  : name of the file containing the user-defined
                                  look-up table
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of GAIN convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_ugaincvs
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ char                *user_lut,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_ugaincvs";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;
   char                   err_msg[ 256 ];

   UINTx4                 row, column;
   void                  *imgline = (void *) NULL;
   UINTx1                *outline;
   float                  val, valold;
   FILE                  *fpLut;
   char                   lut_line[ LDEFID_dense_line ];
   char                  *null_char;
   float                  func[ 256 ];
   UINTx1                 index[ 256 ];
   INTx4                  i, iold, nolev;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow > IANNIV_ImageAnnot[ inp_ima_num ].ImageLength ) ||
        ( TLCol + ncol > IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth ) )
      ERRSIM_set_error( status_code, ERRSID_CONV_start_stop_col_err, "" );

/* ==========================================================================
   Load user-defined convertion LUT
   ========================================================================== */
   FILSIP_open( user_lut, "r", 0, &fpLut, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Loop on lines of lut files
   ========================================================================== */
   iold = -1; nolev = 0; valold = -1.0e37;
   while( fgets(lut_line, sizeof( lut_line ), fpLut) != (char *) NULL ) {

/* ==========================================================================
   Null the \n character
   ========================================================================== */
      if( (null_char = strchr( lut_line, '\n' )) != (char *) NULL ) {
         *null_char = '\0';
      }

/* ==========================================================================
   Skip blan lines
   ========================================================================== */
      if( strcmp( lut_line, "" ) ) {

         if( sscanf( lut_line,"%d %f", &i, &val ) < 2 ) {
            sprintf( err_msg, "Line <%s>", lut_line );
            ERRSIM_set_error( status_code, ERRSID_CONV_inv_user_lut, 
               err_msg );
         }

#ifdef __NOT_USEFUL__
         if( i <= iold ) {
            sprintf( err_msg, "Line <%s> do not increase input value", 
               lut_line );
            ERRSIM_set_error( status_code, ERRSID_CONV_inv_user_lut, 
               err_msg );
         }
#endif
         if( val < valold ) {
            sprintf( err_msg, "Line <%s> do not increase output value",
               lut_line );
            ERRSIM_set_error( status_code, ERRSID_CONV_inv_user_lut,
               err_msg );
         }
         if( i > 255) {
            sprintf( err_msg, "Line <%s> has an invalid output value", 
               lut_line );
            ERRSIM_set_error( status_code, ERRSID_CONV_inv_user_lut, 
               err_msg );
         }

         if( nolev > 255 ) {
            sprintf( err_msg, "Line <%s> ignored: too much values", 
               lut_line );
         }
         else {
            func[ nolev ] = val;
            index[ nolev ] = i;
            nolev++;                  
         }
         iold = i;
         valold = val;
      }

   }

/* ==========================================================================
   Close LUT
   ========================================================================== */
   FILSIP_close( &fpLut, &log_status_code );

/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Alloc output image line
   ========================================================================== */
   if( (outline = 
        (UINTx1 *) MEMSIP_alloc( ncol * sizeof(UINTx1) )) ==
       (UINTx1 *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
   }

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow, &log_status_code );

/* ==========================================================================
   Switch according to input image type
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_UINTx1:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((float) (((UINTx1 *) imgline)[ column ]));
               if( val < func[ 0 ] ) {
                  outline[ column ] = (UINTx1) index[ 0 ];
               }
               else  {
                  for( i=1; i<nolev; i++ ) {
                     if( (val >= func[ i-1 ]) &&
                         (val < func[ i ] ) ) {
                        outline[ column ] = (UINTx1) index[ i ];
                        break;
                     }
                  }
                  if( i == nolev ) {
                     outline[ column ] = (UINTx1) 255;
                  }
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_INTx2:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((float) (((INTx2 *) imgline)[ column ]));
               if( val < func[ 0 ] ) {
                  outline[ column ] = (UINTx1) index[ 0 ];
               }
               else  {
                  for( i=1; i<nolev; i++ ) {
                     if( (val >= func[ i-1 ]) &&
                         (val < func[ i ] ) ) {
                        outline[ column ] = (UINTx1) index[ i ];
                        break;
                     }
                  }
                  if( i == nolev ) {
                     outline[ column ] = (UINTx1) 255;
                  }
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_UINTx2:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((float) (((UINTx2 *) imgline)[ column ]));
               if( val < func[ 0 ] ) {
                  outline[ column ] = (UINTx1) index[ 0 ];
               }
               else  {
                  for( i=1; i<nolev; i++ ) {
                     if( (val >= func[ i-1 ]) &&
                         (val < func[ i ] ) ) {
                        outline[ column ] = (UINTx1) index[ i ];
                        break;
                     }
                  }
                  if( i == nolev ) {
                     outline[ column ] = (UINTx1) 255;
                  }
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_INTx4:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((float) (((INTx4 *) imgline)[ column ]));
               if( val < func[ 0 ] ) {
                  outline[ column ] = (UINTx1) index[ 0 ];
               }
               else  {
                  for( i=1; i<nolev; i++ ) {
                     if( (val >= func[ i-1 ]) &&
                         (val < func[ i ] ) ) {
                        outline[ column ] = (UINTx1) index[ i ];
                        break;
                     }
                  }
                  if( i == nolev ) {
                     outline[ column ] = (UINTx1) 255;
                  }
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_UINTx4:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((float) (((UINTx4 *) imgline)[ column ]));
               if( val < func[ 0 ] ) {
                  outline[ column ] = (UINTx1) index[ 0 ];
               }
               else  {
                  for( i=1; i<nolev; i++ ) {
                     if( (val >= func[ i-1 ]) &&
                         (val < func[ i ] ) ) {
                        outline[ column ] = (UINTx1) index[ i ];
                        break;
                     }
                  }
                  if( i == nolev ) {
                     outline[ column ] = (UINTx1) 255;
                  }
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_float:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = (((float *) imgline)[ column ]);
               if( val < func[ 0 ] ) {
                  outline[ column ] = (UINTx1) index[ 0 ];
               }
               else  {
                  for( i=1; i<nolev; i++ ) {
                     if( (val >= func[ i-1 ]) &&
                         (val < func[ i ] ) ) {
                        outline[ column ] = (UINTx1) index[ i ];
                        break;
                     }
                  }
                  if( i == nolev ) {
                     outline[ column ] = (UINTx1) 255;
                  }
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &outline );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_ugaincvs */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_sgaincvs

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      scale_fact: scaling factor value
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of GAIN convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_sgaincvs
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ float                scale_fact,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_sgaincvs";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;
   char                   err_msg[ 256 ];

   UINTx4                 row, column;
   void                  *imgline = (void *) NULL;
   UINTx1                *outline;
   float                  val;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow > IANNIV_ImageAnnot[ inp_ima_num ].ImageLength ) ||
        ( TLCol + ncol > IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth ) )
      ERRSIM_set_error( status_code, ERRSID_CONV_start_stop_col_err, "" );

/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Alloc output image line
   ========================================================================== */
   if( (outline = 
        (UINTx1 *) MEMSIP_alloc( ncol * sizeof(UINTx1) )) ==
       (UINTx1 *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
   }

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow, &log_status_code );

/* ==========================================================================
   Switch according to input image type
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_UINTx1:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((float) (((UINTx1 *) imgline)[ column ]));
               if( (val/scale_fact) > 255.0 ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1) (val/scale_fact);
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_INTx2:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((float) (((INTx2 *) imgline)[ column ]));
               if( (val/scale_fact) > 255.0 ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1) (val/scale_fact);
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_UINTx2:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((float) (((UINTx2 *) imgline)[ column ]));
               if( (val/scale_fact) > 255.0 ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1) (val/scale_fact);
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_INTx4:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((float) (((INTx4 *) imgline)[ column ]));
               if( (val/scale_fact) > 255.0 ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1) (val/scale_fact);
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_UINTx4:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = ((float) (((UINTx4 *) imgline)[ column ]));
               if( (val/scale_fact) > 255.0 ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1) (val/scale_fact);
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_float:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

            for( column=0; column<ncol; column++ ) {

               val = (((float *) imgline)[ column ]);
               if( (val/scale_fact) > 255.0 ) {
                  outline[ column ] = (UINTx1) 255;
               }
               else {
                  outline[ column ] = (UINTx1) (val/scale_fact);
               }

            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &outline );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_sgaincvs */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_bilgen

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input images
                      image_no  : number of input images
                      out_io    : IO structure of the output 
                      out_image_erm
                                : name of ascii file for ERMPAPPER import 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of BIL generation
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_bilgen
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               image_no,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ char                *out_image_erm,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_bilgen";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, nrows, ncols, i, size;
   void                  *imgline = (void *) NULL;
   FILE                  *fp;
   char                   cell_type[ 100 ];
   char                   msg[ 256 ];
   LDEFIT_boolean         build_ers_file;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set number of rows and columns
   ========================================================================== */
   nrows = inp_io[ 0 ].val.tif.bpar.imagelength;
   ncols = inp_io[ 0 ].val.tif.bpar.imagewidth;

/* ==========================================================================
   Open read mode for input images
   ========================================================================== */
   for( i=0; i<image_no; i++ ) {
      GIOSIP_open_line( &(inp_io[ i ]), 'x', 0, ncols - 1, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncols - 1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set build_ers_file to TRUE
   ========================================================================== */
   build_ers_file = TRUE;

/* ==========================================================================
   Switch according to input image type
   ========================================================================== */
   switch( inp_io[ 0 ].dt ) {

      case LDEFIE_dt_UINTx1:
         size = ncols * sizeof(UINTx1);
         sprintf( cell_type, "Unsigned8BitInteger");
         break;

      case LDEFIE_dt_INTx2:
         size = ncols * sizeof(INTx2);
         sprintf( cell_type, "Signed16BitInteger");
         break;

      case LDEFIE_dt_UINTx2:
         size = ncols * sizeof(UINTx2);
         sprintf( cell_type, "Unsigned16BitInteger");
         break;

      case LDEFIE_dt_INTx4:
         size = ncols * sizeof(INTx4);
         sprintf( cell_type, "Signed32BitInteger");
         break;

      case LDEFIE_dt_UINTx4:
         size = ncols * sizeof(UINTx4);
         sprintf( cell_type, "Unsigned32BitInteger");
         break;

      case LDEFIE_dt_float:
         size = ncols * sizeof(float);
         sprintf( cell_type, "IEEE4ByteReal");
         break;

      case LDEFIE_dt_2_UINTx1:
         size = 2 * ncols * sizeof(UINTx1);
         sprintf( cell_type, "CompexUnsigned8BitInteger");
         build_ers_file = FALSE;
         break;

      case LDEFIE_dt_2_INTx2:
         size = 2 * ncols * sizeof(INTx2);
         sprintf( cell_type, "CompexSigned16BitInteger");
         build_ers_file = FALSE;
         break;

      case LDEFIE_dt_2_float:
         size = 2 * ncols * sizeof(float);
         sprintf( cell_type, "ComplexFloat");
         build_ers_file = FALSE;
         break;
       
      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrows, &log_status_code );

/* ==========================================================================
   Loop on lines
   ========================================================================== */
   for( row=0; row<nrows; row ++) {
      SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read and write the rows
   ========================================================================== */
      for( i=0; i<image_no; i++ ) {
         GIOSIP_read_line( &(inp_io[ i ]), row, 0, 
                           &imgline, status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         FILSIF_write( out_io->val.fil.fp,
                       size,
                       imgline,
                       status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }

   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   for( i=0; i<image_no; i++ ) {
      GIOSIP_close_line( &(inp_io[ i ]), status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

   if( build_ers_file == FALSE ) {
      sprintf( msg, "%s file not created for %s data type", 
         out_image_erm, cell_type );
      ERRSIM_print_warning( msg );
   }
   else {
/* ==========================================================================
   Open out image ERMAPPER ascii file
   ========================================================================== */
      FILSIP_open( out_image_erm, "w", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Write file
   ========================================================================== */
      fprintf( fp, "DatasetHeader Begin\n" );
      fprintf( fp, "\tDataSetType\t= ERStorage\n");
      fprintf( fp, "\tDataType\t= Raster\n");
      fprintf( fp, "\tByteOrder\t= MSBFirst\n");
      fprintf( fp, "\tRasterInfo Begin\n");
      fprintf( fp, "\t\tCellType\t= %s\n", cell_type );
      fprintf( fp, "\t\tNrOfLines\t= %0d\n", nrows );
      fprintf( fp, "\t\tNrOfCellsPerLine\t= %0d\n", ncols );
      fprintf( fp, "\t\tNrOfBands\t= %0d\n", image_no );
      for( i=0; i<image_no; i++ ) {
         fprintf( fp, "\t\tBandId Begin\n");
         fprintf( fp, "\t\t\tValue\t = \"band %0d\"\n", i+1 );
         fprintf( fp, "\t\tBandId End\n"); 
      }
      fprintf( fp, "\tRasterInfo End\n");
      fprintf( fp, "DatasetHeader End\n" );

/* ==========================================================================
   Close it
   ========================================================================== */
      FILSIP_close( &fp, &log_status_code );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_bilgen */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_tiffgen

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input images
                      image_no  : number of input images
                      out_io    : IO structure of the output 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of TIFF generation
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_tiffgen
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               image_no,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_tiffgen";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, col, nrows, ncols, i;
   UINTx1               **imgline = (UINTx1 **) NULL;
   UINTx1                *outline = (UINTx1 *) NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Set number of rows and columns
   ========================================================================== */
   nrows = inp_io[ 0 ].val.tif.bpar.imagelength;
   ncols = inp_io[ 0 ].val.tif.bpar.imagewidth;

/* ==========================================================================
   Alloc pointers for input ...
   ========================================================================== */
   if( (imgline = (UINTx1 **) MEMSIP_alloc( image_no * sizeof(UINTx1 *) )) ==
       (UINTx1 **) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "imgline" );
   }

/* ==========================================================================
   ... and output lines
   ========================================================================== */
   if( (outline = 
        (UINTx1 *) MEMSIP_alloc( image_no * ncols * sizeof(UINTx1) )) ==
       (UINTx1 *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
   }

/* ==========================================================================
   Open read mode for input images
   ========================================================================== */
   for( i=0; i<image_no; i++ ) {
      GIOSIP_open_line( &(inp_io[ i ]), 'x', 0, ncols - 1, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncols - 1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrows, &log_status_code );

/* ==========================================================================
   Loop on lines
   ========================================================================== */
   for( row=0; row<nrows; row ++) {
      SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
      for( i=0; i<image_no; i++ ) {
         GIOSIP_read_line( &(inp_io[ i ]), row, 0, 
                           (void *) &(imgline[ i ]), status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }

/* ==========================================================================
   Rearrange output
   ========================================================================== */
      for( col=0; col<ncols; col ++) {
         for( i=0; i<image_no; i++ ) {
            outline[ image_no * col + i] = imgline[ i ][ col ];
         }
      }

/* ==========================================================================
   Write the row
   ========================================================================== */
      GIOSIP_write_line( out_io, row, outline, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   for( i=0; i<image_no; i++ ) {
      GIOSIP_close_line( &(inp_io[ i ]), status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_tiffgen */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_dumpannot

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      dump_file : output dump file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure contains the core of ANCILLARY DUMP
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_dumpannot
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ char                *dump_file,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_dumpannot";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   FILE                  *fp_dump;
   FILSIT_file_name       cfg_tag;
   TIFSIT_tag_elem       *tag_vet = (TIFSIT_tag_elem *) NULL;
   UINTx4		  tot_tag, img, i, j, k;
   char		          par_name[REPLINELEN];
   UINTx2		 *tag;
   TIFSIT_par             param;
   char                  *unknown = "***Unknown Name***";
   UINTx4		  terminator;
   UINTx4                 a, b;
   INTx4                  c, d;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Obtain tags configuration file
   ========================================================================== */
#ifdef __VMS__
   sprintf( cfg_tag, "inc$:iann_tags.h" );
#else
   sprintf( cfg_tag, "%s%s", LDEFIV_cfg_dir, "tags.h" );
#endif

/* ==========================================================================
   Fill tag vector 
   ========================================================================== */
   TIFSIP_fill_tag_vet( cfg_tag, &tot_tag, &tag_vet, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open Dump Annotation File
   ========================================================================== */
   FILSIP_open( dump_file, "w", 0, &fp_dump, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Print header
   ========================================================================== */
   fprintf( fp_dump, "====================================================================================================================================");
   fprintf( fp_dump, "\n\tSTB - Sar Tool Box - Telespazio / ESA - ANNOTATION DUMP" );
   fprintf( fp_dump, "\n====================================================================================================================================");

/* ==========================================================================
   Write image name
   ========================================================================== */
   fprintf( fp_dump, "\nImage: %s", inp_io->val.tif.name );
   fprintf( fp_dump, "\n====================================================================================================================================");

/* ==========================================================================
   For each image
   ========================================================================== */
   for ( img = 0; img < inp_io->val.tif.nimg; img++ ) {

      if( img > 0 ) {
         fprintf( fp_dump, "\n====================================================================================================================================");
      }

      if( (tag = MEMSIP_alloc( inp_io->val.tif.npar * sizeof(UINTx2) )) == 
          (UINTx2 *) NULL ) {
         ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "tag" );
      }
      TIFSIP_dir_par( inp_io->chan, img, tag, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      for( i = 0; i < inp_io->val.tif.npar; i++ ) {

 	 param.tag = tag[i];
         TIFSIP_get_par( inp_io->chan, img, &param, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

         TIFSIP_get_tag_name(  tag_vet, tot_tag, param.tag, par_name, 
                               status_code);
         ERRSIM_on_err_goto_exit( *status_code );

         if (strlen(par_name) == 0 ) {
	    fprintf(fp_dump, "\n%5d\t%s(%0u)\t\t", i, unknown,param.tag);
         }
	 else {
            strlow(par_name);
	    fprintf(fp_dump, "\n%5d\t%s", i, par_name );	    
#ifdef __TRACE__
            fprintf(fp_dump, "(%0u)", param.tag );
#endif
            fprintf(fp_dump, "\t\t");
         }

	 if ( (param.length >= 2) && (param.type != TYPE_ASCII)) {
	    fprintf(fp_dump, "VectorialTag");
            if (param.type == TYPE_USHORT) fprintf(fp_dump,"[0]=%u",*(unsigned short *)param.val);
            if (param.type == TYPE_UINT) fprintf(fp_dump,"[0]=%u",*(unsigned int *)param.val);
         }
         else {
	    terminator = 0;
	    for( j = 0; j < (int)param.length; j++ ) {
            if ( terminator !=1 ) {
               switch( param.type ) {
	          case TYPE_UBYTE:
		     fprintf(fp_dump, "%d", *((unsigned char *)param.val + j ) );
                     break;
		  case TYPE_ASCII:
		     fprintf(fp_dump, "%c", *((unsigned char *)param.val + j ) );
		     if ( *((unsigned char *)param.val + j + 1 ) == 0 )
			terminator = 1;
		     break;
		  case TYPE_USHORT:
		     fprintf(fp_dump, "%u", *((unsigned short *)param.val + j ) );
		     break;
		  case TYPE_UINT:
		     fprintf(fp_dump, "%u", *((unsigned int *)param.val + j ) );
		     break;
		  case TYPE_URATIONAL:
		     a = *((unsigned int *)(param.val) + 2 * j );
		     b = *((unsigned int *)(param.val) + 2 * j + 1 );
		     if(b != 0) { 
		        fprintf(fp_dump, "%f",(float)a / (float)b );
	     	     } else fprintf(fp_dump, " "); /* divide by zero */
		     break; 
		  case TYPE_BYTE:
		     fprintf(fp_dump, "%d", *( (char *)param.val + j ) );
		     break;
		  case TYPE_SHORT:
		     fprintf(fp_dump, "%d", *( (short *)param.val + j ) );
		     break;
		  case TYPE_INT:
		     fprintf(fp_dump, "%d", *( (int *)param.val + j ) );
		     break;
		  case TYPE_FLOAT:
		     fprintf(fp_dump, "%f", *( (float *)param.val + j ) );
		     break;
		  case TYPE_DOUBLE:
	     	     fprintf(fp_dump, "%20.10f", *( (double *)param.val + j ) );
		     break;
		  case TYPE_UBYTE_COD_ASCII:
		     fprintf(fp_dump, "%s", ( (char *)param.val + 40 * j ) );
		     break;
		  case TYPE_BYTE_COD_ASCII:
		     fprintf(fp_dump, "%s", ( (char *)param.val + 40 * j ) );
		     break;
		  case TYPE_USHORT_COD_ASCII:
		     fprintf(fp_dump, "%s", ( (char *)param.val + 40 * j ) );
		     break;
		  case TYPE_SHORT_COD_ASCII:
		     fprintf(fp_dump, "%s", ( (char *)param.val + 40 * j ) );
		     break;
		  case TYPE_UINT_COD_ASCII:
		     fprintf(fp_dump, "%s", ( (char *)param.val + 40 * j ) );
		     break;
		  case TYPE_INT_COD_ASCII:
		     fprintf(fp_dump, "%s", ( (char *)param.val + 40 * j ) );
		     break;
		  case TYPE_FLOAT_COD_ASCII:
		     fprintf(fp_dump, "%s", ( (char *)param.val + 40 * j ) );
		     break;
		  case TYPE_DOUBLE_COD_ASCII:
		     fprintf(fp_dump, "%s", ( (char *)param.val + 80 * j ) );
		     break;
		  case TYPE_UBYTE_32:
		     for( k = 0; k < 32; k++ )
		        fprintf(fp_dump, "%u ", *( (unsigned char *)param.val + 32 * j + k ) );
		     break;
		  case TYPE_UBYTE_220:
		     for( k = 0; k < 220; k++ )
		        fprintf(fp_dump, "%u ", *( (unsigned char *)param.val + 220 * j + k ) );
		     break;
		  case TYPE_ASCII_STRING:
		     fprintf(fp_dump, "%s", ( (char *)param.val + 80 * j ) );
		     break;
		  case TYPE_RATIONAL:
		     c= *( (int *)(param.val) + 2 * j );
		     d= *( (int *)(param.val) + 2 * j + 1 );
		     if(d != 0) { 
		        fprintf(fp_dump, "%d/%d = %f", c, d, (float)c/(float)d );
		     } 
                     else {
                        fprintf(fp_dump," "); /* div by zero */
	     	     } 
		     break;
		  default:
		     fprintf(fp_dump, "UnrecognizedType" );
		     break;
                  }
               }
            }
        }
      }
      MEMSIP_free( (void ** ) &tag );
    }

/* ==========================================================================
   Print stop header
   ========================================================================== */
   fprintf( fp_dump, "\n====================================================================================================================================");

/* ==========================================================================
   Close Dump Annotation File
   ========================================================================== */
   FILSIP_close( &fp_dump, &log_status_code );

error_exit:;

/* ==========================================================================
   Freeze memory
   ========================================================================== */
   MEMSIP_free( (void **) &tag_vet );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_dumpannot */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_impraster

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      media_file_skip
                                : number of file to skip on TAPE
                      file_skip : header skip in bytes
                      line_skip : line skip in bytes
                      rec_len   : image record length
                      nrows     : number of rows
                      ncols     : number of columns
                      data_type : raster data type
                      swap_bytes: 'Y" if bytes needs to be swapped
                      out_io    : IO structure of the output 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of IMPORT RASTER
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_impraster
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ INTx4                media_file_skip,
                         /*IN    */ INTx4                file_skip,
                         /*IN    */ INTx4                line_skip,
                         /*IN    */ INTx4                rec_len,
                         /*IN    */ INTx4                nrows,
                         /*IN    */ INTx4                ncols,
                         /*IN    */ CONVIT_raster_data_type     
                                                         data_type,
                         /*IN    */ char                 swap_bytes,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_impraster";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, column;
   UINTx4                 noMediaFile;
   INTx4                  bytes_read;
   char                  *tmpbuff;
   char                  *tmpline;
   char                  *imgline;
   char                   app[ 2 ];
   float                 *outline;
   INTx2                  iTemp;
   UINTx2                 uiTemp;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check if inp_io is a device and skip the first media_file_skip files
   ========================================================================== */
   if( inp_io->type == GIOSIE_device ) {
      if( (tmpbuff = (char *) MEMSIP_alloc( (size_t) DEVSID_max_read_size * 
                                                     sizeof(char) )) ==
          (char *) NULL ) {
         ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc,
            "tmpbuff" );
      }
      for( noMediaFile = 0; noMediaFile<media_file_skip; noMediaFile++ ) {
         do {
            bytes_read = DEVSIF_read( (INTx4) inp_io->chan,
                                      DEVSID_max_read_size,
                                      (void *) tmpbuff,
                                      status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         } while( bytes_read > 0 );

      }
      MEMSIP_free( (void **) &tmpbuff );
   }

/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', 0, ncols-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncols-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrows, &log_status_code );

/* ==========================================================================
   Switch according to data_type
   ========================================================================== */
   switch( data_type ) {

      case CONVIE_raster_2i:

/* ==========================================================================
   Check input parameters
   ========================================================================== */
         if( (ncols*sizeof(UINTx2)) > rec_len) {
            ERRSIM_set_error( status_code, ERRSID_CONV_inv_param_val,
               "Record Length value less or equal than image column size" );
         }

/* ==========================================================================
   Allocate input buffer
   ========================================================================== */
         if( (imgline = (char *) 
                 MEMSIP_alloc( (size_t) rec_len * sizeof( char ) ) ) == 
             (char *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "imgline" );
         }

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
         if( (outline = (float *) MEMSIP_alloc( (size_t) ncols * 
                                                   sizeof(float) )) ==
             (float *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
         }

/* ==========================================================================
   Skip initial header
   ========================================================================== */
         if( file_skip != 0 ) {
            GIOSIP_read_line( inp_io, 0, file_skip, (void *) &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=0; row<nrows; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, rec_len, (void *) &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            tmpline = &(imgline[ line_skip ]);
            for( column=0; column<ncols; column++, tmpline+= 2) {
               if( swap_bytes == 'Y' ) {
                  app[ 1 ] = *tmpline;
                  app[ 0 ] = *(tmpline+1);
               }
               else {
                  app[ 0 ] = *tmpline;
                  app[ 1 ] = *(tmpline+1);
               }
               memcpy( (void *) &uiTemp, (void *) app, 2 );

               outline[ column ] = (float) uiTemp;
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }

         break;

      case CONVIE_raster_complex2i:

/* ==========================================================================
   Check input parameters
   ========================================================================== */
         if( (2*ncols*sizeof(UINTx2)) > rec_len) {
            ERRSIM_set_error( status_code, ERRSID_CONV_inv_param_val,
               "Record Length value less or equal than image column size" );
         }

/* ==========================================================================
   Allocate input buffer
   ========================================================================== */
         if( (imgline = (char *) 
                 MEMSIP_alloc( (size_t) rec_len * sizeof( char ) ) ) == 
             (char *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "imgline" );
         }

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
         if( (outline = (float *) MEMSIP_alloc( (size_t) 2 * ncols * 
                                                   sizeof(float) )) ==
             (float *) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
         }

/* ==========================================================================
   Skip initial header
   ========================================================================== */
         if( file_skip != 0 ) {
            GIOSIP_read_line( inp_io, 0, file_skip, (void *) &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );
         }

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=0; row<nrows; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, rec_len, (void *) &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            tmpline = &(imgline[ line_skip ]);
            for( column=0; column<ncols; column++, tmpline += 4) {
               if( swap_bytes == 'Y' ) {
                  app[ 1 ] = *tmpline;
                  app[ 0 ] = *(tmpline+1);
               }
               else {
                  app[ 0 ] = *tmpline;
                  app[ 1 ] = *(tmpline+1);
               }
               memcpy( (void *) &iTemp, (void *) app, 2 );
               outline[ 2 * column ] = (float) iTemp;
               iTemp = 0;
               if( swap_bytes == 'Y' ) {
                  app[ 1 ] = *(tmpline+2);
                  app[ 0 ] = *(tmpline+3);
               }
               else {
                  app[ 0 ] = *(tmpline+2);
                  app[ 1 ] = *(tmpline+3);
               }
               memcpy( (void *) &iTemp, (void *) app, 2 );
               outline[ 2 * column + 1 ] = (float) iTemp;
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }

         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "" );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &tmpbuff );
   MEMSIP_free( (void **) &outline );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_impraster */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         CONVIP_lin2db

        $TYPE         PROCEDURE

        $INPUT        inp_io 	: IO structure of the input
                      inp_ima_num
                                : number identifing the input image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow    	: number of rows of the input/output
                      ncol    	: number of columns of the input/output
                      out_io    : IO structure of the output 
                      out_ima_num
                                : number identifing the output image in the tool

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_CONV_start_stop_col_err

        $DESCRIPTION  This procedure contains the core of LINEAR TO DB 
                      convertion

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void CONVIP_lin2db
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow,
                         /*IN    */ UINTx4               ncol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "CONVIP_lin2db";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 row, column;
   void                  *imgline = (void *) NULL;
   float                 *outline;
   float                  factor;
   UINTx1                 tmpUintx1;
   UINTx2                 tmpUintx2;
   float                  tmpFloat;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );


   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow > IANNIV_ImageAnnot[ inp_ima_num ].ImageLength ) ||
        ( TLCol + ncol > IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth ) )
      ERRSIM_set_error( status_code, ERRSID_CONV_start_stop_col_err, "" );

/* ==========================================================================
   Allocate output buffer
   ========================================================================== */
   if( (outline = (float *) MEMSIP_alloc( (size_t) ncol * 
                                                   sizeof(float) )) ==
       (float *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_CONV_err_mem_alloc, "outline" );
   }
   
/* ==========================================================================
   Check input pixel type
   ========================================================================== */
   if( IANNIV_ImageAnnot[ inp_ima_num ].PixelType == IANNIE_pixt_amplitude ) {
      factor = 20.0;
   }
   else if( IANNIV_ImageAnnot[ inp_ima_num ].PixelType == IANNIE_pixt_power ) {
      factor = 10.0;
   }
   else {
      ERRSIM_set_error( status_code, ERRSID_CONV_inv_param_val,
         "Input image has an invalid pixel type" );
   }

/* ==========================================================================
   Open read mode for input image
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open write mode form output image
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ncol-1, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow, &log_status_code );

/* ==========================================================================
   Switch according to input image type
   ========================================================================== */
   switch( inp_io->dt ) {

      case LDEFIE_dt_UINTx1:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               if( (tmpUintx1 = (((UINTx1 *) imgline)[ column ])) == 0) {
                  outline[ column ] = - CONVLD_overflow_float;
               }
               else {
                  outline[ column ] = factor * 
                                      ((float) log10((double) tmpUintx1));
               }
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_UINTx2:

/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               if( (tmpUintx2 = (((UINTx2 *) imgline)[ column ])) == 0) {
                  outline[ column ] = - CONVLD_overflow_float;
               }
               else {
                  outline[ column ] = factor * 
                                      ((float) log10((double) tmpUintx2));
               }
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      case LDEFIE_dt_float:
/* ==========================================================================
   Loop on lines
   ========================================================================== */
         for( row=TLRow; row<TLRow+nrow; row ++) {
            SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Read the row
   ========================================================================== */
            GIOSIP_read_line( inp_io, row, 0, &imgline, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute convertion
   ========================================================================== */
            for( column=0; column<ncol; column++ ) {
               if( (tmpFloat = (((float *) imgline)[ column ])) < 
                   CONVLD_underflow_float ) {
                  outline[ column ] = - CONVLD_overflow_float;
               }
               else {
                  outline[ column ] = factor * 
                                      ((float) log10((double) tmpFloat));
               }
            }

/* ==========================================================================
   Write the row
   ========================================================================== */
            GIOSIP_write_line( out_io, row-TLRow, (void *) outline, 
                               status_code );
            ERRSIM_on_err_goto_exit( *status_code );

         }
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_CONV_inv_data_type, "inp_io->dt" );
   }

/* ==========================================================================
   Close the read mode of the input image
   ========================================================================== */
   GIOSIP_close_line( inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the write mode of the output image
   ========================================================================== */
   GIOSIP_close_line( out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Freeze variables
   ========================================================================== */
   MEMSIP_free( (void **) &outline );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* CONVIP_lin2db */
