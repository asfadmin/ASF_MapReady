/* ==========================================================================
   $MODULE_HEADER

      $NAME             COOR_AOIX

      $FUNCTION         This module contains the general procedures for AoI
			managment

      $ROUTINE          COORIP_AOIX_CheckAoI
			COORIP_AOIX_CheckPointInAoID
			COORIP_AOIX_CheckPointInAoIS
			COORIP_AOIX_CoverRect
			COORIP_AOIX_CheckRect
			COORIP_AOIX_CheckPointInRect

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A      12-JUN-97     AN       Initial Release
         SCR #1      26-NOV-97     AG       Changed acos with ACOS in 
                                            COORIP_AOIX_CheckPointInAoI
                                            and check arguments with 
                                            (1+COORLD_acos_epsilon)

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include MEMS_INTF_H
#include COOR_INTF_H
#include COOR_PGLB_H

/* ==========================================================================
                         DEFINE DECLARATION SECTION
   ========================================================================== */
#define COORLD_acos_epsilon ((double) 0.001)

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CheckAoI

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     nVertex : number of points
                      coords  : array of coordinates

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_few_vertex
		      
        $DESCRIPTION  This procedure checks and , if it is possible, fixes the
		      polygonal array of AoI vertex coordinates

        $WARNING      NONE

        $PDL	      - Checks the multiple defined vertex
		      - Fixes them if there are
		      - Resets the vertex

   $EH
   ========================================================================== */
void COORIP_AOIX_CheckAoI
			(/*IN OUT*/ UINTx4               nVertex, 
			 /*IN OUT*/ MATHIT_RC           *coords, 
			 /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name  routine_name = "COORIP_AOIX_CheckAoI";
   ERRSIT_status           log_status_code;
   ERRSIT_flag             process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                   nDistinct;
   INTx4                   nCount0;
/*   INTx4                   nCount1; */
/*   INTx4                   bExist; */
   MATHIT_RC              *ptLocal = (MATHIT_RC *)NULL;
   INTx4                  *count = (INTx4 *)NULL;

/* ==========================================================================
   Default initialization
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Checks the number of vertex
   ========================================================================== */
   if ( nVertex < 3 ) {
      ERRSIM_set_error( status_code, ERRSID_COOR_few_vertex, "" );
   }

/* ==========================================================================
   Allocate the local variable with the points
   ========================================================================== */
   if ( ( ptLocal = (MATHIT_RC *)MEMSIP_alloc ( (size_t)(nVertex *
                                                sizeof (MATHIT_RC)) ) ) ==
        (MATHIT_RC *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_COOR_err_mem_alloc,
                         "for the local points array" );
   }

/* ==========================================================================
   Allocate the counter of the multiple vertices
   ========================================================================== */
   if ( ( count = (INTx4 *)MEMSIP_alloc ( (size_t)(nVertex *
                                          sizeof (INTx4)) ) ) ==
        (INTx4 *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_COOR_err_mem_alloc,
                         "allocating the counter array" );
   }

/* ==========================================================================
   Zero the counter
   ========================================================================== */
   memset ( (void *)count, 0, (size_t)(nVertex * sizeof (INTx4)) );

/* ==========================================================================
   Check if there are multiple vertex
   ========================================================================== */

   /* from first to last minum one */
   for ( nCount0=0;nCount0<nVertex-1;nCount0++ ) {
      if ( ( ( coords + nCount0 + 1 )->row == ( coords + nCount0 )->row ) &&
           ( ( coords + nCount0 + 1 )->col == ( coords + nCount0 )->col ) ) {
         count[ nCount0 ] = 1;
         ERRSIM_print_warning ( "Founded equals adiacent vertices. Fixing them" );
      }
   }

   /* see last vertex */
   if ( ( coords[ 0 ].row == coords[ nVertex - 1 ].row ) &&
        ( coords[ 0 ].col == coords[ nVertex - 1 ].col ) ) {
      ERRSIM_print_warning ( "Founded equals adiacent vertices. Fixing them." );
      count[ nVertex - 1 ] = 1;
   }

/* ==========================================================================
   Set the different vertices
   ========================================================================== */
   nDistinct = 0;
   for ( nCount0=0; nCount0<nVertex; nCount0++ ) {
      if ( count[ nCount0 ] == 0 ) {
         ptLocal[ nDistinct ].row = ( coords + nCount0 )->row;
         ptLocal[ nDistinct ].col = ( coords + nCount0 )->col;
         nDistinct++;
      }
   }

/* ==========================================================================
   Checks the new number of vertex
   ========================================================================== */
   if ( nDistinct < 3 ) {
      ERRSIM_set_error( status_code, ERRSID_COOR_few_vertex, "" );
   }

/* ==========================================================================
   Reset the vertex
   ========================================================================== */
   nVertex = nDistinct;
   memcpy( (void *)coords, (const void *)ptLocal,
	   (size_t)(nDistinct * sizeof(MATHIT_RC)) );

error_exit:;

/* ==========================================================================
   Free the allocated array
   ========================================================================== */
   MEMSIP_free ( (void **)&ptLocal );
   MEMSIP_free ( (void **)&count );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* COORIP_AOIX_CheckAoI */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CheckPointInAoID

        $TYPE         PROCEDURE

        $INPUT        nVertex : number of vertexes of the AoI
		      coords  : array of vertex coordinates
		      point   : coordinates of the point to check

        $MODIFIED     NONE

        $OUTPUT       in_out  : indicator of the point position WRT the AoI:
				 -1  point out of the AoI;
				  0  point on the AoI borders;
				  1  point into the AoI;

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure checks if a point lies into a polygonal
		      AoI

        $WARNING      No formal check is made for the AoI: call the 
                      COORIP_AOIX_CheckAoI routine before

        $PDL	      - Evaluates the differences of the point coordinates
			WRT each AoI vertex
		      - Evaluates the distances between the point and each
		        vertex
		      - Loop on the vertex
		            - Evaluates the scalar product between the contigues
			      vectors distances
                            - Evaluates the vector product between them
			    - Sums the angles with their sign given by the sign
			      of the vector product component out of the vectors
			      plane
		      - End Loop
		      - Checks the point position using the value of the angles
		        sum

   $EH
   ========================================================================== */
void COORIP_AOIX_CheckPointInAoID
			(/*IN    */ UINTx4               nVertex, 
			 /*IN    */ MATHIT_RC           *coords, 
                         /*IN    */ MATHIT_RC           *point, 
                         /*   OUT*/ INTx4               *in_out,
                         /*   OUT*/ ERRSIT_status       *status_code )
{  
   const ERRSIT_proc_name  routine_name = "COORIP_AOIX_CheckPointInAoID";
   ERRSIT_status           log_status_code;
   ERRSIT_flag             process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                   nCount;
   double                  sum_angles;
   double                  sign_angles;
   double                  prod_scal;
   double                  prod_vect;
   double                  angles;
   double                  angles_sum;
   double                  acosarg;
   MATHIT_RC              *diff = (MATHIT_RC *) NULL;
   double                 *dist = (double *) NULL;
   float                   find;
   INTx4                   ind;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the number of vertex
   ========================================================================== */
   if( nVertex < 3 ) {
      ERRSIM_set_error( status_code, ERRSID_COOR_few_vertex, "" );
   }

/* ==========================================================================
   Alloc diff and dist
   ========================================================================== */
   if( (diff = (MATHIT_RC *) MEMSIP_alloc( nVertex * sizeof(MATHIT_RC) ) ) ==
       (MATHIT_RC *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_COOR_err_mem_alloc, "diff" );
   }

   if( (dist = (double *) MEMSIP_alloc( nVertex * sizeof(double) ) ) ==
       (double *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_COOR_err_mem_alloc, "dist" );
   }

/* ==========================================================================
   Compute the difference of contigues vertices coodinates
   ========================================================================== */
   *in_out = -1;
   for ( nCount=0;nCount<nVertex; nCount++ ) {
      diff[nCount].row = (coords+nCount)->row - point->row;
      diff[nCount].col = (coords+nCount)->col - point->col;
 
/* ==========================================================================
   Check if the point overlay the vertex
   ========================================================================== */
      if ( ( diff[ nCount ].row == 0 ) && ( diff[ nCount ].col == 0 ) ) {
	 *in_out = 0;
         break;
      }
   }

/* ==========================================================================
   Compute the distances from the vertices
   ========================================================================== */
   if ( *in_out == -1 ) {
      for ( nCount=0;nCount< nVertex; nCount++ ) {
         dist[ nCount ] = sqrt( ( diff[ nCount ].row * diff[ nCount ].row ) +
                                ( diff[ nCount ].col * diff[ nCount ].col ) );
      }

/* ==========================================================================
   Compute the scalar product
   ========================================================================== */
      sum_angles = 0;
      for ( nCount=0;nCount< nVertex - 1; nCount++ ) {
         prod_scal = ( diff[ nCount ].row * diff[ nCount + 1 ].row ) +
                     ( diff[ nCount ].col * diff[ nCount + 1 ].col);
         prod_vect = -( diff[ nCount ].row * diff[ nCount + 1 ].col ) +
                      ( diff[ nCount ].col * diff[ nCount + 1 ].row );
         acosarg = prod_scal / ( dist[ nCount ] * dist[ nCount + 1 ] );
#ifdef __TRACE__
         if( ( (prod_scal / ( dist[ nCount ] * dist[ nCount + 1 ]) ) >  1.0 ) ||
             ( (prod_scal / ( dist[ nCount ] * dist[ nCount + 1 ]) ) < -1.0 ) ){

            fprintf( stderr, "prod_scal = %f\ndist[%0d] = %f\ndist[%0d] = %f\n\
div = %20.18f\n\n", prod_scal, nCount, dist[ nCount ], nCount + 1, 
                     dist[ nCount + 1 ], acosarg );
         }
#endif
         if( ABS( acosarg ) > (1 + COORLD_acos_epsilon) ) {
            char errmsg[ 132 ];
            sprintf( errmsg, "acos arg = %f", acosarg );
            ERRSIM_set_error( status_code, 
                              ERRSID_COOR_math_exception, 
                              errmsg )
         }

         angles = ACOS( prod_scal / ( dist[ nCount ] * dist[ nCount + 1 ] ) );
         if ( prod_vect < 0 )
            sum_angles -=  angles; 
         else
            if ( prod_vect >= 0 )
               sum_angles +=  angles;
      }
      prod_scal = ( diff[ nVertex - 1 ].row * diff[ 0 ].row ) +
                ( diff[ nVertex - 1 ].col * diff[ 0 ].col );
      prod_vect = - ( diff[ nVertex - 1 ].row * diff[ 0 ].col ) +
                    ( diff[ nVertex - 1 ].col * diff[ 0 ].row );

      angles = ACOS( prod_scal / ( dist[ nVertex - 1 ] * dist[ 0 ] ) );
      if ( prod_vect < 0 ) 
         sum_angles -=  angles;
      else
         if ( prod_vect >= 0 )
            sum_angles +=  angles;
   
/* ==========================================================================
   Evaluate the position through the absolute angle value
   ========================================================================== */
      sum_angles = ABS( sum_angles );
      if ( ( sum_angles < ( - COORID_AOIPRECISION ) ) ||
	   ( sum_angles > COORID_AOIPRECISION ) ) {

         ind = ROUND( ( sum_angles / PI ) );

	 find = ind % 2;

	 if ( find == 0. ) {
	    *in_out = 1;
	 }
	 else {
	    *in_out = 0;
	 }

      }

#ifdef __WHY__
      /* point into the AoI */
      if ( ( sum_angles > ( 2 * PI - COORID_AOIPRECISION ) ) &&
           ( sum_angles < ( 2 * PI + COORID_AOIPRECISION ) ) )
         *in_out = 1;
      /*  point on the Aoi borders */
      if ( ( sum_angles > ( PI - COORID_AOIPRECISION ) ) &&
	   ( sum_angles < ( PI + COORID_AOIPRECISION ) ) )
         *in_out = 0;
#endif
   }

error_exit:;

/* ==========================================================================
   Freeze the allocated memory
   ========================================================================== */
   MEMSIP_free( (void **) &diff );
   MEMSIP_free( (void **) &dist );
   
   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                           *status_code, 
                          &log_status_code );

} /* COORIP_AOIX_CheckPointInAoID */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CheckPointInAoIS

        $TYPE         PROCEDURE

        $INPUT        nVertex : number of vertexes of the AoI
		      coords  : array of vertex coordinates
		      point   : coordinates of the point to check

        $MODIFIED     NONE

        $OUTPUT       in_out  : indicator of the point position WRT the AoI:
				 -1  point out of the AoI;
				  0  point on the AoI borders;
				  1  point into the AoI;

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure checks if a point lies into a polygonal
		      AoI

        $WARNING      No formal check is made for the AoI: call the 
                      COORIP_AOIX_CheckAoI routine before

        $PDL	      - Evaluates the differences of the point coordinates
			WRT each AoI vertex
		      - Evaluates the distances between the point and each
		        vertex
		      - Loop on the vertex
		            - Evaluates the scalar product between the contigues
			      vectors distances
                            - Evaluates the vector product between them
			    - Sums the angles with their sign given by the sign
			      of the vector product component out of the vectors
			      plane
		      - End Loop
		      - Checks the point position using the value of the angles
		        sum

   $EH
   ========================================================================== */
void COORIP_AOIX_CheckPointInAoIS
			(/*IN    */ UINTx4               nVertex, 
			 /*IN    */ MATHIT_RC           *coords, 
                         /*IN    */ MATHIT_RC           *point, 
                         /*   OUT*/ INTx4               *in_out,
                         /*   OUT*/ ERRSIT_status       *status_code )
{  
   const ERRSIT_proc_name  routine_name = "COORIP_AOIX_CheckPointInAoIS";
   ERRSIT_status           log_status_code;
   ERRSIT_flag             process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                   nCount;
   double                  sum_angles;
   double                  sign_angles;
   double                  prod_scal;
   double                  prod_vect;
   double                  angles;
   double                  angles_sum;
   double                  acosarg;
   MATHIT_RC               diff[ COORPD_Max_Vertex ];
   double                  dist[ COORPD_Max_Vertex];
   float                   find;
   INTx4                   ind;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the number of vertex
   ========================================================================== */
   if ( ( nVertex < 3 ) || ( nVertex > COORPD_Max_Vertex ) ) {
      ERRSIM_set_error( status_code, ERRSID_COOR_few_vertex, "" );
   }

/* ==========================================================================
   Compute the difference of contigues vertices coodinates
   ========================================================================== */
   *in_out = -1;
   for ( nCount=0;nCount<nVertex; nCount++ ) {
      diff[nCount].row = (coords+nCount)->row - point->row;
      diff[nCount].col = (coords+nCount)->col - point->col;
 
/* ==========================================================================
   Check if the point overlay the vertex
   ========================================================================== */
      if ( ( diff[ nCount ].row == 0 ) && ( diff[ nCount ].col == 0 ) ) {
	 *in_out = 0;
         break;
      }
   }

/* ==========================================================================
   Compute the distances from the vertices
   ========================================================================== */
   if ( *in_out == -1 ) {
      for ( nCount=0;nCount< nVertex; nCount++ ) {
         dist[ nCount ] = sqrt( ( diff[ nCount ].row * diff[ nCount ].row ) +
                                ( diff[ nCount ].col * diff[ nCount ].col ) );
      }

/* ==========================================================================
   Compute the scalar product
   ========================================================================== */
      sum_angles = 0;
      for ( nCount=0;nCount< nVertex - 1; nCount++ ) {
         prod_scal = ( diff[ nCount ].row * diff[ nCount + 1 ].row ) +
                     ( diff[ nCount ].col * diff[ nCount + 1 ].col);
         prod_vect = -( diff[ nCount ].row * diff[ nCount + 1 ].col ) +
                      ( diff[ nCount ].col * diff[ nCount + 1 ].row );
         acosarg = prod_scal / ( dist[ nCount ] * dist[ nCount + 1 ] );
#ifdef __TRACE__
         if( ( (prod_scal / ( dist[ nCount ] * dist[ nCount + 1 ]) ) >  1.0 ) ||
             ( (prod_scal / ( dist[ nCount ] * dist[ nCount + 1 ]) ) < -1.0 ) ){

            fprintf( stderr, "prod_scal = %f\ndist[%0d] = %f\ndist[%0d] = %f\n\
div = %20.18f\n\n", prod_scal, nCount, dist[ nCount ], nCount + 1, 
                     dist[ nCount + 1 ], acosarg );
         }
#endif
         if( ABS( acosarg ) > (1 + COORLD_acos_epsilon) ) {
            char errmsg[ 132 ];
            sprintf( errmsg, "acos arg = %f", acosarg );
            ERRSIM_set_error( status_code, 
                              ERRSID_COOR_math_exception, 
                              errmsg )
         }

         angles = ACOS( prod_scal / ( dist[ nCount ] * dist[ nCount + 1 ] ) );
         if ( prod_vect < 0 )
            sum_angles -=  angles; 
         else
            if ( prod_vect >= 0 )
               sum_angles +=  angles;
      }
      prod_scal = ( diff[ nVertex - 1 ].row * diff[ 0 ].row ) +
                ( diff[ nVertex - 1 ].col * diff[ 0 ].col );
      prod_vect = - ( diff[ nVertex - 1 ].row * diff[ 0 ].col ) +
                    ( diff[ nVertex - 1 ].col * diff[ 0 ].row );

      angles = ACOS( prod_scal / ( dist[ nVertex - 1 ] * dist[ 0 ] ) );
      if ( prod_vect < 0 ) 
         sum_angles -=  angles;
      else
         if ( prod_vect >= 0 )
            sum_angles +=  angles;
   
/* ==========================================================================
   Evaluate the position through the absolute angle value
   ========================================================================== */
      sum_angles = ABS( sum_angles );
      if ( ( sum_angles < ( - COORID_AOIPRECISION ) ) ||
	   ( sum_angles > COORID_AOIPRECISION ) ) {

         ind = ROUND( ( sum_angles / PI ) );

	 find = ind % 2;

	 if ( find == 0. ) {
	    *in_out = 1;
	 }
	 else {
	    *in_out = 0;
	 }

      }

#ifdef __WHY__
      /* point into the AoI */
      if ( ( sum_angles > ( 2 * PI - COORID_AOIPRECISION ) ) &&
           ( sum_angles < ( 2 * PI + COORID_AOIPRECISION ) ) )
         *in_out = 1;
      /*  point on the Aoi borders */
      if ( ( sum_angles > ( PI - COORID_AOIPRECISION ) ) &&
	   ( sum_angles < ( PI + COORID_AOIPRECISION ) ) )
         *in_out = 0;
#endif
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                           *status_code, 
                          &log_status_code );

} /* COORIP_AOIX_CheckPointInAoIS */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CoverRect

        $TYPE	      PROCEDURE

        $INPUT        nVertex	    : number of vertex
                      coords	    : array of coordinates of the vertex

        $MODIFIED     NONE

        $OUTPUT       TopLeft       : coordinates of the Top Left corner of the
                                      rectangle covering the AoI
                      BottomRight   : coordinates of the Bottom Right corner of
                                      the rectangle covering the AoI

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_few_vertex
		      ERRSID_COOR_invalid_AoI

        $DESCRIPTION  This procedure computes the smallest rectangle including
		      the given AoI

        $WARNING      NONE

        $PDL          - Searches the minima Top Left corner coordinates
		      - Searches the maxima Bottom Right corner coordinates

   $EH
   ========================================================================== */
void COORIP_AOIX_CoverRect
			(/*IN    */ UINTx4              nVertex, 
			 /*IN    */ MATHIT_RC          *coords, 
			 /*   OUT*/ MATHIT_RC          *TopLeft, 
			 /*   OUT*/ MATHIT_RC          *BottomRight,
			 /*   OUT*/ ERRSIT_status      *status_code )
{
   const ERRSIT_proc_name  routine_name = "COORIP_AOIX_CoverRect";
   ERRSIT_status           log_status_code;
   ERRSIT_flag             process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   INTx4                   nCount;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the number of vertex
   ========================================================================== */
   if ( nVertex < 3 ) {
      ERRSIM_set_error( status_code, ERRSID_COOR_few_vertex, "" );
   }

/* ==========================================================================
   Initialize the corners coordinates
   ========================================================================== */
   TopLeft->row = coords->row;
   BottomRight->row = coords->row;
   TopLeft->col = coords->col;
   BottomRight->col = coords->col;

/* ==========================================================================
   Search for the minima top left and the maxima bottom right coordinates
   ========================================================================== */
   for ( nCount=1;nCount< nVertex; nCount++ ) {

      /* Top Left coordinates */
      if ( ( coords + nCount )->row < TopLeft->row )
         TopLeft->row = ( coords + nCount )->row;
      if ( ( coords + nCount )->col < TopLeft->col )
         TopLeft->col = ( coords + nCount )->col;

      /* Bottom Right coordinates */
      if ( ( coords + nCount )->row > BottomRight->row )
         BottomRight->row = ( coords + nCount )->row;
      if ( ( coords + nCount )->col > BottomRight->col )
         BottomRight->col = ( coords + nCount )->col;
   }

/* ==========================================================================
   Chec if the rectangle degenerate
   ========================================================================== */
   if ( ( TopLeft->row == BottomRight->row ) ||
	( TopLeft->col == BottomRight->col) ) {
      ERRSIM_set_error( status_code, ERRSID_COOR_invalid_AoI, "" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* COORIP_AOIX_CoverRect */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CheckRect

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     TopLeft	    : input row, col coordinates of the Top Left
				      corner
		      BottomRight   : input row, col coordinates of the Bottom
				      Right corner

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_COOR_invalid_AoI

        $DESCRIPTION  This procedure checks and, if it is possible, fixs the
		      rectangular array of AoI coordinates

        $WARNING      The first point is the top-left corner, the others
		      follow clockwise.

	$PDL	      - Checks if the coordinates defines a line or a point
		      - Exchanges the corners coordinates if they are not
		        in the right order
   $EH
   ========================================================================== */
void COORIP_AOIX_CheckRect
			(/*IN OUT*/ MATHIT_RC           *TopLeft, 
			 /*IN OUT*/ MATHIT_RC           *BottomRight,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name  routine_name = "COORIP_AOIX_CheckRect";
   ERRSIT_status           log_status_code;
   ERRSIT_flag             process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                   nCount;
   char                   *message;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the coordinates
   ========================================================================== */
   if ( ( TopLeft->row == BottomRight->row ) ||
        ( TopLeft->col == BottomRight->col ) ) {

/* ==========================================================================
   The square is a line or a point
   ========================================================================== */
      ERRSIM_set_error( status_code, ERRSID_COOR_invalid_AoI, "" );
   }

/* ==========================================================================
   Check for exchanged coordinates: row ...
   ========================================================================== */
   if ( TopLeft->row > BottomRight->row ) {
      double                  dRow;

      dRow = TopLeft->row;
      TopLeft->row = BottomRight->row;
      BottomRight->row = dRow;
      ERRSIM_print_warning( "AoI RECOVERED: Exchanged TLRow and BRRow" );
   }

/* ==========================================================================
   ... columns
   ========================================================================== */
   if ( TopLeft->col > BottomRight->col ) {
      double                  dCol;

      dCol = TopLeft->col;
      TopLeft->col = BottomRight->col;
      BottomRight->col = dCol;
      ERRSIM_print_warning( "AoI RECOVERED: Exchanged TLCol and BRCol" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* COORIP_AOIX_CheckRect */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         COORIP_AOIX_CheckPointInRect

        $TYPE	      PROCEDURE

        $INPUT        TopLeft	    : Top Left row, col coordinates of the
				      rectangular area
		      BottomRight   : Bottom Right row, col coordinates of the
				      rectangular area
		      point	    : coordinates of the point to check

        $MODIFIED     NONE

        $OUTPUT       in_out	    : flag to indicate the point position WRT
				      the rectangular area
				       - 1        point into the rectangle
				       - 0        point on the rectangular
						  borders
				       - -1       point out of the rectangle

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure checks if a point is into a rectangular AoI

        $WARNING      No formal check is made for the rect AoI: call the 
                      COORIP_AOIX_RectCheckAoI routine before

        $PDL	      - Checks if the point is on the rectangular borders
		      - Checks if the point is internal of the rectangle

   $EH
   ========================================================================== */
void COORIP_AOIX_CheckPointInRect 
			(/*IN    */ MATHIT_RC           *TopLeft, 
			 /*IN    */ MATHIT_RC           *BottomRight,
			 /*IN    */ MATHIT_RC           *point,
			 /*   OUT*/ INTx4               *in_out,
			 /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name  routine_name = "COORIP_AOIX_CheckPointInRect";
   ERRSIT_status           log_status_code;
   ERRSIT_flag             process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check if the point is on the borders
   ========================================================================== */
   *in_out = 1;
   if ( ( point->row == BottomRight->row ) ||
        ( point->row == TopLeft->row ) ||
        ( point->col == BottomRight->col ) ||
        ( point->col == TopLeft->col ) )
      *in_out = 0;

/* ==========================================================================
   Check if the point is in the rectangle
   ========================================================================== */
   if ( ( point->row > BottomRight->row ) ||
        ( point->row < TopLeft->row ) ||
        ( point->col > BottomRight->col ) ||
        ( point->col < TopLeft->col ) )
      *in_out = -1;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* COORIP_AOIX_CheckPointInRect */

