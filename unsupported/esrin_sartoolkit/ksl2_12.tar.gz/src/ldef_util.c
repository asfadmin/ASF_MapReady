/* ==========================================================================
   $MODULE_HEADER

      $NAME              LDEF_UTIL

      $FUNCTION          General utility procedures and functions

      $ROUTINE           LDEFIF_UTIL_strnmatch
                         LDEFIP_UTIL_get_unique_id
                         LDEFIP_UTIL_gen_tmp_name

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       23-MAY-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#ifdef __UNIX__
#include <sys/types.h>
#include <sys/stat.h>
#include <ustat.h>
#include <unistd.h>
#include <errno.h>
#endif

#ifdef __DOS__
#include <dos.h>
#include <process.h>
#endif

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include LDEF_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIF_UTIL_strnmatch

        $TYPE         FUNCTION

        $INPUT        str1  : string to match with the other. Its number of
                              character must be lesser or equal then the
                              number of the second string
                      str2  : string in which to search the first

        $MODIFIED     NONE

        $OUTPUT       a status code that can be 0 = the string match
                                                1 = no match
                                              - 1 = memory allocation error
                                                    has occurred
                                              - 2 = the second string is lesser
                                                    then the first

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_LDEF_first_longer
                      ERRSID_LDEF_err_mem_alloc

        $DESCRIPTION  This function returns a flag indicating if the two string
                      match together

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

INTx1 LDEFIF_UTIL_strnmatch
                        (/*IN    */ char                *str1,
                         /*IN    */ char                *str2,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "LDEFIF_UTIL_strnmatch";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   char                  *p = NULL;
   char                  *s = NULL;
   INTx4                  i = 0;
   INTx1                  res = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the number of character
   ========================================================================== */
   if ( strlen(str2) < strlen(str1) ) {

      /* no possible match searching */
      res = -2;
      goto error_exit;
   }

   p = str2;

   /* copy the second string to avoid the border effect */
   s = (char *) MEMSIP_alloc( (size_t)((strlen(str2) + strlen(str1))*sizeof(char)));
   if ( s == NULL ) {
      res = -1;
      ERRSIM_set_error(status_code,ERRSID_LDEF_no_mem_allocated,"");
   }
   strncpy( s, str2, strlen(str2) );

   /* do while a correspondence has been found */
   do {
      p = strpbrk( p, str1);  /* search for the first corresponding character */
      if ( p == NULL ) goto out;
      p++;
      i++;

   } while ( !( strncmp( p-1, str1, strlen(str1) ) == 0 ) );

   /* succesfull match */
   if ( s != NULL ) MEMSIP_free( (void **) &s );
   res = 0;
   goto error_exit;

out:;

   /* no correspondence */
   if ( s != NULL ) MEMSIP_free( (void **) &s );
   res = 1;

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   if ( s != NULL ) MEMSIP_free( (void **) &s );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return res;

}/* LDEFIF_UTIL_strnmatch */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         LDEFIP_UTIL_get_unique_id

      $TYPE         PROCEDURE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       unique_id                 : unique id

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  Generates an unique id of 5 characters for the current
                    process.

      $WARNING      NONE

   $EH
   ========================================================================== */
void LDEFIP_UTIL_get_unique_id
                        (/*   OUT*/ ERRSIT_unique_id  *unique_id,
                         /*   OUT*/ ERRSIT_status     *status_code )
{
   const ERRSIT_proc_name routine_name = "LDEFIP_UTIL_get_unique_id";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   time_t                 start_time;
   time_t                 curr_time;
   double                 diff_time;
   char                   numb[ LDEFID_char_line ];
   char                   num5[6];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code     = STC( ERRSID_normal );
   log_status_code  = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Zero in the utility strings
   ========================================================================== */
   memset(numb,'\0',LDEFID_char_line);
   memset(num5,'\0',6);

/* ==========================================================================
   Compute the difference between current time and start time.
   ========================================================================== */
   start_time = (time_t) LDEFPD_start_time;
   time( &curr_time );

#ifdef __VMS__
   diff_time = difftime( curr_time, start_time );
#else
   diff_time = curr_time - start_time;
#endif

   *unique_id = LDEFLM_abs( (int) diff_time);

/* ==========================================================================
   Verify that the unique ID length is less than 5 char.
   ========================================================================== */
   sprintf(numb,"%u",*unique_id);
   memcpy(num5,numb+strlen(numb)-5,5);
   *(unique_id) = (ERRSIT_unique_id)atol(num5);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

}/* LDEFIP_UTIL_get_unique_id */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         LDEFIP_UTIL_gen_tmp_name

      $TYPE         PROCEDURE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       tmp_name                  : unique file name

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  Generates an unique file name of the current process.

      $WARNING      tmp_name shall be allocated

   $EH
   ========================================================================== */
void LDEFIP_UTIL_gen_tmp_name
                        (/*   OUT*/ char              *tmp_name,
                         /*   OUT*/ ERRSIT_status     *status_code )
{
   const ERRSIT_proc_name routine_name = "LDEFIP_UTIL_gen_tmp_name";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   ERRSIT_unique_id       unique_id;
   FILE                  *fp = (FILE *) NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code     = STC( ERRSID_normal );
   log_status_code  = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Generates a unique file ID
   ========================================================================== */
   LDEFIP_UTIL_get_unique_id( &unique_id, status_code );
   ERRSIM_on_err_goto_exit( *status_code );


   do {

/* ==========================================================================
   Checks limit and increments
   ========================================================================== */
      if( unique_id >= 99999 ) {
         unique_id = 0;
      }
      unique_id++;

/* ==========================================================================
   Close previously open file
   ========================================================================== */
      if( fp != (FILE *) NULL ) {
         fclose( fp );
      }

/* ==========================================================================
   Create the file name
   ========================================================================== */
      memset( tmp_name, '\0', sizeof( tmp_name ) );
      sprintf( tmp_name, "%s%s%05u%c%s", 
                         LDEFIV_temp_dir, LDEFIV_tmp_id_name,
                         unique_id, '.', LDEFIV_tmp_ext_name );

/* ==========================================================================
   Check if the file already exists
   ========================================================================== */
      fp = fopen( tmp_name, "r" );

   } while (fp != (FILE *) NULL);


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

}/* LDEFIP_UTIL_gen_tmp_name */


#ifdef __SUBS__
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         LDEFIP_UTIL_

      $TYPE         PROCEDURE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  

      $WARNING      

   $EH
   ========================================================================== */
void LDEFIP_UTIL_
                        (/*IN    */ 
                         /*   OUT*/ ERRSIT_status     *status_code )
{
   const ERRSIT_proc_name routine_name = "LDEFIP_UTIL_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code     = STC( ERRSID_normal );
   log_status_code  = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Please put code hereinafter
   ========================================================================== */

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code,
                          &log_status_code );

}/* LDEFIP_UTIL_ */
#endif
