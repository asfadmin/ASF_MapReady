/* ==========================================================================
   $MODULE_HEADER

      $NAME              IANN_MPHP

      $FUNCTION          This module contains the procedures for the tags
                         translation from the MPH - SPH format into
                         SAR Toolbox like annotations

      $ROUTINE           IANNIP_MPHP_GetAnnotations
                         IANNIP_MPHP_PutAnnotations
                         IANNPP_MPHP_set_month
                         IANNIP_MPHP_AnnotDump 

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       11-FEB-98     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>
#include <string.h>
#include <math.h>

#include "defl_libname_intf.h"
#include IANN_TAGS_H

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include TIFS_INTF_H
#include MATH_INTF_H
#include IANN_INTF_H
#include IANN_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_MPHP_GetAnnotations

        $TYPE         PROCEDURE

        $INPUT        chan   : channel of the input TIFF file
                      img    : image ID in the input TIFF file
                      imanum : progressive number of the image
                      bpar          : basic parameters of the input file

        $MODIFIED     NONE

        $OUTPUT       The global structure with the <imanum> image annotations
                      stored

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the image
                                                  annotations that must be
                                                  filled
                      IANNPV_found_tag          : a vector of boolean values
                                                  that are TRUE or FALSE
                                                  according to the existence
                                                  or not of the tag in the MPH
                                                  -SPH input file

        $RET_STATUS   ERRSID_IANN_not_allow_imanum
                      ERRSID_LDEF_first_longer

        $DESCRIPTION  This procedure gets the MPH-SPHlike image annotations
                      from the input TIFF file and fill with them the image
                      annotations structure

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void IANNIP_MPHP_GetAnnotations
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ TIFSIT_basicpar      bpar,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNIP_MPHP_GetAnnotations";
   ERRSIT_status          log_status_code; 
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   TIFSIT_par             param;
   INTx4                  comp = -1;
   INTx4                  I4num;
   INTx2                  I2num;
   INTx1                  Bnum;
   double                 dnum;
   char                  *ptr = (char *)NULL;
   char                   numb[ 4 ] = "";
   char                   sst[ LDEFID_char_line ];
   char                   ref[ LDEFID_char_line ];
   INTx4                  i;
   INTx4                  tag_count = -1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image index
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) {
      sprintf ( numb, "%0d", imanum );
      ERRSIM_set_error ( status_code, ERRSID_IANN_not_allow_imanum, numb );
   }

/* ==========================================================================
   Initialize the structure with the image annotations
   ========================================================================== */
   memset ( &IANNIV_ImageAnnot[ imanum ], '\0',
           (size_t)sizeof ( IANNIT_ImageAnnot ) );

/* ==========================================================================
   Initialize the vector of the tags ( all TRUE = found )
   ========================================================================== */
   for ( i=0; i<IANNID_ImageAnnotMaxNumber; i++ ) {
      IANNPV_found_tag[ i ] = TRUE;
   }

/* ==========================================================================
   Fill the basic parameters section of the image annotation
   ========================================================================== */
   IANNIV_ImageAnnot[ imanum ].ImageWidth = (INTx4)bpar.imagewidth;
   IANNIV_ImageAnnot[ imanum ].ImageLength = (INTx4)bpar.imagelength;
   IANNIV_ImageAnnot[ imanum ].SamplePerPixel = (INTx2)bpar.sampleperpixel;
   for ( i=0;i<IANNIV_ImageAnnot[ imanum ].SamplePerPixel;i++ ) {
      IANNIV_ImageAnnot[ imanum ].BitsPerSample[ i ] =
         (INTx2)bpar.bitspersample[ 0 ];
   }
   for (i=0;i<IANNIV_ImageAnnot[ imanum ].SamplePerPixel;i++) {
      IANNIV_ImageAnnot[ imanum ].SampleFormat[ i ] =
         (INTx1)bpar.sampleformat[ 0 ];
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   General info section
   ========================================================================== */
   tag_count++;
   param.tag = SENSOR_PLAT_MISSION_ID;                        /* mission type */
   IANNIV_ImageAnnot[ imanum ].ProductType = IANNIE_prod_undef;
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      I4num = (INTx4)atoi ( param.val );

/* ==========================================================================
   Switch over ERS-1 or ERS-2
   ========================================================================== */
      switch ( I4num ) {
         case 1:

/* ==========================================================================
            Do not dump errors to terminal, if any
   ========================================================================== */
            ERRSIV_dump_error = 0;

            /* ERS-1 product */
            param.tag = LOG_VOL_ID;            /* product type */
            TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
            Reset dumping
   ========================================================================== */
            ERRSIV_dump_error = 1;

            if ( *status_code != ERRSID_normal ) {
               IANNPV_found_tag[ tag_count ] = FALSE;
               *status_code = STC ( ERRSID_normal );
            }
            else {
               ptr = param.val;
               strupr( ptr );

               comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_prod[ 0 ], ptr,
                                              status_code );
               ERRSIM_on_err_goto_exit ( *status_code );
               if ( comp == 0 ) {                    /* RAW product */
                  IANNIV_ImageAnnot[ imanum ].ProductType =
                     IANNIE_prod_ERS1_RAW;
               }
               else if ( comp == 1 ) {
                  comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_prod[ 1 ], ptr,
                                                 status_code );
                  ERRSIM_on_err_goto_exit ( *status_code );
                  if ( comp == 0 ) {                    /* SLC product */
                     IANNIV_ImageAnnot[ imanum ].ProductType =
                        IANNIE_prod_ERS1_SLC;
                  }

                  comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_prod[ 2 ], ptr,
                                                 status_code );
                  ERRSIM_on_err_goto_exit ( *status_code );
                  if ( comp == 0 ) {                    /* SLCI product */
                     IANNIV_ImageAnnot[ imanum ].ProductType =
                        IANNIE_prod_ERS1_SLCI;
                  }

                  comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_prod[ 3 ], ptr,
                                                 status_code );
                  ERRSIM_on_err_goto_exit ( *status_code );
                  if ( comp == 0 ) {                    /* PRI product */
                     IANNIV_ImageAnnot[ imanum ].ProductType =
                        IANNIE_prod_ERS1_PRI;
                  }
               }
               else if ( comp == -2 ) {
                  memset ( sst, '\0', LDEFID_char_line );
                  sprintf ( sst, "%s%s%0u", LDEFIV_ERRS_error_message[
                            ERRSID_LDEF_first_longer ], " for the tag: ",
                            LOG_VOL_ID );
               }
            }
         break;
         case 2:

/* ==========================================================================
            Do not dump errors to terminal, if any
   ========================================================================== */
            ERRSIV_dump_error = 0;

            /* ERS-2 product */
            param.tag = LOG_VOL_ID;            /* product type */
            TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
            Reset dumping
   ========================================================================== */
            ERRSIV_dump_error = 1;

            if ( *status_code != ERRSID_normal ) {
               IANNPV_found_tag[ tag_count ] = FALSE;
               *status_code = STC ( ERRSID_normal );
            }
            else {
               ptr = param.val;
               strupr( ptr );

               comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_prod[ 0 ], ptr,
                                              status_code );
               ERRSIM_on_err_goto_exit ( *status_code );
               if ( comp == 0 ) {                    /* RAW product */
                  IANNIV_ImageAnnot[ imanum ].ProductType =
                     IANNIE_prod_ERS2_RAW;
               }
               else if ( comp == 1 ) {
                  comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_prod[ 1 ], ptr,
                                                 status_code );
                  ERRSIM_on_err_goto_exit ( *status_code );
                  if ( comp == 0 ) {                    /* SLC product */
                     IANNIV_ImageAnnot[ imanum ].ProductType =
                        IANNIE_prod_ERS2_SLC;
                  }

                  comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_prod[ 2 ], ptr,
                                                 status_code );
                  ERRSIM_on_err_goto_exit ( *status_code );
                  if ( comp == 0 ) {                    /* SLCI product */
                     IANNIV_ImageAnnot[ imanum ].ProductType =
                        IANNIE_prod_ERS2_SLCI;
                  }

                  comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_prod[ 3 ], ptr,
                                                 status_code );
                  ERRSIM_on_err_goto_exit ( *status_code );
                  if ( comp == 0 ) {                    /* PRI product */
                     IANNIV_ImageAnnot[ imanum ].ProductType =
                        IANNIE_prod_ERS2_PRI;
                  }
               }
               else if ( comp == -2 ) {
                  memset ( sst, '\0', LDEFID_char_line );
                  sprintf ( sst, "%s%s%0u", LDEFIV_ERRS_error_message[
                            ERRSID_LDEF_first_longer ], " for the tag: ",
                            LOG_VOL_ID );
               }
            }
         break;
      }

/* ==========================================================================
   Control if some memories has been allocated and deallocate them
   ========================================================================== */
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( (void **)&param.val );
      }
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   tag_count++;
   param.tag = DATA_FORMAT;             /* media data format */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNPV_found_tag[ tag_count ] = FALSE;
      *status_code = STC( ERRSID_normal );
   }
   else {
      sprintf( IANNIV_ImageAnnot[ imanum ].dataFormat,
	       (char *)param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   tag_count++;
   param.tag = SOURCE_ID;             /* media source */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNPV_found_tag[ tag_count ] = FALSE;
      *status_code = STC( ERRSID_normal );
   }
   else {
      sprintf( IANNIV_ImageAnnot[ imanum ].sourceId,
	       (char *)param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   tag_count++;
   param.tag = NUMBER_OF_VOLUMES;      /* null lines */
   TIFSIP_get_par( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNPV_found_tag[ tag_count ] = FALSE;
      *status_code = STC( ERRSID_normal );
   }
   else {
      IANNIV_ImageAnnot[ imanum ].numberOfVolumes= (INTx4)atoi( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 )
         MEMSIP_free( &param.val );
   }

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

/* ==========================================================================
   Search for orbit and frame
   ========================================================================== */
   tag_count++;
   param.tag = ORBIT_NUM;         /* orbit number */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      memset ( sst, '\0', LDEFID_char_line );
      sprintf ( sst, "ORBIT: %4d - ", param.tag );

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = FRAME_NUM;      /* frame number */
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         *status_code = STC( ERRSID_normal );
         IANNPV_found_tag[ tag_count ] = FALSE;
      }
      else {
         sprintf ( IANNIV_ImageAnnot[ imanum ].SceneReferenceNumbers,
                   "%sFRAME: %4d", sst, param.tag );
      }
   }

/* ==========================================================================
   Count the processing PAF
   ========================================================================== */
   tag_count++;
   IANNPV_found_tag[ tag_count ] = FALSE;


   tag_count++;
/*
   param.tag = PROCESSOR_NAME; */          /* ID of the SW processing the image */
/*
   IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_undef;

   TIFSIP_get_par ( chan, img, &param, status_code );
   if ( *status_code != ERRSID_normal ) {
      *status_code = STC( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      ptr = param.val;
      strupr ( ptr );

      comp = -1;
      comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_swproc[ 0 ], ptr,
                                     status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == -2 ) {
         memset ( sst, '\0', LDEFID_char_line );
         sprintf ( sst, "%s%s%0u", LDEFIV_ERRS_error_message[
                   ERRSID_LDEF_first_longer ], " for the tag: ",
                   PROCESSOR_NAME );
         ERRSIM_print_warning ( sst );
      }
      else {
         if ( comp == 0 ) {
            IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_VMP;
         }

         comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_swproc[ 1 ], ptr,
                                        status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 ) {
            IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_ESAR;
         }

         comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_swproc[ 2 ], ptr,
                                        status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
         if ( comp == 0 ) {
            IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_Bangkok;
         }
      }
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }
*/


/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = PROCESSOR_NAME;           /* ID of the SW processing the image */
   IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_undef;

   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      ptr = param.val;
      strupr ( ptr );

      comp = -1;
      comp = LDEFIF_UTIL_strnmatch ( (char *)IANNPC_swproc[ 2 ], ptr,
                                     status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      if ( comp == -2 ) {
         memset ( sst, '\0', LDEFID_char_num );
         sprintf ( sst, "%s%s%0u", LDEFIV_ERRS_error_message[
                   ERRSID_LDEF_first_longer ], " for the tag: ",
                   PROCESSOR_NAME );
         ERRSIM_print_warning ( sst );
      }
      else {
         if ( comp == 0 ) {
            IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_ESAR;
         }
         else {
            ERRSIM_print_warning ( "Processor name set to VMP" );
            IANNIV_ImageAnnot[ imanum ].ProcessorName = IANNIE_sproc_VMP;
         }
      }
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

/* ==========================================================================
   Calibration section
   ========================================================================== */
   tag_count++;
   param.tag = ABSOLUTE_CALIB_KX;      /* exponential part of the calibration */
                                       /* constant                            */

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      IANNPV_found_tag[ tag_count ] = FALSE;
      *status_code = STC ( ERRSID_normal );
   }
   else {
      I2num = (INTx2)atoi ( param.val );

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = ABSOLUTE_CALIB_KY;     /* mantissa part of the calibration */
                                         /* constant                         */
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         IANNPV_found_tag[ tag_count ] = FALSE;
         *status_code = STC ( ERRSID_normal );
      }
      else {
         I4num = (INTx4)atoi ( param.val );
         IANNIV_ImageAnnot[ imanum ].CalibrationConstant = (float)
            (I4num * POW ( 10., I2num ) * 1e-05);
         if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
            MEMSIP_free ( &param.val );
         }
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = INCID_ANGLE_CENTRE_RANGE;      /* incidence angle */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].IncidenceAngleAtMiddleRange_deg = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;
   IANNIV_ImageAnnot[ imanum ].BoresightAngle_deg = IANNPD_boresigth_angle_deg;

/* ==========================================================================
   Corners coordinates section
   ========================================================================== */
   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = TOP_LEFT_LAT;      /* top left latitude*/
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].TopLeftLat_deg = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = TOP_LEFT_LON;      /* top left longitude */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = TOP_RIGHT_LAT;      /* top right latitude*/
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].TopRightLat_deg = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = TOP_RIGHT_LON;      /* top right longitude */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].TopRightLon_deg = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = BOTTOM_LEFT_LAT;      /* bottom left latitude*/
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = BOTTOM_LEFT_LON;      /* bottom left longitude */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = BOTTOM_RIGHT_LAT;      /* bottom right latitude*/
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].BottomRightLat_deg = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = BOTTOM_RIGHT_LON;      /* bottom right longitude */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CENTRE_GEODETIC_LAT;    /* latitude of the image center */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg =
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CENTRE_GEODETIC_LON;    /* longitude of the image center */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg =
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

/* ==========================================================================
   The zero filled pixels and lines are not found
   ========================================================================== */
   for ( i=1; i<=4; i++ ) {
      IANNPV_found_tag[ ++tag_count ] = FALSE;
   }

/* ==========================================================================
   MAP Projection section
   ========================================================================== */
   tag_count++;
   IANNIV_ImageAnnot[ imanum ].MapProjectionType = IANNIE_proj_undef;
   switch ( IANNIV_ImageAnnot[ imanum ].ProductType  ) {
      case IANNIE_prod_ERS1_RAW:
      case IANNIE_prod_ERS2_RAW:
      case IANNIE_prod_ERS1_SLC:
      case IANNIE_prod_ERS2_SLC:
      case IANNIE_prod_ERS1_SLCI:
      case IANNIE_prod_ERS2_SLCI:
         IANNIV_ImageAnnot[ imanum ].MapProjectionType = IANNIE_proj_slant;
      break;
      case IANNIE_prod_ERS1_PRI:
      case IANNIE_prod_ERS2_PRI:
         IANNIV_ImageAnnot[ imanum ].MapProjectionType = IANNIE_proj_ground;
   }

/* ==========================================================================
   The projection not found tags
   ========================================================================== */
   for ( i=1; i<=7; i++ ) {
      IANNPV_found_tag[ ++tag_count ] = FALSE;
   }

/* ==========================================================================
   Spacing section
   ========================================================================== */
   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = LINE_SPACING;      /* spacing in rows direction */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].LineSpacing_m = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = PIXEL_SPACING;      /* spacing in the col direction */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].PixelSpacing_m = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

/* ==========================================================================
   Timing section
   ========================================================================== */

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = STATE_VECT_UTC_TIME;     /* time of the first state vector */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      for ( i=1; i<=4; i++ ) {
         IANNPV_found_tag[ ++tag_count ] = FALSE;
      }
   }
   else {
      tag_count += 4;
      ptr = param.val;
      memset ( sst, '\0', LDEFID_char_line );

      /* copy the day ... */
      strncpy ( sst, ptr, 2 );
      IANNIV_ImageAnnot[ imanum ].FirstSTVectDay = (INTx2)atoi ( sst );

      /* ... the month ... */
      strncpy ( sst, ptr + 3, 3 );
      IANNPP_MPHP_set_month ( sst, &I2num, status_code );
      if ( I2num != 0 ) {
         IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth = (INTx2)I2num;
      }

      /* ... the year ... */
      strncpy ( sst, ptr + 7, 4 );
      IANNIV_ImageAnnot[ imanum ].FirstSTVectYear = (INTx2)atoi ( sst );

      /* ... the seconds */
      memset ( ref, '\0', LDEFID_char_line );
      strncpy ( ref, ptr, 11 );
      strcat ( ref, " 00:00:00.000" );
      LDEFIP_DATE_DiffDate ( ptr, ref, &dnum, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds = dnum *
         IANNPD_sec_in_a_day;

      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = ZERO_DOPP_AZIM_FIRST_TIME;     /* time of the first image line */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      sprintf ( IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                (char *)param.val );
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = ZERO_DOPP_AZIM_LAST_TIME;       /* time of the last image line */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ ++tag_count ] = FALSE;
   }
   else {
      sprintf ( IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthLastLine_UTC,
                (char *)param.val );
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;
   IANNIV_ImageAnnot[ imanum ].RadarWaveLength_m = IANNPD_radar_wavelength_m;

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = SAMPLING_RATE;      /* sampling rate */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ ++tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz = (float) atoi ( param.val );
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = ZERO_DOPP_RANGE_FIRST_TIME;
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ ++tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec =
         (float)(atoi ( param.val ) * 1.e-09);            /* from nsec to sec */
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = PRF;      /* pulse rep. freq. */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ ++tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz =
         (float)(atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

/* ==========================================================================
   Count the equivalent PRF not found
   ========================================================================== */
   IANNPV_found_tag[ ++tag_count ] = FALSE;

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CROSS_DOPP_FREQ_CONST; /* first coeff. of the doppler centr. */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ 0 ] = (float)
         (atoi ( param.val ) * 1e-03);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CROSS_DOPP_FREQ_LINEAR; /* second coeff. of the doppler centr. */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ 1 ] = (float)
         atoi ( param.val );
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = CROSS_DOPP_FREQ_QUAD; /* third coeff. of the doppler centr. */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ 2 ] = (float)
         (atoi ( param.val ) * 1e+06);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = DOPPL_CENTR_CUB_COEFF; /* fourth coeff. of the doppler centr. */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ 3 ] = (float)
         (atoi ( param.val ) * 1e+12);
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

/* ==========================================================================
   Ellipsoid section
   ========================================================================== */
   tag_count++;
   IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m = (float)
      IANNPD_semimajor_axis_km * ( 1.e+3 );                /* from km to m */
   tag_count++;
   IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m = (float)
      IANNPD_semiminor_axis_km * ( 1.e+3 );                /* from km to m */

/* ==========================================================================
   State vectors section
   ========================================================================== */
   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = TIME_INTERVAL_DATA_POINT;       /* state vectors time interval */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec = (float)
         (atoi ( param.val ) * 1e-03);                    /* from msec to sec */
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;
   IANNIV_ImageAnnot[ imanum ].NStateVectors = IANNPD_MPHSPH_N_STVec;

   /* retrive the state vectors */
   for ( i=0; i<IANNPD_MPHSPH_N_STVec; i++ ) {

      /* x state vectors */
      tag_count++;

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = (X_SAT_1+i);                       /* satellites x position */
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         *status_code = STC ( ERRSID_normal );
         IANNPV_found_tag[ tag_count ] = FALSE;
      }
      else {
         IANNIV_ImageAnnot[ imanum ].X_STVec_m[ i ] = (float)
            (atoi ( param.val ) * 1e-02);                     /* from cm to m */
         if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
            MEMSIP_free ( &param.val );
         }
      }
   }
   for ( i=0; i<IANNPD_MPHSPH_N_STVec; i++ ) {

      /* y state vectors */
      tag_count++;

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = (Y_SAT_1+i);                       /* satellites y position */
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         *status_code = STC ( ERRSID_normal );
         IANNPV_found_tag[ tag_count ] = FALSE;
      }
      else {
         IANNIV_ImageAnnot[ imanum ].Y_STVec_m[ i ] = (float)
            (atoi ( param.val ) * 1e-02);                     /* from cm to m */
         if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
            MEMSIP_free ( &param.val );
         }
      }
   }
   for ( i=0; i<IANNPD_MPHSPH_N_STVec; i++ ) {

      /* z state vectors */
      tag_count++;

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = (Z_SAT_1+i);                       /* satellites z position */
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         *status_code = STC ( ERRSID_normal );
         IANNPV_found_tag[ tag_count ] = FALSE;
      }
      else {
         IANNIV_ImageAnnot[ imanum ].Z_STVec_m[ i ] = (float)
            (atoi ( param.val ) * 1e-02);                     /* from cm to m */
         if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
            MEMSIP_free ( &param.val );
         }
      }
   }
   for ( i=0; i<IANNPD_MPHSPH_N_STVec; i++ ) {

      /* Vx state vectors */
      tag_count++;

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = (VX_SAT_1+i);                      /* satellites x velocity */
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         *status_code = STC ( ERRSID_normal );
         IANNPV_found_tag[ tag_count ] = FALSE;
      }
      else {
         IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[ i ] = (float)
            (atoi ( param.val ) * 1e-05);
         if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
            MEMSIP_free ( &param.val );
         }
      }
   }
   for ( i=0; i<IANNPD_MPHSPH_N_STVec; i++ ) {

      /* Vy state vectors */
      tag_count++;

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = (VY_SAT_1+i);                      /* satellites y velocity */
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         *status_code = STC ( ERRSID_normal );
         IANNPV_found_tag[ tag_count ] = FALSE;
      }
      else {
         IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[ i ] = (float)
            (atoi ( param.val ) * 1e-05);
         if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
            MEMSIP_free ( &param.val );
         }
      }
   }
   for ( i=0; i<IANNPD_MPHSPH_N_STVec; i++ ) {

      /* Vz state vectors */
      tag_count++;

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = (VZ_SAT_1+i);                      /* satellites z velocity */
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         *status_code = STC ( ERRSID_normal );
         IANNPV_found_tag[ tag_count ] = FALSE;
      }
      else {
         IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[ i ] = (float)
            (atoi ( param.val ) * 1e-05);
         if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
            MEMSIP_free ( &param.val );
         }
      }
   }

/* ==========================================================================
   Ground to slant parameters section
   ========================================================================== */
   tag_count++;
   IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree = IANNPD_VMP_GR2SR_degree;

/* ==========================================================================
   Search for the coefficients
   ========================================================================== */

   /* constant coefficient components */
   tag_count++; 

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = GR_SR_POL_C0_F;
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      I4num = (INTx4)atoi ( param.val );
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = GR_SR_POL_C0_E;
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         *status_code = STC ( ERRSID_normal );
         IANNPV_found_tag[ tag_count ] = FALSE;
      }
      else {
         I2num = (INTx2)atoi ( param.val );
         if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
            MEMSIP_free ( &param.val );
         }

/* ==========================================================================
         Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         param.tag = GR_SR_POL_C0_B;
         TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            *status_code = STC ( ERRSID_normal );
            IANNPV_found_tag[ tag_count ] = FALSE;
         }
         else {
            Bnum = (INTx1)atoi ( param.val );
            if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
               MEMSIP_free ( &param.val );
            }
            IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff[ 0 ] = (double)
               ( POW ( -1., Bnum ) * POW ( 2., ( I2num - 128 ) ) *
               ( 0.5 + (float)I4num / IANNPD_MPHSPH_GR2SR_div ) );
         }
      }
   }

   /* linear coefficient components */

   tag_count++;
/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = GR_SR_POL_C1_F;
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      I4num = (INTx4)atoi ( param.val );
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = GR_SR_POL_C1_E;
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         *status_code = STC ( ERRSID_normal );
         IANNPV_found_tag[ tag_count ] = FALSE;
      }
      else {
         I2num = (INTx2)atoi ( param.val );
         if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
            MEMSIP_free ( &param.val );
         }

/* ==========================================================================
         Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         param.tag = GR_SR_POL_C1_B;
         TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            *status_code = STC ( ERRSID_normal );
            IANNPV_found_tag[ tag_count ] = FALSE;
         }
         else {
            Bnum = (INTx1)atoi ( param.val );
            if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
               MEMSIP_free ( &param.val );
            }
            IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff[ 1 ] = (double)
               ( POW ( -1., Bnum ) * POW ( 2., ( I2num - 128 ) ) *
               ( 0.5 + (float)I4num / IANNPD_MPHSPH_GR2SR_div ) );
         }
      }
   }

   /* quadratic coefficient components */
   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = GR_SR_POL_C2_F;
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      I4num = (INTx4)atoi ( param.val );
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = GR_SR_POL_C2_E;
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         *status_code = STC ( ERRSID_normal );
         IANNPV_found_tag[ tag_count ] = FALSE;
      }
      else {
         I2num = (INTx2)atoi ( param.val );
         if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
            MEMSIP_free ( &param.val );
         }

/* ==========================================================================
         Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         param.tag = GR_SR_POL_C2_B;
         TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            *status_code = STC ( ERRSID_normal );
            IANNPV_found_tag[ tag_count ] = FALSE;
         }
         else {
            Bnum = (INTx1)atoi ( param.val );
            if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
               MEMSIP_free ( &param.val );
            }
            IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff[ 2 ] = (double)
               ( POW ( -1., Bnum ) * POW ( 2., ( I2num - 128 ) ) *
               ( 0.5 + (float)I4num / IANNPD_MPHSPH_GR2SR_div ) );
         }
      }
   }

   /* cubic coefficient components */
   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = GR_SR_POL_C3_F;
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      I4num = (INTx4)atoi ( param.val );
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }

/* ==========================================================================
      Do not dump errors to terminal, if any
   ========================================================================== */
      ERRSIV_dump_error = 0;

      param.tag = GR_SR_POL_C3_E;
      TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
      Reset dumping
   ========================================================================== */
      ERRSIV_dump_error = 1;

      if ( *status_code != ERRSID_normal ) {
         *status_code = STC ( ERRSID_normal );
         IANNPV_found_tag[ tag_count ] = FALSE;
      }
      else {
         I2num = (INTx2)atoi ( param.val );
         if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
            MEMSIP_free ( &param.val );
         }

/* ==========================================================================
         Do not dump errors to terminal, if any
   ========================================================================== */
         ERRSIV_dump_error = 0;

         param.tag = GR_SR_POL_C3_B;
         TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
         Reset dumping
   ========================================================================== */
         ERRSIV_dump_error = 1;

         if ( *status_code != ERRSID_normal ) {
            *status_code = STC ( ERRSID_normal );
            IANNPV_found_tag[ tag_count ] = FALSE;
         }
         else {
            Bnum = (INTx1)atoi ( param.val );
            if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
               MEMSIP_free ( &param.val );
            }
            IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff[ 3 ] = (double)
               ( POW ( -1., Bnum ) * POW ( 2., ( I2num - 128 ) ) *
               ( 0.5 + (float)I4num / IANNPD_MPHSPH_GR2SR_div ) );
         }
      }
   }

/* ==========================================================================
   Count the sub image not found tags
   ========================================================================== */
   for ( i=1; i<=2; i++ ) {
      IANNPV_found_tag[ ++tag_count ] = FALSE;
   }

/* ==========================================================================
   Pixel type tag not found
   ========================================================================== */
   IANNPV_found_tag[ ++tag_count ] = FALSE;

/* ==========================================================================
   Count the scaling factor not found
   ========================================================================== */
   IANNPV_found_tag[ ++tag_count ] = FALSE;

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = NOM_NB_LOOKS_AZIM;                     /* azimuth looks number */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].LooksNumber = (float) atoi ( param.val );
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = NORMALISATION_REF_RANGE;              /* reference slant range */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].ReferenceSlantRange_m = (float)
         (atoi ( param.val ) * ( 1.e-2 ));                    /* from cm to m */
      if ( ( TIFSIV_Size[ param.type ] * param.length ) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = REPLICA_POWER;                   /* Pulse Replica Power */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].ProductReplicaPower = (float)
         (atoi ( param.val ));
   }

/* ==========================================================================
   Count the chirp average density tag not found
   ========================================================================== */
   IANNPV_found_tag[ ++tag_count ] = FALSE;

/* ==========================================================================
   Count the processing history not found
   ========================================================================== */
   IANNPV_found_tag[ ++tag_count ] = FALSE;

/* ==========================================================================
   Antenna pattern flag
   ========================================================================== */
   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = MPHSPH_PROC_FLAGS;             /* antenna elevation flag appl. */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      Bnum = (INTx1)atoi ( param.val );
      IANNIV_ImageAnnot[ imanum ].AntennaPatternCorrectionFlag =
         (LDEFIT_boolean)(Bnum && 4);
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

/* ==========================================================================
   Range Spreading loss flag
   ========================================================================== */
   tag_count++;

/* ==========================================================================
   Do not dump errors to terminal, if any
   ========================================================================== */
   ERRSIV_dump_error = 0;

   param.tag = SPREAD_LOSS_COMP_FLAG;           /* range spreading loss appl. */
   TIFSIP_get_par ( chan, img, &param, status_code );

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

   if ( *status_code != ERRSID_normal ) {
      *status_code = STC ( ERRSID_normal );
      IANNPV_found_tag[ tag_count ] = FALSE;
   }
   else {
      IANNIV_ImageAnnot[ imanum ].RangeSpreadingLossCompensationFlag =
         (LDEFIT_boolean)atoi ( param.val );
      if ( (TIFSIV_Size[ param.type ] * param.length) > 4 ) {
         MEMSIP_free ( &param.val );
      }
   }

/* ==========================================================================
   Count the not founded flags tags
   ========================================================================== */
   for ( i=1; i<=2; i++ ) {
      IANNPV_found_tag[ ++tag_count ] = FALSE;
   }

/* ==========================================================================
   Count the co-registration INFO not found
   ========================================================================== */
   IANNPV_found_tag[ ++tag_count ] = FALSE;

/* ==========================================================================
   count the resampling factors not found
   ========================================================================== */
   for ( i=1; i<=2; i++ ) {
      IANNPV_found_tag[ ++tag_count ] = FALSE;
   }

error_exit:;

/* ==========================================================================
   Reset dumping
   ========================================================================== */
   ERRSIV_dump_error = 1;

/* ==========================================================================
   Free the eventually param structure left allocated
   ========================================================================== */
   MEMSIP_free ( &param.val );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNIP_MPHP_GetAnnotations */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_MPHP_PutAnnotations

        $TYPE         PROCEDURE

        $INPUT        chan   : channel of the output TIFF file
                      img    : image ID in the output TIFF file
                      imanum : progressive number of the image

        $MODIFIED     NONE

        $OUTPUT       The global structure with the <imanum> image annotations
                      stored

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the image
                                                  annotations that must be
                                                  filled

        $RET_STATUS   ERRSID_IANN_not_allow_imanum

        $DESCRIPTION  This procedure puts the image annotations read from an
                      MPH-SPH format file in an output TIFF file

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void IANNIP_MPHP_PutAnnotations
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx1               imanum,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNIP_MPHP_PutAnnotations";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  tag_count = -1;
   char                   tag[ LDEFID_char_num ] = "";
   char                   numb[ 4 ] = "";
   float                  val = 1.e+3;
   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check the image index
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) {
      sprintf( numb, "%0u", imanum );
      ERRSIM_set_error( status_code, ERRSID_IANN_not_allow_imanum, numb );
   }

/* ==========================================================================
   General INFO
   ========================================================================== */

   /* product type */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      switch ( IANNIV_ImageAnnot[ imanum ].ProductType ) {
         case IANNIE_prod_ERS1_RAW:                      /* RAW product */
            sprintf ( tag, "ERS1.SAR.RAW" );
         break;
         case IANNIE_prod_ERS1_SLC:                      /* SLC product */
            sprintf ( tag, "ERS1.SAR.SLC" );
         break;
         case IANNIE_prod_ERS1_SLCI:                     /* SLCI product */
            sprintf ( tag, "ERS1.SAR.SLCI" );
         break;
         case IANNIE_prod_ERS1_PRI:                      /* PRI product */
            sprintf ( tag, "ERS1.SAR.PRI" );
         break;
         case IANNIE_prod_ERS1_GEC:                      /* GEC product */
            sprintf ( tag, "ERS1.SAR.GEC" );
         break;
         case IANNIE_prod_ERS1_GTC:                      /* GTC product */
            sprintf ( tag, "ERS1.SAR.GTC" );
         break;
         case IANNIE_prod_ERS2_RAW:                      /* RAW product */
            sprintf ( tag, "ERS2.SAR.RAW" );
         break;
         case IANNIE_prod_ERS2_SLC:                      /* SLC product */
            sprintf ( tag, "ERS2.SAR.SLC" );
         break;
         case IANNIE_prod_ERS2_SLCI:                     /* SLCI product */
            sprintf ( tag, "ERS2.SAR.SLCI" );
         break;
         case IANNIE_prod_ERS2_PRI:                      /* PRI product */
            sprintf ( tag, "ERS2.SAR.PRI" );
         break;
         case IANNIE_prod_ERS2_GEC:                      /* GEC product */
            sprintf ( tag, "ERS2.SAR.GEC" );
         break;
         case IANNIE_prod_ERS2_GTC:                      /* GTC product */
            sprintf ( tag, "ERS2.SAR.GTC" );
         break;
         case IANNIE_prod_undef:                     /* product unknown */
            sprintf ( tag, "-" );
            ERRSIM_print_warning( "Tag LOG_VOL_ID not defined" );
         break;
      }
      IANNPP_PUTP_SetTag ( LOG_VOL_ID, tag, (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII,
                           chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      if ( strcmp ( IANNIV_ImageAnnot[ imanum ].dataFormat, "" ) ) {
         IANNPP_PUTP_SetTag( DATA_FORMAT,
            IANNIV_ImageAnnot[ imanum ].dataFormat,
               (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan, img,
               status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      if ( strcmp ( IANNIV_ImageAnnot[ imanum ].sourceId, "" ) ) {
         IANNPP_PUTP_SetTag( SOURCE_ID,
            IANNIV_ImageAnnot[ imanum ].sourceId,
               (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan, img,
               status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      sprintf( tag, "%0d", IANNIV_ImageAnnot[ imanum ].numberOfVolumes );
      IANNPP_PUTP_SetTag( NUMBER_OF_VOLUMES, tag, (UINTx1)TYPE_ASCII, 
                          (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

   /* scene ref num */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      if ( strcmp ( IANNIV_ImageAnnot[ imanum ].SceneReferenceNumbers, "" ) ) {
         IANNPP_PUTP_SetTag ( SCENE_REF_NUM,
                              IANNIV_ImageAnnot[ imanum ].SceneReferenceNumbers,
                              (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan, img,
                              status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

   /* count the processing PAF */
   tag_count++;

   /* processor name */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      memset ( tag, 0, LDEFID_char_num );
      switch ( IANNIV_ImageAnnot[ imanum ].ProcessorName ) {
         case IANNIE_sproc_VMP:
            sprintf ( tag, "VMP_PRO" );
         break;
         case IANNIE_sproc_ESAR:
            sprintf ( tag, "SAR-ERS" );
         break;
         case IANNIE_sproc_Bangkok:
            sprintf ( tag, "Bangkok" );
         break;
         case IANNIE_sproc_undef:
            ERRSIM_print_warning ( "Tag PROCESSOR_NAME not defined" );
         break;
      }
      IANNPP_PUTP_SetTag ( PROCESSOR_NAME, tag, (UINTx1)TYPE_ASCII,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Calibration section
   ========================================================================== */

   /* absolute constant calibration */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( ABSOLUTE_CALIB_K,
                           &IANNIV_ImageAnnot[ imanum ].CalibrationConstant,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* incidence angle at middle range */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( INCID_ANGLE_CENTRE_RANGE,
                           &IANNIV_ImageAnnot[
                           imanum ].IncidenceAngleAtMiddleRange_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* boresigth angle */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( ANTENNA_BORESIGHT,
                           &IANNIV_ImageAnnot[ imanum ].BoresightAngle_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Corners coordinates section
   ========================================================================== */

   /* top left corner */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( TOP_LEFT_LAT,
                           &IANNIV_ImageAnnot[ imanum ].TopLeftLat_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( TOP_LEFT_LON,
                           &IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* top right corner */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( TOP_RIGHT_LAT,
                           &IANNIV_ImageAnnot[ imanum ].TopRightLat_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( TOP_RIGHT_LON,
                           &IANNIV_ImageAnnot[ imanum ].TopRightLon_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* bottom left corner */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( BOTTOM_LEFT_LAT,
                           &IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( BOTTOM_LEFT_LON,
                           &IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* bottom right corner */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( BOTTOM_RIGHT_LAT,
                           &IANNIV_ImageAnnot[ imanum ].BottomRightLat_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( BOTTOM_RIGHT_LON,
                           &IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* central coordinates */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( CENTRE_GEODETIC_LAT,
                           &IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( CENTRE_GEODETIC_LON,
                           &IANNIV_ImageAnnot[imanum].CentreGeodeticLon_deg,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
       ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* count the zero filling parameters */
   tag_count += 4;

/* ==========================================================================
   Map projection section
   ========================================================================== */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      memset ( tag, '\0', LDEFID_char_num );
      switch ( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {
         case IANNIE_proj_ground:
            sprintf ( tag, "Ground range" );
         break;
         case IANNIE_proj_slant:
            sprintf ( tag, "Slant range" );
         break;
         default:
            ERRSIM_print_warning ( "Tag MAP_PROJ_DESCR not defined" );
      }
      IANNPP_PUTP_SetTag ( MAP_PROJ_DESCR, tag, (UINTx1)TYPE_ASCII,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* count the UTM and UPS variables */
   tag_count += 7;

/* ==========================================================================
   Spacing section   
   ========================================================================== */

   /* line spacing */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( LINE_SPACING,
                           &IANNIV_ImageAnnot[ imanum ].LineSpacing_m,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* pixel spacing */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( PIXEL_SPACING,
                           &IANNIV_ImageAnnot[ imanum ].PixelSpacing_m,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Timing section
   ========================================================================== */

   /* year of first state vector */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( YEAR_DATA_POINT,
                           &IANNIV_ImageAnnot[ imanum ].FirstSTVectYear,
                           (UINTx1)TYPE_SHORT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* month of first state vector */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( MONTH_DATA_POINT,
                           &IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth,
                           (UINTx1)TYPE_SHORT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* day of first state vector */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( DAY_DATA_POINT,
                           &IANNIV_ImageAnnot[ imanum ].FirstSTVectDay,
                           (UINTx1)TYPE_SHORT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* second of day */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( SECOND_OF_DAY,
                           &IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* first line UTC time */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      if ( ( IANNIV_ImageAnnot[ imanum ].ProductType ==
             IANNIE_prod_ERS1_RAW ) ||
           ( IANNIV_ImageAnnot[ imanum ].ProductType ==
             IANNIE_prod_ERS2_RAW ) ) {
         if ( strcmp ( IANNIV_ImageAnnot[
                       imanum ].ZeroDopplerAzimuthFirstLine_UTC, "" ) ) {
            IANNPP_PUTP_SetTag ( RAW_FIRST_LINE_UTC_TIME, IANNIV_ImageAnnot[
                                 imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                                 (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan,
                                 img, status_code );
            ERRSIM_on_err_goto_exit ( *status_code );
         }
      }
      else {
         if ( strcmp ( IANNIV_ImageAnnot[
                       imanum ].ZeroDopplerAzimuthFirstLine_UTC, "" ) ) {
            IANNPP_PUTP_SetTag ( ZERO_DOPP_AZIM_FIRST_TIME,
                                 IANNIV_ImageAnnot[
                                 imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                                 (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan,
                                 img, status_code );
            ERRSIM_on_err_goto_exit ( *status_code );
         }
      }
   }

   /* last line UTC time */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      if ( strcmp ( IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthLastLine_UTC,
                    "" ) ) {
         IANNPP_PUTP_SetTag ( ZERO_DOPP_AZIM_LAST_TIME,
                              IANNIV_ImageAnnot[
                              imanum ].ZeroDopplerAzimuthLastLine_UTC,
                              (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan,
                              img, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

   /* radar wavelength */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( RADAR_WAVELEN, &IANNIV_ImageAnnot[
                           imanum ].RadarWaveLength_m, (UINTx1)TYPE_FLOAT,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* sampling rate */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      val = IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz * ( 1.e-6 );
      IANNPP_PUTP_SetTag ( SAMPLING_RATE, &val, (UINTx1)TYPE_FLOAT,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* first range time */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      val = IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec * 1.e+3;
      IANNPP_PUTP_SetTag ( ZERO_DOPP_RANGE_FIRST_TIME, &val,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* PRF */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( PRF, &IANNIV_ImageAnnot[
                           imanum ].PulseRepetitionFreq_Hz, (UINTx1)TYPE_FLOAT,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* count the equivalent PRF */
   tag_count++;

   /* Doppler coefficients: the constant one ... */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( CROSS_DOPP_FREQ_CONST, &IANNIV_ImageAnnot[
                           imanum ].DopplerFreqCoeff_Hz_sec[ 0 ],
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* ... the linear term ... */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( CROSS_DOPP_FREQ_LINEAR, &IANNIV_ImageAnnot[
                           imanum ].DopplerFreqCoeff_Hz_sec[ 1 ],
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* ... the quadratic one ... */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( CROSS_DOPP_FREQ_QUAD, &IANNIV_ImageAnnot[
                           imanum ].DopplerFreqCoeff_Hz_sec[ 2 ],
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* ... and the cubic one */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( DOPPL_CENTR_CUB_COEFF, &IANNIV_ImageAnnot[
                           imanum ].DopplerFreqCoeff_Hz_sec[ 3 ],
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Ellipsoid section
   ========================================================================== */

   /* semimajor and ... */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      val = IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m * ( 1.e-3 );
      IANNPP_PUTP_SetTag ( ELLIPSOID_SEMIMAJOR_AXIS, &val, (UINTx1)TYPE_FLOAT,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* ... semiminor axes */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      val = IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m * ( 1.e-3 );
      IANNPP_PUTP_SetTag ( ELLIPSOID_SEMIMINOR_AXIS, &val, (UINTx1)TYPE_FLOAT,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   State vectors section
   ========================================================================== */

   /* interval data point */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( TIME_INTERVAL_DATA_POINT,
                           &IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec,
                           (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                           status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* number of state vectors */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( NB_DATA_POINTS, &IANNIV_ImageAnnot[
                           imanum ].NStateVectors, (UINTx1)TYPE_UBYTE,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* X state vectors */
   for( i=0;  i<IANNIV_ImageAnnot[ imanum ].NStateVectors; i++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         IANNPP_PUTP_SetTag ( ( X_SAT_1 + i ), &IANNIV_ImageAnnot[
                              imanum ].X_STVec_m[ i ], (UINTx1)TYPE_DOUBLE,
                              (UINTx1)TYPE_ASCII, chan, img, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

   /* Y state vectors */
   for( i=0;  i<IANNIV_ImageAnnot[ imanum ].NStateVectors; i++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         IANNPP_PUTP_SetTag ( ( Y_SAT_1 + i ), &IANNIV_ImageAnnot[
                              imanum ].Y_STVec_m[ i ], (UINTx1)TYPE_DOUBLE,
                              (UINTx1)TYPE_ASCII, chan, img, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

   /* Z state vectors */
   for( i=0;  i<IANNIV_ImageAnnot[ imanum ].NStateVectors; i++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         IANNPP_PUTP_SetTag ( ( Z_SAT_1 + i ), &IANNIV_ImageAnnot[
                              imanum ].Z_STVec_m[ i ], (UINTx1)TYPE_DOUBLE,
                              (UINTx1)TYPE_ASCII, chan, img, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

   /* VX state vector */
   for( i=0;  i<IANNIV_ImageAnnot[ imanum ].NStateVectors; i++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         IANNPP_PUTP_SetTag ( ( VX_SAT_1 + i ), &IANNIV_ImageAnnot[
                              imanum ].VX_STVec_m_sec[ i ], (UINTx1)TYPE_DOUBLE,
                              (UINTx1)TYPE_ASCII, chan, img, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

   /* VYstate vector */
   for( i=0;  i<IANNIV_ImageAnnot[ imanum ].NStateVectors; i++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         IANNPP_PUTP_SetTag ( ( VY_SAT_1 + i ), &IANNIV_ImageAnnot[
                              imanum ].VY_STVec_m_sec[ i ], (UINTx1)TYPE_DOUBLE,
                              (UINTx1)TYPE_ASCII, chan, img, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

   /* VZ state vector */
   for( i=0;  i<IANNIV_ImageAnnot[ imanum ].NStateVectors; i++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         IANNPP_PUTP_SetTag ( ( VZ_SAT_1 + i ), &IANNIV_ImageAnnot[
                              imanum ].VZ_STVec_m_sec[ i ], (UINTx1)TYPE_DOUBLE,
                              (UINTx1)TYPE_ASCII, chan, img, status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

/* ==========================================================================
   Ground to slant section
   ========================================================================== */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( GR_SR_POL_DEGREE, &IANNIV_ImageAnnot[
                           imanum ].GroundToSlantDegree, (UINTx1)TYPE_UBYTE,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* ground to slant coeff of polynomials */
   for ( i=0; i<=IANNPD_VMP_GR2SR_degree; i++ ) {
#ifdef __TRACE__
   fprintf ( stdout, "\n\n\n --------------- Trace -----------\n" );
   fprintf ( stdout, "\n IANNPV_found_tag[%d] = %d", tag_count + 1,
             IANNPV_found_tag[ tag_count + 1 ] );
   fprintf ( stdout, "\n IANNIV_ImageAnnot[%d].GroundToSlantCoeff[%d] = %g",
             imanum, i, IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff[ i ] );
#endif
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         IANNPP_PUTP_SetTag ( ( GR_SR_COEFF_1 + i ), &IANNIV_ImageAnnot[
                              imanum ].GroundToSlantCoeff[ i ],
                              (UINTx1)TYPE_DOUBLE, (UINTx1)TYPE_ASCII, chan, img,
                              status_code );
         ERRSIM_on_err_goto_exit ( *status_code );
      }
   }

/* ==========================================================================
   Image processing INFO
   ========================================================================== */

   /* count the new tags not found */
   tag_count += 4;

   /* number of look */
#ifdef __TRACE__
   fprintf ( stdout, "\n\n\n --------------- Trace -----------\n" );
   fprintf ( stdout, "\n IANNPV_found_tag[%d] = %d", tag_count + 1,
             IANNPV_found_tag[ tag_count + 1 ] );
   fprintf ( stdout, "\n IANNIV_ImageAnnot[%d].LooksNumber = %f", imanum,
             IANNIV_ImageAnnot[ imanum ].LooksNumber );
#endif
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      IANNPP_PUTP_SetTag ( NOM_NB_LOOKS_AZIM, &IANNIV_ImageAnnot[
                           imanum ].LooksNumber, (UINTx1)TYPE_FLOAT,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* reference slant range */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      val = IANNIV_ImageAnnot[ imanum ].ReferenceSlantRange_m * ( 1.e-3 );
      IANNPP_PUTP_SetTag ( NORMALISATION_REF_RANGE, &val, (UINTx1)TYPE_FLOAT,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* pulse replica power */
#ifdef __TRACE__
   fprintf ( stdout, "\n\n\n --------------- Trace -----------\n" );
   fprintf ( stdout, "\n IANNPV_found_tag[%d] = %d", tag_count + 1,
             IANNPV_found_tag[ tag_count + 1 ] );
   fprintf ( stdout, "\n IANNIV_ImageAnnot[%d].ProductReplicaPower = %g",
             imanum, IANNIV_ImageAnnot[ imanum ].ProductReplicaPower );
#endif
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      memset( tag, '\0', LDEFID_char_num);
      IANNPP_PUTP_SetTag ( REPLICA_POWER, &IANNIV_ImageAnnot[
                           imanum ].ProductReplicaPower, (UINTx1)TYPE_FLOAT,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
       ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Count the chirp average density tag not found
   ========================================================================== */
   tag_count++;

/* ==========================================================================
   Count the processing history not found
   ========================================================================== */
   tag_count++;

/* ==========================================================================
   Processing flags
   ========================================================================== */

   /* antenna elevation application flag */
#ifdef __TRACE__
   fprintf ( stdout, "\n\n\n --------------- Trace -----------\n" );
   fprintf ( stdout, "\n IANNPV_found_tag[%d] = %d", tag_count + 1,
             IANNPV_found_tag[ tag_count + 1 ] );
   fprintf ( stdout, "\n IANNIV_ImageAnnot[%d].AntennaPatternCorrectionFlag",
             imanum );
   fprintf ( stdout, " = %d",
             IANNIV_ImageAnnot[ imanum ].AntennaPatternCorrectionFlag );
#endif
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      memset( tag, '\0', LDEFID_char_num );
      if ( IANNIV_ImageAnnot[ imanum ].AntennaPatternCorrectionFlag ) {
         sprintf ( tag, "1" );
      }
      else {
         sprintf ( tag, "0" );
      }
      IANNPP_PUTP_SetTag ( ANTENNA_ELEVATION_GAIN_FLAG, tag, (UINTx1)TYPE_ASCII,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

   /* range spreading loss application flag */
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      memset ( tag, '\0', LDEFID_char_num );
      if ( IANNIV_ImageAnnot[ imanum ].RangeSpreadingLossCompensationFlag ) {
         sprintf ( tag, "1" );
      }
      else {
         sprintf ( tag, "0" );
      }
      IANNPP_PUTP_SetTag ( SPREAD_LOSS_COMP_FLAG, tag, (UINTx1)TYPE_ASCII,
                           (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNIP_MPHP_PutAnnotations */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_MPHP_set_month

        $TYPE         PROCEDURE

        $INPUT        sst : string to convert into number

        $MODIFIED     NONE

        $OUTPUT       num : number of the month

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure assignes the sequential number of the 
                      month in the year

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void IANNPP_MPHP_set_month
                        (/*IN    */ char                *sst,
                         /*   OUT*/ INTx2               *num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNPP_MPHP_set_month";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   char                   str[ 4 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Copy the string
   ========================================================================== */
   memcpy ( (void *)str, (const void *)sst, 4 );

/* ==========================================================================
   Initialize the number
   ========================================================================== */
   *num = 0;

/* ==========================================================================
   Convert the string into uppercase
   ========================================================================== */
   strupr ( str );

/* ==========================================================================
   Compare the string
   ========================================================================== */
   if ( strcmp ( str, "JAN" ) == 0 ) {
      *num = 1;
   }
   else if ( strcmp ( str, "FEB" ) == 0 ) {
      *num = 2;
   }
   else if ( strcmp ( str, "MAR" ) == 0 ) {
      *num = 3;
   }
   else if ( strcmp ( str, "APR" ) == 0 ) {
      *num = 4;
   }
   else if ( strcmp ( str, "MAY" ) == 0 ) {
      *num = 5;
   }
   else if ( strcmp ( str, "JUN" ) == 0 ) {
      *num = 6;
   }
   else if ( strcmp ( str, "JUL" ) == 0 ) {
      *num = 7;
   }
   else if ( strcmp ( str, "AUG" ) == 0 ) {
      *num = 8;
   }
   else if ( strcmp ( str, "SEP" ) == 0 ) {
      *num = 9;
   }
   else if ( strcmp ( str, "OCT" ) == 0 ) {
      *num = 10;
   }
   else if ( strcmp ( str, "NOV" ) == 0 ) {
      *num = 11;
   }
   else if ( strcmp ( str, "DEC" ) == 0 ) {
      *num = 12;
   }


error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNPP_MPHP_set_month */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_MPHP_AnnotDump

        $TYPE         PROCEDURE

        $INPUT        imanum : ID number of the image
                      fpt    : output file pointer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure dumps the annotations stored in the
                      image annotations structure

        $WARNING      NONE

   $EH
   ========================================================================== */
void IANNIP_MPHP_AnnotDump
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ FILE                *fpt,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNIP_MPHP_AnnotDump";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  tag_count = -1;
   INTx4                  tag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Print out the structure
   ========================================================================== */
   fprintf ( fpt, "\n ImageLength:                         %d",
             IANNIV_ImageAnnot[ imanum ].ImageLength );
   fprintf ( fpt, "\n ImageWidth:                          %d",
             IANNIV_ImageAnnot[ imanum ].ImageWidth );
   fprintf ( fpt, "\n SamplePerPixel:                      %d",
             IANNIV_ImageAnnot[ imanum ].SamplePerPixel );
   fprintf ( fpt, "\n BitsPerSample[0]:                    %d",
             IANNIV_ImageAnnot[ imanum ].BitsPerSample[0] );
   switch ( IANNIV_ImageAnnot[ imanum ].SampleFormat[ 0 ] ) {
      case TIFSID_sintdata:
         fprintf ( fpt, "\n SampleFormat[0]:                     TIFSID_sintdata" );
      break;
      case TIFSID_uintdata:
         fprintf ( fpt, "\n SampleFormat[0]:                     TIFSID_uintdata" );
      break;
      case TIFSID_float:
         fprintf ( fpt, "\n SampleFormat[0]:                     TIFSID_float" );
      break;
      case TIFSID_IEEEdata:
         fprintf ( fpt, "\n SampleFormat[0]:                     TIFSID_IEEEdata" );
      break;
      default:
         fprintf ( fpt, "\n SampleFormat[0]:                     ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      switch ( IANNIV_ImageAnnot[ imanum ].ProductType ) {
	 case IANNIE_prod_ERS1_RAW:
	    fprintf ( fpt, "\n ProductType:                         ERS1.RAW" );
	 break;
	 case IANNIE_prod_ERS1_SLC:
	    fprintf ( fpt, "\n ProductType:                         ERS1.SLC" );
	 break;
	 case IANNIE_prod_ERS1_SLCI:
	    fprintf ( fpt, "\n ProductType:                         ERS1.SLCI" );
	 break;
	 case IANNIE_prod_ERS1_PRI:
	    fprintf ( fpt, "\n ProductType:                         ERS1.PRI" );
	 break;
	 case IANNIE_prod_ERS1_GEC:
	    fprintf ( fpt, "\n ProductType:                         ERS1.GEC" );
	 break;
	 case IANNIE_prod_ERS1_GTC:
	    fprintf ( fpt, "\n ProductType:                         ERS1.GTC" );
	 break;
	 case IANNIE_prod_ERS2_RAW:
	    fprintf ( fpt, "\n ProductType:                         ERS2.RAW" );
	 break;
	 case IANNIE_prod_ERS2_SLC:
	    fprintf ( fpt, "\n ProductType:                         ERS2.SLC" );
	 break;
	 case IANNIE_prod_ERS2_SLCI:
	    fprintf ( fpt, "\n ProductType:                         ERS2.SLCI" );
	 break;
	 case IANNIE_prod_ERS2_PRI:
	    fprintf ( fpt, "\n ProductType:                         ERS2.PRI" );
	 break;
	 case IANNIE_prod_ERS2_GEC:
	    fprintf ( fpt, "\n ProductType:                         ERS2.GEC" );
	 break;
	 case IANNIE_prod_ERS2_GTC:
	    fprintf ( fpt, "\n ProductType:                         ERS2.GTC" );
	 break;
	 default:
	    fprintf ( fpt, "\n ProductType:                         ###############" );
      }
   }
   else {
      fprintf ( fpt, "\n ProductType:                         ###############" );
   }


   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n SceneReferenceNumbers:               %s",
                IANNIV_ImageAnnot[ imanum ].SceneReferenceNumbers );
   }
   else {
      fprintf ( fpt, "\n SceneReferenceNumbers:                         ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      switch ( IANNIV_ImageAnnot[ imanum ].ProcessingPAF ) {
	 case IANNIE_proc_CPAF:
	    fprintf ( fpt, "\n ProcessingPAF:                       Central - PAF" );
	 break;
	 case IANNIE_proc_DPAF:
	    fprintf ( fpt, "\n ProcessingPAF:                       German - PAF" );
	 break;
	 case IANNIE_proc_UPAF:
	    fprintf ( fpt, "\n ProcessingPAF:                       U. K. - PAF" );
	 break;
	 case IANNIE_proc_IPAF:
	    fprintf ( fpt, "\n ProcessingPAF:                       Italian - PAF" );
	 break;
	 case IANNIE_proc_APAF:
	    fprintf ( fpt, "\n ProcessingPAF:                       U.S.A. - PAF" );
	 break;
	 case IANNIE_proc_SPAF:
	    fprintf ( fpt, "\n ProcessingPAF:                       Singapore - PAF" );
	 break;
	 default:
	    fprintf ( fpt, "\n ProcessingPAF:                       ###############" );
      }
   }
   else {
      fprintf ( fpt, "\n ProcessingPAF:                       ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      switch ( IANNIV_ImageAnnot[ imanum ].ProcessorName ) {
	 case IANNIE_sproc_VMP:
	    fprintf ( fpt, "\n ProcessorName:                       VMP" );
	 break;
	 case IANNIE_sproc_ESAR:
	    fprintf ( fpt, "\n ProcessorName:                       E-SAR" );
	 break;
	 case IANNIE_sproc_Bangkok:
	    fprintf ( fpt, "\n ProcessorName:                       Bangkok" );
	 break;
	 default:
	    fprintf ( fpt, "\n ProcessorName:                       ###############" );
      }
   }
   else {
      fprintf ( fpt, "\n ProcessorName:                         ###############" );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n CalibrationConstant:                 %f",
                IANNIV_ImageAnnot[ imanum ].CalibrationConstant );
   }
   else {
      fprintf ( fpt, "\n CalibrationConstant:                         ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n IncidenceAngleAtMiddleRange_deg:     %f",
                IANNIV_ImageAnnot[ imanum ].IncidenceAngleAtMiddleRange_deg );
   }
   else {
      fprintf ( fpt, "\n IncidenceAngleAtMiddleRange_deg:     ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n BoresightAngle_deg:                  %f",
                IANNIV_ImageAnnot[ imanum ].BoresightAngle_deg );
   }
   else {
      fprintf ( fpt, "\n BoresightAngle_deg:                  ###############" );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n TopLeftLat_deg:                      %f",
                IANNIV_ImageAnnot[ imanum ].TopLeftLat_deg );
   }
   else {
      fprintf ( fpt, "\n TopLeftLat_deg:                      ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n TopLeftLon_deg:                      %f",
                IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg );
   }
   else {
      fprintf ( fpt, "\n TopLeftLon_deg:                      ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n TopRightLat_deg:                     %f",
                IANNIV_ImageAnnot[ imanum ].TopRightLat_deg );
   }
   else {
      fprintf ( fpt, "\n TopRightLat_deg:                     ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n TopRightLon_deg:                     %f",
                IANNIV_ImageAnnot[ imanum ].TopRightLon_deg );
   }
   else {
      fprintf ( fpt, "\n TopRightLon_deg:                     ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n BottomLeftLat_deg:                   %f",
                IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg );
   }
   else {
      fprintf ( fpt, "\n BottomLeftLat_deg:                   ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n BottomRightLon_deg:                  %f",
                IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg );
   }
   else {
      fprintf ( fpt, "\n BottomRightLon_deg:                  ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n BottomLeftLat_deg:                   %f",
                IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg );
   }
   else {
      fprintf ( fpt, "\n BottomLeftLat_deg:                   ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n BottomRightLon_deg:                  %f",
                IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg );
   }
   else {
      fprintf ( fpt, "\n BottomRightLon_deg:                  ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n CentreGeodeticLat_deg:               %f",
                IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg );
   }
   else {
      fprintf ( fpt, "\n CentreGeodeticLat_deg:               ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n CentreGeodeticLon_deg:               %f",
                IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg );
   }
   else {
      fprintf ( fpt, "\n CentreGeodeticLon_deg:               ###############" );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n TopZeroFilledLines:                  %d",
                IANNIV_ImageAnnot[ imanum ].TopZeroFilledLines );
   }
   else {
      fprintf ( fpt, "\n TopZeroFilledLines:                  ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n BottomZeroFilledLines:               %d",
                IANNIV_ImageAnnot[ imanum ].BottomZeroFilledLines );
   }
   else {
      fprintf ( fpt, "\n BottomZeroFilledLines:               ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n LeftZeroFilledPixels:                %d",
                IANNIV_ImageAnnot[ imanum ].LeftZeroFilledPixels );
   }
   else {
      fprintf ( fpt, "\n LeftZeroFilledPixels:                ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
         fprintf ( fpt, "\n RightZeroFilledPixels:               %d",
                   IANNIV_ImageAnnot[ imanum ].RightZeroFilledPixels );
   }
   else {
      fprintf ( fpt, "\n RightZeroFilledPixels:               ###############" );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      switch ( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {
	 case IANNIE_proj_UTM:
	    fprintf ( fpt, "\n MapProjectionType:                   UTM" );
	 break;
	 case IANNIE_proj_UPS:
	    fprintf ( fpt, "\n MapProjectionType:                   UPS" );
	 break;
	 case IANNIE_proj_ground:
	    fprintf ( fpt, "\n MapProjectionType:                   Ground range" );
	 break;
	 case IANNIE_proj_slant:
	    fprintf ( fpt, "\n MapProjectionType:                   Slant range" );
	 break;
	 default:
	    fprintf ( fpt, "\n MapProjectionType:                   ###############" );
      }
   }
   else {
      fprintf ( fpt, "\n MapProjectionType:                   ###############" );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n ProjectionScaleFactor:               %f",
                IANNIV_ImageAnnot[ imanum ].ProjectionScaleFactor );
   }
   else {
      fprintf ( fpt, "\n ProjectionScaleFactor:               ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n ProjectionCentralMeridian_deg:       %f",
                IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg );
   }
   else {
      fprintf ( fpt, "\n ProjectionCentralMeridian_deg:       ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n ProjectionCentralParallel_deg:       %f",
                IANNIV_ImageAnnot[ imanum ].ProjectionCentralParallel_deg );
   }
   else {
      fprintf ( fpt, "\n ProjectionCentralParallel_deg:       ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n TopLeftEast_m:                       %f",
                IANNIV_ImageAnnot[ imanum ].TopLeftEast_m );
   }
   else {
      fprintf ( fpt, "\n TopLeftEast_m:                       ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n TopLeftNorth_m:                      %f",
                IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m );
   }
   else {
      fprintf ( fpt, "\n TopLeftNorth_m:                      ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n FalseEast_m:                         %f",
                IANNIV_ImageAnnot[ imanum ].FalseEast_m );
   }
   else {
      fprintf ( fpt, "\n FalseEast_m:                         ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n FalseNorth_m:                        %f",
                IANNIV_ImageAnnot[ imanum ].FalseNorth_m );
   }
   else {
      fprintf ( fpt, "\n FalseNorth_m:                        ###############" );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n LineSpacing_m:                       %f",
                IANNIV_ImageAnnot[ imanum ].LineSpacing_m );
   }
   else {
      fprintf ( fpt, "\n LineSpacing_m:                       ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n PixelSpacing_m:                      %f",
                IANNIV_ImageAnnot[ imanum ].PixelSpacing_m );
   }
   else {
      fprintf ( fpt, "\n PixelSpacing_m:                      ###############" );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n FirstSTVectYear:                     %d",
                IANNIV_ImageAnnot[ imanum ].FirstSTVectYear );
   }
   else {
      fprintf ( fpt, "\n FirstSTVectYear:                     ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n FirstSTVectMonth:                    %d",
                IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth );
   }
   else {
      fprintf ( fpt, "\n FirstSTVectMonth:                    ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n FirstSTVectDay:                      %d",
                IANNIV_ImageAnnot[ imanum ].FirstSTVectDay );
   }
   else {
      fprintf ( fpt, "\n FirstSTVectDay:                      ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n FirstSTVectSeconds:                  %f",
                IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds );
   }
   else {
      fprintf ( fpt, "\n FirstSTVectSeconds:                  ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n ZeroDopplerAzimuthFirstLine_UTC:     %s",
                IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthFirstLine_UTC );
   }
   else {
      fprintf ( fpt, "\n ZeroDopplerAzimuthFirstLine_UTC:     ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n ZeroDopplerAzimuthLastLine_UTC:      %s",
                IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthLastLine_UTC );
   }
   else {
      fprintf ( fpt, "\n ZeroDopplerAzimuthLastLine_UTC:      ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n RadarWaveLength_m:                   %f",
                IANNIV_ImageAnnot[ imanum ].RadarWaveLength_m );
   }
   else {
      fprintf ( fpt, "\n RadarWaveLength_m:                   ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n SamplingRate_Hz:                     %f",
                IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz );
   }
   else {
      fprintf ( fpt, "\n SamplingRate_Hz:                     ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n RangeFirstTime_sec:                  %f",
                IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec );
   }
   else {
      fprintf ( fpt, "\n RangeFirstTime_sec:                  ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n PulseRepetitionFreq_Hz:              %f",
                IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz );
   }
   else {
      fprintf ( fpt, "\n PulseRepetitionFreq_Hz:              ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n EquivalentPulseRepetitionFreq_Hz:    %f",
                IANNIV_ImageAnnot[ imanum ].EquivalentPulseRepetitionFreq_Hz );
   }
   else {
      fprintf ( fpt, "\n EquivalentPulseRepetitionFreq_Hz:    ###############" );
   }
   for ( tag=0; tag<4; tag++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         fprintf ( fpt, "\n DopplerFreqCoeff_Hz_sec[%d]:          %g", tag,
                   IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ tag ] );
      }
      else {
         fprintf ( fpt, "\n DopplerFreqCoeff_Hz_sec[%d]:      ###############", tag );
      }
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n SemiMajorAxis_m:                     %f",
                IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m );
   }
   else {
      fprintf ( fpt, "\n SemiMajorAxis_m:                     ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n SemiMinorAxis_m:                     %f",
                IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m );
   }
   else {
      fprintf ( fpt, "\n SemiMinorAxis_m:                     ###############" );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n STVectIntervalTime_sec:              %f",
                IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec );
   }
   else {
      fprintf ( fpt, "\n STVectIntervalTime_sec:              ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n NStateVectors:                       %d",
                IANNIV_ImageAnnot[ imanum ].NStateVectors );
   }
   else {
      fprintf ( fpt, "\n NStateVectors:                       ###############" );
   }
   for ( tag=0; tag<5; tag++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         fprintf ( fpt, "\n X_STVec_m[%d]:                        %f", tag,
                   IANNIV_ImageAnnot[ imanum ].X_STVec_m[ tag ] );
      }
      else {
         fprintf ( fpt, "\n X_STVec_m[%d]:                       ###############", tag );
      }
   }
   for ( tag=0; tag<5; tag++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
	 fprintf ( fpt, "\n Y_STVec_m[%d]:                        %f", tag,
		   IANNIV_ImageAnnot[ imanum ].Y_STVec_m[ tag ] );
      }
      else {
         fprintf ( fpt, "\n Y_STVec_m[%d]:                          ###############", tag );
      }
   }
   for ( tag=0; tag<5; tag++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         fprintf ( fpt, "\n Z_STVec_m[%d]:                        %f", tag,
                   IANNIV_ImageAnnot[ imanum ].Z_STVec_m[ tag ] );
      }
      else {
         fprintf ( fpt, "\n Z_STVec_m[%d]::                          ###############", tag );
      }
   }
   for ( tag=0; tag<5; tag++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         fprintf ( fpt, "\n VX_STVec_m[%d]:                       %f", tag,
                   IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[ tag ] );
      }
      else {
         fprintf ( fpt, "\n VX_STVec_m[%d]:                          ###############", tag );
      }
   }
   for ( tag=0; tag<5; tag++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         fprintf ( fpt, "\n VY_STVec_m[%d]:                       %f", tag,
                   IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[ tag ] );
      }
      else {
         fprintf ( fpt, "\n VY_STVec_m[%d]:                          ###############", tag );
      }
   }
   for ( tag=0; tag<5; tag++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         fprintf ( fpt, "\n VZ_STVec_m[%d]:                       %f", tag,
                   IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[ tag ] );
      }
      else {
         fprintf ( fpt, "\n VZ_STVec_m[%d]:                          ###############", tag );
      }
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n GroundToSlantDegree:                 %d",
                IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree );
   }
   else {
      fprintf ( fpt, "\n GroundToSlantDegree:                 ###############" );
   }
   for ( tag=0; tag<IANNID_GRSRMAX; tag++ ) {
      if ( IANNPV_found_tag[ ++tag_count ] ) {
         fprintf ( fpt, "\n GroundToSlantCoeff[%d]:               %g", tag,
                   IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff[ tag ] );
      }
      else {
         fprintf ( fpt, "\n GroundToSlantCoeff[%d]:              ###############", tag );
      }
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n SubImageTopLeftRow:                  %d",
                IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow );
   }
   else {
      fprintf ( fpt, "\n SubImageTopLeftRow:                  ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n SubImageTopLeftCol:                  %d",
                IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol );
   }
   else {
      fprintf ( fpt, "\n SubImageTopLeftCol:                  ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      switch ( IANNIV_ImageAnnot[ imanum ].PixelType ) {
         case IANNIE_pixt_complex:
            fprintf ( fpt, "\n PixelType:                           COMPLEX" );
         break;
         case IANNIE_pixt_amplitude:
            fprintf ( fpt, "\n PixelType:                           AMPLITUDE" );
         break;
         case IANNIE_pixt_power:
            fprintf ( fpt, "\n PixelType:                           POWER" );
         break;
         default:
            fprintf ( fpt, "\n PixelType:                           ###############" );
      }
   }
   else {
      fprintf ( fpt, "\n PixelType:                           ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n ScalingFactor:                       %f",
                IANNIV_ImageAnnot[ imanum ].ScalingFactor );
   }
   else {
      fprintf ( fpt, "\n ScalingFactor:                       ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n LooksNumber:                         %f",
                IANNIV_ImageAnnot[ imanum ].LooksNumber );
   }
   else {
      fprintf ( fpt, "\n LooksNumber:                         ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n ReferenceSlantRange_m:               %f",
                IANNIV_ImageAnnot[ imanum ].ReferenceSlantRange_m );
   }
   else {
      fprintf ( fpt, "\n ReferenceSlantRange_m:               ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n ProductReplicaPower:                 %f",
                IANNIV_ImageAnnot[ imanum ].ProductReplicaPower );
   }
   else {
      fprintf ( fpt, "\n ProductReplicaPower:                 ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n ChirpAverageDensity:                 %f",
                IANNIV_ImageAnnot[ imanum ].ChirpAverageDensity );
   }
   else {
      fprintf ( fpt, "\n ChirpAverageDensity:                 ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      if ( strcmp ( IANNIV_ImageAnnot[ imanum ].ProcessingHistory, "" ) ) {
         fprintf ( fpt, "\n ProcessingHistory:                   %s",
                   IANNIV_ImageAnnot[ imanum ].ProcessingHistory );
      }
      else {
         fprintf ( fpt, "\n ProcessingHistory:                   ###############" );
      }
   }
   else {
      fprintf ( fpt, "\n ProcessingHistory:                   ###############" );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n AntennaPatternCorrectionFlag:        %d",
                IANNIV_ImageAnnot[ imanum ].AntennaPatternCorrectionFlag );
   }
   else {
      fprintf ( fpt, "\n AntennaPatternCorrectionFlag:        ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n RangeSpreadingLossCompensationFlag:  %d",
                IANNIV_ImageAnnot[ imanum ].RangeSpreadingLossCompensationFlag );
   }
   else {
      fprintf ( fpt, "\n RangeSpreadingLossCompensationFlag:  ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n CalibrationConstantApplicationFlag:  %d",
                IANNIV_ImageAnnot[ imanum ].CalibrationConstantApplicationFlag );
   }
   else {
      fprintf ( fpt, "\n CalibrationConstantApplicationFlag:  ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n ADCSaturationCompensationFlag:       %d",
                IANNIV_ImageAnnot[ imanum ].ADCSaturationCompensationFlag );
   }
   else {
      fprintf ( fpt, "\n ADCSaturationCompensationFlag:       ###############" );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      if ( strcmp ( IANNIV_ImageAnnot[ imanum ].MasterSceneReference, "" ) ) {
         fprintf ( fpt, "\n MasterSceneReference:                %s",
                   IANNIV_ImageAnnot[ imanum ].MasterSceneReference );
      }
      else {
         fprintf ( fpt, "\n MasterSceneReference:                ###############"
                   /* , IANNIV_ImageAnnot[ imanum ].MasterSceneReference */ );
      }
   }
   else {
      fprintf ( fpt, "\n MasterSceneReference:                ###############" );
   }

   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n XScalingFactor:                      %f",
                IANNIV_ImageAnnot[ imanum ].XScalingFactor );
   }
   else {
      fprintf ( fpt, "\n XScalingFactor:                      ###############" );
   }
   if ( IANNPV_found_tag[ ++tag_count ] ) {
      fprintf ( fpt, "\n YScalingFactor:                      %f",
                IANNIV_ImageAnnot[ imanum ].YScalingFactor );
   }
   else {
      fprintf ( fpt, "\n YScalingFactor:                      ###############" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNIP_MPHP_AnnotDump */

#ifdef __EXAM__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_MPHP_

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure 

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void IANNIP_MPHP_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNIP_MPHP_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IANNIP_MPHP_ */
#endif
