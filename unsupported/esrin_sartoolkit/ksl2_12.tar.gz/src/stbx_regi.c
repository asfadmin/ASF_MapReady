/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_REGI

      $FUNCTION          This module contains the task procedures for
                         the Sar Toolbox IMAGE CO-REGISTRATION and the
                         COHERENCE IMAGE GENERATION tasks

      $ROUTINE           STBXPP_REGI_Registrator
                         STBXPP_REGI_CoherImaGenerator

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       09-MAR-98     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>
#include <string.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include FIIS_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include IANN_INTF_H
#include COOR_INTF_H
#include MATH_INTF_H
#include IREG_INTF_H
#include STBX_INTF_H
#include STBX_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_REGI_Registrator

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_insuff_input_num
                      ERRSID_STBX_insuff_output_num
                      ERRSID_STBX_invalid_warp_val
                      ERRSID_STBX_invalid_ov_mode
                      ERRSID_STBX_invalid_in_mode
                      ERRSID_STBX_not_poly_aoi

        $DESCRIPTION  This procedure executes the IMAGE CO-REGISTRATION task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Open the input files
                      - Get the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of output image
                      - Initialize output file TIFF parameters
                      - Open output files
                      - Calls the core routine
                      - Updates the image annotations
                      - Close input and output files
                      - Delete input file, if requested

   $EH
   ========================================================================== */

void STBXPP_REGI_Registrator
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_REGI_Registrator";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   INI file variables
   ========================================================================== */
   STBXPT_task             task;
   FIISIT_parm_name        tmpParmName;
   FILSIT_file_name        inImages[ IREGID_MaxImaNum ];
   FILSIT_file_name        inImagesNames[ IREGID_MaxImaNum ];
   FILSIT_file_name        outImages[ IREGID_MaxImaNum ];
   FILSIT_file_name        outImagesNames[ IREGID_MaxImaNum ];
   FILSIT_file_name        GCPsFileName;
   FILSIT_file_name        BaselineFile;
   FILSIT_file_name        BaselineFileName;
   FILSIT_file_name        ResidFileName;
   char                   *GCPsFile = (char *)NULL;
   char                   *ResidFile = (char *)NULL;
   INTx4                   GCPsFileN_par;
   INTx4                   GCPsN_par;
   INTx4                   coarseCellN_par;
   INTx4                   intFactN_par;
   INTx4                   fineCellN_par;
   INTx4                   ResidFileN_par;
   INTx4                   intWinSizeN_par;
   INTx4                   OverMode_par;
   INTx4                   FineReg_par;
   INTx4                   par = 0;
   INTx4                   npar = 22;
   INTx4                   GCPsNumbers[ 2 ] = {
                              IREGID_GCP_mas_num_row,
                              IREGID_GCP_mas_num_col
                           };
   INTx4                   coarseCellsDims[ 2 ] = {
                              IREGID_coarse_cell_dim_row,
                              IREGID_coarse_cell_dim_col
                           };
   INTx4                   fineCellsDims[ 2 ] = {
                              IREGID_fine_cell_dim_row,
                              IREGID_fine_cell_dim_col
                           };
   INTx4                   coherWinSize = IREGID_coher_wsiz;
   INTx4                   intWinSizes[ 2 ] = {
                              IREGID_interp_win_size,
                              IREGID_interp_win_size
                           };
   INTx4                   interpPrec = IREGID_interp_prec;
   INTx4                   sincWidth = IREGID_sinc_width;
   float                   ccCoeff = IREGID_cubconv_coeff;
   float                   coarseIntFacts[ 2 ] = {
                              IREGID_int_fact_row,
                              IREGID_int_fact_col
                           };
   float                   coarseMaxTol = IREGID_max_coarse_shift;
   float                   coherFTol = IREGID_coher_ftol;
   float                   coherVTol = IREGID_coher_vtol;
   float                   warpDegree = IREGID_warp_deg;
   float                   maxPointRMS = IREGID_max_point_RMS;
   char                    OverMode[ 10 ];
   char                    InterMode[ 30 ];

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                  mas_imanum = 0;
   UINTx1                  imanum;
   INTx4                   NImages;
   INTx4                   i;
   INTx4                   j;
   FILE                   *fp = (FILE *)NULL;
   GIOSIT_io              *inp_io = (GIOSIT_io *)NULL;
   GIOSIT_io              *out_io = (GIOSIT_io *)NULL;
   UINTx1                  degree;
   UINTx1                  ovmode;
   UINTx1                  inmode;
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   INTx4                   TLRow = 0;
   INTx4                   TLCol = 0;
   INTx4                   BRRow = 0;
   INTx4                   BRCol = 0;
   LDEFIT_boolean          real_aoi;
   MATHIT_RC               corner_rc;
   MATHIT_LLH              corner_llh;
   MATHIT_EN               corner_en;
   char                    strpar[ LDEFID_char_num ] = "";

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task ( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy ( task.name, task_name );
   task.parmNo = npar + STBXPD_default_parm_no;
   task.parm = (FIISIT_parm *)MEMSIP_alloc ( (size_t)(task.parmNo *
                                             sizeof ( FIISIT_parm )) );
   if ( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc, "" );
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy ( task.parm[ par ].name, STBXPD_input_images );
   task.parm[ par ].type = FIISIE_tt_string;
   task.parm[ par ].size = sizeof ( FILSIT_file_name );
   task.parm[ par ].mandatory = TRUE;
   task.parm[ par ].vector = TRUE;
   task.parm[ par ].max_number = IREGID_MaxImaNum;
   task.parm[ par++ ].value = (void *)inImagesNames;

   strcpy ( task.parm[ par ].name, STBXPD_output_images );
   task.parm[ par ].type = FIISIE_tt_string;
   task.parm[ par ].size = sizeof ( FILSIT_file_name );
   task.parm[ par ].mandatory = TRUE;
   task.parm[ par ].vector = TRUE;
   task.parm[ par ].max_number = IREGID_MaxImaNum;
   task.parm[ par++ ].value = (void *)outImagesNames;

   strcpy ( BaselineFileName, IREGID_baseline_fname );
   strcpy ( task.parm[ par ].name, STBXPD_baseline_file_name );
   task.parm[ par ].type = FIISIE_tt_string;
   task.parm[ par ].size = sizeof ( FILSIT_file_name );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)BaselineFileName;

   GCPsN_par = par;
   strcpy ( task.parm[ par ].name, STBXPD_GCPs_number );
   task.parm[ par ].type = FIISIE_tt_int;
   task.parm[ par ].size = sizeof ( INTx4 );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = TRUE;
   task.parm[ par ].max_number = 2;
   task.parm[ par++ ].value = (void *)GCPsNumbers;

   GCPsFileN_par = par;
   strcpy ( task.parm[ par ].name, STBXPD_GCPs_file_name );
   task.parm[ par ].type = FIISIE_tt_string;
   task.parm[ par ].size = sizeof ( FILSIT_file_name );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)GCPsFileName;

   coarseCellN_par = par;
   strcpy ( task.parm[ par ].name, STBXPD_coarse_cell_dim );
   task.parm[ par ].type = FIISIE_tt_int;
   task.parm[ par ].size = sizeof ( INTx4 );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = TRUE;
   task.parm[ par ].max_number = 2;
   task.parm[ par++ ].value = (void *)coarseCellsDims;

   intFactN_par = par;
   strcpy ( task.parm[ par ].name, STBXPD_interp_fact );
   task.parm[ par ].type = FIISIE_tt_float;
   task.parm[ par ].size = sizeof ( float );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = TRUE;
   task.parm[ par ].max_number = 2;
   task.parm[ par++ ].value = (void *)coarseIntFacts;

   fineCellN_par = par;
   strcpy ( task.parm[ par ].name, STBXPD_fine_cell_dim );
   task.parm[ par ].type = FIISIE_tt_int;
   task.parm[ par ].size = sizeof ( INTx4 );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = TRUE;
   task.parm[ par ].max_number = 2;
   task.parm[ par++ ].value = (void *)fineCellsDims;

   strcpy ( task.parm[ par ].name, STBXPD_coher_win_size );
   task.parm[ par ].type = FIISIE_tt_int;
   task.parm[ par ].size = sizeof ( INTx4 );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)&coherWinSize;

   strcpy ( task.parm[ par ].name, STBXPD_coher_ftol );
   task.parm[ par ].type = FIISIE_tt_float;
   task.parm[ par ].size = sizeof ( float );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)&coherFTol;

   strcpy ( task.parm[ par ].name, STBXPD_coarse_tolerance );
   task.parm[ par ].type = FIISIE_tt_float;
   task.parm[ par ].size = sizeof ( float );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)&coarseMaxTol;

   strcpy ( task.parm[ par ].name, STBXPD_coher_vtol );
   task.parm[ par ].type = FIISIE_tt_float;
   task.parm[ par ].size = sizeof ( float );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)&coherVTol;

   strcpy ( task.parm[ par ].name, STBXPD_warp_deg );
   task.parm[ par ].type = FIISIE_tt_float;
   task.parm[ par ].size = sizeof ( float );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)&warpDegree;

   strcpy ( task.parm[ par ].name, STBXPD_max_RMS );
   task.parm[ par ].type = FIISIE_tt_float;
   task.parm[ par ].size = sizeof ( float );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)&maxPointRMS;

   OverMode_par = par;
   strcpy ( OverMode, IREGID_over_mode );
   strcpy ( task.parm[ par ].name, STBXPD_over_mode );
   task.parm[ par ].type = FIISIE_tt_string;
   task.parm[ par ].size = sizeof ( OverMode );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)OverMode;

   intWinSizeN_par = par;
   strcpy ( task.parm[ par ].name, STBXPD_interp_win_siz );
   task.parm[ par ].type = FIISIE_tt_int;
   task.parm[ par ].size = sizeof ( INTx4 );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = TRUE;
   task.parm[ par ].max_number = 2;
   task.parm[ par++ ].value = (void *)intWinSizes;

   strcpy ( InterMode, IREGID_interp_mode );
   strcpy ( task.parm[ par ].name, STBXPD_interp_mode );
   task.parm[ par ].type = FIISIE_tt_string;
   task.parm[ par ].size = sizeof ( InterMode );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)InterMode;

   ResidFileN_par = par;
   strcpy ( task.parm[ par ].name, STBXPD_resid_file_name );
   task.parm[ par ].type = FIISIE_tt_string;
   task.parm[ par ].size = sizeof ( FILSIT_file_name );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)ResidFileName;

   strcpy ( task.parm[ par ].name, STBXPD_interp_precision );
   task.parm[ par ].type = FIISIE_tt_int;
   task.parm[ par ].size = sizeof ( INTx4 );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)interpPrec;

   strcpy ( task.parm[ par ].name, STBXPD_sinc_width );
   task.parm[ par ].type = FIISIE_tt_int;
   task.parm[ par ].size = sizeof ( INTx4 );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)sincWidth;

   strcpy ( task.parm[ par ].name, STBXPD_cc_coeff );
   task.parm[ par ].type = FIISIE_tt_float;
   task.parm[ par ].size = sizeof ( float );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)&ccCoeff;

   FineReg_par = par;
   strcpy ( task.parm[ par ].name, STBXPD_fine_reg_flag );
   task.parm[ par ].type = FIISIE_tt_char;
   task.parm[ par ].size = sizeof ( char );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)&IREGIV_FineRegFlag;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy ( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i++ ].value = (void *) LDEFIV_inp_dir;

   strcpy ( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i++ ].value = (void *) LDEFIV_out_dir;

   strcpy ( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i++ ].value = (void *) LDEFIV_temp_dir;

   strcpy ( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for ( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info ( argv[ 2 ], task.name, section_no,
                             &(task.parm[ i ]), status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for ( i=3; i<argc; i+=2 ) {
      if ( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {
         sprintf ( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for ( j=0; j<task.parmNo; j++ ) {
	    if ( !strcmp ( tmpParmName, task.parm[ j ].name ) ) {
	       STBXPP_set_par ( (void *)argv[ i + 1 ], &(task.parm[ j ]),
                                status_code );
	       ERRSIM_on_err_goto_exit ( *status_code );
	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for ( i=0; i<task.parmNo; i++ ) {
      if ( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
   fprintf ( stdout, "Param %s not defined\n", task.parm[ i ].name );
#endif
         ERRSIM_set_error ( status_code, ERRSID_STBX_parm_not_defined,
                            task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   for ( i=0; i<task.parm[ 0 ].number; i++ ) {
      fprintf ( stdout, "\nInput Images : %s", inImagesNames[ i ] );
   }
   for ( i=0; i<task.parm[ 1 ].number; i++ ) {
      fprintf ( stdout, "\nOut Images : %s", outImagesNames[ i ] );
   }
#endif

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input images
   ========================================================================== */
   for ( i=0; i<task.parm[ 0 ].number; i++ ) {
      sprintf ( inImages[ i ], "%s%s", LDEFIV_inp_dir, inImagesNames[ i ] );
   }

/* ==========================================================================
   Build base line
   ========================================================================== */
   sprintf  ( BaselineFile, "%s%s", LDEFIV_out_dir, BaselineFileName );

/* ==========================================================================
   Check params
   ========================================================================== */
   if ( task.parm[ GCPsFileN_par ].founded ) {
      if ( ( GCPsFile = (char *)
                MEMSIP_alloc ( (size_t)FILSID_file_name_length ) ) ==
           (char *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                            "for the GCPs File Name string" );
      }
      sprintf ( GCPsFile, "%s%s", LDEFIV_inp_dir, GCPsFileName );
   }
   if ( task.parm[ ResidFileN_par ].founded ) {
      if ( ( ResidFile = (char *)
                MEMSIP_alloc ( (size_t)FILSID_file_name_length ) ) ==
           (char *)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                            "for the Residual File Name string" );
      }
      sprintf ( ResidFile, "%s%s", LDEFIV_out_dir, ResidFileName );
   }

/* ==========================================================================
   Check input files number
   ========================================================================== */
   if ( task.parm[ 0 ].number < 2 ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_insuff_input_num, "" );
   }

/* ==========================================================================
   Check output files number
   ========================================================================== */
   if ( task.parm[ 1 ].number < task.parm[ 0 ].number ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_insuff_output_num, "" );
   }

/* ==========================================================================
   Check the input files existence
   ========================================================================== */
   for ( i=0; i<task.parm[ 0 ].number; i++ ) {
      FILSIP_open ( inImages[ i ], "r", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      FILSIP_close ( &fp, &log_status_code );
   }

/* ==========================================================================
   Check the baseline file and residual file for goodness
   ========================================================================== */
   FILSIP_open ( BaselineFile, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   FILSIP_close ( &fp, &log_status_code );
   FILSIP_delete ( BaselineFile, &log_status_code );
   if ( task.parm[ ResidFileN_par ].founded ) {
      FILSIP_open ( ResidFile, "w", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      FILSIP_close ( &fp, &log_status_code );
      FILSIP_delete ( ResidFile, &log_status_code );
   }

/* ==========================================================================
   Check the GCPs input file existence
   ========================================================================== */
   if ( task.parm[ GCPsFileN_par ].founded ) {
      FILSIP_open ( GCPsFile, "r", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      FILSIP_close ( &fp, &log_status_code );
   }

/* ==========================================================================
   Check the GCPs numbers
   ========================================================================== */
   if ( task.parm [ GCPsN_par ].founded ) {
      if ( task.parm[ GCPsN_par ].number != 2 ) {
         memset ( strpar, '\0', LDEFID_char_num );
         sprintf ( strpar, "%s", STBXPD_GCPs_number );
         ERRSIM_set_error ( status_code, ERRSID_STBX_bad_vect_par_num,
                            strpar );
      }
   }

/* ==========================================================================
   Check the number of cell dimensions for the coarse registration
   ========================================================================== */
   if ( task.parm[ coarseCellN_par ].founded ) {
      if ( task.parm[ coarseCellN_par ].number != 2 ) {
         memset ( strpar, '\0', LDEFID_char_num );
         sprintf ( strpar, "%s", STBXPD_coarse_cell_dim );
         ERRSIM_set_error ( status_code, ERRSID_STBX_bad_vect_par_num,
                            strpar );
      }
   }

/* ==========================================================================
   Check the number of interpolation factors for the coarse registration
   ========================================================================== */
   if ( task.parm[ intFactN_par ].founded ) {
      if ( task.parm[ intFactN_par ].number != 2 ) {
         memset ( strpar, '\0', LDEFID_char_num );
         sprintf ( strpar, "%s", STBXPD_interp_fact );
         ERRSIM_set_error ( status_code, ERRSID_STBX_bad_vect_par_num,
                            strpar );
      }
   }

/* ==========================================================================
   Check the number of cell dimensions for the fine registration
   ========================================================================== */
   if ( task.parm[ fineCellN_par ].founded ) {
      if ( task.parm[ fineCellN_par ].number != 2 ) {
         memset ( strpar, '\0', LDEFID_char_num );
         sprintf ( strpar, "%s", STBXPD_fine_cell_dim );
         ERRSIM_set_error ( status_code, ERRSID_STBX_bad_vect_par_num,
                            strpar );
      }
   }

/* ==========================================================================
   Check the number of cell dimensions for the interpolation
   ========================================================================== */
   if ( task.parm[ intWinSizeN_par ].founded ) {
      if ( task.parm[ intWinSizeN_par ].number != 2 ) {
         memset ( strpar, '\0', LDEFID_char_num );
         sprintf ( strpar, "%s", STBXPD_interp_win_siz );
         ERRSIM_set_error ( status_code, ERRSID_STBX_bad_vect_par_num,
                            strpar );
      }
   }

/* ==========================================================================
   Fill the images number
   ========================================================================== */
   NImages = task.parm[ 0 ].number;

/* ==========================================================================
   Allocate the file descriptors
   ========================================================================== */
   if ( ( inp_io = (GIOSIT_io *)MEMSIP_alloc ( (size_t)(NImages *
                                               sizeof (GIOSIT_io)) ) ) ==
        (GIOSIT_io *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                         "for the input images descriptors" );
   }
   if ( ( out_io = (GIOSIT_io *)MEMSIP_alloc ( (size_t)(NImages *
                                               sizeof (GIOSIT_io)) ) ) ==
        (GIOSIT_io *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                         "for the output images descriptors" );
   }

/* ==========================================================================
   Convert to upper the real image fine registration flag
   ========================================================================== */
   if ( task.parm[ FineReg_par ].founded ) {
      IREGIV_FineRegFlag = toupper ( IREGIV_FineRegFlag );

/* ==========================================================================
   Check it
   ========================================================================== */
      if ( ( IREGIV_FineRegFlag != 'Y' ) && ( IREGIV_FineRegFlag != 'N' ) ) {
         ERRSIM_print_warning ( "The Fine Registration Flag is set to N" );
      }
   }

/* ==========================================================================
   Initialize the TIFF stuff
   ========================================================================== */
   GIOSIP_init ( status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Open the input files
   ========================================================================== */
   for ( i=0; i<NImages; i++ ) {
      inp_io[ i ].type = GIOSIE_tif;
      inp_io[ i ].mode = 'r';
      strcpy ( inp_io[ i ].val.tif.name, inImages[ i ] );
      inp_io[ i ].img = 0;
      GIOSIP_open_io ( &inp_io[ i ], status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Read the image annotations of the input files
   ========================================================================== */
   for ( i=0; i<NImages; i++ ) {
      IANNIP_GETP_ImageAnnot ( inp_io[ i ].chan, inp_io[ i ].img,
                               (UINTx1)i, IANNID_IREG_IREG,
                               inp_io[ i ].val.tif.bpar, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Build full name of output images
   ========================================================================== */
   for ( i=0; i<task.parm[ 1 ].number; i++ ) {
      STBXPP_bld_file_name ( outImagesNames[ i ], 
                             task_name, 
                             ((inp_io[ 0 ].val.tif.bpar.sampleperpixel == 1) ?
                              LDEFIE_dt_float : LDEFIE_dt_2_float),
                             outImages[ i ], status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Check the output files different names
   ========================================================================== */
   for ( i=0; i<task.parm[ 1 ].number-1; i++ ) {
      for ( j=i+1; j<task.parm[ 1 ].number; j++ ) {
         if ( !( strcmp ( outImages[ i ], outImages[ j ] ) ) ) {
            ERRSIM_set_error ( status_code, ERRSID_STBX_parm_invalid,
                               "output file names must be different" );
         }
      }
   }

/* ==========================================================================
   Check the output files path goodness
   ========================================================================== */
   for ( i=0; i<task.parm[ 1 ].number; i++ ) {
      FILSIP_open ( outImages[ i ], "w", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      FILSIP_close ( &fp, &log_status_code );
      FILSIP_delete ( outImages[ i ], &log_status_code );
   }

/* ==========================================================================
   Set the warp degree variable
   ========================================================================== */
   if ( warpDegree == 1. ) {
      degree = 1;
   }
   else if ( warpDegree == 1.5 ) {
      degree = 2;
   }
   else if ( warpDegree == 2. ) {
      degree = 3;
   }
   else if ( warpDegree == 3. ) {
      degree = 4;
   }
   else {
      ERRSIM_set_error ( status_code, ERRSID_STBX_invalid_warp_val, "" );
   }

/* ==========================================================================
   Set the output layout mode
   ========================================================================== */
   if ( task.parm[ OverMode_par ].founded ) {
      strupr ( OverMode );
      if ( !strcmp ( (const char *)OverMode, STBXPD_over_min ) ) {
         ovmode = 1;
      }
      else if ( !strcmp ( (const char *)OverMode, STBXPD_over_max ) ) {
         ovmode = 2;
      }
      else if ( !strcmp ( (const char *)OverMode, STBXPD_over_master ) ) {
         ovmode = 3;
      }
      else {
         ERRSIM_set_error ( status_code, ERRSID_STBX_invalid_ov_mode, "" );
      }
   }
   else {
      ovmode = 0;
   }

/* ==========================================================================
   Set the interpolation mode
   ========================================================================== */
   if ( !strcmp ( (const char *)InterMode, STBXPD_interp_nn ) ) {
      inmode = 1;
   }
   else if ( !strcmp ( (const char *)InterMode, STBXPD_interp_bil ) ) {
      inmode = 2;
   }
   else if ( !strcmp ( (const char *)InterMode, STBXPD_interp_cconv ) ) {
      inmode = 3;
   }
   else if ( !strcmp ( (const char *)InterMode, STBXPD_interp_FFTshift ) ) {
      inmode = 4;
   }
   else if ( !strcmp ( (const char *)InterMode, STBXPD_interp_sinc ) ) {
      inmode = 5;
   }
   else if ( !strcmp ( (const char *)InterMode, STBXPD_interp_CCFFTShift ) ) {
      inmode = 6;
   }
   else if ( !strcmp ( (const char *)InterMode,
                       STBXPD_interp_SincFFTShift ) ) {
      inmode = 7;
   }
   else {
      ERRSIM_set_error ( status_code, ERRSID_STBX_invalid_in_mode, "" );
   }

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   if ( ovmode == 0 ) {
      STBXPP_get_coordinates ( argv[ 2 ], task.name, section_no,
                               mas_imanum,
                               (UINTx4 *)&TLRow, (UINTx4 *)&TLCol,
                               (UINTx4 *)&BRRow, (UINTx4 *)&BRCol, &vertex_no,
                               &vertex, &real_aoi, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      if ( real_aoi == TRUE ) {
         ERRSIM_set_error ( status_code, ERRSID_STBX_not_poly_aoi, task.name );
      }
   }
   else {
      TLRow = TLCol = 0;
      BRRow = IANNIV_ImageAnnot[ mas_imanum ].ImageLength - 1;
      BRCol = IANNIV_ImageAnnot[ mas_imanum ].ImageWidth - 1;
   }

/* ==========================================================================
   Call the registrator
   ========================================================================== */
   IREGIP_DRVR_Registrator ( inp_io, outImages, NImages, GCPsNumbers[ 0 ],
                             GCPsNumbers[ 1 ], (char *)GCPsFile,
                             (char *)ResidFile,
                             coarseCellsDims[ 0 ],
                             coarseCellsDims[ 1 ], coarseIntFacts[ 0 ],
                             coarseIntFacts[ 1 ], fineCellsDims[ 0 ],
                             fineCellsDims[ 1 ], coherWinSize, coherFTol,
                             coherVTol, degree, ovmode, intWinSizes[ 0 ],
                             intWinSizes[ 1 ], inmode, BaselineFile, sincWidth,
                             interpPrec, ccCoeff, coarseMaxTol, maxPointRMS,
                             &TLRow, &TLCol, &BRRow, &BRCol, out_io,
                             status_code );
    ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Loop over the output files
   ========================================================================== */
   for ( i=0; i<NImages; i++ ) {

/* ==========================================================================
   Set the output file ID
   ========================================================================== */
      imanum = (UINTx1)(NImages + i);

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
      IANNIP_GETP_CopyAnnot ( i, imanum, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
      IANNIV_ImageAnnot[ imanum ].ImageLength =
         out_io[ i ].val.tif.bpar.imagelength;
      IANNIV_ImageAnnot[ imanum ].ImageWidth =
         out_io[ i ].val.tif.bpar.imagewidth;
      switch ( out_io[ i ].val.tif.bpar.sampleperpixel ) {
         case 1:
            IANNIV_ImageAnnot[ imanum ].BitsPerSample[ 0 ] =
               out_io[ i ].val.tif.bpar.bitspersample[ 0 ];
            IANNIV_ImageAnnot[ imanum ].SampleFormat[ 0 ] =
               out_io[ i ].val.tif.bpar.sampleformat[ 0 ];
         break;
         case 2:
            IANNIV_ImageAnnot[ imanum ].BitsPerSample[0] =
               out_io[ i ].val.tif.bpar.bitspersample[0];
            IANNIV_ImageAnnot[ imanum ].BitsPerSample[1] =
               out_io[ i ].val.tif.bpar.bitspersample[1];
            IANNIV_ImageAnnot[ imanum ].SampleFormat[0] =
               out_io[ i ].val.tif.bpar.sampleformat[0];
            IANNIV_ImageAnnot[ imanum ].SampleFormat[1] =
               out_io[ i ].val.tif.bpar.sampleformat[1];
         break;
      }

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
      IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow =
         /* current offset */
         (INTx4) (TLRow / IANNIV_ImageAnnot[ mas_imanum ].YScalingFactor) +
         /* old subimage offset */
         IANNIV_ImageAnnot[ mas_imanum ].SubImageTopLeftRow;

      IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol =
         /* current offset */
         (INTx4) (TLCol / IANNIV_ImageAnnot[ mas_imanum ].XScalingFactor) +
         /* old subimage offset */
         IANNIV_ImageAnnot[ mas_imanum ].SubImageTopLeftCol;

/* ==========================================================================
   Spacing
   ========================================================================== */
      IANNIV_ImageAnnot[ imanum ].LineSpacing_m =
         IANNIV_ImageAnnot[ mas_imanum ].LineSpacing_m;
      IANNIV_ImageAnnot[ imanum ].PixelSpacing_m =
         IANNIV_ImageAnnot[ mas_imanum ].PixelSpacing_m;
   }

/* ==========================================================================
   Copy into each slave image the tags necessary for the coordinates
   conversions
   ========================================================================== */
   for ( i=1; i<NImages; i++ ) {

      imanum = (UINTx1)(NImages + i);

      switch ( IANNIV_ImageAnnot[ mas_imanum ].MapProjectionType ) {
         case IANNIE_proj_UTM:
         case IANNIE_proj_UPS:

/* ==========================================================================
   UTM and UPS products
   ========================================================================== */
            IANNIV_ImageAnnot[ imanum ].TopLeftEast_m =
               IANNIV_ImageAnnot[ mas_imanum ].TopLeftEast_m;
            IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m =
               IANNIV_ImageAnnot[ mas_imanum ].TopLeftNorth_m;
            IANNIV_ImageAnnot[ imanum ].FalseEast_m =
               IANNIV_ImageAnnot[ mas_imanum ].FalseEast_m;
            IANNIV_ImageAnnot[ imanum ].FalseNorth_m =
               IANNIV_ImageAnnot[ mas_imanum ].FalseNorth_m;
            IANNIV_ImageAnnot[ imanum ].ProjectionScaleFactor =
               IANNIV_ImageAnnot[ mas_imanum ].ProjectionScaleFactor;
            IANNIV_ImageAnnot[ imanum ].ProjectionCentralParallel_deg =
               IANNIV_ImageAnnot[ mas_imanum ].ProjectionCentralParallel_deg;
            IANNIV_ImageAnnot[ imanum ].ProjectionCentralMeridian_deg =
               IANNIV_ImageAnnot[ mas_imanum ].ProjectionCentralMeridian_deg;
         break;
         case IANNIE_proj_ground:
         case IANNIE_proj_slant:
            IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz =
               IANNIV_ImageAnnot[ mas_imanum ].SamplingRate_Hz;
            IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz =
               IANNIV_ImageAnnot[ mas_imanum ].PulseRepetitionFreq_Hz;
            IANNIV_ImageAnnot[ imanum ].RadarWaveLength_m =
               IANNIV_ImageAnnot[ mas_imanum ].RadarWaveLength_m;
            IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec  =
               IANNIV_ImageAnnot[ mas_imanum ].STVectIntervalTime_sec;
            IANNIV_ImageAnnot[ imanum ].NStateVectors =
               IANNIV_ImageAnnot[ mas_imanum ].NStateVectors;
            for ( j=0; j<IANNIV_ImageAnnot[ imanum ].NStateVectors; j++ ) {
               IANNIV_ImageAnnot[ imanum ].X_STVec_m[ j ] =
                  IANNIV_ImageAnnot[ mas_imanum ].X_STVec_m[ j ];
               IANNIV_ImageAnnot[ imanum ].Y_STVec_m[ j ] =
                  IANNIV_ImageAnnot[ mas_imanum ].Y_STVec_m[ j ];
               IANNIV_ImageAnnot[ imanum ].Z_STVec_m[ j ] =
                  IANNIV_ImageAnnot[ mas_imanum ].Z_STVec_m[ j ];
               IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[ j ] =
                  IANNIV_ImageAnnot[ mas_imanum ].VX_STVec_m_sec[ j ];
               IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[ j ] =
                  IANNIV_ImageAnnot[ mas_imanum ].VY_STVec_m_sec[ j ];
               IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[ j ] =
                  IANNIV_ImageAnnot[ mas_imanum ].VZ_STVec_m_sec[ j ];
            }
            IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg =
               IANNIV_ImageAnnot[ mas_imanum ].CentreGeodeticLat_deg;
            IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg =
               IANNIV_ImageAnnot[ mas_imanum ].CentreGeodeticLon_deg;
            IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec =
               IANNIV_ImageAnnot[ mas_imanum ].RangeFirstTime_sec;
            strcpy ( IANNIV_ImageAnnot[
                     imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                     IANNIV_ImageAnnot[
                     mas_imanum ].ZeroDopplerAzimuthFirstLine_UTC );
            strcpy ( IANNIV_ImageAnnot[
                     imanum ].ZeroDopplerAzimuthLastLine_UTC,
                     IANNIV_ImageAnnot[
                     mas_imanum ].ZeroDopplerAzimuthLastLine_UTC );
            IANNIV_ImageAnnot[ imanum ].FirstSTVectYear =
               IANNIV_ImageAnnot[ mas_imanum ].FirstSTVectYear;
            IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth =
               IANNIV_ImageAnnot[ mas_imanum ].FirstSTVectMonth;
            IANNIV_ImageAnnot[ imanum ].FirstSTVectDay =
               IANNIV_ImageAnnot[ mas_imanum ].FirstSTVectDay;
            IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds =
               IANNIV_ImageAnnot[ mas_imanum ].FirstSTVectSeconds;
            IANNIV_ImageAnnot[ imanum ].EquivalentPulseRepetitionFreq_Hz =
               IANNIV_ImageAnnot[ mas_imanum ].EquivalentPulseRepetitionFreq_Hz;
            for ( j=0; j<4; j++ ) {
               IANNIV_ImageAnnot[ imanum ].DopplerFreqCoeff_Hz_sec[ j ] =
                  IANNIV_ImageAnnot[ mas_imanum ].DopplerFreqCoeff_Hz_sec[ j ];
            }
      }
   }

/* ==========================================================================
   Make the coordinates conversions on the master image
   ========================================================================== */
   COORIP_CONV_Init ( (UINTx1)NImages, status_code );
   if ( *status_code != STC ( ERRSID_normal ) ) {
      *status_code = STC ( ERRSID_normal );
      ERRSIM_print_warning ( "Corners coordinates not evaluable" );
      IANNIV_ImageAnnot[ NImages ].TopLeftLat_deg = 0.0;
      IANNIV_ImageAnnot[ NImages ].TopLeftLon_deg = 0.0;
      IANNIV_ImageAnnot[ NImages ].TopRightLat_deg = 0.0;
      IANNIV_ImageAnnot[ NImages ].TopRightLon_deg = 0.0;
      IANNIV_ImageAnnot[ NImages ].BottomRightLat_deg = 0.0;
      IANNIV_ImageAnnot[ NImages ].BottomRightLon_deg = 0.0;
      IANNIV_ImageAnnot[ NImages ].BottomLeftLat_deg = 0.0;
      IANNIV_ImageAnnot[ NImages ].BottomLeftLon_deg = 0.0;
      IANNIV_ImageAnnot[ NImages ].CentreGeodeticLat_deg = 0.0;
      IANNIV_ImageAnnot[ NImages ].CentreGeodeticLon_deg = 0.0;
      IANNIV_ImageAnnot[ NImages ].TopLeftEast_m = 0.0;
      IANNIV_ImageAnnot[ NImages ].TopLeftNorth_m = 0.0;
   }
   else {
      imanum = NImages;

/* ==========================================================================
   Corners coordinates
   ========================================================================== */
      /* Top Left corner */
      corner_rc.row = (double)0;
      corner_rc.col = (double)0;
      COORIP_CONV_rc_llh ( &corner_rc, imanum, &corner_llh, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      IANNIV_ImageAnnot[ imanum ].TopLeftLat_deg = (float)corner_llh.lat;
      IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg = (float)corner_llh.lon;

      /* Top Right corner */
      corner_rc.row = (double)0;
      corner_rc.col = (double)(IANNIV_ImageAnnot[ imanum ].ImageWidth - 1);
      COORIP_CONV_rc_llh ( &corner_rc, imanum, &corner_llh, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      IANNIV_ImageAnnot[ imanum ].TopRightLat_deg = (float)corner_llh.lat;
      IANNIV_ImageAnnot[ imanum ].TopRightLon_deg = (float)corner_llh.lon;

      /* Bottom Right corner */
      corner_rc.row = (double)(IANNIV_ImageAnnot[ imanum ].ImageLength - 1);
      corner_rc.col = (double)(IANNIV_ImageAnnot[ imanum ].ImageWidth - 1);
      COORIP_CONV_rc_llh ( &corner_rc, imanum, &corner_llh, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      IANNIV_ImageAnnot[ imanum ].BottomRightLat_deg = (float)corner_llh.lat;
      IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg = (float)corner_llh.lon;

      /* Bottom Left corner */
      corner_rc.row = (double)(IANNIV_ImageAnnot[ imanum ].ImageLength - 1);
      corner_rc.col = (double)0;
      COORIP_CONV_rc_llh ( &corner_rc, imanum, &corner_llh, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg = (float)corner_llh.lat;
      IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg = (float)corner_llh.lon;

      /* Center point */
      corner_rc.row = (double)
	 (( IANNIV_ImageAnnot[ imanum ].ImageLength - 1 ) >> 1);
      corner_rc.col = (double)
	 (( IANNIV_ImageAnnot[ imanum ].ImageWidth - 1 ) >> 1);
      COORIP_CONV_rc_llh ( &corner_rc, imanum, &corner_llh, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg = (float)
	 corner_llh.lat;
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg = (float)
	 corner_llh.lon;

/* ==========================================================================
   Geocoded product
   ========================================================================== */
      switch ( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {
	 case IANNIE_proj_UTM:
	 case IANNIE_proj_UPS: {

/* ==========================================================================
   Rescale the top left corner
   ========================================================================== */
            corner_rc.row = (double) 
               (IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow *
                IANNIV_ImageAnnot[ imanum ].YScalingFactor);
	    corner_rc.col = (double) 
               (IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol *
                IANNIV_ImageAnnot[ imanum ].XScalingFactor);

/* ==========================================================================
   Convert the top left corner
   ========================================================================== */
	    COORIP_CONV_rc_en ( &corner_rc, imanum, &corner_en, status_code );
	    ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the corresponding tags in the structure
   ========================================================================== */
	    IANNIV_ImageAnnot[ imanum ].TopLeftEast_m = (float)corner_en.east;
	    IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m = (float)corner_en.north;
	 }
      }
   }

/* ==========================================================================
   Copy the corners into the slaves
   ========================================================================== */
   for ( i=1; i<NImages; i++ ) {
      imanum = NImages + i;

      /* Top Left corner */
      IANNIV_ImageAnnot[ imanum ].TopLeftLat_deg =
         IANNIV_ImageAnnot[ NImages ].TopLeftLat_deg;
      IANNIV_ImageAnnot[ imanum ].TopLeftLon_deg =
         IANNIV_ImageAnnot[ NImages ].TopLeftLon_deg;

      /* Top Right corner */
      IANNIV_ImageAnnot[ imanum ].TopRightLat_deg =
         IANNIV_ImageAnnot[ NImages ].TopRightLat_deg;
      IANNIV_ImageAnnot[ imanum ].TopRightLon_deg =
         IANNIV_ImageAnnot[ NImages ].TopRightLon_deg;

      /* Bottom Right corner */
      IANNIV_ImageAnnot[ imanum ].BottomRightLat_deg =
         IANNIV_ImageAnnot[ NImages ].BottomRightLat_deg;
      IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg =
         IANNIV_ImageAnnot[ NImages ].BottomRightLon_deg;

      /* Bottom Left corner */
      IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg =
         IANNIV_ImageAnnot[ NImages ].BottomLeftLat_deg;
      IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg =
         IANNIV_ImageAnnot[ NImages ].BottomLeftLon_deg;

      /* Centre */
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg=
         IANNIV_ImageAnnot[ NImages ].CentreGeodeticLat_deg;
      IANNIV_ImageAnnot[ imanum ].CentreGeodeticLon_deg=
         IANNIV_ImageAnnot[ NImages ].CentreGeodeticLon_deg;

      /* TopLeft East-North */
      IANNIV_ImageAnnot[ imanum ].TopLeftEast_m=
         IANNIV_ImageAnnot[ NImages ].TopLeftEast_m;
      IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m=
         IANNIV_ImageAnnot[ NImages ].TopLeftNorth_m;

   }

   for ( i=0; i<NImages; i++ ) {
      imanum = NImages + i;

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
      IANNIP_PUTP_UpdateProcHistory ( imanum, task.name, "", status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Update the master scene reference tag
   ========================================================================== */
      strcpy ( IANNIV_ImageAnnot[ imanum ].MasterSceneReference,
               ( const char *)IANNIV_ImageAnnot[
               mas_imanum ].SceneReferenceNumbers );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
      IANNIP_PUTP_ImageAnnot ( out_io[ i ].chan, out_io[ i ].img, imanum,
                               status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Close the files
   ========================================================================== */
   for ( i=0; i<NImages; i++ ) {
      GIOSIP_close_io ( &inp_io[ i ], status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

      GIOSIP_close_io ( &out_io[ i ], status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Delete input files, if requested
   ========================================================================== */
   if ( ( LDEFIV_delete_input == 'Y' ) || ( LDEFIV_delete_input == 'y' ) ) {
      for ( i=0; i<NImages; i++ ) {
         FILSIP_delete ( inImages[ i ], &log_status_code );
      }
   }

/* ==========================================================================
   Log stop
   ========================================================================== */
   STBXPM_end_task ( task_name );

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&inp_io );
   MEMSIP_free ( (void **)&out_io );
   MEMSIP_free ( (void **)&GCPsFile );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code,
                          &log_status_code );

}/* STBXPP_REGI_Registrator */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_REGI_CoherImaGenerator

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_inp_files_not_two
                      ERRSID_STBX_not_poly_aoi

        $DESCRIPTION  This procedure executes the COHERENCE IMAGE GENERATION
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Open the input files
                      - Get the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Initialize output file TIFF parameters
                      - Open output file
                      - Calls the core routine
                      - Updates the image annotations
                      - Close input and output files
                      - Delete input file, if requested

   $EH
   ========================================================================== */

void STBXPP_REGI_CoherImaGenerator
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_REGI_CoherImaGenerator";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   INI file variables
   ========================================================================== */
   STBXPT_task             task;
   FIISIT_parm_name        tmpParmName;
   FILSIT_file_name        inImages[ IREGID_MaxImaNum ];
   FILSIT_file_name        inImagesNames[ IREGID_MaxImaNum ];
   FILSIT_file_name        outImage;
   FILSIT_file_name        outImageName;
   INTx4                   WinSizes[ 2 ] = {
                              IREGID_coher_wsiz,
                              IREGID_coher_wsiz
                           };
   INTx4                   WinSizesN_par;
   INTx4                   par = 0;
   INTx4                   npar = 3;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx1                  mas_imanum = 0;
   UINTx1                  out_imanum;
   INTx4                   NImages;
   INTx4                   i;
   INTx4                   j;
   GIOSIT_io              *inp_io = (GIOSIT_io *)NULL;
   GIOSIT_io               out_io;
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow;
   UINTx4                  TLCol;
   UINTx4                  BRRow;
   UINTx4                  BRCol;
   UINTx4                  NRow;
   UINTx4                  NCol;
   LDEFIT_boolean          real_aoi;
   FILE                   *fp = (FILE *)NULL;
   char                    strpar[ LDEFID_char_num ] = "";

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task ( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy ( task.name, task_name );
   task.parmNo = npar + STBXPD_default_parm_no;
   task.parm = (FIISIT_parm *)MEMSIP_alloc ( (size_t)(task.parmNo *
                                             sizeof ( FIISIT_parm )) );
   if ( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc, "" );
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy ( task.parm[ par ].name, STBXPD_input_images );
   task.parm[ par ].type = FIISIE_tt_string;
   task.parm[ par ].size = sizeof ( FILSIT_file_name );
   task.parm[ par ].mandatory = TRUE;
   task.parm[ par ].vector = TRUE;
   task.parm[ par ].max_number = IREGID_MaxImaNum;
   task.parm[ par++ ].value = (void *)inImagesNames;

   strcpy ( task.parm[ par ].name, STBXPD_output_image );
   task.parm[ par ].type = FIISIE_tt_string;
   task.parm[ par ].size = sizeof ( FILSIT_file_name );
   task.parm[ par ].mandatory = TRUE;
   task.parm[ par ].vector = FALSE;
   task.parm[ par++ ].value = (void *)outImageName;

   WinSizesN_par = par;
   strcpy ( task.parm[ par ].name, STBXPD_window_sizes );
   task.parm[ par ].type = FIISIE_tt_int;
   task.parm[ par ].size = sizeof ( INTx4 );
   task.parm[ par ].mandatory = FALSE;
   task.parm[ par ].vector = TRUE;
   task.parm[ par ].max_number = 2;
   task.parm[ par++ ].value = (void *)WinSizes;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy ( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i++ ].value = (void *) LDEFIV_inp_dir;

   strcpy ( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i++ ].value = (void *) LDEFIV_out_dir;

   strcpy ( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i++ ].value = (void *) LDEFIV_temp_dir;

   strcpy ( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for ( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info ( argv[ 2 ], task.name, section_no,
                             &(task.parm[ i ]), status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for ( i=3; i<argc; i+=2 ) {
      if ( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {
         sprintf ( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

         for ( j=0; j<task.parmNo; j++ ) {
            if ( !strcmp ( tmpParmName, task.parm[ j ].name ) ) {
               STBXPP_set_par ( (void *)argv[ i + 1 ], &(task.parm[ j ]),
                                status_code );
               ERRSIM_on_err_goto_exit ( *status_code );
               break;
            }
         }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for ( i=0; i<task.parmNo; i++ ) {
      if ( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
   fprintf ( stdout, "Param %s not defined\n", task.parm[ i ].name );
#endif
         ERRSIM_set_error ( status_code, ERRSID_STBX_parm_not_defined,
                            task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Dump the task variables
   ========================================================================== */
#ifdef __TRACE__
   for ( i=0; i<task.parm[ 0 ].number; i++ ) {
      fprintf ( stdout, "\nInput Images : %s", inImagesNames[ i ] );
   }
   fprintf ( stdout, "\nOut Image : %s", outImageName );
#endif

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input and output images
   ========================================================================== */
   for ( i=0; i<task.parm[ 0 ].number; i++ ) {
      sprintf ( inImages[ i ], "%s%s", LDEFIV_inp_dir, inImagesNames[ i ] );
   }
   STBXPP_bld_file_name ( outImageName, task_name, LDEFIE_dt_float,
                          outImage, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check input files number
   ========================================================================== */
   if ( task.parm[ 0 ].number != 2 ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_inp_files_not_two, "" );
   }

/* ==========================================================================
   Check the input files existence
   ========================================================================== */
   for ( i=0; i<task.parm[ 0 ].number; i++ ) {
      FILSIP_open ( inImages[ i ], "r", 0, &fp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      FILSIP_close ( &fp, &log_status_code );
   }

/* ==========================================================================
   Check the window sizes number of parameters
   ========================================================================== */
   if ( task.parm[ WinSizesN_par ].founded ) {
      if ( task.parm[ WinSizesN_par ].number ) {
         memset ( strpar, '\0', LDEFID_char_num );
         sprintf ( strpar, "%s", STBXPD_window_sizes );
         ERRSIM_set_error ( status_code, ERRSID_STBX_bad_vect_par_num,
                            strpar );
      }
   }

/* ==========================================================================
   Fill the images number
   ========================================================================== */
   NImages = task.parm[ 0 ].number;

/* ==========================================================================
   Allocate the file descriptors
   ========================================================================== */
   if ( ( inp_io = (GIOSIT_io *)MEMSIP_alloc ( (size_t)(NImages *
                                               sizeof (GIOSIT_io)) ) ) ==
        (GIOSIT_io *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_err_mem_alloc,
                         "for the input images descriptors" );
   }

/* ==========================================================================
   Initialize the TIFF stuff
   ========================================================================== */
   GIOSIP_init ( status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Open the input files
   ========================================================================== */
   for ( i=0; i<NImages; i++ ) {
      inp_io[ i ].type = GIOSIE_tif;
      inp_io[ i ].mode = 'r';
      strcpy ( inp_io[ i ].val.tif.name, inImages[ i ] );
      inp_io[ i ].img = 0;
      GIOSIP_open_io ( &inp_io[ i ], status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Read the image annotations of the input files
   ========================================================================== */
   for ( i=0; i<NImages; i++ ) {
      IANNIP_GETP_ImageAnnot ( inp_io[ i ].chan, inp_io[ i ].img,
                               (UINTx1)i, IANNID_IREG_COHE,
                               inp_io[ i ].val.tif.bpar, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ], task.name, section_no, mas_imanum,
                            (UINTx4 *)&TLRow, (UINTx4 *)&TLCol,
                            (UINTx4 *)&BRRow, (UINTx4 *)&BRCol, &vertex_no,
                            &vertex, &real_aoi, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   if ( real_aoi == TRUE ) {
      ERRSIM_set_error ( status_code, ERRSID_STBX_not_poly_aoi, task.name );
   }

/* ==========================================================================
   Evaluate the number of rows and columns
   ========================================================================== */
   NRow = BRRow - TLRow + 1;
   NCol = BRCol - TLCol + 1;

/* ==========================================================================
   Fill the basic parameter structure of the output file
   ========================================================================== */
   TIFSIM_bpar_init ( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = NRow;
   out_io.val.tif.bpar.imagewidth = NCol;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.bitspersample[ 0 ] = 32;
   out_io.val.tif.bpar.sampleformat[ 0 ] = TIFSID_float;
   out_io.val.tif.bpar.disposition = 'x';

/* ==========================================================================
   Open the  output files
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy ( out_io.val.tif.name, outImage );
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;
   out_io.img = 0;
   GIOSIP_open_io ( &out_io, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Call the coherence image generation
   ========================================================================== */
   IREGIP_COHE_OverlapAndSave ( inp_io, &out_io, TLRow, TLCol, NRow, NCol,
                                (UINTx4)WinSizes[ 0 ], (UINTx4)WinSizes[ 1 ],
                                status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Set the output file ID
   ========================================================================== */
   out_imanum =  (UINTx1)NImages;

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot ( mas_imanum, out_imanum, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_imanum ].ImageLength =
      out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_imanum ].ImageWidth = out_io.val.tif.bpar.imagewidth;
   IANNIV_ImageAnnot[ out_imanum ].BitsPerSample[ 0 ] =
      out_io.val.tif.bpar.bitspersample[ 0 ];
   IANNIV_ImageAnnot[ out_imanum ].SampleFormat[ 0 ] =
      out_io.val.tif.bpar.sampleformat[ 0 ];

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_imanum ].SubImageTopLeftRow =
      /* current offset */
      (INTx4) (TLRow / IANNIV_ImageAnnot[ mas_imanum ].YScalingFactor) +
      /* old subimage offset */
      IANNIV_ImageAnnot[ mas_imanum ].SubImageTopLeftRow;

   IANNIV_ImageAnnot[ out_imanum ].SubImageTopLeftCol =
      /* current offset */
      (INTx4) (TLCol / IANNIV_ImageAnnot[ mas_imanum ].XScalingFactor) +
      /* old subimage offset */
      IANNIV_ImageAnnot[ mas_imanum ].SubImageTopLeftCol;

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates ( out_imanum, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory ( out_imanum, task.name, "", status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot ( out_io.chan, out_io.img, out_imanum, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Close the input ...
   ========================================================================== */
   for ( i=0; i<NImages; i++ ) {
      GIOSIP_close_io ( &inp_io[ i ], status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   ... and output files
   ========================================================================== */
   GIOSIP_close_io ( &out_io, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Delete input files, if requested
   ========================================================================== */
   if ( ( LDEFIV_delete_input == 'Y' ) || ( LDEFIV_delete_input == 'y' ) ) {
      for ( i=0; i<NImages; i++ ) {
         FILSIP_delete ( inImages[ i ], &log_status_code );
      }
   }

/* ==========================================================================
   Log stop
   ========================================================================== */
   STBXPM_end_task ( task_name );

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&inp_io );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code,
                          &log_status_code );

}/* STBXPP_REGI_CoherImaGenerator */

#ifdef __EXAM__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_REGI_

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure ...

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */

void STBXPP_REGI_
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_REGI_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task ( task_name );

/* ==========================================================================
   Log stop
   ========================================================================== */
   STBXPM_end_task ( task_name );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code,
                          &log_status_code );

}/* STBXPP_REGI_ */
#endif
