/* ==========================================================================
   $MODULE_HEADER

      $NAME              MATH_NREC

      $FUNCTION          This module contains the procedures of the Numerical
                         Recipes necessary to the mathematical procedures of
                         the package MATH

      $ROUTINE           damoeba
			 amotry
			 dlubksb
			 dludcmp
			 dmnewt
			 dspline
			 dsplint
			 dtqli
			 dtred2
			 ivector
			 dvector
			 dmatrix
			 free_ivector
			 free_dvector
			 free_dmatrix

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       10-JUN-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <math.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include MATH_PGLB_H
#include MATH_NREC_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
                     LOCAL ROUTINE PROTOTYPES SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ---

        $TYPE         PROCEDURES, FUNCTIONS

        $DESCRIPTION  These procedures and functions are taken from the
                      Numerical Recipes Library and are transformed in order
                      to match with the SAR ToolBox Routines

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

#ifdef NMAX
#undef NMAX
#endif
#define NMAX 5000

#ifdef ALPHA
#undef ALPHA
#endif
#define ALPHA 1.0

#ifdef BETA
#undef BETA
#endif
#define BETA 0.5

#ifdef GAMMA
#undef GAMMA
#endif
#define GAMMA 2.0

#ifdef GET_PSUM
#undef GET_PSUM
#endif

#define GET_PSUM for (j=1;j<=ndim;j++) { for (i=1,sum=0.0;i<=mpts;i++)\
						sum += p[i][j]; psum[j]=sum;}

void damoeba(p,y,ndim,ftol,vtol,funk,nfunk,nr_status)
double **p,y[],ftol,vtol,(*funk)();
INTx4 ndim,*nfunk,*nr_status;
{
	INTx4 i,j,ilo,ihi,inhi,mpts=ndim+1;
	double ytry,ysave,sum,rtol,amotry(),*psum,*dvector();
	void free_dvector();

        /* g. r. v. 7/2/98 */
        double maxs,mmm;
        UINTx1 flag;

	psum=dvector(1,ndim,nr_status);
        if (*nr_status) return; /* memory allocation check */
	*nfunk=0;
	GET_PSUM
	for (;;) {
		ilo=1;
		ihi = y[1]>y[2] ? (inhi=2,1) : (inhi=1,2);
		for (i=1;i<=mpts;i++) {
			if (y[i] < y[ilo]) ilo=i;
			if (y[i] > y[ihi]) {
				inhi=ihi;
				ihi=i;
			} else if (y[i] > y[inhi])
				if (i != ihi) inhi=i;
		}
		rtol=2.0*fabs(y[ihi]-y[ilo])/(fabs(y[ihi])+fabs(y[ilo]));

/* old version: only the ftol check is implemented */
/*
		if (rtol < ftol) break;
*/
                /* g. r. v. 7/2/98 */
                if ( rtol < ftol ) {
                   for ( i=1, flag=0; i<=ndim; i++ ) {
                      for ( j=1, maxs=0; j<mpts; j++ ) {
                         mmm = fabs ( p[ j + 1 ][ i ] - p[ j ][ i ] );
                         if ( mmm > maxs ) {
                            maxs = mmm;
                         }
                         mmm = fabs ( p[ mpts ][ i ] - p[ 1 ][ i ] );
                         if ( mmm > maxs ) {
                            maxs = mmm;
                         }
                      }
                      if ( maxs < vtol ) {
                         flag++;
                      }
                   }
                   if ( flag == (UINTx1)ndim ) break;
                }

		if (*nfunk >= NMAX) {

                   /* Too many iterations */
                   *nr_status = 1;
                   free_dvector( &psum[ 1 ] );
                   return;
                }
		ytry=amotry(p,y,psum,ndim,funk,ihi,nfunk,-ALPHA,nr_status);
                if (*nr_status) return; /* memory allocation error check */
		if (ytry <= y[ilo])
			ytry=amotry(p,y,psum,ndim,funk,ihi,nfunk,GAMMA,nr_status);
                        if (*nr_status) return; /* memory allocation error check */
		else if (ytry >= y[inhi]) {
			ysave=y[ihi];
			ytry=amotry(p,y,psum,ndim,funk,ihi,nfunk,BETA,nr_status);
                        if (*nr_status) return; /* memory allocation error check */
			if (ytry >= ysave) {
				for (i=1;i<=mpts;i++) {
					if (i != ilo) {
						for (j=1;j<=ndim;j++) {
							psum[j]=0.5*(p[i][j]+p[ilo][j]);
							p[i][j]=psum[j];
						}
						y[i]=(*funk)(psum);
					}
				}
				*nfunk += ndim;
				GET_PSUM
			}
		}
	}
	free_dvector( &psum[ 1 ] );
}

double amotry(p,y,psum,ndim,funk,ihi,nfunk,fac,nr_status)
double **p,*y,*psum,(*funk)(),fac;
INTx4 ndim,ihi,*nfunk,*nr_status;
{
	INTx4 j;
	double fac1,fac2,ytry,*ptry,*dvector();
	void free_dvector();

	ptry=dvector(1,ndim,nr_status);
        if (*nr_status) return 0.0; /* memory allocation check */
	fac1=(1.0-fac)/ndim;
	fac2=fac1-fac;
	for (j=1;j<=ndim;j++) ptry[j]=psum[j]*fac1-p[ihi][j]*fac2;
	ytry=(*funk)(ptry);
	++(*nfunk);
	if (ytry < y[ihi]) {
		y[ihi]=ytry;
		for (j=1;j<=ndim;j++) {
			psum[j] += ptry[j]-p[ihi][j];
			p[ihi][j]=ptry[j];
		}
	}
	free_dvector( &ptry[ 1 ] );
	return ytry;
}

#undef ALPHA
#undef BETA
#undef GAMMA
#undef NMAX




void dlubksb(a,n,indx,b,nr_status)
double **a,b[];
INTx4 n,*indx,*nr_status;
{
	INTx4 i,ii=0,ip,j;
	double sum;

	for (i=1;i<=n;i++) {
		ip=indx[i];
		sum=b[ip];
		b[ip]=b[i];
		if (ii)
			for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
		else if (sum) ii=i;
		b[i]=sum;
	}
	for (i=n;i>=1;i--) {
		sum=b[i];
		for (j=i+1;j<=n;j++) sum -= a[i][j]*b[j];
		b[i]=sum/a[i][i];
	}
}



#ifdef TINY
#undef TINY
#endif
#define TINY 1.0-20;

void dludcmp(a,n,indx,d,nr_status)
INTx4 n,*indx,*nr_status;
double **a,*d;
{
	INTx4 i,imax,j,k;
	double big,dum,sum,temp;
	double *vv,*dvector();
	void free_dvector();

	vv=dvector(1,n,nr_status);
        if (*nr_status) return; /* memory allocation error check */
	*d=1.0;
	for (i=1;i<=n;i++) {
		big=0.0;
		for (j=1;j<=n;j++)
			if ((temp=fabs(a[i][j])) > big) big=temp;
		if (big == 0.0) {

                   /* Singular matrix */
                   *nr_status = 1;
                   return;
                }
		vv[i]=1.0/big;
	}
	for (j=1;j<=n;j++) {
		for (i=1;i<j;i++) {
			sum=a[i][j];
			for (k=1;k<i;k++) sum -= a[i][k]*a[k][j];
			a[i][j]=sum;
		}
		big=0.0;
		for (i=j;i<=n;i++) {
			sum=a[i][j];
			for (k=1;k<j;k++)
				sum -= a[i][k]*a[k][j];
			a[i][j]=sum;
			if ( (dum=vv[i]*fabs(sum)) >= big) {
				big=dum;
				imax=i;
			}
		}
		if (j != imax) {
			for (k=1;k<=n;k++) {
				dum=a[imax][k];
				a[imax][k]=a[j][k];
				a[j][k]=dum;
			}
			*d = -(*d);
			vv[imax]=vv[j];
		}
		indx[j]=imax;
		if (a[j][j] == 0.0) a[j][j]=TINY;
		if (j != n) {
			dum=1.0/(a[j][j]);
			for (i=j+1;i<=n;i++) a[i][j] *= dum;
		}
	}
	free_dvector( &vv[ 1 ] );
}

#undef TINY




#ifdef FREERETURN
#undef FREERETURN
#endif

#define FREERETURN {INTx4 i; for(i=0;i<n;i++) alpha[1+i] +=1;\
        free_dmatrix(&alpha[1],n);free_dvector(&bet[1]);\
	free_ivector(&indx[1]);return;}

void dmnewt(ntrial,x,n,usrfun,tolx,tolf,nr_status)
void (*usrfun)();
INTx4 ntrial,n,*nr_status;
double x[],tolx,tolf;
{
	INTx4 k,i,*indx,*ivector();
	double errx,errf,d,*bet,**alpha,*dvector(),**dmatrix();
	void dludcmp(),dlubksb(),free_ivector(),free_dvector(),
	     free_dmatrix();

	indx=ivector(1,n,nr_status);
        if (*nr_status) return; /* memory allocation error check */
	bet=dvector(1,n,nr_status);
        if (*nr_status) {

           /* memory allocation error */
           free_ivector(&indx[1]);
           return;
        }
	alpha=dmatrix(1,n,1,n,nr_status);
        if (*nr_status) {

           /* memory allocation error check */
           free_ivector( &indx[1]);
           free_dvector( &bet[1] );
           return;
        }
	for (k=1;k<=ntrial;k++) {
		(*usrfun)(x,alpha,bet,nr_status);
		if (*nr_status) {

		    /* memory allocation error check */
		    free_ivector( &indx[1]);
		    free_dvector( &bet[1] );
		    return;
		}

		errf=0.0;
		for (i=1;i<=n;i++) errf += fabs(bet[i]);
		if (errf <= tolf) FREERETURN
		dludcmp(alpha,n,indx,&d,nr_status);
                if (*nr_status) FREERETURN
		dlubksb(alpha,n,indx,bet,nr_status);
		errx=0.0;
		for (i=1;i<=n;i++) {
			errx += fabs(bet[i]);
			x[i] += bet[i];
		}
		if (errx <= tolx) FREERETURN
	}
	FREERETURN
}

#undef FREERETURN






void dspline(x,y,n,yp1,ypn,y2,nr_status)
double x[],y[],yp1,ypn,y2[];
INTx4 n,*nr_status;
{
	INTx4 i,k;
	double p,qn,sig,un,*u,*dvector();
	void free_dvector();

	u=dvector(1,n-1,nr_status);
        if (*nr_status) return; /* memory allocation error check */
	if (yp1 > 0.99e30)
		y2[1]=u[1]=0.0;
	else {
		y2[1] = -0.5;
		u[1]=(3.0/(x[2]-x[1]))*((y[2]-y[1])/(x[2]-x[1])- yp1);
	}
	for (i=2;i<=n-1;i++) {
		sig=(x[i]-x[i-1])/(x[i+1]-x[i-1]);
		p=sig*y2[i-1]+2.0;
		y2[i]=(sig-1.0)/p;
		u[i]=(y[i+1]-y[i])/(x[i+1]-x[i]) - (y[i]-y[i-1])/(x[i]-x[i-1]);
		u[i]=(6.0*u[i]/(x[i+1]-x[i-1])-sig*u[i-1])/p;
	}
	if (ypn > 0.99e30)
		qn=un=0.0;
	else {
		qn=0.5;
		un=(3.0/(x[n]-x[n-1]))*(ypn-(y[n]-y[n-1])/(x[n]-x[n-1]));
	}
	y2[n]=(un-qn*u[n-1])/(qn*y2[n-1]+1.0);
	for (k=n-1;k>=1;k--)
		y2[k]=y2[k]*y2[k+1]+u[k];
	free_dvector(&u[ 1 ]);
}









void dsplint(xa,ya,y2a,n,x,y,nr_status)
double xa[],ya[],y2a[],x,*y;
INTx4 n,*nr_status;
{
	INTx4 klo,khi,k;
	double h,b,a;

	klo=1;
	khi=n;
	while (khi-klo > 1) {
		k=(khi+klo) >> 1;
		if (xa[k] > x) khi=k;
		else klo=k;
	}
	h=xa[khi]-xa[klo];
	if (h == 0.0) {

           /* Bad XA input */
           *nr_status = 1;
           return;
        }
	a=(xa[khi]-x)/h;
	b=(x-xa[klo])/h;
	*y=a*ya[klo]+b*ya[khi]+((a*a*a-a)*y2a[klo]+(b*b*b-b)*y2a[khi])*(h*h)/6.0;
}





#ifdef SIGN
#undef SIGN
#endif

#define SIGN(a,b) ((b)<0 ? -fabs(a) : fabs(a))

void dtqli(d,e,n,z,nr_status)
double d[],e[],**z;
INTx4 n,*nr_status;
{
	INTx4 m,l,iter,i,k;
	double s,r,p,g,f,dd,c,b;

	for (i=2;i<=n;i++) e[i-1]=e[i];
	e[n]=0.0;
	for (l=1;l<=n;l++) {
		iter=0;
		do {
			for (m=l;m<=n-1;m++) {
				dd=fabs(d[m])+fabs(d[m+1]);
				if (fabs(e[m])+dd == dd) break;
			}
			if (m != l) {
				if (iter++ == 30) {

                                   /* too many iterations */
                                   *nr_status = 1;
                                   return;
                                }
				g=(d[l+1]-d[l])/(2.0*e[l]);
				r=sqrt((g*g)+1.0);
				g=d[m]-d[l]+e[l]/(g+SIGN(r,g));
				s=c=1.0;
				p=0.0;
				for (i=m-1;i>=l;i--) {
					f=s*e[i];
					b=c*e[i];
					if (fabs(f) >= fabs(g)) {
						c=g/f;
						r=sqrt((c*c)+1.0);
						e[i+1]=f*r;
						c *= (s=1.0/r);
					} else {
						s=f/g;
						r=sqrt((s*s)+1.0);
						e[i+1]=g*r;
						s *= (c=1.0/r);
					}
					g=d[i+1]-p;
					r=(d[i]-g)*s+2.0*c*b;
					p=s*r;
					d[i+1]=g+p;
					g=c*r-b;
					/* Next loop can be omitted if eigenvectors not wanted */
					for (k=1;k<=n;k++) {
						f=z[k][i+1];
						z[k][i+1]=s*z[k][i]+c*f;
						z[k][i]=c*z[k][i]-s*f;
					}
				}
				d[l]=d[l]-p;
				e[l]=g;
				e[m]=0.0;
			}
		} while (m != l);
	}
}






void dtred2(a,n,d,e,nr_status)
double **a,d[],e[];
INTx4 n,*nr_status;
{
	INTx4 l,k,j,i;
	double scale,hh,h,g,f;

	for (i=n;i>=2;i--) {
		l=i-1;
		h=scale=0.0;
		if (l > 1) {
			for (k=1;k<=l;k++)
				scale += fabs(a[i][k]);
			if (scale == 0.0)
				e[i]=a[i][l];
			else {
				for (k=1;k<=l;k++) {
					a[i][k] /= scale;
					h += a[i][k]*a[i][k];
				}
				f=a[i][l];
				g = f>0 ? -sqrt(h) : sqrt(h);
				e[i]=scale*g;
				h -= f*g;
				a[i][l]=f-g;
				f=0.0;
				for (j=1;j<=l;j++) {
				/* Next statement can be omitted if eigenvectors not wanted */
					a[j][i]=a[i][j]/h;
					g=0.0;
					for (k=1;k<=j;k++)
						g += a[j][k]*a[i][k];
					for (k=j+1;k<=l;k++)
						g += a[k][j]*a[i][k];
					e[j]=g/h;
					f += e[j]*a[i][j];
				}
				hh=f/(h+h);
				for (j=1;j<=l;j++) {
					f=a[i][j];
					e[j]=g=e[j]-hh*f;
					for (k=1;k<=j;k++)
						a[j][k] -= (f*e[k]+g*a[i][k]);
				}
			}
		} else
			e[i]=a[i][l];
		d[i]=h;
	}
	/* Next statement can be omitted if eigenvectors not wanted */
	d[1]=0.0;
	e[1]=0.0;
	/* Contents of this loop can be omitted if eigenvectors not
			wanted except for statement d[i]=a[i][i]; */
	for (i=1;i<=n;i++) {
		l=i-1;
		if (d[i]) {
			for (j=1;j<=l;j++) {
				g=0.0;
				for (k=1;k<=l;k++)
					g += a[i][k]*a[k][j];
				for (k=1;k<=l;k++)
					a[k][j] -= g*a[k][i];
			}
		}
		d[i]=a[i][i];
		a[i][i]=1.0;
		for (j=1;j<=l;j++) a[j][i]=a[i][j]=0.0;
	}
}








INTx4 *ivector(nl,nh,nr_status)
INTx4 nl,nh,*nr_status;
{
	INTx4 *v;

	v=(INTx4 *)MEMSIP_alloc((size_t) (nh-nl+1)*sizeof(INTx4));
	if (!v) {
	    *nr_status = 2;
            return NULL;
	}
	return v-nl;
}

double *dvector(nl,nh,nr_status)
INTx4 nl,nh,*nr_status;
{
	double *v;

	v=(double *)MEMSIP_alloc((size_t) (nh-nl+1)*sizeof(double));
	if (!v) {
           *nr_status = 2;
           return NULL;
        }
	return v-nl;
}



double **dmatrix(nrl,nrh,ncl,nch,nr_status)
INTx4 nrl,nrh,ncl,nch,*nr_status;
{
	INTx4 i,j;
	double **m;

	m=(double **) MEMSIP_alloc((size_t) (nrh-nrl+1)*sizeof(double*));
	if (!m) {
	    *nr_status = 2;
	    return NULL;
	}
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
	    m[i]=(double *) MEMSIP_alloc((size_t) (nch-ncl+1)*sizeof(double));
	    if (!m[i]) {
                *nr_status = 2;
		for (j=nrl;j<i;j++) {
		   MEMSIP_free((void **)&m[j] );
		}
		return NULL;
	    }
	    m[i] -= ncl;
	}
	return m;
}







void free_ivector(v)
INTx4 *v;
{
        MEMSIP_free((void **)&v );
}

void free_dvector(v)
double *v;
{
        MEMSIP_free( (void **)&v );
}

void free_dmatrix(m,nrl)
double **m;
INTx4 nrl;
{
	INTx4 i;

	for ( i=0; i<nrl; i++ ) MEMSIP_free( (void **)&m[i] );
	MEMSIP_free( (void **)&m );
}
