/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_ANNF

      $FUNCTION          

      $ROUTINE           PMDSIP_ANNF_FormatFieldData
                         PMDSIP_ANNF_SetAnnFile
                         PMDSIP_ANNF_WriteAnnFile

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       01-OCT-97     DDN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <stdlib.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include PMDS_INTF_H
#include PMDS_PGLB_H

/* ==========================================================================
                        LOCAL DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSLD_ANNF_num_len

      $DESCRIPTION  length of the num field in annotation file

   $EH
   ========================================================================== */
#define PMDSLD_ANNF_num_len 4

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSLD_ANNF_esa_fname_len

      $DESCRIPTION  length of the esa field name field in annotation file

   $EH
   ========================================================================== */
#define PMDSLD_ANNF_esa_fname_len 40

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSLD_ANNF_value_len

      $DESCRIPTION  length of the value field in annotation file

   $EH
   ========================================================================== */
#define PMDSLD_ANNF_value_len 25

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSLD_ANNF_units_len

      $DESCRIPTION  length of the units field in annotation file

   $EH
   ========================================================================== */
#define PMDSLD_ANNF_units_len 16

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSLD_ANNF_tag_len

      $DESCRIPTION  length of the tag field in annotation file

   $EH
   ========================================================================== */
#define PMDSLD_ANNF_tag_len 25

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSLD_ANNF_remark_len

      $DESCRIPTION  length of the remark field in annotation file

   $EH
   ========================================================================== */
#define PMDSLD_ANNF_remark_len 30

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSLD_ANNF_max_rows_per_field

      $DESCRIPTION  maximum number of rows per record in annotation file

   $EH
   ========================================================================== */
#define PMDSLD_ANNF_max_rows_per_field 20


/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_ANNF_SetAnnFile

        $TYPE

        $INPUT        mode        : operation type onto the annotation file
                      data_type   : type of data to be read
                      label_p     : pointer to the current data label
                      data_p      : pointer to the current data to be read

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_error_paramaters
                      ERRSID_PMDS_error_create_file
                      ERRSID_PMDS_error_close_file

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_ANNF_SetAnnFile
                        (/*IN    */ PMDSPT_mode_type     mode,
                         /*IN    */ PMDSPT_data_type     data_type,
                         /*IN    */ char                *label_p,
                         /*IN    */ void                *data_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_ANNF_SetAnnFile";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   char                  *file_name_p;/* pointer to the annotation file name */
   char                  *buf_p;      /* pointer to current data to be used */
   static FILE           *fp = NULL;  /* pointer to the annotation file */
   PMDSPT_cfg_field      *field_p;    /* pointer to the cfg field */
   INTx4                  ichar;      /* convenient loop variable */
   INTx4                  irow;       /* convenient loop variable */
   INTx4                  field_num;  /* convenient loop variable */
   INTx4                  pos_list1[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  len_list1[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  pos_num1;   /* num of positions and length in array */
   INTx4                  pos_list2[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  len_list2[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  pos_num2;   /* num of positions and length in array */
   INTx4                  pos_list3[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  len_list3[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  pos_num3;   /* num of positions and length in array */
   INTx4                  pos_list4[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  len_list4[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  pos_num4;   /* num of positions and length in array */
   INTx4                  pos_list5[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  len_list5[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  pos_num5;   /* num of positions and length in array */
   INTx4                  pos_list6[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  len_list6[PMDSLD_ANNF_max_rows_per_field];
   INTx4                  pos_num6;   /* num of positions and length in array */
   char                   header_data[256];/* header buffer */
   char                   record_data[256];/* record buffer */
   char                   field_data[256];/* field data buffer */
   char                   field_data1[256];/* field data buffer */
   char                   field_data2[256];/* field data buffer */
   char                   field_data3[1024];/* field data buffer */
   char                   field_data4[256];/* field data buffer */
   char                   field_data5[256];/* field data buffer */
   char                   field_data6[256];/* field data buffer */
   char                   msg[512];   /* error message buffer */
  
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check parameters
   ========================================================================== */
   if((mode != PMDSPE_ANNF_FileNameOpen)                                      &&
      (mode != PMDSPE_ANNF_FileNameWrite)                                     &&
      (mode != PMDSPE_ANNF_FileNameClose))
   {
      sprintf(msg, "Wrong access mode to the annotation file");
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_error_paramaters,
                        msg );
   }

   if((data_type != PMDSPE_ANNF_FileNameType)                                 &&
      (data_type != PMDSPE_ANNF_DataType)                                     &&
      (data_type != PMDSPE_ANNF_HeaderType)                                   &&
      (data_type != PMDSPE_ANNF_FieldType))
   {
      sprintf(msg, "Wrong data type used in the annotation file");
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_error_paramaters,
                        msg );
   }

   if((data_p == NULL) && (data_type != PMDSPE_ANNF_HeaderType))
   {
      sprintf(msg, "Null data used in the annotation file");
      ERRSIM_set_error( status_code,
                        ERRSID_PMDS_error_paramaters,
                        msg );
   }

/* ==========================================================================
   Check if data type is the annotation file name
   ========================================================================== */
   if(data_type == PMDSPE_ANNF_FileNameType)
   {
      file_name_p = (char *)data_p;
      if(mode == PMDSPE_ANNF_FileNameOpen)
      {
         if((fp = fopen(file_name_p, "w")) == NULL)
         {
            sprintf(msg, "Cannot create annotation file <%s>", file_name_p);
            ERRSIM_set_error( status_code,
                              ERRSID_PMDS_error_create_file,
                              msg );
         }
      }
      else if(mode == PMDSPE_ANNF_FileNameClose)
      {
         if(fp == NULL)
         {
            sprintf(msg, "Cannot close annotation file");
            ERRSIM_set_error( status_code,
                              ERRSID_PMDS_error_close_file,
                              msg );
         }
         fclose(fp);
         fp = NULL;
      }
   }
/* ==========================================================================
   Check if data type is the data type
   ========================================================================== */
   else if(data_type == PMDSPE_ANNF_DataType)
   {
      buf_p = (char *)data_p;
      PMDSIP_ANNF_WriteAnnFile(label_p, buf_p, fp);
   }
/* ==========================================================================
   Check if data type is the header data type
   ========================================================================== */
   else if(data_type == PMDSPE_ANNF_HeaderType)
   {
      sprintf(header_data, "%*.*s %-*.*s   %-*.*s %-*.*s %-*.*s %-*.*s",
         PMDSLD_ANNF_num_len, PMDSLD_ANNF_num_len, "Pos",
         PMDSLD_ANNF_esa_fname_len, PMDSLD_ANNF_esa_fname_len, "Esa field name",
         PMDSLD_ANNF_value_len, PMDSLD_ANNF_value_len, "Value",
         PMDSLD_ANNF_units_len, PMDSLD_ANNF_units_len, "Units",
         PMDSLD_ANNF_tag_len, PMDSLD_ANNF_tag_len, "Tag",
         PMDSLD_ANNF_remark_len, PMDSLD_ANNF_remark_len, "Remark");
      PMDSIP_ANNF_WriteAnnFile(header_data, NULL, fp);
   }
/* ==========================================================================
   Check if data type is the field data type
   ========================================================================== */
   else if(data_type == PMDSPE_ANNF_FieldType)
   {
/* ==========================================================================
      Set the position field
   ========================================================================== */
      field_p = (PMDSPT_cfg_field *)data_p;
      sprintf(field_data1, "%d", field_p->num);
      PMDSIP_ANNF_FormatFieldData(PMDSLD_ANNF_num_len, pos_list1,
         len_list1, &pos_num1, field_data1);

/* ==========================================================================
      Set the esa equivalent name field
   ========================================================================== */
      sprintf(field_data2, "%s", field_p->esa_name);
      for(ichar = (strlen(field_data2) - 1); ichar >= 0; ichar--)
      {
         if(!(isspace(field_data2[ichar])))
         {
            break;
         }
         field_data2[ichar] = '\0';
      }

      if((strlen(field_data2)) <= 0)
         strcpy(field_data2, "-");

      PMDSIP_ANNF_FormatFieldData(PMDSLD_ANNF_esa_fname_len, pos_list2,
         len_list2, &pos_num2, field_data2);

/* ==========================================================================
      Set the value field
   ========================================================================== */
      sprintf(field_data3, "%s", label_p);

      for(ichar = 0; ichar < strlen(field_data3); ichar++)
      {
         if(field_data3[ichar] != ' ')
         {
            strcpy(field_data3, (field_data3 + ichar));
            break;
         }
      }

      for(ichar = (strlen(field_data3) - 1); ichar >= 0; ichar--)
      {
         if(((field_data3[ichar] >= '0') && (field_data3[ichar] <= '9')) ||
            ((field_data3[ichar] >= 'A') && (field_data3[ichar] <= 'z')) ||
             (field_data3[ichar] == '.') ||
             (field_data3[ichar] == ',') ||
             (field_data3[ichar] == '_') ||
             (field_data3[ichar] == '-') ||
             (field_data3[ichar] == '+'))
         {
            break;
         }
         field_data3[ichar] = '\0';
      }

      if((strlen(field_data3)) <= 0)
         strcpy(field_data3, "-");

      PMDSIP_ANNF_FormatFieldData(PMDSLD_ANNF_value_len, pos_list3,
         len_list3, &pos_num3, field_data3);

/* ==========================================================================
      Set the units field
   ========================================================================== */
      sprintf(field_data4, "%s", field_p->units);
      PMDSIP_ANNF_FormatFieldData(PMDSLD_ANNF_units_len, pos_list4,
         len_list4, &pos_num4, field_data4);

/* ==========================================================================
      Set the tag name field
   ========================================================================== */
      sprintf(field_data5, "%s", field_p->name);
      PMDSIP_ANNF_FormatFieldData(PMDSLD_ANNF_tag_len, pos_list5,
        len_list5, &pos_num5, field_data5);

/* ==========================================================================
      Set the remark field
   ========================================================================== */
      sprintf(field_data6, "%s", field_p->remark);
      PMDSIP_ANNF_FormatFieldData(PMDSLD_ANNF_remark_len, pos_list6,
        len_list6, &pos_num6, field_data6);

/* ==========================================================================
      Loop onto the record row(s)
   ========================================================================== */
      memset(record_data, '\0', sizeof(record_data));
      irow = 0;
      while(TRUE)
      {
         field_num = 6;
         if(pos_num1 > irow)
         {
            sprintf(field_data, "%*.*s ",
              len_list1[irow], PMDSLD_ANNF_num_len,
              field_data1 + pos_list1[irow]);
         }
         else
         {
            sprintf(field_data, "%*.*s ",
              PMDSLD_ANNF_num_len, PMDSLD_ANNF_num_len, " ");
            field_num--;
         }
         strcpy(record_data, field_data);

         if(pos_num2 > irow)
         {
            sprintf(field_data, "%-*.*s%-*.*s",
              len_list2[irow], len_list2[irow],
              field_data2 + pos_list2[irow],
              (PMDSLD_ANNF_esa_fname_len - len_list2[irow]) + 3,
              (PMDSLD_ANNF_esa_fname_len - len_list2[irow]) + 3,
              " ");
         }
         else
         {
            sprintf(field_data, "%-*.*s   ",
              PMDSLD_ANNF_esa_fname_len, PMDSLD_ANNF_esa_fname_len, " ");
            field_num--;
         }
         strcat(record_data, field_data);

         if(pos_num3 > irow)
         {
            sprintf(field_data, "%-*.*s%-*.*s",
               len_list3[irow], len_list3[irow],
               field_data3 + pos_list3[irow],
               (PMDSLD_ANNF_value_len - len_list3[irow]) + 1,
               (PMDSLD_ANNF_value_len - len_list3[irow]) + 1,
               " ");
         }
         else
         {
            sprintf(field_data, "%-*.*s ",
               PMDSLD_ANNF_value_len, PMDSLD_ANNF_value_len, " ");
            field_num--;
         }
         strcat(record_data, field_data);

         if(pos_num4 > irow)
         {
            sprintf(field_data, "%-*.*s%-*.*s",
              len_list4[irow], len_list4[irow],
              field_data4 + pos_list4[irow],
              (PMDSLD_ANNF_units_len - len_list4[irow]) + 1,
              (PMDSLD_ANNF_units_len - len_list4[irow]) + 1,
              " ");
         }
         else
         {
            sprintf(field_data, "%-*.*s ",
              PMDSLD_ANNF_units_len, PMDSLD_ANNF_units_len, " ");
            field_num--;
         }
         strcat(record_data, field_data);

         if(pos_num5 > irow)
         {
            sprintf(field_data, "%-*.*s%-*.*s",
               len_list5[irow], len_list5[irow],
               field_data5 + pos_list5[irow],
               (PMDSLD_ANNF_tag_len - len_list5[irow]) + 1,
               (PMDSLD_ANNF_tag_len - len_list5[irow]) + 1,
               " ");
         }
         else
         {
            sprintf(field_data, "%-*.*s ",
               PMDSLD_ANNF_tag_len, PMDSLD_ANNF_tag_len, " ");
            field_num--;
         }
         strcat(record_data, field_data);

         if(pos_num6 > irow)
         {
            sprintf(field_data, "%-*.*s",
              len_list6[irow], PMDSLD_ANNF_remark_len,
              field_data6 + pos_list6[irow]);
         }
         else
         {
            sprintf(field_data, "%-*.*s",
              PMDSLD_ANNF_remark_len, PMDSLD_ANNF_remark_len, " ");
            field_num--;
         }
         strcat(record_data, field_data);

         if(field_num <= 0)
            break;

         PMDSIP_ANNF_WriteAnnFile(record_data, NULL, fp);
         irow++;
      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSIP_ANNF_SetAnnfile */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_ANNF_WriteAnnFile

        $TYPE

        $INPUT        label_p     : label data to be written into file line
                      data_p      : data to be written into file line
                      fp          : pointer to the annotation file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure allows to write a new line into the file

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_ANNF_WriteAnnFile
                        (/*IN    */ char                *label_p,
                         /*IN    */ char                *data_p,
                         /*IN    */ FILE                *fp)
{
/* ==========================================================================
   Write data into file
   ========================================================================== */
   if(fp != NULL)
   {
      if(label_p != NULL)
         fprintf(fp, "%s", label_p);
      if(data_p != NULL)
         fprintf(fp, "%s", data_p);

      fprintf(fp, "\n");
      fflush( fp );
   }
}/* PMDSIP_ANNF_WriteAnnFile */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_ANNF_FormatFieldData

        $TYPE

        $INPUT        max_field_len : maximum length reachable by field data
                      pos_list_p    : array of positions
                      len_list_p    : array of length(s)
                      pos_num_p     : number of positions
                      data_p        : pointer to field data

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure allows to split field data in multi-line

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_ANNF_FormatFieldData
                        (/*IN    */ INTx4                max_field_len,
                         /*IN    */ INTx4               *pos_list_p,
                         /*IN    */ INTx4               *len_list_p,
                         /*IN    */ INTx4               *pos_num_p,
                         /*IN    */ char                *data_p)
{
/* ==========================================================================
   Local variables
   ========================================================================== */
   INTx4                  ipos;       /* convenient loop variable */
   INTx4                  curr_len;   /* convenient loop variable */
   INTx4                  start_pos;  /* convenient loop variable */
   INTx4                  pos_num;    /* convenient loop variable */

/* ==========================================================================
   Set default data
   ========================================================================== */
   *pos_num_p    = 0;
   pos_list_p[0] = 0;
   len_list_p[0] = 0;
/* ==========================================================================
   Loop onto the field data length
   ========================================================================== */
   ipos      = 0;
   curr_len  = 0;
   start_pos = 0;
   pos_num   = 0;
   if(data_p != NULL)
   {
      if((strlen(data_p)) > max_field_len)
      {
         pos_num = (INTx4)(strlen(data_p) / max_field_len);
         curr_len = pos_num * max_field_len;
         for(ipos = 0; ipos < pos_num; ipos++)
         {
            pos_list_p[ipos] = (ipos * max_field_len);
            len_list_p[ipos] = max_field_len;
         }
         if(curr_len < strlen(data_p))
         {
            pos_list_p[pos_num] = curr_len;
            len_list_p[pos_num] = (strlen(data_p) - curr_len);
            pos_num++;
         }
         *pos_num_p = pos_num;
      }
      else
      {
         *pos_num_p    = 1;
         pos_list_p[0] = 0;
         len_list_p[0] = max_field_len;
      }
   }

}/* PMDSIP_ANNF_FormatFieldData */


