/* ==========================================================================
   $MODULE_HEADER

      $NAME              IANN_PUTP

      $FUNCTION          Contains the procedures to put the annotations stored
                         in the global structure IANNIV_ImageAnnot[imanum] in
                         a Toolbox TIFF file.

      $ROUTINE           IANNIP_PUTP_ImageAnnot
			 IANNPP_PUTP_SetTag
			 IANNIP_PUTP_UpdateProcHistory

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       17-JUN-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <string.h>
#include <stdio.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include IANN_TAGS_H
#include TIFS_INTF_H
#include MATH_INTF_H
#include IANN_INTF_H
#include IANN_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_PUTP_ImageAnnot

        $TYPE         PROCEDURE

        $INPUT        chan          : the open TIFF file channel in which the
                                      parameters must be stored
                      img           : the image number in the TIFF file
                      imanum        : progressive number of the image (more
                                      than one images can be simultaneously
                                      handled)

        $MODIFIED     NONE

        $OUTPUT       The tags of the image are stored

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the image
                                                  annotations that must be
                                                  stored

        $RET_STATUS   ERRSID_IANN_not_allow_imanum

        $DESCRIPTION  This procedure stores the tags annotated in the global
                      structure <IANNIV_ImageAnnot[imanum]> in the TIFF file
                      defined by the channel <chan>

        $WARNING      The TIFF file in which the tags must be stored must be
                      opened and initialised befor the procedure calling

   $EH
   ========================================================================== */

void IANNIP_PUTP_ImageAnnot
                        (/*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx1               imanum,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNIP_PUTP_ImageAnnot";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   char                   tag[ LDEFID_char_num ] = "";
   char                   numb[ 4 ] = "";
   float                  val = 1.e+3;
   UINTx4                 i;
   float                  coeff[ IANNID_GRSRMAX ];
   float                  new_pixel_spacing = 0.;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image index
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) {
      sprintf( numb, "%0u", imanum );
      ERRSIM_set_error( status_code, ERRSID_IANN_not_allow_imanum, numb );
   }

/* ==========================================================================
   General INFO
   ========================================================================== */
   switch ( IANNIV_ImageAnnot[ imanum ].ProductType ) {
      case IANNIE_prod_ERS1_RAW:                      /* RAW product */
         sprintf( tag, "ERS1.SAR.RAW");
         break;
      case IANNIE_prod_ERS1_SLC:                      /* SLC product */
         sprintf( tag, "ERS1.SAR.SLC");
         break;
      case IANNIE_prod_ERS1_SLCI:                     /* SLCI product */
         sprintf( tag, "ERS1.SAR.SLCI");
         break;
      case IANNIE_prod_ERS1_PRI:                      /* PRI product */
         sprintf( tag, "ERS1.SAR.PRI");
         break;
      case IANNIE_prod_ERS1_GEC:                      /* GEC product */
         sprintf( tag, "ERS1.SAR.GEC");
         break;
      case IANNIE_prod_ERS1_GTC:                      /* GTC product */
         sprintf( tag, "ERS1.SAR.GTC");
         break;
      case IANNIE_prod_ERS2_RAW:                      /* RAW product */
         sprintf( tag, "ERS2.SAR.RAW");
         break;
      case IANNIE_prod_ERS2_SLC:                      /* SLC product */
         sprintf( tag, "ERS2.SAR.SLC");
         break;
      case IANNIE_prod_ERS2_SLCI:                     /* SLCI product */
         sprintf( tag, "ERS2.SAR.SLCI");
         break;
      case IANNIE_prod_ERS2_PRI:                      /* PRI product */
         sprintf( tag, "ERS2.SAR.PRI");
         break;
      case IANNIE_prod_ERS2_GEC:                      /* GEC product */
         sprintf( tag, "ERS2.SAR.GEC");
         break;
      case IANNIE_prod_ERS2_GTC:                      /* GTC product */
         sprintf( tag, "ERS2.SAR.GTC");
         break;
      case IANNIE_prod_undef:                     /* product unknown */
         sprintf( tag, "-");
         ERRSIM_print_warning( "Tag LOG_VOL_ID not defined" );
         break;
   }
   IANNPP_PUTP_SetTag( LOG_VOL_ID, tag, (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII,
                       chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if ( strcmp ( IANNIV_ImageAnnot[ imanum ].dataFormat, "" ) ) {
      IANNPP_PUTP_SetTag( DATA_FORMAT,
         IANNIV_ImageAnnot[ imanum ].dataFormat,
            (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan, img,
            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

   if ( strcmp ( IANNIV_ImageAnnot[ imanum ].sourceId, "" ) ) {
      IANNPP_PUTP_SetTag( SOURCE_ID,
         IANNIV_ImageAnnot[ imanum ].sourceId,
            (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan, img,
            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

   sprintf( tag, "%0d", IANNIV_ImageAnnot[ imanum ].numberOfVolumes );
   IANNPP_PUTP_SetTag( NUMBER_OF_VOLUMES, tag, (UINTx1)TYPE_ASCII, 
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if ( strcmp ( IANNIV_ImageAnnot[ imanum ].SceneReferenceNumbers, "" ) ) {
      IANNPP_PUTP_SetTag( SCENE_REF_NUM,
         IANNIV_ImageAnnot[ imanum ].SceneReferenceNumbers,
            (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan, img,
            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

   memset( tag, 0, LDEFID_char_num );
   switch ( IANNIV_ImageAnnot[ imanum ].ProcessingPAF ) {
      case IANNIE_proc_CPAF:
         sprintf( tag, "CPAF");
      break;
      case IANNIE_proc_DPAF:
         sprintf( tag, "D-PAF");
      break;
      case IANNIE_proc_UPAF:
         sprintf( tag, "U-PAF");
      break;
      case IANNIE_proc_IPAF:
         sprintf( tag, "IP");
      break;
      case IANNIE_proc_APAF:
         sprintf( tag, "APAF");
      break;
      case IANNIE_proc_SPAF:
         sprintf( tag, "SPAF");
      break;
      case IANNIE_proc_undef:
#ifdef __PLAPLA__
         ERRSIM_print_warning( "Tag PROCESSING_PAF not defined" );
#endif
      break;
   }
   IANNPP_PUTP_SetTag( PROCESSING_PAF, tag, (UINTx1)TYPE_ASCII,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   memset( tag, 0, LDEFID_char_num );
   switch ( IANNIV_ImageAnnot[ imanum ].ProcessorName ) {
      case IANNIE_sproc_VMP:
         sprintf( tag, "VMP_PROD");
      break;
      case IANNIE_sproc_ESAR:
         sprintf( tag, "SAR-ERS");
      break;
      case IANNIE_sproc_Bangkok:
         sprintf( tag, "Bangkok");
      break;
      case IANNIE_sproc_undef:
         ERRSIM_print_warning( "Tag PROCESSOR_NAME not defined" );
      break;
   }
   IANNPP_PUTP_SetTag( PROCESSOR_NAME, tag, (UINTx1)TYPE_ASCII,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Calibration section
   ========================================================================== */
   IANNPP_PUTP_SetTag( ABSOLUTE_CALIB_K,
                       &IANNIV_ImageAnnot[ imanum ].CalibrationConstant,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( INCID_ANGLE_CENTRE_RANGE,
                    &IANNIV_ImageAnnot[imanum].IncidenceAngleAtMiddleRange_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( ANTENNA_BORESIGHT,
                       &IANNIV_ImageAnnot[ imanum ].BoresightAngle_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Corners coordinates section
   ========================================================================== */
   IANNPP_PUTP_SetTag( TOP_LEFT_LAT, &IANNIV_ImageAnnot[imanum].TopLeftLat_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( TOP_LEFT_LON, &IANNIV_ImageAnnot[imanum].TopLeftLon_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( TOP_RIGHT_LAT,&IANNIV_ImageAnnot[imanum].TopRightLat_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( TOP_RIGHT_LON,&IANNIV_ImageAnnot[imanum].TopRightLon_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( BOTTOM_LEFT_LAT,
                       &IANNIV_ImageAnnot[ imanum ].BottomLeftLat_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( BOTTOM_LEFT_LON,
                       &IANNIV_ImageAnnot[ imanum ].BottomLeftLon_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( BOTTOM_RIGHT_LAT,
                       &IANNIV_ImageAnnot[ imanum ].BottomRightLat_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( BOTTOM_RIGHT_LON,
                       &IANNIV_ImageAnnot[ imanum ].BottomRightLon_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( CENTRE_GEODETIC_LAT,
                       &IANNIV_ImageAnnot[ imanum ].CentreGeodeticLat_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( CENTRE_GEODETIC_LON,
                       &IANNIV_ImageAnnot[imanum].CentreGeodeticLon_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( EARLY_ZERO_FILL_RECORD_NUMBER,
                       &IANNIV_ImageAnnot[ imanum ].TopZeroFilledLines,
                       (UINTx1)TYPE_INT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( LATE_ZERO_FILL_RECORD_NUMBER,
                       &IANNIV_ImageAnnot[ imanum ].BottomZeroFilledLines,
                       (UINTx1)TYPE_INT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( NEAR_ZERO_FILL_PIXEL_NUMBER,
                       &IANNIV_ImageAnnot[ imanum ].LeftZeroFilledPixels,
                       (UINTx1)TYPE_INT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( FAR_ZERO_FILL_PIXEL_NUMBER,
                       &IANNIV_ImageAnnot[ imanum ].RightZeroFilledPixels,
                       (UINTx1)TYPE_INT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Map projection section
   ========================================================================== */
   memset( tag, '\0', LDEFID_char_num );
   switch( IANNIV_ImageAnnot[ imanum ].MapProjectionType ) {
      case IANNIE_proj_UTM:
         sprintf( tag, "UTM");
         IANNPP_PUTP_SetTag( UTM_SCALE_FACTOR,
                             &IANNIV_ImageAnnot[ imanum ].ProjectionScaleFactor,
                             (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         IANNPP_PUTP_SetTag( UTM_CENTER_PROJ_LAT,
                       &IANNIV_ImageAnnot[imanum].ProjectionCentralParallel_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         IANNPP_PUTP_SetTag( UTM_CENTER_PROJ_LON,
                       &IANNIV_ImageAnnot[imanum].ProjectionCentralMeridian_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         IANNPP_PUTP_SetTag( TOP_LEFT_EAST,
                             &IANNIV_ImageAnnot[ imanum ].TopLeftEast_m,
                             (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         IANNPP_PUTP_SetTag( TOP_LEFT_NORTH,
                             &IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m,
                             (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         IANNPP_PUTP_SetTag( UTM_FALSE_EAST,
                             &IANNIV_ImageAnnot[ imanum ].FalseEast_m,
                             (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         IANNPP_PUTP_SetTag( UTM_FALSE_NORTH,
                             &IANNIV_ImageAnnot[ imanum ].FalseNorth_m,
                             (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      break;
      case IANNIE_proj_UPS:
         sprintf( tag, "UPS");
         IANNPP_PUTP_SetTag( UPS_SCALE_FACTOR,
                             &IANNIV_ImageAnnot[ imanum ].ProjectionScaleFactor,
                             (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         IANNPP_PUTP_SetTag( UPS_CENTER_PROJ_LAT,
                       &IANNIV_ImageAnnot[imanum].ProjectionCentralParallel_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         IANNPP_PUTP_SetTag( UPS_CENTER_PROJ_LON,
                       &IANNIV_ImageAnnot[imanum].ProjectionCentralMeridian_deg,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         IANNPP_PUTP_SetTag( TOP_LEFT_EAST,
                             &IANNIV_ImageAnnot[ imanum ].TopLeftEast_m,
                             (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );

         IANNPP_PUTP_SetTag( TOP_LEFT_NORTH,
                             &IANNIV_ImageAnnot[ imanum ].TopLeftNorth_m,
                             (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      break;
      case IANNIE_proj_ground:
         sprintf( tag, "Ground range");
      break;
      case IANNIE_proj_slant:
         sprintf( tag, "Slant range");
      break;
      case IANNIE_proj_undef:
         ERRSIM_print_warning( "Tag MAP_PROJ_DESCR not defined" );
      break;
   }
   IANNPP_PUTP_SetTag( MAP_PROJ_DESCR, tag, (UINTx1)TYPE_ASCII,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Spacing section
   ========================================================================== */
   IANNPP_PUTP_SetTag( LINE_SPACING,
                       &IANNIV_ImageAnnot[ imanum ].LineSpacing_m,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( PIXEL_SPACING,
                       &IANNIV_ImageAnnot[ imanum ].PixelSpacing_m,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Timing section
   ========================================================================== */
   IANNPP_PUTP_SetTag( YEAR_DATA_POINT,
                       &IANNIV_ImageAnnot[ imanum ].FirstSTVectYear,
                       (UINTx1)TYPE_SHORT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( MONTH_DATA_POINT,
                       &IANNIV_ImageAnnot[ imanum ].FirstSTVectMonth,
                       (UINTx1)TYPE_SHORT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( DAY_DATA_POINT,
                       &IANNIV_ImageAnnot[ imanum ].FirstSTVectDay,
                       (UINTx1)TYPE_SHORT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( SECOND_OF_DAY,
                       &IANNIV_ImageAnnot[ imanum ].FirstSTVectSeconds,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( ( IANNIV_ImageAnnot[ imanum ].ProductType == IANNIE_prod_ERS1_RAW ) ||
       ( IANNIV_ImageAnnot[ imanum ].ProductType == IANNIE_prod_ERS2_RAW ) ) {
      if ( strcmp ( IANNIV_ImageAnnot[
                    imanum ].ZeroDopplerAzimuthFirstLine_UTC, "" ) ) {
         IANNPP_PUTP_SetTag( RAW_FIRST_LINE_UTC_TIME,
            IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthFirstLine_UTC,
            (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan, img,
            status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
   }
   else {
      if ( strcmp ( IANNIV_ImageAnnot[
                    imanum ].ZeroDopplerAzimuthFirstLine_UTC, "" ) ) {
         IANNPP_PUTP_SetTag( ZERO_DOPP_AZIM_FIRST_TIME,
                             IANNIV_ImageAnnot[
                             imanum ].ZeroDopplerAzimuthFirstLine_UTC,
                             (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
   }

   if ( strcmp ( IANNIV_ImageAnnot[ imanum ].ZeroDopplerAzimuthLastLine_UTC,
                 "" ) ) {
      IANNPP_PUTP_SetTag( ZERO_DOPP_AZIM_LAST_TIME,
                          IANNIV_ImageAnnot[
                          imanum ].ZeroDopplerAzimuthLastLine_UTC,
                          (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan, img,
                          status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

   IANNPP_PUTP_SetTag( RADAR_WAVELEN,
                       &IANNIV_ImageAnnot[ imanum ].RadarWaveLength_m,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   /* convert the sampling rate from Hz to MHz */
   val = IANNIV_ImageAnnot[ imanum ].SamplingRate_Hz * ( 1.e-6 );
   IANNPP_PUTP_SetTag( SAMPLING_RATE, &val, (UINTx1)TYPE_FLOAT,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   /* convert the range first time in milliseconds */
   val = IANNIV_ImageAnnot[ imanum ].RangeFirstTime_sec * 1.e+3;
   IANNPP_PUTP_SetTag( ZERO_DOPP_RANGE_FIRST_TIME, &val, (UINTx1)TYPE_FLOAT,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( PRF, &IANNIV_ImageAnnot[ imanum ].PulseRepetitionFreq_Hz,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( PRF_EQUIVALENT,
		       &IANNIV_ImageAnnot[
			    imanum ].EquivalentPulseRepetitionFreq_Hz,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
		       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( CROSS_DOPP_FREQ_CONST,
                       &IANNIV_ImageAnnot[imanum].DopplerFreqCoeff_Hz_sec[0],
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( CROSS_DOPP_FREQ_LINEAR,
                       &IANNIV_ImageAnnot[imanum].DopplerFreqCoeff_Hz_sec[1],
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( CROSS_DOPP_FREQ_QUAD,
                       &IANNIV_ImageAnnot[imanum].DopplerFreqCoeff_Hz_sec[2],
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( DOPPL_CENTR_CUB_COEFF,
                       &IANNIV_ImageAnnot[imanum].DopplerFreqCoeff_Hz_sec[3],
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( DOPPL_CENTR_CUB_COEFF,
                       &IANNIV_ImageAnnot[imanum].DopplerFreqCoeff_Hz_sec[3],
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Ellipsoid section
   ========================================================================== */
   /* rescale from meters to km */
   val = IANNIV_ImageAnnot[ imanum ].SemiMajorAxis_m * ( 1.e-3 );
   IANNPP_PUTP_SetTag( ELLIPSOID_SEMIMAJOR_AXIS, &val, (UINTx1)TYPE_FLOAT,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   val = IANNIV_ImageAnnot[ imanum ].SemiMinorAxis_m * ( 1.e-3 );
   IANNPP_PUTP_SetTag( ELLIPSOID_SEMIMINOR_AXIS, &val, (UINTx1)TYPE_FLOAT,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   State vectors section
   ========================================================================== */
   IANNPP_PUTP_SetTag( TIME_INTERVAL_DATA_POINT,
		       &IANNIV_ImageAnnot[ imanum ].STVectIntervalTime_sec,
		       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
		       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( NB_DATA_POINTS,
                       &IANNIV_ImageAnnot[ imanum ].NStateVectors,
                       (UINTx1)TYPE_UBYTE, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if ( IANNIV_ImageAnnot[ imanum ].NStateVectors > 0 ) {
      for( i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++ ) {

         /* X state vector */
         IANNPP_PUTP_SetTag( (X_SAT_1+i),
                             &IANNIV_ImageAnnot[ imanum ].X_STVec_m[ i ],
                             (UINTx1)TYPE_DOUBLE, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
      for( i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++ ) {

         /* Y state vector */
         IANNPP_PUTP_SetTag( (Y_SAT_1+i),
                             &IANNIV_ImageAnnot[ imanum ].Y_STVec_m[ i ],
                             (UINTx1)TYPE_DOUBLE, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
      for( i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++ ) {

         /* Z state vector */
         IANNPP_PUTP_SetTag( (Z_SAT_1+i),
                             &IANNIV_ImageAnnot[ imanum ].Z_STVec_m[ i ],
                             (UINTx1)TYPE_DOUBLE, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
      for( i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++ ) {

         /* VX state vector */
         IANNPP_PUTP_SetTag( (VX_SAT_1+i),
                             &IANNIV_ImageAnnot[ imanum ].VX_STVec_m_sec[ i ],
                             (UINTx1)TYPE_DOUBLE, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
      for( i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++ ) {

         /* VY state vector */
         IANNPP_PUTP_SetTag( (VY_SAT_1+i),
                             &IANNIV_ImageAnnot[ imanum ].VY_STVec_m_sec[ i ],
                             (UINTx1)TYPE_DOUBLE, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
      for( i=0;i<IANNIV_ImageAnnot[ imanum ].NStateVectors;i++ ) {

         /* VZ state vector */
         IANNPP_PUTP_SetTag( (VZ_SAT_1+i),
                             &IANNIV_ImageAnnot[ imanum ].VZ_STVec_m_sec[ i ],
                             (UINTx1)TYPE_DOUBLE, (UINTx1)TYPE_ASCII, chan, img,
                             status_code );
         ERRSIM_on_err_goto_exit( *status_code );
      }
   }

/* ==========================================================================
   Ground to slant section
   ========================================================================== */
   IANNPP_PUTP_SetTag( GR_SR_POL_DEGREE,
                       &IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree,
                       (UINTx1)TYPE_UBYTE, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   for( i=0;i<=IANNIV_ImageAnnot[ imanum ].GroundToSlantDegree;i++ ) {

      /* ground to slant coeff of polynomials */
/*
      switch ( IANNIV_ImageAnnot[ imanum ].ProcessingPAF ) {
         case IANNIE_proc_CPAF:
         case IANNIE_proc_DPAF:
         case IANNIE_proc_UPAF:
         case IANNIE_proc_APAF:
         case IANNIE_proc_SPAF:
         case IANNIE_proc_IPAF:
            switch ( IANNIV_ImageAnnot[ imanum ].ProcessorName ) {
               case IANNIE_sproc_VMP: {
                  new_pixel_spacing = IANNIV_ImageAnnot[ imanum ].PixelSpacing_m
                     * IANNIV_ImageAnnot[ imanum ].XScalingFactor;

                  coeff[i] =
                     IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff[ i ] /
                     (POW( new_pixel_spacing, i ) * POW( 1.e+3, i ));
               }
               break;
               case IANNIE_sproc_ESAR:
                  coeff[ i ] =
                     IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff[ i ];
               break;
               case IANNIE_sproc_Bangkok:
                  coeff[ i ] =
                     IANNIV_ImageAnnot[ imanum ].GroundToSlantCoeff[ i ] *
                     1.e-3;
               break;
               case IANNIE_sproc_undef:
                  ERRSIM_print_warning( "Tags GR_SR_COEFF_# not definible" );
                  coeff[ i ] = 0;
               break;
            }
         break;
         case IANNIE_proc_undef:
            ERRSIM_print_warning( "Tags GR_SR_COEFF_# not definible" );
            coeff[ i ] = 0;
         break;
      }
      IANNPP_PUTP_SetTag( (GR_SR_COEFF_1+i), &coeff[ i ], (UINTx1)TYPE_FLOAT,
                          (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
*/
      IANNPP_PUTP_SetTag( (GR_SR_COEFF_1+i), &IANNIV_ImageAnnot[
                          imanum ].GroundToSlantCoeff[ i ], (UINTx1)TYPE_DOUBLE,
                          (UINTx1)TYPE_ASCII, chan, img, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Image processing INFO
   ========================================================================== */
   IANNPP_PUTP_SetTag( SUBIMG_TOP_LEFT_ROW,
                       &IANNIV_ImageAnnot[ imanum ].SubImageTopLeftRow,
                       (UINTx1)TYPE_INT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( SUBIMG_TOP_LEFT_COL,
                       &IANNIV_ImageAnnot[ imanum ].SubImageTopLeftCol,
                       (UINTx1)TYPE_INT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   memset( tag, '\0', LDEFID_char_num );
   switch( IANNIV_ImageAnnot[ imanum ].PixelType ) {
      case IANNIE_pixt_undef:
         ERRSIM_print_warning( "Tag PIXEL_TYPE not defined" );
      break;
      case IANNIE_pixt_complex:
         sprintf( tag, "COMPLEX" );
      break;
      case IANNIE_pixt_amplitude:
         sprintf( tag, "AMPLITUDE");
      break;
      case IANNIE_pixt_power:
         sprintf( tag, "POWER");
      break;
   }
   IANNPP_PUTP_SetTag( PIXEL_TYPE, tag, (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII,
                       chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( SCALING_FACTOR,
		       &IANNIV_ImageAnnot[ imanum ].ScalingFactor,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
   fprintf ( stdout, "\n\n\n --------- Trace ---------\n" );
   fprintf ( stdout, "\n IANNIV_ImageAnnot[%d].LooksNumber = %f", imanum,
             IANNIV_ImageAnnot[ imanum ].LooksNumber );
#endif
   IANNPP_PUTP_SetTag( NOM_NB_LOOKS_AZIM, &IANNIV_ImageAnnot[ imanum ].LooksNumber,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   val = IANNIV_ImageAnnot[ imanum ].ReferenceSlantRange_m * ( 1.e-3 );
   IANNPP_PUTP_SetTag( NORMALISATION_REF_RANGE, &val, (UINTx1)TYPE_FLOAT,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
   fprintf ( stdout, "\n\n\n --------- Trace ---------\n" );
   fprintf ( stdout, "\n IANNIV_ImageAnnot[%d].ProductReplicaPower = %f", imanum,
             IANNIV_ImageAnnot[ imanum ].ProductReplicaPower );
#endif
   IANNPP_PUTP_SetTag( REPLICA_POWER,
                       &IANNIV_ImageAnnot[ imanum ].ProductReplicaPower,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( CHIRP_AVERAGE_DENSITY,
                       &IANNIV_ImageAnnot[ imanum ].ChirpAverageDensity,
                       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if ( strcmp ( IANNIV_ImageAnnot[ imanum ].ProcessingHistory, "" ) ) {
      IANNPP_PUTP_SetTag( PROC_HISTORY,IANNIV_ImageAnnot[
                          imanum ].ProcessingHistory,
                          (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan, img,
                          status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Flags about the applied processing corrections
   ========================================================================== */
#ifdef __TRACE__
   fprintf ( stdout, "\n\n\n --------- Trace ---------\n" );
   fprintf ( stdout, "\n IANNIV_ImageAnnot[%d].AntennaPatternCorrectionFlag",
             imanum );
   fprintf ( stdout, " = %d",
             IANNIV_ImageAnnot[ imanum ].AntennaPatternCorrectionFlag );
#endif
   memset( tag, '\0', LDEFID_char_num);
   if ( IANNIV_ImageAnnot[ imanum ].AntennaPatternCorrectionFlag )
      sprintf( tag, "1");
   else sprintf( tag, "0");
   IANNPP_PUTP_SetTag( ANTENNA_ELEVATION_GAIN_FLAG, tag, (UINTx1)TYPE_ASCII,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   memset( tag, '\0', LDEFID_char_num);
   if ( IANNIV_ImageAnnot[ imanum ].RangeSpreadingLossCompensationFlag )
      sprintf( tag, "1");
   else sprintf( tag, "0");
   IANNPP_PUTP_SetTag( SPREAD_LOSS_COMP_FLAG, tag, (UINTx1)TYPE_ASCII,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   memset( tag, '\0', LDEFID_char_num);
   if ( IANNIV_ImageAnnot[ imanum ].CalibrationConstantApplicationFlag )
      sprintf( tag, "1");
   else sprintf( tag, "0");
   IANNPP_PUTP_SetTag( CALIB_CONST_APPLI_FLAG, tag, (UINTx1)TYPE_ASCII,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   memset( tag, '\0', LDEFID_char_num);
   if ( IANNIV_ImageAnnot[ imanum ].ADCSaturationCompensationFlag )
      sprintf( tag, "1");
   else sprintf( tag, "0");
   IANNPP_PUTP_SetTag( ADC_SATUR_COMPENS_FLAG, tag, (UINTx1)TYPE_ASCII,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   memset( tag, '\0', LDEFID_char_num);
   if ( IANNIV_ImageAnnot[ imanum ].ReplicaPowerCompensationFlag )
      sprintf( tag, "1");
   else sprintf( tag, "0");
   IANNPP_PUTP_SetTag( REPLICA_POWER_COMP_FLAG, tag, (UINTx1)TYPE_ASCII,
                       (UINTx1)TYPE_ASCII, chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Co-registration INFO
   ========================================================================== */
   if ( strcmp ( IANNIV_ImageAnnot[ imanum ].MasterSceneReference, "" ) ) {
      IANNPP_PUTP_SetTag( MASTER_REFERENCE_NUMBER,
                          IANNIV_ImageAnnot[ imanum ].MasterSceneReference,
                          (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII, chan, img,
                          status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Resampling factors
   ========================================================================== */
   IANNPP_PUTP_SetTag( X_SCALE_FACTOR,
		       &IANNIV_ImageAnnot[ imanum ].XScalingFactor,
		       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
		       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( Y_SCALE_FACTOR,
		       &IANNIV_ImageAnnot[ imanum ].YScalingFactor,
		       (UINTx1)TYPE_FLOAT, (UINTx1)TYPE_ASCII, chan, img,
		       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   ImageScale tag
   ========================================================================== */
   memset( tag, '\0', LDEFID_char_num );
   switch( IANNIV_ImageAnnot[ imanum ].ImageScale ) {
      case IANNIE_iscale_undef:
         ERRSIM_print_warning( "Tag IMAGE_SCALE not defined" );
         break;
      case IANNIE_iscale_linear:
         sprintf( tag, "LINEAR" );
         break;
      case IANNIE_iscale_db:
         sprintf( tag, "DB");
         break;
   }
   IANNPP_PUTP_SetTag( IMAGE_SCALE, tag, (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII,
                       chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Row/Col Transient
   ========================================================================== */
   IANNPP_PUTP_SetTag( ROW_TRANSIENT,
                       &IANNIV_ImageAnnot[ imanum ].RowTransient,
                       (UINTx1)TYPE_INT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   IANNPP_PUTP_SetTag( COL_TRANSIENT,
                       &IANNIV_ImageAnnot[ imanum ].ColTransient,
                       (UINTx1)TYPE_INT, (UINTx1)TYPE_ASCII, chan, img,
                       status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Presentation tag
   ========================================================================== */
   memset( tag, '\0', LDEFID_char_num );
   switch( IANNIV_ImageAnnot[ imanum ].Presentation ) {
      case IANNIE_pres_undef:
         ERRSIM_print_warning( "Tag PRESENTATION not defined" );
         break;
      case IANNIE_pres_normal:
         sprintf( tag, "NORMAL" );
         break;
      case IANNIE_pres_geo:
         sprintf( tag, "GEO");
         break;
   }
   IANNPP_PUTP_SetTag( PRESENTATION, tag, (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII,
                       chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Orbit Direction tag
   ========================================================================== */
   memset( tag, '\0', LDEFID_char_num );
   switch( IANNIV_ImageAnnot[ imanum ].OrbitDirection) {
      case IANNIE_orbit_undef:
         ERRSIM_print_warning( "Tag ORBIT_DIRECTION not defined" );
         break;
      case IANNIE_orbit_ascend:
         sprintf( tag, "ASCENDING" );
         break;
      case IANNIE_orbit_descend:
         sprintf( tag, "DESCENDING");
         break;
   }
   IANNPP_PUTP_SetTag( ORBIT_DIRECTION, tag, (UINTx1)TYPE_ASCII, (UINTx1)TYPE_ASCII,
                       chan, img, status_code );
   ERRSIM_on_err_goto_exit( *status_code );


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IANNIP_PUTP_ImageAnnot */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNPP_PUTP_SetTag

        $TYPE         PROCEDURE

        $INPUT        tag_num     : tag number
                      p_tag       : pointer to the tag value
                      tag_type    : tag type
                      out_type    : the output tag type among the predefined
                                    type in the TIFS_INTF.H include file
                      chan        : channel of the opened TIFF file in which to
                                    store the tag_val
                      img         : image number in the TIFF file

        $MODIFIED     NONE

        $OUTPUT       The tag is stored in the file

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IANN_tag_type_not_known

        $DESCRIPTION  This procedure store the tag passed in input in the file
                      TIFF with the channel <chan>

        $WARNING      NONE

   $EH
   ========================================================================== */

void IANNPP_PUTP_SetTag
                        (/*IN    */ UINTx4               tag_num,
                         /*IN    */ void                *p_tag,
                         /*IN    */ UINTx1               tag_type,
                         /*IN    */ UINTx1               out_type,
                         /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNPP_PUTP_SetTag";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   TIFSIT_par             param;
   char                   store_tag[ LDEFID_char_num ] = "";
   char                   tag_str[ LDEFID_char_line ] = "";

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Fill the param structure
   ========================================================================== */
   param.tag = tag_num;
   param.type = out_type;

/* ==========================================================================
   Fill the parameters values
   ========================================================================== */
   if ( out_type == TYPE_ASCII ) {

/* ==========================================================================
   It must be transformed in a string
   ========================================================================== */
      switch( tag_type ) {
         case TYPE_UBYTE:
            sprintf( store_tag, "%u", *( (UINTx1 *)p_tag) );
            param.val = (void *)store_tag;
            param.length = strlen( store_tag ) + 1;
         break;
         case TYPE_USHORT:
            sprintf( store_tag, "%u", *( (UINTx2 *)p_tag) );
            param.val = (void *)store_tag;
            param.length = strlen( store_tag ) + 1;
         break;
         case TYPE_UINT:
            sprintf( store_tag, "%u", *( (UINTx4 *)p_tag) );
            param.val = (void *)store_tag;
            param.length = strlen( store_tag ) + 1;
         break;
         case TYPE_ASCII:
            param.val = (void *)p_tag;
            param.length = strlen( p_tag ) + 1;
         break;
         case TYPE_BYTE:
            sprintf( store_tag, "%d", *( (INTx1 *)p_tag) );
            param.val = (void *)store_tag;
            param.length = strlen( store_tag ) + 1;
         break;
         case TYPE_SHORT:
            sprintf( store_tag, "%d", *( (INTx2 *)p_tag) );
            param.val = (void *)store_tag;
            param.length = strlen( store_tag ) + 1;
         break;
         case TYPE_INT:
            sprintf( store_tag, "%d", *( (INTx4 *)p_tag) );
            param.val = (void *)store_tag;
            param.length = strlen( store_tag ) + 1;
         break;
         case TYPE_FLOAT:
            sprintf( store_tag, "%f", *( (float *)p_tag) );
            param.val = (void *)store_tag;
            param.length = strlen( store_tag ) + 1;
         break;
         case TYPE_DOUBLE:
            sprintf( store_tag, "%e", *( (double *)p_tag) );
            param.val = (void *)store_tag;
            param.length = strlen( store_tag ) + 1;
         break;
         default:

            /* type not known */
            sprintf( tag_str, "%u", param.tag );
            ERRSIM_set_error( status_code, ERRSID_IANN_tag_type_not_known,
                              tag_str );
      }
   }
   else {

/* ==========================================================================
   The tag is written in its own format
   ========================================================================== */
      param.val = (void *)p_tag;
      param.length = TIFSIV_Size[ tag_type ];
   }

/* ==========================================================================
   Store the parameter
   ========================================================================== */
   TIFSIP_store_par( chan, img, &param, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IANNPP_PUTP_SetTag */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IANNIP_PUTP_UpdateProcHistory

        $TYPE         PROCEDURE

        $INPUT        imanum      : progressive number of the image
                      taskname    : name of the task executing the update
		      usrstrng	  : user string to append to the processing
				    history current string

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum].ProcessingHistory

        $RET_STATUS   ERRSID_IANN_not_allow_imanum

        $DESCRIPTION  This procedure update the PROC_HISTORY tag

        $WARNING      NONE

   $EH
   ========================================================================== */
void IANNIP_PUTP_UpdateProcHistory
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ char                *taskname,
			 /*IN    */ char                *usrstrng,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IANNIP_PUTP_UpdateProcHistory";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   char                   sectString[ IANNID_sect_size ];
   char                   tmpSectString[ LDEFID_char_num ];
   char                   time_stamp[ 40 ];
   INTx4                  len;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image index
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX ) {
      ERRSIM_set_error( status_code, ERRSID_IANN_not_allow_imanum, "" );
   }

/* ==========================================================================
   Build current section string
   ========================================================================== */
   sprintf( tmpSectString, "\n%s %s %s", taskname,
	    ERRSIF_LODT_out_date( time_stamp ), usrstrng );

/* ==========================================================================
   Check the processing history length
   ========================================================================== */
   len = strlen( tmpSectString );
   if ( len >= IANNID_sect_size ) {
      ERRSIM_print_warning( IANNIV_ERRS_error_message[
				 ERRSID_IANN_string_too_long ] );
      len = IANNID_sect_size;
   }

/* ==========================================================================
   Fill the section string
   ========================================================================== */
   memset( sectString, 32, sizeof( sectString ) );
   memcpy( sectString, tmpSectString, len );

#ifdef __TRACE__
   printf("\nBefore\n");
   printf("<%s>\n", IANNIV_ImageAnnot[ imanum ].ProcessingHistory  );
   printf("Length = %d\n", 
           strlen( IANNIV_ImageAnnot[ imanum ].ProcessingHistory ) );
#endif

/* ==========================================================================
   Set or append current task and time
   ========================================================================== */
   if( !strcmp( IANNIV_ImageAnnot[ imanum ].ProcessingHistory, "" ) ) {
      strncpy( IANNIV_ImageAnnot[ imanum ].ProcessingHistory,
               sectString,
               IANNID_sect_size - 1 );
   }
   else if( strlen( IANNIV_ImageAnnot[ imanum ].ProcessingHistory ) >= 
            ((IANNID_sect_size - 1) * IANNID_histo_sect) ) {
      memcpy( (void *) IANNIV_ImageAnnot[ imanum ].ProcessingHistory,
              (void *) &( IANNIV_ImageAnnot[ imanum ].ProcessingHistory[ 
                                              IANNID_sect_size - 1 ] ),
              (IANNID_sect_size - 1) * IANNID_histo_sect );
      IANNIV_ImageAnnot[ imanum ].ProcessingHistory[
              (IANNID_sect_size - 1) * (IANNID_histo_sect - 1) ] = '\0';
      strncat( IANNIV_ImageAnnot[ imanum ].ProcessingHistory,
               sectString,
	       IANNID_sect_size - 1 );
   }
   else {
      strncat( IANNIV_ImageAnnot[ imanum ].ProcessingHistory,
               sectString,
	       IANNID_sect_size - 1 );
   }

#ifdef __TRACE__
   printf("\nAfter\n");
   printf("<%s>\n", IANNIV_ImageAnnot[ imanum ].ProcessingHistory  );
   printf("Length = %d\n", 
           strlen( IANNIV_ImageAnnot[ imanum ].ProcessingHistory ) );
#endif

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IANNIP_PUTP_UpdateProcHistory */
