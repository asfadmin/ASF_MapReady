/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_GRID

      $FUNCTION          

      $ROUTINE           PMDSIP_GRID_DrawArea

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       20-OCT-97     DDN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */
#define PMDSLD_GRID_stbf_prefix       "stbfont"
#define PMDSLD_GRID_stbf_sfx_rowcol   "r"
#define PMDSLD_GRID_stbf_sfx_minus    "m"
#define PMDSLD_GRID_stbf_sfx_latlon   "l"
#define PMDSLD_GRID_stbf_sfx_point    "p"
#define PMDSLD_GRID_stbf_extension    ".tif"

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <stdlib.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include IANN_TAGS_H
#include IANN_INTF_H
#include COOR_INTF_H
#include LDEF_INTF_H
#include TIFS_INTF_H
#include PMDS_INTF_H
#include PMDS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_GRID_DrawArea

        $TYPE

        $INPUT        tif_input_file  : input tiff file
                      tif_output_file : output tiff file
                      max_ipoint      : number of points in the x axis
                      max_jpoint      : number of points in the y axis
                      lat_lon_flag    : flag to draw lines in latlon or pixline
                      drawing_mode    : transparent, overwrite, none, mode(s)

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_GRID_DrawArea
                        (/*IN    */ char                *tif_input_file,
                         /*IN    */ UINTx1               full_ima_num,
                         /*IN    */ UINTx1               und_ima_num,
                         /*IN    */ char                *tif_output_file,
                         /*IN    */ INTx4                max_ipoint,
                         /*IN    */ INTx4                max_jpoint,
                         /*IN    */ INTx4                lat_lon_flag,
                         /*IN    */ PMDSIT_drawing_mode  drawing_mode,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_GRID_DrawArea";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   float            top_left_lat;     /* */
   float            top_left_lon;     /* */
   float            top_right_lat;    /* */
   float            top_right_lon;    /* */
   float            bottom_left_lat;  /* */
   float            bottom_left_lon;  /* */
   float            bottom_right_lat; /* */
   float            bottom_right_lon; /* */

   MATHIT_LLH       lat_lon_data;     /* */
   MATHIT_RC        row_col_data;     /* */

   INTx4            image_width;      /* */
   INTx4            image_height;     /* */

   INTx4            anno_image_width;
   INTx4            anno_image_height;

   INTx4            ilimit;           /* */
   INTx4            jlimit;           /* */
   INTx4            ipoint;           /* */
   INTx4            jpoint;           /* */
   float            x_step;           /* */
   float            y_step;           /* */
   float            anno_x_step;      /* */
   float            anno_y_step;      /* */

   MATHIT_RC       *point = (MATHIT_RC *) NULL;            
                                      /* */

   INTx4            npoint;           /* */

   INTx4            ichar;            /* */
   INTx4            pos;              /* */
   INTx4            pos1;             /* */
   INTx4            anno_pos;         /* */
   INTx4            row;              /* */
   INTx4            col;              /* */

   char             file_type[256];   /* */
   PMDSIT_drawing_mode  
                    old_drawing_mode; /* */
   INTx4            lat_lon_found;    /* */

   TIFSIT_basicpar  bpar;             /* basic parameter structure */
   TIFSIT_par       param;            /* parameter structure */
   INTx4            inp_channel;      /* input file channel */
   void             *imgline;         /* image line buffer */
   UINTx1           *image_buf;       /* */

   UINTx2          *tag = (UINTx2 *) NULL;        
                                      /* array of tags */

   INTx4            itag;             /* convenient loop variable */
   INTx4            iline;            /* convenient loop variable */
   INTx4            nimage = 1;       /* image number */
   INTx4            iimage = 0;       /* current image index */
   UINTx2           inp_npar;         /* number of parameters in the image */
   UINTx2           out_npar;         /* number of parameters in the image */
   GIOSIT_io        out_io;           /* handle for output file */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Open the input file
   ========================================================================== */
   TIFSIP_open_tiff( tif_input_file, 'r', &inp_channel, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_imgnum( inp_channel, &nimage, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_blockinfo( inp_channel, iimage, &bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_parnum( inp_channel, iimage, &inp_npar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get image size
   ========================================================================== */
   image_width  = bpar.imagewidth;
   image_height = bpar.imagelength;

#ifdef __TRACE__

fprintf(stderr,"Debug: ----------------------------------------------------\n");
fprintf(stderr,"Debug:  input tiff file = <%s>\n", tif_input_file);
fprintf(stderr,"Debug: ----------------------------------------------------\n");
fprintf(stderr,"Debug:         inp_npar = <%d>\n", inp_npar);
fprintf(stderr,"Debug:      image_width = <%d>\n", bpar.imagewidth);
fprintf(stderr,"Debug:     image_height = <%d>\n", bpar.imagelength);
fprintf(stderr,"Debug:   sampleperpixel = <%d>\n", bpar.sampleperpixel);
fprintf(stderr,"Debug:    bitspersample = <%d>\n", bpar.bitspersample[0]);
fprintf(stderr,"Debug: ----------------------------------------------------\n");
fprintf(stderr,"Debug: output tiff file = <%s>\n", tif_output_file);
fprintf(stderr,"Debug: ----------------------------------------------------\n");

#endif

/* ==========================================================================
   Open the read mode of the input file
   ========================================================================== */
   TIFSIP_open_line( inp_channel, iimage, 'x', 0, (image_width - 1),
      status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Allocate memory for the image buffer
   ========================================================================== */
   if((image_buf = (UINTx1 *) MEMSIP_alloc(image_width * image_height *
      sizeof(UINTx1))) == NULL)
   {
      ERRSIM_set_error( status_code, ERRSID_PMDS_alloc_memory, "image file");
   }

/* ==========================================================================
   Loop onto the file line(s)
   ========================================================================== */
   for(iline = 0; iline < image_height; iline++)
   {
/* ==========================================================================
      Read line from input file
   ========================================================================== */
      TIFSIP_read_line(inp_channel, iimage, iline, &imgline, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Copy the image line just read
   ========================================================================== */
      memcpy((void *)(image_buf + (iline * image_width)), imgline, image_width);
   }


#ifdef __TRACE__

fprintf(stderr,"Debug:              PRF = <%f>\n", IANNIV_ImageAnnot[ und_ima_num  ].EquivalentPulseRepetitionFreq_Hz);
fprintf(stderr,"Debug:     TOP_LEFT_LAT = <%f>\n", IANNIV_ImageAnnot[ und_ima_num  ].TopLeftLat_deg);
fprintf(stderr,"Debug:     TOP_LEFT_LON = <%f>\n", IANNIV_ImageAnnot[ und_ima_num  ].TopLeftLon_deg);
fprintf(stderr,"Debug:    TOP_RIGHT_LAT = <%f>\n", IANNIV_ImageAnnot[ und_ima_num  ].TopRightLat_deg);
fprintf(stderr,"Debug:    TOP_RIGHT_LON = <%f>\n", IANNIV_ImageAnnot[ und_ima_num  ].TopRightLon_deg);
fprintf(stderr,"Debug:  BOTTOM_LEFT_LAT = <%f>\n", IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLat_deg);
fprintf(stderr,"Debug:  BOTTOM_LEFT_LON = <%f>\n", IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLon_deg);
fprintf(stderr,"Debug: BOTTOM_RIGHT_LAT = <%f>\n", IANNIV_ImageAnnot[ und_ima_num  ].BottomRightLat_deg);
fprintf(stderr,"Debug: BOTTOM_RIGHT_LON = <%f>\n", IANNIV_ImageAnnot[ und_ima_num  ].BottomRightLon_deg);
fprintf(stderr,"Debug: ----------------------------------------------------\n");

#endif

/* ==========================================================================
   Check the minimum and maximum left latitude
   ========================================================================== */
   top_right_lat = IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLat_deg;
   if(top_right_lat < IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLat_deg)
      top_right_lat = IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLat_deg;
   if(top_right_lat < IANNIV_ImageAnnot[ und_ima_num  ].TopLeftLat_deg)
      top_right_lat = IANNIV_ImageAnnot[ und_ima_num  ].TopLeftLat_deg;
   if(top_right_lat < IANNIV_ImageAnnot[ und_ima_num  ].TopRightLat_deg)
      top_right_lat = IANNIV_ImageAnnot[ und_ima_num  ].TopRightLat_deg;
   if(top_right_lat < IANNIV_ImageAnnot[ und_ima_num  ].BottomRightLat_deg)
      top_right_lat = IANNIV_ImageAnnot[ und_ima_num  ].BottomRightLat_deg;

   top_right_lon = IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLon_deg;
   if(top_right_lon < IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLon_deg)
      top_right_lon = IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLon_deg;
   if(top_right_lon < IANNIV_ImageAnnot[ und_ima_num  ].TopLeftLon_deg)
      top_right_lon = IANNIV_ImageAnnot[ und_ima_num  ].TopLeftLon_deg;
   if(top_right_lon < IANNIV_ImageAnnot[ und_ima_num  ].TopRightLon_deg)
      top_right_lon = IANNIV_ImageAnnot[ und_ima_num  ].TopRightLon_deg;
   if(top_right_lon < IANNIV_ImageAnnot[ und_ima_num  ].BottomRightLon_deg)
      top_right_lon = IANNIV_ImageAnnot[ und_ima_num  ].BottomRightLon_deg;

   bottom_left_lat = IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLat_deg;
   if(bottom_left_lat > IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLat_deg)
      bottom_left_lat = IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLat_deg;
   if(bottom_left_lat > IANNIV_ImageAnnot[ und_ima_num  ].TopLeftLat_deg)
      bottom_left_lat = IANNIV_ImageAnnot[ und_ima_num  ].TopLeftLat_deg;
   if(bottom_left_lat > IANNIV_ImageAnnot[ und_ima_num  ].TopRightLat_deg)
      bottom_left_lat = IANNIV_ImageAnnot[ und_ima_num  ].TopRightLat_deg;
   if(bottom_left_lat > IANNIV_ImageAnnot[ und_ima_num  ].BottomRightLat_deg)
      bottom_left_lat = IANNIV_ImageAnnot[ und_ima_num  ].BottomRightLat_deg;

   bottom_left_lon = IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLon_deg;
   if(bottom_left_lon > IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLon_deg)
      bottom_left_lon = IANNIV_ImageAnnot[ und_ima_num  ].BottomLeftLon_deg;
   if(bottom_left_lon > IANNIV_ImageAnnot[ und_ima_num  ].TopLeftLon_deg)
      bottom_left_lon = IANNIV_ImageAnnot[ und_ima_num  ].TopLeftLon_deg;
   if(bottom_left_lon > IANNIV_ImageAnnot[ und_ima_num  ].TopRightLon_deg)
      bottom_left_lon = IANNIV_ImageAnnot[ und_ima_num  ].TopRightLon_deg;
   if(bottom_left_lon > IANNIV_ImageAnnot[ und_ima_num  ].BottomRightLon_deg)
      bottom_left_lon = IANNIV_ImageAnnot[ und_ima_num  ].BottomRightLon_deg;

/* ==========================================================================
   Set the other corners
   ========================================================================== */
   top_left_lat     = top_right_lat;
   top_left_lon     = bottom_left_lon;
   bottom_right_lat = bottom_left_lat;
   bottom_right_lon = top_right_lon;

#ifdef __TRACE__

fprintf(stderr,"Debug: ----------------------------------------------------\n");
fprintf(stderr,"Debug:     top_left_lat = <%f>\n", top_left_lat);
fprintf(stderr,"Debug:     top_left_lon = <%f>\n", top_left_lon);
fprintf(stderr,"Debug:    top_right_lat = <%f>\n", top_right_lat);
fprintf(stderr,"Debug:    top_right_lon = <%f>\n", top_right_lon);
fprintf(stderr,"Debug:  bottom_left_lat = <%f>\n", bottom_left_lat);
fprintf(stderr,"Debug:  bottom_left_lon = <%f>\n", bottom_left_lon);
fprintf(stderr,"Debug: bottom_right_lat = <%f>\n", bottom_right_lat);
fprintf(stderr,"Debug: bottom_right_lon = <%f>\n", bottom_right_lon);
fprintf(stderr,"Debug: ----------------------------------------------------\n");

#endif

/* ==========================================================================
   Save old values
   ========================================================================== */
   old_drawing_mode = drawing_mode;

/* ==========================================================================
   Check if it is lat_lon
   ========================================================================== */
   if(lat_lon_flag == TRUE)
   {
      if(((INTx4)top_left_lat == 0) && ((INTx4)top_left_lon == 0) &&
         ((INTx4)top_right_lat == 0) && ((INTx4)top_right_lon == 0) &&
         ((INTx4)bottom_left_lat == 0) && ((INTx4)bottom_left_lon == 0) &&
         ((INTx4)bottom_right_lat == 0) && ((INTx4)bottom_right_lon == 0))
      {
         ERRSIM_print_warning( "Drawing ROWCOL grid" );
         lat_lon_found = FALSE;
      }
      else
      {
         lat_lon_found = TRUE;
      }
   }
   else
   {
      lat_lon_found = FALSE;
   }

/* ==========================================================================
   Check if coordinate conversion is allowed
   ========================================================================== */
   if( lat_lon_found == TRUE ) {

/* ==========================================================================
      Initialize coordinate conversion
   ========================================================================== */
      COORIP_CONV_Init( und_ima_num, status_code);
      if( *status_code != STC( ERRSID_normal ) ) {
         lat_lon_found = FALSE;
         ERRSIM_print_warning( "Drawing ROWCOL grid" );
      }
   }
   
/* ==========================================================================
   Loop onto the grid point(s)
   ========================================================================== */
   if( lat_lon_found == TRUE )
   {
/* ==========================================================================
      Draw coordinate type at starting position
   ========================================================================== */
      strcpy(file_type, PMDSLD_GRID_stbf_sfx_latlon);
      pos = 0;
      PMDSIP_GRID_DrawCoord(pos, file_type, drawing_mode,
         image_width, image_height, image_buf, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      x_step = (float)((top_right_lon - top_left_lon) / (float)max_ipoint);
      y_step = (float)((top_left_lat - bottom_left_lat) / (float)max_jpoint);

#ifdef __TRACE__

fprintf(stderr,"Debug:           x step = <%f>\n", x_step);
fprintf(stderr,"Debug:           y step = <%f>\n", y_step);
fprintf(stderr,"Debug:      max ipoints = <%d>\n", max_ipoint);
fprintf(stderr,"Debug:      max jpoints = <%d>\n", max_jpoint);
fprintf(stderr,"Debug:       tot points = <%d>\n", (max_ipoint * max_jpoint));
fprintf(stderr,"Debug: ----------------------------------------------------\n");

#endif

      npoint = 0;

      for(ipoint = 0; ipoint < max_ipoint + 2; ipoint++)
      {
         lat_lon_data.lon = top_left_lon + ((double)x_step * (ipoint + 0));
         for(jpoint = 0; jpoint < max_jpoint + 2; jpoint++)
         {
            lat_lon_data.lat =
               top_left_lat - ((double)y_step * (jpoint + 0));
            lat_lon_data.h   = (double)0.;
            COORIP_CONV_llh_rc(&lat_lon_data, und_ima_num , &row_col_data,
               status_code);
            ERRSIM_on_err_goto_exit( *status_code );

            row = (INTx4)(row_col_data.row);
            col = (INTx4)(row_col_data.col);

            if( IANNIV_ImageAnnot[ und_ima_num ].Presentation ==
                IANNIE_pres_geo ) {
               if( IANNIV_ImageAnnot[ und_ima_num ].OrbitDirection ==
                   IANNIE_orbit_descend ) {
                  col = image_width - col - 1;
               }
               else {
                  row = image_height - row - 1;
               }
            }
            pos = (image_width * row) + col;

/* ==========================================================================
            Store point
   ========================================================================== */
            if( (point = MEMSIP_realloc( 
                            (void *) point, 
                            (size_t) (npoint+1)*sizeof(MATHIT_RC) ) ) ==
                ((MATHIT_RC *) NULL) ) {
               ERRSIM_set_error( status_code, ERRSID_PMDS_err_mem_alloc,
                  "point" );
            }

            point[npoint].col = row_col_data.col;
            point[npoint].row = row_col_data.row;

            if( IANNIV_ImageAnnot[ und_ima_num ].Presentation ==
                IANNIE_pres_geo ) {
               if( IANNIV_ImageAnnot[ und_ima_num ].OrbitDirection ==
                   IANNIE_orbit_descend ) {
                  point[npoint].col = (float) image_width - point[npoint].col - 1.0;
               }
               else {
                  point[npoint].row = (float) image_height - point[npoint].row - 1.0;
               }
            }
            npoint++;

            if((pos >= 0) && (pos < (image_width * image_height)) &&
               (row >= 0) && (col >= 0) &&
               (row < image_height) && (col < image_width))
            {
               image_buf[pos] = 255;
/* ==========================================================================
               Set the position where to write lat,lon value(s)
   ========================================================================== */
               ilimit = (max_ipoint)/2;
               jlimit = (max_jpoint)/2;
               if((ipoint == ilimit) || (jpoint == jlimit))
               {
                  if((ipoint == ilimit) && (jpoint != jlimit))
                  {
                     sprintf(file_type, "%-6.2f", lat_lon_data.lat);
                     if( IANNIV_ImageAnnot[ und_ima_num ].OrbitDirection ==
                         IANNIE_orbit_ascend ) {
                        if( IANNIV_ImageAnnot[ und_ima_num ].Presentation ==
                            IANNIE_pres_geo ) {
                           pos -= ((14 * image_width) - 5);
                        }
                        else {
                           pos -= ((14 * image_width) + 55);
                        }
                     }
                     else {
                        if( IANNIV_ImageAnnot[ und_ima_num ].Presentation ==
                            IANNIE_pres_geo ) {
                           pos -= ((14 * image_width) + 55);
                        }
                        else {
                           pos -= ((14 * image_width) - 5);
                        }
                     }
                     PMDSIP_GRID_DrawCoord(pos, file_type, drawing_mode,
                        image_width, image_height, image_buf, status_code);
                     ERRSIM_on_err_goto_exit( *status_code );
                     
                  }
                  else if((ipoint != ilimit) && (jpoint == jlimit))
                  {
                     sprintf(file_type, "%-6.2f", lat_lon_data.lon);
                     if( IANNIV_ImageAnnot[ und_ima_num ].OrbitDirection ==
                         IANNIE_orbit_ascend ) {
                        if( IANNIV_ImageAnnot[ und_ima_num ].Presentation ==
                            IANNIE_pres_geo ) {
                           pos -= ((14 * image_width) - 5);
                        }
                        else {
                           pos -= ((14 * image_width) + 55);
                        }
                     }
                     else {
                        if( IANNIV_ImageAnnot[ und_ima_num ].Presentation ==
                            IANNIE_pres_geo ) {
                           pos -= ((14 * image_width) + 55);
                        }
                        else {
                           pos -= ((14 * image_width) - 5);
                        }
                     }
                     PMDSIP_GRID_DrawCoord(pos, file_type, drawing_mode,
                        image_width, image_height, image_buf, status_code);
                     ERRSIM_on_err_goto_exit( *status_code );
                  }
                  else if((ipoint == ilimit) && (jpoint == jlimit))
                  {
                     sprintf(file_type, "%-6.2f", lat_lon_data.lon);
                     if( IANNIV_ImageAnnot[ und_ima_num ].OrbitDirection ==
                         IANNIE_orbit_ascend ) {
                        if( IANNIV_ImageAnnot[ und_ima_num ].Presentation ==
                            IANNIE_pres_geo ) {
                           pos -= ((15 * image_width) - 5);
                        }
                        else {
                           pos -= ((15 * image_width) + 55);
                        }
                     }
                     else {
                        if( IANNIV_ImageAnnot[ und_ima_num ].Presentation ==
                            IANNIE_pres_geo ) {
                           pos -= ((15 * image_width) + 55);
                        }
                        else {
                           pos -= ((15 * image_width) - 5);
                        }
                     }
                     PMDSIP_GRID_DrawCoord(pos, file_type, drawing_mode,
                        image_width, image_height, image_buf, status_code);
                     ERRSIM_on_err_goto_exit( *status_code );
                     sprintf(file_type, "%-6.2f", lat_lon_data.lat);
                     pos += (15 * image_width);
                     PMDSIP_GRID_DrawCoord(pos, file_type, drawing_mode,
                        image_width, image_height, image_buf, status_code);
                     ERRSIM_on_err_goto_exit( *status_code );
                  }
               }
            }
         }
      }

/* ==========================================================================
      Draw line(s) into the image buffer
   ========================================================================== */
      PMDSIP_GRID_DrawPoint(point, npoint, max_ipoint + 2, max_jpoint + 2,
         image_width, image_height, image_buf, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

   }
   else
   {
/* ==========================================================================
      Get size of original image from full_ima_num
   ========================================================================== */
      anno_image_width = IANNIV_ImageAnnot[ full_ima_num ].ImageWidth;
      anno_image_height = IANNIV_ImageAnnot[ full_ima_num ].ImageLength;

/* ==========================================================================
      Draw coordinate type at starting position
   ========================================================================== */
      drawing_mode = old_drawing_mode;
      strcpy(file_type, PMDSLD_GRID_stbf_sfx_rowcol);
      pos = 0;
      PMDSIP_GRID_DrawCoord(pos, file_type, drawing_mode,
         image_width, image_height, image_buf, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

      x_step = (float)((float)image_width / (float)max_ipoint);
      y_step = (float)((float)image_height / (float)max_jpoint);

      anno_x_step = (float)((float)anno_image_width / (float)max_ipoint);
      anno_y_step = (float)((float)anno_image_height / (float)max_jpoint);


#ifdef __TRACE__

fprintf(stderr,"Debug:           x step = <%f>\n", x_step);
fprintf(stderr,"Debug:           y step = <%f>\n", y_step);
fprintf(stderr,"Debug:      max ipoints = <%d>\n", max_ipoint);
fprintf(stderr,"Debug:      max jpoints = <%d>\n", max_jpoint);
fprintf(stderr,"Debug:       tot points = <%d>\n", (max_ipoint * max_jpoint));
fprintf(stderr,"Debug: ----------------------------------------------------\n");

#endif

      for(ipoint = 1; ipoint < max_ipoint; ipoint++)
      {
         pos = (ipoint * (INTx4)x_step);
         anno_pos = (ipoint * (INTx4)anno_x_step);
         if(image_width < (pos + 60))
            drawing_mode = PMDSIE_drawing_none;

         for(ichar = 0; ichar < image_height; ichar++)
            image_buf[(ichar * image_width) + pos] = 255;
/* ==========================================================================
         Draw coordinate at current position
   ========================================================================== */
         if( IANNIV_ImageAnnot[ und_ima_num ].Presentation ==
             IANNIE_pres_normal ) {
            sprintf(file_type, "%d", anno_pos);
         }
         else {
            if( IANNIV_ImageAnnot[ und_ima_num ].OrbitDirection ==
                IANNIE_orbit_descend ) {
               sprintf(file_type, "%d", anno_image_width - anno_pos - 1);
            }
            else {
               sprintf(file_type, "%d", anno_pos);
            }
         }

         PMDSIP_GRID_DrawCoord(pos, file_type, drawing_mode,
            image_width, image_height, image_buf, status_code);
         ERRSIM_on_err_goto_exit( *status_code );
      }

      drawing_mode = old_drawing_mode;
      for(jpoint = 1; jpoint < max_jpoint; jpoint++)
      {
         pos = (jpoint * (INTx4)y_step * image_width);
         anno_pos = (jpoint * (INTx4)anno_y_step * anno_image_width);
         if((image_height * image_width) < (pos + (15 * image_width)))
            drawing_mode = PMDSIE_drawing_none;

         for(ichar = 0; ichar < image_width; ichar++)
            image_buf[pos + ichar] = 255;
/* ==========================================================================
         Draw coordinate at current position
   ========================================================================== */
         if( IANNIV_ImageAnnot[ und_ima_num ].Presentation ==
             IANNIE_pres_normal ) {
            sprintf(file_type, "%d", (INTx4)(anno_pos / anno_image_width));
         }
         else {
            if( IANNIV_ImageAnnot[ und_ima_num ].OrbitDirection ==
                IANNIE_orbit_descend ) {
               sprintf(file_type, "%d", (INTx4)(anno_pos / anno_image_width));
            }
            else {
               sprintf(file_type, "%d", 
                  anno_image_height - (INTx4)(anno_pos / anno_image_width) - 1);
            }
         }

         PMDSIP_GRID_DrawCoord(pos, file_type, drawing_mode,
            image_width, image_height, image_buf, status_code);
         ERRSIM_on_err_goto_exit( *status_code );
      }
   }

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = bpar.imagelength;
   out_io.val.tif.bpar.imagewidth = bpar.imagewidth;
   out_io.val.tif.bpar.sampleperpixel = 1;
   out_io.val.tif.bpar.photometricinterpretation = (UINTx2) 1;
   out_io.val.tif.bpar.bitspersample[ 0 ] =
             (UINTx2)(sizeof(UINTx1)*LDEFID_byte_size);
   out_io.val.tif.bpar.sampleformat[ 0 ] = TIFSID_uintdata;
   out_npar = inp_npar + TIFSID_minus_nbpar_std_tif;
                           /* GIOSIP_open_io automatically avoid to count
                              this parameters */

/* ==========================================================================
   Open output STANDARD TIFF file
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, tif_output_file );
   out_io.val.tif.standard = TRUE;
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = out_npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Allocate tag vector
   ========================================================================== */
   if( (tag = (UINTx2 *) 
               MEMSIP_alloc( (size_t) inp_npar * sizeof( UINTx2 ) )) == 
       ((UINTx2 *) NULL) ) {
      ERRSIM_set_error( status_code, ERRSID_PMDS_err_mem_alloc,
         "tag" );
   }

/* ==========================================================================
   Get tags from input file
   ========================================================================== */
   TIFSIP_dir_par(inp_channel, iimage, tag, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Writing parameters
   ========================================================================== */
   for( itag = TIFSID_nbpar - TIFSID_minus_nbpar_std_tif; 
        itag < inp_npar;
        itag++)
   {
      param.tag = tag[itag];
      TIFSIP_get_par(inp_channel, iimage, &param, status_code);
      ERRSIM_on_err_goto_exit( *status_code );
      TIFSIP_store_par(out_io.chan, out_io.img, &param, status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Opening of image write mode
   ========================================================================== */
   GIOSIP_open_line( &out_io, 'x', 0, (out_io.val.tif.bpar.imagewidth - 1),
      status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Loop onto the file line(s)
   ========================================================================== */
   for(iline = 0; iline < image_height; iline++)
   {
/* ==========================================================================
      Write line into output file
   ========================================================================== */
      GIOSIP_write_line( &out_io, iline,
         (void *)(image_buf + (iline * image_width)), status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Close write mode for image file
   ========================================================================== */
   GIOSIP_close_line( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the input file
   ========================================================================== */
   TIFSIP_close_tiff( inp_channel, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

error_exit:;

/* ==========================================================================
   Free allocated memory
   ========================================================================== */
   MEMSIP_free((void **) &image_buf);
   MEMSIP_free((void **) &point);
   MEMSIP_free((void **) &tag);

   ERRSIM_close_routine(  routine_name,
                         &process_flag,
                         *status_code, 
                         &log_status_code );


}/* PMDSIP_GRID_DrawArea */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_GRID_DrawCoord

        $TYPE

        $INPUT        pos          : position into the image buffer
                      file_type    : font tif file type
                      drawing_mode : overwrite or transparent drawing mode
                      width        : width of the image
                      height       : height of the image
                      image_buf    : image buffer to be updated

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_GRID_DrawCoord
                        (/*IN    */ INTx4                pos,
                         /*IN    */ char                *file_type,
                         /*IN    */ PMDSIT_drawing_mode  drawing_mode,
                         /*IN    */ INTx4                width,
                         /*IN    */ INTx4                height,
                         /*IN OUT*/ UINTx1              *image_buf,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_GRID_DrawCoord";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   INTx4            image_width; /* */
   INTx4            image_height;/* */
   INTx4            ival;        /* */
   INTx4            ichar;       /* */
   INTx4            jchar;       /* */
   INTx4            jpos;        /* */
   INTx4            start_pos;   /* */
   TIFSIT_basicpar  bpar;        /* basic parameter structure */
   INTx4            inp_channel; /* input file channel */
   void             *imgline;    /* image line buffer */
   UINTx1           *font_buf;   /* */
   INTx4            iline;       /* convenient loop variable */
   INTx4            nimage = 1;  /* image number */
   INTx4            iimage = 0;  /* current image index */
   char             sub_file_type[256]; /* sub file type */
   char             tif_file_name[256]; /* current font tif file name */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Get starting position
   ========================================================================== */
   start_pos = pos;

/* ==========================================================================
   Check drawing mode
   ========================================================================== */
   if ( drawing_mode != PMDSIE_drawing_none )
   {

/* ==========================================================================
      Loop onto type file name
   ========================================================================== */
      for(ival = 0; ival < strlen(file_type); ival++)
      {

/* ==========================================================================
         If space, loop
   ========================================================================== */
         if(file_type[ival] == ' ')
         {
            pos += 5;
            continue;
         }

/* ==========================================================================
         Check what file has to be opened
   ========================================================================== */
         if( isdigit(file_type[0]) || (file_type[0] == '-'))
         {
            if(file_type[ival] == '.')
            {
               strcpy(sub_file_type, PMDSLD_GRID_stbf_sfx_point);
            }
            else if(file_type[ival] == '-')
            {
               strcpy(sub_file_type, PMDSLD_GRID_stbf_sfx_minus);
            }
            else
            {
               sub_file_type[0] = file_type[ival];
               sub_file_type[1] = '\0';
            }
         }
         else
         {
            strcpy(sub_file_type, file_type);
            ival = strlen(file_type);
         }

         if(file_type[0] == '.')
         {
            strcpy(sub_file_type, PMDSLD_GRID_stbf_sfx_point);
         }
/* ==========================================================================
         Create font tif file name
   ========================================================================== */
         sprintf(tif_file_name, "%s%s%s%s", LDEFIV_cfg_dir,
            PMDSLD_GRID_stbf_prefix, sub_file_type,
            PMDSLD_GRID_stbf_extension);

/* ==========================================================================
         Open the input file
   ========================================================================== */
         TIFSIP_open_tiff( tif_file_name, 'r', &inp_channel, status_code);
         ERRSIM_on_err_goto_exit( *status_code );
         TIFSIP_get_imgnum( inp_channel, &nimage, status_code);
         ERRSIM_on_err_goto_exit( *status_code );
         TIFSIP_get_blockinfo( inp_channel, iimage, &bpar, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
         Get image size
   ========================================================================== */
         image_width  = bpar.imagewidth;
         image_height = bpar.imagelength;

/* ==========================================================================
         Allocate memory for the image buffer
   ========================================================================== */
         if((font_buf = (UINTx1 *) MEMSIP_alloc(image_width * image_height *
            sizeof(UINTx1))) == NULL)
         {
            ERRSIM_set_error( status_code, ERRSID_PMDS_alloc_memory,
               "font file");
         }

/* ==========================================================================
         Open the read mode of the input file
   ========================================================================== */
         TIFSIP_open_line( inp_channel, iimage, 'x', 0, (image_width - 1),
            status_code );
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
         Loop onto the file line(s)
   ========================================================================== */
         for(iline = 0; iline < image_height; iline++)
         {
/* ==========================================================================
            Read line from input file
   ========================================================================== */
            TIFSIP_read_line(inp_channel, iimage, iline, &imgline, status_code);
            ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
            Copy the image line just read
   ========================================================================== */
            memcpy((void *)(font_buf + (iline * image_width)), imgline,
               image_width);
         }

/* ==========================================================================
         Update image buffer
   ========================================================================== */
         if(drawing_mode == PMDSIE_drawing_overwrite)
         {
            jpos = 0;
            iline = (start_pos / width) + 1;
            for(ichar = pos; ichar < (width * height); ichar += width)
            {
               for(jchar = 0; jchar < image_width; jchar++)
               {
                  if(((ichar + jchar) > 0) &&
                     ((ichar + jchar) < (iline * width)))
                  {
                     image_buf[ichar + jchar] = font_buf[jpos + jchar];
                  }
               }
               iline++;
               jpos += image_width;
               if(jpos >= (image_width * image_height))
               {
                  break;
               }
            }
         }
         else if(drawing_mode == PMDSIE_drawing_transparent)
         {
            jpos = 0;
            iline = (start_pos / width) + 1;
            for(ichar = pos; ichar < (width * height); ichar += width)
            {
               for(jchar = 0; jchar < image_width; jchar++)
               {
                  if(((ichar + jchar) > 0) &&
                     ((ichar + jchar) < (iline * width)))
                  {
                     if(font_buf[jpos + jchar] > 0)
                     {
                        image_buf[ichar + jchar] = font_buf[jpos + jchar];
                     }
                  }
               }
               iline++;
               jpos += image_width;
               if(jpos >= (image_width * image_height))
               {
                  break;
               }
            }
         }

/* ==========================================================================
         Close read mode for input file
   ========================================================================== */
         TIFSIP_close_line( inp_channel, iimage, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
         Close the input file
   ========================================================================== */
         TIFSIP_close_tiff( inp_channel, status_code);
         ERRSIM_on_err_goto_exit( *status_code );
/* ==========================================================================
         Increase writing position
   ========================================================================== */
         pos += image_width;

/* ==========================================================================
         Free allocated memory
   ========================================================================== */
         MEMSIP_free((void **) &font_buf);
      } /* end of loop onto the file type(s) */
   } /* end of the drawing mode = none */

error_exit:;

/* ==========================================================================
   Free allocated memory
   ========================================================================== */
   MEMSIP_free((void **) &font_buf);

   ERRSIM_close_routine(  routine_name,
                         &process_flag,
                         *status_code, 
                         &log_status_code );


}/* PMDSIP_GRID_DrawCoord */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_GRID_DrawPoint

        $TYPE

        $INPUT        point        : array of points
                      npoint       : number of points
                      max_ipoint   : maximum number of columns
                      max_jpoint   : maximum number of rows
                      width        : width of the image
                      height       : height of the image
                      image_buf    : image buffer to be updated

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_GRID_DrawPoint
                        (/*IN    */ MATHIT_RC           *point,
                         /*IN    */ INTx4                npoint,
                         /*IN    */ INTx4                max_ipoint,
                         /*IN    */ INTx4                max_jpoint,
                         /*IN    */ INTx4                width,
                         /*IN    */ INTx4                height,
                         /*IN OUT*/ UINTx1              *image_buf,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_GRID_DrawPoint";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   INTx4            ipoint;      /* */
   INTx4            totpoint;    /* */
   INTx4            point1;      /* */
   INTx4            point2;      /* */
   INTx4            pos;         /* */
   float            x0, x1;
   float            y0, y1;
   float            yk;
   float            x, DeltaX;
   float            acoeff;      /* */
   float            bcoeff;      /* */
   INTx4            curr_col;    /* */
   INTx4            curr_row;    /* */
   UINTx1           flag;
   float            toll = 2.0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Loop onto the points of the isolon
   ========================================================================== */
   for(totpoint = 0; totpoint < npoint; totpoint += max_jpoint)
   {
      point1 = -1;
      point2 = -1;
/* ==========================================================================
      Check if it has to be displayed
   ========================================================================== */
      for(ipoint = totpoint; ipoint < (totpoint + max_jpoint); ipoint++)
      {
         if(point1 == -1)
         {
            point1 = ipoint;
            continue;
         }
         if(point2 == -1)
         {
            point2 = ipoint;
         }

/* ==========================================================================
         Reset flag
   ========================================================================== */
         flag = 0;

/* ==========================================================================
         Check best direction to discretize
   ========================================================================== */
         if( ABS(point[point1].col - point[point2].col) <
             ABS(point[point1].row - point[point2].row) ) {
            if( point[point1].row < point[point2].row ) {
               x0 = point[point1].row;
               x1 = point[point2].row;
               y0 = point[point1].col;
               y1 = point[point2].col;
            }
            else {
               x0 = point[point2].row;
               x1 = point[point1].row;
               y0 = point[point2].col;
               y1 = point[point1].col;
            }
         }
         else {
            flag = 1;
            if( point[point1].col < point[point2].col ) {
               x0 = point[point1].col;
               x1 = point[point2].col;
               y0 = point[point1].row;
               y1 = point[point2].row;
            }
            else {
               x0 = point[point2].col;
               x1 = point[point1].col;
               y0 = point[point2].row;
               y1 = point[point1].row;
            }
         }

/* ==========================================================================
         Compute increasing coefficient(s)
   ========================================================================== */
         if( ABS(y0 - y1) < toll ) {
            acoeff = 0.0;
            bcoeff = y0;
         }
         else  {
            acoeff = ((y1 - y0) / (x1 - x0));
            bcoeff = (y0 - (acoeff * x0));
         }

/* ==========================================================================
         Update image buffer
   ========================================================================== */
         x = x0;
         DeltaX = 1.0;
         while( x<x1 ) {
            yk = (acoeff * x) + bcoeff;
            if( flag == 1 ) {
               curr_col = (INTx4) x;
               curr_row = (INTx4) yk;
            }
            else {
               curr_row = (INTx4) x;
               curr_col = (INTx4) yk;
            }
            if(((curr_row >= 0) && (curr_col >= 0)) &&
               ((curr_row < height) && (curr_col < width)))
            {
               pos = (INTx4)((curr_row * width) + curr_col);

               if((pos >= 0) && (pos < (width * height)))
                  image_buf[pos] = 255;
            }
            x += DeltaX;
         }

#ifdef __PLAPLA__
         for(ichar = (INTx4)x0; ichar < (INTx4)x1; ichar++)
         {
            yk = (acoeff * (float)ichar) + bcoeff;
            curr_col = ichar;
            curr_row = (INTx4)((acoeff * (float)ichar) + bcoeff);

            if(((curr_row >= 0) && (curr_col >= 0)) &&
               ((curr_row < height) && (curr_col < width)))
            {
               pos = (INTx4)((curr_row * width) + curr_col);

               if((pos >= 0) && (pos < (width * height)))
                  image_buf[pos] = 255;

#ifdef __BHOO__
               pos += width;
               if((pos >= 0) && (pos < (width * height)))
                  image_buf[pos] = 255;

               pos -= (width * 2);
               if((pos >= 0) && (pos < (width * height)))
                  image_buf[pos] = 255;

               pos -= width;
               if((pos >= 0) && (pos < (width * height)))
                  image_buf[pos] = 255;
#endif
            }
         }
#endif

/* ==========================================================================
         Reset index(s)
   ========================================================================== */
         point1 = point2;
         point2 = -1;
      }
   }

/* ==========================================================================
   Loop onto the points of the isolat
   ========================================================================== */
   for(totpoint = 0; totpoint < max_jpoint; totpoint++)
   {
      point1 = -1;
      point2 = -1;
/* ==========================================================================
      Check if it has to be displayed
   ========================================================================== */
      for(ipoint = totpoint; ipoint < npoint; ipoint += max_jpoint)
      {
         if(point1 == -1)
         {
            point1 = ipoint;

            continue;
         }
         if(point2 == -1)
         {
            point2 = ipoint;
         }

/* ==========================================================================
         Reset flag
   ========================================================================== */
         flag = 0;

/* ==========================================================================
         Check best direction to discretize
   ========================================================================== */
         if( ABS(point[point1].col - point[point2].col) <
             ABS(point[point1].row - point[point2].row) ) {
            if( point[point1].row < point[point2].row ) {
               x0 = point[point1].row;
               x1 = point[point2].row;
               y0 = point[point1].col;
               y1 = point[point2].col;
            }
            else {
               x0 = point[point2].row;
               x1 = point[point1].row;
               y0 = point[point2].col;
               y1 = point[point1].col;
            }
         }
         else {
            flag = 1;
            if( point[point1].col < point[point2].col ) {
               x0 = point[point1].col;
               x1 = point[point2].col;
               y0 = point[point1].row;
               y1 = point[point2].row;
            }
            else {
               x0 = point[point2].col;
               x1 = point[point1].col;
               y0 = point[point2].row;
               y1 = point[point1].row;
            }
         }

/* ==========================================================================
         Compute increasing coefficient(s)
   ========================================================================== */
         if( ABS(y0 - y1) < toll ) {
            acoeff = 0.0;
            bcoeff = y0;
         }
         else  {
            acoeff = ((y1 - y0) / (x1 - x0));
            bcoeff = (y0 - (acoeff * x0));
         }

/* ==========================================================================
         Update image buffer
   ========================================================================== */
         x = x0;
         DeltaX = 1.0;
         while( x<x1 ) {
            yk = (acoeff * x) + bcoeff;
            if( flag == 1 ) {
               curr_col = (INTx4) x;
               curr_row = (INTx4) yk;
            }
            else {
               curr_row = (INTx4) x;
               curr_col = (INTx4) yk;
            }
            if(((curr_row >= 0) && (curr_col >= 0)) &&
               ((curr_row < height) && (curr_col < width)))
            {
               pos = (INTx4)((curr_row * width) + curr_col);

               if((pos >= 0) && (pos < (width * height)))
                  image_buf[pos] = 255;
            }
            x += DeltaX;
         }


/* ==========================================================================
         Reset index(s)
   ========================================================================== */
         point1 = point2;
         point2 = -1;
      }
   }

error_exit:;

   ERRSIM_close_routine(  routine_name,
                         &process_flag,
                         *status_code, 
                         &log_status_code );


}/* PMDSIP_GRID_DrawPoint */


