/* ==========================================================================
   $MODULE_HEADER

      $NAME              LDEF_DATE

      $FUNCTION          

      $ROUTINE           LDEF_DATE

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       21-JUL-97     MC       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include LDEF_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_DATE_JDate

        $TYPE         void

        $INPUT        the date string to convert

        $MODIFIED     the value returning the julian date

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Computes the julian day from a the 01-jan-1950 in the 
                      format

                              DD-MON-YYYY hh:mm:ss.ddd

        $WARNING      The formal check for the date validity is not 
                      complete; check the string before submit to the 
                      routine;

        $PDL

   $EH
   ========================================================================== */
void LDEFIP_DATE_JDate (/*IN    */ char *strData,
                        /*IN OUT*/ double *TotDays,
                       /*   OUT*/ ERRSIT_status     *status_code )
{
   const ERRSIT_proc_name routine_name = "LDEFIP_DATE_JDate";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   INTx4 Day;
   INTx4 Mm;
   INTx4 Year;
   INTx4 Hour;
   INTx4 Min;
   INTx4 Sec;
   INTx4 mSec;
   char Month[4];
   char Buff[4];
   INTx4 Ind;
   INTx4 jj,l,jDay;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);
/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
   *TotDays=0.0;
   /* formal check for date validity  */
   if (   !isdigit(strData[0]) 
       || !isdigit(strData[1])
       || !isdigit(strData[7])
       || !isdigit(strData[8])
       || !isdigit(strData[9])
       || !isdigit(strData[10])
       || !isdigit(strData[12])
       || !isdigit(strData[13])
       || !isdigit(strData[15])
       || !isdigit(strData[16])
       || !isdigit(strData[18])
       || !isdigit(strData[19])
       || !isdigit(strData[21])
       || !isdigit(strData[22])
       || !isdigit(strData[23])
       || !isalpha(strData[3])
       || !isalpha(strData[4])
       || !isalpha(strData[5]))
   {
/* David's patch */
if(strData[18] != ' ')
{
/* End of david's patch */

     ERRSIM_set_error(status_code,ERRSID_LDEF_invalid_date,strData);
}
strData[18] = '0';
   }


   Day=(strData[0]- '0')*10+strData[1]- '0';
   strncpy(Month,strData+3,3);
   Month[0]=toupper(Month[0]);
   Month[1]=toupper(Month[1]);
   Month[2]=toupper(Month[2]);
   Month[3]=0;
#ifdef KK
   for (Ind=0;Ind<36;Ind+=3)
   {
      strncpy(Buff,LDEFIC_MonName+Ind,3);
      Buff[3]=0;
      if (strcmp (Buff,Month)==0)
         break;
   }
   Mm=Ind/3+1;
#endif
/* ==========================================================================
   Substituting code
   ========================================================================== */
   for ( Ind=0;Ind<12;Ind++ )
   {
      strncpy( Buff, LDEFIC_MonName[ Ind ], 3 );
      Buff[ 3 ] = 0;
      if ( strcmp ( Buff, Month ) == 0 )
         break;
   }
   Mm = Ind + 1;
/* ==========================================================================
   End
   ========================================================================== */

   if (Mm >12)
   {
     ERRSIM_set_error(status_code,ERRSID_LDEF_invalid_date,strData);
   }

   Year=
    (( (strData[7] - '0')*10+
       (strData[8] - '0'))*10+
       (strData[9] - '0'))*10+
       (strData[10]- '0');

   Hour=(strData[12]- '0')*10 + (strData[13] - '0');
   Min =(strData[15]- '0')*10 + (strData[16] - '0');
   Sec =(strData[18]- '0')*10 + (strData[19] - '0');

   mSec =
    ( (strData[21] - '0')*10+
      (strData[22] - '0'))*10+
      (strData[23] - '0');

   jj=(14-Mm)/12;
   l=Year-1900 -jj;
   jDay=Day-18234+(1461*l)/4+(367*(Mm -2 +jj * 12))/12;
   *TotDays=(double)jDay*1.0 +
        (double)((Hour *60 + Min) *60 +Sec)/86400.0;
   *TotDays += (double)mSec/86400000.0;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* LDEFIP_DATE_JDate */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_DATE_StrDate

        $TYPE         void

        $INPUT        the julian date value

        $MODIFIED     the string containing the date

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Convert an julian day into a string with the format:

                              DD-MON-YYYY hh:mm:ss.ddd

        $WARNING      The pointer to output date string must refer to a
                      buffer with at least 24 character;

        $PDL

   $EH
   ========================================================================== */
void LDEFIP_DATE_StrDate (/*IN    */ double *jDate,
                          /*IN OUT*/ char *strData,
                          /*   OUT*/ ERRSIT_status     *status_code )
{
   const ERRSIT_proc_name routine_name = "LDEFIP_DATE_StrDate";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;
   INTx4 Day;
   INTx4 Mm;
   INTx4 Year;
   INTx4 Hour;
   INTx4 Min;
   double Sec;
   char Month[4];
   double dDay;
   INTx4 jDay,l,m,n,jj;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);
/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
   if ( (*jDate) <= 0.0)
   {
     ERRSIM_set_error(status_code,ERRSID_LDEF_invalid_date, "");
   }

      dDay=0.0;
      dDay=  (*jDate)  ;
      jDay= (INTx4) ( (float) dDay );
      l= ( 4000 * (jDay+18234) ) / 1461001;
      n= jDay - (1461 * l ) / 4 + 18234;
      m= ( 80 * n ) / 2447;
   Day= n - (2447 * m) / 80;
      jj= m / 11;
      Mm= m + 2 - 12 * jj;
#ifdef KK
   strncpy(Month,LDEFIC_MonName+(Mm-1)*3,3);
#endif
/* ==========================================================================
   Start substituing code
   ========================================================================== */
   strncpy( Month, LDEFIC_MonName[ Mm - 1 ], 3 );

/* ==========================================================================
   End
   ========================================================================== */

   Month[3]=0;
   Year=1900 + l + jj;
     Sec=(dDay -(double)jDay *1.0)*24.0;
   Hour=(INTx4)Sec;
     Sec=(Sec -(double)Hour*1.0)*60.0;
   Min=(INTx4)Sec;
   Sec=(Sec -(double)Min*1.0)*60.0;

   sprintf(strData,"%02d-%s-%04d %02d:%02d:%06.3f", 
         Day,Month,Year,Hour,Min,Sec);

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* LDEFIP_DATE_StrDate */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_DATE_DiffDate

        $TYPE         void

        $INPUT        two date strings whose difference is to be computed

        $MODIFIED     the value returning the difference

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Computes the difference between two dates expressed
                      in the format

                              DD-MON-YYYY hh:mm:ss.ddd

        $WARNING      The formal check for the dates validity is not 
                      exaustive; check the strings before call the routine;

        $PDL

   $EH
   ========================================================================== */
void LDEFIP_DATE_DiffDate (/*IN    */ char *strData0,
                          /*IN    */ char *strData1 ,
                        /*IN OUT*/ double *DiffDays,
                       /*   OUT*/ ERRSIT_status     *status_code )
{
   const ERRSIT_proc_name routine_name = "LDEFIP_DATE_DiffDate";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;
   double JDay0;
   double JDay1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
   LDEFIP_DATE_JDate (strData0,&JDay0,status_code);
   ERRSIM_on_err_goto_exit(*status_code);

   LDEFIP_DATE_JDate (strData1,&JDay1,status_code);
   ERRSIM_on_err_goto_exit(*status_code);

   *DiffDays=JDay0 -JDay1;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* LDEFIP_DATE_DiffDate */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         LDEFIP_DATE_NextDate

        $TYPE         void

        $INPUT        the base date string
                      the date interval expressed in number of days

        $MODIFIED     the string containing the new date

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Computes the next date from a base after a specific
                      time

        $WARNING      The formal check for the dates validity is not 
                      exaustive; check the strings before call the routine;

        $PDL

   $EH
   ========================================================================== */
void LDEFIP_DATE_NextDate (/*IN    */ char *strData0,
                           /*IN    */ double *DiffDays,
                           /*IN OUT*/ char *strData1 ,
                       /*   OUT*/ ERRSIT_status     *status_code )
{
   const ERRSIT_proc_name routine_name = "LDEFIP_DATE_NextDate";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;
   double JDay0;
   double JDay1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
   LDEFIP_DATE_JDate (strData0,&JDay0,status_code);
   ERRSIM_on_err_goto_exit(*status_code);

   JDay1 = (*DiffDays) + JDay0;

   LDEFIP_DATE_StrDate (&JDay1,strData1,status_code);
   ERRSIM_on_err_goto_exit(*status_code);


error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* LDEFIP_DATE_NextDate */

