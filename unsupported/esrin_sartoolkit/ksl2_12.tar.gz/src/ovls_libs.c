/* ==========================================================================
   $MODULE_HEADER

      $NAME              OVLS_LIBS

      $FUNCTION          OVERLAP & SAVE Functions

      $ROUTINE           OVLSIP_OverlapAndSave
                         OVLSIP_CheckMemory
   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       05-AUG-97     AG       Initial Release
          SCR #5      27-NOV-97     AG       Changed checks of Kr and Kc
            N/A       23-MAR-97     AG       Add for Reqs B10/B18

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H
#include SRVS_INTF_H
#include OVLS_INTF_H
#include OVLS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         OVLSIP_OverlapAndSave

        $TYPE         PROCEDURE

        $INPUT        inp_io        : structure with the IO basic parameters
                                      of the input image
                      inp_ima_num   : annotation index of the input image
                      TLRow         : row coordinate of the first pixel of the
                                      image to filter in the full image   
                                      reference system
                      TLCol         : column coordinate of the first pixel of
                                      the image to filter in the full image
                                      reference system
                      nrow_inp      : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
                      Kern          : kernel matrix
                      Kr            : rows kernel size
                      Kc            : columns kernel size
                      stepR         : rows step
                      stepC         : columns step
                      out_io        : ID structure of the output image
                      nrow_out      : number of rows of the output image block
                      ncol_out      : number of columns of the output image block
                      core_func     : function to apply to the image block of
                                      the overlap and save procedure
                      fill_val      : float filler value
                      data_size     : size of record in read

        $MODIFIED     NONE

        $OUTPUT       The output image is filled

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_OVLS_incorrect_rows_cols
            ERRSID_OVLS_no_undersampling
            ERRSID_OVLS_kernel_dim_high
            ERRSID_OVLS_read_block_dim_low
            ERRSID_OVLS_err_mem_alloc
            ERRSID_OVLS_data_type_not_allow

        $DESCRIPTION  This procedure reads the input image blocking it with an
            Overlp & Save algorithm (O&S) considering the filter
            transient. Each image block is passed to a core function
            user defined. The core function fills the output image
            file.

        $WARNING      The input and the output image must be initialised before
            calling this procedure. The open line of the input and the
            output image are done here.

        $PDL         - Evaluate the size of the image block to read at each
              O&S step in the rows direction
            - Evaluate the steps of the moving window
            - Evaluate the equivalent dimensions of the block to read
         at each step
            - Evaluate the number of blocks to read
            - Allocate the memory for the input image block storing
            - Open the line reading for the input image
            - Open the line writing for the output image
            - Inizialise the counters
            - Loop over the rows blocks with full dimensions
             - Update the counters and the block sizes
                            - Read the image block
             - Call the core function
             - Reset the counters
            - End loop
            - If there are not full dimensions image block
             - Update the counters and the block sizes
                            - Read the image block
                            - Call the core function
            - End if
            - Close the line writing for the output image
            - Close the line reading for the input image
            - Free the allocated memories

   $EH
   ========================================================================== */
void OVLSIP_OverlapAndSave
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ double               stepR,
                         /*IN    */ double               stepC,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ OVLSIT_core_func     core_func,
                         /*IN    */ float                fill_val,
                         /*IN    */ INTx4                data_size,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "OVLSIP_OverlapAndSave";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 RReadDim;   /* actual read block dimension */
   UINTx4                 NStepR = 0;
   UINTx4                 NStepBlock;   /* number of steps in an O&S block */
   UINTx4                 RStartR = 0;   /* starting read row index */
   UINTx4                 RStopR;   /* stopping read row index */
   UINTx4                 RStartW = 0;   /* starting write row index */
   UINTx4                 RStopW;   /* stopping write row index */
   INTx4                  RDim = 0;      /* not full rows block dimensions */
   UINTx4                 ROutDim;   /* row dimension of the output block */
   UINTx4                 i;      /* counter */
   void                 **InpIma = (void **)NULL;   /* input image pointer*/
   DATA_TYPEIT            inp_type = DATA_TYPE_undef;   /* input data type    */
                     /* descriptor         */
   UINTx4                 inp_row_size, out_row_size, tmp_row_size;
   UINTx4                 inp_rowsperblock, out_rowsperblock;
   UINTx4                 inp_block_size, out_block_size, avail_memsiz;
   MATHIT_RC             *vert = (MATHIT_RC *)NULL;
   LDEFIT_boolean         in_line_open = FALSE;
   LDEFIT_boolean         out_line_open = FALSE;
   char                   err_msg[ 256 ];
   INTx4                  inpima_data_size;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the input parameters consistency
   ========================================================================== */
   if ( ( nrow_inp <= 1 ) || ( ncol_inp <= 1 ) )
      ERRSIM_set_error( status_code, ERRSID_OVLS_incorrect_rows_cols, "" );

/* ==========================================================================
   Check the kernel sizes consistency
   ========================================================================== */
   if ( ( Kr > nrow_inp ) || ( Kc > ncol_inp ) )
      ERRSIM_set_error( status_code, ERRSID_OVLS_kernel_dim_high, "" );

#ifdef __TRACE__
   fprintf(stderr, "%s: Kc=%0d stepC=%f\n", routine_name, Kc, stepC);
#endif

/* ==========================================================================
   Evaluate the rows reading dimensions
   ========================================================================== */
   SRVSIP_avail_memory( &avail_memsiz,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Transform avail_memsiz in bytes
   ========================================================================== */
   avail_memsiz *= 1024;

/* ==========================================================================
   Compute RReadDim as function of free memory
   ========================================================================== */
   inp_row_size = tmp_row_size = inp_io->spp * (inp_io->bps / 8) * ncol_inp;
   out_row_size = out_io->spp * (out_io->bps / 8) * ncol_out;

   if( out_io->type == GIOSIE_tif ) {
      out_rowsperblock = out_io->val.tif.bpar.rowsperblock;
   }
   else {
      out_rowsperblock = 0; /* no further memory is needed */
   }

   if((inp_io->type == GIOSIE_device) || (inp_io->type == GIOSIE_file))
   {
      out_block_size = out_row_size * out_rowsperblock;
      if( avail_memsiz <= out_block_size ) {
         sprintf( err_msg, "avail_memsiz = %0d necessary = %0d", 
            avail_memsiz, out_block_size );
         ERRSIM_set_error( status_code, ERRSID_OVLS_not_enough_memory, err_msg);
      }
      RReadDim = (avail_memsiz - out_block_size)/(inp_row_size + tmp_row_size);
#ifdef __TRACE__
      fprintf( stderr, "%0d %0d %0d %0d\n", avail_memsiz, out_block_size,
               tmp_row_size, RReadDim);
#endif
   }
   else {
      out_block_size = out_row_size * out_rowsperblock;

      if( inp_io->type == GIOSIE_tif ) {
         inp_rowsperblock = inp_io->val.tif.bpar.rowsperblock;
      }
      else {
         inp_rowsperblock = 0; /* no further memory is needed */
      }

      inp_block_size = inp_row_size * inp_rowsperblock; 

      if( avail_memsiz <= (inp_block_size + out_block_size) ) {
         sprintf( err_msg, "avail_memsiz = %0d necessary = %0d", 
            avail_memsiz, inp_block_size + out_block_size );
         ERRSIM_set_error( status_code, ERRSID_OVLS_not_enough_memory, err_msg);
      }

      RReadDim = (avail_memsiz - ( inp_block_size + out_block_size ))/ 
                 tmp_row_size;

#ifdef __TRACE__
      fprintf( stderr, "avail_memsiz=%0d\n\
inp_block_size+out_block_size=%0d\n\
tmp_row_size=%0d\n\
RReadDim=%0d\n",
               avail_memsiz, inp_block_size + out_block_size,
               tmp_row_size, RReadDim);
#endif
   }

/* ==========================================================================
   Check the reading block dimension
   ========================================================================== */
   if ( RReadDim > nrow_inp ) RReadDim = nrow_inp;

/* ==========================================================================
   Check the reading dimensions consistency
   ========================================================================== */
   if ( RReadDim < Kr ) {
      ERRSIM_set_error( status_code, ERRSID_OVLS_read_block_dim_low, "" );
   }

/* ==========================================================================
   Evaluate the number of blocks
   ========================================================================== */
   NStepBlock = SRVSIM_out( RReadDim, Kr, stepR);

/* ==========================================================================
   Allocates the input block image
   ========================================================================== */
   switch ( inp_io->dt ) {
    /* SLC and SLCI data type */
      case LDEFIE_dt_2_INTx2:
         if ( ( InpIma = (void **)MEMSIP_alloc(
                 (size_t)( RReadDim * sizeof(INTx2 *)) ) ) == (void **)NULL ) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }

         inpima_data_size = ((data_size == 0) ? 
                                 (2 * ncol_inp * sizeof(INTx2)) :
                                 data_size) ;

         if ( ( InpIma[ 0 ] = (void *)MEMSIP_alloc(
                 (size_t) inpima_data_size * RReadDim)) == (void *)NULL) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }
         for ( i=1; i<RReadDim; i++ ) {
            InpIma[ i ] = &(((UINTx1 *)(InpIma[ 0 ]))[ i * inpima_data_size ]);
         }

         inp_type = DATA_TYPE_INTx2;
      break;

      /* RAW data type */
      case LDEFIE_dt_2_UINTx1:
         if ( ( InpIma = (void **)MEMSIP_alloc(
                 (size_t)( RReadDim * sizeof(UINTx1 *)) ) ) == (void **)NULL ) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }
 
         inpima_data_size = ((data_size == 0) ?
                                 (2 * ncol_inp * sizeof(UINTx1)) :
                                 data_size) ;

         if ( ( InpIma[ 0 ] = (void *)MEMSIP_alloc(
                 (size_t) inpima_data_size * RReadDim)) == (void *)NULL) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }
         for ( i=1; i<RReadDim; i++ ) {
            InpIma[ i ] = &(((UINTx1 *)(InpIma[ 0 ]))[ i * inpima_data_size ]);
         }

         inp_type = DATA_TYPE_UINTx1;
      break;

      case LDEFIE_dt_UINTx1:

    /* byte data type */
         if ( ( InpIma = (void **)MEMSIP_alloc(
                 (size_t)( RReadDim * sizeof(UINTx1 *)) ) ) == (void **)NULL ) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }

         inpima_data_size = ((data_size == 0) ? 
                                 (ncol_inp * sizeof(UINTx1)) :
                                 data_size) ;

         if ( ( InpIma[ 0 ] = (void *)MEMSIP_alloc(
                 (size_t) inpima_data_size * RReadDim)) == (void *)NULL) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }
         for ( i=1; i<RReadDim; i++ ) {
            InpIma[ i ] = &(((UINTx1 *)(InpIma[ 0 ]))[ i * inpima_data_size ]);
         }

         inp_type = DATA_TYPE_UINTx1;
      break;
      case LDEFIE_dt_UINTx2:

    /* PRI, GEC and GTC data */
         if ( ( InpIma = (void **)MEMSIP_alloc(
                 (size_t)( RReadDim * sizeof(UINTx2 *)) ) ) == (void **)NULL ) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }

         inpima_data_size = ((data_size == 0) ? 
                                 (ncol_inp * sizeof(UINTx2)) :
                                 data_size);

         if ( ( InpIma[ 0 ] = (void *)MEMSIP_alloc(
                 (size_t) inpima_data_size * RReadDim)) == (void *)NULL) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }
         for ( i=1; i<RReadDim; i++ ) {
            InpIma[ i ] = &(((UINTx1 *)(InpIma[ 0 ]))[ i * inpima_data_size ]);
         }

         inp_type = DATA_TYPE_UINTx2;
      break;
      case LDEFIE_dt_float:

    /* internal product */
         if ( ( InpIma = (void **)MEMSIP_alloc(
                 (size_t)( RReadDim * sizeof(float *) ) ) ) == (void **)NULL ) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }

         inpima_data_size = ((data_size == 0) ? 
                                 (ncol_inp * sizeof(float)) :
                                 data_size) ;

         if ( ( InpIma[ 0 ] = (void *)MEMSIP_alloc(
                 (size_t) inpima_data_size * RReadDim)) == (void *)NULL) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }
         for ( i=1; i<RReadDim; i++ ) {
            InpIma[ i ] = &(((UINTx1 *)(InpIma[ 0 ]))[ i * inpima_data_size ]);
         }

         inp_type = DATA_TYPE_float;
      break;
      case LDEFIE_dt_2_float:

    /* internal product */
         if ( ( InpIma = (void **)MEMSIP_alloc(
                 (size_t)( RReadDim * sizeof(float *) ) ) ) == (void **)NULL ) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }

         inpima_data_size = ((data_size == 0) ? 
                                 (2 * ncol_inp * sizeof(float)) :
                                 data_size) ;
         if ( ( InpIma[ 0 ] = (void *)MEMSIP_alloc(
                 (size_t) inpima_data_size * RReadDim)) == (void *)NULL) {
            ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
         }
         for ( i=1; i<RReadDim; i++ ) {
            InpIma[ i ] = &(((UINTx1 *)(InpIma[ 0 ]))[ i * inpima_data_size ]);
         }

         inp_type = DATA_TYPE_float;
      break;
      default:
         ERRSIM_set_error( status_code, ERRSID_OVLS_data_type_not_allow, "" );
   }

/* ==========================================================================
   Open the reading mode for the input file
   ========================================================================== */
   GIOSIP_open_line( inp_io, 'x', TLCol, TLCol + ncol_inp - 1,
                     status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   in_line_open = TRUE;

/* ==========================================================================
   Open the write mode for the output file
   ========================================================================== */
   GIOSIP_open_line( out_io, 'x', 0, ( ncol_out - 1 ), status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_line_open = TRUE;

/* ==========================================================================
   Allocates the rescaled vertices memories
   ========================================================================== */
   if( vertex_no > 0 ) {
      if ( ( vert = (MATHIT_RC *)
          MEMSIP_alloc( (size_t)( vertex_no * sizeof( MATHIT_RC ))) ) ==
     (MATHIT_RC *)NULL ) {
         ERRSIM_set_error( status_code, ERRSID_OVLS_err_mem_alloc, "" );
      }
/* ==========================================================================
   Reset the vertices
   ========================================================================== */
      for ( i=0;i<vertex_no;i++ ) {
         vert[ i ].row = vertex[ i ].row - TLRow;
         vert[ i ].col = vertex[ i ].col - TLCol;
      }
   }

/* ==========================================================================
   Output counter initialization
   ========================================================================== */
   RStartW = 0;
   RStopR = TLRow;

/* ==========================================================================
   Output dimension setting
   ========================================================================== */
   ROutDim = SRVSIM_out( RReadDim, Kr, stepR);

/* ==========================================================================
   Set the computation target value
   ========================================================================== */
   SRVSIP_set_comp( (INTx4) nrow_out, &log_status_code );

/* ==========================================================================
   Begin the loop
   ========================================================================== */
   while((TLRow + (UINTx4)(NStepR * stepR) + (RReadDim - 1)) < 
         (TLRow + nrow_inp))
   {

/* ==========================================================================
   Extreems setting: read ...
   ========================================================================== */
      RStartR = TLRow + (UINTx4) ROUND ( NStepR * stepR );
      RStopR = RStartR + RReadDim - 1;

/* ==========================================================================
   ... and write
   ========================================================================== */
      RStopW = RStartW + ROutDim - 1;      /* stop writing row */

#ifdef __TRACE__
fprintf(stderr,"Debug: ----------------------------------------------------\n");
fprintf(stderr,"Debug:  RStartR = <%d>\n", RStartR);
fprintf(stderr,"Debug:   RStopR = <%d>\n", RStopR);
fprintf(stderr,"Debug:  RStartW = <%d>\n", RStartW);
fprintf(stderr,"Debug:   RStopW = <%d>\n", RStopW);
fprintf(stderr,"Debug:    TLRow = <%d>\n", TLRow);
fprintf(stderr,"Debug: RReadDim = <%d>\n", RReadDim);
fprintf(stderr,"Debug:  ROutDim = <%d>\n", ROutDim);
fprintf(stderr,"Debug: nrow_inp = <%d>\n", nrow_inp);
fprintf(stderr,"Debug:   NStepR = <%d>\n", NStepR);
fprintf(stderr,"Debug:    stepR = <%g>\n", stepR);
fprintf(stderr,"Debug:     RDim = <%d>\n", RDim);
fprintf(stderr,"Debug:       Kr = <%d>\n", Kr);
fprintf(stderr,"Debug: ----------------------------------------------------\n");
#endif

/* ==========================================================================
   Read the input block
   ========================================================================== */
      GIOSIP_read_block( inp_io, RStartR, RStopR, data_size, inp_type, InpIma,
          status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Core function call
   ========================================================================== */
      (*core_func)(RReadDim, ncol_inp, (RStartR - TLRow), stepR, stepC, 
                   vertex_no, vert, Kern, Kr, Kc, InpIma, RStartW, RStopW, 
                   inp_io->dt, out_io, ncol_out, fill_val, inp_ima_num, 
                   status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Output counters reset
   ========================================================================== */
      RStartW = RStopW + 1;
      NStepR += NStepBlock;

   }

/* ==========================================================================
   Last rows in the block; see comment above ...
   ========================================================================== */
   RStartR = TLRow + (UINTx4) ROUND ( NStepR * stepR );
   RStopR = TLRow + nrow_inp - 1;
   RDim = RStopR - RStartR + 1;

#ifdef __TRACE__
fprintf(stderr,"Debug: ----------------------------------------------------\n");
fprintf(stderr,"Debug:  RStartR = <%d>\n", RStartR);
fprintf(stderr,"Debug:   RStopR = <%d>\n", RStopR);
fprintf(stderr,"Debug:    TLRow = <%d>\n", TLRow);
fprintf(stderr,"Debug: nrow_inp = <%d>\n", nrow_inp);
fprintf(stderr,"Debug:   NStepR = <%d>\n", NStepR);
fprintf(stderr,"Debug:    stepR = <%g>\n", stepR);
fprintf(stderr,"Debug:     RDim = <%d>\n", RDim);
fprintf(stderr,"Debug:       Kr = <%d>\n", Kr);
fprintf(stderr,"Debug: ----------------------------------------------------\n");
#endif

   if( RDim >= (INTx4)Kr )
   {
      ROutDim = SRVSIM_out( RDim, Kr, stepR);
      RStopW = RStartW + ROutDim - 1;

#ifdef __TRACE__
   printf( "\n\n RStartR = %u, RStopR = %u", RStartR, RStopR );
   printf( "\n RStartW = %u, RStopW = %u", RStartW, RStopW );
#endif

      GIOSIP_read_block(inp_io, RStartR, RStopR, data_size, inp_type, InpIma, 
         status_code);
      ERRSIM_on_err_goto_exit(*status_code);

      (*core_func)(RDim, ncol_inp, (RStartR - TLRow), stepR, stepC, 
                   vertex_no, vert, Kern, Kr, Kc, InpIma, RStartW, RStopW,
                   inp_io->dt, out_io, ncol_out, fill_val, inp_ima_num, 
                   status_code);
      ERRSIM_on_err_goto_exit(*status_code);
   }

/* ==========================================================================
   Close the write mode for the output file
   ========================================================================== */

   GIOSIP_close_line(out_io, status_code);
   ERRSIM_on_err_goto_exit(*status_code);
   out_line_open = FALSE;

/* ==========================================================================
   Close the reading mode for the input file
   ========================================================================== */
   GIOSIP_close_line(inp_io, status_code);
   ERRSIM_on_err_goto_exit(*status_code);
   in_line_open = FALSE;

error_exit:;

/* ==========================================================================
   Close IOs if errors
   ========================================================================== */
   if(in_line_open)
   {
      GIOSIP_close_line(inp_io, &log_status_code);
   }
   if(out_line_open)
   {
      GIOSIP_close_line(out_io, &log_status_code);
   }

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   if ( InpIma != (void **)NULL ) {
      MEMSIP_free( (void **) &(InpIma[ 0 ]) );
   }
   MEMSIP_free( (void **)(&InpIma) );

   MEMSIP_free( (void **)(&vert) );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* OVLSIP_OverlapAndSave */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         OVLSIP_CheckMemory

        $TYPE         PROCEDURE

        $INPUT        inp_io     : array of input files descriptors
                      NInpImages : number of input images
                      out_io     : array of output files descriptors
                      NOutImages : number of output images
                      ncol_inp   : number of input columns
                      ncol_out   : number of output columns

        $MODIFIED     NONE

        $OUTPUT       RReadDim   : size of the block that can be read at each
                                   step of the Overlap and Save

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_OVLS_not_compat_ima
                      ERRSID_OVLS_not_enough_memory

        $DESCRIPTION  This procedure evaluates the size of the block to read in
                      the Overlap and Save procedure evaluates WRT the available
                      memory in the machine

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
void OVLSIP_CheckMemory
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx4               NInpImages,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               NOutImages,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               ncol_out,
                         /*   OUT*/ UINTx4              *RReadDim,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "OVLSIP_CheckMemory";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 inp_row_size;
   UINTx4                 tmp_row_size;
   UINTx4                 out_row_size = 0;
   UINTx4                 inp_rowsperblock = 0;
   UINTx4                 out_rowsperblock = 0;
   UINTx4                 inp_block_size = 0;
   UINTx4                 out_block_size = 0;
   UINTx4                 avail_memsiz;
   INTx4                  ima;
   UINTx1                 ref = 0;
   char                   err_msg[ 256 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Evaluate the rows reading dimensions
   ========================================================================== */
   SRVSIP_avail_memory ( &avail_memsiz, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Transform avail_memsiz in bytes
   ========================================================================== */
   avail_memsiz *= 1024;

/* ==========================================================================
   Check the images are of the same type
   ========================================================================== */

   /* input ... */
   for ( ima=1; ima<NInpImages; ima++ ) {
      if ( ( inp_io[ ima ].spp != inp_io[ ref ].spp ) ||
           ( inp_io[ ima ].bps != inp_io[ ref ].bps ) ) {
         ERRSIM_set_error ( status_code, ERRSID_OVLS_not_compat_ima, "" );
      }
   }

   /* ... and output */
   for ( ima=1; ima<NOutImages; ima++ ) {
      if ( ( out_io[ ima ].spp != out_io[ ref ].spp ) ||
           ( out_io[ ima ].bps != out_io[ ref ].bps ) ) {
         ERRSIM_set_error ( status_code, ERRSID_OVLS_not_compat_ima, "" );
      }
   }

/* ==========================================================================
   Sum the input contribution
   ========================================================================== */
   inp_row_size = tmp_row_size = NInpImages *  /* counts the images number */
      inp_io[ ref ].spp *                      /* counts the sample per pixel */
      ( inp_io[ ref ].bps / 8 ) *              /* the bytes */
      ncol_inp;                                /* ... and the columns */

/* ==========================================================================
   ... and the out one
   ========================================================================== */
   out_row_size = NOutImages *       /* counts the images number */
      out_io[ ref ].spp *            /* counts the sample per pixel */
      ( out_io[ ima ].bps / 8 ) *    /* the bytes ... */
      ncol_out;                      /* ... and the columns */

/* ==========================================================================
   Rows per block
   ========================================================================== */
   if ( out_io[ ref ].type == GIOSIE_tif ) {
      out_rowsperblock = NOutImages * out_io[ ref ].val.tif.bpar.rowsperblock;
   }

   if ( ( inp_io[ ref ].type == GIOSIE_device ) ||
        ( inp_io[ ref ].type == GIOSIE_file ) ) {
      out_block_size = out_row_size * out_rowsperblock;

/* ==========================================================================
   Check the needed memory
   ========================================================================== */
      if ( avail_memsiz <= out_block_size ) {
         sprintf ( err_msg, "avail_memsiz = %0d necessary = %0d", 
                   avail_memsiz, out_block_size );
         ERRSIM_set_error ( status_code, ERRSID_OVLS_not_enough_memory,
                            err_msg );
      }

/* ==========================================================================
   Set the row size
   ========================================================================== */
      *RReadDim = ( avail_memsiz - out_block_size ) /
         ( inp_row_size + tmp_row_size );
#ifdef __TRACE__
      fprintf ( stderr, "%0d %0d %0d %0d\n", avail_memsiz, out_block_size,
                tmp_row_size, RReadDim );
#endif
   }
   else {

/* ==========================================================================
   TIFF or buffer
   ========================================================================== */
      out_block_size = out_row_size * out_rowsperblock;

      if ( inp_io[ ref ].type == GIOSIE_tif ) {
         inp_rowsperblock = NInpImages *
            inp_io[ ima ].val.tif.bpar.rowsperblock;
      }

      inp_block_size = inp_row_size * inp_rowsperblock; 

/* ==========================================================================
   Check the needed memory
   ========================================================================== */
      if ( avail_memsiz <= ( inp_block_size + out_block_size ) ) {
         sprintf ( err_msg, "avail_memsiz = %0d necessary = %0d", 
                   avail_memsiz, inp_block_size + out_block_size );
         ERRSIM_set_error ( status_code, ERRSID_OVLS_not_enough_memory,
                            err_msg );
      }

/* ==========================================================================
   Set the rows dimension
   ========================================================================== */
      *RReadDim = ( avail_memsiz - ( inp_block_size + out_block_size ) ) / 
         tmp_row_size;
#ifdef __TRACE__
      fprintf ( stderr, "avail_memsiz=%0d\n\
inp_block_size+out_block_size=%0d\n\
tmp_row_size=%0d\n\
RReadDim=%0d\n",
                avail_memsiz, inp_block_size + out_block_size,
                tmp_row_size, RReadDim );
#endif
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* OVLSIP_CheckMemory */
