/* ==========================================================================
   $MODULE_HEADER

      $NAME              MATH_INTR

      $FUNCTION          This module contains the procedures for the image
			 interpolation

      $ROUTINE           MATHIP_INTR_Linear
			 MATHIP_INTR_NearestNeighbor
			 MATHIP_INTR_Bilinear
                         MATHIP_INTR_CubiConvInit
                         MATHIP_INTR_CubicConvolution
                         MATHIP_INTR_CubiConvClose
                         MATHIP_INTR_SincInit
                         MATHIP_INTR_Sinc
                         MATHIP_INTR_SincClose
                         MATHIP_INTR_FFTConstShift
                         MATHIP_INTR_ImageRowShift
                         MATHIP_INTR_ImageColShift
                         MATHPP_INTR_BLUINTx1
                         MATHPP_INTR_BLUINTx2
                         MATHPP_INTR_BLfloat
                         MATHPP_INTR_BL2INTx2
                         MATHPP_INTR_BL2float
                         MATHPP_INTR_CCUINTx1
                         MATHPP_INTR_CCUINTx2
                         MATHPP_INTR_CCfloat
                         MATHPP_INTR_CC2INTx2
                         MATHPP_INTR_CC2float
                         MATHPF_INTR_CubiConvKernel
                         MATHPP_INTR_SincAzimuth
                         MATHPP_INTR_SincRange
                         MATHPP_INTR_SNUINTx1
                         MATHPP_INTR_SNUINTx2
                         MATHPP_INTR_SNfloat
                         MATHPP_INTR_SN2INTx2
                         MATHPP_INTR_SN2float
                         MATHPP_INTR_FillArray
                         MATHPP_INTR_FillImage
                         MATHPP_INTR_FillRowArray
                         MATHPP_INTR_FillColArray
                         MATHPP_INTR_FillImaRow
                         MATHPP_INTR_FillImaCol

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       06-AUG-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <string.h>
#include <stdio.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include MATH_INTF_H
#include MATH_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_Linear

        $TYPE         PROCEDURE

        $INPUT        x	      : array with the abscissa values
		      y	      : array with the ordinate values
		      x_curr  : actual abscissa at which the interpolated value
				must be interpolated

        $MODIFIED     NONE

        $OUTPUT       out_val : interpolated value

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_xy_num_diff
		      ERRSID_MATH_abscissa_out
		      ERRSID_MATH_math_err
		      ERRSID_MATH_arr_uncomp
		      ERRSID_MATH_arr_undef

        $DESCRIPTION  This procedure evaluates the linear interpolation of the
		      array <y> at the abscissa value <x>

        $WARNING      The abscissa value must be increasing ordered

        $PDL	      - Search the class of abscissa values in which the
		        actual value fall
                      - Evaluate the coefficients of the interpolation
		      - Evaluate the interpolated value

   $EH
   ========================================================================== */

void MATHIP_INTR_Linear
                        (/*IN    */ MATHIT_array	 x,
			 /*IN    */ MATHIT_array         y,
			 /*IN    */ float		 x_curr,
                         /*   OUT*/ void 	        *out_val,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_Linear";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4		  ind = -1;	  /* current class index */
   INTx4		  jl;		  /* utility variables */
   INTx4		  jm;		  /*                   */
   INTx4		  ju;		  /*                   */
   INTx4		  ascnd;	  /*                   */
   UINTx4		  i;		  /* counter */
   double		  inv_delta;	  /* inverse of the abscissa interval */
   double                 x_low;	  /* rigth extreem of the class */
   double   		  eps = 1.e-30;	  /* lower possible value */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the number of values
   ========================================================================== */
   if ( x.nelem < 2 )
      ERRSIM_set_error( status_code, ERRSID_MATH_no_suff_arr_elem, "" );
   if ( y.nelem != x.nelem )
      ERRSIM_set_error( status_code, ERRSID_MATH_xy_num_diff, "" );

/* ==========================================================================
   Search the class at which the actual abscissa belong
   ========================================================================== */
   switch ( x.atype ) {
      case MATHIE_uchar:

/* ==========================================================================
   Check if the actual abscissa value is in the range of the tabulated ones
   ========================================================================== */
	 if ( ( x_curr < (float)((UINTx1 *)x.ap)[ 0 ] ) ||
	      ( x_curr > (float)((UINTx1 *)x.ap)[ x.nelem - 1 ]) )
         ERRSIM_set_error( status_code, ERRSID_MATH_abscissa_out, "" );

	 /* search the class among all excluding the last one */
	 jl = 0;
	 ju = x.nelem;
	 ascnd = ((INTx4 *)x.ap)[ x.nelem - 1 ] > ((INTx4 *)x.ap)[ 0 ];
	 while ( ju - jl > 1 ) {
	    jm = ( ju + jl ) >> 1;
	    if ( x_curr > (float)((INTx4 *)x.ap)[ jm ] == ascnd ) jl = jm;
	    else ju = jm;
	 }
	 ind = jl;

	 /* consider the last */
	 if ( x_curr == (float)((UINTx1 *)x.ap)[ x.nelem - 1 ])
	    ind = x.nelem - 2;

	 /* fill the lower extreem of the interval */
	 x_low = (double)( ((UINTx1 *)x.ap)[ ind ] );

	 /* evaluate the difference between adiacent abscissa values */
	 inv_delta = (double)(((UINTx1 *)x.ap)[ ind + 1 ]) - x_low;
	 if ( inv_delta < eps )
	    ERRSIM_set_error( status_code, ERRSID_MATH_math_err,
			      " null abscissa interval" );
         inv_delta = 1. / inv_delta;

      break;
      case MATHIE_uintx2:

/* ==========================================================================
   Check if the actual abscissa value is in the range of the tabulated ones
   ========================================================================== */
	 if ( ( x_curr < (float)((UINTx2 *)x.ap)[ 0 ] ) ||
	      ( x_curr > (float)((UINTx2 *)x.ap)[ x.nelem - 1 ]) )
         ERRSIM_set_error( status_code, ERRSID_MATH_abscissa_out, "" );

	 /* search the class among all excluding the last one */
	 jl = 0;
	 ju = x.nelem;
	 ascnd = ((INTx4 *)x.ap)[ x.nelem - 1 ] > ((INTx4 *)x.ap)[ 0 ];
	 while ( ju - jl > 1 ) {
	    jm = ( ju + jl ) >> 1;
	    if ( x_curr > (float)((INTx4 *)x.ap)[ jm ] == ascnd ) jl = jm;
	    else ju = jm;
	 }
	 ind = jl;

	 /* consider the last */
	 if ( x_curr == (float)((UINTx2 *)x.ap)[ x.nelem - 1 ]) ind = x.nelem - 2;

	 /* fill the lower extreem of the interval */
	 x_low = (double)( ((UINTx2 *)x.ap)[ ind ] );

	 /* evaluate the difference between adiacent abscissa values */
	 inv_delta = (double)(((UINTx2 *)x.ap)[ ind + 1 ]) - x_low;
	 if ( inv_delta < eps )
	    ERRSIM_set_error( status_code, ERRSID_MATH_math_err,
			      " null abscissa interval" );
         inv_delta = 1. / inv_delta;

      break;
      case MATHIE_uintx4:

/* ==========================================================================
   Check if the actual abscissa value is in the range of the tabulated ones
   ========================================================================== */
	 if ( ( x_curr < (float)((UINTx4 *)x.ap)[ 0 ] ) ||
	      ( x_curr > (float)((UINTx4 *)x.ap)[ x.nelem - 1 ]) )
         ERRSIM_set_error( status_code, ERRSID_MATH_abscissa_out, "" );

	 /* search the class among all excluding the last one */
	 jl = 0;
	 ju = x.nelem;
	 ascnd = ((INTx4 *)x.ap)[ x.nelem - 1 ] > ((INTx4 *)x.ap)[ 0 ];
	 while ( ju - jl > 1 ) {
	    jm = ( ju + jl ) >> 1;
	    if ( x_curr > (float)((INTx4 *)x.ap)[ jm ] == ascnd ) jl = jm;
	    else ju = jm;
	 }
	 ind = jl;

	 /* consider the last */
	 if ( x_curr == (float)((UINTx4 *)x.ap)[ x.nelem - 1 ])
	    ind = x.nelem - 2;

	 /* fill the lower extreem of the interval */
	 x_low = (double)( ((UINTx4 *)x.ap)[ ind ] );

	 /* evaluate the difference between adiacent abscissa values */
	 inv_delta = (double)(((UINTx4 *)x.ap)[ ind + 1 ]) - x_low;
	 if ( inv_delta < eps )
	    ERRSIM_set_error( status_code, ERRSID_MATH_math_err,
			      " null abscissa interval" );
         inv_delta = 1. / inv_delta;

      break;
      case MATHIE_sintx4: {

/* ==========================================================================
   Check if the actual abscissa value is in the range of the tabulated ones
   ========================================================================== */
	 if ( ( x_curr < (float)((INTx4 *)x.ap)[ 0 ] ) ||
	      ( x_curr > (float)((INTx4 *)x.ap)[ x.nelem - 1 ]) )
         ERRSIM_set_error( status_code, ERRSID_MATH_abscissa_out, "" );

	 /* search the class among all excluding the last one */
	 jl = 0;
	 ju = x.nelem;
	 ascnd = ((INTx4 *)x.ap)[ x.nelem - 1 ] > ((INTx4 *)x.ap)[ 0 ];
	 while ( ju - jl > 1 ) {
	    jm = ( ju + jl ) >> 1;
	    if ( x_curr > (float)((INTx4 *)x.ap)[ jm ] == ascnd ) jl = jm;
	    else ju = jm;
	 }
	 ind = jl;

	 /* fill the lower extreem of the interval */
	 x_low = (double)( ((INTx4 *)x.ap)[ ind ] );

	 /* evaluate the difference between adiacent abscissa values */
	 inv_delta = (double)(((INTx4 *)x.ap)[ ind + 1 ]) - x_low;
	 if ( inv_delta < eps )
	    ERRSIM_set_error( status_code, ERRSID_MATH_math_err,
			      " null abscissa interval" );
         inv_delta = 1. / inv_delta;
      }
      break;
      case MATHIE_float:

/* ==========================================================================
   Check if the actual abscissa value is in the range of the tabulated ones
   ========================================================================== */
	 if ( ( x_curr < ((float *)x.ap)[ 0 ] ) ||
	      ( x_curr > ((float *)x.ap)[ x.nelem - 1 ]) )
         ERRSIM_set_error( status_code, ERRSID_MATH_abscissa_out, "" );

	 /* search the class among all excluding the last one */
	 jl = 0;
	 ju = x.nelem;
	 ascnd = ((INTx4 *)x.ap)[ x.nelem - 1 ] > ((INTx4 *)x.ap)[ 0 ];
	 while ( ju - jl > 1 ) {
	    jm = ( ju + jl ) >> 1;
	    if ( x_curr > (float)((INTx4 *)x.ap)[ jm ] == ascnd ) jl = jm;
	    else ju = jm;
	 }
	 ind = jl;

	 /* consider the last */
	 if ( x_curr == ((float *)x.ap)[ x.nelem - 1 ]) ind = x.nelem - 2;

	 /* fill the lower extreem of the interval */
	 x_low = (double)( ((float *)x.ap)[ ind ] );

	 /* evaluate the difference between adiacent abscissa values */
	 inv_delta = (double)(((float *)x.ap)[ ind + 1 ]) - x_low;
	 if ( inv_delta < eps )
	    ERRSIM_set_error( status_code, ERRSID_MATH_math_err,
			      " null abscissa interval" );
         inv_delta = 1. / inv_delta;

      break;
      default:
	 ERRSIM_set_error( status_code, ERRSID_MATH_arr_uncomp, "x" );
   }

/* ==========================================================================
   Switch between complex and real array
   ========================================================================== */
   switch ( y.atype ) {
      case MATHIE_undef:
	 ERRSIM_set_error( status_code, ERRSID_MATH_arr_undef, "y" );

      case MATHIE_uchar: {
	 double        	        a_cf;
	 double              	b_cf;

/* ==========================================================================
   Evaluate the coefficients:
	    a = ( y[ind+1] - y[ind] ) / ( x[ind+1] - x[ind] )
	    b = y[ind] - a*x[ind]
   ========================================================================== */
	 a_cf = (double	)
	           ( ((UINTx1 *)y.ap)[ ind + 1 ] - ((UINTx1 *)y.ap )[ ind ] ) *
		   inv_delta;
	 b_cf = (double)(((UINTx1 *)y.ap)[ ind ]) - a_cf * x_low;

/* ==========================================================================
   Evaluate the interpolated value
   ========================================================================== */
	 *((float *)out_val) = (float)(a_cf * (double)x_curr + b_cf);
      }
      break;
      case MATHIE_uintx2: {
	 double        	        a_cf;
	 double              	b_cf;

/* ==========================================================================
   Evaluate the coefficients:
	    a = ( y[ind+1] - y[ind] ) / ( x[ind+1] - x[ind] )
	    b = y[ind] - a*x[ind]
   ========================================================================== */
	 a_cf = (double	)
	           ( ((UINTx2 *)y.ap)[ ind + 1 ] - ((UINTx2 *)y.ap )[ ind ] ) *
		   inv_delta;
	 b_cf = (double)(((UINTx2 *)y.ap)[ ind ]) - a_cf * x_low;

/* ==========================================================================
   Evaluate the interpolated value
   ========================================================================== */
	 *((float *)out_val) = (float)(a_cf * (double)x_curr + b_cf);
      }
      break;
      case MATHIE_uintx4: {
	 double        	        a_cf;
	 double              	b_cf;

/* ==========================================================================
   Evaluate the coefficients:
	    a = ( y[ind+1] - y[ind] ) / ( x[ind+1] - x[ind] )
	    b = y[ind] - a*x[ind]
   ========================================================================== */
	 a_cf = (double	)
	           ( ((UINTx4 *)y.ap)[ ind + 1 ] - ((UINTx4 *)y.ap )[ ind ] ) *
		   inv_delta;
	 b_cf = (double)(((UINTx4 *)y.ap)[ ind ]) - a_cf * x_low;

/* ==========================================================================
   Evaluate the interpolated value
   ========================================================================== */
	 *((float *)out_val) = (float)(a_cf * (double)x_curr + b_cf);
      }
      break;
      case MATHIE_sintx4: {
	 double        	        a_cf;
	 double              	b_cf;

/* ==========================================================================
   Evaluate the coefficients:
	    a = ( y[ind+1] - y[ind] ) / ( x[ind+1] - x[ind] )
	    b = y[ind] - a*x[ind]
   ========================================================================== */
	 a_cf = (double	)
	           ( ((INTx4 *)y.ap)[ ind + 1 ] - ((INTx4 *)y.ap )[ ind ] ) *
		   inv_delta;
	 b_cf = (double)(((INTx4 *)y.ap)[ ind ]) - a_cf * x_low;

/* ==========================================================================
   Evaluate the interpolated value
   ========================================================================== */
	 *((float *)out_val) = (float)(a_cf * (double)x_curr + b_cf);
      }
      break;
      case MATHIE_float: {
	 double        	        a_cf;
	 double             	b_cf;

/* ==========================================================================
   Evaluate the coefficients:
	    a = ( y[ind+1] - y[ind] ) / ( x[ind+1] - x[ind] )
	    b = y[ind] - a*x[ind]
   ========================================================================== */
	 a_cf = (double)
	           ( ((float *)y.ap)[ ind + 1 ] - ((float *)y.ap)[ ind ] ) *
		   inv_delta;
         b_cf = (double)(((float *)y.ap)[ ind ]) - a_cf * x_low;

/* ==========================================================================
   Evaluate the interpolated value
   ========================================================================== */
	 *((float *)out_val) = (float)(a_cf * (double)x_curr + b_cf);
      }
      break;
      case MATHIE_complex: {
	 MATHIT_complex	        a_cf;
	 MATHIT_complex		b_cf;

/* ==========================================================================
   Evaluate the coefficients:
	    a = ( y[ind+1] - y[ind] ) / ( x[ind+1] - x[ind] )
	    b = y[ind] - a*x[ind]
   ========================================================================== */
	 MATHIP_STYP_CSubt( ((MATHIT_complex *)y.ap)[ ind + 1 ],
			    ((MATHIT_complex *)y.ap)[ ind ],
			    &a_cf, status_code );
	 MATHIP_STYP_CConstMult( inv_delta, a_cf, &a_cf, status_code );
	 MATHIP_STYP_CConstMult( x_low, a_cf, &b_cf, status_code );
	 MATHIP_STYP_CSubt( ((MATHIT_complex *)y.ap)[ ind ], b_cf, &b_cf,
			    status_code );

/* ==========================================================================
   Evaluate the interpolated value
   ========================================================================== */
	 MATHIP_STYP_CConstMult( (double)x_curr, a_cf,
				 (MATHIT_complex *)out_val,
				 status_code );
         MATHIP_STYP_CSum( *((MATHIT_complex *)out_val), b_cf,
			   (MATHIT_complex *)out_val,
			   status_code );

      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* MATHIP_INTR_Linear */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_NearestNeighbor

        $TYPE	      PROCEDURE

        $INPUT        InpIma	 : input matrix
		      NRowInp	 : number of rows of the input matrix
		      NColInp	 : number of columns of the input matrix
		      OutPoint	 : 2D array with the row, col coordinates of the
				   the points in which to interpolate
		      NRowOut	 : number of rows of the output matrix
		      NColOut	 : number of columns of the output matrix
		      InvVal	 : value for the points out of borders
		      DataType	 : flag to indicate the data type of the input
				   and the output matrices among the enumerate
				   LDEFIE_dt_type:
				   - LDEFIE_dt_UINTx1	 ( byte data )
				   - LDEFIE_dt_UINTx2	 ( real data )
				   - LDEFIE_dt_2_INTx2	 ( complex data )
				   - LDEFIE_dt_float	 ( real floating )
				   - LDEFIE_dt_2_float	 ( complex floating )

        $MODIFIED     NONE

        $OUTPUT       OutIma	 : matrix with the values of the input matrix
				   into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_interp_not_allow

        $DESCRIPTION  This procedure makes the Nearest Neighbor interpolation
		      of a matrix on the points coordinates given by an array
		      of row, col coordinates

        $WARNING      The invalid value <InvVal> is a number. For the complex
		      type matrix, the real and imaginary part of each element
		      are filled both with the value <InvVal>.
		      The type of the input and the output matrix must be equal.
		      No check is done here

        $PDL	      - Loop over the number of output rows
			   - Loop over the number of output columns
				 - Evaluate the nearest point coordinates
				 - Fill the output block
			   - End loop
		      - End loop

   $EH
   ========================================================================== */

void MATHIP_INTR_NearestNeighbor
                        (/*IN    */ void               **InpIma,
			 /*IN    */ UINTx4               NRowInp,
			 /*IN    */ UINTx4               NColInp,
			 /*IN    */ MATHIT_RC_float    **OutPoint,
			 /*IN    */ UINTx4               NRowOut,
			 /*IN    */ UINTx4               NColOut,
			 /*IN    */ void                *InvVal,
			 /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_NearestNeighbor";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 rc;
   UINTx4                 cc;
   INTx4                  NNr;
   INTx4                  NNc;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Loop over the number of output rows
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Evaluate the nearest point coordinates
   ========================================================================== */
	 NNr = (INTx4)( OutPoint[ rc ][ cc ].row + 0.5 );
	 NNc = (INTx4)( OutPoint[ rc ][ cc ].col + 0.5 );

/* ==========================================================================
   Inner coordinates control
   ========================================================================== */
	 if ( ( ( NNr >= 0 ) && ( ( (INTx4)( NNr + 0.5 ) ) < NRowInp ) ) &&
	      ( ( NNc >= 0 ) && ( ( (INTx4)( NNc + 0.5 ) ) < NColInp ) ) ) {

/* ==========================================================================
   Output image block filling
   ========================================================================== */
	    switch ( DataType ) {
	       case LDEFIE_dt_UINTx1:
		  ((UINTx1 **)OutIma)[ rc ][ cc ] =
		     ((UINTx1 **)InpIma)[ NNr ][ NNc ];
	       break;
	       case LDEFIE_dt_UINTx2:
		  ((UINTx2 **)OutIma)[ rc ][ cc ] =
                     ((UINTx2 **)InpIma)[ NNr ][ NNc ];
	       break;
	       case LDEFIE_dt_2_INTx2:
		  ((INTx2 **)OutIma)[ rc ][ cc * 2 ] =
                     ((INTx2 **)InpIma)[ NNr ][ NNc * 2 ];
		  ((INTx2 **)OutIma)[ rc ][ cc * 2 + 1 ] =
                     ((INTx2 **)InpIma)[ NNr ][ NNc * 2 + 1 ];
	       break;
	       case LDEFIE_dt_float:
		  ((float **)OutIma)[ rc ][ cc ] =
                     ((float **)InpIma)[ NNr ][ NNc ];
	       break;
	       case LDEFIE_dt_2_float:
		  ((float **)OutIma)[ rc ][ cc * 2 ] =
                     ((float **)InpIma)[ NNr ][ NNc * 2 ];
                  ((float **)OutIma)[ rc ][ cc * 2 + 1 ] =
                     ((float **)InpIma)[ NNr ][ NNc * 2 + 1 ];
	       break;
	       default:
		  ERRSIM_set_error ( status_code, ERRSID_MATH_interp_not_allow,
                                     "" );
	    }
	 }
	 else {

/* ==========================================================================
   Out border value
   ========================================================================== */
	    switch ( DataType ) {
	       case LDEFIE_dt_UINTx1:
		  ((UINTx1 **)OutIma)[ rc ][ cc ] = *((UINTx1 *)InvVal);
	       break;
	       case LDEFIE_dt_UINTx2:
		  ((UINTx2 **)OutIma)[ rc ][ cc ] = *((UINTx2 *)InvVal);
	       break;
	       case LDEFIE_dt_2_INTx2:
		  ((INTx2 **)OutIma)[ rc ][ cc * 2 ] =
		     (INTx2)( (MATHIT_complex *)InvVal)->rea;
		  ((INTx2 **)OutIma)[ rc ][ cc * 2 + 1 ] =
		     (INTx2)( (MATHIT_complex *)InvVal)->ima;
	       break;
	       case LDEFIE_dt_float:
		  ((float **)OutIma)[ rc ][ cc ] = *((float *)InvVal);
	       break;
	       case LDEFIE_dt_2_float:
		  ((float **)OutIma)[ rc ][ cc * 2 ] =
		     ( (MATHIT_complex *)InvVal)->rea;
                  ((float **)OutIma)[ rc ][ cc * 2 + 1 ] =
		     ( (MATHIT_complex *)InvVal)->ima;
	       break;
	       default:
		  ERRSIM_set_error ( status_code, ERRSID_MATH_interp_not_allow,
                                     "" );
	    }
	 }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code,
                          &log_status_code );

}/* MATHIP_INTR_NearestNeighbor */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_Bilinear

        $TYPE	      PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders
                      DataType   : flag to indicate the data type of the input
                                   and the output matrices among the enumerate
                                   LDEFIE_dt_type:
                                   - LDEFIE_dt_UINTx1    ( byte data )
                                   - LDEFIE_dt_UINTx2    ( real data )
                                   - LDEFIE_dt_2_INTx2   ( complex data )
                                   - LDEFIE_dt_float     ( real floating )
                                   - LDEFIE_dt_2_float   ( complex floating )

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_interp_not_allow

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
		      matrix on the points coordinates given by an array of row,
		      col coordinates

        $WARNING      The invalid value <InvVal> is a number. For the complex
                      type matrix, the real and imaginary part of each element
                      are filled both with the value <InvVal>

        $PDL	      - Loop over the number of output rows' coordinates
		            - Loop over the number of output columns'
			      coordinates
			          - Evaluate the image coordinates of the image
				    point on the top left of the square
				    surrounding the wanted point
                                  - If it is in the image or not
				        - Evaluate the value of the point with
					  coordinates equals to the top square
					  row at the wanted fractionary column
					  with a linear interpolation
				        - Evaluate the value of the point with
					  coordinates equals to the bottom
					  square row at the wanted fractionary
					  column with a linear interpolation
					- Evaluated the output value with a
					  linear interpolation between the two
					  interpolated points at the fractionary
					  row
                                  - End if
				  - Else
				        - Put the invalid value as output
					  interpolated value
				  - End else
			    - End loop
		      - End loop

   $EH
   ========================================================================== */

void MATHIP_INTR_Bilinear
                        (/*IN    */ void               **InpIma,
			 /*IN    */ UINTx4               NRowInp,
			 /*IN    */ UINTx4               NColInp,
			 /*IN    */ MATHIT_RC_float    **OutPoint,
			 /*IN    */ UINTx4               NRowOut,
			 /*IN    */ UINTx4               NColOut,
			 /*IN    */ float                InvVal,
			 /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_Bilinear";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   UINTx1                 fun;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Switch WRT the input data type
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx1:
         fun = 0;
      break;
      case LDEFIE_dt_UINTx2:
         fun = 1;
      break;
      case LDEFIE_dt_float:
         fun = 2;
      break;
      case LDEFIE_dt_2_INTx2:
         fun = 3;
      break;
      case LDEFIE_dt_2_float:
         fun = 4;
      break;
      default:
	 ERRSIM_set_error ( status_code, ERRSID_MATH_interp_not_allow, "" );
   }

/* ==========================================================================
   Call the bilinear interpolation function
   ========================================================================== */
   ( *MATHPC_bl_func[ fun ] )
      ( InpIma, NRowInp, NColInp, OutPoint, NRowOut, NColOut, InvVal, OutIma,
        status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* MATHIP_INTR_Bilinear */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_CubiConvInit

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MATHPV_CubiConvTable : table with the values of the
                                             cubic convolution kernel in the
                                             columns direction

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure allocates and fills the table with the
                      values of the cubic convolution kernel that will be used
                      to convolve the image to interpolate

        $WARNING      THIS PROCEDURE MUST BE USED BEFORE ALL THE CALLS TO THE
                      CUBIC CONVOLUTION PROCEDURES

        $PDL          - Checks that the table length is even and changes it if
                        it's not
                      - Allocates the necessary memories to store the table for
                        the cubic convolution values
                      - Loop over the intervals of delta
                            - Evaluates the value of the coordinates normalized
                              at the rigth range
                            - Loop over the points of the image to interpolate
                                  - Evaluates the complement of the delta
                                  - Evaluates the cubic convolution kernel
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHIP_INTR_CubiConvInit
                        (/*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_CubiConvInit";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 i;
   UINTx4                 j;
   float                  dd;
   float                  delta;
   float                  val;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check that the length variable is odd
   ========================================================================== */
   if ( ( (float)( MATHIV_CCTableLength >> 1 ) -
          (float)( (UINTx4)( MATHIV_CCTableLength >> 1 ) ) ) ) {
      MATHIV_CCTableLength ++;
   }

/* ==========================================================================
   Allocate the table necessary memories
   ========================================================================== */
   if ( ( MATHPV_CubiConvTable = (float **)MEMSIP_alloc ( (size_t)
             ( ( MATHIV_CCTableLength + 1 ) * sizeof (float *) ) ) ) ==
        (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                         " in the cubic conv. table allocation" );
   }
   for ( i=0; i<=MATHIV_CCTableLength; i++ ) {
      if ( ( MATHPV_CubiConvTable[ i ] = (float *)MEMSIP_alloc ( (size_t)
                (MATHID_cubi_conv_elem * sizeof (float) ) ) ) ==
           (float *)NULL )  {
         ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                            " in the cubic conv. table allocation" );
      }
   }

/* ==========================================================================
   Loop over the delta values
   ========================================================================== */
   for ( i=0; i<( MATHIV_CCTableLength >> 1 ); i++ ) {

/* ==========================================================================
   Evaluate the delta WRT the left integer pixel
   ========================================================================== */
      delta = (float)i / ((float)MATHIV_CCTableLength );

/* ==========================================================================
   Loop over the coefficients
   ========================================================================== */
      for ( j=0; j<MATHID_cubi_conv_elem; j++ ) {

/* ==========================================================================
   Evaluate the complementary delta value
   ========================================================================== */
         dd = 2. - delta - (float)j;

/* ==========================================================================
   Fill the table
   ========================================================================== */
         MATHPV_CubiConvTable[ i ][ j ] =
            MATHPF_INTR_CubiConvKernel ( dd, status_code );

/* ==========================================================================
   The table is simmetric
   ========================================================================== */
         MATHPV_CubiConvTable[ MATHIV_CCTableLength - i ]
            [ MATHID_cubi_conv_elem - j - 1 ] =
            MATHPV_CubiConvTable[ i ][ j ];
      }
   }

/* ==========================================================================
   Central line of the table
   ========================================================================== */
   i = (UINTx4)( MATHIV_CCTableLength >> 1 );
   delta = (float)i / ((float)(MATHIV_CCTableLength) );
   for ( j=0; j<( MATHID_cubi_conv_elem >> 1 ); j++ ) {

/* ==========================================================================
   Evaluate the complementary delta value
   ========================================================================== */
      dd = 2. - delta - (float)j;

/* ==========================================================================
   Fill the table
   ========================================================================== */
      MATHPV_CubiConvTable[ i ][ j ] =
         MATHPF_INTR_CubiConvKernel ( dd, status_code );

/* ==========================================================================
   Fill the simmetric central line
   ========================================================================== */
      MATHPV_CubiConvTable[ i ]
         [ MATHID_cubi_conv_elem - j - 1 ] = MATHPV_CubiConvTable[ i ][ j ];
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_INTR_CubiConvInit */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_CubicConvolution

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders
                      DataType   : flag to indicate the data type of the input
                                   and the output matrices among the enumerate
                                   LDEFIE_dt_type:
                                   - LDEFIE_dt_UINTx1    ( byte data )
                                   - LDEFIE_dt_UINTx2    ( real data )
                                   - LDEFIE_dt_2_INTx2   ( complex data )
                                   - LDEFIE_dt_float     ( real floating )
                                   - LDEFIE_dt_2_float   ( complex floating )

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHPC_cc_func : array of functions to make the cubic
                                       convolution with a given input image
                                       type

        $RET_STATUS   ERRSID_MATH_negative_dimen
                      ERRSID_MATH_interp_not_allow

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Checks the number of rows and columns
                      - Switch WRT the input data type
                            - Puts the index WRT the data type
                      - End switch
                      - Calls the interpolation function

   $EH
   ========================================================================== */

void MATHIP_INTR_CubicConvolution
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_CubicConvolution";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   UINTx1                 fun = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the number of rows and columns
   ========================================================================== */
   if ( ( NRowInp <= 0 ) || ( NColInp <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_negative_dimen,
                         "of the input image" );
   }
/* ==========================================================================
   Check the number of output points
   ========================================================================== */
   if ( ( NRowOut <= 0 ) || ( NColOut <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_negative_dimen,
                         "of the output image" );
   }

/* ==========================================================================
   Interpolate WRT the different data type
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx1:
         fun = 0;
      break;
      case LDEFIE_dt_UINTx2:
         fun = 1;
      break;
      case LDEFIE_dt_float:
         fun = 2;
      break;
      case LDEFIE_dt_2_INTx2:
         fun = 3;
      break;
      case LDEFIE_dt_2_float:
         fun = 4;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_MATH_interp_not_allow,
                            "in the cubic convolution interpolation" );
   }

/* ==========================================================================
   Call the cubic convolution function
   ========================================================================== */
   ( *MATHPC_cc_func[ fun ] )( InpIma, NRowInp, NColInp, OutPoint, NRowOut,
                               NColOut, InvVal, OutIma, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_INTR_CubicConvolution */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_CubiConvClose

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MATHPV_CubiConvTable : table with the values of the
                                             cubic convolution kernel in the
                                             columns direction

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure frees the memories allocated to store the
                      tabulated values for the cubic convolution interpolation

        $WARNING      NONE

        $PDL          - Check if the double pointer to the table is not NULL
                            - Loop over the rows of the table
                                  - Frees the allocated rows memory
                            - End loop
                            - Deallocates the double pointer memories
                      - End if

   $EH
   ========================================================================== */

void MATHIP_INTR_CubiConvClose
                        (/*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_CubiConvClose";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Deallocate the cubic convolution table
   ========================================================================== */
   if ( MATHPV_CubiConvTable != (float **)NULL ) {
      for ( i=0; i<=MATHIV_CCTableLength; i++ ) {
         MEMSIP_free ( (void **)&(MATHPV_CubiConvTable[ i ]) );
      }
      MEMSIP_free ( (void **)&MATHPV_CubiConvTable );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_INTR_CubiConvClose */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_SincInit

        $TYPE         PROCEDURE

        $INPUT        Fdc     : array of frequences for the azimuth
                                modulation
                      NImages : number of images on which the sinc
                                interpolation can be done
        $MODIFIED     NONE

        $OUTPUT       The azimuth and range sinc tables are created and filled

        $GLOBAL       MATHPV_SincRowTable       : the table of sinc values to
                                                  interpolate in the range
                                                  direction
                      MATHPV_SincColTable       : the table of sinc values to
                                                  interpolate in the azimuth
                                                  direction
                      MATHIV_SincTableLength    : the reciprocal of the
                                                  precision required in the
                                                  interpolation

        $RET_STATUS   ERRSID_MATH_even_sinc_num
                      ERRSID_MATH_err_mem_alloc

        $DESCRIPTION  This procedure initialize the tables for the sinc
                      interpolation.

        $WARNING      AT THE END OF THE TOOL THE COLSURE PROCEDURE MUST BE
                      CALLED.

        $PDL          - Checks the number of images
                      - Checks the table dimensions
                      - Allocates the sinc tables
                      - Loop over the images
                            - Allocates the range table
                            - Zeroes the table
                            - Allocates the azimuth table
                            - Zeroes the table
                              interpolate
                                  - Evaluates the delta
                                  - Fills the corresponding tables row
                            - End loop
                      - End Loop

   $EH
   ========================================================================== */

void MATHIP_INTR_SincInit
                        (/*IN    */ float               *Fdc,
                         /*IN    */ INTx4                NImages,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_SincInit";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   float                  delta;
   INTx4                  ncol;
   INTx4                  i;
   INTx4                  j;
   INTx4                  k;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Check that the length variable is odd
   ========================================================================== */
   if ( ( (float)MATHIV_SincTableLength / 2. ) -
        ( (UINTx4)(MATHIV_SincTableLength / 2.) ) ) {
      MATHIV_SincTableLength ++;
   }

/* ==========================================================================
   Check that the number of sinc is odd
   ========================================================================== */
   if ( !( ( (float)MATHIV_sinc_elem / 2. ) -
           ( (UINTx4)(MATHIV_sinc_elem / 2.) ) ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_even_sinc_num, "" );
   }

/* ==========================================================================
   Allocate the Sinc table
   ========================================================================== */
   if ( (MATHPV_SincRowTable = (float ***)MEMSIP_alloc ( (size_t)(NImages *
                                                       sizeof (float **)) ) ) ==
        (float ***)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                         " in the row sinc table allocation" );
   }
   if ( (MATHPV_SincColTable = (MATHIT_complex ***)MEMSIP_alloc ( (size_t)
                                                                  (NImages *
                                              sizeof (MATHIT_complex **)) ) ) ==
        (MATHIT_complex ***)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                         " in the row sinc table allocation" );
   }

/* ==========================================================================
   Initializes the pointers of the tables pointer
   ========================================================================== */
   for ( i=0; i<NImages; i++ ) {
      MATHPV_SincRowTable[ i ] = (float **)NULL;
      MATHPV_SincColTable[ i ] = (MATHIT_complex **)NULL;
   }

/* ==========================================================================
   Allocate the table necessary memories
   ========================================================================== */

   for ( j=0; j<NImages; j++ ) {

      /* row table */
      if ( ( MATHPV_SincRowTable[ j ] = (float **)MEMSIP_alloc ( (size_t)
                 ( ( MATHIV_SincTableLength + 1 ) * sizeof (float *) ) ) ) ==
            (float **)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                            " in the row sinc table allocation" );
      }
      for ( i=0; i<=MATHIV_SincTableLength; i++ ) {
         if ( ( MATHPV_SincRowTable[ j ][ i ] = (float *)MEMSIP_alloc ( (size_t)
                                                             (MATHIV_sinc_elem *
                                                         sizeof (float) ) ) ) ==
              (float *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                               " in the row sinc table allocation" );
         }

/* ==========================================================================
   Zero the row of the table
   ========================================================================== */
         memset ( (void *)(MATHPV_SincRowTable[ j ][ i ]), '\0',
                  (size_t)(MATHIV_sinc_elem * sizeof (float)) );
      }

      /* col table */
      if ( ( MATHPV_SincColTable[ j ] = (MATHIT_complex **)
              MEMSIP_alloc ( (size_t)(( MATHIV_SincTableLength + 1 ) *
                             sizeof (MATHIT_complex *) ) ) ) ==
            (MATHIT_complex **)NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                            " in the row sinc table allocation" );
      }
      for ( i=0; i<=MATHIV_SincTableLength; i++ ) {
         if ( ( MATHPV_SincColTable[ j ][ i ] = (MATHIT_complex *)
                    MEMSIP_alloc ( (size_t)(MATHIV_sinc_elem *
                                   sizeof (MATHIT_complex) ) ) ) ==
               (MATHIT_complex *)NULL ) {
            ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                               " in the row sinc table allocation" );
         }

/* ==========================================================================
   Zero the row of the table
   ========================================================================== */
         memset ( (void *)(MATHPV_SincColTable[ j ][ i ]), '\0',
                  (size_t)(MATHIV_sinc_elem * sizeof (MATHIT_complex)) );
      }

/* ==========================================================================
   Loop over the delta values
   ========================================================================== */
      for ( i=0; i<( MATHIV_SincTableLength >> 1 ); i++ ) {

/* ==========================================================================
   Evaluate the delta
   ========================================================================== */
         delta = (float)i / ((float)MATHIV_SincTableLength ) - 0.5;

/* ==========================================================================
   Fill the range table
   ========================================================================== */
         MATHPP_INTR_SincRange ( delta, MATHPV_SincRowTable[ j ][ i ],
                                 status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the azimuth table
   ========================================================================== */
         MATHPP_INTR_SincAzimuth ( delta, Fdc[ j ], MATHPV_SincColTable[ j ][ i ],
                                   status_code );
         ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the simmetric tables part
   ========================================================================== */
         for ( k=0;k<MATHIV_sinc_elem; k++ ) {
            MATHPV_SincRowTable[ j ][ MATHIV_SincTableLength - i ]
               [ MATHIV_sinc_elem - k - 1 ] =
               MATHPV_SincRowTable[ j ][ i ][ k ];
            MATHIP_STYP_CConj ( MATHPV_SincColTable[ j ][ i ][ k ],
                                &(MATHPV_SincColTable[ j ]
                                  [ MATHIV_SincTableLength - i ]
                                  [ MATHIV_sinc_elem - k - 1 ]), status_code );
         }
      }

/* ==========================================================================
   Central line of the table
   ========================================================================== */
      i = (UINTx4)( MATHIV_SincTableLength >> 1 );

/* ==========================================================================
   Evaluate the delta
   ========================================================================== */
      delta = (float)i / ((float)MATHIV_SincTableLength ) - 0.5;

/* ==========================================================================
   Fill the range table
   ========================================================================== */
      MATHPP_INTR_SincRange ( delta, MATHPV_SincRowTable[ j ][ i ],
                              status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the azimuth table
   ========================================================================== */
      MATHPP_INTR_SincAzimuth ( delta, Fdc[ j ], MATHPV_SincColTable[ j ][ i ],
                                status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }


error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_INTR_SincInit */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_Sinc

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders
                      DataType   : flag to indicate the data type of the input
                                   and the output matrices among the enumerate
                                   LDEFIE_dt_type:
                                   - LDEFIE_dt_UINTx1    ( byte data )
                                   - LDEFIE_dt_UINTx2    ( real data )
                                   - LDEFIE_dt_2_INTx2   ( complex data )
                                   - LDEFIE_dt_float     ( real floating )
                                   - LDEFIE_dt_2_float   ( complex floating )

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHPC_sinc_func : array of functions to make the sinc
                                         interpolation of a matrix on the points
                                         coordinates given by an array of row,
                                         col coordinates

        $RET_STATUS   ERRSID_MATH_imanum_out
                      ERRSID_MATH_negative_dimen
                      ERRSID_MATH_interp_not_allow

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Checks the number of rows and columns
                      - Switch WRT the input data type
                            - Puts the index WRT the data type
                      - End switch
                      - Calls the interpolation function

   $EH
   ========================================================================== */

void MATHIP_INTR_Sinc
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_Sinc";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   UINTx1                 fun = 0;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the number of rows and columns
   ========================================================================== */
   if ( ( NRowInp <= 0 ) || ( NColInp <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_negative_dimen,
                         "of the input image" );
   }

/* ==========================================================================
   Check the number of output points
   ========================================================================== */
   if ( ( NRowOut <= 0 ) || ( NColOut <= 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_negative_dimen,
                         "of the output image" );
   }
/* ==========================================================================
   Interpolate WRT the different data type
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx1:
         fun = 0;
      break;
      case LDEFIE_dt_UINTx2:
         fun = 1;
      break;
      case LDEFIE_dt_float:
         fun = 2;
      break;
      case LDEFIE_dt_2_INTx2:
         fun = 3;
      break;
      case LDEFIE_dt_2_float:
         fun = 4;
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_MATH_interp_not_allow,
                            "in the sinc interpolation" );
   }

/* ==========================================================================
   Call the sinc function
   ========================================================================== */
   ( *MATHPC_sinc_func[ fun ] )( imanum, InpIma, NRowInp, NColInp, OutPoint,
                                 NRowOut, NColOut, InvVal, OutIma,
                                 status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_INTR_Sinc */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_SincClose

        $TYPE         PROCEDURE

        $INPUT        NImages : number of images opened

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MATHIV_SincTableLength : inverse of the precision required
                                               for the sinc interpolator kernel
                      MATHPV_SincRowTable    : tabulated values of the sinc
                                               function for various delta values
                                               in the range direction
                      MATHPV_SincColTable    : tabulated values of the sinc
                                               function for various delta values
                                               in the azimuth direction

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure deallocates the memories allocated in the
                      initialization procedure for the sinc tables

        $WARNING      THIS PROCEDURE MUST BE CALLED AT THE END OF ALL THE
                      INTERPOLATION PROCEDURES THAT USES THE SINC INTERPOLATION
                      FUNCTION

        $PDL          - Deallocates the row table
                      - Deallocate the column table

   $EH
   ========================================================================== */

void MATHIP_INTR_SincClose
                        (/*IN    */ INTx4                NImages,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_SincClose";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variable
   ========================================================================== */
   UINTx4                 i;
   UINTx4                 j;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Deallocate the row ...
   ========================================================================== */
   if ( MATHPV_SincRowTable != (float ***)NULL ) {
      for ( j=0; j<NImages; j++ ) {
         for ( i=0; i<=MATHIV_SincTableLength; i++ ) {
            MEMSIP_free ( (void **)&(MATHPV_SincRowTable[ j ][ i ]) );
         }
         MEMSIP_free ( (void **)&(MATHPV_SincRowTable[ j ]) );
      }
   }
   MEMSIP_free ( (void **)&MATHPV_SincRowTable );

/* ==========================================================================
   ... and column table
   ========================================================================== */
   if ( MATHPV_SincColTable != (MATHIT_complex ***)NULL ) {
      for ( j=0; j<NImages; j++ ) {
         for ( i=0; i<=MATHIV_SincTableLength; i++ ) {
            MEMSIP_free ( (void **)&(MATHPV_SincColTable[ j ][ i ]) );
         }
         MEMSIP_free ( (void **)&(MATHPV_SincColTable[ j ]) );
      }
   }
   MEMSIP_free ( (void **)&MATHPV_SincColTable );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_INTR_SincClose */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_FFTConstShift

        $TYPE         PROCEDURE

        $INPUT        NRowInp  : number of rows of the image block
                      NColInp  : number of columns of the image block
                      DataType : image data type
                      InpIma   : input image block
                      shift    : shifts values in row and column direction

        $MODIFIED     NONE

        $OUTPUT       OutIma   : output image block

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_dim
                      ERRSID_MATH_shift_too_high

        $DESCRIPTION  This procedure shifts the image block of the wanted
                      constant amount in the row and column directions

        $WARNING      THE OUTPUT IMAGE MUST BE OF THE SAME TYPE OF THE INPUT
                      ONE

        $PDL          - Checks the numbers of rows and columns
                      - Checks the shifts values
                      - Allocates the necessary vectors
                      - Fills an array with the input image
                      - Evaluates the utility variables for the row shift
                      - Loop over the image columns
                            - Evaluates the phase value
                            - Evaluates the corresponding exponential values
                      - End loop
                      - Makes the 2D FFT of the image
                      - Re-allocates the arrays
                      - Loop over the image rows
                            - Copies the row in a temporary array
                            - Multiplicates the row by the exponential before
                              evaluated
                            - Copies the modified row in the FFT matrix
                      - End loop
                      - Evaluates the constants for the column shift
                      - Re-allocates the necessary memories
                      - Loop over the rows
                            - Evaluates the phase value
                            - Evaluates the corresponding exponential values
                      - End loop
                      - Loop over the FFT columns
                            - Copies the column in a temporary array
                            - Multiplicates the column by the exponential before
                              evaluated
                            - Copies the modified column in the FFT matrix
                      - End loop
                      - De-allocates the memories
                      - Makes the inverse FFT
                      - Copies the obtained shifted image in the output variable
                      - Clean-up the FFT lefted static memories

   $EH
   ========================================================================== */

void MATHIP_INTR_FFTConstShift
                        (/*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ void               **InpIma,
                         /*IN    */ MATHIT_RC            shift,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_FFTConstShift";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 row;
   UINTx4                 col;
   UINTx4                 dc = 0;
   UINTx4                 h;
   INTx1                  flag;
   float                  nu;
   float                  nu0;
   double                 ph;
   MATHIT_array           phase;
   MATHIT_array           sign_s;
   MATHIT_array           sign_f;
   MATHIT_array           temp;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the number of rows and columns of the input block
   ========================================================================== */
   if ( ( NRowInp < 1 ) || ( NColInp < 1 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_null_dim, "" );
   }

/* ==========================================================================
   Check the shifts values
   ========================================================================== */
   if ( ( ABS ( shift.row ) > (double)((INTx4)(NColInp / 2)) ) ||
        ( ABS ( shift.col ) > (double)((INTx4)(NRowInp / 2)) ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_shift_too_high, "" );
   }

/* ==========================================================================
   Allocated the necessary vectors
   ========================================================================== */
   /* phase array */
   MATHIP_VECT_Make ( NColInp, MATHIE_complex, &phase, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* input signal array */
   MATHIP_VECT_Make ( (INTx4)(NRowInp * NColInp), MATHIE_complex, &sign_s,
                      status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* output signal array */
   MATHIP_VECT_Make ( (INTx4)(NRowInp * NColInp), MATHIE_complex, &sign_f,
                      status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

   /* temporary array */
   MATHIP_VECT_Make ( NColInp, MATHIE_complex, &temp, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the signal array
   ========================================================================== */
   MATHPP_INTR_FillArray ( InpIma, NRowInp, NColInp, DataType, &sign_s,
                           status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the utility variables for the row shift
   ========================================================================== */
   /* half number of columns */
   h = (UINTx4)(NColInp / 2);

   /* phase frequency */
   nu = - (double)(2 * PI * shift.col / (float)NColInp);

   /* utility odd indicator */
   dc = NColInp % 2;

/* ==========================================================================
   Fill the phase vector
   ========================================================================== */
   for ( col=0; col<h; col++ ) {

/* ==========================================================================
   Phase evaluation for the column col
   ========================================================================== */
      ph = ( (double)col ) * nu;

/* ==========================================================================
   Exponential evaluation
   ========================================================================== */
      MATHIP_STYP_CExp ( ph, &(((MATHIT_complex *)phase.ap)[ col ]),
                         status_code );

/* ==========================================================================
   Phase evaluation for the column col - h
   ========================================================================== */
      ph -= ( (double)(h + dc) ) * nu;
      MATHIP_STYP_CExp ( ph, &(((MATHIT_complex *)phase.ap)[ col + h ]),
                         status_code );
   }

/* ==========================================================================
   Fill the central element
   ========================================================================== */
   if ( dc ) {
      ph = - (double)(1 * nu);
      MATHIP_STYP_CExp ( ph, &(((MATHIT_complex *)phase.ap)[ 2 * h ]),
                         status_code );
   }

/* ==========================================================================
   Make the 2D FFT of the input signal
   ========================================================================== */
   flag = 0;
   MATHIP_DFFT_2D ( sign_s, NRowInp, NColInp, flag, &sign_f, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Reallocate the input signal
   ========================================================================== */
   MATHIP_VECT_Free ( &sign_s, status_code );
   MATHIP_VECT_Make ( NColInp, MATHIE_complex, &sign_s, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Shift the image block rows multipling the image FFT
   ========================================================================== */
   for ( row=0; row<NRowInp; row++ ) {

/* ==========================================================================
   Copy the portion of the input FFT array in the temporary one
   ========================================================================== */
      MATHIP_VECT_SubCopy ( sign_f, (INTx4)(row * NColInp), NColInp, &sign_s,
                            (INTx4)0, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Multiply the FFT array by the complex factor
   ========================================================================== */
      MATHIP_VECT_Prod ( sign_s, phase, &temp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Copy the shifted FFT in the old matrix
   ========================================================================== */
      MATHIP_VECT_SubCopy ( temp, (INTx4)0, temp.nelem, &sign_f,
                            (INTx4)(row * NColInp), status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

/* ==========================================================================
   Evaluate the utility variables for the column ... see comment above
   ========================================================================== */
   h = (UINTx4)(NRowInp / 2);
   nu = - (double)(2 * PI * shift.row / (float)NRowInp);
   dc = NRowInp % 2;

/* ==========================================================================
   Re-allocated the necessary vectors
   ========================================================================== */
   MATHIP_VECT_Free ( &phase, status_code );
   MATHIP_VECT_Free ( &sign_s, status_code );
   MATHIP_VECT_Free ( &temp, status_code );

   MATHIP_VECT_Make ( NRowInp, MATHIE_complex, &phase, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   MATHIP_VECT_Make ( NRowInp, MATHIE_complex, &sign_s, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   MATHIP_VECT_Make ( NRowInp, MATHIE_complex, &temp, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the phase vector ... see comment above
   ========================================================================== */
   for ( row=0; row<h; row++ ) {
      ph = ( (double)row ) * nu;
      MATHIP_STYP_CExp ( ph, &(((MATHIT_complex *)phase.ap)[ row ]),
                         status_code );
#ifdef __TRACE__
   fprintf ( stdout, "\n ph[%d]=%f", row, ph );
#endif
      ph -= ( (double)(h + dc) ) * nu;
      MATHIP_STYP_CExp ( ph, &(((MATHIT_complex *)phase.ap)[ row + h ]),
                         status_code );
#ifdef __TRACE__
   fprintf ( stdout, "\n ph[%d]=%f", row + h, ph );
#endif
   }
   if ( dc ) {
      ph = - (double)(1 * nu);
      MATHIP_STYP_CExp ( ph, &(((MATHIT_complex *)phase.ap)[ 2 * h ]),
                         status_code );
#ifdef __TRACE__
   fprintf ( stdout, "\n ph[%d]=%f", 2 * h, ph );
#endif
   }

#ifdef __TRACE__
   for ( row=0; col<NRowInp; row++ ) {
      fprintf ( stdout, "\n phase[%d]=(    %f,    %f)", row,
                (((MATHIT_complex *)phase.ap)[ row ]).rea,
                (((MATHIT_complex *)phase.ap)[ row ]).ima );
   }
#endif

/* ==========================================================================
   Shift the image block ... see comment above
   ========================================================================== */
   for ( col=0; col<NColInp; col++ ) {
      for ( row=0; row<NRowInp; row++ ) {
         memcpy ( &(((MATHIT_complex *)sign_s.ap)[ row ]),
                  &(((MATHIT_complex *)sign_f.ap)[ row * NColInp + col ]),
                  sizeof (MATHIT_complex) );
      }
      MATHIP_VECT_Prod ( sign_s, phase, &temp, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
      for ( row=0; row<NRowInp; row++ ) {
         memcpy ( &(((MATHIT_complex *)sign_f.ap)[ row * NColInp + col ]),
                  &(((MATHIT_complex *)temp.ap)[ row ]),
                  sizeof (MATHIT_complex) );
      }
   }

/* ==========================================================================
   Re-allocate the output signal array
   ========================================================================== */
   MATHIP_VECT_Free ( &sign_s, status_code );
   MATHIP_VECT_Make ( (INTx4)(NRowInp * NColInp), MATHIE_complex, &sign_s,
                      status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Make the inverse FFT
   ========================================================================== */
   flag = 1;
   MATHIP_DFFT_2D ( sign_f, NRowInp, NColInp, flag, &sign_s, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Copy the shifted image in the output block
   ========================================================================== */
   MATHPP_INTR_FillImage ( sign_s, NRowInp, NColInp, DataType, OutIma,
                           status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

error_exit:;

/* ==========================================================================
   Clean up the allocated memories
   ========================================================================== */
   flag = -1;
   MATHIP_DFFT_1D ( phase, NColInp, flag, &phase, &log_status_code );
   ERRSIM_on_err_goto_exit ( log_status_code );

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MATHIP_VECT_Free ( &phase, status_code );
   MATHIP_VECT_Free ( &sign_s, status_code );
   MATHIP_VECT_Free ( &sign_f, status_code );
   MATHIP_VECT_Free ( &temp, status_code );

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_INTR_FFTConstShift */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_ImageRowShift

        $TYPE         PROCEDURE

        $INPUT        NRowInp  : number of rows of the image portion
                      NColInp  : number of columns of the image portion
                      shift    : array of shifts to apply to the image rows
                      DataType : data type of the image

        $MODIFIED     InpIma   : the image to shift

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_dim

        $DESCRIPTION  This procedure shifts a block image of a wanted number
                      (floating) of pixels in the row direction

        $WARNING      NONE

        $PDL          - Checks the number of rows and columns of the block
                        image
                      - Initializes the usefull variables
                      - Allocates the wanted memories
                      - Loop over the number of columns
                            - Evaluates the phase of the multiplicator factor
                            - Fills the vector element with the multiplication
                              factor
                            - Fills the vector element complementar to the
                              current column
                      - End loop
                      - Fills the central element of the multiplication factors
                        vector if the total number of elements if odd
                      - Loop over the rows of the image block
                            - Evaluates the factor depending by the row shift
                            - Re-scales the phase array by the evaluate factor
                            - Zeroes the signal vector
                            - Fills the signal vector with the image row
                            - Makes the FFT of the signal
                            - Multiplicates the signal FFT with the phase
                              vector
                            - Makes the inverse FFT of the signal FFT
                            - Fills the image row with the new values
                      - End loop
                      - Clears all the memories of the FFT evaluation
                      - Frees the allocated memories

   $EH
   ========================================================================== */

void MATHIP_INTR_ImageRowShift
                        (/*IN    */ UINTx4              NRowInp,
                         /*IN    */ UINTx4              NColInp,
                         /*IN    */ float              *shift,
                         /*IN    */ LDEFIT_data_type    DataType,
                         /*IN OUT*/ void              **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_ImageRowShift";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;
   INTx4                  dc = 0;
   INTx4                  h;
   INTx1                  flag;
   float                  nu;
   MATHIT_array           ph;
   MATHIT_array           tmp;
   MATHIT_array           phase;
   MATHIT_array           sign_s;
   MATHIT_array           sign_f;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the image sizes
   ========================================================================== */
   if ( ( NRowInp < 1 ) || ( NColInp < 1 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_null_dim, "" );
   }

/* ==========================================================================
   Evaluate the utility variables for the row shift
   ========================================================================== */
   h = (INTx4)(NColInp / 2);
   nu = - (double)(2 * PI / (float)NColInp);
   dc = NColInp % 2;

/* ==========================================================================
   Allocated the necessary vectors
   ========================================================================== */
   MATHIP_VECT_Make ( NColInp, MATHIE_complex, &phase, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   MATHIP_VECT_Make ( NColInp, MATHIE_complex, &sign_s, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   MATHIP_VECT_Make ( NColInp, MATHIE_complex, &sign_f, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   MATHIP_VECT_Make ( NColInp, MATHIE_float, &ph, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   MATHIP_VECT_Make ( NColInp, MATHIE_float, &tmp, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the phase vector
   ========================================================================== */
   for ( col=0; col<h; col++ ) {
      ((float *)tmp.ap)[ col ] = (float)(col) * nu;
      ((float *)tmp.ap)[ col + h ] = (float)(col - h - dc) * nu;
#ifdef __TRACE__
      fprintf ( stdout, "\n tmp[%d] = %f", col, ((float *)tmp.ap)[ col ] );
      fprintf ( stdout, "\n tmp[%d] = %f", col + h, ((float *)tmp.ap)[ col + h] );
#endif
   }

/* ==========================================================================
   Fill the central element
   ========================================================================== */
   if ( dc ) {
      ((float *)tmp.ap)[ 2 * h ] = - 1. * nu;
#ifdef __TRACE__
   fprintf ( stdout, "\n tmp[%d] = %f", 2 * h, ((float *)tmp.ap)[ 2 * h ] );
#endif
   }

/* ==========================================================================
   Shift the image block
   ========================================================================== */
   for ( row=0; row<NRowInp; row++ ) {

/* ==========================================================================
   Re-scale the phase vector
   ========================================================================== */
      MATHIP_VECT_ConstMult ( shift[ row ], tmp, &ph, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Evaluate the array with the phase values
   ========================================================================== */
      MATHIP_VECT_Exp ( ph, &phase, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
#ifdef __TRACE__
   for ( col=0; col<NColInp; col++ ) {
      fprintf ( stdout, "\n phase[%d] = (    %f,    %f)", col,
                (((MATHIT_complex *)phase.ap)[ col ]).rea,
                (((MATHIT_complex *)phase.ap)[ col ]).ima );
   }
#endif

/* ==========================================================================
   Zero the input array
   ========================================================================== */
      memset ( sign_s.ap, '\0', (size_t)(NColInp * sizeof (MATHIT_complex)) );

/* ==========================================================================
   Fill the array with the elements of the line
   ========================================================================== */
      MATHPP_INTR_FillRowArray ( InpIma, row, NColInp, DataType, &sign_s,
                                 status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Make the FFT of the line
   ========================================================================== */
      flag = 0;
      MATHIP_DFFT_1D ( sign_s, NColInp, flag, &sign_s, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Multiply the FFT array by the complex factor
   ========================================================================== */
      MATHIP_VECT_Prod ( sign_s, phase, &sign_f, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Make the inverse FFT of the signal
   ========================================================================== */
      flag = 1;
      MATHIP_DFFT_1D ( sign_f, NColInp, flag, &sign_f, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the input image row
   ========================================================================== */
      MATHPP_INTR_FillImaRow ( sign_f, row, NColInp, DataType, InpIma,
                               status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

/* ==========================================================================
   Clean up all the FFT memories
   ========================================================================== */
   flag = -1;
   MATHIP_DFFT_1D ( sign_f, NColInp, flag, &sign_f, &log_status_code );
   ERRSIM_on_err_goto_exit ( log_status_code );

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MATHIP_VECT_Free ( &phase, status_code );
   MATHIP_VECT_Free ( &sign_s, status_code );
   MATHIP_VECT_Free ( &sign_f, status_code );
   MATHIP_VECT_Free ( &tmp, status_code );
   MATHIP_VECT_Free ( &ph, status_code );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* MATHIP_INTR_ImageRowShift */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_ImageColShift

        $TYPE         PROCEDURE

        $INPUT        NRowInp  : number of rows of the image portion
                      NColInp  : number of columns of the image portion
                      shift    : array of shifts to apply to the image columns
                      DataType : data type of the image

        $MODIFIED     InpIma   : the image to shift

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_dim

        $DESCRIPTION  This procedure shifts a block image of a wanted number
                      (floating) of pixels in the columns direction

        $WARNING      NONE

        $PDL          - Checks the number of rows and columns of the block
                        image
                      - Initializes the usefull variables
                      - Allocates the wanted memories
                      - Loop over the number of rows
                            - Evaluates the phase of the multiplicator factor
                            - Fills the vector element with the multiplication
                              factor
                            - Fills the vector element complementar to the
                              current row
                      - End loop
                      - Fills the central element of the multiplication factors
                        vector if the total number of elements if odd
                      - Loop over the columns of the image block
                            - Evaluates the factor depending by the column shift
                            - Re-scales the phase array by the evaluate factor
                            - Zeroes the signal vector
                            - Fills the signal vector with the image column
                            - Makes the FFT of the signal
                            - Multiplicates the signal FFT with the phase
                              vector
                            - Makes the inverse FFT of the signal FFT
                            - Fills the image column with the new values
                      - End loop
                      - Clears all the memories of the FFT evaluation
                      - Frees the allocated memories

   $EH
   ========================================================================== */

void MATHIP_INTR_ImageColShift
                        (/*IN    */ UINTx4              NRowInp,
                         /*IN    */ UINTx4              NColInp,
                         /*IN    */ float              *shift,
                         /*IN    */ LDEFIT_data_type    DataType,
                         /*IN OUT*/ void              **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_ImageColShift";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;
   INTx4                  col;
   INTx4                  dr = 0;
   INTx4                  h;
   INTx1                  flag;
   float                  nu;
   MATHIT_array           ph;
   MATHIT_array           tmp;
   MATHIT_array           phase;
   MATHIT_array           sign_s;
   MATHIT_array           sign_f;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the image sizes
   ========================================================================== */
   if ( ( NRowInp < 1 ) || ( NColInp < 1 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_null_dim, "" );
   }

/* ==========================================================================
   Evaluate the utility variables for the row shift
   ========================================================================== */
   h = (INTx4)(NRowInp / 2);
   nu = - (double)(2 * PI / (float)NRowInp);
   dr = NRowInp % 2;

/* ==========================================================================
   Allocated the necessary vectors
   ========================================================================== */
   MATHIP_VECT_Make ( NRowInp, MATHIE_complex, &phase, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   MATHIP_VECT_Make ( NRowInp, MATHIE_complex, &sign_s, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   MATHIP_VECT_Make ( NRowInp, MATHIE_complex, &sign_f, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   MATHIP_VECT_Make ( NRowInp, MATHIE_float, &ph, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   MATHIP_VECT_Make ( NRowInp, MATHIE_float, &tmp, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the phase vector
   ========================================================================== */
   for ( row=0; row<h; row++ ) {
      ((float *)tmp.ap)[ row ] = (float)(row) *  nu;
      ((float *)tmp.ap)[ row + h ] = (float)(row - h - dr) * nu;
#ifdef __TRACE__
   fprintf ( stdout, "\n tmp[%d] = %f", row, ((float *)tmp.ap)[ row ] );
   fprintf ( stdout, "\n tmp[%d] = %f", row + h, ((float *)tmp.ap)[ row + h] );
#endif
   }

/* ==========================================================================
   Fill the central element
   ========================================================================== */
   if ( dr ) {
      ((float *)tmp.ap)[ 2 * h ] = - 1. * nu;
#ifdef __TRACE__
   fprintf ( stdout, "\n tmp[%d] = %f", 2 * h, ((float *)tmp.ap)[ 2 * h ] );
#endif
   }

/* ==========================================================================
   Shift the image block
   ========================================================================== */
   for ( col=0; col<NColInp; col++ ) {

/* ==========================================================================
   Re-scale the phase vector
   ========================================================================== */
      MATHIP_VECT_ConstMult ( shift[ col ], tmp, &ph, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
#ifdef __TRACE__
   for ( row=0; row<NRowInp; row++ ) {
      fprintf ( stdout, "\n phase[%d] = %f", row,
                (((float *)ph.ap)[ row ]) );
   }
#endif

/* ==========================================================================
   Evaluate the array with the phase values
   ========================================================================== */
      MATHIP_VECT_Exp ( ph, &phase, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
#ifdef __TRACE__
   for ( row=0; row<NRowInp; row++ ) {
      fprintf ( stdout, "\n phase[%d] = (    %f,    %f)", row,
                (((MATHIT_complex *)phase.ap)[ row ]).rea,
                (((MATHIT_complex *)phase.ap)[ row ]).ima );
   }
#endif

/* ==========================================================================
   Zero the input array
   ========================================================================== */
      memset ( sign_s.ap, '\0', (size_t)(NRowInp * sizeof (MATHIT_complex)) );

/* ==========================================================================
   Fill the array with the elements of the line
   ========================================================================== */
      MATHPP_INTR_FillColArray ( InpIma, col, NRowInp, DataType, &sign_s,
                                 status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Make the FFT of the line
   ========================================================================== */
      flag = 0;
      MATHIP_DFFT_1D ( sign_s, NRowInp, flag, &sign_s, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Multiply the FFT array by the complex factor
   ========================================================================== */
      MATHIP_VECT_Prod ( sign_s, phase, &sign_f, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Make the inverse FFT of the signal
   ========================================================================== */
      flag = 1;
      MATHIP_DFFT_1D ( sign_f, NRowInp, flag, &sign_f, status_code );
      ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Fill the input image row
   ========================================================================== */
      MATHPP_INTR_FillImaCol ( sign_f, col, NRowInp, DataType, InpIma,
                               status_code );
      ERRSIM_on_err_goto_exit ( *status_code );
   }

error_exit:;

/* ==========================================================================
   Clean up all the FFT memories
   ========================================================================== */
   flag = -1;
   MATHIP_DFFT_1D ( sign_f, NRowInp, flag, &sign_f, &log_status_code );
   ERRSIM_on_err_goto_exit ( log_status_code );

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MATHIP_VECT_Free ( &phase, status_code );
   MATHIP_VECT_Free ( &sign_s, status_code );
   MATHIP_VECT_Free ( &sign_f, status_code );
   MATHIP_VECT_Free ( &tmp, status_code );
   MATHIP_VECT_Free ( &ph, status_code );

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* MATHIP_INTR_ImageColShift */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_BLUINTx1

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input matrix
                      NRowInp  : number of rows of the input matrix
                      NColInp  : number of columns of the input matrix
                      OutPoint : 2D array with the row, col coordinates of the
                                 the points in which to interpolate
                      NRowOut  : number of rows of the output matrix
                      NColOut  : number of columns of the output matrix
                      InvVal   : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma   : matrix with the values of the input matrix
                                 into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
                      matrix of UINTx1 type on the points coordinates given by
                      an array of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the number of output rows' coordinates
                            - Loop over the number of output columns'
                              coordinates
                                  - Evaluate the image coordinates of the image
                                    point on the top left of the square
                                    surrounding the wanted point
                                  - If it is in the image or not
                                        - Evaluate the value of the point with
                                          coordinates equals to the top square
                                          row at the wanted fractionary column
                                          with a linear interpolation
                                        - Evaluate the value of the point with
                                          coordinates equals to the bottom
                                          square row at the wanted fractionary
                                          column with a linear interpolation
                                        - Evaluated the output value with a
                                          linear interpolation between the two
                                          interpolated points at the fractionary
                                          row
                                  - End if
                                  - Else
                                        - Put the invalid value as output
                                          interpolated value
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_BLUINTx1
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_BLUINTx1";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  TLr;         /* Coordinates of the image points     */
   INTx4                  TLc;         /* surronding the point to interpolate */
   UINTx4                 rc;                                /* rows' counter */
   UINTx4                 cc;                             /* columns' counter */
   double                 Top;
   double                 Bottom;
   double                 delta;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Rows' loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns' loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Evaluate the top left coordinates
   ========================================================================== */
         TLr = (INTx4)(OutPoint[ rc ][ cc ].row);
         TLc = (INTx4)(OutPoint[ rc ][ cc ].col);

/* ==========================================================================
   Check the inner coordinates
   ========================================================================== */
         if ( ( ( TLr >= 0 ) && ( TLr <= NRowInp - 2 ) ) &&
              ( ( TLc >= 0 ) && ( TLc <= NColInp - 2 ) ) ) {

/* ==========================================================================
   Linear interpolation of the value corresponding to the point on the
   top row
   ========================================================================== */
            delta = (double)( ((UINTx1 **)InpIma)[ TLr ][ TLc + 1 ] -
               ((UINTx1 **)InpIma)[ TLr ][ TLc ] );

            Top = (double)((UINTx1 **)InpIma)[ TLr ][ TLc ] +
               delta * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );

/* ==========================================================================
   Interpolate the bottom row value ... see comments above
   ========================================================================== */
            delta = (double)( ((UINTx1 **)InpIma)[ TLr + 1 ][ TLc + 1 ] -
               ((UINTx1 **)InpIma)[ TLr + 1 ][ TLc  ] );
            Bottom = (double)((UINTx1 **)InpIma)[ TLr + 1 ][ TLc ] +
               delta * ( OutPoint[ rc ][ cc ].col - (double)TLc );

/* ==========================================================================
   Interpolate the actual value
   ========================================================================== */
            delta = Bottom - Top;
            ((float **)OutIma)[ rc ][ cc ] = (float)
               (Top + delta *
               ( (double)OutPoint[ rc ][ cc ].row - (double)TLr ));
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = InvVal;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_BLUINTx1 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_BLUINTx2

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input matrix
                      NRowInp  : number of rows of the input matrix
                      NColInp  : number of columns of the input matrix
                      OutPoint : 2D array with the row, col coordinates of the
                                 the points in which to interpolate
                      NRowOut  : number of rows of the output matrix
                      NColOut  : number of columns of the output matrix
                      InvVal   : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma   : matrix with the values of the input matrix
                                 into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
                      matrix of UINTx2 type on the points coordinates given by
                      an array of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the number of output rows' coordinates
                            - Loop over the number of output columns'
                              coordinates
                                  - Evaluate the image coordinates of the image
                                    point on the top left of the square
                                    surrounding the wanted point
                                  - If it is in the image or not
                                        - Evaluate the value of the point with
                                          coordinates equals to the top square
                                          row at the wanted fractionary column
                                          with a linear interpolation
                                        - Evaluate the value of the point with
                                          coordinates equals to the bottom
                                          square row at the wanted fractionary
                                          column with a linear interpolation
                                        - Evaluated the output value with a
                                          linear interpolation between the two
                                          interpolated points at the fractionary
                                          row
                                  - End if
                                  - Else
                                        - Put the invalid value as output
                                          interpolated value
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_BLUINTx2
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_BLUINTx2";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  TLr;         /* Coordinates of the image points     */
   INTx4                  TLc;         /* surronding the point to interpolate */
   UINTx4                 rc;                                /* rows' counter */
   UINTx4                 cc;                             /* columns' counter */
   double                 Top;
   double                 Bottom;
   double                 delta;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Rows' loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns' loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Evaluate the top left coordinates
   ========================================================================== */
         TLr = (INTx4)(OutPoint[ rc ][ cc ].row);
         TLc = (INTx4)(OutPoint[ rc ][ cc ].col);

/* ==========================================================================
   Check the inner coordinates
   ========================================================================== */
         if ( ( ( TLr >= 0 ) && ( TLr <= NRowInp - 2 ) ) &&
              ( ( TLc >= 0 ) && ( TLc <= NColInp - 2 ) ) ) {

/* ==========================================================================
   Linear interpolation of the value corresponding to the point on the
   top row
   ========================================================================== */
            delta = (double)( ((UINTx2 **)InpIma)[ TLr ][ TLc + 1 ] -
               ((UINTx2 **)InpIma)[ TLr ][ TLc ] );

            Top = (double)((UINTx2 **)InpIma)[ TLr ][ TLc ] +
               delta * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );

/* ==========================================================================
   Interpolate the bottom row value ... see comments above
   ========================================================================== */
            delta = (double)( ((UINTx2 **)InpIma)[ TLr + 1 ][ TLc + 1 ] -
               ((UINTx2 **)InpIma)[ TLr + 1 ][ TLc  ] );
            Bottom = (double)((UINTx2 **)InpIma)[ TLr + 1 ][ TLc ] +
               delta * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );

/* ==========================================================================
   Interpolate the actual value
   ========================================================================== */
            delta = Bottom - Top;
            ((float **)OutIma)[ rc ][ cc ] = (float)
               (Top + delta *
               ( (double)OutPoint[ rc ][ cc ].row - (double)TLr ));
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = InvVal;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_BLUINTx2 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_BLfloat

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input matrix
                      NRowInp  : number of rows of the input matrix
                      NColInp  : number of columns of the input matrix
                      OutPoint : 2D array with the row, col coordinates of the
                                 the points in which to interpolate
                      NRowOut  : number of rows of the output matrix
                      NColOut  : number of columns of the output matrix
                      InvVal   : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma   : matrix with the values of the input matrix
                                 into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
                      matrix of float type on the points coordinates given by
                      an array of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the number of output rows' coordinates
                            - Loop over the number of output columns'
                              coordinates
                                  - Evaluate the image coordinates of the image
                                    point on the top left of the square
                                    surrounding the wanted point
                                  - If it is in the image or not
                                        - Evaluate the value of the point with
                                          coordinates equals to the top square
                                          row at the wanted fractionary column
                                          with a linear interpolation
                                        - Evaluate the value of the point with
                                          coordinates equals to the bottom
                                          square row at the wanted fractionary
                                          column with a linear interpolation
                                        - Evaluated the output value with a
                                          linear interpolation between the two
                                          interpolated points at the fractionary
                                          row
                                  - End if
                                  - Else
                                        - Put the invalid value as output
                                          interpolated value
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_BLfloat
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_BLfloat";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  TLr;         /* Coordinates of the image points     */
   INTx4                  TLc;         /* surronding the point to interpolate */
   UINTx4                 rc;                                /* rows' counter */
   UINTx4                 cc;                             /* columns' counter */
   double                 Top;
   double                 Bottom;
   double                 delta;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, &process_flag, &log_status_code );

/* ==========================================================================
   Rows' loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns' loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Evaluate the top left coordinates
   ========================================================================== */
         TLr = (INTx4)(OutPoint[ rc ][ cc ].row);
         TLc = (INTx4)(OutPoint[ rc ][ cc ].col);

/* ==========================================================================
   Check the inner coordinates
   ========================================================================== */
         if ( ( ( TLr >= 0 ) && ( TLr <= NRowInp - 2 ) ) &&
              ( ( TLc >= 0 ) && ( TLc <= NColInp - 2 ) ) ) {

/* ==========================================================================
   Linear interpolation of the value corresponding to the point on the
   top row
   ========================================================================== */
            delta = (double)( ((float **)InpIma)[ TLr ][ TLc + 1 ] -
               ((float **)InpIma)[ TLr ][ TLc ] );

            Top = (double)((float **)InpIma)[ TLr ][ TLc ] +
               delta * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );

/* ==========================================================================
   Interpolate the bottom row value ... see comments above
   ========================================================================== */
            delta = (double)( ((float **)InpIma)[ TLr + 1 ][ TLc + 1 ] -
               ((float **)InpIma)[ TLr + 1 ][ TLc  ] );
            Bottom = (double)((float **)InpIma)[ TLr + 1 ][ TLc ] +
               delta * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );

/* ==========================================================================
   Interpolate the actual value
   ========================================================================== */
            delta = Bottom - Top;
            ((float **)OutIma)[ rc ][ cc ] = (float)
               (Top + delta *
               ( (double)OutPoint[ rc ][ cc ].row - (double)TLr ));
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = InvVal;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_BLfloat */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_BL2INTx2

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input matrix
                      NRowInp  : number of rows of the input matrix
                      NColInp  : number of columns of the input matrix
                      OutPoint : 2D array with the row, col coordinates of the
                                 the points in which to interpolate
                      NRowOut  : number of rows of the output matrix
                      NColOut  : number of columns of the output matrix
                      InvVal   : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma   : matrix with the values of the input matrix
                                 into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
                      matrix of 2INTx2 type on the points coordinates given by
                      an array of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the number of output rows' coordinates
                            - Loop over the number of output columns'
                              coordinates
                                  - Evaluate the image coordinates of the image
                                    point on the top left of the square
                                    surrounding the wanted point
                                  - If it is in the image or not
                                        - Evaluate the value of the point with
                                          coordinates equals to the top square
                                          row at the wanted fractionary column
                                          with a linear interpolation
                                        - Evaluate the value of the point with
                                          coordinates equals to the bottom
                                          square row at the wanted fractionary
                                          column with a linear interpolation
                                        - Evaluated the output value with a
                                          linear interpolation between the two
                                          interpolated points at the fractionary
                                          row
                                  - End if
                                  - Else
                                        - Put the invalid value as output
                                          interpolated value
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_BL2INTx2
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_BL2INTx2";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  TLr;         /* Coordinates of the image points     */
   INTx4                  TLc;         /* surronding the point to interpolate */
   UINTx4                 rc;                                /* rows' counter */
   UINTx4                 cc;                             /* columns' counter */
   MATHIT_dcomplex        Top;
   MATHIT_dcomplex        Bottom;
   MATHIT_dcomplex        delta;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Rows' loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns' loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Evaluate the top left coordinates
   ========================================================================== */
         TLr = (INTx4)(OutPoint[ rc ][ cc ].row);
         TLc = (INTx4)(OutPoint[ rc ][ cc ].col);

/* ==========================================================================
   Check the inner coordinates
   ========================================================================== */
         if ( ( ( TLr >= 0 ) && ( TLr <= NRowInp - 2 ) ) &&
              ( ( TLc >= 0 ) && ( TLc <= NColInp - 2 ) ) ) {

/* ==========================================================================
   Linear interpolation of the value corresponding to the point on the
   top row
   ========================================================================== */
	    delta.rea = (double)
               ( ((INTx2 **)InpIma)[ TLr ][ 2 * ( TLc + 1 ) ] -
                 ((INTx2 **)InpIma)[ TLr ][ 2 * TLc ] );
            delta.ima = (double)
               ( ((INTx2 **)InpIma)[ TLr ][ 2 * ( TLc + 1 ) + 1 ] -
                 ((INTx2 **)InpIma)[ TLr ][ 2 * TLc ] );

            Top.rea = (double)((INTx2 **)InpIma)[ TLr ][ 2 * TLc ] +
               delta.rea * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );
            Top.ima = (double)((INTx2 **)InpIma)[ TLr ][ 2 * TLc + 1 ] +
               delta.ima * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );

/* ==========================================================================
   Interpolate the bottom row value ... see comments above
   ========================================================================== */
            delta.rea = (double)
               ( ((INTx2 **)InpIma)[ TLr + 1 ][ 2 * ( TLc + 1 ) ] -
                 ((INTx2 **)InpIma)[ TLr + 1 ][ 2 * TLc ] );
            delta.ima = (double)
               ( ((INTx2 **)InpIma)[ TLr + 1 ][ 2 * ( TLc + 1 ) + 1 ] -
                 ((INTx2 **)InpIma)[ TLr + 1 ][ 2 * TLc + 1 ] );
            Bottom.rea = (double)
               ((INTx2 **)InpIma)[ TLr + 1 ][ 2 * TLc ] +
               delta.rea * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );
            Bottom.ima = (double)
               ((INTx2 **)InpIma)[ TLr + 1 ][ 2 * TLc + 1 ] +
               delta.ima * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );

/* ==========================================================================
   Interpolate the actual value
   ========================================================================== */
            delta.rea = Bottom.rea - Top.rea;
            delta.ima = Bottom.ima - Top.ima;
            ((float **)OutIma)[ rc ][ 2 * cc ] = (float)
               (Top.rea + delta.rea *
                  ( (double)OutPoint[ rc ][ cc ].row - (double)TLr ));
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = (float)
               (Top.ima + delta.ima *
                  ( (double)OutPoint[ rc ][ cc ].row - (double)TLr ));
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ 2 * cc ] = InvVal;
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = InvVal;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_BL2INTx2 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_BL2float

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input matrix
                      NRowInp  : number of rows of the input matrix
                      NColInp  : number of columns of the input matrix
                      OutPoint : 2D array with the row, col coordinates of the
                                 the points in which to interpolate
                      NRowOut  : number of rows of the output matrix
                      NColOut  : number of columns of the output matrix
                      InvVal   : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma   : matrix with the values of the input matrix
                                 into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
                      matrix of 2float type on the points coordinates given by
                      an array of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the number of output rows' coordinates
                            - Loop over the number of output columns'
                              coordinates
                                  - Evaluate the image coordinates of the image
                                    point on the top left of the square
                                    surrounding the wanted point
                                  - If it is in the image or not
                                        - Evaluate the value of the point with
                                          coordinates equals to the top square
                                          row at the wanted fractionary column
                                          with a linear interpolation
                                        - Evaluate the value of the point with
                                          coordinates equals to the bottom
                                          square row at the wanted fractionary
                                          column with a linear interpolation
                                        - Evaluated the output value with a
                                          linear interpolation between the two
                                          interpolated points at the fractionary
                                          row
                                  - End if
                                  - Else
                                        - Put the invalid value as output
                                          interpolated value
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_BL2float
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_BL2float";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  TLr;         /* Coordinates of the image points     */
   INTx4                  TLc;         /* surronding the point to interpolate */
   UINTx4                 rc;                                /* rows' counter */
   UINTx4                 cc;                             /* columns' counter */
   MATHIT_dcomplex        Top;
   MATHIT_dcomplex        Bottom;
   MATHIT_dcomplex        delta;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Rows' loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns' loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Evaluate the top left coordinates
   ========================================================================== */
         TLr = (INTx4)(OutPoint[ rc ][ cc ].row);
         TLc = (INTx4)(OutPoint[ rc ][ cc ].col);

/* ==========================================================================
   Check the inner coordinates
   ========================================================================== */
         if ( ( ( TLr >= 0 ) && ( TLr <= NRowInp - 2 ) ) &&
              ( ( TLc >= 0 ) && ( TLc <= NColInp - 2 ) ) ) {

/* ==========================================================================
   Linear interpolation of the value corresponding to the point on the
   top row
   ========================================================================== */
	    delta.rea = (double)
               ( ((float **)InpIma)[ TLr ][ 2 * ( TLc + 1 ) ] -
                 ((float **)InpIma)[ TLr ][ 2 * TLc ] );
            delta.ima = (double)
               ( ((float **)InpIma)[ TLr ][ 2 * ( TLc + 1 ) + 1 ] -
                 ((float **)InpIma)[ TLr ][ 2 * TLc ] );

            Top.rea = (double)((float **)InpIma)[ TLr ][ 2 * TLc ] +
               delta.rea * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );
            Top.ima = (double)((float **)InpIma)[ TLr ][ 2 * TLc + 1 ] +
               delta.ima * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );

/* ==========================================================================
   Interpolate the bottom row value ... see comments above
   ========================================================================== */
            delta.rea = (double)
               ( ((float **)InpIma)[ TLr + 1 ][ 2 * ( TLc + 1 ) ] -
                 ((float **)InpIma)[ TLr + 1 ][ 2 * TLc ] );
            delta.ima = (double)
               ( ((float **)InpIma)[ TLr + 1 ][ 2 * ( TLc + 1 ) + 1 ] -
                 ((float **)InpIma)[ TLr + 1 ][ 2 * TLc + 1 ] );
            Bottom.rea = (double)
               ((float **)InpIma)[ TLr + 1 ][ 2 * TLc ] +
               delta.rea * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );
            Bottom.ima = (double)
               ((float **)InpIma)[ TLr + 1 ][ 2 * TLc + 1 ] +
               delta.ima * ( (double)OutPoint[ rc ][ cc ].col - (double)TLc );

/* ==========================================================================
   Interpolate the actual value
   ========================================================================== */
            delta.rea = Bottom.rea - Top.rea;
            delta.ima = Bottom.ima - Top.ima;
            ((float **)OutIma)[ rc ][ 2 * cc ] = (float)
               (Top.rea + delta.rea *
               ( (double)OutPoint[ rc ][ cc ].row - (double)TLr ));
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = (float)
               (Top.ima + delta.ima *
               ( (double)OutPoint[ rc ][ cc ].row - (double)TLr ));
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ 2 * cc ] = InvVal;
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = InvVal;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_BL2float */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPF_INTR_CubiConvKernel

        $TYPE         FUNCTION

        $INPUT        x : the independent variable value 

        $MODIFIED     NONE

        $OUTPUT       y : the function value evaluated in <x>

        $GLOBAL       MATHIV_cubi_conv_coeff : coefficient of the cubic
                                               convolution kernel function

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the value of the cubic
                      convolution kernel at the given value of shift from
                      the integer point coordinate

        $WARNING      NONE

        $PDL          - Switches between the various distances ranges
                            - assignes the kernel function value
                      - End switch

   $EH
   ========================================================================== */

float MATHPF_INTR_CubiConvKernel
                        (/*IN    */ float                x,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPF_INTR_CubiConvKernel";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   float                  ax;
   float                  val = 0.;      /* default value */

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   The function is simmetric
   ========================================================================== */
   ax = ABS ( x );

/* ==========================================================================
   Distance lesser than one
   ========================================================================== */
   if ( ( ax >= 0. ) && ( ax <= 1. ) ) {
      val = ( MATHIV_cubi_conv_coeff + 2. ) * POW ( ax, 3. ) -
            ( MATHIV_cubi_conv_coeff + 3. ) * POW ( ax, 2. ) + 1.;
   }

/* ==========================================================================
   Distance between 1 and 2
   ========================================================================== */
   if ( ( ax > 1. ) && ( ax <= 2. ) ) {
      val = MATHIV_cubi_conv_coeff * POW ( ax, 3 ) -
         5. * MATHIV_cubi_conv_coeff * POW ( ax, 2. ) +
         8. * MATHIV_cubi_conv_coeff * ax -
         4. * MATHIV_cubi_conv_coeff;
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return ( val );

}/* MATHPF_INTR_CubiConvKernel */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_CCUINTx1

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHIV_CCTableLength : inverse of the precision required
                                             for the cubic convolution
                      MATHPV_CubiConvTable : the table with the values for the
                                             cubic convolution

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates for images of UINTx1 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the left integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the tables
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_CCUINTx1
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_CCUINTx1";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 rc;
   UINTx4                 cc;
   UINTx4                 row;
   UINTx4                 col;
   UINTx4                 Nr;
   UINTx4                 Nc;
   float                  delta;
   float                  rowval[ MATHID_cubi_conv_elem ];
   UINTx4                 index;
   INTx4                  h;
   REGISTER float        *KernR = (float *)NULL;
   REGISTER float        *KernC = (float *)NULL;
   REGISTER UINTx1       *p = (UINTx1 *)NULL;
   REGISTER float         OutVal;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the table are initialized
   ========================================================================== */
   if ( MATHPV_CubiConvTable == (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_table_not_allocated, "" );
   }

/* ==========================================================================
   Utility variable evaluation
   ========================================================================== */
   h = MATHID_cubi_conv_elem / 2;

/* ==========================================================================
   Rows loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Check that the point is internal
   ========================================================================== */
         if ( ( ( OutPoint[ rc ][ cc ].row >= (float)h ) &&
                ( OutPoint[ rc ][ cc ].row <= (float)(NRowInp - h - 1) ) ) &&
              ( ( OutPoint[ rc ][ cc ].col >= (float)h ) &&
                ( OutPoint[ rc ][ cc ].col <= (float)(NColInp - h - 1) ) ) ) {

/* ==========================================================================
   Evaluate the left integer coordinate
   ========================================================================== */
            Nr = (UINTx4)OutPoint[ rc ][ cc ].row;

/* ==========================================================================
   Evaluate the delta of the coordinate WRT the lefmost one
   ========================================================================== */
            delta = (OutPoint[ rc ][ cc ].row - (float)Nr);

/* ==========================================================================
   Evaluate the index in the table
   ========================================================================== */
            index = (UINTx4)(delta * (float)MATHIV_CCTableLength + 0.5);

/* ==========================================================================
   Point to the necessary row
   ========================================================================== */
            KernC = &(MATHPV_CubiConvTable[ index ]
                        [ MATHID_cubi_conv_elem - 1 ]) + 1;

/* ==========================================================================
   Retrive the columns index ... see comment above
   ========================================================================== */
            Nc = (UINTx4)OutPoint[ rc ][ cc ].col;
            delta = (OutPoint[ rc ][ cc ].col - (float)Nc);
            index = (UINTx4)(delta * (float)MATHIV_CCTableLength + 0.5);

/* ==========================================================================
   Initialize the sum variable
   ========================================================================== */
            memset ( (void *)rowval, 0,
                     (size_t)(MATHID_cubi_conv_elem * sizeof ( float )) );

/* ==========================================================================
   Make four convolutions in the rows direction
   ========================================================================== */
            for ( row=Nr-1; row<=Nr+2; row++ ) {

/* ==========================================================================
   Point the kernel
   ========================================================================== */
               KernR = &(MATHPV_CubiConvTable[ index ]
                           [ MATHID_cubi_conv_elem - 1 ]) + 1;

/* ==========================================================================
   Point to the beginning of the matrices rows
   ========================================================================== */
               p = &(((UINTx1 **)InpIma)[ row ][ Nc - 1 ]) - 1;
                     
/* ==========================================================================
   Convolution loop
   ========================================================================== */
               for ( col=0; col<MATHID_cubi_conv_elem; col++ ) {
                  rowval[ row - Nr + 1 ] += *--KernR * (float)*++p;
               }
            }

/* ==========================================================================
   Columns interpolation ... see comments above
   ========================================================================== */
            OutVal = 0.;
            for ( col=0; col<MATHID_cubi_conv_elem; col++ ) {
               OutVal += *--KernC * rowval[ col ];
            }

/* ==========================================================================
   Output fill
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = OutVal;
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = InvVal;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_CCUINTx1 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_CCUINTx2

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHIV_CCTableLength : inverse of the precision required
                                             for the cubic convolution
                      MATHPV_CubiConvTable : the table with the values for the
                                             cubic convolution

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates for images of UINTx2 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the left integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the tables
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_CCUINTx2
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_CCUINTx2";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 rc;
   UINTx4                 cc;
   UINTx4                 row;
   UINTx4                 col;
   UINTx4                 Nr;
   UINTx4                 Nc;
   float                  delta;
   float                  rowval[ MATHID_cubi_conv_elem ];
   UINTx4                 index;
   INTx4                  h;
   REGISTER float        *KernR = (float *)NULL;
   REGISTER float        *KernC = (float *)NULL;
   REGISTER UINTx2       *p = (UINTx2 *)NULL;
   REGISTER float         OutVal;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the table are initialized
   ========================================================================== */
   if ( MATHPV_CubiConvTable == (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_table_not_allocated, "" );
   }

/* ==========================================================================
   Utility variable evaluation
   ========================================================================== */
   h = MATHID_cubi_conv_elem / 2;

/* ==========================================================================
   Rows loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Check that the point is internal
   ========================================================================== */
         if ( ( ( OutPoint[ rc ][ cc ].row >= (float)h ) &&
                ( OutPoint[ rc ][ cc ].row <= (float)(NRowInp - h - 1) ) ) &&
              ( ( OutPoint[ rc ][ cc ].col >= (float)h ) &&
                ( OutPoint[ rc ][ cc ].col <= (float)(NColInp - h - 1) ) ) ) {

/* ==========================================================================
   Evaluate the left integer coordinate
   ========================================================================== */
            Nr = (UINTx4)OutPoint[ rc ][ cc ].row;

/* ==========================================================================
   Evaluate the delta of the coordinate WRT the lefmost one
   ========================================================================== */
            delta = (OutPoint[ rc ][ cc ].row - (float)Nr);

/* ==========================================================================
   Evaluate the index in the table
   ========================================================================== */
            index = (UINTx4)(delta * (float)MATHIV_CCTableLength + 0.5);

/* ==========================================================================
   Point to the necessary row
   ========================================================================== */
            KernC = &(MATHPV_CubiConvTable[ index ]
                        [ MATHID_cubi_conv_elem - 1 ]) + 1;

/* ==========================================================================
   Retrive the columns index ... see comment above
   ========================================================================== */
            Nc = (UINTx4)OutPoint[ rc ][ cc ].col;
            delta = (OutPoint[ rc ][ cc ].col - (float)Nc);
            index = (UINTx4)(delta * (float)MATHIV_CCTableLength + 0.5);

/* ==========================================================================
   Initialize the sum variable
   ========================================================================== */
            memset ( (void *)rowval, 0,
                     (size_t)(MATHID_cubi_conv_elem * sizeof ( float )) );

/* ==========================================================================
   Make four convolutions in the rows direction
   ========================================================================== */
            for ( row=Nr-1; row<=Nr+2; row++ ) {

/* ==========================================================================
   Point the kernel
   ========================================================================== */
               KernR = &(MATHPV_CubiConvTable[ index ]
                           [ MATHID_cubi_conv_elem - 1 ]) + 1;
/* ==========================================================================
   Point to the beginning of the matrices rows
   ========================================================================== */
               p = &(((UINTx2 **)InpIma)[ row ][ Nc - 1 ]) - 1;
                     
/* ==========================================================================
   Convolution loop
   ========================================================================== */
               for ( col=0; col<MATHID_cubi_conv_elem; col++ ) {
                  rowval[ row - Nr + 1 ] += *--KernR * (float)*++p;
               }
            }

/* ==========================================================================
   Columns interpolation ... see comments above
   ========================================================================== */
            OutVal = 0.;
            for ( col=0; col<MATHID_cubi_conv_elem; col++ ) {
               OutVal += (double)*--KernC * rowval[ col ];
            }

/* ==========================================================================
   Output fill
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = OutVal;
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = InvVal;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_CCUINTx2 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_CCfloat

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHIV_CCTableLength : inverse of the precision required
                                             for the cubic convolution
                      MATHPV_CubiConvTable : the table with the values for the
                                             cubic convolution

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates for images of float type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the left integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the tables
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_CCfloat
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_CCfloat";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 rc;
   UINTx4                 cc;
   UINTx4                 row;
   UINTx4                 col;
   UINTx4                 Nr;
   UINTx4                 Nc;
   float                  delta;
   float                  rowval[ MATHID_cubi_conv_elem ];
   UINTx4                 index;
   INTx4                  h;
   REGISTER float        *KernR = (float *)NULL;
   REGISTER float        *KernC = (float *)NULL;
   REGISTER float        *p = (float *)NULL;
   REGISTER float         OutVal;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the table are initialized
   ========================================================================== */
   if ( MATHPV_CubiConvTable == (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_table_not_allocated, "" );
   }

/* ==========================================================================
   Utility variable evaluation
   ========================================================================== */
   h = MATHID_cubi_conv_elem / 2;

/* ==========================================================================
   Rows loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Check that the point is internal
   ========================================================================== */
         if ( ( ( OutPoint[ rc ][ cc ].row >= (float)h ) &&
                ( OutPoint[ rc ][ cc ].row <= (float)(NRowInp - h - 1) ) ) &&
              ( ( OutPoint[ rc ][ cc ].col >= (float)h ) &&
                ( OutPoint[ rc ][ cc ].col <= (float)(NColInp - h - 1) ) ) ) {

/* ==========================================================================
   Evaluate the left integer coordinate
   ========================================================================== */
            Nr = (UINTx4)OutPoint[ rc ][ cc ].row;

/* ==========================================================================
   Evaluate the delta of the coordinate WRT the lefmost one
   ========================================================================== */
            delta = (OutPoint[ rc ][ cc ].row - (float)Nr);

/* ==========================================================================
   Evaluate the index in the table
   ========================================================================== */
            index = (UINTx4)(delta * (float)MATHIV_CCTableLength + 0.5);

/* ==========================================================================
   Point to the necessary row
   ========================================================================== */
            KernC = &(MATHPV_CubiConvTable[ index ]
                        [ MATHID_cubi_conv_elem - 1 ]) + 1;

/* ==========================================================================
   Retrive the columns index ... see comment above
   ========================================================================== */
            Nc = (UINTx4)OutPoint[ rc ][ cc ].col;
            delta = (OutPoint[ rc ][ cc ].col - (float)Nc);
            index = (UINTx4)(delta * (float)MATHIV_CCTableLength + 0.5);

/* ==========================================================================
   Initialize the sum variable
   ========================================================================== */
            memset ( (void *)rowval, 0,
                     (size_t)(MATHID_cubi_conv_elem * sizeof ( float )) );

/* ==========================================================================
   Make four convolutions in the rows direction
   ========================================================================== */
            for ( row=Nr-1; row<=Nr+2; row++ ) {

/* ==========================================================================
   Point the kernel
   ========================================================================== */
               KernR = &(MATHPV_CubiConvTable[ index ]
                           [ MATHID_cubi_conv_elem - 1 ]) + 1;

/* ==========================================================================
   Point to the beginning of the matrices rows
   ========================================================================== */
               p = &(((float **)InpIma)[ row ][ Nc - 1 ]) - 1;
                     
/* ==========================================================================
   Convolution loop
   ========================================================================== */
               for ( col=0; col<MATHID_cubi_conv_elem; col++ ) {
                  rowval[ row - Nr + 1 ] += *--KernR * (float)*++p;
               }
            }

/* ==========================================================================
   Columns interpolation ... see comments above
   ========================================================================== */
            OutVal = 0.;
            for ( col=0; col<MATHID_cubi_conv_elem; col++ ) {
               OutVal += *--KernC * rowval[ col ];
            }

/* ==========================================================================
   Output fill
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = OutVal;
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = InvVal;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_CCfloat */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_CC2INTx2

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHIV_CCTableLength : inverse of the precision required
                                             for the cubic convolution
                      MATHPV_CubiConvTable : the table with the values for the
                                             cubic convolution

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates for images of 2INTx2 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the left integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the tables
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_CC2INTx2
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_CC2INTx2";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                   rc;
   UINTx4                   cc;
   UINTx4                   row;
   UINTx4                   col;
   UINTx4                   Nr;
   UINTx4                   Nc;
   float                    delta;
   MATHIT_complex           rowval[ MATHID_cubi_conv_elem ];
   UINTx4                   index;
   INTx4                    h;
   REGISTER float          *KernR = (float *)NULL;
   REGISTER float          *KernC = (float *)NULL;
   REGISTER INTx2          *pr = (INTx2 *)NULL;
   REGISTER INTx2          *pi = (INTx2 *)NULL;
   REGISTER MATHIT_complex  OutVal;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the table are initialized
   ========================================================================== */
   if ( MATHPV_CubiConvTable == (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_table_not_allocated, "" );
   }

/* ==========================================================================
   Utility variable evaluation
   ========================================================================== */
   h = MATHID_cubi_conv_elem / 2;

/* ==========================================================================
   Rows loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Check that the point is internal
   ========================================================================== */
         if ( ( ( OutPoint[ rc ][ cc ].row >= (float)h ) &&
                ( OutPoint[ rc ][ cc ].row <= (float)(NRowInp - h - 1) ) ) &&
              ( ( OutPoint[ rc ][ cc ].col >= (float)h ) &&
                ( OutPoint[ rc ][ cc ].col <= (float)(NColInp - h - 1) ) ) ) {

/* ==========================================================================
   Evaluate the left integer coordinate
   ========================================================================== */
            Nr = (UINTx4)OutPoint[ rc ][ cc ].row;

/* ==========================================================================
   Evaluate the delta of the coordinate WRT the lefmost one
   ========================================================================== */
            delta = (OutPoint[ rc ][ cc ].row - (float)Nr);

/* ==========================================================================
   Evaluate the index in the table
   ========================================================================== */
            index = (UINTx4)(delta * (float)MATHIV_CCTableLength + 0.5);

/* ==========================================================================
   Point to the necessary row
   ========================================================================== */
            KernC = &(MATHPV_CubiConvTable[ index ]
                        [ MATHID_cubi_conv_elem - 1 ]) + 1;

/* ==========================================================================
   Retrive the columns index ... see comment above
   ========================================================================== */
            Nc = (UINTx4)OutPoint[ rc ][ cc ].col;
            delta = (OutPoint[ rc ][ cc ].col - (float)Nc);
            index = (UINTx4)(delta * (float)MATHIV_CCTableLength + 0.5);

/* ==========================================================================
   Initialize the sum variable
   ========================================================================== */
            memset ( (void *)rowval, 0,
                           (size_t)(MATHID_cubi_conv_elem *
                           sizeof ( MATHIT_complex )) );

/* ==========================================================================
   Make four convolutions in the rows direction
   ========================================================================== */
            for ( row=Nr-1; row<=Nr+2; row++ ) {

/* ==========================================================================
   Point the kernel
   ========================================================================== */
               KernR = &(MATHPV_CubiConvTable[ index ]
                           [ MATHID_cubi_conv_elem - 1 ]) + 1;

/* ==========================================================================
   Point to the beginning of the matrices rows
   ========================================================================== */
               pr = &(((INTx2 **)InpIma)[ row ][ 2 * ( Nc - 1 ) ]) - 2;
               pi = &(((INTx2 **)InpIma)[ row ][ 2 * ( Nc - 1 ) + 1 ]) - 2;

/* ==========================================================================
   Convolution loop
   ========================================================================== */
               for ( col=0; col<MATHID_cubi_conv_elem; col++ ) {
                  pr++;
                  pi++;
                  rowval[ row - Nr + 1 ].rea += *--KernR * (float)*++pr;
                  rowval[ row - Nr + 1 ].ima += *KernR * (float)*++pi;
               }
            }

/* ==========================================================================
   Columns interpolation ... see comments above
   ========================================================================== */
            OutVal.rea = 0.0;
            OutVal.ima = 0.0;
            for ( col=0; col<MATHID_cubi_conv_elem; col++ ) {
               OutVal.rea += *--KernC * rowval[ col ].rea;
               OutVal.ima += *KernC * rowval[ col ].ima;
            }

/* ==========================================================================
   Output fill
   ========================================================================== */
            ((float **)OutIma)[ rc ][ 2 * cc ] = OutVal.rea;
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = OutVal.ima;
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ 2 * cc ] = InvVal;
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = InvVal;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_CC2INTx2 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_CC2float

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHIV_CCTableLength : inverse of the precision required
                                             for the cubic convolution
                      MATHPV_CubiConvTable : the table with the values for the
                                             cubic convolution

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates for images of 2float type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the left integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the tables
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_CC2float
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_CC2float";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                   rc;
   UINTx4                   cc;
   UINTx4                   row;
   UINTx4                   col;
   UINTx4                   Nr;
   UINTx4                   Nc;
   float                    delta;
   MATHIT_complex           rowval[ MATHID_cubi_conv_elem ];
   UINTx4                   index;
   INTx4                    h;
   REGISTER float          *KernR = (float *)NULL;
   REGISTER float          *KernC = (float *)NULL;
   REGISTER float          *pr = (float *)NULL;
   REGISTER float          *pi = (float *)NULL;
   REGISTER MATHIT_complex  OutVal;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the table are initialized
   ========================================================================== */
   if ( MATHPV_CubiConvTable == (float **)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_table_not_allocated, "" );
   }

/* ==========================================================================
   Utility variable evaluation
   ========================================================================== */
   h = MATHID_cubi_conv_elem / 2;

/* ==========================================================================
   Rows loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Check that the point is internal
   ========================================================================== */
         if ( ( ( OutPoint[ rc ][ cc ].row >= (float)h ) &&
                ( OutPoint[ rc ][ cc ].row <= (float)(NRowInp - h - 1) ) ) &&
              ( ( OutPoint[ rc ][ cc ].col >= (float)h ) &&
                ( OutPoint[ rc ][ cc ].col <= (float)(NColInp - h - 1) ) ) ) {

/* ==========================================================================
   Evaluate the left integer coordinate
   ========================================================================== */
            Nr = (UINTx4)OutPoint[ rc ][ cc ].row;

/* ==========================================================================
   Evaluate the delta of the coordinate WRT the lefmost one
   ========================================================================== */
            delta = (OutPoint[ rc ][ cc ].row - (float)Nr);

/* ==========================================================================
   Evaluate the index in the table
   ========================================================================== */
            index = (UINTx4)(delta * (float)MATHIV_CCTableLength + 0.5);

/* ==========================================================================
   Point to the necessary row
   ========================================================================== */
            KernC = &(MATHPV_CubiConvTable[ index ]
                        [ MATHID_cubi_conv_elem - 1 ]) + 1;

/* ==========================================================================
   Retrive the columns index ... see comment above
   ========================================================================== */
            Nc = (UINTx4)OutPoint[ rc ][ cc ].col;
            delta = (OutPoint[ rc ][ cc ].col - (float)Nc);
            index = (UINTx4)(delta * (float)MATHIV_CCTableLength + 0.5);

/* ==========================================================================
   Initialize the sum variable
   ========================================================================== */
            memset ( (void *)rowval, 0,
                     (size_t)(MATHID_cubi_conv_elem *
                     sizeof ( MATHIT_complex )) );

/* ==========================================================================
   Make four convolutions in the rows direction
   ========================================================================== */
            for ( row=Nr-1; row<=Nr+2; row++ ) {

/* ==========================================================================
   Point the kernel
   ========================================================================== */
               KernR = &(MATHPV_CubiConvTable[ index ]
                           [ MATHID_cubi_conv_elem - 1 ]) + 1;

/* ==========================================================================
   Point to the beginning of the matrices rows
   ========================================================================== */
               pr = &(((float **)InpIma)[ row ][ 2 * ( Nc - 1 ) ]) - 2;
               pi = &(((float **)InpIma)[ row ][ 2 * ( Nc - 1 ) + 1 ]) - 2;

/* ==========================================================================
   Convolution loop
   ========================================================================== */
               for ( col=0; col<MATHID_cubi_conv_elem; col++ ) {
                  pr++;
                  pi++;
                  rowval[ row - Nr + 1 ].rea += *--KernR * *++pr;
                  rowval[ row - Nr + 1 ].ima += *KernR * *++pi;
               }
            }

/* ==========================================================================
   Columns interpolation ... see comments above
   ========================================================================== */
            OutVal.rea = 0.0;
            OutVal.ima = 0.0;
         
            for ( col=0; col<MATHID_cubi_conv_elem; col++ ) {
               OutVal.rea += *--KernC * rowval[ col ].rea;
               OutVal.ima += *KernC * rowval[ col ].ima;
            }

/* ==========================================================================
   Output fill
   ========================================================================== */
            ((float **)OutIma)[ rc ][ 2 * cc ] = OutVal.rea;
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = OutVal.ima;
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ 2 * cc ] = InvVal;
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = InvVal;
         }
      }
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_CC2float */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SincAzimuth

        $TYPE         PROCEDURE

        $INPUT        shift : the independent variable value
                      fc    : doppler centroid frequency

        $MODIFIED     NONE

        $OUTPUT       y     : the array of the sinc function evaluated for the
                              shift <shift>

        $GLOBAL       MATHIV_sinc_elem : the length of the sinc

        $RET_STATUS   ERRSID_MATH_delta_out

        $DESCRIPTION  This procedure evaluates an array of values of the sinc
                      function in the form: sinc ( x ) = sin ( x ) / x for a
                      given value of delta (shift). The sinc function is
                      evaluated considering the modulation given by the doppler
                      centroid frequency <fc>

        $WARNING      THE INITIALIZATION PROCEDURE MUST BE CALLED BEFORE THE
                      PRESENT ONE.

        $PDL          - Evaluates the frequence of the sinc
                      - Loop over the points of the sinc to evaluate
                            - Evaluates the delta from the current point
                            - Fill the real part of the result
                            - Modulates the array point with the term due to
                              the doppler centroid freq.
                            - Increments the array modulus sum
                      - End loop
                      - Normalizes the result with the modulus of the array

   $EH
   ========================================================================== */

void MATHPP_INTR_SincAzimuth
                        (/*IN    */ float                shift,
                         /*IN    */ float                fc,
                         /*   OUT*/ MATHIT_complex      *y,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_SincAzimuth";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   float                  nu;
   float                  w;
   float                  phi0;
   float                  phi;
   float                  x;
   double                 Sum;
   MATHIT_complex         fact;
   MATHIT_array           arr;
   INTx4                  h;
   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the shift consistency
   ========================================================================== */
   if ( ( shift < -.5 ) && ( shift > .5 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_delta_out, "" );
   }

/* ==========================================================================
   Initializes the variables
   ========================================================================== */
   Sum = (double)0;
   phi0 = 2. * PI * fc;

/* ==========================================================================
   Evaluate the necessary variables
   ========================================================================== */
   nu = PI / ( (float)(MATHIV_sinc_elem / 2 + 1) );       /* freq. */
   h = (INTx4)(MATHIV_sinc_elem / 2);               /* half length */

/* ==========================================================================
   Loop over the array elements
   ========================================================================== */
   for ( i=-h; i<=h; i++ ) {

/* ==========================================================================
   Evaluate the current shift
   ========================================================================== */
      x = ( shift + (float)i ) * PI;

/* ==========================================================================
   Evaluate the element
   ========================================================================== */
      w = 0.5 * ( 1.0 + cos ( ( (float)i + shift) * nu ) );

/* ==========================================================================
   Fill the array
   ========================================================================== */
      y[ i + h ].rea = ( x == 0. ) ? w : w * sin ( x ) / x;
      y[ i + h ].ima = 0.;

/* ==========================================================================
   Evaluate the modulation phase
   ========================================================================== */
      phi = phi0 * ( (float)i + shift );

/* ==========================================================================
   Modulate the array
   ========================================================================== */
      MATHIP_STYP_CExp ( (double)phi, &fact, status_code );
      MATHIP_STYP_CProd ( y[ i + h ], fact, &(y[ i + h ]), status_code );

/* ==========================================================================
   Update the array sum
   ========================================================================== */
      Sum += (double)(y[ i + h ].rea);
   }

/* ==========================================================================
   Fill the array element to call MATHIP_ procedure
   ========================================================================== */
   arr.nelem = MATHIV_sinc_elem;
   arr.atype = MATHIE_complex;
   arr.ap = (void *)y;

/* ==========================================================================
   Normalize the array
   ========================================================================== */
   MATHIP_VECT_ConstMult ( (double)(1. / Sum), arr, &arr, status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_SincAzimuth */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SincRange

        $TYPE         PROTOTYPE

        $INPUT        shift : the independent variable value

        $MODIFIED     NONE

        $OUTPUT       y     : the array of the sinc function evaluated for the
                              shift <shift>

        $GLOBAL       MATHIV_sinc_elem : the length of the sinc

        $RET_STATUS   ERRSID_MATH_delta_out

        $DESCRIPTION  This procedure evaluates an array of values of the sinc
                      function in the form: sinc ( x ) = sin ( x ) / x for a
                      given value of delta (shift).

        $WARNING      THE INITIALIZATION PROCEDURE MUST BE CALLED BEFORE THE
                      PRESENT ONE

        $PDL          - Evaluates the frequence of the sinc
                      - Loop over the points of the sinc to evaluate
                            - Evaluates the delta from the current point
                            - Fill the real part of the result
                            - Increments the array modulus sum
                      - End loop
                      - Normalizes the result with the modulus of the array

   $EH
   ========================================================================== */

void MATHPP_INTR_SincRange
                        (/*IN    */ float                shift,
                         /*   OUT*/ float               *y,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_SincRange";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   float                  nu;
   float                  w;
   float                  x;
   double                 Sum;
   MATHIT_array           arr;
   INTx4                  h;
   INTx4                  i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name,  &process_flag, &log_status_code );

/* ==========================================================================
   Check the shift consistency
   ========================================================================== */
   if ( ( shift < -.5 ) && ( shift > .5 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_delta_out, "" );
   }

/* ==========================================================================
   Initializes the variables
   ========================================================================== */
   Sum = (double)0;

/* ==========================================================================
   Evaluate the necessary variables
   ========================================================================== */
   nu = PI / ( (float)(MATHIV_sinc_elem / 2 + 1) );       /* freq. */
   h = (INTx4)(MATHIV_sinc_elem / 2);               /* half length */

/* ==========================================================================
   Loop over the array elements
   ========================================================================== */
   for ( i=-h; i<=h; i++ ) {

/* ==========================================================================
   Evaluate the current shift
   ========================================================================== */
      x = ( shift + (float)i ) * PI;

/* ==========================================================================
   Evaluate the element
   ========================================================================== */
      w = 0.5 * ( 1.0 + cos ( ( (float)i + shift) * nu ) );

/* ==========================================================================
   Fill the array
   ========================================================================== */
      y[ i + h ] = ( x == 0. ) ? w : w * sin ( x ) / x;

/* ==========================================================================
   Update the array sum
   ========================================================================== */
      Sum += (double)(y[ i + h ]);
   }

/* ==========================================================================
   Fill the array element to call MATHIP_ procedure
   ========================================================================== */
   arr.nelem = MATHIV_sinc_elem;
   arr.atype = MATHIE_float;
   arr.ap = (void *)y;

/* ==========================================================================
   Normalize the array
   ========================================================================== */
   MATHIP_VECT_ConstMult ( (double)(1. / Sum), arr, &arr, status_code );

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_SincRange */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SNUINTx1

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHIV_SincTableLength : inverse of the precision required
                                               for the sinc interpolation
                      MATHPV_SincRowTable    : the table with the values for the
                                               sinc interpolation in the row
                                               direction
                      MATHPV_SincColTable    : the table with the values for the
                                               sinc interpolation in the column
                                               direction

        $RET_STATUS   ERRSID_MATH_table_not_allocated

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates for images of UINTx1 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the round integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the azimuth
                                          table
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_SNUINTx1
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_SNUINTx1";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                   rc;
   UINTx4                   cc;
   UINTx4                   row;
   UINTx4                   col;
   UINTx4                   Nr;
   UINTx4                   Nc;
   UINTx4                   ih;
   float                    h;
   float                    delta;
   UINTx4                   index;
   REGISTER float          *KernR = (float *)NULL;
   REGISTER MATHIT_complex *KernC = (MATHIT_complex *)NULL;
   REGISTER UINTx1         *p = (UINTx1 *)NULL;
   REGISTER float           OutVal;
   float                   *rowval = (float *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the initialization has be done
   ========================================================================== */
   if ( ( MATHPV_SincRowTable == (float ***)NULL ) ||
        ( MATHPV_SincColTable == (MATHIT_complex ***)NULL ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_table_not_allocated, "" );
   }

/* ==========================================================================
   Allocate the tmp vector
   ========================================================================== */
   if ( ( rowval = (float *)MEMSIP_alloc ( (size_t)(MATHIV_sinc_elem *
                                          sizeof (float)) ) ) ==
        (float *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                         "in the temporary vector" );
   }

/* ==========================================================================
   Evaluate the half column dimension
   ========================================================================== */
   h = (float)MATHIV_sinc_elem / 2.;
   ih = (UINTx4)h;

/* ==========================================================================
   Rows loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Check that the point is internal
   ========================================================================== */
         if ( ( ( OutPoint[ rc ][ cc ].row > h ) &&
                ( OutPoint[ rc ][ cc ].row < ( (float)NRowInp - 1. - h ) ) ) &&
              ( ( OutPoint[ rc ][ cc ].col > h ) &&
                ( OutPoint[ rc ][ cc ].col < ( (float)NColInp - 1. - h ) ) ) ) {

/* ==========================================================================
   Evaluate the rounded integer coordinate
   ========================================================================== */
            Nr = (UINTx4)(OutPoint[ rc ][ cc ].row + .5);

/* ==========================================================================
   Evaluate the delta of the coordinate WRT the lefmost one
   ========================================================================== */
            delta = (OutPoint[ rc ][ cc ].row - (float)Nr);

/* ==========================================================================
   Evaluate the index in the table
   ========================================================================== */
            index = (UINTx4)(( delta + 0.5 ) * (float)MATHIV_SincTableLength);

/* ==========================================================================
   Point to the necessary row
   ========================================================================== */
            KernC = &(MATHPV_SincColTable[ imanum ][ index ]
                        [ MATHIV_sinc_elem - 1 ]) + 1;

/* ==========================================================================
   Retrive the columns index ... see comment above
   ========================================================================== */
            Nc = (UINTx4)(OutPoint[ rc ][ cc ].col + 0.5 );
            delta = (OutPoint[ rc ][ cc ].col - (float)Nc);
            index = (UINTx4)(( delta + 0.5 ) * (float)MATHIV_SincTableLength);

/* ==========================================================================
   Initialize the sum variable
   ========================================================================== */
            memset ( (void *)rowval, '\0',
                           (size_t)(MATHIV_sinc_elem * sizeof (float)) );

/* ==========================================================================
   Make four convolutions in the rows direction
   ========================================================================== */
            for ( row=Nr-ih; row<=Nr+ih; row++ ) {

/* ==========================================================================
   Point the kernel
   ========================================================================== */
               KernR = &(MATHPV_SincRowTable[ imanum ][ index ]
                  [ MATHIV_sinc_elem - 1 ]) + 1;

/* ==========================================================================
   Point to the beginning of the matrices rows
   ========================================================================== */
               p = &(((UINTx1 **)InpIma)[ row ][ Nc - ih ]) - 1;

/* ==========================================================================
   Convolution loop
   ========================================================================== */
               for ( col=0; col<MATHIV_sinc_elem; col++ ) {
                  rowval[ row - Nr + ih ] += *--KernR * (float)*++p;
               }
            }

/* ==========================================================================
   Columns interpolation ... see comments above
   ========================================================================== */
            OutVal = 0.;
            for ( col=0; col<MATHIV_sinc_elem; col++ ) {
               OutVal += ( (--KernC)->rea ) * rowval[ col ];
            }

/* ==========================================================================
   Output fill
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = OutVal;
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = InvVal;
         }
      }
   }

error_exit:;

/* ==========================================================================
   Free the allocated memory
   ========================================================================== */
   MEMSIP_free ( (void **)&rowval );

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_SNUINTx1 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SNUINTx2

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHIV_SincTableLength : inverse of the precision required
                                               for the sinc interpolation
                      MATHPV_SincRowTable    : the table with the values for the
                                               sinc interpolation in the row
                                               direction
                      MATHPV_SincColTable    : the table with the values for the
                                               sinc interpolation in the column
                                               direction

        $RET_STATUS   ERRSID_MATH_table_not_allocated

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates for images of UINTx2 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the round integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the azimuth
                                          table
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_SNUINTx2
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_SNUINTx2";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                   rc;
   UINTx4                   cc;
   UINTx4                   row;
   UINTx4                   col;
   UINTx4                   Nr;
   UINTx4                   Nc;
   UINTx4                   ih;
   float                    h;
   float                    delta;
   UINTx4                   index;
   REGISTER float          *KernR = (float *)NULL;
   REGISTER MATHIT_complex *KernC = (MATHIT_complex *)NULL;
   REGISTER UINTx2         *p = (UINTx2 *)NULL;
   REGISTER float           OutVal;
   float                   *rowval = (float *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the initialization has be done
   ========================================================================== */
   if ( ( MATHPV_SincRowTable == (float ***)NULL ) ||
        ( MATHPV_SincColTable == (MATHIT_complex ***)NULL ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_table_not_allocated, "" );
   }

/* ==========================================================================
   Allocate the tmp vector
   ========================================================================== */
   if ( ( rowval = (float *)MEMSIP_alloc ( (size_t)(MATHIV_sinc_elem *
                                          sizeof (float)) ) ) ==
        (float *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                         "in the temporary vector" );
   }

/* ==========================================================================
   Evaluate the half column dimension
   ========================================================================== */
   h = (float)MATHIV_sinc_elem / 2.;
   ih = (UINTx4)h;

/* ==========================================================================
   Rows loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Check that the point is internal
   ========================================================================== */
         if ( ( ( OutPoint[ rc ][ cc ].row > h ) &&
                ( OutPoint[ rc ][ cc ].row < ( (float)NRowInp - 1. - h ) ) ) &&
              ( ( OutPoint[ rc ][ cc ].col > h ) &&
                ( OutPoint[ rc ][ cc ].col < ( (float)NColInp - 1. - h ) ) ) ) {

/* ==========================================================================
   Evaluate the rounded integer coordinate
   ========================================================================== */
            Nr = (UINTx4)(OutPoint[ rc ][ cc ].row + .5);

/* ==========================================================================
   Evaluate the delta of the coordinate WRT the lefmost one
   ========================================================================== */
            delta = (OutPoint[ rc ][ cc ].row - (float)Nr);

/* ==========================================================================
   Evaluate the index in the table
   ========================================================================== */
            index = (UINTx4)(( delta + 0.5 ) * (float)MATHIV_SincTableLength);

/* ==========================================================================
   Point to the necessary row
   ========================================================================== */
            KernC = &(MATHPV_SincColTable[ imanum ][ index ]
                        [ MATHIV_sinc_elem - 1 ]) + 1;

/* ==========================================================================
   Retrive the columns index ... see comment above
   ========================================================================== */
            Nc = (UINTx4)(OutPoint[ rc ][ cc ].col + 0.5 );
            delta = (OutPoint[ rc ][ cc ].col - (float)Nc);
            index = (UINTx4)(( delta + 0.5 ) * (float)MATHIV_SincTableLength);

/* ==========================================================================
   Initialize the sum variable
   ========================================================================== */
            memset ( (void *)rowval, '\0',
                           (size_t)(MATHIV_sinc_elem * sizeof (float)) );

/* ==========================================================================
   Make four convolutions in the rows direction
   ========================================================================== */
            for ( row=Nr-ih; row<=Nr+ih; row++ ) {

/* ==========================================================================
   Point the kernel
   ========================================================================== */
               KernR = &(MATHPV_SincRowTable[ imanum ][ index ]
                  [ MATHIV_sinc_elem - 1 ]) + 1;

/* ==========================================================================
   Point to the beginning of the matrices rows
   ========================================================================== */
               p = &(((UINTx2 **)InpIma)[ row ][ Nc - ih ]) - 1;

/* ==========================================================================
   Convolution loop
   ========================================================================== */
               for ( col=0; col<MATHIV_sinc_elem; col++ ) {
                  rowval[ row - Nr + ih ] += *--KernR * (float)*++p;
               }
            }

/* ==========================================================================
   Columns interpolation ... see comments above
   ========================================================================== */
            OutVal = 0.;
            for ( col=0; col<MATHIV_sinc_elem; col++ ) {
               OutVal += ( (--KernC)->rea ) * rowval[ col ];
            }

/* ==========================================================================
   Output fill
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = OutVal;
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = InvVal;
         }
      }
   }

error_exit:;

/* ==========================================================================
   Free the allocated memory
   ========================================================================== */
   MEMSIP_free ( (void **)&rowval );

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_SNUINTx2 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SNfloat

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHIV_SincTableLength : inverse of the precision required
                                               for the sinc interpolation
                      MATHPV_SincRowTable    : the table with the values for the
                                               sinc interpolation in the row
                                               direction
                      MATHPV_SincColTable    : the table with the values for the
                                               sinc interpolation in the column
                                               direction

        $RET_STATUS   ERRSID_MATH_table_not_allocated

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates for images of float type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the round integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the azimuth
                                          table
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_SNfloat
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_SNfloat";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                   rc;
   UINTx4                   cc;
   UINTx4                   row;
   UINTx4                   col;
   UINTx4                   Nr;
   UINTx4                   Nc;
   UINTx4                   ih;
   float                    h;
   float                    delta;
   UINTx4                   index;
   REGISTER float          *KernR = (float *)NULL;
   REGISTER MATHIT_complex *KernC = (MATHIT_complex *)NULL;
   REGISTER float          *p = (float *)NULL;
   REGISTER float           OutVal;
   float                   *rowval = (float *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the initialization has be done
   ========================================================================== */
   if ( ( MATHPV_SincRowTable == (float ***)NULL ) ||
        ( MATHPV_SincColTable == (MATHIT_complex ***)NULL ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_table_not_allocated, "" );
   }

/* ==========================================================================
   Allocate the tmp vector
   ========================================================================== */
   if ( ( rowval = (float *)MEMSIP_alloc ( (size_t)(MATHIV_sinc_elem *
                                          sizeof (float)) ) ) ==
        (float *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                         "in the temporary vector" );
   }

/* ==========================================================================
   Evaluate the half column dimension
   ========================================================================== */
   h = (float)MATHIV_sinc_elem / 2.;
   ih = (UINTx4)h;

/* ==========================================================================
   Rows loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Check that the point is internal
   ========================================================================== */
         if ( ( ( OutPoint[ rc ][ cc ].row > h ) &&
                ( OutPoint[ rc ][ cc ].row < ( (float)NRowInp - 1. - h ) ) ) &&
              ( ( OutPoint[ rc ][ cc ].col > h ) &&
                ( OutPoint[ rc ][ cc ].col < ( (float)NColInp - 1. - h ) ) ) ) {

/* ==========================================================================
   Evaluate the rounded integer coordinate
   ========================================================================== */
            Nr = (UINTx4)(OutPoint[ rc ][ cc ].row + .5);

/* ==========================================================================
   Evaluate the delta of the coordinate WRT the lefmost one
   ========================================================================== */
            delta = (OutPoint[ rc ][ cc ].row - (float)Nr);

/* ==========================================================================
   Evaluate the index in the table
   ========================================================================== */
            index = (UINTx4)(( delta + 0.5 ) * (float)MATHIV_SincTableLength);

/* ==========================================================================
   Point to the necessary row
   ========================================================================== */
            KernC = &(MATHPV_SincColTable[ imanum ][ index ]
                        [ MATHIV_sinc_elem - 1 ]) + 1;

/* ==========================================================================
   Retrive the columns index ... see comment above
   ========================================================================== */
            Nc = (UINTx4)(OutPoint[ rc ][ cc ].col + 0.5 );
            delta = (OutPoint[ rc ][ cc ].col - (float)Nc);
            index = (UINTx4)(( delta + 0.5 ) * (float)MATHIV_SincTableLength);

/* ==========================================================================
   Initialize the sum variable
   ========================================================================== */
            memset ( (void *)rowval, '\0',
                           (size_t)(MATHIV_sinc_elem * sizeof (float)) );

/* ==========================================================================
   Make four convolutions in the rows direction
   ========================================================================== */
            for ( row=Nr-ih; row<=Nr+ih; row++ ) {

/* ==========================================================================
   Point the kernel
   ========================================================================== */
               KernR = &(MATHPV_SincRowTable[ imanum ][ index ]
                  [ MATHIV_sinc_elem - 1 ]) + 1;

/* ==========================================================================
   Point to the beginning of the matrices rows
   ========================================================================== */
               p = &(((float **)InpIma)[ row ][ Nc - ih ]) - 1;

/* ==========================================================================
   Convolution loop
   ========================================================================== */
               for ( col=0; col<MATHIV_sinc_elem; col++ ) {
                  rowval[ row - Nr + ih ] += *--KernR * (float)*++p;
               }
            }

/* ==========================================================================
   Columns interpolation ... see comments above
   ========================================================================== */
            OutVal = 0.;
            for ( col=0; col<MATHIV_sinc_elem; col++ ) {
               OutVal += ( (--KernC)->rea ) * rowval[ col ];
            }

/* ==========================================================================
   Output fill
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = OutVal;
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ cc ] = InvVal;
         }
      }
   }

error_exit:;

/* ==========================================================================
   Free the allocated memory
   ========================================================================== */
   MEMSIP_free ( (void **)&rowval );

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_SNfloat */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SN2INTx2

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHIV_SincTableLength : inverse of the precision required
                                               for the sinc interpolation
                      MATHPV_SincRowTable    : the table with the values for the
                                               sinc interpolation in the row
                                               direction
                      MATHPV_SincColTable    : the table with the values for the
                                               sinc interpolation in the column
                                               direction

        $RET_STATUS   ERRSID_MATH_table_not_allocated

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates for images of 2INTx2 type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the round integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the azimuth
                                          table
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_SN2INTx2
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_SN2INTx2";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                   rc;
   UINTx4                   cc;
   UINTx4                   row;
   UINTx4                   col;
   UINTx4                   Nr;
   UINTx4                   Nc;
   UINTx4                   ih;
   float                    h;
   float                    delta;
   UINTx4                   index;
   REGISTER float          *KernR = (float *)NULL;
   REGISTER MATHIT_complex *KernC = (MATHIT_complex *)NULL;
   REGISTER INTx2          *pr = (INTx2 *)NULL;
   REGISTER INTx2          *pi = (INTx2 *)NULL;
   REGISTER MATHIT_complex  OutVal;
   MATHIT_complex          *rowval = (MATHIT_complex *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the initialization has be done
   ========================================================================== */
   if ( ( MATHPV_SincRowTable == (float ***)NULL ) ||
        ( MATHPV_SincColTable == (MATHIT_complex ***)NULL ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_table_not_allocated, "" );
   }

/* ==========================================================================
   Allocate the tmp vector
   ========================================================================== */
   if ( ( rowval = (MATHIT_complex *)MEMSIP_alloc ( (size_t)(MATHIV_sinc_elem *
                                                 sizeof (MATHIT_complex)) ) ) ==
        (MATHIT_complex *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                         "in the temporary vector" );
   }

/* ==========================================================================
   Evaluate the half column dimension
   ========================================================================== */
   h = (float)MATHIV_sinc_elem / 2.;
   ih = (UINTx4)h;

/* ==========================================================================
   Rows loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Check that the point is internal
   ========================================================================== */
         if ( ( ( OutPoint[ rc ][ cc ].row > h ) &&
                ( OutPoint[ rc ][ cc ].row < ( (float)NRowInp - 1. - h ) ) ) &&
              ( ( OutPoint[ rc ][ cc ].col > h ) &&
                ( OutPoint[ rc ][ cc ].col < ( (float)NColInp - 1. - h ) ) ) ) {

/* ==========================================================================
   Evaluate the rounded integer coordinate
   ========================================================================== */
            Nr = (UINTx4)(OutPoint[ rc ][ cc ].row + .5);

/* ==========================================================================
   Evaluate the delta of the coordinate WRT the lefmost one
   ========================================================================== */
            delta = (OutPoint[ rc ][ cc ].row - (float)Nr);

/* ==========================================================================
   Evaluate the index in the table
   ========================================================================== */
            index = (UINTx4)(( delta + 0.5 ) * (float)MATHIV_SincTableLength);

/* ==========================================================================
   Point to the necessary row
   ========================================================================== */
            KernC = &(MATHPV_SincColTable[ imanum ][ index ]
                        [ MATHIV_sinc_elem - 1 ]) + 1;

/* ==========================================================================
   Retrive the columns index ... see comment above
   ========================================================================== */
            Nc = (UINTx4)(OutPoint[ rc ][ cc ].col + 0.5 );
            delta = (OutPoint[ rc ][ cc ].col - (float)Nc);
            index = (UINTx4)(( delta + 0.5 ) * (float)MATHIV_SincTableLength);

/* ==========================================================================
   Initialize the sum variable
   ========================================================================== */
            memset ( (void *)rowval, '\0',
                           (size_t)(MATHIV_sinc_elem *
                           sizeof ( MATHIT_complex )) );

/* ==========================================================================
   Make four convolutions in the rows direction
   ========================================================================== */
            for ( row=Nr-ih; row<=Nr+ih; row++ ) {

/* ==========================================================================
   Point the kernel
   ========================================================================== */
               KernR = &(MATHPV_SincRowTable[ imanum ][ index ]
                  [ MATHIV_sinc_elem - 1 ]) + 1;

/* ==========================================================================
   Point to the beginning of the matrices rows
   ========================================================================== */
               pr = &(((INTx2 **)InpIma)[ row ][ 2 * ( Nc - ih ) ]) - 2;
               pi = &(((INTx2 **)InpIma)[ row ][ 2 * ( Nc - ih ) + 1 ]) - 2;

/* ==========================================================================
   Convolution loop
   ========================================================================== */
               for ( col=0; col<MATHIV_sinc_elem; col++ ) {
                  pr++;
                  pi++;
                  rowval[ row - Nr + ih ].rea += *--KernR * (float)*++pr;
                  rowval[ row - Nr + ih ].ima += *KernR * (float)*++pi;
               }
            }

/* ==========================================================================
   Columns interpolation ... see comments above
   ========================================================================== */
            OutVal.rea = 0.0;
            OutVal.ima = 0.0;
            for ( col=0; col<MATHIV_sinc_elem; col++ ) {
               OutVal.rea += (--KernC)->rea * rowval[ col ].rea -
                  KernC->ima * rowval[ col ].ima;
               OutVal.ima += KernC->rea * rowval[ col ].ima +
                  KernC->ima * rowval[ col ].rea;
            }

/* ==========================================================================
   Output fill
   ========================================================================== */
            ((float **)OutIma)[ rc ][ 2 * cc ] = OutVal.rea;
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = OutVal.ima;
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ 2 * cc ] = InvVal;
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = InvVal;
         }
      }
   }

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&rowval );

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_SN2INTx2 */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_SN2float

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHIV_SincTableLength : inverse of the precision required
                                               for the sinc interpolation
                      MATHPV_SincRowTable    : the table with the values for the
                                               sinc interpolation in the row
                                               direction
                      MATHPV_SincColTable    : the table with the values for the
                                               sinc interpolation in the column
                                               direction

        $RET_STATUS   ERRSID_MATH_table_not_allocated

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates for images of 2float type

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Loop over the points along rows
                            - Loop over the points along the columns
                                  - If the point is internal to the image
                                        - Evaluates the round integer value of
                                          the point row and column coordinates
                                        - Evaluates the delta of the coordinates
                                          WRT the integer values
                                        - Evaluates the indices in the tables
                                        - Points the pointer to the azimuth
                                          table
                                        - Loop over the four rows that
                                          partecipates to the interpolation
                                                - Points the pointer to the
                                                  input image
                                                - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        image
                                                - End loop
                                        - End loop
                                        - Loop over the four values obtained
                                          interpolating the rows elements
                                              - Loop over the columns of the
                                                  row
                                                      - Sums the product kernel
                                                        interpolated values
                                                - End loop
                                        - End loop
                                  - End if
                                  - Else if the point is external
                                        - Put the invalid value in the output
                                          image
                                  - End else
                            - End loop
                      - End loop

   $EH
   ========================================================================== */

void MATHPP_INTR_SN2float
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_SN2float";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                   rc;
   UINTx4                   cc;
   UINTx4                   row;
   UINTx4                   col;
   UINTx4                   Nr;
   UINTx4                   Nc;
   UINTx4                   ih;
   float                    h;
   float                    delta;
   UINTx4                   index;
   REGISTER float          *KernR = (float *)NULL;
   REGISTER MATHIT_complex *KernC = (MATHIT_complex *)NULL;
   REGISTER float          *pr = (float *)NULL;
   REGISTER float          *pi = (float *)NULL;
   REGISTER MATHIT_complex  OutVal;
   MATHIT_complex          *rowval = (MATHIT_complex *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the initialization has be done
   ========================================================================== */
   if ( ( MATHPV_SincRowTable == (float ***)NULL ) ||
        ( MATHPV_SincColTable == (MATHIT_complex ***)NULL ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_table_not_allocated, "" );
   }

/* ==========================================================================
   Allocate the tmp vector
   ========================================================================== */
   if ( ( rowval = (MATHIT_complex *)MEMSIP_alloc ( (size_t)(MATHIV_sinc_elem *
                                                 sizeof (MATHIT_complex)) ) ) ==
        (MATHIT_complex *)NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_err_mem_alloc,
                         "in the temporary vector" );
   }

/* ==========================================================================
   Evaluate the half column dimension
   ========================================================================== */
   h = (float)MATHIV_sinc_elem / 2.;
   ih = (UINTx4)h;

/* ==========================================================================
   Rows loop
   ========================================================================== */
   for ( rc=0; rc<NRowOut; rc++ ) {

/* ==========================================================================
   Columns loop
   ========================================================================== */
      for ( cc=0; cc<NColOut; cc++ ) {

/* ==========================================================================
   Check that the point is internal
   ========================================================================== */
         if ( ( ( OutPoint[ rc ][ cc ].row > h ) &&
                ( OutPoint[ rc ][ cc ].row < ( (float)NRowInp - 1. - h ) ) ) &&
              ( ( OutPoint[ rc ][ cc ].col > h ) &&
                ( OutPoint[ rc ][ cc ].col < ( (float)NColInp - 1. - h ) ) ) ) {

/* ==========================================================================
   Evaluate the rounded integer coordinate
   ========================================================================== */
            Nr = (UINTx4)(OutPoint[ rc ][ cc ].row + .5);

/* ==========================================================================
   Evaluate the delta of the coordinate WRT the lefmost one
   ========================================================================== */
            delta = (OutPoint[ rc ][ cc ].row - (float)Nr);

/* ==========================================================================
   Evaluate the index in the table
   ========================================================================== */
            index = (UINTx4)(( delta + 0.5 ) * (float)MATHIV_SincTableLength);

/* ==========================================================================
   Point to the necessary row
   ========================================================================== */
            KernC = &(MATHPV_SincColTable[ imanum ][ index ]
                        [ MATHIV_sinc_elem - 1 ]) + 1;

/* ==========================================================================
   Retrive the columns index ... see comment above
   ========================================================================== */
            Nc = (UINTx4)(OutPoint[ rc ][ cc ].col + 0.5 );
            delta = (OutPoint[ rc ][ cc ].col - (float)Nc);
            index = (UINTx4)(( delta + 0.5 ) * (float)MATHIV_SincTableLength);

/* ==========================================================================
   Initialize the sum variable
   ========================================================================== */
            memset ( (void *)rowval, 0,
                           (size_t)(MATHIV_sinc_elem *
                           sizeof ( MATHIT_complex )) );

/* ==========================================================================
   Make four convolutions in the rows direction
   ========================================================================== */
            for ( row=Nr-ih; row<=Nr+ih; row++ ) {

/* ==========================================================================
   Point the kernel
   ========================================================================== */
            KernR = &(MATHPV_SincRowTable[ imanum ][ index ]
                        [ MATHIV_sinc_elem - 1 ]) + 1;

/* ==========================================================================
   Point to the beginning of the matrices rows
   ========================================================================== */
               pr = &(((float **)InpIma)[ row ][ 2 * ( Nc - ih ) ]) - 2;
               pi = &(((float **)InpIma)[ row ][ 2 * ( Nc - ih ) + 1 ]) - 2;

/* ==========================================================================
   Convolution loop
   ========================================================================== */
               for ( col=0; col<MATHIV_sinc_elem; col++ ) {
                  pr++;
                  pi++;
                  rowval[ row - Nr + ih ].rea += *--KernR * (float)*++pr;
                  rowval[ row - Nr + ih ].ima += *KernR * (float)*++pi;
               }
            }

/* ==========================================================================
   Columns interpolation ... see comments above
   ========================================================================== */
            OutVal.rea = 0.0;
            OutVal.ima = 0.0;
            for ( col=0; col<MATHIV_sinc_elem; col++ ) {
               OutVal.rea += (--KernC)->rea * rowval[ col ].rea -
                  KernC->ima * rowval[ col ].ima;
               OutVal.ima += KernC->rea * rowval[ col ].ima +
                  KernC->ima * rowval[ col ].rea;
            }

/* ==========================================================================
   Output fill
   ========================================================================== */
            ((float **)OutIma)[ rc ][ 2 * cc ] = OutVal.rea;
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = OutVal.ima;
         }
         else {

/* ==========================================================================
   Out border value
   ========================================================================== */
            ((float **)OutIma)[ rc ][ 2 * cc ] = InvVal;
            ((float **)OutIma)[ rc ][ 2 * cc + 1 ] = InvVal;
         }
      }
   }

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   MEMSIP_free ( (void **)&rowval );

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_SN2float */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillRowArray

        $TYPE         PROCEDURE

        $INPUT        InpIma    : input image
                      row       : image row to copy
                      NColInp   : number of elements of the line
                      DataType  : enumerate the various image types

        $MODIFIED     NONE

        $OUTPUT       sign_s    : array with the image row copy

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills an array with an image row to be
                      processed by FFT algorithms

        $WARNING      NONE

        $PDL          - Checks the number of elements of the image row
                      - Checks the array type
                      - Switch over the data types
                            - Loop over the image elements
                                  - Copies the image row element
                            - End loop
                      - End switch

   $EH
   ========================================================================== */

void MATHPP_INTR_FillRowArray
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               row,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *sign_s,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_FillRowArray";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the number of elements
   ========================================================================== */
   if ( NColInp > sign_s->nelem ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_no_suff_arr_elem, "" );
   }

/* ==========================================================================
   Check the array type
   ========================================================================== */
   if ( sign_s->atype != MATHIE_complex ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_no_complex, "" );
   }

/* ==========================================================================
   Copy the image line in the array
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx1:
         for ( col=0; col<NColInp; col++ ) {
            (((MATHIT_complex *)sign_s->ap)[ col ]).rea =
               (float)(((UINTx1 **)InpIma)[ row ][ col ]);
         }
      break;
      case LDEFIE_dt_UINTx2:
         for ( col=0; col<NColInp; col++ ) {
            (((MATHIT_complex *)sign_s->ap)[ col ]).rea =
               (float)(((UINTx2 **)InpIma)[ row ][ col ]);
         }
      break;
      case LDEFIE_dt_float:
         for ( col=0; col<NColInp; col++ ) {
            (((MATHIT_complex *)sign_s->ap)[ col ]).rea =
               (((float **)InpIma)[ row ][ col ]);
         }
      break;
      case LDEFIE_dt_2_INTx2:
         for ( col=0; col<NColInp; col++ ) {
            (((MATHIT_complex *)sign_s->ap)[ col ]).rea =
               (float)(((INTx2 **)InpIma)[ row ][ 2 * col ]);
            (((MATHIT_complex *)sign_s->ap)[ col ]).ima =
               (float)(((INTx2 **)InpIma)[ row ][ 2 * col + 1 ]);
         }
      break;
      case LDEFIE_dt_2_float:
         for ( col=0; col<NColInp; col++ ) {
            (((MATHIT_complex *)sign_s->ap)[ col ]).rea =
               (((float **)InpIma)[ row ][ 2 * col ]);
            (((MATHIT_complex *)sign_s->ap)[ col ]).ima =
               (((float **)InpIma)[ row ][ 2 * col + 1 ]);
         }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_MATH_data_type_not_allow,
                            "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_FillRowArray */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillColArray

        $TYPE         PROCEDURE

        $INPUT        InpIma    : input image
                      col       : image col to copy
                      NRowInp   : number of elements of the column 
                      DataType  : enumerate the various image types

        $MODIFIED     NONE

        $OUTPUT       sign_s    : array with the image column copy

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills an array with an image column to be
                      processed by FFT algorithms

        $WARNING      NONE

        $PDL          - Checks the number of elements of the image row
                      - Checks the array type
                      - Switch over the data types
                            - Loop over the image rows
                                  - Copies the image column element
                            - End loop
                      - End switch

   $EH
   ========================================================================== */

void MATHPP_INTR_FillColArray
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               col,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *sign_s,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_FillColArray";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                  row;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the number of elements
   ========================================================================== */
   if ( NRowInp > sign_s->nelem ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_no_suff_arr_elem, "" );
   }

/* ==========================================================================
   Check the array type
   ========================================================================== */
   if ( sign_s->atype != MATHIE_complex ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_no_complex, "" );
   }

/* ==========================================================================
   Copy the image line in the array
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx1:
         for ( row=0; row<NRowInp; row++ ) {
            (((MATHIT_complex *)sign_s->ap)[ row ]).rea =
               (float)(((UINTx1 **)InpIma)[ row ][ col ]);
         }
      break;
      case LDEFIE_dt_UINTx2:
         for ( row=0; row<NRowInp; row++ ) {
            (((MATHIT_complex *)sign_s->ap)[ row ]).rea =
               (float)(((UINTx2 **)InpIma)[ row ][ col ]);
         }
      break;
      case LDEFIE_dt_float:
         for ( row=0; row<NRowInp; row++ ) {
            (((MATHIT_complex *)sign_s->ap)[ row ]).rea =
               (((float **)InpIma)[ row ][ col ]);
         }
      break;
      case LDEFIE_dt_2_INTx2:
         for ( row=0; row<NRowInp; row++ ) {
            (((MATHIT_complex *)sign_s->ap)[ row ]).rea =
               (float)(((INTx2 **)InpIma)[ row ][ 2 * col ]);
            (((MATHIT_complex *)sign_s->ap)[ row ]).ima =
               (float)(((INTx2 **)InpIma)[ row ][ 2 * col + 1 ]);
         }
      break;
      case LDEFIE_dt_2_float:
         for ( row=0; row<NRowInp; row++ ) {
            (((MATHIT_complex *)sign_s->ap)[ row ]).rea =
               (((float **)InpIma)[ row ][ 2 * col ]);
            (((MATHIT_complex *)sign_s->ap)[ row ]).ima =
               (((float **)InpIma)[ row ][ 2 * col + 1 ]);
         }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_MATH_data_type_not_allow,
                            "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_FillColArray */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillImaRow

        $TYPE         PROCEDURE

        $INPUT        sign_s   : array to copy
                      row      : image line to fill
                      NColInp  : number of image columns
                      DataType : data type of the output image line

        $MODIFIED     InpIma   : image to rewrite

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills the image row indicated by the input
                      <row>

        $WARNING      NONE

        $PDL          - Checks the number of array elements
                      - Checks the array type
                      - Switch over the output image types
                            - Loop over the array elements
                                  - Fills the image row element
                            - End loop
                      - End switch

   $EH
   ========================================================================== */

void MATHPP_INTR_FillImaRow
                        (/*IN    */ MATHIT_array         sign_s,
                         /*IN    */ UINTx4               row,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN OUT*/ void               **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_FillImaRow";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                 col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the number of elements
   ========================================================================== */
   if ( sign_s.nelem < 1 ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_null_arr, "" );
   }

/* ==========================================================================
   Check the array type
   ========================================================================== */
   if ( sign_s.atype != MATHIE_complex ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_no_complex, "" );
   }

/* ==========================================================================
   Fill the input image row
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx1:
         for ( col=0; col<NColInp; col++ ) {
            ((UINTx1 **)InpIma)[ row ][ col ] =
               (UINTx1)((((MATHIT_complex *)sign_s.ap)[ col ]).rea);
         }
      break;
      case LDEFIE_dt_UINTx2:
         for ( col=0; col<NColInp; col++ ) {
            ((UINTx2 **)InpIma)[ row ][ col ] =
               (UINTx2)((((MATHIT_complex *)sign_s.ap)[ col ]).rea);
         }
      break;
      case LDEFIE_dt_float:
         for ( col=0; col<NColInp; col++ ) {
            ((float **)InpIma)[ row ][ col ] =
               (float)((((MATHIT_complex *)sign_s.ap)[ col ]).rea);
         }
      break;
      case LDEFIE_dt_2_INTx2:
         for ( col=0; col<NColInp; col++ ) {
            ((INTx2 **)InpIma)[ row ][ 2 * col ] =
               (INTx2)((((MATHIT_complex *)sign_s.ap)[ col ]).rea);
            ((INTx2 **)InpIma)[ row ][ 2 * col + 1 ] =
               (INTx2)((((MATHIT_complex *)sign_s.ap)[ col ]).ima);
         }
      break;
      case LDEFIE_dt_2_float:
         for ( col=0; col<NColInp; col++ ) {
            ((float **)InpIma)[ row ][ 2 * col ] =
               (((MATHIT_complex *)sign_s.ap)[ col ]).rea;
            ((float **)InpIma)[ row ][ 2 * col + 1 ] =
               (((MATHIT_complex *)sign_s.ap)[ col ]).ima;
         }
      break;
      default:
        ERRSIM_set_error ( status_code, ERRSID_MATH_data_type_not_allow,
                           "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_FillImaRow */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillImaCol

        $TYPE         PROCEDURE

        $INPUT        sign_s   : array to copy
                      col      : image line to fill
                      NRowInp  : number of image rows
                      DataType : data type of the output image line

        $MODIFIED     InpIma   : image to rewrite

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills the image column indicated by the
                      input <row>

        $WARNING      NONE

        $PDL          - Checks the number of array elements
                      - Checks the array type
                      - Switch over the output image types
                            - Loop over the array elements
                                  - Fills the image row element
                            - End loop
                      - End switch

   $EH
   ========================================================================== */

void MATHPP_INTR_FillImaCol
                        (/*IN    */ MATHIT_array         sign_s,
                         /*IN    */ UINTx4               col,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN OUT*/ void               **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_FillImaCol";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   INTx4                 row;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the number of elements
   ========================================================================== */
   if ( sign_s.nelem < 1 ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_null_arr, "" );
   }

/* ==========================================================================
   Check the array type
   ========================================================================== */
   if ( sign_s.atype != MATHIE_complex ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_no_complex, "" );
   }

/* ==========================================================================
   Fill the input image row
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx1:
         for ( row=0; row<NRowInp; row++ ) {
            ((UINTx1 **)InpIma)[ row ][ col ] =
               (UINTx1)((((MATHIT_complex *)sign_s.ap)[ row ]).rea);
         }
      break;
      case LDEFIE_dt_UINTx2:
         for ( row=0; row<NRowInp; row++ ) {
            ((UINTx2 **)InpIma)[ row ][ col ] =
               (UINTx2)((((MATHIT_complex *)sign_s.ap)[ row ]).rea);
         }
      break;
      case LDEFIE_dt_float:
         for ( row=0; row<NRowInp; row++ ) {
            ((float **)InpIma)[ row ][ col ] =
               (float)((((MATHIT_complex *)sign_s.ap)[ row ]).rea);
         }
      break;
      case LDEFIE_dt_2_INTx2:
         for ( row=0; row<NRowInp; row++ ) {
            ((INTx2 **)InpIma)[ row ][ 2 * col ] =
               (INTx2)((((MATHIT_complex *)sign_s.ap)[ row ]).rea);
            ((INTx2 **)InpIma)[ row ][ 2 * col + 1 ] =
               (INTx2)((((MATHIT_complex *)sign_s.ap)[ row ]).ima);
         }
      break;
      case LDEFIE_dt_2_float:
         for ( row=0; row<NRowInp; row++ ) {
            ((float **)InpIma)[ row ][ 2 * col ] =
               (((MATHIT_complex *)sign_s.ap)[ row ]).rea;
            ((float **)InpIma)[ row ][ 2 * col + 1 ] =
               (((MATHIT_complex *)sign_s.ap)[ row ]).ima;
         }
      break;
      default:
        ERRSIM_set_error ( status_code, ERRSID_MATH_data_type_not_allow,
                           "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_FillImaCol */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillArray

        $TYPE         PROCEDURE

        $INPUT        InpIma   : input image block
                      NRowInp  : number of rows of the image block
                      NColInp  : number of columns of the image block
                      DataType : input image block data type

        $MODIFIED     NONE

        $OUTPUT       array    : output array containing the 2D input matrix

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_negative_dimen
                      ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills an array with the 2D image block
                      given in input in a sequential manner

        $WARNING      NONE

        $PDL          - Checks the number of rows and columns of the input
                        image block
                      - Checks the number of elements of the output array
                      - Checks the array type
                      - Switch over the input image block data type
                            - Loop over the input image block rows
                                  - Loop over the row elements
                                        - Fills the array element
                                  - End loop
                            - End loop
                      - End switch

   $EH
   ========================================================================== */

void MATHPP_INTR_FillArray
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *array,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_FillArray";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 row;
   UINTx4                 col;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the number of image elements
   ========================================================================== */
   if ( ( NRowInp < 1 ) || ( NColInp < 1 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_negative_dimen, "" );
   }

/* ==========================================================================
   Check the consistency of the array and the image block
   ========================================================================== */
   if ( array->nelem < (INTx4)(NRowInp * NColInp) ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_no_suff_arr_elem, "" );
   }

/* ==========================================================================
   Check the array type
   ========================================================================== */
   if ( array->atype != MATHIE_complex ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_no_complex, "" );
   }

/* ==========================================================================
   Fill the array
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx1:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               (((MATHIT_complex *)array->ap)[ row * NColInp + col ]).rea =
               (float)(((UINTx1 **)InpIma)[ row ][ col ]);
            }
         }
      break;
      case LDEFIE_dt_UINTx2:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               (((MATHIT_complex *)array->ap)[ row * NColInp + col ]).rea =
               (float)(((UINTx2 **)InpIma)[ row ][ col ]);
            }
         }
      break;
      case LDEFIE_dt_float:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               (((MATHIT_complex *)array->ap)[ row * NColInp + col ]).rea =
               ((float **)InpIma)[ row ][ col ];
            }
         }
      break;
      case LDEFIE_dt_2_INTx2:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               (((MATHIT_complex *)array->ap)[ row * NColInp + col ]).rea =
                  (float)(((INTx2 **)InpIma)[ row ][ 2 * col ]);
               (((MATHIT_complex *)array->ap)[ row * NColInp + col ]).ima =
                  (float)(((INTx2 **)InpIma)[ row ][ 2 * col + 1 ]);
            }
         }
      break;
      case LDEFIE_dt_2_float:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               (((MATHIT_complex *)array->ap)[ row * NColInp + col ]).rea =
                  ((float **)InpIma)[ row ][ 2 * col ];
               (((MATHIT_complex *)array->ap)[ row * NColInp + col ]).ima =
                  ((float **)InpIma)[ row ][ 2 * col + 1 ];
            }
         }
      break;
      default:
         ERRSIM_set_error ( status_code, ERRSID_MATH_data_type_not_allow, "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_FillArray */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHPP_INTR_FillImage

        $TYPE         PROCEDURE

        $INPUT        sign_s   : array to copy
                      NColInp  : number of image columns
                      NRowInp  : number of image rows
                      DataType : data type of the output image

        $MODIFIED     NONE

        $OUTPUT       OutIma   : image to rewrite

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_no_complex
                      ERRSID_MATH_data_type_not_allow

        $DESCRIPTION  This procedure fills the image from the sequentially
                      written array

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHPP_INTR_FillImage
                        (/*IN    */ MATHIT_array         sign_s,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ void               **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHPP_INTR_FillImage";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables 
   ========================================================================== */
   INTx4                 row;
   INTx4                 col;

/* ==========================================================================
   Default initialization
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Check the number of elements
   ========================================================================== */
   if ( sign_s.nelem < 1 ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_null_arr, "" );
   }

/* ==========================================================================
   Check the array type
   ========================================================================== */
   if ( sign_s.atype != MATHIE_complex ) {
      ERRSIM_set_error ( status_code, ERRSID_MATH_no_complex, "" );
   }

/* ==========================================================================
   Fill the input image
   ========================================================================== */
   switch ( DataType ) {
      case LDEFIE_dt_UINTx1:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               ((UINTx1 **)InpIma)[ row ][ col ] = (UINTx1)
                  ((((MATHIT_complex *)sign_s.ap)[ row * NColInp + col ]).rea);
            }
         }
      break;
      case LDEFIE_dt_UINTx2:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               ((UINTx2 **)InpIma)[ row ][ col ] = (UINTx2)
                  ((((MATHIT_complex *)sign_s.ap)[ row * NColInp + col ]).rea);
            }
         }
      break;
      case LDEFIE_dt_float:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               ((float **)InpIma)[ row ][ col ] =
                  (((MATHIT_complex *)sign_s.ap)[ row * NColInp + col ]).rea;
            }
         }
      break;
      case LDEFIE_dt_2_INTx2:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               ((INTx2 **)InpIma)[ row ][ 2 * col ] = (INTx2)
                  ((((MATHIT_complex *)sign_s.ap)[ row * NColInp + col ]).rea);
               ((INTx2 **)InpIma)[ row ][ 2 * col + 1 ] = (INTx2)
                  ((((MATHIT_complex *)sign_s.ap)[ row * NColInp + col ]).ima);
            }
         }
      break;
      case LDEFIE_dt_2_float:
         for ( row=0; row<NRowInp; row++ ) {
            for ( col=0; col<NColInp; col++ ) {
               ((float **)InpIma)[ row ][ 2 * col ] =
                  (((MATHIT_complex *)sign_s.ap)[ row * NColInp + col ]).rea;
               ((float **)InpIma)[ row ][ 2 * col + 1 ] =
                  (((MATHIT_complex *)sign_s.ap)[ row * NColInp + col ]).ima;
            }
         }
      break;
      default:
        ERRSIM_set_error ( status_code, ERRSID_MATH_data_type_not_allow,
                           "" );
   }

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHPP_INTR_FillImage */

#ifdef __EXAM__
/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_

        $TYPE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_INTR_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "MATHIP_INTR_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

}/* MATHIP_INTR_ */
#endif
