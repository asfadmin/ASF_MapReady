/* ==========================================================================
   $MODULE_HEADER

      $NAME              BUFS_LIBS

      $FUNCTION          

      $ROUTINE           BUFS_LIBS

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       08-OCT-97     AN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */


#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include BUFS_INTF_H
#include BUFS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_init_buffers

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Set the BUFSPV_gid global structure

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void BUFSIP_init_buffers
                       ( /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "BUFSIP_init_buffers";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

   for( i=0; i< BUFSPD_max_buffers; i++) {
      BUFSPV_gid[ i ].used = FALSE;
      BUFSPV_gid[ i ].p_data = (void *) NULL;
      BUFSPV_gid[ i ].line_buff = (void *) NULL;
      BUFSPV_gid[ i ].r_w = '\0';
      BUFSPV_gid[ i ].n_rows = 0;
      BUFSPV_gid[ i ].n_columns = 0;
      BUFSPV_gid[ i ].sample_per_pixel = 0;
      BUFSPV_gid[ i ].data_type = LDEFIE_dt_undef;
  }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* BUFSIP_init_buffers */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_open_buffer

        $TYPE	      PROCEDURE

        $INPUT        Buffer   : pointer to the buffer
                      NRows    : number of rows of the buffer
                      NColumns : number of columns of the buffer
                      DataType : descriptor of the type of buffer
                      mode     : mode of the buffer ( read = 'r' or write = 'w' )

        $MODIFIED     The global variable describing the buffer is filled

        $OUTPUT       chan     : channel assigned to the buffer

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_neg_dimensions
                      ERRSID_BUFS_mode_not_set
                      ERRSID_BUFS_max_chan
                      ERRSID_BUFS_not_allow_data_type

        $DESCRIPTION  This procedure fills the structure assigned to each buffer
                      and returns the first free chennel among that allowable
                      for the buffers

        $WARNING      NONE

        $PDL          - Makes the necessary checks on the parameters
                      - Checks the number of rows and columns
                      - Checks the mode of the buffer
                      - Searches for a free channel
                      - Checks the channel number
                      - Points the pointer in the structure to the buffer
                      - Fills the structure fields corresponding to the numbers
                        of rows and columns and mode
                      - Checks the buffer data type
                      - Fills the structure field of data type

   $EH
   ========================================================================== */
void BUFSIP_open_buffer
                       ( /*IN    */ void                *Buffer,
                         /*IN    */ UINTx4               NRows,
                         /*IN    */ UINTx4               NColumns,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ char                 mode,
                         /*   OUT*/ UINTx4              *chan,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "BUFSIP_open_buffer";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code);

/* ==========================================================================
   Check the input dimensions
   ========================================================================== */
   if ( ( NRows == 0 ) || ( NColumns == 0 ) ) {
      ERRSIM_set_error ( status_code, ERRSID_BUFS_neg_dimensions, "" );
   }

/* ==========================================================================
   Check the mode of the buffer
   ========================================================================== */
   if ( ( tolower ( mode ) != 'r' ) && ( tolower ( mode ) != 'w' ) ) {
      ERRSIM_set_error ( status_code, ERRSID_BUFS_mode_not_set, "" );
   }

/* ==========================================================================
   Evaluate the channel
   ========================================================================== */
   *chan = 0;
   while ( BUFSPV_gid[ *chan ].used ) {
      (*chan) ++;
   }

/* ==========================================================================
   Set the channel used
   ========================================================================== */
   BUFSPV_gid[ *chan ].used = TRUE;

/* ==========================================================================
   Check the free channel
   ========================================================================== */
   if ( *chan >= BUFSPD_max_buffers ) {
      ERRSIM_set_error ( status_code, ERRSID_BUFS_max_chan, "" );
   }

/* ==========================================================================
   Make the structure pointer to point to the buffer
   ========================================================================== */
   BUFSPV_gid[ *chan ].p_data = (void *)Buffer;

/* ==========================================================================
   Set the mode
   ========================================================================== */
   BUFSPV_gid[ *chan ].r_w = tolower ( mode );

/* ==========================================================================
   Fill the number of rows and columns
   ========================================================================== */
   BUFSPV_gid[ *chan ].n_rows = (UINTx4)NRows;
   BUFSPV_gid[ *chan ].n_columns = (UINTx4)NColumns;

/* ==========================================================================
   Switch WRT the data type
   ========================================================================== */
   switch ( DataType) {
      case LDEFIE_dt_UINTx1:
      case LDEFIE_dt_UINTx2:
      case LDEFIE_dt_INTx2:
      case LDEFIE_dt_UINTx4:
      case LDEFIE_dt_INTx4:
      case LDEFIE_dt_float:
         BUFSPV_gid[ *chan ].sample_per_pixel = 1;
         break;

      case LDEFIE_dt_2_UINTx1:
      case LDEFIE_dt_2_INTx2:
      case LDEFIE_dt_2_float:
         BUFSPV_gid[ *chan ].sample_per_pixel = 2;
         break;

      default:
         ERRSIM_set_error ( status_code, ERRSID_BUFS_not_allow_data_type, "" );
   }

/* ==========================================================================
   Fill the data type
   ========================================================================== */
   BUFSPV_gid[ *chan ].data_type = DataType;

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* BUFSIP_open_buffer */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_close_buffer

        $TYPE	      PROCEDURE

        $INPUT        chan     : buffer channel

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_neg_dimensions
                      ERRSID_BUFS_mode_not_set
                      ERRSID_BUFS_max_chan
                      ERRSID_BUFS_not_allow_data_type

        $DESCRIPTION  This procedure fills the structure assigned to each buffer
                      and returns the first free chennel among that allowable
                      for the buffers

        $WARNING      NONE

        $PDL          - Nulls the structure field of data type

   $EH
   ========================================================================== */
void BUFSIP_close_buffer
                       ( /*IN    */ UINTx4               chan,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "BUFSIP_close_buffer";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code);

/* ==========================================================================
   Check the chan number
   ========================================================================== */
   if ( chan >= BUFSPD_max_buffers ) {
      ERRSIM_set_error ( status_code, ERRSID_BUFS_max_chan, "" );
   }

/* ==========================================================================
   Set the channel NOT used 
   ========================================================================== */
   BUFSPV_gid[ chan ].used = FALSE;

/* ==========================================================================
   Null the pointer pointing to the buffer
   ========================================================================== */
   BUFSPV_gid[ chan ].p_data = (void *) NULL;

/* ==========================================================================
   Null the mode
   ========================================================================== */
   BUFSPV_gid[ chan ].r_w = '\0';

/* ==========================================================================
   Null the number of rows and columns
   ========================================================================== */
   BUFSPV_gid[ chan ].n_rows = 0;
   BUFSPV_gid[ chan ].n_columns = 0;

/* ==========================================================================
   Null the number of sample per pixel
   ========================================================================== */
   BUFSPV_gid[ chan ].sample_per_pixel = 0;

/* ==========================================================================
   Null the data type
   ========================================================================== */
   BUFSPV_gid[ chan ].data_type = LDEFIE_dt_undef;

error_exit:;

   ERRSIM_close_routine ( routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

} /* BUFSIP_close_buffer */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_open_line

        $TYPE	      PROCEDURE

        $INPUT        chan        : buffer number
		      direction   : 'x' or 'y'
		      samplestart : first sample in line
		      sampleend   : last sample in line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_max_chan
                      ERRSID_BUFS_not_allow_data_type
                      ERRSID_BUFS_mode_not_set

        $DESCRIPTION  This procedure opens the reading or the writing of a line
                      buffer.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void BUFSIP_open_line
                       (/*IN    */ UINTx4               chan,
                        /*IN    */ char                 direction,
                        /*IN    */ UINTx4               samplestart,
                        /*IN    */ UINTx4               sampleend,
                        /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "BUFSIP_open_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 nelem;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code);

/* ==========================================================================
   Check the channel number
   ========================================================================== */
   if ( chan >= BUFSPD_max_buffers ) {
      ERRSIM_set_error ( status_code, ERRSID_BUFS_max_chan, "" );
   }

/* ==========================================================================
   Fill the global structure
   ========================================================================== */
   BUFSPV_gid[ chan ].direction = tolower ( direction );
   BUFSPV_gid[ chan ].start_line = (UINTx4) samplestart;
   BUFSPV_gid[ chan ].end_line = (UINTx4) sampleend;

/* ==========================================================================
   Allocate the line_buff of current line
   ========================================================================== */
   if ( tolower ( BUFSPV_gid[ chan ].r_w ) == 'r' ) {
/* ==========================================================================
   Switch WRT the data type
   ========================================================================== */
      switch ( BUFSPV_gid[ chan ].data_type ) {
         case LDEFIE_dt_2_UINTx1:
         case LDEFIE_dt_UINTx1:

/* ==========================================================================
   Evaluate the number of bytes to allocate in the line
   ========================================================================== */
	    nelem = BUFSPV_gid[ chan ].sample_per_pixel *
	       ( BUFSPV_gid[ chan ].end_line -
		 BUFSPV_gid[ chan ].start_line + 1 ) *
	       sizeof ( UINTx1 );

/* ==========================================================================
   Allocate the line
   ========================================================================== */
	    if ( ( BUFSPV_gid[ chan ].line_buff = (UINTx1 *)
		      MEMSIP_realloc ( BUFSPV_gid[ chan ].line_buff,
				       (size_t)nelem ) )== (UINTx1 *)NULL ) {
	       ERRSIM_set_error ( status_code,
				  ERRSID_BUFS_err_mem_alloc,
				  "" );
	    }
            break;

         case LDEFIE_dt_UINTx2:

/* ==========================================================================
   UINTx2 data ... see comment above
   ========================================================================== */
	    nelem = BUFSPV_gid[ chan ].sample_per_pixel *
	       ( BUFSPV_gid[ chan ].end_line -
		 BUFSPV_gid[ chan ].start_line + 1 ) *
	       sizeof ( UINTx2 );
	    if ( ( BUFSPV_gid[ chan ].line_buff = (UINTx2 *)
		      MEMSIP_realloc ( BUFSPV_gid[ chan ].line_buff,
				       (size_t)nelem ) )== (UINTx2 *)NULL ) {
	       ERRSIM_set_error ( status_code,
				  ERRSID_BUFS_err_mem_alloc,
				  "" );
	    }
            break;

         case LDEFIE_dt_INTx2:

/* ==========================================================================
   INTx2 data ... see comment above
   ========================================================================== */
	    nelem = BUFSPV_gid[ chan ].sample_per_pixel *
	       ( BUFSPV_gid[ chan ].end_line -
		 BUFSPV_gid[ chan ].start_line + 1 ) *
	       sizeof ( INTx2 );
	    if ( ( BUFSPV_gid[ chan ].line_buff = (INTx2 *)
		      MEMSIP_realloc ( BUFSPV_gid[ chan ].line_buff,
				       (size_t)nelem ) )== (INTx2 *)NULL ) {
	       ERRSIM_set_error ( status_code,
				  ERRSID_BUFS_err_mem_alloc,
				  "" );
	    }
            break;

         case LDEFIE_dt_UINTx4:

/* ==========================================================================
   UINTx4 data ... see comment above
   ========================================================================== */
	    nelem = BUFSPV_gid[ chan ].sample_per_pixel *
	       ( BUFSPV_gid[ chan ].end_line -
		 BUFSPV_gid[ chan ].start_line + 1 ) *
	       sizeof ( UINTx4 );
	    if ( ( BUFSPV_gid[ chan ].line_buff = (UINTx4 *)
		      MEMSIP_realloc ( BUFSPV_gid[ chan ].line_buff,
				       (size_t)nelem ) )== (UINTx4 *)NULL ) {
	       ERRSIM_set_error ( status_code,
				  ERRSID_BUFS_err_mem_alloc,
				  "" );
	    }
            break;

         case LDEFIE_dt_INTx4:

/* ==========================================================================
   INTx4 data ... see comment above
   ========================================================================== */
	    nelem = BUFSPV_gid[ chan ].sample_per_pixel *
	       ( BUFSPV_gid[ chan ].end_line -
		 BUFSPV_gid[ chan ].start_line + 1 ) *
	       sizeof ( INTx4 );
	    if ( ( BUFSPV_gid[ chan ].line_buff = (INTx4 *)
		      MEMSIP_realloc ( BUFSPV_gid[ chan ].line_buff,
				       (size_t)nelem ) )== (INTx4 *)NULL ) {
	       ERRSIM_set_error ( status_code,
				  ERRSID_BUFS_err_mem_alloc,
				  "" );
	    }
            break;

         case LDEFIE_dt_2_INTx2:

/* ==========================================================================
   INTx2 data ... see comment above
   ========================================================================== */
	    nelem = BUFSPV_gid[ chan ].sample_per_pixel *
	       ( BUFSPV_gid[ chan ].end_line -
		 BUFSPV_gid[ chan ].start_line + 1 ) *
	       sizeof ( INTx2 );
	    if ( ( BUFSPV_gid[ chan ].line_buff = (INTx2 *)
		      MEMSIP_realloc ( BUFSPV_gid[ chan ].line_buff,
				       (size_t)nelem ) )== (INTx2 *)NULL ) {
	       ERRSIM_set_error ( status_code,
				  ERRSID_BUFS_err_mem_alloc,
				  "" );
	    }
            break;

	 case LDEFIE_dt_float:
	 case LDEFIE_dt_2_float:
	    nelem = BUFSPV_gid[ chan ].sample_per_pixel *
	       ( BUFSPV_gid[ chan ].end_line -
		 BUFSPV_gid[ chan ].start_line + 1 ) *
	       sizeof ( float );
	    if ( ( BUFSPV_gid[ chan ].line_buff = (float *)
		      MEMSIP_realloc ( BUFSPV_gid[ chan ].line_buff,
				       (size_t)nelem ) )== (float *)NULL ) {
	       ERRSIM_set_error ( status_code,
				  ERRSID_BUFS_err_mem_alloc,
				  "" );
	    }
            break;

	 default:
	     ERRSIM_set_error ( status_code, ERRSID_BUFS_not_allow_data_type,
				"" );
      }
   }
   else  {
      if ( tolower ( BUFSPV_gid[ chan ].r_w ) != 'w' ) {
	 ERRSIM_set_error ( status_code, ERRSID_BUFS_mode_not_set, "" );
      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* BUFSIP_open_line */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_read_block

        $TYPE	      PROCEDURE

        $INPUT        chan       : buffer channel
                      firstline  : first line to be read
		      lastline   : last line to read

        $MODIFIED     NONE

        $OUTPUT       buff       : double pointer to the output block

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_bad_dimensions
	              ERRSID_BUFS_err_no_block
                      ERRSID_BUFS_not_allow_data_type

        $DESCRIPTION  This procedure reads a block of lines from memory buffers.

        $WARNING      NONE

   $EH
   ========================================================================== */
void BUFSIP_read_block
                      ( /*IN    */ UINTx4               chan,
                        /*IN    */ UINTx4               firstline,
			/*IN    */ UINTx4               lastline,
                        /*   OUT*/ void               **buff,
                        /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "BUFSIP_read_block";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 line, nelem;
   void                  *temp;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the channel
   ========================================================================== */
   if ( chan >= BUFSPD_max_buffers ) {
      ERRSIM_set_error ( status_code, ERRSID_BUFS_max_chan, "" );
   }

/* ==========================================================================
   Check start and stop line consistency
   ========================================================================== */
   if ( lastline < firstline ) {
      ERRSIM_set_error( status_code, 
                        ERRSID_BUFS_bad_dimensions, 
                        "firstline/lastline" );
   }

/* ==========================================================================
   Switch between the two possible directions
   ========================================================================== */
   switch ( tolower( BUFSPV_gid[ chan ].direction ) ) {
      case 'x':
/* ==========================================================================
   Read by rows
   ========================================================================== */
         if ( lastline > BUFSPV_gid[ chan ].n_rows ) {
            ERRSIM_set_error( status_code, 
                              ERRSID_BUFS_bad_dimensions, 
                              "lastline" );
         }
         break;

      case 'y':
/* ==========================================================================
   Read by columns
   ========================================================================== */
         if ( lastline > BUFSPV_gid[ chan ].n_columns ) {
            ERRSIM_set_error( status_code, 
                              ERRSID_BUFS_bad_dimensions, 
                              "lastline" );
         }
         break;

   }

   for ( line=firstline; line<=lastline; line++ ) {

/* ==========================================================================
   Read the line
   ========================================================================== */
      BUFSIP_read_line(  chan,
                         line,
			&temp,
			 status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Evaluate the number of elements
   ========================================================================== */
      nelem = BUFSPV_gid[ chan ].sample_per_pixel *
	       ( BUFSPV_gid[ chan ].end_line -
	         BUFSPV_gid[ chan ].start_line + 1 );

/* ==========================================================================
   Switch WRT the data type
   ========================================================================== */
      switch ( BUFSPV_gid[ chan ].data_type ) {
	 case LDEFIE_dt_UINTx1:
	 case LDEFIE_dt_2_UINTx1:
            memcpy( buff[ line - firstline ], temp, (size_t)( nelem * sizeof (UINTx1) ));
            break;

         case LDEFIE_dt_UINTx2:
            memcpy( buff[ line - firstline ], temp, (size_t)( nelem * sizeof (UINTx2) ));
	    break;

         case LDEFIE_dt_INTx2:
            memcpy( buff[ line - firstline ], temp, (size_t)( nelem * sizeof (INTx2) ));
	    break;

         case LDEFIE_dt_UINTx4:
            memcpy( buff[ line - firstline ], temp, (size_t)( nelem * sizeof (UINTx4) ));
	    break;

         case LDEFIE_dt_INTx4:
            memcpy( buff[ line - firstline ], temp, (size_t)( nelem * sizeof (INTx4) ));
	    break;

	 case LDEFIE_dt_2_INTx2:
            memcpy( buff[ line - firstline ], temp, (size_t)( nelem * sizeof (INTx2) ));
	    break;

	 case LDEFIE_dt_float:
	 case LDEFIE_dt_2_float:
            memcpy( buff[ line -firstline ], temp, (size_t)( nelem * sizeof (float) ));
	    break;

	 default:
            ERRSIM_set_error ( status_code, ERRSID_BUFS_not_allow_data_type,
			       "" );
      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* BUFSIP_read_block */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_read_line

        $TYPE	      PROCEDURE

        $INPUT        chan       : buffer channel
                      linenumber : line to be read

        $MODIFIED     NONE

        $OUTPUT       bufout     : address of pointer to void buffer

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_max_chan
                      ERRSID_BUFS_not_allow_data_type

        $DESCRIPTION  This procedure reads a line from memory buffers.

        $WARNING      NONE

   $EH
   ========================================================================== */
void BUFSIP_read_line
                      ( /*IN    */ UINTx4               chan,
                        /*IN    */ UINTx4               linenumber,
                        /*   OUT*/ void               **bufout,
                        /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "BUFSIP_read_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 nelem;
   UINTx4                 counter;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the channel
   ========================================================================== */
   if ( chan >= BUFSPD_max_buffers ) {
      ERRSIM_set_error ( status_code, ERRSID_BUFS_max_chan, "" );
   }

/* ==========================================================================
   Switch WRT the direction
   ========================================================================== */
   switch ( tolower ( BUFSPV_gid[ chan ].direction ) ) {
      case 'x': {
	 void *p = (void *)NULL;

/* ==========================================================================
   Evaluate the number of elements to read
   ========================================================================== */
	 nelem = BUFSPV_gid[ chan ].sample_per_pixel *
	    ( BUFSPV_gid[ chan ].end_line -
	      BUFSPV_gid[ chan ].start_line + 1 );

/* ==========================================================================
   Evaluate the starting position in the source vector
   ========================================================================== */
	 counter = BUFSPV_gid[ chan ].sample_per_pixel *
	    ( linenumber * BUFSPV_gid[ chan ].n_columns +
	      BUFSPV_gid[ chan ].start_line );

/* ==========================================================================
   Switch WRT the data type
   ========================================================================== */
	 switch ( BUFSPV_gid[ chan ].data_type ) {
	    case LDEFIE_dt_UINTx1:
	    case LDEFIE_dt_2_UINTx1:

/* ==========================================================================
   Point to the right buffer
   ========================================================================== */
	       p = (void *)
		  ( (UINTx1 *)(BUFSPV_gid[ chan ].p_data) + counter );

/* ==========================================================================
   Copy the line of data in the buffer
   ========================================================================== */
	       memcpy ( BUFSPV_gid[ chan ].line_buff, p,
			(size_t)( nelem * sizeof (UINTx1) ) );
	       break;

	    case LDEFIE_dt_UINTx2:

/* ==========================================================================
   Copy the line ... see comment above
   ========================================================================== */
	       p = (void *)
		  ( (UINTx2 *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( BUFSPV_gid[ chan ].line_buff, p,
			(size_t)( nelem * sizeof (UINTx2) ) );
	       break;

	    case LDEFIE_dt_INTx2:

/* ==========================================================================
   Copy the line ... see comment above
   ========================================================================== */
	       p = (void *)
		  ( (INTx2 *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( BUFSPV_gid[ chan ].line_buff, p,
			(size_t)( nelem * sizeof (INTx2) ) );
	       break;

	    case LDEFIE_dt_UINTx4:

/* ==========================================================================
   Copy the line ... see comment above
   ========================================================================== */
	       p = (void *)
		  ( (UINTx4 *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( BUFSPV_gid[ chan ].line_buff, p,
			(size_t)( nelem * sizeof (UINTx4) ) );
	       break;

	    case LDEFIE_dt_INTx4:

/* ==========================================================================
   Copy the line ... see comment above
   ========================================================================== */
	       p = (void *)
		  ( (INTx4 *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( BUFSPV_gid[ chan ].line_buff, p,
			(size_t)( nelem * sizeof (INTx4) ) );
	       break;

	    case LDEFIE_dt_2_INTx2:
	       p = (void *)
		  ( (INTx2 *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( BUFSPV_gid[ chan ].line_buff, p,
			(size_t)( nelem * sizeof (INTx2) ) );
	       break;

	    case LDEFIE_dt_float:
	    case LDEFIE_dt_2_float:
	       p = (void *)
		  ( (float *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( BUFSPV_gid[ chan ].line_buff, p,
			(size_t)( nelem * sizeof ( float ) ) );
	       break;

	    default:
	       ERRSIM_set_error ( status_code, ERRSID_BUFS_not_allow_data_type,
				  "" );
	 }
      }
      break;

      case 'y': {
	 UINTx4                 el;
	 UINTx4                 ncol;

/* ==========================================================================
   Evaluate the number of elements to read
   ========================================================================== */
	 nelem = BUFSPV_gid[ chan ].end_line -
	    BUFSPV_gid[ chan ].start_line + 1;

/* ==========================================================================
   Evaluate the starting position in the source vector
   ========================================================================== */
	 counter = BUFSPV_gid[ chan ].sample_per_pixel *
	    ( BUFSPV_gid[ chan ].start_line *
	      BUFSPV_gid[ chan ].n_columns + linenumber );

/* ==========================================================================
   Evaluate the number of row elements
   ========================================================================== */
	 ncol = BUFSPV_gid[ chan ].n_columns *
	    BUFSPV_gid[ chan ].sample_per_pixel;

/* ==========================================================================
   Switch WRT the data type
   ========================================================================== */
	 switch ( BUFSPV_gid[ chan ].data_type ) {
	    case LDEFIE_dt_UINTx1:

/* ==========================================================================
   Copy the line of data in the buffer
   ========================================================================== */
	       for ( el=0;el<nelem;el++ ) {
		  ( (UINTx1 *) BUFSPV_gid[ chan ].line_buff) [ el ] =
		     *( (UINTx1 *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el );
	       }
	       break;

	    case LDEFIE_dt_2_UINTx1:

/* ==========================================================================
   Copy the line ... see comment above
   ========================================================================== */
	       for ( el=0;el<nelem;el++ ) {
		  ( (UINTx1 *) BUFSPV_gid[ chan ].line_buff)[ 2*el] =
		     *( (UINTx1 *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el );
		  ( (UINTx1 *) BUFSPV_gid[ chan ].line_buff)[2*el+1] =
		     *( (UINTx1 *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el + 1 );
	       }
	       break;

	    case LDEFIE_dt_UINTx2:
	       for ( el=0;el<nelem;el++ ) {
		  ( (UINTx2 *) BUFSPV_gid[ chan ].line_buff)[ el ] =
		     *( (UINTx2 *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el );
	       }
	       break;

	    case LDEFIE_dt_INTx2:
	       for ( el=0;el<nelem;el++ ) {
		  ( (INTx2 *) BUFSPV_gid[ chan ].line_buff)[ el ] =
		     *( (INTx2 *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el );
	       }
	       break;

	    case LDEFIE_dt_UINTx4:
	       for ( el=0;el<nelem;el++ ) {
		  ( (UINTx4 *) BUFSPV_gid[ chan ].line_buff)[ el ] =
		     *( (UINTx4 *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el );
	       }
	       break;

	    case LDEFIE_dt_INTx4:
	       for ( el=0;el<nelem;el++ ) {
		  ( (INTx4 *) BUFSPV_gid[ chan ].line_buff)[ el ] =
		     *( (INTx4 *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el );
	       }
	       break;

	    case LDEFIE_dt_2_INTx2:
	       for ( el=0;el<nelem;el++ ) {
		  ( (INTx2 *) BUFSPV_gid[ chan ].line_buff)[ 2*el ] =
		     *( (INTx2 *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el );
		  ( (INTx2 *) BUFSPV_gid[ chan ].line_buff)[2*el+1] =
		     *( (INTx2 *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el + 1 );
	       }
	       break;

	    case LDEFIE_dt_float:
	       for ( el=0;el<nelem;el++ ) {
		  ( (float *) BUFSPV_gid[ chan ].line_buff)[ el ] =
		     *( (float *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el );
	       }
	       break;

	    case LDEFIE_dt_2_float:
	       for ( el=0;el<nelem;el++ ) {
		  ( (float *) BUFSPV_gid[ chan ].line_buff)[ 2*el ] =
		     *( (float *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el );
		  ( (float *) BUFSPV_gid[ chan ].line_buff)[2*el+1] =
		     *( (float *)(BUFSPV_gid[ chan ].p_data) +
			counter + ncol * el + 1 );
	       }
	       break;

	    default:
	       ERRSIM_set_error ( status_code, ERRSID_BUFS_not_allow_data_type,
				  "" );
	 }
      }
   }

/* ==========================================================================
   Set out pointer to the internal line buffer
   ========================================================================== */
   *bufout = BUFSPV_gid[ chan ].line_buff;

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* BUFSIP_read_line */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_write_line

        $TYPE	      PROCEDURE

        $INPUT        chan       : buffer channel
                      linenumber : line to be read
                      bufin      : pointer to void buffer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_max_chan
                      ERRSID_BUFS_not_allow_data_type

        $DESCRIPTION  This procedure writes a line to buffers.

        $WARNING      NONE

        $PDL
	   -If la linea e' fuori dal buffer
	     -Salva il buffer dividendolo a blocks
	     -Aggiorna i flags relativi ai blocks salvati
	     -If tutti i blocks relativi allla linea da scrivere sono gia' 
              stati salvati 
	       -Carica i nuovi blocks relativi alla linea da scrivere
	     -Endif
	     -Aggiorna minline
	     -Ricopia la linea nel buffer
	   -Else la linea e' nel buffer
	     -Ricopia la linea nel buffer
	   -Endif                                     

   $EH
   ========================================================================== */
void BUFSIP_write_line ( /*IN    */ UINTx4               chan,
                         /*IN    */ UINTx4               linenumber,
                         /*   OUT*/ void                *bufin,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "BUFSIP_write_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   UINTx4                 nelem;
   UINTx4                 counter;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);
      
/* ==========================================================================
   Check the channel
   ========================================================================== */
   if ( chan >= BUFSPD_max_buffers ) {
      ERRSIM_set_error ( status_code, ERRSID_BUFS_max_chan, "" );
   }

/* ==========================================================================
   Switch WRT the direction
   ========================================================================== */
   switch ( tolower ( BUFSPV_gid[ chan ].direction ) ) {
      case 'x': {
	 void  *p = (void *)NULL;

/* ==========================================================================
   Evaluate the number of elements to read
   ========================================================================== */
	 nelem = BUFSPV_gid[ chan ].sample_per_pixel *
	    ( BUFSPV_gid[ chan ].end_line -
	      BUFSPV_gid[ chan ].start_line + 1 );

/* ==========================================================================
   Evaluate the starting position in the source vector
   ========================================================================== */
	 counter = BUFSPV_gid[ chan ].sample_per_pixel *
	    ( linenumber * BUFSPV_gid[ chan ].n_columns +
	      BUFSPV_gid[ chan ].start_line );

/* ==========================================================================
   Switch WRT the data type
   ========================================================================== */
	 switch ( BUFSPV_gid[ chan ].data_type ) {
	    case LDEFIE_dt_UINTx1:
	    case LDEFIE_dt_2_UINTx1:

/* ==========================================================================
   Point to the right buffer
   ========================================================================== */
	       p = (void *)
		  ( (UINTx1 *)(BUFSPV_gid[ chan ].p_data) + counter );

/* ==========================================================================
   Copy the line of data in the buffer
   ========================================================================== */
	       memcpy ( p, bufin, (size_t)( nelem * sizeof (UINTx1) ) );
	       break;

	    case LDEFIE_dt_UINTx2:

/* ==========================================================================
   Copy the line ... see comment above
   ========================================================================== */
	       p = (void *)
		  ( (UINTx2 *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( p, bufin, (size_t)( nelem * sizeof (UINTx2) ) );
	       break;

	    case LDEFIE_dt_INTx2:

/* ==========================================================================
   Copy the line ... see comment above
   ========================================================================== */
	       p = (void *)
		  ( (INTx2 *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( p, bufin, (size_t)( nelem * sizeof (INTx2) ) );
	       break;

	    case LDEFIE_dt_UINTx4:

/* ==========================================================================
   Copy the line ... see comment above
   ========================================================================== */
	       p = (void *)
		  ( (UINTx4 *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( p, bufin, (size_t)( nelem * sizeof (UINTx4) ) );
	       break;

	    case LDEFIE_dt_INTx4:

/* ==========================================================================
   Copy the line ... see comment above
   ========================================================================== */
	       p = (void *)
		  ( (INTx4 *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( p, bufin, (size_t)( nelem * sizeof (INTx4) ) );
	       break;

	    case LDEFIE_dt_2_INTx2:
	       p = (void *)
		  ( (INTx2 *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( p, bufin, (size_t)( nelem * sizeof (INTx2) ) );
	       break;

	    case LDEFIE_dt_float:
	    case LDEFIE_dt_2_float:
	       p = (void *)
		  ( (float *)(BUFSPV_gid[ chan ].p_data) + counter );
	       memcpy ( p, bufin, (size_t)( nelem * sizeof ( float ) ) );
	       break;

	    default:
	       ERRSIM_set_error ( status_code, ERRSID_BUFS_not_allow_data_type,
				  "" );
	 }
      }
      break;
      case 'y': {
	 UINTx4                 el;
	 UINTx4                 ncol;

/* ==========================================================================
   Evaluate the number of elements to read
   ========================================================================== */
         nelem = BUFSPV_gid[ chan ].end_line -
            BUFSPV_gid[ chan ].start_line + 1;

/* ==========================================================================
   Evaluate the starting position in the source vector
   ========================================================================== */
	 counter = BUFSPV_gid[ chan ].sample_per_pixel *
	    ( BUFSPV_gid[ chan ].start_line *
	      BUFSPV_gid[ chan ].n_columns + linenumber );

/* ==========================================================================
   Evaluate the number of row elements
   ========================================================================== */
	 ncol = BUFSPV_gid[ chan ].n_columns *
	    BUFSPV_gid[ chan ].sample_per_pixel;

/* ==========================================================================
   Switch WRT the data type
   ========================================================================== */
	 switch ( BUFSPV_gid[ chan ].data_type ) {
	    case LDEFIE_dt_UINTx1:

/* ==========================================================================
   Copy the line of data in the buffer
   ========================================================================== */
	       for ( el=0;el<nelem;el++ ) {
		  ( (UINTx1 *)(BUFSPV_gid[ chan ].p_data) )[ counter +
		     ncol * el ] =
		  ((UINTx1 *)bufin)[ el ];
	       }
	       break;

	    case LDEFIE_dt_2_UINTx1:

/* ==========================================================================
   Copy the line ... see comment above
   ========================================================================== */
	       for ( el=0;el<nelem;el++ ) {
		  ( (UINTx1 *)(BUFSPV_gid[ chan ].p_data) )[ counter +
		     ncol * el ] =
		  ((UINTx1 *)bufin)[ 2 * el ];
		  ( (UINTx1 *)(BUFSPV_gid[ chan ].p_data) )[ counter + 
		     ncol * el + 1 ] =
		  ((UINTx1 *)bufin)[ 2 * el + 1 ];
	       }
	       break;

	    case LDEFIE_dt_UINTx2:
	       for ( el=0;el<nelem;el++ ) {
		  ( (UINTx2 *)(BUFSPV_gid[ chan ].p_data) )[ counter + 
		     ncol * el ] =
		  ((UINTx2 *)(bufin))[ el ];
	       }
	       break;

	    case LDEFIE_dt_INTx2:
	       for ( el=0;el<nelem;el++ ) {
		  ( (INTx2 *)(BUFSPV_gid[ chan ].p_data) )[ counter + 
		     ncol * el ] =
		  ((INTx2 *)(bufin))[ el ];
	       }
	       break;

	    case LDEFIE_dt_UINTx4:
	       for ( el=0;el<nelem;el++ ) {
		  ( (UINTx4 *)(BUFSPV_gid[ chan ].p_data) )[ counter + 
		     ncol * el ] =
		  ((UINTx4 *)(bufin))[ el ];
	       }
	       break;

	    case LDEFIE_dt_INTx4:
	       for ( el=0;el<nelem;el++ ) {
		  ( (INTx4 *)(BUFSPV_gid[ chan ].p_data) )[ counter + 
		     ncol * el ] =
		  ((INTx4 *)(bufin))[ el ];
	       }
	       break;

	    case LDEFIE_dt_2_INTx2:
	       for ( el=0;el<nelem;el++ ) {
		  ( (INTx2 *)(BUFSPV_gid[ chan ].p_data) )[ counter + 
		     ncol * el ] =
		  ((INTx2 *)bufin)[ 2 * el ];
		  ( (INTx2 *)(BUFSPV_gid[ chan ].p_data) )[ counter + 
		     ncol * el + 1 ] =
		  ((INTx2 *)bufin)[ 2 * el + 1 ];
	       }
	       break;

	    case LDEFIE_dt_float:
	       for ( el=0;el<nelem;el++ ) {
		  ( (float *)(BUFSPV_gid[ chan ].p_data) )[ counter + 
		     ncol * el ] =
		  ((float *)bufin)[ el ];
	       }
	       break;

	    case LDEFIE_dt_2_float:
	       for ( el=0;el<nelem;el++ ) {
		  ( (float *)(BUFSPV_gid[ chan ].p_data) )[ counter +
		     ncol * el ] =
		  ((float *)bufin)[ 2 * el ];
		  ( (float *)(BUFSPV_gid[ chan ].p_data) )[ counter +
		     ncol * el + 1 ] =
		  ((float *)bufin)[ 2 * el + 1 ];
	       }
	       break;

	    default:
	       ERRSIM_set_error ( status_code, ERRSID_BUFS_not_allow_data_type,
				  "" );
	 }
      }
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* BUFSIP_write_line */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_close_line

        $TYPE	      PROCEDURE

        $INPUT        chan : buffer channel

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure close the reading or writing of a line on
                      buffers.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
void BUFSIP_close_line
                       ( /*IN    */ UINTx4               chan,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "BUFSIP_close_line";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the channel number
   ========================================================================== */
   if ( chan >= BUFSPD_max_buffers ) {
      ERRSIM_set_error ( status_code, ERRSID_BUFS_max_chan, "" );
   }

/* ==========================================================================
   Null the global structure
   ========================================================================== */
   BUFSPV_gid[ chan ].direction = '\0';
   BUFSPV_gid[ chan ].start_line = 0;
   BUFSPV_gid[ chan ].end_line = 0;

/* ==========================================================================
   Free the line buffer
   ========================================================================== */
   MEMSIP_free( (void **) &(BUFSPV_gid[ chan ].line_buff) );
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* BUFSIP_close_line */

#ifdef __SUBS__

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_LIBS_

        $TYPE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void BUFSIP_LIBS_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "BUFSIP_LIBS_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* BUFSIP_LIBS_ */
#endif
