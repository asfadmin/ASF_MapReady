/* ==========================================================================
   $MODULE_HEADER

      $NAME              IRES_UNDR

      $FUNCTION          This modulus contains the procedures for the image
                         undersampling

      $ROUTINE           IRESIP_UNDR_Interpolate
                         IRESIP_UNDR_ConvCore
			 IRESIP_UNDR_ConvCoreConstKern
                         IRESIF_UNDR_Convol
			 IRESIP_UNDR_ReadFilter
                         IRESPP_UNDR_AllocBlock

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       17-JUL-97     GRV      Initial Release
          SCR #5      27-NOV-97     AG       Changed checks of Kr and Kc and
                                             RStartW vs RStopW
          SCR #18      2-DEC-97     GRV      The kernel elements read from the
                                             filter file cannot be characters
          SCR #19      3-DEC-97     GRV      The error message on the output
                                             dimensions is improved
            N/A       25-FEB-98     AG       ERMAPPER Interfacing

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include <stdio.h>
#include <stdlib.h>
#ifdef __UNIX__
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#endif
#include <string.h>
#include <ctype.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include FILS_INTF_H
#include GIOS_INTF_H
#include SRVS_INTF_H
#include OVLS_INTF_H
#include IANN_INTF_H
#include IRES_INTF_H
#include IRES_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_UNDR_Interpolate

        $TYPE         PROCEDURE

        $INPUT        inp_chan	    : channel of the TTIFF file containing the
				      input image
                      inp_img	    : ID of the input image in the input file
                      inp_bpar	    : descriptor of the basic input parameters
                      imanum	    : ID of the input image among that of the
				      tool
                      TLRow	    : row coordinate of the top left pixel of
				      the input image to filter
                      TLCol	    : column coordinate of the top left pixel of
				      the input image to filter
                      nrow_inp	    : number of rows of the input image
                      ncol_inp	    : number of columns of the input image
                      nrow_out	    : number of rows of the output image
                      ncol_out	    : number of columns of the output image
                      kern_filename : name of the file containing the kernel
				      matrix to convolve with the input image
                      out_chan	    : channel of the file that will contain the
				      output filtered image
                      out_img	    : ID of the output image in the output file

        $MODIFIED     NONE

        $OUTPUT       The file that will contain the output filtered image is
		      filled

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the image
						  annotations of the <imanum>
						  image

        $RET_STATUS   ERRSID_IRES_imanum_not_allow
                      ERRSID_IRES_not_under_allow
                      ERRSID_IRES_start_stop_col_err
		      ERRSID_IRES_bad_kernel_dim
                      ERRSID_IRES_kernel_dim_high
		      ERRSID_IRES_no_over
                      ERRSID_IRES_err_mem_alloc

        $DESCRIPTION  This procedure undersamples the input image convolving it
		      with an user defined kernel.

        $WARNING      The input and the output TTIFF files must be initialized
		      and opened before calling the procedure

        $PDL	      - Make all the checks on the input parameters
		      - Read the kernel from the kernel file
		      - Make some consistency checks on the kernel sizes
		      - Check if the kernel is a constant one
		      - Interpolate the image

   $EH
   ========================================================================== */

void IRESIP_UNDR_Interpolate
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ char                *kern_filename,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIP_UNDR_Interpolate";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   float                **Kern = (float **)NULL;
   UINTx4                 Kr = 0;
   UINTx4                 Kc = 0;
   UINTx4                 i;
   UINTx4		  j;
   float                  val = 0.;
   LDEFIT_boolean	  const_kern = TRUE;
   double                 StepR;        /* row step */
   double                 StepC;        /* column step */

/* ==========================================================================
   Dummy variables to call Overlap & Save procedure
   ========================================================================== */
   UINTx4                 nVertices = 0;
   MATHIT_RC             *vertices = (MATHIT_RC *) NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the image number
   ========================================================================== */
   if ( imanum >= IANNID_NIMAMAX )
      ERRSIM_set_error( status_code, ERRSID_IRES_imanum_not_allow, "");

/* ==========================================================================
   Check the image type
   ========================================================================== */
   if ( IANNIV_ImageAnnot[ imanum ].SamplePerPixel != 1 )
      ERRSIM_set_error( status_code, ERRSID_IRES_not_under_allow, "" );

/* ==========================================================================
   Check the consistency of the requirements
   ========================================================================== */
   if ( ( TLRow + nrow_inp > IANNIV_ImageAnnot[ imanum ].ImageLength ) ||
        ( TLCol + ncol_inp > IANNIV_ImageAnnot[ imanum ].ImageWidth ) )
      ERRSIM_set_error( status_code, ERRSID_IRES_start_stop_col_err, "" );

/* ==========================================================================
   Read the filter file
   ========================================================================== */
   IRESIP_UNDR_ReadFilter( kern_filename, &Kern, &Kr, &Kc, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check the filter sizes consistency
   ========================================================================== */
   if ( ( Kr > nrow_inp ) || ( Kc > ncol_inp ) )
      ERRSIM_set_error( status_code, ERRSID_IRES_kernel_dim_high, "" );

/* ==========================================================================
   Check the output dimensions consistency
   ========================================================================== */
   if ( ( nrow_out >= nrow_inp - Kr + 1 ) || ( ncol_out >= ncol_inp - Kc + 1 ) )
      ERRSIM_set_error( status_code, ERRSID_IRES_no_undersampling,
                        "considering the filter transients" );

/* ==========================================================================
   Fill the global variable with the filter coordinates
   ========================================================================== */
   IRESIV_FilterSizeRow = Kr;
   IRESIV_FilterSizeCol = Kc;

/* ==========================================================================
   Steps evaluation
   ========================================================================== */
   StepR = (double) SRVSIM_step( nrow_inp, Kr, nrow_out );
   StepC = (double) SRVSIM_step( ncol_inp, Kc, ncol_out );

/* ==========================================================================
   Check if the kernel is constant
   ========================================================================== */
   val = Kern[ 0 ][ 0 ];
   for ( i=0; i<Kr; i++ ) {
      for ( j=0; j<Kc; j++ ) {
	 if ( Kern[ i ][ j ] != val )
	    const_kern = FALSE;
      }
   }

/* ==========================================================================
   Evaluate the input image data type
   IRESPP_OVER_SetDataType ( inp_io, &inp_data_type, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );
   ========================================================================== */

/* ==========================================================================
   Interpolate the image
   ========================================================================== */
   if ( const_kern ) {
      OVLSIP_OverlapAndSave( inp_io, imanum, TLRow, TLCol,
                             nrow_inp, ncol_inp, nVertices, vertices, Kern,
                             Kr, Kc, StepR, StepC, out_io, nrow_out,
                             ncol_out, IRESIP_UNDR_ConvCoreConstKern, 
                             (float) 0, (INTx4) 0, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

   }
   else {
      OVLSIP_OverlapAndSave( inp_io, imanum, TLRow, TLCol,
                             nrow_inp, ncol_inp, nVertices, vertices, Kern,
                             Kr, Kc, StepR, StepC, out_io, nrow_out,
                             ncol_out, IRESIP_UNDR_ConvCore, (float) 0, 
                             (INTx4) 0, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

error_exit:;

/* ==========================================================================
   Free the allocated memories
   ========================================================================== */
   if ( Kern != (float **)NULL )
      for ( i=0; i<Kr; i++ ) MEMSIP_free( (void *)(&Kern[ i ]) );
   MEMSIP_free( (void *)(&Kern) );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IRESIP_UNDR_Interpolate */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_UNDR_ReadFilter

        $TYPE         PROCEDURE

        $INPUT        kern_filename : name of the ASCII file to be read

        $MODIFIED     NONE

        $OUTPUT       Kern	    : pointer to the pointer to the matrix that
				      will return filled
		      Kr	    : number of rows of the matrix
		      Kc	    : number of columns of the matrix

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_error_read_kern
		      ERRSID_IRES_no_elem_kern
		      ERRSID_IRES_kern_spec_not_good
		      ERRSID_IRES_err_mem_alloc

        $DESCRIPTION  This procedure read an ASCII file containing a matrix of
		      floating point objects returning also its number of rows
		      and columns

        $WARNING      - The only consistency required on the read values is that
			the number of rows is equals to the number of file rows
			and the number of columns is the same of the first row
			written in the file.
		      - The matrix can be written also as a row and a column.
			The procedure returns, in this case, the matrix product
			of the two vectors
		      - The kernel matrix is allocated in this procedure but
			must be deallocated in the caller of it

        $PDL	      - Open the kernel file name
		      - Read the first line
		      - Count the number of kernel columns
		      - Read the second line
		      - IF the kernel is a 2D matrix
			   - Loop overl the matrix rows
				 - Loop over the columns elements
				       - Fill the matrix element
				 - End loop
			   - End loop
		      - End IF
		      - ELSE IF there are two 1D vectors
			   - Fill the row vector
			   - Loop over the elements of the column vector
				 - Read and fill the column vector
			   - End loop
			   - Fill the 2D matrix with the matricial product of
			     the row vector time the column one
		      - End ELSE
		      - Close the kernel file name

   $EH
   ========================================================================== */

void IRESIP_UNDR_ReadFilter
                        (/*IN    */ char                *kern_filename,
                         /*   OUT*/ float             ***Kern,
			 /*   OUT*/ UINTx4	        *Kr,
			 /*   OUT*/ UINTx4              *Kc,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIP_UNDR_ReadFilter";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   FILE			 *finp = (FILE *)NULL;
   char			 *p = (char *)NULL;
   char			  str[ LDEFID_char_num ] = "";
   UINTx1		  count = 0;
   UINTx1		  elem = 0;
   INTx4		  i;
   INTx4		  j;
   float                  tmp;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC ( ERRSID_normal );
   log_status_code = STC ( ERRSID_normal );

   ERRSIM_init_routine ( routine_name, 
                         &process_flag,
                         &log_status_code );

/* ==========================================================================
   Open the input filter file
   ========================================================================== */
   FILSIP_open ( kern_filename, "r", 0, &finp, status_code );
   ERRSIM_on_err_goto_exit ( *status_code );

/* ==========================================================================
   Read the first line
   ========================================================================== */
   if ( fgets ( str, (INTx4)LDEFID_char_num, finp ) == NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IRES_error_read_kern,
                         kern_filename );
   }

/* ==========================================================================
   Count the numerical matrix elements ( columns number )
   ========================================================================== */
   if ( ( p = strtok ( str, ", " ) ) == NULL ) {
      ERRSIM_set_error ( status_code, ERRSID_IRES_no_elem_kern, "" );
   }

   /* almost one row */
   (*Kr)++;

   /* almost one column */
   if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
      ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good, "" );
*/
   }
   else {
      (*Kc)++;
   }

   while ( ( p = strtok ( '\0', ", " ) ) != NULL ) {
      if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/* 
         ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good, "" );
*/
        
      }
      else {
         (*Kc)++;
      }
   }

/* ==========================================================================
   Check the number of columns
   ========================================================================== */
   if ( *Kc > 1 ) {

/* ==========================================================================
   Read the second row
   ========================================================================== */
      if ( fgets ( str, (INTx4)LDEFID_char_num, finp ) == NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IRES_error_read_kern,
                            kern_filename );
      }

      if ( ( p = strtok ( str, ", " ) ) == NULL ) {
         ERRSIM_set_error ( status_code, ERRSID_IRES_no_elem_kern, "" );
      }

/* ==========================================================================
   Count the elements of the second row
   ========================================================================== */
      if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
         ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good, "" );
*/
      }
      else {
         count++;
      }
      while ( ( p = strtok ( '\0', ", " ) ) != NULL ) {
         if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
            ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good,
                               "" );
*/
         }
         else {
            count++;
         }
      }

      if ( count == *Kc ) {

/* ==========================================================================
   The kernel is written as a 2D matrix
   ========================================================================== */
         (*Kr)++;	    /* count the second row already read */

/* ==========================================================================
   Count the number of rows
   ========================================================================== */
         while ( fgets ( str, LDEFID_char_num, finp ) != NULL ) {
            elem = 0;
	    if ( ( p = strtok ( str, ", " ) ) == NULL )
	       ERRSIM_set_error ( status_code, ERRSID_IRES_no_elem_kern, "" );
            if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
               ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good,
                                  "" );
*/
            }
            else {
               elem++;
            }
	    while ( ( p = strtok ( '\0', ", " ) ) != NULL ) {
               if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
                  ERRSIM_set_error ( status_code,
                                     ERRSID_IRES_kern_spec_not_good, "" );
*/
               }
               else {
                  elem++;
               }
            }
            if ( elem == *Kc ) {
	       (*Kr)++;			      /* till the EOF */
	    }
	    else
	       ERRSIM_set_error ( status_code, ERRSID_IRES_error_read_kern, 
                                  kern_filename );
         }

/* ==========================================================================
   Alocates the kernel memories
   ========================================================================== */
         if ( ( (*Kern) = (float **)
	          MEMSIP_alloc ( (size_t)( (*Kr) * sizeof (float *)) ) ) ==
	      (float **)NULL ) {
	    ERRSIM_set_error ( status_code, ERRSID_IRES_err_mem_alloc, "" );
         }

         for ( i=0; i<(*Kr); i++ ) {
	    if ( ( (*Kern)[ i ] = (float *)
	            MEMSIP_alloc ( (size_t)((*Kc) * sizeof (float)) ) ) ==
	         (float *)NULL ) {
	       ERRSIM_set_error ( status_code, ERRSID_IRES_err_mem_alloc, "" );
            }
         }

/* ==========================================================================
   Back to the file beginning
   ========================================================================== */
         if ( fseek ( finp, (INTx8)0, SEEK_SET ) != 0 ) {
 	    ERRSIM_set_error ( status_code, ERRSID_IRES_error_read_kern,
                               kern_filename );
         }

         for ( i=0; i<(*Kr); i++ ) {

/* ==========================================================================
   Fill each row ... see comment above for the controls
   ========================================================================== */
	    if ( fgets ( str, (INTx4)LDEFID_char_num, finp ) == NULL ) {
	       ERRSIM_set_error ( status_code, ERRSID_IRES_error_read_kern,
                                  kern_filename );
            }
	    j = 0;
	    if ( ( p = strtok ( str, ", " ) ) == NULL ) {
/*
	       ERRSIM_set_error ( status_code, ERRSID_IRES_no_elem_kern, "" );
*/
            }

            if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
               ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good,
                                  "" );
*/
            }
            else {
               (*Kern)[ i ][ j++ ] = tmp;
            }
	    while ( ( p = strtok ( '\0', ", " ) ) != NULL ) {
               if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
                  ERRSIM_set_error ( status_code,
                                     ERRSID_IRES_kern_spec_not_good, "" );
*/
               }
               else {
                  (*Kern)[ i ][ j++ ] = tmp;
               }
            }
         }
      }
      else if ( count == 1 ) {
         float			 *row = (float *)NULL;
         float			 *col = (float *)NULL;

/* ==========================================================================
   The kernel is written as two 1D vectors
   ========================================================================== */
         /* count the number of rows */
         while ( fgets ( str, LDEFID_char_num, finp ) != (char *)NULL ) {

	    elem = 0;
	    if ( ( p = strtok ( str, ", " ) ) == NULL ) {
/*
	       ERRSIM_set_error ( status_code, ERRSID_IRES_no_elem_kern, "" );
*/
            }
            if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
               ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good,
                                  "" );
*/
            }
            else {
               elem++;
            }
	    while ( ( p = strtok ( '\0', ", " ) ) != NULL ) {
               if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
                  ERRSIM_set_error ( status_code,
                                     ERRSID_IRES_kern_spec_not_good, "" );
*/
               }
               else {
                  elem++;
               }
            }
	    if ( elem == 1 ) {
	       (*Kr)++;			      /* till the EOF */
	    }
	    else if ( elem == 0 ) {
	       break;
	    }
	    else
	       ERRSIM_set_error ( status_code, ERRSID_IRES_error_read_kern, 
                                  kern_filename );
         }

/* ==========================================================================
   Check the number of rows
   ========================================================================== */
         if ( *Kr <= 1 ) {
	    ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good,
                               "" );
         }

/* ==========================================================================
   Allocates the memories to store row and column 1D vectors
   ========================================================================== */
         if ( ( row = (float *)
		    MEMSIP_alloc( (size_t)(*(Kc)*sizeof(float)) ) ) ==
	       (float *)NULL )
	    ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc, "" );
         if ( ( col = (float *)
		    MEMSIP_alloc( (size_t)((*Kr)*sizeof(float)) ) ) ==
	       (float *)NULL )
	    ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc, "" );

/* ==========================================================================
   Back to the file beginning
   ========================================================================== */
         if ( fseek( finp, (INTx8)0, SEEK_SET ) != 0 )
	    ERRSIM_set_error( status_code, ERRSID_IRES_error_read_kern,
			      kern_filename );

/* ==========================================================================
   Read the row vector of the first line
   ========================================================================== */
         if ( fgets( str, (INTx4)LDEFID_char_num, finp ) == NULL )
	    ERRSIM_set_error( status_code, ERRSID_IRES_error_read_kern,
			      kern_filename );

/* ==========================================================================
   Fill the row vector elements
   ========================================================================== */
         if ( ( p = strtok( str, ", " ) ) == NULL )
	    ERRSIM_set_error( status_code, ERRSID_IRES_no_elem_kern, "" );

         if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/* 
           ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good,
                               "" );
*/
         }
         else {
            row[ 0 ] = tmp;
         }

         for ( i=1; i<(*Kc); i++ ) {
	    if ( ( p = strtok( '\0', ", " ) ) == NULL )
	       ERRSIM_set_error( status_code, ERRSID_IRES_no_elem_kern, "" );
            if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
               ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good,
                                  "" );
*/
            }
            else {
               row[ i ] = tmp;
            }
         }

/* ==========================================================================
   Fills the column vector element
   ========================================================================== */
         for ( i=0; i<(*Kr); i++ ) {
	    if ( fgets( str, LDEFID_char_num, finp ) == NULL )
	       ERRSIM_set_error( status_code, ERRSID_IRES_error_read_kern,
	   		         kern_filename );

	    if ( ( p = strtok( str, ", " ) ) == NULL )
	       ERRSIM_set_error( status_code, ERRSID_IRES_no_elem_kern, "" );

            if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
               ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good,
                                  "" );
*/
            }
            else {
               col[ i ] = tmp;
            }
         }

/* ==========================================================================
   Alocates the kernel memories
   ========================================================================== */
         if ( ( (*Kern) = (float **)
		    MEMSIP_alloc( (size_t)( (*Kr) * sizeof(float *) ) ) ) ==
	      (float **)NULL )
	    ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc, "" );

         for ( i=0; i<(*Kr); i++ ) {
	    if ( ( (*Kern)[ i ] = (float *)
		    MEMSIP_alloc((size_t)( (*Kc) * sizeof(float) ) ) )==
	         (float *)NULL )
	       ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc, "" );
         }

/* ==========================================================================
   Fill the 2D kernel
   ========================================================================== */
         for ( i=0; i<(*Kr); i++ ) {
	    for ( j=0; j<(*Kc); j++ ) (*Kern)[ i ][ j ] = col[ i ] * row[ j ];
         }

/* ==========================================================================
   Free the row, col memories
   ========================================================================== */
         MEMSIP_free( (void *)(&row) );
         MEMSIP_free( (void *)(&col) );
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_IRES_kern_spec_not_good, "" );
      }
   }
   else {
      if ( *Kc < 1 ) {

         /* no elements */
         ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good, "" );
      }
      else {

         /* only one element */
         *Kr = 1;
         if ( ( (*Kern) = (float **)MEMSIP_alloc ( (size_t)sizeof (float *))) ==
              (float **)NULL ) {
            ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc, "" );
         }
         if ( ( (*Kern)[ 0 ] = (float *)MEMSIP_alloc ( (size_t)
                                                       sizeof (float) ) ) ==
              (float *)NULL ) {
            ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc, "" );
         }

/* ==========================================================================
   Back to the file beginning
   ========================================================================== */
         if ( fseek( finp, (INTx8)0, SEEK_SET ) != 0 )
            ERRSIM_set_error( status_code, ERRSID_IRES_error_read_kern,
                              kern_filename );

/* ==========================================================================
   Read the row vector of the first line
   ========================================================================== */
         if ( fgets( str, (INTx4)LDEFID_char_num, finp ) == NULL )
            ERRSIM_set_error( status_code, ERRSID_IRES_error_read_kern,
                              kern_filename );

/* ==========================================================================
   Fill the row vector elements
   ========================================================================== */
         if ( ( p = strtok( str, ", " ) ) == NULL )
            ERRSIM_set_error( status_code, ERRSID_IRES_no_elem_kern, "" );

         if ( sscanf ( p, "%f", &tmp ) != 1 ) {
/*
            ERRSIM_set_error ( status_code, ERRSID_IRES_kern_spec_not_good,
                               "" );
*/
         }
         else {
            (*Kern)[ 0 ][ 0 ] = tmp;
         }
      }
   }

error_exit:;

/* ==========================================================================
   Close the opened input file
   ========================================================================== */
   fclose( finp );

   if ( *status_code != ERRSID_normal ) {

/* ==========================================================================
   Free the kernel memories
   ========================================================================== */
      if ( (*Kern) != (float **)NULL )
	 for ( i=0; i<(*Kr); i++ )
	    MEMSIP_free( (void *) &((*Kern)[ i ]) );

      MEMSIP_free( (void *) Kern );
   }

   ERRSIM_close_routine ( routine_name, &process_flag, *status_code, 
                          &log_status_code );

}/* IRESIP_UNDR_ReadFilter */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_UNDR_ConvCore

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI

        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_kernel_dim_high
		      ERRSID_IRES_bad_steps
		      ERRSID_IRES_bad_write_size
		      ERRSID_IRES_err_mem_alloc
		      ERRSID_IRES_not_under_allow

        $DESCRIPTION  This procedure convolves the kernel given in input with
                      the image block also given and writes the output in the
                      file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
                                        - Convolve the image block with the
                                          kernel
                                        - Fill the output vector
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */

void IRESIP_UNDR_ConvCore
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIP_UNDR_ConvCore";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 rs;
   UINTx4                 cs;
   UINTx4                 RStart;
   UINTx4                 CStart;
   float                 *OutIma = (float *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the kernel sizes consistency
   ========================================================================== */
   if ( ( Kr > nrow_inp ) || ( Kc > ncol_inp ) )
      ERRSIM_set_error( status_code, ERRSID_IRES_kernel_dim_high, "" );

/* ==========================================================================
   Check the steps values
   ========================================================================== */
   if ( ( StepR < 1. ) || ( StepC < 1. ) )
      ERRSIM_set_error( status_code, ERRSID_IRES_bad_steps, "" );

/* ==========================================================================
   Check the writing counters
   ========================================================================== */
   if ( RStartW > RStopW )
      ERRSIM_set_error( status_code, ERRSID_IRES_bad_write_size, "" );

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
   if ( ( OutIma = (float *)
           MEMSIP_alloc((size_t)(ncol_out * sizeof(float))) ) ==(float *)NULL) {
      ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc, "" );
   }


/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
   for ( rs=RStartW; rs<=RStopW; rs++ ) {

      SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
      for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
         RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
         CStart = (UINTx4) ROUND( cs* StepC );

/* ==========================================================================
   Convolution core
   ========================================================================== */
         OutIma[ cs ] = 
            IRESIF_UNDR_Convol( InpIma, inp_data_type, RStart, CStart,
               Kern, Kr, Kc, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

      }
/* ==========================================================================
   Write the output line
   ========================================================================== */
      GIOSIP_write_line( out_io, rs, (void *)OutIma,
                         status_code );
      ERRSIM_on_err_goto_exit( *status_code );

   }

error_exit:;

/* ==========================================================================
   Free the output vector memory
   ========================================================================== */
   MEMSIP_free( (void **)(&OutIma) );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IRESIP_UNDR_ConvCore */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_UNDR_ConvCoreConstKern

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI

        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_kernel_dim_high
		      ERRSID_IRES_bad_steps
		      ERRSID_IRES_bad_write_size
		      ERRSID_IRES_err_mem_alloc
		      ERRSID_IRES_not_under_allow

        $DESCRIPTION  This procedure convolves the constant kernel given in
		      input with the image block also given and writes the
		      output in the file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
                                        - Sum the window element
                                        - Fill the output vector rescaling it
					  by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */

void IRESIP_UNDR_ConvCoreConstKern
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIP_UNDR_ConvCoreConstKern";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 rs;
   UINTx4                 cs;
   UINTx4                 RStart;
   UINTx4                 CStart;
   float                 *OutIma = (float *)NULL;
   float 		  k;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Check the kernel sizes consistency
   ========================================================================== */
   if ( ( Kr > nrow_inp ) || ( Kc > ncol_inp ) )
      ERRSIM_set_error( status_code, ERRSID_IRES_kernel_dim_high, "" );

/* ==========================================================================
   Check the steps values
   ========================================================================== */
   if ( ( StepR < 1. ) || ( StepC < 1. ) )
      ERRSIM_set_error( status_code, ERRSID_IRES_bad_steps, "" );

/* ==========================================================================
   Check the writing counters
   ========================================================================== */
   if ( RStartW > RStopW )
      ERRSIM_set_error( status_code, ERRSID_IRES_bad_write_size, "" );

/* ==========================================================================
   Copy the kernel value in a variable
   ========================================================================== */
   k = Kern[ 0 ][ 0 ];

/* ==========================================================================
   Allocates the output block vector
   ========================================================================== */
   if ( ( OutIma = (float *)
           MEMSIP_alloc((size_t)(ncol_out * sizeof(float))) ) ==(float *)NULL) {
      ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc, "" );
   }

/* ==========================================================================
   Start the moving windowing
   ========================================================================== */
   for ( rs=RStartW; rs<=RStopW; rs++ ) {

      SRVSIP_trace_comp( &log_status_code );

/* ==========================================================================
   Rows' step loop
   ========================================================================== */
      for ( cs=0; cs<ncol_out; cs++ ) {

/* ==========================================================================
   Columns' step loop
   ========================================================================== */
         RStart = (UINTx4) ROUND( rs * StepR ) - RStartR;
         CStart = (UINTx4) ROUND( cs* StepC );

/* ==========================================================================
   Convolution core
   ========================================================================== */
         OutIma[ cs ] = 
            IRESIF_UNDR_ConstConvol( InpIma, inp_data_type, RStart, CStart,
               k, Kr, Kc, status_code );
            ERRSIM_on_err_goto_exit( *status_code );

      }
/* ==========================================================================
   Write the output line
   ========================================================================== */
      GIOSIP_write_line( out_io, rs, (void *)OutIma,
                         status_code );
      ERRSIM_on_err_goto_exit( *status_code );

   }

error_exit:;

/* ==========================================================================
   Free the output vector memory
   ========================================================================== */
   MEMSIP_free( (void **)(&OutIma) );

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IRESIP_UNDR_ConvCoreConstKern */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIF_UNDR_Convol

        $TYPE         FUNCTION

        $INPUT        inp_ima      : pointer to the input image
                      inp_ima_dt   : input image data type
                      row_start    : start row index of image window
                      col_start    : start column index of image window
                      Kern         : kernel filter
                      Kr           : kernel row size
                      Kc           : kernel column size

        $MODIFIED     NONE

        $OUTPUT       OutPoint     : result of the convolution

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine executes the convolution between an image
                      and a kernel

        $WARNING      NONE

   $EH
   ========================================================================== */
float IRESIF_UNDR_Convol
                        (/*IN    */ void               **inp_ima,
                         /*IN    */ LDEFIT_data_type     inp_ima_dt,
                         /*IN    */ UINTx4               row_start,
                         /*IN    */ UINTx4               col_start,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIF_UNDR_Convol";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   REGISTER UINTx2        i;
   REGISTER UINTx2        j;
   REGISTER float         out_point;
   REGISTER float        *k = (float *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Switch the various input types
   ========================================================================== */
   switch ( inp_ima_dt ) {
      case LDEFIE_dt_UINTx1: 
         {
            REGISTER UINTx1       *p = (UINTx1 *)NULL;

/* ==========================================================================
   Convolution core
   ========================================================================== */
            out_point = 0.0;
            for ( i=0; i<Kr; i++ ) {

               /* point to the beginning of the matrices rows */
               p = &((UINTx1 **) inp_ima)[ row_start + i ][ col_start ] - 1;
               k = &Kern[ Kr - i - 1 ][ Kc - 1 ] + 1;

               /* internal convolution loop */
               for ( j=0; j<Kc; j++ ) out_point += *--k * (float)*++p;
            }
         }
         break;

      case LDEFIE_dt_UINTx2: 
         {
            REGISTER UINTx2       *p = (UINTx2 *)NULL;

/* ==========================================================================
   Convolution core
   ========================================================================== */
            out_point = 0.0;
            for ( i=0; i<Kr; i++ ) {

               /* point to the beginning of the matrices rows */
               p = &((UINTx2 **) inp_ima)[ row_start + i ][ col_start ] - 1;
               k = &Kern[ Kr - i - 1 ][ Kc - 1 ] + 1;

               /* internal convolution loop */
               for ( j=0; j<Kc; j++ ) out_point += *--k * (float)*++p;
            }
         }
         break;

      case LDEFIE_dt_float: 
         {
            REGISTER float        *p = (float *)NULL;

/* ==========================================================================
   Convolution core
   ========================================================================== */
            out_point = 0.0;
            for ( i=0; i<Kr; i++ ) {

               /* point to the beginning of the matrices rows */
               p = &((float **) inp_ima)[ row_start + i ][ col_start ] - 1;
               k = &Kern[ Kr - i - 1 ][ Kc - 1 ] + 1;

               /* internal convolution loop */
               for ( j=0; j<Kc; j++ ) out_point += *--k * (float)*++p;
            }
         }
         break;

      case LDEFIE_dt_double:
         {
            REGISTER double       *p = (double *)NULL;

/* ==========================================================================
   Convolution core
   ========================================================================== */
            out_point = 0.0;
            for ( i=0; i<Kr; i++ ) {

               /* point to the beginning of the matrices rows */
               p = &((double **) inp_ima)[ row_start + i ][ col_start ] - 1;
               k = &Kern[ Kr - i - 1 ][ Kc - 1 ] + 1;

               /* internal convolution loop */
               for ( j=0; j<Kc; j++ ) out_point += *--k * (float) ((double)*++p);
            }
         }
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_IRES_not_under_allow, "" );

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return( out_point );

}/* IRESIF_UNDR_Convol */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIF_UNDR_ConstConvol

        $TYPE         FUNCTION

        $INPUT        inp_ima      : pointer to the input image
                      inp_ima_dt   : input image data type
                      row_start    : start row index of image window
                      col_start    : start column index of image window
                      K            : kernel filter value
                      Kr           : kernel row size
                      Kc           : kernel column size

        $MODIFIED     NONE

        $OUTPUT       OutPoint     : result of the convolution

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine executes the convolution between an image
                      and a constant kernel

        $WARNING      NONE

   $EH
   ========================================================================== */
float IRESIF_UNDR_ConstConvol
                        (/*IN    */ void               **inp_ima,
                         /*IN    */ LDEFIT_data_type     inp_ima_dt,
                         /*IN    */ UINTx4               row_start,
                         /*IN    */ UINTx4               col_start,
                         /*IN    */ float                K,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESIF_UNDR_ConstConvol";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

   REGISTER UINTx2        i;
   REGISTER UINTx2        j;
   REGISTER float         out_point;
   REGISTER float        *k = (float *)NULL;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Switch the various input types
   ========================================================================== */
   switch ( inp_ima_dt ) {
      case LDEFIE_dt_UINTx1: 
         {
            REGISTER UINTx1       *p = (UINTx1 *)NULL;

/* ==========================================================================
   Convolution core
   ========================================================================== */
            out_point = 0.0;
            for ( i=0; i<Kr; i++ ) {

               /* point to the beginning of the matrices rows */
               p = &((UINTx1 **) inp_ima)[ row_start + i ][ col_start ] - 1;

               /* internal convolution loop */
               for ( j=0; j<Kc; j++ ) out_point += (float)*++p;
            }
         }
         break;

      case LDEFIE_dt_UINTx2: 
         {
            REGISTER UINTx2       *p = (UINTx2 *)NULL;

/* ==========================================================================
   Convolution core
   ========================================================================== */
            out_point = 0.0;
            for ( i=0; i<Kr; i++ ) {

               /* point to the beginning of the matrices rows */
               p = &((UINTx2 **) inp_ima)[ row_start + i ][ col_start ] - 1;

               /* internal convolution loop */
               for ( j=0; j<Kc; j++ ) out_point += (float)*++p;
            }
         }
         break;

      case LDEFIE_dt_float: 
         {
            REGISTER float        *p = (float *)NULL;

/* ==========================================================================
   Convolution core
   ========================================================================== */
            out_point = 0.0;
            for ( i=0; i<Kr; i++ ) {

               /* point to the beginning of the matrices rows */
               p = &((float **) inp_ima)[ row_start + i ][ col_start ] - 1;

               /* internal convolution loop */
               for ( j=0; j<Kc; j++ ) out_point += (float)*++p;
            }
         }
         break;

      case LDEFIE_dt_double: 
         {
            REGISTER double       *p = (double *)NULL;

/* ==========================================================================
   Convolution core
   ========================================================================== */
            out_point = 0.0;
            for ( i=0; i<Kr; i++ ) {

               /* point to the beginning of the matrices rows */
               p = &((double **) inp_ima)[ row_start + i ][ col_start ] - 1;

               /* internal convolution loop */
               for ( j=0; j<Kc; j++ ) out_point += (float) ((double)*++p);
            }
         }
         break;

      default:
         ERRSIM_set_error( status_code, ERRSID_IRES_not_under_allow, "" );

   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );

   return( out_point * K );

}/* IRESIF_UNDR_ConstConvol */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESPP_UNDR_AllocBlock

        $TYPE         PROCEDURE

        $INPUT        RBlockSize    : block size in the row direction
                      CBlockSize    : block size in the column direction

        $MODIFIED     inp_data_type : enumerates the various data types

        $OUTPUT       block_p       : pointer to the buffer that will contain
                                      the allocated block

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_err_mem_alloc
                      ERRSID_IRES_not_under_allow

        $DESCRIPTION  This procedure allocates the image block of the required
                      ( via <inp_data_type> ) data type

        $WARNING      NONE

        $PDL          - Switch among the possible data types allowed
                            - Allocates a column of pointers
                            - Loop over the rows
                                  - Allocates the rows
                            - End loop
                      - Break

   $EH
   ========================================================================== */

void IRESPP_UNDR_AllocBlock
                        (/*IN    */ UINTx4               RBlockSize,
                         /*IN    */ UINTx4               CBlockSize,
                         /*IN OUT*/ DATA_TYPEIT         *inp_data_type,
                         /*   OUT*/ void               **block_p,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "IRESPP_UNDR_AllocBlock";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Utility variables
   ========================================================================== */
   UINTx4                 i;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Switch among the various data types
   ========================================================================== */
   switch ( *inp_data_type ) {
      case LDEFIE_dt_UINTx1:

	 /* byte data type */
         if ( ( block_p = (void **) MEMSIP_alloc(
                 (size_t)( RBlockSize * sizeof( UINTx1 * ) ) ) ) ==
              (void **) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc,
                              " of the UINTx1 type block" );
         }

         for ( i=0; i<RBlockSize; i++ ) {
            block_p[ i ] = (void *)NULL;
            if ( ( block_p[ i ] = (void *) MEMSIP_alloc(
                    (size_t)( CBlockSize * sizeof( UINTx1 ) ) ) ) ==
                 (void *) NULL ){
               ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc,
                                 " of the UINTx1 type block" );
            }
         }
	 *inp_data_type = DATA_TYPE_UINTx1;
      break;
      case LDEFIE_dt_UINTx2:

	 /* PRI, GEC and GTC data */
         if ( ( block_p = (void **) MEMSIP_alloc(
                 (size_t)( RBlockSize * sizeof( UINTx2 * ) ) ) ) ==
              (void **) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc,
                              " of the UINTx2 type block" );
         }

         for ( i=0; i<RBlockSize; i++ ) {
            block_p[ i ] = (void *) NULL;
            if ( ( block_p[ i ] = (void *) MEMSIP_alloc(
                    (size_t)( CBlockSize * sizeof( UINTx2 ) ) ) ) ==
               (void *) NULL ){
               ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc,
                                 " of the UINTx2 type block" );
            }
         }
	 *inp_data_type = DATA_TYPE_UINTx2;
      break;
      case LDEFIE_dt_float:

	 /* internal product */
         if ( ( block_p = (void **) MEMSIP_alloc(
                 (size_t)( RBlockSize * sizeof( float * ) ) ) ) ==
            (void **) NULL ) {
            ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc,
                              " of the float type block" );
         }

         for ( i=0; i<RBlockSize; i++ ) {
            block_p[ i ] = (void *) NULL;
            if ( ( block_p[ i ] = (void *) MEMSIP_alloc(
                    (size_t)( CBlockSize * sizeof( float ) ) ) ) ==
               (void *) NULL ){
               ERRSIM_set_error( status_code, ERRSID_IRES_err_mem_alloc,
                                 " of the float type block" );
            }
         }
	 *inp_data_type = DATA_TYPE_float;
      break;
      default:
         ERRSIM_set_error( status_code, ERRSID_IRES_not_under_allow, "" );
   }

error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* IRESPP_UNDR_AllocBlock */
