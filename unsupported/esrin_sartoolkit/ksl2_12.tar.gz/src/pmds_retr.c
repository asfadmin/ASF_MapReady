/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_RETR

      $FUNCTION          

      $ROUTINE           PMDSIP_RETR_CheckImage
                         PMDSIP_RETR_CheckBuffer

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       14-OCT-97     DDN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include MEMS_INTF_H
#include LDEF_INTF_H
#include TIFS_INTF_H
#include IANN_INTF_H
#include COOR_INTF_H
#include PMDS_INTF_H
#include PMDS_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */


#ifdef gino

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_RETR_

        $TYPE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_RETR_
                        (/*IN    */ 
                         /*IN OUT*/ 
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_RETR_";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Place code hereinafter
   ========================================================================== */
error_exit:;

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSIP_RETR_ */

#endif



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_RETR_CheckImage

        $TYPE

        $INPUT        image_file     : image file from where extract sub-image
                      sub_image_file : image file to use as check to find image

        $MODIFIED     NONE

        $OUTPUT       out_retr_file  : output data file

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_alloc_memory

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void PMDSIP_RETR_CheckImage
                        (/*IN    */ char                *image_file,
                         /*IN    */ char                *sub_image_file,
                         /*   OUT*/ char                *out_retr_file,
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "PMDSIP_RETR_CheckImage";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Local variables
   ========================================================================== */
   TIFSIT_basicpar  image_bpar;         /* input file basic parameters */
   INTx4            image_channel;      /* image channel */
   FILE            *fp;                 /* file pointer to the output data */
   void            *imgline;            /* image line buffer */
   UINTx1          *image_buf;          /* total image buffer */
   UINTx1          *sub_image_buf;      /* total sub-image buffer */
   INTx4            iline;              /* convenient loop variable */
   INTx4            nimage;             /* image number */
   INTx4            iimage = 0;         /* current image index */
   INTx4            image_width;        /* image width */
   INTx4            image_height;       /* image height */
   INTx4            sub_image_width;    /* sub image width */
   INTx4            sub_image_height;   /* sub image height */
   INTx4            start_col;          /* starting column in the image file */
   INTx4            start_row;          /* starting row in the image file */
   INTx4            end_col;            /* ending column in the image file */
   INTx4            end_row;            /* ending row in the image file */
   INTx4            full_start_col;     /* starting column in the full image */
   INTx4            full_start_row;     /* starting row in the full image */
   INTx4            full_stop_col;      /* stop column in the full image */
   INTx4            full_stop_row;      /* stop row in the full image */
   MATHIT_RC        row_col_data;       /* row column data structure */
   MATHIT_LLH       lat_lon_data;       /* lat lon height data structure */
   float            top_left_lat;       /* */
   float            top_left_lon;       /* */
   float            top_right_lat;      /* */
   float            top_right_lon;      /* */
   float            bottom_left_lat;    /* */
   float            bottom_left_lon;    /* */
   float            bottom_right_lat;   /* */
   float            bottom_right_lon;   /* */
   LDEFIT_boolean   coor_flag = TRUE;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1     inp_ima_num = 0;
 
/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name,
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Open image file
   ========================================================================== */
   TIFSIP_open_tiff( image_file, 'r', &image_channel, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_imgnum( image_channel, &nimage, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_blockinfo( image_channel, iimage, &image_bpar, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check that it is a byte image
   ========================================================================== */
   if( (image_bpar.sampleperpixel !=1) ||
       (image_bpar.bitspersample[0] !=8) ||
       (image_bpar.sampleformat[0] != TIFSID_uintdata) ) {
      ERRSIM_set_error( status_code, ERRSID_PMDS_error_not_allowed,
         "input image should be a byte image" );
   }
  
/* ==========================================================================
   Get image size
   ========================================================================== */
   image_width  = image_bpar.imagewidth;
   image_height = image_bpar.imagelength;

/* ==========================================================================
   Reset image annatation data
   ========================================================================== */
   memset((void *)&(IANNIV_ImageAnnot[inp_ima_num]), '\0',
      sizeof(IANNIT_ImageAnnot));
 
/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot(image_channel, iimage, inp_ima_num, IANNID_EXTR_CORT,
      image_bpar, status_code);
   ERRSIM_on_err_goto_exit(*status_code);

/* ==========================================================================
   Allocate memory for the image buffer
   ========================================================================== */
   if((image_buf = (UINTx1 *) MEMSIP_alloc(image_width * image_height *
      sizeof(UINTx1))) == NULL)
   {
      ERRSIM_set_error( status_code, ERRSID_PMDS_alloc_memory, "image file");
   }

/* ==========================================================================
   Open the read mode of the image file
   ========================================================================== */
   TIFSIP_open_line( image_channel, iimage, 'x', 0, (image_width - 1),
      status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Loop onto the file line(s)
   ========================================================================== */

#ifdef __TRACE__

fprintf(stderr,"Debug: ----------------------------------------------------\n");
fprintf(stderr,"Debug:     image file = <%s>\n", image_file);
fprintf(stderr,"Debug:          width = <%d>\n", image_width);
fprintf(stderr,"Debug:         height = <%d>\n", image_height);

#endif

   for(iline = 0; iline < image_height; iline++)
   {
/* ==========================================================================
      Read line from image file
   ========================================================================== */
      TIFSIP_read_line(image_channel, iimage, iline, &imgline, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Copy the image line just read
   ========================================================================== */
      memcpy((void *)(image_buf + (iline * image_width)), imgline, image_width);

#ifdef __TRACE__
fprintf(stderr,"Debug:     lines read = <%d/%d>\r", iline, image_height);
#endif

   }

#ifdef __TRACE__
fprintf(stderr,"Debug:     lines read = <%d/%d>\n", iline, image_height);
#endif

/* ==========================================================================
   Close read mode for image file
   ========================================================================== */
   TIFSIP_close_line( image_channel, iimage, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close image file
   ========================================================================== */
   TIFSIP_close_tiff( image_channel, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open sub-image file
   ========================================================================== */
   TIFSIP_open_tiff( sub_image_file, 'r', &image_channel, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_imgnum( image_channel, &nimage, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_blockinfo( image_channel, iimage, &image_bpar, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check that it is a byte image
   ========================================================================== */
   if( (image_bpar.sampleperpixel !=1) ||
       (image_bpar.bitspersample[0] !=8) ||
       (image_bpar.sampleformat[0] != TIFSID_uintdata) ) {
      ERRSIM_set_error( status_code, ERRSID_PMDS_error_not_allowed,
         "cropped input image should be a byte image" );
   }
  
/* ==========================================================================
   Get image size
   ========================================================================== */
   sub_image_width  = image_bpar.imagewidth;
   sub_image_height = image_bpar.imagelength;

/* ==========================================================================
   Allocate memory for the image buffer
   ========================================================================== */
   if((sub_image_buf = (UINTx1 *) MEMSIP_alloc(sub_image_width *
      sub_image_height * sizeof(UINTx1))) == NULL)
   {
      ERRSIM_set_error( status_code, ERRSID_PMDS_alloc_memory, "sub-image");
   }

/* ==========================================================================
   Open the read mode of the image file
   ========================================================================== */
   TIFSIP_open_line( image_channel, iimage, 'x', 0, (sub_image_width - 1),
      status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Loop onto the file line(s)
   ========================================================================== */

#ifdef __TRACE__
fprintf(stderr,"Debug: ----------------------------------------------------\n");
fprintf(stderr,"Debug: sub image file = <%s>\n", sub_image_file);
fprintf(stderr,"Debug:          width = <%d>\n", sub_image_width);
fprintf(stderr,"Debug:         height = <%d>\n", sub_image_height);
#endif

   for(iline = 0; iline < sub_image_height; iline++)
   {
/* ==========================================================================
      Read line from image file
   ========================================================================== */
      TIFSIP_read_line(image_channel, iimage, iline, &imgline, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Copy the image line just read
   ========================================================================== */
      memcpy((void *)(sub_image_buf + (iline * sub_image_width)), imgline,
         sub_image_width);

#ifdef __TRACE__
fprintf(stderr,"Debug:     lines read = <%d/%d>\r", iline, sub_image_height);
#endif

   }

#ifdef __TRACE__
fprintf(stderr,"Debug:     lines read = <%d/%d>\n", iline, sub_image_height);
fprintf(stderr,"Debug: ----------------------------------------------------\n");
#endif

/* ==========================================================================
   Close read mode for image file
   ========================================================================== */
   TIFSIP_close_line( image_channel, iimage, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close image file
   ========================================================================== */
   TIFSIP_close_tiff( image_channel, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check the images
   ========================================================================== */
   if((PMDSIP_RETR_CheckBuffer (image_buf,
                                sub_image_buf,
                                image_width,
                                image_height,
                                sub_image_width,
                                sub_image_height,
                                &start_row,
                                &start_col)) == TRUE) {
/* ==========================================================================
   Compute end row/column
   ========================================================================== */
      end_col = (start_col + sub_image_width - 1);
      end_row = (start_row + sub_image_height - 1);
/* ==========================================================================
      Try to create output coordinates text file
   ========================================================================== */
      if((fp = fopen(out_retr_file, "w")) != NULL)
      {
/* ==========================================================================
         Initialize coordinate conversion
   ========================================================================== */
         COORIP_CONV_Init(inp_ima_num, status_code);
         if( *status_code != STC( ERRSID_normal ) ) {
            *status_code = ERRSID_normal;
            ERRSIM_print_warning( "Corners coordinates not evaluable" );
            coor_flag = FALSE;
         }
         else {
/* ==========================================================================
   If the input image has a geographic presentation update coordinates
   ========================================================================== */
            if( IANNIV_ImageAnnot[ inp_ima_num ].Presentation ==
                IANNIE_pres_geo ) {
               if( IANNIV_ImageAnnot[ inp_ima_num ].OrbitDirection ==
                   IANNIE_orbit_descend ) {
                  UINTx4   old_start_col;
                  old_start_col = start_col;
                  start_col = IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth -
                              end_col - 1;
                  end_col   = IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth -
                              old_start_col - 1;
               }
               else {
                  UINTx4   old_start_row;
                  old_start_row = start_row;
                  start_row = IANNIV_ImageAnnot[ inp_ima_num ].ImageLength -
                              end_row - 1;
                  end_row   = IANNIV_ImageAnnot[ inp_ima_num ].ImageLength -
                              old_start_row - 1;
               }
            }
/* ==========================================================================
         Get lat lon data from row column data
   ========================================================================== */
/* Top left corner */
	    row_col_data.row = (double)start_row;
	    row_col_data.col = (double)start_col;
	    COORIP_CONV_rc_llh(&row_col_data, inp_ima_num, &lat_lon_data,
	       status_code);
	    ERRSIM_on_err_goto_exit(*status_code);
	    top_left_lat = lat_lon_data.lat;
	    top_left_lon = lat_lon_data.lon;

/* Top right corner */
	    row_col_data.row = (double)start_row;
	    row_col_data.col = (double)end_col;
	    COORIP_CONV_rc_llh(&row_col_data, inp_ima_num, &lat_lon_data,
	       status_code);
	    ERRSIM_on_err_goto_exit(*status_code);
	    top_right_lat = lat_lon_data.lat;
	    top_right_lon = lat_lon_data.lon;

/* Bottom left corner */
	    row_col_data.row = (double)end_row;
	    row_col_data.col = (double)start_col;
	    COORIP_CONV_rc_llh(&row_col_data, inp_ima_num, &lat_lon_data,
	       status_code);
	    ERRSIM_on_err_goto_exit(*status_code);
	    bottom_left_lat = lat_lon_data.lat;
	    bottom_left_lon = lat_lon_data.lon;

/* Bottom right corner */
	    row_col_data.row = (double)end_row;
	    row_col_data.col = (double)end_col;
	    COORIP_CONV_rc_llh(&row_col_data, inp_ima_num, &lat_lon_data,
	       status_code);
	    ERRSIM_on_err_goto_exit(*status_code);
	    bottom_right_lat = lat_lon_data.lat;
	    bottom_right_lon = lat_lon_data.lon;

         }

         full_start_row = (IANNIV_ImageAnnot[inp_ima_num].SubImageTopLeftRow +
            ROUND(start_row / IANNIV_ImageAnnot[inp_ima_num].YScalingFactor));
         full_start_col = (IANNIV_ImageAnnot[inp_ima_num].SubImageTopLeftCol +
            ROUND(start_col / IANNIV_ImageAnnot[inp_ima_num].XScalingFactor));

         full_stop_row = (IANNIV_ImageAnnot[inp_ima_num].SubImageTopLeftRow +
            ( ROUND( end_row/ IANNIV_ImageAnnot[inp_ima_num].YScalingFactor)));
         full_stop_col = (IANNIV_ImageAnnot[inp_ima_num].SubImageTopLeftCol +
            ( ROUND( end_col/ IANNIV_ImageAnnot[inp_ima_num].XScalingFactor)));

#ifdef __BHOOOO__
         full_start_row++;
         full_start_col++;
#endif

/* ==========================================================================
         Write into the file all the coordinate retrieving data found
   ========================================================================== */
         fprintf(fp, "----------------------------------------");
         fprintf(fp, "----------------------------------------\n");
         fprintf(fp, "              Quicklook image file : %s\n", image_file);
         fprintf(fp, "                Example image file : %s\n",
            sub_image_file);
         fprintf(fp, "----------------------------------------");
         fprintf(fp, "----------------------------------------\n");
         if( coor_flag ) {
            fprintf(fp, "    Top left lat in full res. file : %f\n",
               top_left_lat);
            fprintf(fp, "    Top left lon in full res. file : %f\n",
               top_left_lon);
            fprintf(fp, "   Top right lat in full res. file : %f\n",
               top_right_lat);
            fprintf(fp, "   Top right lon in full res. file : %f\n",
               top_right_lon);
            fprintf(fp, " Bottom left lat in full res. file : %f\n",
               bottom_left_lat);
            fprintf(fp, " Bottom left lon in full res. file : %f\n",
               bottom_left_lon);
            fprintf(fp, "Bottom right lat in full res. file : %f\n",
               bottom_right_lat);
            fprintf(fp, "Bottom right lon in full res. file : %f\n",
               bottom_right_lon);
         }
         else {
            fprintf(fp, "Corners geodetic coordinates not evaluable\n" );
         }
         fprintf(fp, "----------------------------------------");
         fprintf(fp, "----------------------------------------\n");
         fprintf(fp, "       Start row in full res. file : %d\n",
            full_start_row);
         fprintf(fp, "    Start column in full res. file : %d\n",
            full_start_col);
         fprintf(fp, "        Stop row in full res. file : %d\n",
            full_stop_row);
         fprintf(fp, "     Stop column in full res. file : %d\n",
            full_stop_col);
         fprintf(fp, "----------------------------------------");
         fprintf(fp, "----------------------------------------\n");
#ifdef __NOT_USEFUL__
         fprintf(fp, "       Start row in quicklook file : %d\n", start_row );
         fprintf(fp, "    Start column in quicklook file : %d\n", start_col );
         fprintf(fp, "         End row in quicklook file : %d\n", end_row );
         fprintf(fp, "      End column in quicklook file : %d\n", end_col );
         fprintf(fp, "----------------------------------------");
         fprintf(fp, "----------------------------------------\n");
#endif
/* ==========================================================================
         Close coordinates data file
   ========================================================================== */
         fclose(fp);
      }

fprintf(stderr,"\n\nCropped subimage found !\n");

   }
   else
   {

fprintf(stderr,"\n\nCropped subimage not found !\n");

   }

#ifdef __TRACE__
fprintf(stderr,"Debug: start column = <%d>\n", start_col);
fprintf(stderr,"Debug:    start row = <%d>\n", start_row);
fprintf(stderr,"Debug: Done !\n");
#endif

error_exit:;

/* ==========================================================================
   Free allocated memory
   ========================================================================== */
   MEMSIP_free((void **) &image_buf);
   MEMSIP_free((void **) &sub_image_buf);

   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* PMDSIP_RETR_CheckImage */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_RETR_CheckBuffer

        $TYPE

        $INPUT        image_buffer     : image buffer to be checked
                      sub_image_buffer : image buffer to use as check
                      image_width      : image width
                      image_height     : image height
                      sub_image_width  : sub image width
                      sub_image_height : sub image height
                      start_row        : starting row in the image
                      start_col        : starting column in the image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_alloc_memory

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

INTx4 PMDSIP_RETR_CheckBuffer
                        (/*IN    */ UINTx1              *image_buffer,
                         /*IN    */ UINTx1              *sub_image_buffer,
                         /*IN    */ INTx4                image_width,
                         /*IN    */ INTx4                image_height,
                         /*IN    */ INTx4                sub_image_width,
                         /*IN    */ INTx4                sub_image_height,
                         /*   OUT*/ INTx4               *start_row_p,
                         /*   OUT*/ INTx4               *start_col_p)
{
/* ==========================================================================
   Local variables
   ========================================================================== */
   INTx4            irow;              /* convenient loop variable */
   INTx4            icol;              /* convenient loop variable */
   INTx4            jrow;              /* convenient loop variable */
   INTx4            jcol;              /* convenient loop variable */
   INTx4            istart;            /* convenient loop variable */
   INTx4            found;              /* flag variable */
   UINTx1          *image_record;       /* current image record */
   UINTx1          *sub_image_record;   /* current sub-image record */

/* ==========================================================================
   Set default values
   ========================================================================== */
   *start_col_p = -1;
   *start_row_p = -1;

#ifdef __TRACE__
   fprintf( stdout, "image_height=%0d\nimage_width=%0d\nsub_image_height=%0d\nsub_image_width=%0d\n",
      image_height, image_width, sub_image_height, sub_image_width );
#endif

/* ==========================================================================
   Loop onto the image lines
   ========================================================================== */
   for(irow = 0; irow < (image_height - sub_image_height + 1); irow++)
   {
      image_record = (image_buffer + (irow * image_width));
#ifdef __TRACE__
      fprintf( stdout, "irow=%0d\n", irow );
#endif
/* ==========================================================================
      Loop onto the image record
   ========================================================================== */
      for(icol = 0; icol < (image_width - sub_image_width + 1); icol++)
      {
         found = TRUE;

/* ==========================================================================
         Loop onto the sub-image lines
   ========================================================================== */
         for(jrow = 0; jrow < sub_image_height; jrow++)
         {
            sub_image_record =
               (sub_image_buffer + (jrow * sub_image_width));
            istart = (jrow*image_width) + icol;

/* ==========================================================================
            Compare the image record(s) and the sub-image record(s)
   ========================================================================== */
            for(jcol = 0; jcol < sub_image_width; jcol++)
            {
#ifdef __TRACE__
               fprintf( stdout, "irow=%0d icol=%0d jrow=%0d jcol=%0d\n", irow, icol, jrow, jcol);
               fprintf( stdout, "image=%0d subimage=%0d\n", 
                  image_record[istart + jcol], sub_image_record[jcol] );
#endif
               if(image_record[istart + jcol] != sub_image_record[jcol])
               {
                  found = FALSE;
                  break;
               }
            }
            if( found == FALSE ) 
            {
               break; 
            }
         }
/* ==========================================================================
            If found returns true and the right values
   ========================================================================== */
         if(found == TRUE)
         {
            *start_col_p = icol;
            *start_row_p = irow;
            return( TRUE );
         }
      }
   }

/* ==========================================================================
   Return status
   ========================================================================== */
   return(FALSE);

} /* PMDSIP_RETR_CheckBuffer */


