/* ==========================================================================
   $MODULE_HEADER

      $NAME          ERRS_RFLG

      $FUNCTION      Read the flag list

      $ROUTINE       ERRSLF_RLFG_match_wild
                     ERRSIP_RFLG_read_flag
                  
      $HISTORY

            SCR NO.      DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       23-SEP-92     DD       Initial Release

    $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <ctype.h>
#include <stdio.h>
#include <string.h>

#include "defl_libname_intf.h"
#include ERRS_INTF_H
#include ERRS_PGLB_H


/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ERRSIP_RFLG_read_flag

      $FUNCTION     Read the flag list

      $INPUT        routine_name              : routine name

      $MODIFIED     NONE

      $OUTPUT       process_flag              : Flag setting

      $GLOBAL       ERRSPA_global_flag        : Read
                      
      $RET_STATUS   ERRSID_err_no_mem_allocated

      $DESCRIPTION  Read the flag setting.

      $WARNING      NONE

   $EH
   ========================================================================== */
void ERRSIP_RFLG_read_flag
                        ( /*IN    */ const ERRSIT_proc_name  routine_name,
                          /*   OUT*/ ERRSIT_flag            *process_flag,
                          /*   OUT*/ ERRSIT_status          *status_code )
{

   const ERRSIT_proc_name proc_name = "ERRSIP_RFLG_read_flag";

   INTx4	    i;
   INTx4	    struct_no;
   ERRSIT_proc_name in_routine_name;

   *status_code = ERRSID_normal;

/* ==========================================================================
   Takes the first 4 char of routine_name converted to upper case.
   ========================================================================== */
   for( i=0; i<4; i++) {
      in_routine_name[ i ] = toupper( routine_name[ i ] );
   }
   in_routine_name[ 4 ] = '\0';


/* ==========================================================================
   Initialize the flag variable.
   ========================================================================== */
   *process_flag = 0;

/* ==========================================================================
   Read each records. If the proc name is included in the flag list read the 
   relevant flags value.
   ========================================================================== */
   if (ERRSPV_global_flag != NULL)
   {
      for ( struct_no=0;
            ERRSPV_global_flag[struct_no].proc_id[0] !='\0';
            struct_no++ )
      {
         if ( !strcmp(in_routine_name, ERRSPV_global_flag[struct_no].proc_id)) {
            *process_flag = ERRSPV_global_flag[struct_no].flag;
            break;
         }
      } /* endfor struct_no */
   } /* endif ERRSPV_global_flag != NULL */

error_exit:;

} /* ERRSIP_RFLG_read_flag */ 
