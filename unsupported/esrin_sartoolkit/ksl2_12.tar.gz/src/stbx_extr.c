/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_EXTR

      $FUNCTION          This module contains the task procedure for
                         the Sar Toolbox EXTRACTION TOOL

      $ROUTINE           STBXPP_EXTR_MediaAnalysis
                         STBXPP_EXTR_HeaderDecode
                         STBXPP_EXTR_FullResolution
                         STBXPP_EXTR_QuickLook
                         STBXPP_EXTR_Preview
                         STBXPP_EXTR_CoordRetr
                         STBXPP_EXTR_SupportData
                         STBXPP_EXTR_Portion 

   $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       22-AUG-97     AG       Initial Release
            N/A       23-MAR-97     AG       Add for Reqs B10/B18

   $EH
   ========================================================================== */

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <stdlib.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MEMS_INTF_H
#include SRVS_INTF_H
#include IANN_INTF_H
#include COOR_INTF_H
#include STAT_INTF_H
#include PMDS_INTF_H
#include STBX_INTF_H
#include STBX_PGLB_H

/* ==========================================================================
                        ROUTINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_MediaAnalysis

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call media_analysis routine

   $EH
   ========================================================================== */
void STBXPP_EXTR_MediaAnalysis
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_EXTR_MediaAnalysis";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   ipar;
   INTx4                   jpar;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   INTx4                   numOfVol = 0;
   INTx4                   ichar;
   FILSIT_file_name        inImageName;
   FILSIT_file_name        inDb;
   FILSIT_file_name        outMcrName;
   FILSIT_file_name        outMcr;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 3 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL )
   {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_media_path );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_number_of_volumes );
   task.parm[ ipar ].type       = FIISIE_tt_int;
   task.parm[ ipar ].size       = sizeof( INTx4 );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) &numOfVol;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_mcr_file );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outMcrName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   ipar = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ ipar ].name, STBXPD_input_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_inp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_inp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_out_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_out_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_temporary_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_temp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_temp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_delete_input_image );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      FIISIP_GETS_get_info(argv[2],
                           task.name,
                           section_no,
                           &(task.parm[ipar]),
                           status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for(ipar = 3; ipar < argc; ipar += 2)
   {
      if(argv[ipar][0] == STBXPD_prefix_line_arg)
      {
         sprintf(tmpParmName, "%s", &(argv[ipar][1]));
         for(jpar = 0; jpar < task.parmNo; jpar++)
         {
            if(!strcmp(tmpParmName, task.parm[jpar].name))
            {
               STBXPP_set_par((void *) argv[ipar + 1],
                                &(task.parm[jpar]),
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               break;
            }
         }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      if((!task.parm[ipar].founded ) && (task.parm[ipar].mandatory))
      {
#ifdef __TRACE__
         printf("Param %s not defined\n", task.parm[ipar].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ipar].name);
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input file(s)
   ========================================================================== */
   sprintf( inDb, "%s%s", LDEFIV_cfg_dir, STBXPD_db_file_name );

/* ==========================================================================
   Build full name of output file(s)
   ========================================================================== */
   STBXPP_bld_file_name( outMcrName,
                         task_name,
                         LDEFIE_dt_undef,
                         outMcr,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters outMcr
   ========================================================================== */
   FILSIP_open( outMcr, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outMcr, &log_status_code );

/* ==========================================================================
   Check numOfVol
   ========================================================================== */
   if( numOfVol <= 0 ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
         STBXPD_number_of_volumes );
   }

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   PMDSIP_MDAN_MediaAnalysis( inImageName,
                              DEVSIE_mt_exa,
                              numOfVol,
                              inDb,
                              outMcr,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if((LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y'))
   {
;;;
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;
/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

/* ==========================================================================
   Delete output file(s), if an error occured (if any)
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) )
   {
      FILSIP_delete( outMcr, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_EXTR_MediaAnalysis */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_HeaderDecode

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call header_decoding routine
                      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_EXTR_HeaderDecode
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_EXTR_HeaderDecode";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   char                    dismount_flag = 'Y';
   INTx4                   ipar;
   INTx4                   jpar;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        outHead;
   FILSIT_file_name        outAnn;
   FILSIT_file_name        inImageName;
   FILSIT_file_name        outAnnName;
   FILSIT_file_name        outHeadName;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   DEVSIT_media_type       mediaType = DEVSIE_mt_none;
   char                    mediaTypeTxt[256];
   INTx4                   ichar;
   PMDSIT_product_type     productType = PMDSIE_unk_prod;
   char                    productTypeTxt[256];
   char                    sensorIdTxt[256];
   INTx4                   sensorId;
   char                    dataFormat[16];
   char                    sourceId[16];
   INTx4                   numOfVol    = 0;
   UINTx4                  TLRow       = 0;
   UINTx4                  TLCol       = 0;
   UINTx4                  BRRow       = 0;
   UINTx4                  BRCol       = 0;
   UINTx4                  ql_width    = 0;
   UINTx4                  ql_height   = 0;
   UINTx4                  win_width   = 0;
   UINTx4                  win_height  = 0;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            out_ima_num = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 10 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL )
   {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_media_path );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_input_media_type );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( mediaTypeTxt );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) mediaTypeTxt;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_product_type );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( productTypeTxt );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) productTypeTxt;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_sensor_id );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( sensorIdTxt );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) sensorIdTxt;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_data_format );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( dataFormat );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) dataFormat;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_source_id );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( sourceId );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) sourceId;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_number_of_volumes );
   task.parm[ ipar ].type       = FIISIE_tt_int;
   task.parm[ ipar ].size       = sizeof( INTx4 );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) &numOfVol;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_annotation_file );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outAnnName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_head_an_file );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outHeadName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_dismount_flag );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &dismount_flag;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   ipar = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ ipar ].name, STBXPD_input_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_inp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_inp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_out_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_out_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_temporary_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_temp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_temp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_delete_input_image );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      FIISIP_GETS_get_info(argv[2],
                           task.name,
                           section_no,
                           &(task.parm[ipar]),
                           status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for(ipar = 3; ipar < argc; ipar += 2)
   {
      if(argv[ipar][0] == STBXPD_prefix_line_arg)
      {
         sprintf(tmpParmName, "%s", &(argv[ipar][1]));
         for(jpar = 0; jpar < task.parmNo; jpar++)
         {
            if(!strcmp(tmpParmName, task.parm[jpar].name))
            {
               STBXPP_set_par((void *) argv[ipar + 1],
                                &(task.parm[jpar]),
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               break;
            }
         }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      if((!task.parm[ipar].founded ) && (task.parm[ipar].mandatory))
      {
#ifdef __TRACE__
         printf("Param %s not defined\n", task.parm[ipar].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ipar].name);
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check numOfVol
   ========================================================================== */
   if( numOfVol <= 0 ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_parm_not_negative,
         STBXPD_number_of_volumes );
   }

/* ==========================================================================
   Check dismount_flag
   ========================================================================== */
   if( (toupper( dismount_flag ) != 'Y') &&
       (toupper( dismount_flag ) != 'N') ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        STBXPD_dismount_flag );
   }

/* ==========================================================================
   Build full name of output file(s)
   ========================================================================== */
   STBXPP_bld_file_name( outHeadName,
                         task_name,
                         LDEFIE_dt_undef,
                         outHead,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   sprintf( outAnn, "%s%s.txt", LDEFIV_out_dir, outAnnName);

/* ==========================================================================
   Check on the input parameters outHead
   ========================================================================== */
   FILSIP_open( outHead, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outHead, &log_status_code );

/* ==========================================================================
   Check which media type has been selected
   ========================================================================== */
   for(ichar = 0; ichar < strlen(mediaTypeTxt); ichar++)
      mediaTypeTxt[ichar] = toupper(mediaTypeTxt[ichar]);

   if((strcmp(mediaTypeTxt, "DISK")) == 0)
      mediaType = DEVSIE_mt_file;
   else if((strcmp(mediaTypeTxt, "TAPE")) == 0)
      mediaType = DEVSIE_mt_exa;
   else if((strcmp(mediaTypeTxt, "CDROM")) == 0)
      mediaType = DEVSIE_mt_cdrom;
   else {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        STBXPD_input_media_type );
   }

/* ==========================================================================
   Check which product type has been selected
   ========================================================================== */
   for(ichar = 0; ichar < strlen(productTypeTxt); ichar++)
      productTypeTxt[ichar] = toupper(productTypeTxt[ichar]);

   if((strcmp(productTypeTxt, "RAW")) == 0)
      productType = PMDSIE_raw_prod;
   else if((strcmp(productTypeTxt, "SLC")) == 0)
      productType = PMDSIE_slc_prod;
   else if((strcmp(productTypeTxt, "SLCI")) == 0)
      productType = PMDSIE_slci_prod;
   else if((strcmp(productTypeTxt, "PRI")) == 0)
      productType = PMDSIE_pri_prod;
   else if((strcmp(productTypeTxt, "GEC")) == 0)
      productType = PMDSIE_gec_prod;
   else if((strcmp(productTypeTxt, "GTC")) == 0)
      productType = PMDSIE_gtc_prod;
   else {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        STBXPD_product_type );
   }

/* ==========================================================================
   Check which sensor id has been selected
   ========================================================================== */
   for(ichar = 0; ichar < strlen(sensorIdTxt); ichar++)
      sensorIdTxt[ichar] = toupper(sensorIdTxt[ichar]);

   if((strcmp(sensorIdTxt, "ERS1")) == 0)
      sensorId = 1;
   else if((strcmp(sensorIdTxt, "ERS2")) == 0)
      sensorId = 2;
   else {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        STBXPD_sensor_id );
   }


/* ==========================================================================
   Check which data format type has been selected
   ========================================================================== */
   for(ichar = 0; ichar < strlen(dataFormat); ichar++)
      dataFormat[ichar] = toupper(dataFormat[ichar]);

   if((strcmp(dataFormat, "CEOS")) == 0)
      strcpy(dataFormat, "C");
   else if((strcmp(dataFormat, "MPHSPH")) == 0)
      strcpy(dataFormat, "M");
   else if((strcmp(dataFormat, "ENVISAT")) == 0)
      strcpy(dataFormat, "E");
   else {
      ERRSIM_set_error( status_code, ERRSID_PMDS_defo_prod,
         "Unknown data format" );
   }

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   PMDSIP_Deformat( inImageName,
                    inp_ima_num,
                    mediaType,
                    productType,
                    sensorId,
                    dataFormat,
                    sourceId,
                    PMDSIE_HeaderDecodeMode,
                    numOfVol,
                    'Y', /* always acknowledge mount */
                    toupper( dismount_flag ),
                    TLRow,
                    TLCol,
                    BRRow,
                    BRCol,
                    ql_width,
                    ql_height,
                    win_width,
                    win_height,
                    outHead,
                    outAnn,
                    out_ima_num,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if((LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y'))
   {
;;;
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;
/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

/* ==========================================================================
   Delete output file(s), if an error occured (if any)
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) )
   {
      FILSIP_delete( outAnn, &log_status_code );
      FILSIP_delete( outHead, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_EXTR_HeaderDecode */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_FullResolution

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
                      - Call deformat routine
                      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_EXTR_FullResolution
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_EXTR_FullResolution";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no   = 0;
   MATHIT_RC              *vertex      = (MATHIT_RC *) NULL;
   DEVSIT_media_type       mediaType = DEVSIE_mt_none;
   char                    mediaTypeTxt[256];
   char                    ack_mount_flag = 'Y';
   char                    dismount_flag = 'Y';
   INTx4                   ichar;
   PMDSIT_product_type     productType = PMDSIE_unk_prod;
   INTx4                   sensorId;
   char                    dataFormat[ 16 ];
   char                    sourceId[ 16 ];
   INTx4                   numOfVol    = 0;
   UINTx4                  TLRow       = 0;
   UINTx4                  TLCol       = 0;
   UINTx4                  BRRow       = 0;
   UINTx4                  BRCol       = 0;
   UINTx4                  ql_width    = 0;
   UINTx4                  ql_height   = 0;
   UINTx4                  win_width   = 0;
   UINTx4                  win_height  = 0;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   ipar;
   INTx4                   jpar;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inHead;
   FILSIT_file_name        inHeadName;
   FILSIT_file_name        inImageName;
   FILSIT_file_name        outImage;
   FILSIT_file_name        outImageName;
 
/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               head_io;
   INTx4                   nimage;
   LDEFIT_boolean	   real_aoi;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            out_ima_num = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 6 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL )
   {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_media_path );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_input_media_type );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( mediaTypeTxt );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) mediaTypeTxt;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_head_an_file );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inHeadName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_ackn_mount_flag );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &ack_mount_flag;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_dismount_flag );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &dismount_flag;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   ipar = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ ipar ].name, STBXPD_input_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_inp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_inp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_out_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_out_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_temporary_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_temp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_temp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_delete_input_image );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      FIISIP_GETS_get_info(argv[2],
                           task.name,
                           section_no,
                           &(task.parm[ipar]),
                           status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for(ipar = 3; ipar < argc; ipar += 2)
   {
      if(argv[ipar][0] == STBXPD_prefix_line_arg)
      {
         sprintf(tmpParmName, "%s", &(argv[ipar][1]));
         for(jpar = 0; jpar < task.parmNo; jpar++)
         {
            if(!strcmp(tmpParmName, task.parm[jpar].name))
            {
               STBXPP_set_par((void *) argv[ipar + 1],
                                &(task.parm[jpar]),
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               break;
            }
         }
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Dump the task variables
   ========================================================================== */

#ifdef __TRACE__
   fprintf(stderr, "Debug: <%s> : <%s>\n", STBXPD_input_media_path,
      inImageName);
   fprintf(stderr, "Debug: <%s> : <%s>\n", STBXPD_input_head_file,
      inHeadName );
   fprintf(stderr, "Debug: <%s> : <%s>\n", STBXPD_input_media_type, mediaTypeTxt);
   fprintf(stderr, "Debug: <%s> : <%s>\n", STBXPD_output_image, 
      outImageName);
#endif
 
/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      if((!task.parm[ipar].founded ) && (task.parm[ipar].mandatory))
      {
#ifdef __TRACE__
         printf("Param %s not defined\n", task.parm[ipar].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ipar].name);
      }
   }

/* ==========================================================================
   Build full name of header analysis file
   ========================================================================== */
   sprintf( inHead, "%s%s", LDEFIV_inp_dir, inHeadName );

/* ==========================================================================
   Check ack_mount_flag
   ========================================================================== */
   if( (toupper( ack_mount_flag ) != 'Y') &&
       (toupper( ack_mount_flag ) != 'N') ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        STBXPD_ackn_mount_flag );
   }

/* ==========================================================================
   Check dismount_flag
   ========================================================================== */
   if( (toupper( dismount_flag ) != 'Y') &&
       (toupper( dismount_flag ) != 'N') ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        STBXPD_dismount_flag );
   }

/* ==========================================================================
   Check which media type has been selected
   ========================================================================== */
   for(ichar = 0; ichar < strlen(mediaTypeTxt); ichar++)
      mediaTypeTxt[ichar] = toupper(mediaTypeTxt[ichar]);

   if((strcmp(mediaTypeTxt, "DISK")) == 0)
      mediaType = DEVSIE_mt_file;
   else if((strcmp(mediaTypeTxt, "TAPE")) == 0)
      mediaType = DEVSIE_mt_exa;
   else if((strcmp(mediaTypeTxt, "CDROM")) == 0)
      mediaType = DEVSIE_mt_cdrom;
   else {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        STBXPD_input_media_type );
   }

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open the input header analysis file
   ========================================================================== */
   head_io.type = GIOSIE_tif;
   head_io.mode = 'r';
   strcpy( head_io.val.tif.name, inHead );
   head_io.img = 0;
   GIOSIP_open_io( &head_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
   fprintf(stderr,"Debug:  width = <%d>\n", inp_bpar.imagewidth);
   fprintf(stderr,"Debug: height = <%d>\n", inp_bpar.imagelength);
#endif

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( head_io.chan, head_io.img, inp_ima_num,
                           IANNID_EXTR_FRES, head_io.val.tif.bpar, 
                           status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of output file(s)
   ========================================================================== */
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         head_io.dt,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &head_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check on the input parameters outImage
   ========================================================================== */
   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Set productType and sensorId from the annotation
   ========================================================================== */
   switch ( IANNIV_ImageAnnot[ inp_ima_num ].ProductType ) {
      case IANNIE_prod_ERS1_RAW:
         productType = PMDSIE_raw_prod;
         sensorId = 1;
         break;
      case IANNIE_prod_ERS1_SLC:
         productType = PMDSIE_slc_prod;
         sensorId = 1;
         break;
      case IANNIE_prod_ERS1_SLCI:
         productType = PMDSIE_slci_prod;
         sensorId = 1;
         break;
      case IANNIE_prod_ERS1_PRI:
         productType = PMDSIE_pri_prod;
         sensorId = 1;
         break;
      case IANNIE_prod_ERS1_GEC:
         productType = PMDSIE_gec_prod;
         sensorId = 1;
         break;
      case IANNIE_prod_ERS1_GTC:
         productType = PMDSIE_gtc_prod;
         sensorId = 1;
         break;
      case IANNIE_prod_ERS2_RAW:
         productType = PMDSIE_raw_prod;
         sensorId = 2;
         break;
      case IANNIE_prod_ERS2_SLC:
         productType = PMDSIE_slc_prod;
         sensorId = 2;
         break;
      case IANNIE_prod_ERS2_SLCI:
         productType = PMDSIE_slci_prod;
         sensorId = 2;
         break;
      case IANNIE_prod_ERS2_PRI:
         productType = PMDSIE_pri_prod;
         sensorId = 2;
         break;
      case IANNIE_prod_ERS2_GEC:
         productType = PMDSIE_gec_prod;
         sensorId = 2;
         break;
      case IANNIE_prod_ERS2_GTC:
         productType = PMDSIE_gtc_prod;
         sensorId = 2;
         break;
   }

/* ==========================================================================
   Set dataFormat form the annotation
   ========================================================================== */
   if((strcmp(IANNIV_ImageAnnot[ inp_ima_num ].dataFormat, "ceos")) == 0)
      strcpy(dataFormat, "C");
   else if((strcmp(IANNIV_ImageAnnot[ inp_ima_num ].dataFormat, "mph-sph")) == 0)
      strcpy(dataFormat, "M");
   else if((strcmp(IANNIV_ImageAnnot[ inp_ima_num ].dataFormat, "envisat")) == 0)
      strcpy(dataFormat, "E");
   else {
      ERRSIM_set_error( status_code, ERRSID_PMDS_defo_prod,
         "Unknown data format" );
   }

/* ==========================================================================
   Set sourceId from the annotation
   ========================================================================== */
   strcpy( sourceId, IANNIV_ImageAnnot[ inp_ima_num ].sourceId );

/* ==========================================================================
   Set numOfVol from the annotation
   ========================================================================== */
   numOfVol = IANNIV_ImageAnnot[ inp_ima_num ].numberOfVolumes;
   
/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[2],
                            task.name,
                            section_no,
                            inp_ima_num,
                           &TLRow, &TLCol, &BRRow, &BRCol,
                           &vertex_no, &vertex,
                           &real_aoi,
                            status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   PMDSIP_Deformat( inImageName,
                    inp_ima_num,
                    mediaType,
                    productType,
                    sensorId,
                    dataFormat,
                    sourceId,
                    PMDSIE_FullResolutionMode,
                    numOfVol,
                    toupper( ack_mount_flag ),
                    toupper( dismount_flag ),
                    TLRow,
                    TLCol,
                    BRRow,
                    BRCol,
                    ql_width,
                    ql_height,
                    win_width,
                    win_height,
                    inHead,
                    outImage,
                    out_ima_num,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if((LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y'))
   {
;;;
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) )
   {
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_EXTR_FullResolution */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_QuickLook

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
                      - Call quick look routine
                      - Call stretching image routine
                      - Call drawing grid routine
                      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_EXTR_QuickLook
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_EXTR_QuickLook";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   DEVSIT_media_type       mediaType = DEVSIE_mt_none;
   char                    mediaTypeTxt[256];
   INTx4                   ichar;
   PMDSIT_product_type     productType = PMDSIE_unk_prod;
   INTx4                   sensorId;
   char                    dataFormat[16];
   char                    sourceId[16];
   INTx4                   numOfVol    = 0;
   UINTx4                  TLRow       = 0;
   UINTx4                  TLCol       = 0;
   UINTx4                  BRRow       = 0;
   UINTx4                  BRCol       = 0;
   INTx4                   ql_size[ 2 ];
   INTx4                   win_size[ 2 ];
   char                    msg[ 256 ];

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   char                    ack_mount_flag = 'Y';
   char                    dismount_flag = 'Y';
   INTx4                   ipar, iparno_points, iparno_qlsize, iparno_winsize,
                           iparMediaTypeTxt, iparHeadName, iparQLPresent;
   INTx4                   jpar;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inHead;
   FILSIT_file_name        undImage;
   FILSIT_file_name        qlImage;
   FILSIT_file_name        geoImage;
   FILSIT_file_name        outImage;
   FILSIT_file_name        inImageName, inImage;
   FILSIT_file_name        inHeadName;
   FILSIT_file_name        qlImageName;
   FILSIT_file_name        outImageName;
   char                    qlPresentationTxt[ 40 ];
   IANNIT_Presentation     qlPresentation;
   INTx4                   points[ 2 ];
   char                    lat_lon_txt[256];
   INTx4                   lat_lon_flag = TRUE;
   char                    drawing_grid[256];
   PMDSIT_drawing_mode     drawing_mode;
   float                   minPerc, maxPerc, noBlack;
   LDEFIT_boolean          noBlackFound;
   INTx4                   noBlackParNo;
   LDEFIT_boolean          internalFormat;
   UINTx4                  outImageSize;

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   INTx4                   inp_chan = 0;
   INTx4                   inp_img  = 0;
   TIFSIT_basicpar         inp_bpar;
   INTx4                   nimage;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            und_ima_num = 1;
   const UINTx1            ql_ima_num = 2;
   const UINTx1            geo_ima_num = 3;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 16 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL )
   {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_media_path );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_input_media_type );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( mediaTypeTxt );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) mediaTypeTxt;
   iparMediaTypeTxt = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_head_an_file );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inHeadName;
   iparHeadName = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_quick_look_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) qlImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_grid_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_grid_lines_num );
   task.parm[ ipar ].type       = FIISIE_tt_int;
   task.parm[ ipar ].size       = sizeof( INTx4 );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value      = (void *) points;
   iparno_points = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image_size );
   task.parm[ ipar ].type       = FIISIE_tt_int;
   task.parm[ ipar ].size       = sizeof( INTx4 );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value      = (void *) ql_size;
   iparno_qlsize = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_window_sizes );
   task.parm[ ipar ].type       = FIISIE_tt_int;
   task.parm[ ipar ].size       = sizeof( INTx4 );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = TRUE;
   task.parm[ ipar ].max_number = 2;
   task.parm[ ipar ].value      = (void *) win_size;
   iparno_winsize = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_grid_type );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( lat_lon_txt );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) lat_lon_txt;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_grid_drawing_mode );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( drawing_grid );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) drawing_grid;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_min_perc );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &minPerc;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_max_perc );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &maxPerc;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_no_black );
   task.parm[ ipar ].type = FIISIE_tt_float;
   task.parm[ ipar ].size = sizeof( float );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector = FALSE;
   task.parm[ ipar ].value = (void *) &noBlack;
   noBlackParNo = ipar;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_ackn_mount_flag );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &ack_mount_flag;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_dismount_flag );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &dismount_flag;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_quick_look_presentation );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( qlPresentationTxt );
   task.parm[ ipar ].mandatory  = FALSE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) qlPresentationTxt;
   iparQLPresent = ipar;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   ipar = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ ipar ].name, STBXPD_input_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_inp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_inp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_out_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_out_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_temporary_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_temp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_temp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_delete_input_image );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Set default values for minPerc and maxPerc
   ========================================================================== */
   minPerc =  2.70;
   maxPerc = 98.50;

/* ==========================================================================
   Get mediaTypeTxt in advance
   ========================================================================== */
   FIISIP_GETS_get_info(argv[2],
                           task.name,
                           section_no,
                           &(task.parm[ iparMediaTypeTxt ]),
                           status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check which media type has been selected
   ========================================================================== */
   if( task.parm[ iparMediaTypeTxt ].founded ) {
      for(ichar = 0; ichar < strlen(mediaTypeTxt); ichar++)
         mediaTypeTxt[ichar] = toupper(mediaTypeTxt[ichar]);

      internalFormat = FALSE;
      if((strcmp(mediaTypeTxt, "DISK")) == 0) {
         mediaType = DEVSIE_mt_file;
      }
      else if((strcmp(mediaTypeTxt, "TAPE")) == 0) {
         mediaType = DEVSIE_mt_exa;
      }
      else if((strcmp(mediaTypeTxt, "FILE")) == 0) {
         internalFormat = TRUE;
         mediaType = DEVSIE_mt_file;
      }
      else if((strcmp(mediaTypeTxt, "CDROM")) == 0) {
         mediaType = DEVSIE_mt_cdrom;
      }
      else {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_invalid,
                           STBXPD_input_media_type );
      }
   }
   if( internalFormat ) {
      task.parm[ iparHeadName ].mandatory  = FALSE;
   }
   else {
      task.parm[ iparHeadName ].mandatory  = TRUE;
   }

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      FIISIP_GETS_get_info(argv[2],
                           task.name,
                           section_no,
                           &(task.parm[ipar]),
                           status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for(ipar = 3; ipar < argc; ipar += 2)
   {
      if(argv[ipar][0] == STBXPD_prefix_line_arg)
      {
         sprintf(tmpParmName, "%s", &(argv[ipar][1]));
         for(jpar = 0; jpar < task.parmNo; jpar++)
         {
            if(!strcmp(tmpParmName, task.parm[jpar].name))
            {
               STBXPP_set_par((void *) argv[ipar + 1],
                                &(task.parm[jpar]),
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               break;
            }
         }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      if((!task.parm[ipar].founded ) && (task.parm[ipar].mandatory))
      {
#ifdef __TRACE__
         printf("Param %s not defined\n", task.parm[ipar].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ipar].name);
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Eval noBlackFound
   ========================================================================== */
   noBlackFound = task.parm[ noBlackParNo ].founded;

/* ==========================================================================
   Check number of grid lines
   ========================================================================== */
   if( task.parm[ iparno_points ].number < 2 ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_not_defined,
                        task.parm[ iparno_points ].name );
   }

/* ==========================================================================
   Accept number of grid lines row>=0 and col>=0 and (row>0 or col>0)
   ========================================================================== */
   if( ((points[ 0 ] <  0) || (points[ 1 ] <= 0)) &&
       ((points[ 0 ] <= 0) || (points[ 1 ] <  0)) ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        task.parm[ iparno_points ].name );
   }


/* ==========================================================================
   Check quick look and window size
   ========================================================================== */
   if( task.parm[ iparno_qlsize ].number < 2 ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_not_defined,
                        task.parm[ iparno_qlsize ].name );
   }

   if( ((ql_size[ 0 ] <  0) || (ql_size[ 1 ] <= 0)) &&
       ((ql_size[ 0 ] <= 0) || (ql_size[ 1 ] <  0)) ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        task.parm[ iparno_qlsize ].name );
   }

/* ==========================================================================
   Check window size
   ========================================================================== */
   if( task.parm[ iparno_winsize ].number < 2 ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_not_defined,
                        task.parm[ iparno_winsize ].name );
   }

   if( (win_size[ 0 ] <= 0) || (win_size[ 1 ] <= 0) ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        task.parm[ iparno_winsize ].name );
   }

/* ==========================================================================
   Check names of output files
   ========================================================================== */
   if( !strcmp( qlImageName, outImageName ) ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        "Use different name for output images" );
   }

/* ==========================================================================
   Check ack_mount_flag
   ========================================================================== */
   if( (toupper( ack_mount_flag ) != 'Y') &&
       (toupper( ack_mount_flag ) != 'N') ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        STBXPD_ackn_mount_flag );
   }

/* ==========================================================================
   Check dismount_flag
   ========================================================================== */
   if( (toupper( dismount_flag ) != 'Y') &&
       (toupper( dismount_flag ) != 'N') ) {
      ERRSIM_set_error( status_code,
                        ERRSID_STBX_parm_invalid,
                        STBXPD_dismount_flag );
   }

/* ==========================================================================
   Check quick-look presentation flag
   ========================================================================== */
   if( task.parm[ iparQLPresent ].founded ) {
      if( !strcmp( qlPresentationTxt, STBXPD_quick_look_normal ) ) {
         qlPresentation = IANNIE_pres_normal;
      }
      else if( !strcmp( qlPresentationTxt, STBXPD_quick_look_geo ) ) {
         qlPresentation = IANNIE_pres_geo;
      }
      else {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_invalid,
                           STBXPD_quick_look_presentation );
      }
   }
   else {
      qlPresentation = IANNIE_pres_geo;
   }

/* ==========================================================================
   Build full name of annotation file
   ========================================================================== */
   sprintf( inHead, "%s%s", LDEFIV_inp_dir, inHeadName );

/* ==========================================================================
   Build full name of output file(s)
   ========================================================================== */
   LDEFIP_UTIL_gen_tmp_name( undImage, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   STBXPP_bld_file_name( qlImageName,
                         task_name,
                         LDEFIE_dt_undef,
                         qlImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_undef,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   if( internalFormat == FALSE ) {

/* ==========================================================================
   Open the input file
   ========================================================================== */
      TIFSIP_open_tiff( inHead, 'r', &inp_chan, status_code);
      ERRSIM_on_err_goto_exit( *status_code );
      TIFSIP_get_imgnum( inp_chan, &nimage, status_code);
      ERRSIM_on_err_goto_exit( *status_code );
      TIFSIP_get_blockinfo( inp_chan, inp_img, &inp_bpar, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

#ifdef __TRACE__
      fprintf(stderr,"Debug:  width = <%d>\n", inp_bpar.imagewidth);
      fprintf(stderr,"Debug: height = <%d>\n", inp_bpar.imagelength);
#endif

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
      IANNIP_GETP_ImageAnnot( inp_chan, inp_img, inp_ima_num,
                              IANNID_EXTR_QLCK, inp_bpar, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set productType and sensorId from the annotation
   ========================================================================== */
      switch ( IANNIV_ImageAnnot[ inp_ima_num ].ProductType ) {
	 case IANNIE_prod_ERS1_RAW:
	    productType = PMDSIE_raw_prod;
	    sensorId = 1;
	    break;
	 case IANNIE_prod_ERS1_SLC:
	    productType = PMDSIE_slc_prod;
	    sensorId = 1;
	    break;
	 case IANNIE_prod_ERS1_SLCI:
	    productType = PMDSIE_slci_prod;
	    sensorId = 1;
	    break;
	 case IANNIE_prod_ERS1_PRI:
	    productType = PMDSIE_pri_prod;
	    sensorId = 1;
	    break;
	 case IANNIE_prod_ERS1_GEC:
	    productType = PMDSIE_gec_prod;
	    sensorId = 1;
	    break;
	 case IANNIE_prod_ERS1_GTC:
	    productType = PMDSIE_gtc_prod;
	    sensorId = 1;
	    break;
	 case IANNIE_prod_ERS2_RAW:
	    productType = PMDSIE_raw_prod;
	    sensorId = 2;
	    break;
	 case IANNIE_prod_ERS2_SLC:
	    productType = PMDSIE_slc_prod;
	    sensorId = 2;
	    break;
	 case IANNIE_prod_ERS2_SLCI:
	    productType = PMDSIE_slci_prod;
	    sensorId = 2;
	    break;
	 case IANNIE_prod_ERS2_PRI:
	    productType = PMDSIE_pri_prod;
	    sensorId = 2;
	    break;
	 case IANNIE_prod_ERS2_GEC:
	    productType = PMDSIE_gec_prod;
	    sensorId = 2;
	    break;
	 case IANNIE_prod_ERS2_GTC:
	    productType = PMDSIE_gtc_prod;
	    sensorId = 2;
	    break;
      }

/* ==========================================================================
   Check if geographic presentation is requested for GEC and GTC products
   ========================================================================== */
      if( (productType == PMDSIE_gec_prod) ||
          (productType == PMDSIE_gtc_prod) ) {
         if( qlPresentation == IANNIE_pres_geo) {
            sprintf( msg, "Compute column size %0d", ql_size[ 1 ] );
            ERRSIM_print_warning( 
               "Geographic presentation for GEC/GTC products not allowed. \
Rendering as normal");
            qlPresentation = IANNIE_pres_normal;
         }
      }

/* ==========================================================================
   Set dataFormat form the annotation
   ========================================================================== */
      if((strcmp(IANNIV_ImageAnnot[ inp_ima_num ].dataFormat, "ceos")) == 0) {
         strcpy(dataFormat, "C");
      }
      else if((strcmp(IANNIV_ImageAnnot[ inp_ima_num ].dataFormat, "mph-sph")) == 0) {
         strcpy(dataFormat, "M");
      }
      else if((strcmp(IANNIV_ImageAnnot[ inp_ima_num ].dataFormat, "envisat")) == 0) {
         strcpy(dataFormat, "E");
      }
      else {
         ERRSIM_set_error( status_code, ERRSID_PMDS_defo_prod,
            "Unknown data format" );
      }

/* ==========================================================================
   Set sourceId from the annotation
   ========================================================================== */
      strcpy( sourceId, IANNIV_ImageAnnot[ inp_ima_num ].sourceId );

/* ==========================================================================
   Set numOfVol from the annotation
   ========================================================================== */
      numOfVol = IANNIV_ImageAnnot[ inp_ima_num ].numberOfVolumes;
   
/* ==========================================================================
   Close the input file ...
   ========================================================================== */
      TIFSIP_close_tiff( inp_chan, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Exit for RAW products
   ========================================================================== */
      if( productType == PMDSIE_raw_prod ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            STBXPD_product_type );
      }

/* ==========================================================================
   Ckeck win_size
   ========================================================================== */
      if( (win_size[ 0 ] <= 0) || (win_size[ 1 ] <= 0) ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_negative,
                           task.parm[ iparno_qlsize ].name );
      }

/* ==========================================================================
   Compute output size when row or column is 0
   ========================================================================== */
      if( (ql_size[ 0 ] == 0) && (ql_size[ 1 ] == 0) ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_invalid,
                           task.parm[ iparno_qlsize ].name );
      }
      else {
/* ==========================================================================
   Compute column size when column is 0
   ========================================================================== */
         if( ql_size[ 1 ] == 0 ) {
            float  steprow, stepcol;
            float  pixelspacing;
            steprow =  (float) SRVSIM_step( inp_bpar.imagelength, 
                                            win_size[ 0 ], ql_size[ 0 ] );
            if( (IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m == 0.0) ||
                (IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m == 0.0) ) {
               ERRSIM_set_error( status_code,
                                 ERRSID_STBX_parm_invalid,
                                 "Null Line Spacing or Pixel Spacing" );
            }
            pixelspacing = IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m * 
                           steprow;
            stepcol = pixelspacing/IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m;
            ql_size[ 1 ] = SRVSIM_out( inp_bpar.imagewidth, win_size[ 1 ], stepcol );
            sprintf( msg, "Compute column size %0d", ql_size[ 1 ] );
            ERRSIM_print_warning( msg );
         }
/* ==========================================================================
   Compute row
   ========================================================================== */
         else if( ql_size[ 0 ] == 0 ) {
            float  steprow, stepcol;
            float  linespacing;
            stepcol =  (float) SRVSIM_step( inp_bpar.imagewidth, 
                                            win_size[ 1 ], ql_size[ 1 ] );
            if( (IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m == 0.0) ||
                (IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m == 0.0) ) {
               ERRSIM_set_error( status_code,
                                 ERRSID_STBX_parm_invalid,
                                 "Null Line Spacing or Pixel Spacing" );
            }
            linespacing = IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m * 
                          stepcol;
            steprow = linespacing/IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m;
            ql_size[ 0 ] = SRVSIM_out( inp_bpar.imagelength, win_size[ 0 ], steprow );
            sprintf( msg, "Compute row size %0d", ql_size[ 0 ] );
            ERRSIM_print_warning( msg );
         }
      }

#ifndef __DEBUG_MODE__

/* ==========================================================================
   Check if both image can be stored on disk
   ========================================================================== */
      outImageSize = ((ql_size[ 0 ] * ql_size[ 1 ])/1024) + 
                     LDEFID_ann_kbytes;
      FILSIP_open( outImage, "w", outImageSize*2, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      FILSIP_close( &fp, &log_status_code );

      FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
      PMDSIP_Deformat( inImageName,
                       inp_ima_num,
                       mediaType,
                       productType,
                       sensorId,
                       dataFormat,
                       sourceId,
                       PMDSIE_QuickLookMode,
                       numOfVol,
                       toupper( ack_mount_flag ),
                       toupper( dismount_flag ),
                       TLRow,
                       TLCol,
                       BRRow,
                       BRCol,
                       ql_size[ 1 ],
                       ql_size[ 0 ],
                       win_size[ 1 ],
                       win_size[ 0 ],
                       inHead,
                       undImage,
                       und_ima_num,
                       status_code );
      ERRSIM_on_err_goto_exit( *status_code );

#else
      {
         GIOSIT_io temp_io;
         INTx4     key_press;

         fprintf(stdout, 
            "Copy to stb00000.tmp and press <Enter> to continue ...\n" );

         fflush( stdin );
         key_press = 0;
         while(key_press == 0)
         {
            key_press = getchar();
         }

/* ==========================================================================
   Open existing file
   ========================================================================== */
         sprintf( undImage, "%s%s", LDEFIV_temp_dir, "stb00000.tmp" );
         temp_io.type = GIOSIE_tif;
         temp_io.mode = 'r';
         strcpy( temp_io.val.tif.name, undImage );
         temp_io.img = 0;
         GIOSIP_open_io( &temp_io,
                          status_code);
         ERRSIM_on_err_goto_exit( *status_code );
   
/* ==========================================================================
   Get the image annotations
   ========================================================================== */
         IANNIP_GETP_ImageAnnot( temp_io.chan, 0, und_ima_num,
                                 IANNID_EXTR_QLCK, temp_io.val.tif.bpar, status_code);
         ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close
   ========================================================================== */
         GIOSIP_close_io( &temp_io, status_code);
         ERRSIM_on_err_goto_exit( *status_code );
      }
   
#endif
   }
   else {
      GIOSIT_io               inp_io, out_io;
      UINTx4                  npar;
      UINTx4                  nrow_out;
      UINTx4                  ncol_out;
      UINTx4                  nrow_inp;
      UINTx4                  ncol_inp;
      UINTx4                  TLRow = 0, TLCol = 0;
      double                  win_increments[ 2 ];

/* ==========================================================================
   Build input image name
   ========================================================================== */
      sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );

/* ==========================================================================
   Open internal format file
   ========================================================================== */
      inp_io.type = GIOSIE_tif;
      inp_io.mode = 'r';
      strcpy( inp_io.val.tif.name, inImage );
      inp_io.img = 0;
      GIOSIP_open_io( &inp_io,
                       status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set inp_bpar 
   ========================================================================== */
      memcpy( (void *) &inp_bpar, 
              (void *) &inp_io.val.tif.bpar, 
              sizeof( TIFSIT_basicpar ) );

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
      IANNIP_GETP_ImageAnnot( inp_chan, inp_img, inp_ima_num,
                              IANNID_EXTR_QLCK, inp_bpar, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
      Set nrow_inp/ncol_inp
   ========================================================================== */
      nrow_inp = inp_io.val.tif.bpar.imagelength;
      ncol_inp = inp_io.val.tif.bpar.imagewidth;

#ifdef __TRACE__
      fprintf( stderr, "nrow_inp=%0d ncol_inp=%0d\n",
         nrow_inp, ncol_inp );
#endif

/* ==========================================================================
   Check if geographic presentation is requested for GEC and GTC products
   ========================================================================== */
      if( (IANNIV_ImageAnnot[ inp_ima_num ].ProductType == 
           IANNIE_prod_ERS1_GEC) ||
          (IANNIV_ImageAnnot[ inp_ima_num ].ProductType ==
           IANNIE_prod_ERS1_GTC) ||
          (IANNIV_ImageAnnot[ inp_ima_num ].ProductType ==
           IANNIE_prod_ERS2_GEC) ||
          (IANNIV_ImageAnnot[ inp_ima_num ].ProductType ==
           IANNIE_prod_ERS2_GTC) ) {
         if( qlPresentation == IANNIE_pres_geo) {
            sprintf( msg, "Compute column size %0d", ql_size[ 1 ] );
            ERRSIM_print_warning( 
               "Geographic presentation for GEC/GTC products not allowed. \
Rendering as normal");
            qlPresentation = IANNIE_pres_normal;
         }
      }

/* ==========================================================================
   Compute output size when row or column is 0
   ========================================================================== */
      if( (ql_size[ 0 ] == 0) && (ql_size[ 1 ] == 0) ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_invalid,
                           task.parm[ iparno_qlsize ].name );
      }
      else {
/* ==========================================================================
   Compute column size when column is 0
   ========================================================================== */
         if( ql_size[ 1 ] == 0 ) {
            float  steprow, stepcol;
            float  pixelspacing;
            steprow =  (float) SRVSIM_step( inp_bpar.imagelength, 
                                            win_size[ 0 ], ql_size[ 0 ] );
            if( (IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m == 0.0) ||
                (IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m == 0.0) ) {
               ERRSIM_set_error( status_code,
                                 ERRSID_STBX_parm_invalid,
                                 "Null Line Spacing or Pixel Spacing" );
            }
            pixelspacing = IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m * 
                           steprow;
            stepcol = pixelspacing/IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m;
            ql_size[ 1 ] = SRVSIM_out( inp_bpar.imagewidth, win_size[ 1 ], stepcol );
            sprintf( msg, "Compute column size %0d", ql_size[ 1 ] );
            ERRSIM_print_warning( msg );
         }
/* ==========================================================================
   Compute row
   ========================================================================== */
         else if( ql_size[ 0 ] == 0 ) {
            float  steprow, stepcol;
            float  linespacing;
            stepcol =  (float) SRVSIM_step( inp_bpar.imagewidth, 
                                            win_size[ 1 ], ql_size[ 1 ] );
            if( (IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m == 0.0) ||
                (IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m == 0.0) ) {
               ERRSIM_set_error( status_code,
                                 ERRSID_STBX_parm_invalid,
                                 "Null Line Spacing or Pixel Spacing" );
            }
            linespacing = IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m * 
                          stepcol;
            steprow = linespacing/IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m;
            ql_size[ 0 ] = SRVSIM_out( inp_bpar.imagelength, win_size[ 0 ], steprow );
            sprintf( msg, "Compute row size %0d", ql_size[ 0 ] );
            ERRSIM_print_warning( msg );
         }
      }

/* ==========================================================================
   Compute win_increments of out image
   ========================================================================== */
      if( win_size[ 0 ] <= 0 ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_negative,
                           task.parm[ iparno_winsize ].name );
      }
      if( ql_size[ 0 ] <= 0 ) {
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_negative,
                           task.parm[ iparno_qlsize ].name );
      }
      win_increments[ 0 ] = 
         SRVSIM_step( nrow_inp, win_size[ 0 ], ql_size[ 0 ] );

      if( nrow_inp < win_size[ 0 ] ) {
         ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
            "Row window size greater or equal that number of input rows" );
      }
      nrow_out = ql_size[ 0 ];

      if( ( task.parm[ iparno_winsize ].number > 1 ) &&
          ( task.parm[ iparno_winsize ].number > 1 ) ) {
         if( win_size[ 1 ] <= 0 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_negative,
                              task.parm[ iparno_winsize ].name );
         }
         if( ql_size[ 1 ] <= 0 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_negative,
                              task.parm[ iparno_qlsize ].name );
         }
         win_increments[ 1 ] = 
            SRVSIM_step( ncol_inp, win_size[ 1 ], ql_size[ 1 ] );

         if( ncol_inp < win_size[ 1 ] ) {
            ERRSIM_set_error( status_code, ERRSID_STBX_parm_invalid,
               "Column window size greater or equal that number of input columns");
         }
         ncol_out = ql_size[ 1 ];

      }
      else {
         if( task.parm[ iparno_qlsize ].number <= 1 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_defined,
                              task.parm[ iparno_qlsize ].name );
         }
         if( task.parm[ iparno_winsize ].number <= 1 ) {
            ERRSIM_set_error( status_code,
                              ERRSID_STBX_parm_not_defined,
                              task.parm[ iparno_winsize ].name );
         }
      }

#ifdef __TRACE__
      fprintf( stderr, "nrow_out = %0d\nncol_out=%0d\nstep=%f,%f\n", 
         nrow_out, ncol_out, win_increments[ 0 ], win_increments[ 1 ] );
#endif

/* ==========================================================================
   Check if both image can be stored on disk
   ========================================================================== */
      outImageSize = ((ql_size[ 0 ] * ql_size[ 1 ])/1024) + 
                     LDEFID_ann_kbytes;
      FILSIP_open( outImage, "w", outImageSize*2, &fp, status_code );
      ERRSIM_on_err_goto_exit( *status_code );
      FILSIP_close( &fp, &log_status_code );

      FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
      TIFSIM_bpar_init( out_io.val.tif.bpar );
      out_io.val.tif.bpar.imagelength = nrow_out;
      out_io.val.tif.bpar.imagewidth = ncol_out;
      out_io.val.tif.bpar.sampleperpixel = 1;
      out_io.val.tif.bpar.bitspersample[0] =
                (UINTx2)(sizeof(float)*LDEFID_byte_size);
      out_io.val.tif.bpar.sampleformat[0] = TIFSID_float;
      out_io.val.tif.bpar.disposition = 'x';
      npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
      out_io.type = GIOSIE_tif;
      out_io.mode = 'w';
      strcpy( out_io.val.tif.name, undImage);
      out_io.val.tif.nimg = 1;
      out_io.val.tif.npar = npar;
      out_io.img = 0;
      GIOSIP_open_io( &out_io,
                       status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
      STATIP_LOCA_stat(&inp_io,
                        inp_ima_num,
                        TLRow,
                        TLCol,
                        nrow_inp,
                        ncol_inp,
                        (UINTx4) 0,
                        (MATHIT_RC *) NULL,
                        win_size,
                        win_increments,
                        0.0,
                       &out_io,
                        nrow_out,
                        ncol_out,
                        STATIE_image_mean,
                        status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set und_ima_num annotations
   ========================================================================== */
      IANNIP_GETP_CopyAnnot( inp_ima_num, und_ima_num, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
      IANNIV_ImageAnnot[ und_ima_num ].ImageLength =
                                     out_io.val.tif.bpar.imagelength;
      IANNIV_ImageAnnot[ und_ima_num ].ImageWidth =
                                     out_io.val.tif.bpar.imagewidth;
      switch ( out_io.val.tif.bpar.sampleperpixel ) {
         case 1:
            IANNIV_ImageAnnot[ und_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
            IANNIV_ImageAnnot[ und_ima_num ].SampleFormat[0] =
                                     out_io.val.tif.bpar.sampleformat[0];
         break;
         case 2:
            IANNIV_ImageAnnot[ und_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
            IANNIV_ImageAnnot[ und_ima_num ].BitsPerSample[1] =
                                     out_io.val.tif.bpar.bitspersample[1];
            IANNIV_ImageAnnot[ und_ima_num ].SampleFormat[0] =
                                     out_io.val.tif.bpar.sampleformat[0];
            IANNIV_ImageAnnot[ und_ima_num ].SampleFormat[1] =
                                     out_io.val.tif.bpar.sampleformat[1];
         break;
      }

/* ==========================================================================
   Set pixel spacing
   ========================================================================== */
      IANNIV_ImageAnnot[ und_ima_num ].PixelSpacing_m *=
         ((float) (ncol_inp - 1))/((float) (ncol_out - 1));
      IANNIV_ImageAnnot[ und_ima_num ].LineSpacing_m *=
         ((float) (nrow_inp - 1))/((float) (nrow_out - 1));

/* ==========================================================================
   Set scaling factor
   ========================================================================== */
      IANNIV_ImageAnnot[ und_ima_num ].XScalingFactor /=
         ((float) (ncol_inp - 1))/((float) (ncol_out - 1));
      IANNIV_ImageAnnot[ und_ima_num ].YScalingFactor /=
         ((float) (nrow_inp - 1))/((float) (nrow_out - 1));

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
      STBXPP_update_coordinates( und_ima_num,
                                 status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the processing history tag
   ========================================================================== */
      IANNIP_PUTP_UpdateProcHistory( und_ima_num,
                                     task.name,
                                     "",
                                     status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
      IANNIP_PUTP_ImageAnnot(  out_io.chan,
                               out_io.img,
                               und_ima_num,
                               status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file
   ========================================================================== */
      GIOSIP_close_io( &out_io, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
      GIOSIP_close_io( &inp_io, status_code);
      ERRSIM_on_err_goto_exit( *status_code );

                                           
   }

/* ==========================================================================
   Set ql_ima_num annotations
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( und_ima_num, ql_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Change image disposition for geographic presentation
   ========================================================================== */
   if( qlPresentation == IANNIE_pres_geo ) {

/* ==========================================================================
   The ouput image is the geographic rendered one
   ========================================================================== */
      strcpy( geoImage, qlImage );

/* ==========================================================================
   Generate a temporary file for quick-look normal image   
   ========================================================================== */
      LDEFIP_UTIL_gen_tmp_name( qlImage, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Call stretching routine
   ========================================================================== */
      fprintf( stdout, "\nDoing stretching ...\n");
      PMDSIP_STRE_TiffFileData( undImage,
                                und_ima_num,
                                minPerc,
                                maxPerc,
                                noBlackFound,
                                noBlack,
                                qlImage,
                                ql_ima_num, /* dummy; not filled */
                                status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete output image of deformatting
   ========================================================================== */
      FILSIP_delete( undImage, &log_status_code );

/* ==========================================================================
   Set geo_ima_num annotations
   ========================================================================== */
      IANNIP_GETP_CopyAnnot( ql_ima_num, geo_ima_num, status_code );
      ERRSIM_on_err_goto_exit( *status_code );

      fprintf( stdout, "\nRendering to geographic presentation ...\n");
      PMDSIP_STRE_GeoPresentation(  qlImage,
                                    ql_ima_num,
                                    geoImage,
                                    geo_ima_num,
                                    status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete quick look image rendered in normal mode
   ========================================================================== */
      FILSIP_delete( qlImage, &log_status_code );

/* ==========================================================================
      Reset the image name
   ========================================================================== */
      strcpy( qlImage, geoImage );


   }
   else {
/* ==========================================================================
   Call stretching routine
   ========================================================================== */
      fprintf( stdout, "\nDoing stretching ...\n");
      PMDSIP_STRE_TiffFileData( undImage,
                                und_ima_num,
                                minPerc,
                                maxPerc,
                                noBlackFound,
                                noBlack,
                                qlImage,
                                ql_ima_num,
                                status_code );
      ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete output image of deformatting
   ========================================================================== */
      FILSIP_delete( undImage, &log_status_code );

   }

/* ==========================================================================
   Check which kind of grid has been selected
   ========================================================================== */
   for(ichar = 0; ichar < strlen(drawing_grid); ichar++)
      drawing_grid[ichar] = toupper(drawing_grid[ichar]);

   drawing_mode = PMDSIE_drawing_transparent;
   if((strcmp(drawing_grid, STBXPD_grid_none)) == 0)
      drawing_mode = PMDSIE_drawing_none;
   else if((strcmp(drawing_grid, STBXPD_grid_overwrite)) == 0)
      drawing_mode = PMDSIE_drawing_overwrite;
   else if((strcmp(drawing_grid, STBXPD_grid_transparent)) == 0)
      drawing_mode = PMDSIE_drawing_transparent;

/* ==========================================================================
   Check which type of grid has been selected
   ========================================================================== */
   for(ichar = 0; ichar < strlen(lat_lon_txt); ichar++)
      lat_lon_txt[ichar] = toupper(lat_lon_txt[ichar]);

   lat_lon_flag = TRUE;
   if((strcmp(lat_lon_txt, STBXPD_row_col)) == 0)
      lat_lon_flag = FALSE;
   else if((strcmp(lat_lon_txt, STBXPD_lat_lon)) == 0)
      lat_lon_flag = TRUE;

/* ==========================================================================
   Call grid maker routine
   ========================================================================== */
   PMDSIP_GRID_DrawArea( qlImage,
                         inp_ima_num,
                         ((qlPresentation == IANNIE_pres_geo) ?
                             geo_ima_num : und_ima_num ),
                         outImage,
                         points[ 1 ],
                         points[ 0 ],
                         lat_lon_flag,
                         drawing_mode,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if((LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y'))
   {
;;;
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;
/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) )
   {
#ifndef __DEBUG_MODE__
      FILSIP_delete( undImage, &log_status_code );
      FILSIP_delete( qlImage, &log_status_code );
      FILSIP_delete( geoImage, &log_status_code );
      FILSIP_delete( outImage, &log_status_code );
#endif
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_EXTR_QuickLook */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_Preview

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call Preview routine

   $EH
   ========================================================================== */
void STBXPP_EXTR_Preview
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_EXTR_Preview";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   ipar;
   INTx4                   jpar;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   FILSIT_file_name        inImageName;
   FILSIT_file_name        outImageName;
   FILSIT_file_name        inImage;
   FILSIT_file_name        outImage;
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   INTx4                   inp_chan = 0;
   INTx4                   inp_img  = 0;
   TIFSIT_basicpar         inp_bpar;
   INTx4                   nimage;
   const UINTx1            inp_ima_num = 0;
   const UINTx1            tmp_ima_num = 1;
   LDEFIT_boolean          real_aoi;
   FIISIT_parm             tmpParm;
   char                    tmpString[ 256 ];

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL )
   {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outImageName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   ipar = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ ipar ].name, STBXPD_input_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_inp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_inp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_out_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_out_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_temporary_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_temp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_temp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_delete_input_image );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      FIISIP_GETS_get_info(argv[ 2 ],
                           task.name,
                           section_no,
                           &(task.parm[ipar]),
                           status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for(ipar = 3; ipar < argc; ipar += 2)
   {
      if(argv[ipar][0] == STBXPD_prefix_line_arg)
      {
         sprintf(tmpParmName, "%s", &(argv[ipar][1]));
         for(jpar = 0; jpar < task.parmNo; jpar++)
         {
            if(!strcmp(tmpParmName, task.parm[jpar].name))
            {
               STBXPP_set_par((void *) argv[ipar + 1],
                                &(task.parm[jpar]),
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               break;
            }
         }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      if((!task.parm[ipar].founded ) && (task.parm[ipar].mandatory))
      {
#ifdef __TRACE__
         printf("Param %s not defined\n", task.parm[ipar].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ipar].name);
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input file(s)
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName);

/* ==========================================================================
   Build full name of output file(s)
   ========================================================================== */
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_undef,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Open the input file
   ========================================================================== */
   TIFSIP_open_tiff( inImage, 'r', &inp_chan, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_imgnum( inp_chan, &nimage, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   TIFSIP_get_blockinfo( inp_chan, inp_img, &inp_bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_chan, inp_img, inp_ima_num,
                           IANNID_EXTR_PREV, inp_bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Set tmp_ima_num annotation of the full image
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, tmp_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the image annotations as full image
   ========================================================================== */
   IANNIV_ImageAnnot[ tmp_ima_num ].ImageLength =
         (INTx4) ROUND((IANNIV_ImageAnnot[ inp_ima_num ].ImageLength - 1) /
                 IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor) + 1;
   IANNIV_ImageAnnot[ tmp_ima_num ].ImageWidth =
         (INTx4) ROUND((IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth - 1) /
                 IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor) + 1;
 
   IANNIV_ImageAnnot[ tmp_ima_num ].LineSpacing_m =
         IANNIV_ImageAnnot[ inp_ima_num ].LineSpacing_m *
         IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor;
   IANNIV_ImageAnnot[ tmp_ima_num ].PixelSpacing_m =
         IANNIV_ImageAnnot[ inp_ima_num ].PixelSpacing_m *
         IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor;

   IANNIV_ImageAnnot[ tmp_ima_num ].XScalingFactor = 1.0;
   IANNIV_ImageAnnot[ tmp_ima_num ].YScalingFactor = 1.0;

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[2],
                            task.name,
                            section_no,
                            tmp_ima_num,
                           &TLRow, &TLCol, &BRRow, &BRCol,
                           &vertex_no, &vertex,
                           &real_aoi,
                            status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Reset the coordinates to quick look image
   ========================================================================== */
   TLRow = (UINTx4) ROUND( TLRow * 
                              IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);
   BRRow = (UINTx4) ROUND( BRRow * 
                              IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);
   TLCol = (UINTx4) ROUND( TLCol * 
                              IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);
   BRCol = (UINTx4) ROUND( BRCol * 
                              IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   If the input image has a geographic presentation update coordinates
   ========================================================================== */
   if( IANNIV_ImageAnnot[ inp_ima_num ].Presentation ==
       IANNIE_pres_geo ) {
      if( IANNIV_ImageAnnot[ inp_ima_num ].OrbitDirection ==
	  IANNIE_orbit_descend ) {
         UINTx4   TLColOld;
         TLColOld = TLCol;
         TLCol = IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth  - BRCol - 1;
         BRCol = IANNIV_ImageAnnot[ inp_ima_num ].ImageWidth -  TLColOld - 1;
      }
      else {
         UINTx4   TLRowOld;
         TLRowOld = TLRow;
         TLRow = IANNIV_ImageAnnot[ inp_ima_num ].ImageLength - BRRow - 1;
         BRRow = IANNIV_ImageAnnot[ inp_ima_num ].ImageLength - TLRowOld - 1;
      }
   }

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   TIFSIP_close_tiff( inp_chan, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   PMDSIP_VIEW_CreatePreviewFile( inImage,
                                  inp_ima_num,
                                  TLCol,
                                  TLRow,
                                  BRCol,
                                  BRRow,
                                  outImage,
                                  status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if((LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y'))
   {
;;;
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;
/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output file(s), if an error occured (if any)
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) )
   {
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_EXTR_Preview */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_CoordRetr

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call PMDSIP_RETR_CheckImage routine

   $EH
   ========================================================================== */
void STBXPP_EXTR_CoordRetr
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_EXTR_CoordRetr";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   ipar;
   INTx4                   jpar;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImageName;
   FILSIT_file_name        subImageName;
   FILSIT_file_name        retrImageName;
   FILSIT_file_name        inImage;
   FILSIT_file_name        subImage;
   FILSIT_file_name        retrImage;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 3 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL )
   {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_cropped_tiff_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) subImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_coord_file );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) retrImageName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   ipar = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ ipar ].name, STBXPD_input_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_inp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_inp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_out_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_out_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_temporary_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_temp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_temp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_delete_input_image );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      FIISIP_GETS_get_info(argv[2],
                           task.name,
                           section_no,
                           &(task.parm[ipar]),
                           status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for(ipar = 3; ipar < argc; ipar += 2)
   {
      if(argv[ipar][0] == STBXPD_prefix_line_arg)
      {
         sprintf(tmpParmName, "%s", &(argv[ipar][1]));
         for(jpar = 0; jpar < task.parmNo; jpar++)
         {
            if(!strcmp(tmpParmName, task.parm[jpar].name))
            {
               STBXPP_set_par((void *) argv[ipar + 1],
                                &(task.parm[jpar]),
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               break;
            }
         }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      if((!task.parm[ipar].founded ) && (task.parm[ipar].mandatory))
      {
#ifdef __TRACE__
         printf("Param %s not defined\n", task.parm[ipar].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ipar].name);
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input file(s)
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName);

/* ==========================================================================
   Build full name of subimage file(s)
   ========================================================================== */
   sprintf( subImage, "%s%s", LDEFIV_out_dir, subImageName);

/* ==========================================================================
   Build full name of output file(s)
   ========================================================================== */
   STBXPP_bld_file_name( retrImageName,
                         task_name,
                         LDEFIE_dt_undef,
                         retrImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   PMDSIP_RETR_CheckImage( inImage,
                           subImage,
                           retrImage,
                           status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if((LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y'))
   {
;;;
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;
/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

/* ==========================================================================
   Delete output file(s), if an error occured (if any)
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) )
   {
      ;;;
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_EXTR_CoordRetr */



/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_SupportData

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call PMDSIP_SUPP_SetSupportData routine

   $EH
   ========================================================================== */
void STBXPP_EXTR_SupportData
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_EXTR_SupportData";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   ipar;
   INTx4                   jpar;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImageName;
   FILSIT_file_name        outImageName;
   FILSIT_file_name        inImage;
   FILSIT_file_name        outImage;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL )
   {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   ipar = 0;
   strcpy( task.parm[ ipar ].name, STBXPD_input_support_data_file );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) inImageName;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_image );
   task.parm[ ipar ].type       = FIISIE_tt_string;
   task.parm[ ipar ].size       = sizeof( FILSIT_file_name );
   task.parm[ ipar ].mandatory  = TRUE;
   task.parm[ ipar ].vector     = FALSE;
   task.parm[ ipar ].value      = (void *) outImageName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   ipar = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ ipar ].name, STBXPD_input_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_inp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_inp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_output_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_out_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_out_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_temporary_dir );
   task.parm[ ipar ].type      = FIISIE_tt_string;
   task.parm[ ipar ].size      = sizeof( LDEFIV_temp_dir );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) LDEFIV_temp_dir;

   ipar++;
   strcpy( task.parm[ ipar ].name, STBXPD_delete_input_image );
   task.parm[ ipar ].type      = FIISIE_tt_char;
   task.parm[ ipar ].size      = sizeof( char );
   task.parm[ ipar ].mandatory = FALSE;
   task.parm[ ipar ].vector    = FALSE;
   task.parm[ ipar ].value     = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      FIISIP_GETS_get_info(argv[2],
                           task.name,
                           section_no,
                           &(task.parm[ipar]),
                           status_code);
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for(ipar = 3; ipar < argc; ipar += 2)
   {
      if(argv[ipar][0] == STBXPD_prefix_line_arg)
      {
         sprintf(tmpParmName, "%s", &(argv[ipar][1]));
         for(jpar = 0; jpar < task.parmNo; jpar++)
         {
            if(!strcmp(tmpParmName, task.parm[jpar].name))
            {
               STBXPP_set_par((void *) argv[ipar + 1],
                                &(task.parm[jpar]),
                                status_code );
               ERRSIM_on_err_goto_exit( *status_code );
               break;
            }
         }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for(ipar = 0; ipar < task.parmNo; ipar++)
   {
      if((!task.parm[ipar].founded ) && (task.parm[ipar].mandatory))
      {
#ifdef __TRACE__
         printf("Param %s not defined\n", task.parm[ipar].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ipar].name);
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input file(s)
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName);

/* ==========================================================================
   Build full name of output file(s)
   ========================================================================== */
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         LDEFIE_dt_float,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   PMDSIP_SUPP_SetSupportData( inImage,
                               outImage,
                               status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if((LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y'))
   {
;;;
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;
/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );

/* ==========================================================================
   Delete output file(s), if an error occured (if any)
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) )
   {
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_EXTR_SupportData */


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_Portion

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the PORTION EXTRACTION task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call STATIP_LOCA_stat routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
void STBXPP_EXTR_Portion
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code )
{
   const ERRSIT_proc_name routine_name = "STBXPP_EXTR_Portion";
   ERRSIT_status          log_status_code;
   ERRSIT_flag            process_flag;

/* ==========================================================================
   Task structure variables
   ========================================================================== */
   STBXPT_task             task;
   INTx4                   i, j;
   FIISIT_parm_name        tmpParmName;
   FILE                   *fp = (FILE *) NULL;
   FILSIT_file_name        inImage, outImage;
   FILSIT_file_name        inImageName, outImageName;
   LDEFIT_boolean          real_aoi;

/* ==========================================================================
   TIFF Variables
   ========================================================================== */
   GIOSIT_io               inp_io, out_io;
   UINTx2                  npar = 0;

/* ==========================================================================
   Algorithm variables
   ========================================================================== */
   UINTx4                  vertex_no = 0;
   MATHIT_RC              *vertex = (MATHIT_RC *) NULL;
   UINTx4                  TLRow = 0;
   UINTx4                  TLCol = 0;
   UINTx4                  BRRow = 0;
   UINTx4                  BRCol = 0;
   INTx4                   win_sizes[ 2 ];
   double                  win_increments[ 2 ];
   LDEFIT_boolean          out_open = FALSE;
   UINTx4                  nrow_inp;
   UINTx4                  ncol_inp;
   UINTx4                  nrow_out;
   UINTx4                  ncol_out;
   float                   fill_val = 0.0;

/* ==========================================================================
   Annotation variables
   ========================================================================== */
   const UINTx1            inp_ima_num = 0;
   const UINTx1            out_ima_num = 1;

/* ==========================================================================
   Default initialization.
   ========================================================================== */
   *status_code    = STC( ERRSID_normal );
   log_status_code = STC( ERRSID_normal );

   ERRSIM_init_routine(  routine_name, 
                        &process_flag,
                        &log_status_code);

/* ==========================================================================
   Log start
   ========================================================================== */
   STBXPM_start_task( task_name );

/* ==========================================================================
   Initialize the task structure
   ========================================================================== */
   task.parm = (FIISIT_parm *) NULL;
   strcpy( task.name, task_name );
   task.parmNo = 2 + STBXPD_default_parm_no;

   task.parm = (FIISIT_parm *) 
                  MEMSIP_alloc( task.parmNo * sizeof( FIISIT_parm ) );
   if( task.parm == (FIISIT_parm *) NULL ) {
      ERRSIM_set_error( status_code, ERRSID_STBX_err_mem_alloc, "");
   }

/* ==========================================================================
   Initialize the parameters to be read
   ========================================================================== */
   strcpy( task.parm[ 0 ].name, STBXPD_input_image );
   task.parm[ 0 ].type = FIISIE_tt_string;
   task.parm[ 0 ].size = sizeof( FILSIT_file_name );
   task.parm[ 0 ].mandatory = TRUE;
   task.parm[ 0 ].vector = FALSE;
   task.parm[ 0 ].value = (void *) inImageName;

   strcpy( task.parm[ 1 ].name, STBXPD_output_image );
   task.parm[ 1 ].type = FIISIE_tt_string;
   task.parm[ 1 ].size = sizeof( FILSIT_file_name );
   task.parm[ 1 ].mandatory = TRUE;
   task.parm[ 1 ].vector = FALSE;
   task.parm[ 1 ].value = (void *) outImageName;

/* ==========================================================================
   Add default parameter for input/temporary/output dir
   ========================================================================== */
   i = task.parmNo - STBXPD_default_parm_no;
   strcpy( task.parm[ i ].name, STBXPD_input_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_inp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_inp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_output_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_out_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_out_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_temporary_dir );
   task.parm[ i ].type = FIISIE_tt_string;
   task.parm[ i ].size = sizeof( LDEFIV_temp_dir );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) LDEFIV_temp_dir;

   i++;
   strcpy( task.parm[ i ].name, STBXPD_delete_input_image );
   task.parm[ i ].type = FIISIE_tt_char;
   task.parm[ i ].size = sizeof( char );
   task.parm[ i ].mandatory = FALSE;
   task.parm[ i ].vector = FALSE;
   task.parm[ i ].value = (void *) &LDEFIV_delete_input;

/* ==========================================================================
   Read the parameter file into the task structure
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      FIISIP_GETS_get_info( argv[2],
                            task.name,
                            section_no,
                           &(task.parm[ i ]),
                            status_code );
      ERRSIM_on_err_goto_exit( *status_code );
   }

/* ==========================================================================
   Read line command parameters, if any
   ========================================================================== */
   for( i=3; i<argc; i+=2 ) {

      if( argv[ i ][ 0 ] == STBXPD_prefix_line_arg ) {

         sprintf( tmpParmName, "%s", &(argv[ i ][ 1 ]) );

	 for( j=0; j<task.parmNo; j++ ) {

	    if( !strcmp( tmpParmName, task.parm[ j ].name ) ) {

	       STBXPP_set_par(  (void *) argv[ i + 1 ],
			       &(task.parm[ j ]),
			        status_code );
	       ERRSIM_on_err_goto_exit( *status_code );

	       break;
	    }
	 }
      }
   }

/* ==========================================================================
   Manage here variables not found in the parameter file and in the command 
   line
   ========================================================================== */
   for( i=0; i<task.parmNo; i++ ) {
      if( ( !task.parm[ i ].founded ) && ( task.parm[ i ].mandatory ) ) {
#ifdef __TRACE__
	 printf("Param %s not defined\n", task.parm[ i ].name);
#endif
         ERRSIM_set_error( status_code,
                           ERRSID_STBX_parm_not_defined,
                           task.parm[ i ].name );
      }
   }

/* ==========================================================================
   Check input, output and temporary directories specification
   ========================================================================== */
   STBXPP_check_dirs( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of input image
   ========================================================================== */
   sprintf( inImage, "%s%s", LDEFIV_inp_dir, inImageName );

/* ==========================================================================
   IO initialization
   ========================================================================== */
   GIOSIP_init( status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Check if the input image can be open
   ========================================================================== */
   FILSIP_open( inImage, "r", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

/* ==========================================================================
   Open the TIFF input file
   ========================================================================== */
   inp_io.type = GIOSIE_tif;
   inp_io.mode = 'r';
   strcpy( inp_io.val.tif.name, inImage);
   inp_io.img = 0;
   GIOSIP_open_io( &inp_io,
                    status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Get the image annotations
   ========================================================================== */
   IANNIP_GETP_ImageAnnot( inp_io.chan, inp_io.img, inp_ima_num, 
			   IANNID_EXTR_FRES, inp_io.val.tif.bpar, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Build full name of output image and check if it can be open
   ========================================================================== */
   STBXPP_bld_file_name( outImageName,
                         task_name,
                         inp_io.dt,
                         outImage,
                         status_code );
   ERRSIM_on_err_goto_exit( *status_code );

   FILSIP_open( outImage, "w", 0, &fp, status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   FILSIP_close( &fp, &log_status_code );

   FILSIP_delete( outImage, &log_status_code );

/* ==========================================================================
   Read Coordinate definition from INI file, if any
   ========================================================================== */
   STBXPP_get_coordinates ( argv[ 2 ],
			    task.name,
                            section_no,
			    inp_ima_num,
			   &TLRow, &TLCol, &BRRow, &BRCol,
			   &vertex_no, &vertex,
                           &real_aoi,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Compute nrow_inp/ncol_inp of source image
   ========================================================================== */
   nrow_inp = BRRow - TLRow + 1;
   ncol_inp = BRCol - TLCol + 1;

#ifdef __TRACE__
   fprintf( stdout, "TLRow = %0d\n", TLRow );
   fprintf( stdout, "TLCol = %0d\n", TLCol );
   fprintf( stdout, "BRRow = %0d\n", BRRow );
   fprintf( stdout, "BRCol = %0d\n", BRCol );
   fprintf( stdout, "nrow_inp = %0d\n", nrow_inp);
   fprintf( stdout, "ncol_inp = %0d\n", ncol_inp);
   for(i=0; i<vertex_no; i++) {
      fprintf( stdout, "vertex[ %0d ].row = %f\n", i, vertex[ i ].row );
      fprintf( stdout, "vertex[ %0d ].col = %f\n", i, vertex[ i ].col );
   }
#endif

/* ==========================================================================
   Compute nrow_out/ncol_out of out image
   ========================================================================== */
   win_sizes[ 0 ] = 1;
   win_increments[ 0 ] = 1.0;
   nrow_out = ( (UINTx4) (((double) (nrow_inp - win_sizes[ 0 ])) /
                          (win_increments[ 0 ]))) + 1;
   win_sizes[ 1 ] = 1;
   win_increments[ 1 ] = 1.0;
   ncol_out = ( (UINTx4) (((double) (ncol_inp - win_sizes[ 1 ])) /
                          (win_increments[ 1 ]))) + 1;

#ifdef __TRACE__
   fprintf( stdout, "nrow_out = %0d\n", nrow_out);
   fprintf( stdout, "ncol_out = %0d\n", ncol_out);
#endif

/* ==========================================================================
   Initialize the basic parameters structure for output image file
   ========================================================================== */
   TIFSIM_bpar_init( out_io.val.tif.bpar );
   out_io.val.tif.bpar.imagelength = nrow_out;
   out_io.val.tif.bpar.imagewidth = ncol_out;
   out_io.val.tif.bpar.sampleperpixel = inp_io.val.tif.bpar.sampleperpixel;
   for(i=0; i<out_io.val.tif.bpar.sampleperpixel; i++) {
      out_io.val.tif.bpar.bitspersample[i] =
                                      inp_io.val.tif.bpar.bitspersample[i];
      out_io.val.tif.bpar.sampleformat[i] = 
                                       inp_io.val.tif.bpar.sampleformat[i];
   }
   out_io.val.tif.bpar.disposition = 'x';
   npar = TIFSID_nbpar + IANNID_ImageAnnotMaxNumber;

/* ==========================================================================
   Open output
   ========================================================================== */
   out_io.type = GIOSIE_tif;
   out_io.mode = 'w';
   strcpy( out_io.val.tif.name, outImage);
   out_io.val.tif.nimg = 1;
   out_io.val.tif.npar = npar;
   out_io.img = 0;
   GIOSIP_open_io( &out_io,
                    status_code );
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = TRUE;

/* ==========================================================================
   Call appropriate algorithm
   ========================================================================== */
   STATIP_LOCA_stat(&inp_io,
		     inp_ima_num,
		     TLRow,
		     TLCol,
		     nrow_inp,
		     ncol_inp,
                     (UINTx4) 0, /* Polygonal AOI is ignored */
                     (MATHIT_RC *) NULL,
		     win_sizes,
		     win_increments,
		     fill_val,
		    &out_io,
                     nrow_out,
                     ncol_out,
                     STATIE_image_copy,
		     status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Fill the structure of the image annotations of the output file
   ========================================================================== */
   IANNIP_GETP_CopyAnnot( inp_ima_num, out_ima_num, status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update the new parameters in the output file
   Basic parameters
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].ImageLength = 
                                     out_io.val.tif.bpar.imagelength;
   IANNIV_ImageAnnot[ out_ima_num ].ImageWidth = 
                                     out_io.val.tif.bpar.imagewidth;
   switch ( out_io.val.tif.bpar.sampleperpixel ) {
      case 1:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] =
			             out_io.val.tif.bpar.sampleformat[0];
      break;
      case 2:
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[0] =
                                     out_io.val.tif.bpar.bitspersample[0];
	 IANNIV_ImageAnnot[ out_ima_num ].BitsPerSample[1] = 
				     out_io.val.tif.bpar.bitspersample[1];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[0] = 
				     out_io.val.tif.bpar.sampleformat[0];
	 IANNIV_ImageAnnot[ out_ima_num ].SampleFormat[1] = 
				     out_io.val.tif.bpar.sampleformat[1];
      break;
   }

/* ==========================================================================
   Subimage coordinates
   ========================================================================== */
   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftRow =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftRow +
      /* current offset + transient offset */
      ROUND((TLRow + (float)(win_sizes[ 0 ] - 1)/2.0) / 
            IANNIV_ImageAnnot[ inp_ima_num ].YScalingFactor);

   IANNIV_ImageAnnot[ out_ima_num ].SubImageTopLeftCol =
      /* old subimage offset */
      IANNIV_ImageAnnot[ inp_ima_num ].SubImageTopLeftCol +
      /* current offset + transient offset */
      ROUND((TLCol + (float)(win_sizes[ 1 ] - 1)/2.0) / 
            IANNIV_ImageAnnot[ inp_ima_num ].XScalingFactor);

/* ==========================================================================
   Update coordinates of output image
   ========================================================================== */
   STBXPP_update_coordinates( out_ima_num,
                              status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Update processing history
   ========================================================================== */
   IANNIP_PUTP_UpdateProcHistory( out_ima_num,
                                  task.name,
				  "",
                                  status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Store the image annotations on output file
   ========================================================================== */
   IANNIP_PUTP_ImageAnnot(  out_io.chan,
			    out_io.img,
			    out_ima_num,
			    status_code );
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Close the output file 
   ========================================================================== */
   GIOSIP_close_io( &out_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );
   out_open = FALSE;

/* ==========================================================================
   Close the input file ...
   ========================================================================== */
   GIOSIP_close_io( &inp_io, status_code);
   ERRSIM_on_err_goto_exit( *status_code );

/* ==========================================================================
   Delete input file, if requested
   ========================================================================== */
   if( (LDEFIV_delete_input == 'Y') || (LDEFIV_delete_input == 'y') ) {
      FILSIP_delete( inImage, &log_status_code );
   }

/* ==========================================================================
   Log end
   ========================================================================== */
   STBXPM_end_task( task_name );

error_exit:;

/* ==========================================================================
   Freeze variable
   ========================================================================== */
   MEMSIP_free( (void **) &task.parm );
   MEMSIP_free( (void **) &vertex );

/* ==========================================================================
   Delete output file, if an error occured
   ========================================================================== */
   if( *status_code != STC( ERRSID_normal ) ) {
      if( out_open ) {
         GIOSIP_close_io( &out_io, &log_status_code);
      }
      FILSIP_delete( outImage, &log_status_code );
   }


   ERRSIM_close_routine(   routine_name,
                          &process_flag,
                          *status_code, 
                          &log_status_code );


}/* STBXPP_EXTR_Portion */
