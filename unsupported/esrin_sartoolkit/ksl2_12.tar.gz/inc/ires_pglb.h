/* ==========================================================================
   $MODULE_HEADER

      $NAME              IRES_PGLB

      $FUNCTION          global module.

      $ROUTINE           IRESPP_UNDR_AllocBlock
                         IRESPP_OVER_LinesInterpolate
                         IRESPP_OVER_SetDataType
                         IRESPP_OVER_ZeroPad
                         IRESPP_OVER_WriteLine

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       09-MAY-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include IRES_INTF_H


#ifdef  IRES_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IRESPD_str_char_num

      $DESCRIPTION  Number of character of the strings used in the package

   $EH
   ========================================================================== */
#define IRESPD_str_char_num   256

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IRESPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum IRESPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IRESPC_

      $DESCRIPTION  The IRESPC_

   $EH
   ========================================================================== */
/*   const IRESPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IRESPT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct IRESPT_*_def { 

   typedef struct IRESPT_*_def IRESPT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IRESPV_temp_dir

      $DESCRIPTION  It contains the directory in which to put the temporary
                    files

   $EH
   ========================================================================== */
#ifdef __VMS__
#ifdef  IRES_GLBL
   GLOBAL char IRESPV_temp_dir[] = "dat$:";
#else
   GLOBAL char IRESPV_temp_dir[];
#endif
#endif

#ifdef __UNIX__
#ifdef  IRES_GLBL
   GLOBAL char IRESPV_temp_dir[] = "./dat/";
#else
   GLOBAL char IRESPV_temp_dir[];
#endif
#endif

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESPP_UNDR_AllocBlock

        $TYPE         PROCEDURE

        $INPUT        RBlockSize    : block size in the row direction
                      CBlockSize    : block size in the column direction

        $MODIFIED     inp_data_type : enumerates the various data types

        $OUTPUT       block_p       : pointer to the buffer that will contain
                                      the allocated block

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_err_mem_alloc
                      ERRSID_IRES_not_under_allow

        $DESCRIPTION  This procedure allocates the image block of the required
                      ( via <inp_data_type> ) data type

        $WARNING      NONE

        $PDL          - Switch among the possible data types allowed
                            - Allocates a column of pointers
                            - Loop over the rows
                                  - Allocates the rows
                            - End loop
                      - Break

   $EH
   ========================================================================== */
   extern void IRESPP_UNDR_AllocBlock
                        (/*IN    */ UINTx4               RBlockSize,
                         /*IN    */ UINTx4               CBlockSize,
                         /*IN OUT*/ DATA_TYPEIT         *inp_data_type,
                         /*   OUT*/ void               **block_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESPP_OVER_LinesInterpolate

        $TYPE         PROCEDURE

        $INPUT        inp_chan  : channel of the input TIFF file
                      inp_img   : number identifying the input image
                      inp_bpar  : descriptor of the input image basic parameters
                      Start     : starting element of the line
                      NElements : number of elements of the line
                      NLines    : number of lines
                      min_indx  : array of the index of the minima spectra value
                      NLinesOut : number of output lines
                      rbuff     : pointer to a buffer alocated if the image is
                                  real to store the real part of the inverse
                                  FFT of the zero padded line to write
                      out_chan  : channel of the output TIFF file
                      out_img   : number identifying the output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the interpolation via zero
                      padding of a certain number of lines

        $WARNING      NONE

        $PDL          - Selects the type of data
                      - Loop over the lines
                            - Reads the line
                            - Makes the direct FFT of the line
                            - Adds the zeroes at the minimum index spectrum
                            - Makes the inverse FFT of the zero padded line
                            - Writes the interpolated line
                      - End loop

   $EH
   ========================================================================== */
   extern void IRESPP_OVER_LinesInterpolate
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx4               Start,
                         /*IN    */ UINTx4               NLines,
                         /*IN    */ UINTx4               NElements,
                         /*IN    */ UINTx4              *min_indx,
                         /*IN    */ UINTx1               dc,
                         /*IN    */ UINTx4               NElementsOut,
                         /*IN    */ float               *rbuff,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESPP_OVER_SetDataType

        $TYPE         PROCEDURE

        $INPUT        inp_bpar : input image basic parameters

        $MODIFIED     NONE

        $OUTPUT       DataType : flag indicating the type of data via the
                                 enumerate LDEFIE_data_type

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_data_type_not_allow

        $DESCRIPTION  This procedure sets the flag indicating the data type
                      throw the LDEFIE_data_type enumerate

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void IRESPP_OVER_SetDataType
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*   OUT*/ LDEFIT_data_type    *DataType,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESPP_OVER_ZeroPad

        $TYPE         PROCEDURE

        $INPUT        inp_array    : array to zero pad
                      NElements    : number of elements of the input array
                      NElementsOut : number of elements of the output array
                                     after the zero padding
                      ind          : index of the minimum spectrum value
                      dc           : value to add at the middle spectrum

        $MODIFIED     NONE

        $OUTPUT       zp_array     : zero padded array

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills a vector enlarged WRT the input one
                      with zeros at a determinated index

        $WARNING      NONE

        $PDL          - Zeroes the output vector
                      - Copies the first part of the input vector into the
                        zero padded one
                      - Copies the last part of the input vector into the
                        zero padded one

   $EH
   ========================================================================== */
   extern void IRESPP_OVER_ZeroPad
                        (/*IN    */ MATHIT_array         inp_array,
                         /*IN    */ UINTx4               NElements,
                         /*IN    */ UINTx4               NElementsOut,
                         /*IN    */ UINTx4               ind,
                         /*IN    */ UINTx1               dc,
                         /*   OUT*/ MATHIT_array        *zp_array,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESPP_OVER_WriteLine

        $TYPE         PROCEDURE

        $INPUT        chan    : channel of the TIFF file to fill
                      img     : image identifier
                      bpar    : basic parameters descriptor
                      ind     : index of the line to write in the output file
                      imgline : array containing the image line
                      rbuff   : pointer to a buffer alocated if the image is
                                real to store the real part of the inverse
                                FFT of the zero padded line to write

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_err_mem_alloc
                      ERRSID_IRES_not_allowed_prod

        $DESCRIPTION  This procedure writes an image line in the output file
                      at the right index

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void IRESPP_OVER_WriteLine
                        (/*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ind,
                         /*IN    */ MATHIT_array         imgline,
                         /*IN    */ float               *rbuff,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IRESPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 IRESPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( IRESPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IRESIM_

      $DESCRIPTION  This procedure

                    IRESIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define IRESPM_
*/
