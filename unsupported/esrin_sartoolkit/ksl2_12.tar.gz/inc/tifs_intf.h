/* ==========================================================================
   $MODULE_HEADER

      $NAME              TIFS_INTF

      $FUNCTION          TIFF library interface module.

      $ROUTINE           TIFSIP_open_tiff
			 TIFSIP_init_filedata
                         TIFSIP_close_tiff
                         TIFSIP_set_tif
                         TIFSIP_get_imgnum
                         TIFSIP_get_parnum
                         TIFSIP_dir_par
                         TIFSIP_set_imgnum
                         TIFSIP_set_parnum
                         TIFSIP_get_blockinfo
                         TIFSIP_set_blockinfo
                         TIFSIP_store_blockinfo
                         TIFSIP_open_line
                         TIFSIP_read_line
                         TIFSIP_write_line
                         TIFSIP_read_block 
                         TIFSIP_close_line
                         TIFSIP_get_par
                         TIFSIP_store_par
                         TIFSIP_fill_tag_vet
			 TIFSIP_IDLI_GetErrorCode
			 TIFSIP_IDLI_OpenTiff
			 TIFSIP_IDLI_InitFiledata
			 TIFSIP_IDLI_CloseTiff
			 TIFSIP_IDLI_GetTag
			 TIFSIP_IDLI_GetParNum
			 TIFSIP_IDLI_DirPar
			 TIFSIP_IDLI_GetImgNum
			 TIFSIP_IDLI_GetBlockInfo
			 TIFSIP_IDLI_ReadSubImage
			 TIFSIP_IDLI_OpenLine
			 TIFSIP_IDLI_ReadLine
			 TIFSIP_IDLI_WriteLine
			 TIFSIP_IDLI_CloseLine
			 TIFSIP_IDLI_SetImgNum
			 TIFSIP_IDLI_SetParNum
			 TIFSIP_IDLI_SetBlockInfo
			 TIFSIP_IDLI_StoreBlockInfo
			 TIFSIP_IDLI_StoreTag
			 TIFSIP_IDLI_WriteSubImage
			 TIFSIP_IDLI_DumpIDLVar

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       02-JAN-97     AG       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */
#ifndef TIFS
#define TIFS TIFS

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#ifdef __HAVEIDL__
#if defined(__WIN95__) && defined(__CODEWARRIOR__)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif
#endif /* __HAVEIDL__ */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#ifdef __HAVEIDL__
#include IDLI_INTF_H
#endif /* __HAVEIDL__ */

#ifdef TIFS_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ---

      $DESCRIPTION  Needed tags

   $EH
   ========================================================================== */

#define TIFS_XY TIFS_XY    /* allow the disposition choice in TIF */

#define         IMAGEWIDTH                      256
#define         IMAGELENGTH                     257
#define         BITSPERSAMPLE                   258
#define         COMPRESSION                     259
#define         PHOTOMETRICINTERPRETATION       262
#define         SAMPLEPERPIXEL                  277
#define         XRESOLUTION                     282
#define         YRESOLUTION                     283
#define         RESOLUTIONUNIT                  296
#define         TILEWIDTH                       322
#define         TILELENGTH                      323
#define         TILEOFFSET                      324
#define         TILEBYTECOUNT                   325
#define         SAMPLEFORMAT                    339
#define 	DISPOSITION                     1005

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ---

      $DESCRIPTION  Tags for BTIFF compatibility

   $EH
   ========================================================================== */
#define         BLOCKOFFSET                     273
#define         ROWSPERBLOCK                    278
#define         BLOCKBYTECOUNT                  279
#define         COLUMNSPERBLOCK                 1000

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ---

      $DESCRIPTION  TIFF library limits

   $EH
   ========================================================================== */
#define MAX_FILES           20      /* numero di files TIFF che possono essere
                                   contemporaneamente aperti */
#define MAX_IMAGES          10 /* numero di immagini che possono essere contenute
                              in un file TIFF */
#define NSAMPLEPERPIXELMAX  5   /* numero massimo di bande trattabili */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ---

      $DESCRIPTION  Allowable types after v1.3.1 and sizes

   $EH
   ========================================================================== */

#define N_TYPES                23 /* numero tipi permessi               */

#define TYPE_UBYTE		1 /* tipo unsigned byte			*/
#define TYPE_ASCII		2 /* tipo ascii char			*/
#define TYPE_USHORT		3 /* tipo unsigned short		*/
#define TYPE_UINT		4 /* tipo unsigned int			*/
#define TYPE_URATIONAL		5 /* tipo frazione di unsigned int	*/

#define TYPE_BYTE		6 /* tipo signed byte			*/
#define TYPE_SHORT		7 /* tipo signed short			*/
#define TYPE_INT		8 /* tipo signed int			*/
#define TYPE_FLOAT		9 /* tipo float				*/
#define TYPE_DOUBLE		10 /* tipo double			*/
#define TYPE_UBYTE_COD_ASCII	11 /* tipo unsigned byte codificato in stringa ASCII  */
#define TYPE_BYTE_COD_ASCII	12 /* tipo signed byte codificato in stringa ASCII    */
#define TYPE_USHORT_COD_ASCII	13 /* tipo unsigned short codificato in stringa ASCII */
#define TYPE_SHORT_COD_ASCII	14 /* tipo signed short codificato in stringa ASCII   */
#define TYPE_UINT_COD_ASCII	15 /* tipo unsigned int codificato in stringa ASCII   */
#define TYPE_INT_COD_ASCII	16 /* tipo signed int codificato in stringa ASCII     */
#define TYPE_FLOAT_COD_ASCII	17 /* tipo float codificato in stringa ASCII          */
#define TYPE_DOUBLE_COD_ASCII	18 /* tipo double codificato in stringa ASCII         */
#define TYPE_UBYTE_32	 	19 /* tipo 32 unsigned bytes			*/
#define TYPE_UBYTE_220	 	20 /* tipo 220 unsigned bytes			*/
#define TYPE_ASCII_STRING	21 /* tipo stringa ASCII di lunghezza fissata 	*/
#define TYPE_RATIONAL		22 /* tipo frazione di signed int	*/

#define SIZE_TYPE_UBYTE		    1
#define SIZE_TYPE_ASCII		    1
#define SIZE_TYPE_USHORT	    2
#define SIZE_TYPE_UINT		    4
#define SIZE_TYPE_URATIONAL	    8
#define SIZE_TYPE_BYTE		    1
#define SIZE_TYPE_SHORT		    2
#define SIZE_TYPE_INT		    4
#define SIZE_TYPE_FLOAT		    4
#define SIZE_TYPE_DOUBLE	    8
#define SIZE_TYPE_UBYTE_COD_ASCII   40
#define SIZE_TYPE_BYTE_COD_ASCII    40
#define SIZE_TYPE_USHORT_COD_ASCII  40
#define SIZE_TYPE_SHORT_COD_ASCII   40
#define SIZE_TYPE_UINT_COD_ASCII    40
#define SIZE_TYPE_INT_COD_ASCII	    40
#define SIZE_TYPE_FLOAT_COD_ASCII   40
#define SIZE_TYPE_DOUBLE_COD_ASCII  80
#define SIZE_TYPE_UBYTE_32	    32
#define SIZE_TYPE_UBYTE_220	    220
#define SIZE_TYPE_ASCII_STRING	    80
#define SIZE_TYPE_RATIONAL	    8

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         REPLINELEN

      $DESCRIPTION  The size of the buffer for the dump file reading (one line)

   $EH
   ========================================================================== */
#define REPLINELEN  255

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ---

      $DESCRIPTION  Possible values of the sample format tag

   $EH
   ========================================================================== */
#define TIFSID_undef        0
#define TIFSID_uintdata     1
#define TIFSID_sintdata     2
#define TIFSID_IEEEdata     3
#define TIFSID_float        4

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSID_nbpar

      $DESCRIPTION  Number of basic parameters (13 plus 2 hidden) to store
                    in a TIFF file

   $EH
   ========================================================================== */
#define TIFSID_nbpar         15

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSID_minus_nbpar_std_tif

      $DESCRIPTION  Number of basic parameters not present in a standard
                    TIFF file

   $EH
   ========================================================================== */
#define TIFSID_minus_nbpar_std_tif    3

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IDLNMESSAGES

      $DESCRIPTION  Number of error messages for IDL interface
		    Used for IDL interface

   $EH
   ========================================================================== */
#define IDLNMESSAGES 40

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IDLMESSAGESLENGTH

      $DESCRIPTION  Size (in characters) of the error messages for IDL interface
		    Used for IDL interface

   $EH
   ========================================================================== */
#define IDLMESSAGESLENGTH 80


/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum TIFSIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSIC_

      $DESCRIPTION  The TIFSIC_

   $EH
   ========================================================================== */
/*   const TIFSIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSIT_par

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
	  tag				   tag number
	  type			           tag type
	  length		           tag length
	  val				   tag value
   $EH
   ========================================================================== */
   struct TIFSIT_par_def { 
      UINTx2      tag;
      UINTx2      type;
      UINTx4      length;
      void       *val;
   };

   typedef struct TIFSIT_par_def TIFSIT_par;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSIT_basicpar

      $DESCRIPTION  TIFF basic parameters

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          compression                        compression of the data (1 = no
                                             compression)
          imagewidth                         number of image's columns
          imagelength                        number of image's rows
          rowsperblock                       number of rows in a TIFF block 
          columnsperblock                    number of columns in a TIFF block
          bitspersample[NSAMPLEPERPIXELMAX]  bit per sample
          sampleformat[NSAMPLEPERPIXELMAX]   sample format (data type)
          sampleperpixel                     sample per pixel
          photometricinterpretation          1 for grey scale
          xresolution[2]                     resolution in x for the print
                                             ([0]=a, [1]=b is a / b)
          yresolution[2]                     resolution in y for the print
          resolutionunit                     dots per inch
          disposition                        faster direction in reading

   $EH
   ========================================================================== */
   struct TIFSIT_basicpar_def {
      UINTx2   compression;
      UINTx4   imagewidth;
      UINTx4   imagelength;
      UINTx4   rowsperblock;
      UINTx4   columnsperblock;
      UINTx2   bitspersample[NSAMPLEPERPIXELMAX];
      UINTx2   sampleformat[NSAMPLEPERPIXELMAX];
      UINTx2   sampleperpixel;
      UINTx2   photometricinterpretation;
      UINTx4   xresolution[2];
      UINTx4   yresolution[2];
      UINTx2   resolutionunit;
#ifdef TIFS_XY
      char     disposition;
#endif
   };
   typedef struct TIFSIT_basicpar_def TIFSIT_basicpar;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSPT_tag_elem_def

      $DESCRIPTION  Tag dump type definition

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
	  name				   tag name
	  num			           tag number (id)

   $EH
   ========================================================================== */
   struct TIFSIT_tag_elem_def { 
      char        name[REPLINELEN];
      UINTx4      num;
   };

   typedef struct TIFSIT_tag_elem_def TIFSIT_tag_elem;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSIT_io

      $DESCRIPTION  TIFF structure for GIOS

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
  struct TIFSIT_io_def {
      char               name[ 256 ];
      LDEFIT_boolean     standard;
      INTx4              nimg;
      UINTx2             npar;
      TIFSIT_basicpar    bpar;
   };
   typedef struct TIFSIT_io_def TIFSIT_io;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         TIFSIV_Size

      $DESCRIPTION  It defines the sizes of the type of variables used in
                    TIFF

   $EH
   ========================================================================== */
#ifdef TIFS_GLBL
GLOBAL UINTx2 TIFSIV_Size[N_TYPES] = { 0, /* primo elemento non usato */
                                      SIZE_TYPE_UBYTE,
                                      SIZE_TYPE_ASCII,
                                      SIZE_TYPE_USHORT,
                                      SIZE_TYPE_UINT,
                                      SIZE_TYPE_URATIONAL,
                                      SIZE_TYPE_BYTE,
                                      SIZE_TYPE_SHORT,
                                      SIZE_TYPE_INT,
                                      SIZE_TYPE_FLOAT,
                                      SIZE_TYPE_DOUBLE,
                                      SIZE_TYPE_UBYTE_COD_ASCII,
                                      SIZE_TYPE_BYTE_COD_ASCII,
                                      SIZE_TYPE_USHORT_COD_ASCII,
                                      SIZE_TYPE_SHORT_COD_ASCII,
                                      SIZE_TYPE_UINT_COD_ASCII,
                                      SIZE_TYPE_INT_COD_ASCII,
                                      SIZE_TYPE_FLOAT_COD_ASCII,
                                      SIZE_TYPE_DOUBLE_COD_ASCII,
                                      SIZE_TYPE_UBYTE_32,
                                      SIZE_TYPE_UBYTE_220,
                                      SIZE_TYPE_ASCII_STRING,
                                      SIZE_TYPE_RATIONAL
                                    };
#else
GLOBAL UINTx2 TIFSIV_Size[N_TYPES];
#endif

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_open_tiff

        $TYPE	      PROCEDURE

        $INPUT        namefile: TIFF file name
                      mode: open mode r/w/u

        $MODIFIED     NONE

        $OUTPUT       chout: out channel

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Open TIFF file in a given mode and returns a channel
                      to it

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_open_tiff  
                       ( /*IN    */ char                *namefile,
                         /*IN    */ char                 mode,
                         /*   OUT*/ INTx4               *chout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_init_filedata

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Set the TIFSPV_gid global structure

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_init_filedata
                       ( /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_close_tiff

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF file channel to be closed

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Chiude un file TIFF liberando la memoria e resettando 
		      l'area filedata associati in scrittura riordina la IFD 
                      e la salva su file

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_close_tiff 
                       ( /*IN    */ INTx4                  chan,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_set_tif

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img:  image 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Modifica img in chan in STRIP TIFF

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_set_tif
                       ( /*IN    */ INTx4	         chan,
                         /*IN    */ INTx4                img,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_get_imgnum

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel

        $MODIFIED     NONE

        $OUTPUT       nimg: number of images in TIFF file

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Trova il numero di immagini presenti in un file TIFF

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_get_imgnum 
                       ( /*IN    */ INTx4	         chan,
                         /*   OUT*/ INTx4               *nimg,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_get_parnum

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number

        $MODIFIED     NONE

        $OUTPUT       npar: number of parameters

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Trova il numero di parametri di una immagine 
                      in un file TIFF 

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_get_parnum 
                       ( /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*   OUT*/ UINTx2              *npar,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_dir_par

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number

        $MODIFIED     NONE

        $OUTPUT       tag: parameters

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Elenca i parametri di una immagine in un file TIFF 

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_dir_par 
                    ( /*IN    */ INTx4                chan,
                      /*IN    */ INTx4                img,
                      /*   OUT*/ UINTx2              *tag,
                      /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_get_par

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number

        $MODIFIED     NONE

        $OUTPUT       p: parameter structure

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Estrae un parametro di una immagine in un file TIFF 
                      in un buffer void

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_get_par    
                       ( /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*   OUT*/ TIFSIT_par          *p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_set_imgnum

        $TYPE	      PROCEDURE

        $INPUT        namefile: TIFF file name
                      nimg: number of images

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Setta il numero di immagini in un file TIFF 

        $WARNING      NONE

   $EH
   ========================================================================== */
  extern void TIFSIP_set_imgnum 
                       ( /*IN    */ char                *namefile,
                         /*IN    */ INTx4                nimg,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_set_parnum

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number
                      npar: number of parameters

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Setta il numero di parametri di una immagine in un file 
                      TIFF

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_set_parnum 
                       ( /*IN    */ char                *namefile,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx2               npar,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_store_par

        $TYPE	      FUNCTION

        $INPUT        chan: TIFF channel
                      img: image number
                      p: pointer to parameter structure

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Scrive il parametro specificato nella struttura par 
                      del file

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_store_par  
                       ( /*IN    */ INTx4                chan,
                         /*IN OUT*/ INTx4                img,
                         /*   OUT*/ TIFSIT_par          *p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_get_blockinfo

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number
                      bpar: pointer to basic parameter structure

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Legge le informazioni di descrizione dei blocchi

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_get_blockinfo 
                          ( /*IN    */ INTx4                chan,
                            /*IN OUT*/ INTx4                img,
                            /*   OUT*/ TIFSIT_basicpar     *bpar,
                            /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_set_blockinfo

        $TYPE	      PROCEDURE

        $INPUT        namefile: TIFF file name
                      img: image number
                      bpar: pointer to basic parameter structure

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Setta le informazioni fondamentali di una immagine 
                      in un file TIFF 

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_set_blockinfo 
                          ( /*IN    */ char                *namefile,
                            /*IN    */ INTx4                img,
                            /*   OUT*/ TIFSIT_basicpar     *bpar,
                            /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_store_blockinfo

        $TYPE	      PROCEDURE

        $INPUT        chan: TIFF channel
                      img: image number

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Scrive i parametri fondamentali dell' immagine

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_store_blockinfo 
                            ( /*IN    */ INTx4                chan,
                              /*IN    */ INTx4                img,
                              /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_open_line

        $TYPE	      PROCEDURE

        $INPUT        chan        : TIFF channel
		      img         : image number
		      direction   : 'x' or 'y'
		      samplestart : first sample in line
		      sampleend   : last sample in line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       TIFSPV_gid[ chan ] 

        $RET_STATUS   ERRSID_TIFS_max_chan
                      ERRSID_TIFS_max_img
                      ERRSID_TIFS_err_no_mem_bufl
                      ERRSID_TIFS_memory_alloc_failure
                      ERRSID_TIFS_not_allow_data_type
                      ERRSID_TIFS_mode_not_set

        $DESCRIPTION  This procedure opens the reading or the writing of a line.
                      The procedure works also on IDL images, that are indicated
                      by negative channels

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void TIFSIP_open_line
                       (/*IN    */ INTx4                chan,
                        /*IN    */ INTx4                img,
                        /*IN    */ char                 direction,
                        /*IN    */ UINTx4               samplestart,
                        /*IN    */ UINTx4               sampleend,
                        /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_read_line

        $TYPE	      PROCEDURE

        $INPUT        chan       : TIFF channel
		      img        : image number
                      linenumber : line to be read

        $MODIFIED     NONE

        $OUTPUT       bufout     : address of pointer to void buffer

        $GLOBAL       TIFSPV_gid[ chan ]

        $RET_STATUS   ERRSID_TIFS_max_chan
                      ERRSID_TIFS_undef_data_type

        $DESCRIPTION  This procedure reads a line from a TIFF file. If the
                      channel has a negative value, it reads from buffers
                      pointing to IDL images.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_read_line
                      ( /*IN    */ INTx4                chan,
                        /*IN    */ INTx4                img,
                        /*IN    */ UINTx4               linenumber,
                        /*   OUT*/ void               **bufout,
                        /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_write_line

        $TYPE	      PROCEDURE

        $INPUT        chan       : TIFF channel
		      img        : image number
                      linenumber : line to be read
                      bufin      : pointer to void buffer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       TIFSPV_gid[ chan ]

        $RET_STATUS   ERRSID_TIFS_max_chan
                      ERRSID_TIFS_undef_data_type

        $DESCRIPTION  This procedure writes a line from a TIFF file. If the
                      channel has a negative value, it writes from buffers
                      pointing to IDL images.

        $WARNING      NONE

        $PDL
	   -If la linea e' fuori dal buffer
	     -Salva il buffer dividendolo a blocks
	     -Aggiorna i flags relativi ai blocks salvati
	     -If tutti i blocks relativi allla linea da scrivere sono gia' 
              stati salvati 
	       -Carica i nuovi blocks relativi alla linea da scrivere
	     -Endif
	     -Aggiorna minline
	     -Ricopia la linea nel buffer
	   -Else la linea e' nel buffer
	     -Ricopia la linea nel buffer
	   -Endif                                     

   $EH
   ========================================================================== */
   extern void TIFSIP_write_line
                       ( /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx4               linenumber,
                         /*   OUT*/ void                *bufin,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_read_block

        $TYPE	      PROCEDURE

        $INPUT        chan	 : channel of the input opened TIFF file
                      img	 : number of the image in the TIFF file
                      firstline	 : first line (in the rows or columns direction)
                                   to read
                      lastline	 : last line to read
                      outtype	 : type of the output buffer

        $MODIFIED     NONE

        $OUTPUT       buff	 : double pointer to the output block

        $GLOBAL       TIFSPV_gid[chan] : the global structure used in the TIFF
                                         package

        $RET_STATUS   ERRSID_TIFS_bad_dimensions
                      ERRSID_TIFS_err_no_block
                      ERRSID_TIFS_not_allow_data_type

        $DESCRIPTION  This procedure read a block of lines ( in rows or columns
                      direction ) from a previously initialised TIFF file

        $WARNING      The read line operation must be initialised before calling
                      this procedure opening the TIFF file and the read mode
                      of the line

   $EH
   ========================================================================== */
   extern void TIFSIP_read_block
                       ( /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*IN    */ UINTx4               firstline,
                         /*IN    */ UINTx4               lastline,
                         /*IN    */ DATA_TYPEIT          outtype,
                         /*IN OUT*/ void               **buff,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_close_line

        $TYPE	      PROCEDURE

        $INPUT        chan : TIFF channel
		      img  : image number

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       TIFSPV_gid[ chan ]

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure close the reading or writing of a line.
                      Called with a negative channel it acts on IDL image
                      buffers.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void TIFSIP_close_line
                       ( /*IN    */ INTx4                chan,
                         /*IN    */ INTx4                img,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_fill_tag_vet

        $TYPE         FUNCTION

        $INPUT        file_name: the name of the file containing the tag names (.h)

        $MODIFIED     NONE

        $OUTPUT       tag_vet: an array of structures containing the tag names and numbers
                      tot_tag: the total number of founded tags

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Fills the structure containing the tag names and numbers
		      starting from the .h file containing the various #define 

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_fill_tag_vet
                        (/*IN    */ char                *filename,
                         /*   OUT*/ UINTx4              *tot_tag,
                         /*   OUT*/ TIFSIT_tag_elem    **tag_vet,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         TIFSIP_get_tag_name   

        $TYPE         FUNCTION

        $INPUT        tag_vet  : the array of structures containing the tag 
                                 numbers and names
		      tot_tag  : the size of the tag structure (quantity of 
                                 tags)
		      tag_num  : the searched tag number

        $MODIFIED     NONE

        $OUTPUT       tag_name : a string containing the name of the tag, 
                                 searched by its number

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Obtain the tag name from the tag number searching in the
                      tag array of structure

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void TIFSIP_get_tag_name
                        (/*IN    */ TIFSIT_tag_elem     *tag_vet,
                         /*IN    */ UINTx2              tot_tag,
                         /*IN    */ UINTx2              tag_num,
                         /*   OUT*/ char                *tag_name,
                         /*   OUT*/ ERRSIT_status       *status_code );

#ifdef __HAVEIDL__

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_geterrorcode

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and BTIFF_GetErrorCode
		    Gives the error string corresponding to an error code
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is the error code
		    1 *           STRING          error message

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_geterrorcode
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_opentiff

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and open_tiff.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             STRING          name of the file to be opened
		    2             STRING          a character indicating the open in read mode
                                                  'r' or write 'w' or update 'u'
		    3 *           LONG INT        the channel of the opened file

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_opentiff
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_initfiledata

      $TYPE         PROCEDURE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and init_filedata.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    - none -

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_initfiledata
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_closetiff

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and close_tiff.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file to be close
 
      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_closetiff
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_gettag

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and GetTag.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             LONG INT        the tag number
		    4 *           unspecified     the value in a allowed IDL type
 
      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_gettag
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_getparnum

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and GetParNum.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3 *           LONG INT        the number of parameters

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_getparnum
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_dirpar

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and dir_par.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3 *           LONG INT array  the array of tags present in the file
				  of the same size
				  of the number
				  of par as given
				  from par_num
 
      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_dirpar
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_getimgnum

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and GetImgNum.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2 *           LONG INT        the image number

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_getimgnum
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_getblockinfo

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and GetBlockInfo.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3 *           LONG INT        the compression
		    4 *           LONG INT        the imagewidth
		    5 *           LONG INT        the imagelenght
		    6 *           LONG INT        the rowsperblock
		    7 *           LONG INT        the columnsperblock
		    8 *           LONG INT        the bitspersample (SCALAR)
		    9 *           LONG INT        the sampleperpixel
		    10 *          LONG INT        the photometricinterpretation
		    11 *          STRING          the disposition

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_getblockinfo
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_readsubimage

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and the following BTIFF routines
		    open_line, readline, close_line
		    This routine does not exist into the original BTIFF package and is build
		    just for IDL. With this routine a image portion can be read
		    into a array ** allocated from IDL **
		    A copy line by line is made from the image buffer into the IDL array using
		    the pointer restituited from BTIFF readline routine
		    The IDL array type IS NOT checked. 
		    The IDL array size IS checked.
		    A byte per byte copy of the BTIFF image buffer is then done.
		    The reading direction is always fixed to be X
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             LONG INT        Start X coord
		    4             LONG INT        Start Y coord
		    5             LONG INT        End   X coord
		    6             LONG INT        End   Y coord
		    7 *           unspecified arr the IDL array that will contain the image porti
 
      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_readsubimage
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_openline

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and OpenLine.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             STRING          the direction of the reading (x or y)
		    5             LONG INT        Start sample coord
		    6             LONG INT        End sample coord
 
      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_openline
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_readline

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and read_line.
		    The IDL array type IS NOT checked.
		    The IDL array size IS checked.
 		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             LONG INT        the line number of the line to be read
		    4 *           unspecified arr the IDL array that will contain the image porti

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_readline
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_writeline

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and writeline.
		    The IDL array type IS NOT checked.
		    The IDL array size IS checked.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             LONG INT        the line number of the line to be writed
		    4             unspecified arr the IDL array that contain the image portion

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_writeline
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_closeline

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and  close_line.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_closeline
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_setimgnum

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and set_imgnum.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the name of the BTIFF file
		    2             LONG INT        the image number to be set

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_setimgnum
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_setparnum

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and set_parnum.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the name of the BTIFF file
		    2             LONG INT        the image number
		    3             LONG INT        the number of parameters to be set

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_setparnum
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_setblockinfo

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and set_blockinfo.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
		    0 *           LONG INT        return status 0 is OK, nonzero is error
  		    1             LONG INT        the name of the file
  		    2             LONG INT        the image number
  		    3             LONG INT        the compression
  		    4             LONG INT        the imagewidth
  		    5             LONG INT        the imagelenght
  		    6             LONG INT        the rowsperblock
  		    7             LONG INT        the columnsperblock
  		    8             LONG INT        the bitspersample (SCALAR)
  		    9             LONG INT        the sampleperpixel
  		    10            LONG INT        the photometricinterpretation
  		    11            STRING          the disposition

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_setblockinfo
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_storeblockinfo

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and store_blockinfo.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
  		    0 *           LONG INT        return status 0 is OK, nonzero is error
  		    1             LONG INT        the channel of the file
  		    2             LONG INT        the image number

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_storeblockinfo
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_storetag

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and store_par.
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    Parameters    IDL_Type        Meaning
  		    0 *           LONG INT        return status 0 is OK, nonzero is error
  		    1             LONG INT        the channel of the file
  		    2             LONG INT        the image number
  		    3             LONG INT        the tag number
  		    4             unspecified     the value in a allowed IDL type

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_storetag
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_writesubImage

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure interfaces via linkimage IDL and the following BTIFF routines
		    open_line, writeline, close_line
		    This routine does not exist into the original BTIFF package and is build
		    just for IDL. With this routine a image portion can be written into a BTIFF
		    file
		    A copy line by line is made from the IDL array image buffer into the file
		    The IDL array type IS NOT checked. 
		    The IDL array size IS checked.
		    A byte per byte copy into the BTIFF image buffer is then done.
		    The writing direction is always fixed to be X
		    The parameters followed by an '*' are changed at the return in IDL even if
		    they are passed by value (direct access to IDL structures)
                    For IDL interface
		    0 *           LONG INT        return status 0 is OK, nonzero is error
		    1             LONG INT        the channel of the file
		    2             LONG INT        the image number
		    3             LONG INT        Start X coord
		    4             LONG INT        Start Y coord
		    5             LONG INT        End   X coord
		    6             LONG INT        End   Y coord
		    7             unspecified arr the IDL array that contain the image portion

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_writesubimage
                        (/*IN    */ INTx4                npar,
                         /*INOUT */ IDL_VPTR             par[]);

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         tifsip_idli_dumpidlvar

      $TYPE         PROCEDURE

      $INPUT        npar: number of parameters passed to the routine
                    par : array of pointers to the passed parameters

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   1=error 0=OK

      $DESCRIPTION  Dump a IDL variable -just for test-

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern EXPORT void tifsip_idli_dumpidlvar
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR             par[]);

#endif /* __HAVEIDL__ */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         TIFSIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void TIFSIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) TIFSIT_var_type   variable,
                         (*IN    *) INTx4               ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         TIFSIM_bpar_init
                    ( (*IN OUT*) TIFSIT_basicpar bpar )

      $DESCRIPTION  This macro initializes the basic parmeter structure

      $WARNING      NONE

   $EH
   ========================================================================== */
#define TIFSIM_bpar_init( bpar )                                            \
{                                                                           \
   UINTx1        i;                                                         \
                                                                            \
   bpar.compression = 1;     /* no compression */                           \
   bpar.imagewidth = 0;                                                     \
   bpar.imagelength = 0;                                                    \
   bpar.rowsperblock = 128;    /* BTIFF block */                            \
   bpar.columnsperblock = 128;                                              \
   for (i=0;i<NSAMPLEPERPIXELMAX;i++)                                       \
      bpar.bitspersample[i] = 0;                                            \
   for (i=0;i<NSAMPLEPERPIXELMAX;i++)                                       \
      bpar.sampleformat[i] = TIFSID_undef;                                  \
   bpar.sampleperpixel = 0;                                                 \
   bpar.photometricinterpretation = 1;   /* grey scale */                   \
   bpar.xresolution[0] = 300;        /* resolution 300 in x */              \
   bpar.xresolution[1] = 1;                                                 \
   bpar.yresolution[0] = 300;        /* resolution 300 in y */              \
   bpar.yresolution[1] = 1;                                                 \
   bpar.resolutionunit = 2;      /* 2 Dots per Inch */                      \
   bpar.disposition = 'x';       /* faster reading in x direction */        \
}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         TIFSIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 


      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define TIFSIM_
*/

/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#ifdef __VMS__

#define ERRSID_TIFS_err_opn_tif		 2
#define ERRSID_TIFS_err_not_tif		 3
#define ERRSID_TIFS_err_not_ifd_mem_r    4
#define ERRSID_TIFS_err_max_tif_opn	 5
#define ERRSID_TIFS_err_isn_opn_tif	 6
#define ERRSID_TIFS_err_no_param	 7
#define ERRSID_TIFS_err_not_tag_mem	 8
#define ERRSID_TIFS_err_not_ifd_mem_w	 9
#define ERRSID_TIFS_err_no_par_num	 10
#define ERRSID_TIFS_err_no_img_num	 11
#define ERRSID_TIFS_err_no_more_par_w	 12
#define ERRSID_TIFS_err_not_opn_tif	 13
#define ERRSID_TIFS_err_no_block	 14
#define ERRSID_TIFS_err_no_bas_par	 15
#define ERRSID_TIFS_err_no_mem_blk	 16
#define ERRSID_TIFS_err_wr_bas_par	 17
#define ERRSID_TIFS_err_no_mem_lzw	 18
#define ERRSID_TIFS_err_no_mem_bufl	 19
#define ERRSID_TIFS_err_no_mem_bufb	 20
#define ERRSID_TIFS_err_no_disp		 21
#define ERRSID_TIFS_err_no_mem_flg	 22
#define ERRSID_TIFS_err_no_ovr_par	 23
#define ERRSID_TIFS_err_on_fseek     	 24
#define ERRSID_TIFS_bad_dimensions       25
#define ERRSID_TIFS_undef_data_type      26
#define ERRSID_TIFS_not_allow_data_type  27
#define ERRSID_TIFS_memory_alloc_failure 28
#define ERRSID_TIFS_test_error           29
#define ERRSID_TIFS_max_chan             30
#define ERRSID_TIFS_max_img              31
#define ERRSID_TIFS_mode_not_set         32
#define ERRSID_TIFS_neg_dimensions       33
#define ERRSID_TIFS_err_on_fwrite    	 34

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */
#ifdef TIFS_GLBL
   GLOBAL char *TIFSIV_ERRS_error_message[] = 
 { "No error happens", /* 0 */
   "Generic error happens", /* 1 */
   "Error opening the file ", /* 2 */
   "Not a TIFF file ", /* 3 */
   "Cannot allocate memory in IFD tables reading the file ", /* 4 */
   "Reached the max number of opened files after the file ", /* 5 */
   "Is not a opened file ", /* 6 */
   "Not exist such parameter in file ", /* 7 */
   "Cannot allocate memory buffer for tag ", /* 8 */
   "Cannot allocate memory in IFD tables writing the file ", /* 9 */
   "The parameter number is not set in file ", /* 10 */
   "The image does not exist in file ", /* 11 */
   "Cannot write more parameters than the allocated number in file ", /* 12 */
   "A channel is access before opening the related file ", /* 13 */
   "The image block accessed does not exist in file ", /* 14 */
   "A basic parameter is not present in file ", /* 15 */
   "Cannot allocate memory in blockoffs or blocksize tables in file ", /* 16 */
   "Error writing the basic parameters in file ", /* 17 */
   "Cannot allocate memory for LZW compression buffer in file ", /* 18 */
   "Cannot allocate memory for the line buffer in file ", /* 19 */
   "Cannot allocate memory for the block buffer in file ", /* 20 */
   "The basic parameter DISPOSITION is not specified in file ", /* 21 */
   "Cannot allocate memory for the flag table in file ", /* 22 */
   "Cannot overwrite a parameter with a different type in file ", /* 23 */
   "Error while doing fseek on file ", /* 24 */
   "Inconsistent buffer dimensions reading image block", /* 25 */
   "Undefined data type required in output buffer", /* 26 */
   "Data type not allowed", /* 27 */
   "Memory allocation failed", /* 28 */
   "TEST ERROR", /* 29 */
   "Maximum number of channels reached", /* 30 */
   "Maximum number of images reached", /* 31 */
   "The open file mode is not set", /* 32 */
   "Negative or null image dimension(s)", /* 33 */
   "Error while doing fwrite on file"   /* 34 */
 };
#else
   GLOBAL  char *TIFSIV_ERRS_error_message[];
#endif

#else

#define ERRSID_TIFS_err_opn_tif		 2
#define ERRSID_TIFS_err_not_tif		 2
#define ERRSID_TIFS_err_not_ifd_mem_r    3
#define ERRSID_TIFS_err_max_tif_opn	 2
#define ERRSID_TIFS_err_isn_opn_tif	 2
#define ERRSID_TIFS_err_no_param	 2
#define ERRSID_TIFS_err_not_tag_mem	 3
#define ERRSID_TIFS_err_not_ifd_mem_w	 3
#define ERRSID_TIFS_err_no_par_num	 2
#define ERRSID_TIFS_err_no_img_num	 2
#define ERRSID_TIFS_err_no_more_par_w	 2
#define ERRSID_TIFS_err_not_opn_tif	 2
#define ERRSID_TIFS_err_no_block	 2
#define ERRSID_TIFS_err_no_bas_par	 2
#define ERRSID_TIFS_err_no_mem_blk	 3
#define ERRSID_TIFS_err_wr_bas_par	 2
#define ERRSID_TIFS_err_no_mem_lzw	 3
#define ERRSID_TIFS_err_no_mem_bufl	 3
#define ERRSID_TIFS_err_no_mem_bufb	 3
#define ERRSID_TIFS_err_no_disp		 2
#define ERRSID_TIFS_err_no_mem_flg	 3
#define ERRSID_TIFS_err_no_ovr_par	 2
#define ERRSID_TIFS_err_on_fseek     	 2
#define ERRSID_TIFS_bad_dimensions       2
#define ERRSID_TIFS_undef_data_type      2
#define ERRSID_TIFS_not_allow_data_type  2
#define ERRSID_TIFS_memory_alloc_failure 3
#define ERRSID_TIFS_test_error           2
#define ERRSID_TIFS_max_chan             2
#define ERRSID_TIFS_max_img              2
#define ERRSID_TIFS_mode_not_set         2
#define ERRSID_TIFS_neg_dimensions       2
#define ERRSID_TIFS_err_on_fwrite    	 2

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */
#ifdef TIFS_GLBL
   GLOBAL char *TIFSIV_ERRS_error_message[] = 
 { "No error happens",                   /* 0 */
   "Generic error happens",              /* 1 */
   "TIFF library error happens",         /* 2 */
   "Not enough memory for this task"     /* 3 */
 };
#else
   GLOBAL  char *TIFSIV_ERRS_error_message[];
#endif

#endif

#ifdef __UNUSED__
/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IDLErrorMessages

      $DESCRIPTION  Error messages for IDL interface

   $EH
   ========================================================================== */
#ifdef __VMS__

#ifdef TIFS_GLBL
GLOBAL char IDLErrorMessages[IDLNMESSAGES][IDLMESSAGESLENGTH] = {
  "", /* 0 not used */
  "Error opening the file ", /* 1 */
  "Not a TIFF file ", /* 2 */
  "Cannot allocate memory in IFD tables reading the file ", /* 3 */
  "Reached the max number of opened files after the file ", /* 4 */
  "Is not a opened file ", /* 5 */
  "Not exist such parameter in file ", /* 6 */
  "Cannot allocate memory buffer for tag ", /* 7 */
  "Cannot allocate memory in IFD tables writing the file ", /* 8 */
  "The parameter number is not set in file ", /* 9 */
  "The image does not exist in file ", /* 10 */
  "Cannot write more parameters than the allocated number in file ", /* 11 */
  "A channel is access before opening the related file ", /* 12 */
  "The image block accessed does not exist in file ", /* 13 */
  "A basic parameter is not present in file ", /* 14 */
  "Cannot allocate memory in blockoffs or blocksize tables in file ", /* 15 */
  "Error writing the basic parameters in file ", /* 16 */
  "Cannot allocate memory for LZW compression buffer in file ", /* 17 */
  "Cannot allocate memory for the line buffer in file ", /* 18 */
  "Cannot allocate memory for the block buffer in file ", /* 19 */
  "The basic parameter DISPOSITION is not specified in file ", /* 20 */
  "Cannot allocate memory for the flag table in file ", /* 21 */
  "Cannot overwrite a parameter with a different type in file ", /* 22 */
  "Cannot convert a BTIFF parameter in a IDL type in file ", /* 23 */
  "Type o size mismatch in IDL tag list array in file ", /* 24 */
  "Inconsistent coordinates reading a subimage in file ", /* 25 */
  "Inconsistent IDL buffer reading a subimage in file ", /* 26 */
  "Inconsistent coordinates writing a subimage in file ", /* 27 */
  "Inconsistent IDL buffer writing a subimage in file ", /* 28 */
  "The compression parameter value in invalid in file ", /* 29 */
  "Cannot convert a IDL parameter in a BTIFF type in file ", /* 30 */
  "Wrong number of argument passed to a IDL-BTIFF routine ", /* 31 */
  "", /* 32 */
  "", /* 33 */
  "", /* 34 */
  "", /* 35 */
  "", /* 37 */
  "", /* 38 */
  "" /*  39 */
};
#else
GLOBAL char IDLErrorMessages[IDLNMESSAGES][IDLMESSAGESLENGTH] ;
#endif

#else

#ifdef TIFS_GLBL
GLOBAL char IDLErrorMessages[IDLNMESSAGES][IDLMESSAGESLENGTH] = {
  "", /* 0 not used */
  "Error opening the file ", /* 1 */
  "Not a TIFF file ", /* 2 */
  "Cannot allocate memory in IFD tables reading the file ", /* 3 */
  "Reached the max number of opened files after the file ", /* 4 */
  "Is not a opened file ", /* 5 */
  "Not exist such parameter in file ", /* 6 */
  "Cannot allocate memory buffer for tag ", /* 7 */
  "Cannot allocate memory in IFD tables writing the file ", /* 8 */
  "The parameter number is not set in file ", /* 9 */
  "The image does not exist in file ", /* 10 */
  "Cannot write more parameters than the allocated number in file ", /* 11 */
  "A channel is access before opening the related file ", /* 12 */
  "The image block accessed does not exist in file ", /* 13 */
  "A basic parameter is not present in file ", /* 14 */
  "Cannot allocate memory in blockoffs or blocksize tables in file ", /* 15 */
  "Error writing the basic parameters in file ", /* 16 */
  "Cannot allocate memory for LZW compression buffer in file ", /* 17 */
  "Cannot allocate memory for the line buffer in file ", /* 18 */
  "Cannot allocate memory for the block buffer in file ", /* 19 */
  "The basic parameter DISPOSITION is not specified in file ", /* 20 */
  "Cannot allocate memory for the flag table in file ", /* 21 */
  "Cannot overwrite a parameter with a different type in file ", /* 22 */
  "Cannot convert a BTIFF parameter in a IDL type in file ", /* 23 */
  "Type o size mismatch in IDL tag list array in file ", /* 24 */
  "Inconsistent coordinates reading a subimage in file ", /* 25 */
  "Inconsistent IDL buffer reading a subimage in file ", /* 26 */
  "Inconsistent coordinates writing a subimage in file ", /* 27 */
  "Inconsistent IDL buffer writing a subimage in file ", /* 28 */
  "The compression parameter value in invalid in file ", /* 29 */
  "Cannot convert a IDL parameter in a BTIFF type in file ", /* 30 */
  "Wrong number of argument passed to a IDL-BTIFF routine ", /* 31 */
  "", /* 32 */
  "", /* 33 */
  "", /* 34 */
  "", /* 35 */
  "", /* 37 */
  "", /* 38 */
  "" /*  39 */
};
#else
GLOBAL char IDLErrorMessages[IDLNMESSAGES][IDLMESSAGESLENGTH] ;
#endif

#endif /* __VMS__ */

#endif /* __UNUSED__ */

#endif
