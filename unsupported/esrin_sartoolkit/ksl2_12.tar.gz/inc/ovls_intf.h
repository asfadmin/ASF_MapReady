/* ==========================================================================
   $MODULE_HEADER

      $NAME              OVLS_INTF

      $FUNCTION          OVERLAP & SAVE interface module.

      $ROUTINE           OVLSIP_OverlapAndSave
                         OVLSIP_CheckMemory

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       05-AUG-97     AG       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef OVLS
#define OVLS OVLS


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include GIOS_INTF_H

#ifdef OVLS_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         OVLSID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define OVLSID_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         OVLSIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum OVLSIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         OVLSIC_

      $DESCRIPTION  The OVLSIC_

   $EH
   ========================================================================== */
/*   const OVLSIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         OVLSIT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct OVLSIT_*_def { 

   typedef struct OVLSIT_*_def OVLSIT_*
*/

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         OVLSIT_core_func

      $DESCRIPTION  This type defines the prototype of the core functions for
                    the filtering                  

   $EH
   ========================================================================== */
typedef void (*OVLSIT_core_func)
      (UINTx4, UINTx4, UINTx4, double, double, UINTx4, MATHIT_RC *,
       float **, UINTx4, UINTx4, void **, UINTx4, UINTx4, LDEFIT_data_type, 
       GIOSIT_io *, UINTx4, float, UINTx1, ERRSIT_status *);

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         OVLSIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         OVLSIP_OverlapAndSave

        $TYPE         PROCEDURE

        $INPUT        inp_chan	    : the channel of the input file
                      inp_img	    : image number of the input image in the
				      input file
                      inp_bpar      : structure with the TIFF basic parameters
                                      of the input image
                      TLRow	    : row coordinate of the first pixel of the
				      image to filter in the full image	
				      reference system
                      TLCol	    : column coordinate of the first pixel of
				      the image to filter in the full image
				      reference system
                      nrow_inp	    : number of rows of the input image block
                      ncol_inp	    : number of columns of the input image block
                      Kern	    : kernel matrix
                      Kr	    : rows kernel size
                      Kc	    : columns kernel size
                      stepR   	    : rows step
                      stepC   	    : columns step
                      out_chan	    : channel of the output image file
                      out_img	    : ID of the output image in the output file
                      nrow_out      : number of rows of the output image block
                      ncol_out      : number of columns of the output image block
		      core_func	    : function to apply to the image block of
				      the overlap and save procedure
                      fill_val      : float filler value
                      data_size     : size of record in read

        $MODIFIED     NONE

        $OUTPUT       The output image is filled

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_OVLS_incorrect_rows_cols
		      ERRSID_OVLS_no_undersampling
		      ERRSID_OVLS_kernel_dim_high
		      ERRSID_OVLS_read_block_dim_low
		      ERRSID_OVLS_err_mem_alloc
		      ERRSID_OVLS_data_type_not_allow

        $DESCRIPTION  This procedure reads the input image blocking it with an
		      Overlp & Save algorithm (O&S) considering the filter
		      transient. Each image block is passed to a core function
		      user defined. The core function fills the output image
		      file.

        $WARNING      The input and the output image must be initialised before
		      calling this procedure. The open line of the input and the
		      output image are done here.

        $PDL	      - Evaluate the size of the image block to read at each
		        O&S step in the rows direction
		      - Evaluate the steps of the moving window
		      - Evaluate the equivalent dimensions of the block to read
			at each step
		      - Evaluate the number of blocks to read
		      - Allocate the memory for the input image block storing
		      - Open the line reading for the input image
		      - Open the line writing for the output image
		      - Inizialise the counters
		      - Loop over the rows blocks with full dimensions
			    - Update the counters and the block sizes
                            - Read the image block
			    - Call the core function
			    - Reset the counters
		      - End loop
		      - If there are not full dimensions image block
			    - Update the counters and the block sizes
                            - Read the image block
                            - Call the core function
		      - End if
		      - Close the line writing for the output image
		      - Close the line reading for the input image
		      - Free the allocated memories

   $EH
   ========================================================================== */
   extern void OVLSIP_OverlapAndSave
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               vertex_no,
			 /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ double               stepR,
                         /*IN    */ double               stepC,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
			 /*IN    */ OVLSIT_core_func     core_func,
                         /*IN    */ float                fill_val,
                         /*IN    */ INTx4                data_size,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         OVLSIP_CheckMemory

        $TYPE         PROCEDURE

        $INPUT        inp_io     : array of input files descriptors
                      NInpImages : number of input images
                      out_io     : array of output files descriptors
                      NOutImages : number of output images
                      ncol_inp   : number of input columns
                      ncol_out   : number of output columns

        $MODIFIED     NONE

        $OUTPUT       RReadDim   : size of the block that can be read at each
                                   step of the Overlap and Save

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_OVLS_not_compat_ima
                      ERRSID_OVLS_not_enough_memory

        $DESCRIPTION  This procedure evaluates the size of the block to read in
                      the Overlap and Save procedure evaluates WRT the available
                      memory in the machine

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void OVLSIP_CheckMemory
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx4               NInpImages,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               NOutImages,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               ncol_out,
                         /*   OUT*/ UINTx4              *RReadDim,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         OVLSIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/*   extern void OVLSIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         OVLSIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void OVLSIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) OVLSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         OVLSIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    OVLSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define OVLSIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#ifdef __VMS__

#define ERRSID_OVLS_err_mem_alloc        2
#define ERRSID_OVLS_incorrect_rows_cols  3
#define ERRSID_OVLS_kernel_dim_high      4
#define ERRSID_OVLS_read_block_dim_low   5
#define ERRSID_OVLS_data_type_not_allow  6
#define ERRSID_OVLS_not_enough_memory    7
#define ERRSID_OVLS_not_compat_ima       8

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef OVLS_GLBL
   GLOBAL char *OVLSIV_ERRS_error_message[] = 
                        { "No error happens",                       /* 0 */
                          "Generic error happens",                  /* 1 */
                          "SYSTEM ERROR: memory allocation error",  /* 2 */
			  "Incorrect number of rows/columns",       /* 3 */
			  "Kernel dimensions too high",             /* 4 */
			  "Reading block dimensions too low",       /* 5 */
			  "Data type not allowed",                  /* 6 */
                          "Not enough memory"                       /* 7 */
                          "Images not compatible",                  /* 8 */
                        };
#else
   GLOBAL char *OVLSIV_ERRS_error_message[];
#endif

#else

#define ERRSID_OVLS_err_mem_alloc        2
#define ERRSID_OVLS_incorrect_rows_cols  2
#define ERRSID_OVLS_kernel_dim_high      2
#define ERRSID_OVLS_read_block_dim_low   2
#define ERRSID_OVLS_data_type_not_allow  2
#define ERRSID_OVLS_not_enough_memory    3
#define ERRSID_OVLS_not_compat_ima       2

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef OVLS_GLBL
   GLOBAL char *OVLSIV_ERRS_error_message[] = 
                        { "No error happens",                       /* 0 */
                          "Generic error happens",                  /* 1 */
                          "Overlap & Save library error happens",   /* 2 */
                          "Not enough memory for this task"         /* 3 */
                        };
#else
   GLOBAL char *OVLSIV_ERRS_error_message[];
#endif

#endif

#endif
