/* ==========================================================================
   $MODULE_HEADER

      $NAME              DEVS_INTF

      $FUNCTION          Device Access Service interface module.

      $ROUTINE           DEVSIP_open_read
                         DEVSIP_mount
                         DEVSIF_read
                         DEVSIP_dismount
                         DEVSIP_close

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       20-MAR-97     AG       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef DEVS
#define DEVS DEVS


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H

#ifdef DEVS_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         DEVSID_max_read_size

      $DESCRIPTION  Define the maximum reading size for tape

   $EH
   ========================================================================== */
#define DEVSID_max_read_size 65534

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         DEVSIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum DEVSIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         DEVSIC_

      $DESCRIPTION  The DEVSIC_

   $EH
   ========================================================================== */
/*   const DEVSIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         DEVSIT_io

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct DEVSIT_io_def { 
      char        media[256];
      INTx4       curr_start_line;
      INTx4       curr_end_line;
      void      **curr_buff;
   };
   typedef struct DEVSIT_io_def DEVSIT_io;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         DEVSIT_media_type

      $DESCRIPTION  Enumerated for different media types

   $EH
   ========================================================================== */
   enum DEVSIE_media_type {
      DEVSIE_mt_none,
      DEVSIE_mt_file,
      DEVSIE_mt_exa,
      DEVSIE_mt_cdrom
   };
   typedef enum DEVSIE_media_type DEVSIT_media_type;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         DEVSIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIP_open_read

      $TYPE	    PROCEDURE

      $INPUT        media_name

      $MODIFIED     NONE

      $OUTPUT       descriptor

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure open a descriptor to read the specified
                    media.

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void DEVSIP_open_read
                        (/*IN    */ char                *media_name,
                         /*   OUT*/ INTx4               *descriptor,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIP_mount

      $TYPE	    PROCEDURE

      $INPUT        descriptor

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure mount the media specified by the descriptor
                    and rewind it.

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void DEVSIP_mount
                        (/*IN    */ char                *media_name,
                         /*IN    */ INTx4                descriptor,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIF_read

      $TYPE         Procedure

      $INPUT        descriptor   :  pointer to the media to be read
                    data_size    :  size of the buffer to be read

      $MODIFIED     data_ptr     :  pointer where store the bytes read

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure read from an open media and store the 
                    data_size bytes in the data_ptr. Returns the effective
                    number of bytes read. 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
   extern INTx4 DEVSIF_read         
                        (/*IN    */ INTx4                descriptor,
                         /*IN    */ INTx4                data_size,
                         /*IN OUT*/ void                *data_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIP_read_block

      $TYPE         Procedure

      $INPUT        descriptor   :  pointer to the media to be read
                    data_size    :  size of the buffer to be read
                    no_lines     :  number of lines

      $MODIFIED     data_ptr     :  pointer where store the bytes read

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure read a set lines from an open media and 
                    store the data_size bytes in the data_ptr. 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
   extern void DEVSIP_read_block         
                        (/*IN    */ INTx4                descriptor,
                         /*IN    */ INTx4                data_size,
                         /*IN    */ INTx4                no_lines,
                         /*IN OUT*/ void               **data_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIP_dismount

      $TYPE	    PROCEDURE

      $INPUT        descriptor

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure rewind the media specified by the descriptor
                    and dismount it.

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void DEVSIP_dismount    
                        (/*IN    */ char                *media_name,
                         /*IN    */ INTx4                descriptor,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIP_close

      $TYPE	    PROCEDURE

      $INPUT        NONE

      $MODIFIED     descriptor

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure closes the descriptor to the media and
                    zeros it.

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void DEVSIP_close       
                        (/*IN OUT*/ INTx4               *descriptor,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void DEVSIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) DEVSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         DEVSIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    DEVSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define DEVSIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_DEVS_err_opn_in_read      2
#define ERRSID_DEVS_err_in_read          3
#define ERRSID_DEVS_err_in_mount         4
#define ERRSID_DEVS_err_in_dismount      5

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef DEVS_GLBL
   GLOBAL char *DEVSIV_ERRS_error_message[] = 
                        { "No error happens",
                          "Generic error happens",
                          "Error opening descriptor to media for read",
                          "Error while reading from media",
                          "Error while mounting the media",
                          "Error while dismounting the media"
                        };
#else
   GLOBAL char *DEVSIV_ERRS_error_message[];
#endif


#endif
