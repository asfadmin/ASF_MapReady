/* ==========================================================================
   $MODULE_HEADER

      $NAME              BUFS_PGLB

      $FUNCTION          global module.

      $ROUTINE           BUFSPP_

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       08-OCT-97     AN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include BUFS_INTF_H


#ifdef  BUFS_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSPD_max_buffers

      $DESCRIPTION  BUFS library limits

   $EH
   ========================================================================== */
#define BUFSPD_max_buffers      10

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum BUFSPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSPC_

      $DESCRIPTION  The BUFSPC_

   $EH
   ========================================================================== */
/*   const BUFSPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSPT_gid

      $DESCRIPTION  This type contains the variables used by the library
                    to keep information about open buffers

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          p_data                           Pointers to the first pixel in the 
                                           data buffer
          line_buff                        contain the current line
          n_rows                           Number of image rows
          n_columns                        Number of image columns
          sample_per_pixel                 Number of bands interlived by pixel
                                           in the image
          data_type                        Type of data expressed by the values
                                           enumerated by the LDEFIE_data_type
          direction                        Direction of reading
          start_line                       Start line to read
          end_line                         End line to read
          used                             Flag to indicate that the structure
                                           channel is used

   $EH
   ========================================================================== */
   struct BUFSPT_gid_def {
      void               *p_data;
      void               *line_buff;
      char                r_w;
      UINTx4              n_rows;
      UINTx4              n_columns;
      UINTx2              sample_per_pixel;
      LDEFIT_data_type    data_type;
      char                direction;
      UINTx4              start_line;
      UINTx4              end_line;
      LDEFIT_boolean      used;
   };

   typedef struct BUFSPT_gid_def BUFSPT_gid;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSPT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct BUFSPT_*_def { 

   typedef struct BUFSPT_*_def BUFSPT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSPV_gid

      $DESCRIPTION  This variable contains the parameters needed to read from
                    or to write to memory buffers

   $EH
   ========================================================================== */
   GLOBAL BUFSPT_gid BUFSPV_gid[ BUFSPD_max_buffers ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSPV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         BUFSPP_

      $DESCRIPTION  

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/*   extern void BUFSPP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         BUFSPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 BUFSPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         BUFSPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void BUFSPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) BUFSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( BUFSPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         BUFSIM_

      $DESCRIPTION  This procedure

                    BUFSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define BUFSPM_
*/
