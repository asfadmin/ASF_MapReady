/* ==========================================================================
   $MODULE_HEADER

      $NAME              IREG_PGLB

      $FUNCTION          global module.

      $ROUTINE           IREGPP_GCPE_Init
                         IREGPP_GCPE_Close
                         IREGPP_GCPE_GridCreator
                         IREGPP_GCPE_MasterGCP
                         IREGPP_GCPE_MasRowCol2LatLon
                         IREGPP_GCPE_SlaveGCP
                         IREGPP_GCPE_CellExtraction
                         IREGPP_GCPE_FillImaCell
                         IREGPP_GCPE_PointSubMatrix
                         IREGPP_GCPE_RotAngleEval
                         IREGPP_GCPE_SlaveCorners
                         IREGPP_GCPE_SlaveToMaster
                         IREGPP_GCPE_AngleEval
                         IREGPP_GCPE_CellExtractor
                         IREGPP_GCPE_ElemSizeEval
                         IREGPP_GCPE_EnlCellAndGridAlloc
                         IREGPP_GCPE_ShiftEvaluation
                         IREGPP_GCPE_FillRotGrid
                         IREGPP_GCPE_FillArray
                         IREGPP_GCPE_ZeroPadding
                         IREGPP_GCPE_FindMaximum
                         IREGPP_GCPE_CoarseRegistrator
                         IREGPP_GCPE_SetDataType
                         IREGPP_GCPE_ModulEval
                         IREGPP_GCPE_FFTAbsImaEval
                         IREGPP_GCPE_ArrayModulEval
                         IREGPP_GCPE_Shifts
                         IREGPP_GCPE_CrossCorrInterp
                         IREGPP_GCPE_RCRotate
                         IREGPP_GCPE_StabilityTest
                         IREGPP_GCPE_ArraysAllocation
                         IREGPP_GCPE_SmoothIma2float
                         IREGPP_GCPE_SmoothImafloat
                         IREGPF_GCPE_Coherfloat
                         IREGPF_GCPE_Coher2float
                         IREGPP_GCPE_CoherMaxim
                         IREGPP_GCPE_InitFineReg
                         IREGPP_GCPE_CloseFineReg
                         IREGPP_GCPE_FineRegistrator
                         IREGPP_GCPE_ReadGCPs
                         IREGPP_WAEV_NormMatrEval
                         IREGPP_WAEV_OneDegMatrEval
                         IREGPP_WAEV_OneHalfDegMatrEval
                         IREGPP_WAEV_TwoDegMatrEval
                         IREGPP_WAEV_ThreeDegMatrEval
                         IREGPP_WAEV_MatrEval
                         IREGPP_WAEV_WarpEval
                         IREGPP_WAEV_InitWarp
                         IREGPP_WAEV_CloseWarp
                         IREGPP_WAEV_OneDegConv
                         IREGPP_WAEV_OneAndHalfDegConv
                         IREGPP_WAEV_TwoDegConv
                         IREGPP_WAEV_ThreeDegConv
                         IREGPP_WAEV_Mas2Sla
                         IREGPP_WAEV_Sla2Mas
                         IREGPP_WAEV_VectMas2Sla
                         IREGPP_WAEV_VectSla2Mas
                         IREGPP_WAEV_WarpCheck
                         IREGPP_WAEV_EditGCPs
                         IREGPP_WAEV_WriteResid
                         IREGPP_LAYO_MaxOverlap
                         IREGPP_LAYO_MasterOverlap
                         IREGPP_LAYO_MinOverlap
                         IREGPP_LAYO_FillBorderArray
                         IREGPP_LAYO_Slave2MasterContour
                         IREGPP_LAYO_MaxSlaveCorners
                         IREGPP_LAYO_MinSlaveCorners
                         IREGPP_LAYO_CornersEval
                         IREGPP_WRIM_InterpolateImages
                         IREGPP_WRIM_InitInterp
                         IREGPP_WRIM_CloseInterp
                         IREGPP_WRIM_WriteSlave
                         IREGPP_WRIM_CoreInterpolator
                         IREGPP_WRIM_FillPointsArray
                         IREGPP_WRIM_WriteMasterBlock
                         IREGPP_WRIM_MaxOverlap
                         IREGPP_WRIM_Interpolate
                         IREGPP_WRIM_CheckMemory
                         IREGPP_BSLN_BaselineEval
                         IREGPP_COHE_AllocImages
                         IREGPP_COHE_CoreFunc
                         IREGPP_COHE_FillVal
                         IREGPP_COHE_MoveCol
                         IREGPP_COHE_MoveRow

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       23-OCT-97     GRV       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include GIOS_INTF_H
#include IANN_INTF_H
#include IREG_INTF_H


#ifdef IREG_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_sqrt_tol

      $DESCRIPTION  It defines the maximum negative value for the sqrt argument

   $EH
   ========================================================================== */
#define IREGPD_sqrt_tol ( (double)5.e-03 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_max_GCP_dir_number

      $DESCRIPTION  It defines the maximum number of GCPs in a direction

   $EH
   ========================================================================== */
#define IREGPD_max_GCP_dir_number   ( (UINTx4)500 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_max_img

      $DESCRIPTION  It defines the maximum number of images to co-register

   $EH
   ========================================================================== */
#define IREGPD_max_img    ( (UINTx2)10 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_rot_ang_min

      $DESCRIPTION  The minimum value of the rotation angle to be considered
                    different from zero

   $EH   
   ========================================================================== */
#define IREGPD_rot_ang_min    ( (double)1.e-02 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_coher_bord

      $DESCRIPTION  The number of pixel to eliminate at the borders in the
                    slave shifted image in the coherence evaluation

   $EH   
   ========================================================================== */
#define IREGPD_coher_bord  ( (INTx2)3 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_min_cell_dim

      $DESCRIPTION  The minimum useful size of the image cells for the fine
                    registration

   $EH   
   ========================================================================== */
#define IREGPD_min_cell_dim  ( (INTx2)10 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_coher_ndim  

      $DESCRIPTION  The number of shifts to evaluate with the coherence
                    maximization

   $EH   
   ========================================================================== */
#define IREGPD_coher_ndim  ( (INTx4)2 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_max_fine_shift

      $DESCRIPTION  The minimum value of the tollerable shift for the fine
                    shifts

   $EH   
  ========================================================================== */
#define IREGPD_max_fine_shift  ( (float)2.0 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_sla_bord_step
                    IREGPD_mas_bord_step

      $DESCRIPTION  The value of the steps with which the slaves and the master
                    borders respectively are covered in the layover definition

   $EH
   ========================================================================== */
#define IREGPD_sla_bord_step     ( (INTx4)100 )
#define IREGPD_mas_bord_step     ( (INTx4)200 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_max_RMS

      $DESCRIPTION  The value of the maximum RMS value allowed for the warp
                    residual

   $EH
   ========================================================================== */
#define IREGPD_max_RMS   50

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_enlarge_fact

      $DESCRIPTION  The factor to enlarge the window size in the image
                    interpolation to take into account the warp errors

   $EH
   ========================================================================== */
#define IREGPD_enlarge_fact   1.

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPD_Max_Vertex

      $DESCRIPTION  Limit the max number of vertex when computing minimum overlap

   $EH
   ========================================================================== */
#define IREGPD_Max_Vertex 1000

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPE_warp_deg

      $DESCRIPTION  It enumerate the possible warp matrices degrees

   $EH
   ========================================================================== */
   enum IREGPE_warp_deg  {
      IREGPE_wd_undef,                           /* null elements value */
      IREGPE_wd_one,                             /* one degree          */
      IREGPE_wd_one_half,                        /* one and half degree */
      IREGPE_wd_two,                             /* two degree          */
      IREGPE_wd_three                            /* three degree        */
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPE_over_mode

      $DESCRIPTION  It enumerate the possible overlapping modes

   $EH
   ========================================================================== */
   enum IREGPE_over_mode  {
      IREGPE_om_undef,                 /* null element */
      IREGPE_om_min,                   /* minimum overlap */
      IREGPE_om_max,                   /* maximum overlap */
      IREGPE_om_master                 /* master overlap  */
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPE_inter_mode

      $DESCRIPTION  It enumerate the possible interpolation modes

   $EH
   ========================================================================== */
   enum IREGPE_inter_mode  {
      IREGPE_im_undef,                 /* null element */
      IREGPE_im_nn,                    /* nearest neighbour interpolation */
      IREGPE_im_bil,                   /* bilinear interpolation */
      IREGPE_im_cc,                    /* cubic convolution interpolation */
      IREGPE_im_fftshift,              /* FFT constant shift interpolation */
      IREGPE_im_sinc,                  /* sinc interpolation */
      IREGPE_im_ccfftshift,            /* cubic conv in range and FFT */
                                       /* constant shift in azimuth   */
      IREGPE_im_sincfftshift           /* sinc interpolation in range and */
                                       /* FFT constant shift in azimuth   */
   };

/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPT_gcp

      $DESCRIPTION  This type is a structure describing a GCP

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          coor                             the GCP coordinates
          quality                          an indicator of the GCP quality 
          valid                            the flag indicating if the GCP is
                                           valid or not

   $EH
   ========================================================================== */
   struct IREGPT_gcp_def {
      MATHIT_RC      coor;
      float          quality;
      LDEFIT_boolean valid;
   };

   typedef struct IREGPT_gcp_def IREGPT_gcp;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPT_gcps_descr

      $DESCRIPTION  This type is a structure that will contain the array of
                    GCPs and the number of them

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          n_gcp                            number of grid GCPs
          gcp_arr                          array of structure of type
                                           IREGPT_gcp

   $EH
   ========================================================================== */
   struct IREGPT_gcps_descr_def {
      UINTx4          n_gcp;
      IREGPT_gcp     *gcp_arr;
   };

   typedef struct IREGPT_gcps_descr_def IREGPT_gcps_descr;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPT_coher

      $DESCRIPTION  This type is a structure that will contain the pointers
                    to the master and slave cells for the coherence maximi-
                    zation and related info

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          init_masp                        double pointer to the master cell
          init_slap                        double pointer to the slave cell
          curr_slap                        double pointer to the current slave
                                           cell
          masp                             double pointer to the master cell
                                           with the borders reduced
          slap                             double pointer to the slave cell
                                           with the borders reduced
          v1v2                             double pointer to the correlation
                                           matrix
          v1v1                             double pointer to the master cova-
                                           riance matrix
          v2v2                             double pointer to the slave cova-
                                           riance matrix
          sv1v1                            double pointer to the smoothed
                                           master variance matrix
          sv2v2                            double pointer to the smoothed
                                           slave variance matrix
          sv1v2                            double pointer to the smoothed
                                           covariance matrix
          cnum                             double pointer to the numerator
                                           matrix
          cden                             double pointer to the denumerator
                                           matrix
          init_nrow                        number of rows of the two cells
          init_ncol                        number of columns of the two cells
          nrow                             number of rows of the two cells
                                           without borders
          ncol                             number of columns of the two cells
                                           without borders
          data_type                        cells image data type
          p                                ancillary matrix for the coherence
                                           maximization procedure
          y                                           "     "

   $EH
   ========================================================================== */
   struct IREGPT_coher_def {
      float           **init_masp;
      float           **init_slap;
      float           **curr_slap;
      float           **masp;
      float           **slap;
      float           **v1v2;
      float           **v1v1;
      float           **v2v2;
      float           **sv1v1;
      float           **sv2v2;
      float           **sv1v2;
      float           **cnum;
      float           **cden;
      INTx2             init_nrow;
      INTx2             init_ncol;
      INTx2             nrow;
      INTx2             ncol;
      LDEFIT_data_type  data_type;
      double           *p;
      double           *y;
   };

   typedef struct IREGPT_coher_def IREGPT_coher;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPT_warp_deg

      $DESCRIPTION  This type defines the possible warp degree types

   $EH
   ========================================================================== */
   typedef enum IREGPE_warp_deg IREGPT_warp_deg;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPT_norm_func

      $DESCRIPTION  This type defines the possible functions to evaluate the
                    normal matrix for the warp evaluation as function of the
                    degree

   $EH
   ========================================================================== */
   typedef void (*IREGPT_norm_func)
      ( MATHIT_RC *, INTx4, double **, ERRSIT_status * );

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPT_conv_func

      $DESCRIPTION  This type defines the possible functions to convert the
                    coordinates row col of a point using a warp matrix

   $EH
   ========================================================================== */
   typedef void (*IREGPT_conv_func)
      ( MATHIT_RC, double **, MATHIT_RC *, ERRSIT_status * );

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPT_warp_matr

      $DESCRIPTION  This type contains the direct and inverse warp
                    matrices for each master - slave couple

   $EH
   ========================================================================== */
   struct IREGPT_warp_def {
      double         **wmas2sla;
      double         **wsla2mas;
   };

   typedef struct IREGPT_warp_def IREGPT_warp_matr;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPT_over_mode

      $DESCRIPTION  It defines an enumerate type that defines the type of
                    possible overlap systems in SAR-Toolbox co-registrator

   $EH
   ========================================================================== */
   typedef enum IREGPE_over_mode IREGPT_over_mode;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPT_over_func

      $DESCRIPTION  It defines the type of the functions that evaluates the
                    corners of the overlapping zone

   $EH
   ========================================================================== */
   typedef void ( *IREGPT_over_func )
      ( INTx4 *, INTx4 *, INTx4 *, INTx4 *, ERRSIT_status * );

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPT_inter_mode

      $DESCRIPTION  This type describes the enumerate variable with the
                    interpolation modes

   $EH
   ========================================================================== */
   typedef enum IREGPE_inter_mode IREGPT_inter_mode ;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPT_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   typedef IREGPT_
*/

/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPC_coher_shift

      $DESCRIPTION  This is the initial simplex for the coherence
                    maximization procedure

   $EH
   ========================================================================== */
#ifdef IREG_GLBL
   GLOBAL const double IREGPC_coher_shift[ 3 ] [ 2 ] = {
      { -1.00, -1.00},
      {  0.50, -0.50},
      {  1.00,  1.00}
   };
#else
   GLOBAL const double IREGPC_coher_shift[ ][ 2 ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPC_warp_npar

      $DESCRIPTION  This is the number of parameters to estimates for each
                    transformation at a degree

   $EH
   ========================================================================== */
#ifdef IREG_GLBL
   GLOBAL const UINTx1 IREGPC_warp_npar[ 5 ] = {
       0,         /* zero degree         */
       3,         /* degree one          */
       4,         /* degree one and half */
       6,         /* degree two          */
      10          /* degree three        */
   };
#else
   GLOBAL const UINTx1 IREGPC_warp_npar[];
#endif

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_GCP_mas_num_row
                    IREGPV_GCP_mas_num_col

      $DESCRIPTION  They contains the number of GCPs required on the master
                    image in the two direction

   $EH
   ========================================================================== */
   GLOBAL INTx4 IREGPV_GCP_mas_num_row;
   GLOBAL INTx4 IREGPV_GCP_mas_num_col;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_gcp

      $DESCRIPTION  It's an array of structures containing the GCPs INFO

   $EH
   ========================================================================== */
   GLOBAL IREGPT_gcps_descr IREGPV_gcp[ IREGPD_max_img ] ;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_coarse_cell_dim_row
                    IREGPV_coarse_cell_dim_col

      $DESCRIPTION  They are the cell dimensions for the extraction in the
                    GCP co-registration

   $EH
   ========================================================================== */
   GLOBAL INTx4 IREGPV_coarse_cell_dim_row;
   GLOBAL INTx4 IREGPV_coarse_cell_dim_col;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_int_fact_row
                    IREGPV_int_fact_col

      $DESCRIPTION  They are the interpolation factors for the GCP
                    co-registration

   $EH
   ========================================================================== */
   GLOBAL float IREGPV_int_fact_row;
   GLOBAL float IREGPV_int_fact_col;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_coher

      $DESCRIPTION  It's a variable that contains the information for the
                    coherence maximization

   $EH
   ========================================================================== */
   GLOBAL IREGPT_coher IREGPV_coher;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_fine_cell_dim_row
                    IREGPV_fine_cell_dim_col

      $DESCRIPTION  They contains the dimensions of the image cells for the
                    fine image registration

   $EH
   ========================================================================== */
   GLOBAL INTx4 IREGPV_fine_cell_dim_row;
   GLOBAL INTx4 IREGPV_fine_cell_dim_col;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_coher_wsiz

      $DESCRIPTION  The size of the moving window for the coherence evaluation

   $EH   
   ========================================================================== */
   GLOBAL INTx2 IREGPV_coher_wsiz;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_coher_ftol

      $DESCRIPTION  The value of the allowed tolerances for the coherence
                    function in the maximization procedure

   $EH   
   ========================================================================== */
   GLOBAL double IREGPV_coher_ftol;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_coher_vtol

      $DESCRIPTION  The values of the allowed tolerances for the variables to
                    find in the coherence maximization procedure

   $EH   
   ========================================================================== */
   GLOBAL double IREGPV_coher_vtol;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_warp_matr

      $DESCRIPTION  The values of the matrices to convert from master to slave
                    and viceversa

   $EH
   ========================================================================== */
   GLOBAL IREGPT_warp_matr IREGPV_warp_matr[ IANNID_NIMAMAX ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_warp_deg

      $DESCRIPTION  The value of the degree of the warp matrices

   $EH
   ========================================================================== */
   GLOBAL IREGPT_warp_deg IREGPV_warp_deg;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_inter_bord

      $DESCRIPTION  The value of the borders to add to the image cells to
                    extract in the image co-registration in order to
                    interpolate the cells

   $EH
   ========================================================================== */
#ifdef IREG_GLBL
   GLOBAL INTx4 IREGPV_inter_bord = 3;
#else
   GLOBAL INTx4 IREGPV_inter_bord;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_max_coarse_shift

      $DESCRIPTION  The minimum value of the tollerable shift for the stability
                    test in the coarse registration procedure

   $EH   
   ========================================================================== */
   GLOBAL float IREGPV_max_coarse_shift;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_max_point_RMS

      $DESCRIPTION  The minimum value of the tollerable residual between the
                    evaluated slave GCPs coordinates and the theorical ones

   $EH
   ========================================================================== */
   GLOBAL float IREGPV_max_point_RMS;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPV_int_win_row_size
                    IREGPV_int_win_col_size

      $DESCRIPTION  The interpolation window sizes in the two directions

   $EH
   ========================================================================== */
   GLOBAL INTx4 IREGPV_int_win_row_size;
   GLOBAL INTx4 IREGPV_int_win_col_size;

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_Init

        $TYPE         PROCEDURE

        $INPUT        NGCPRow              : number of GCPs in the rows
                                             direction
                      NGCPCol              : number of GCPs in the columns
                                             direction
                      row_coarse_cell_size : cell dimension in the row
                                             direction for the coarse 
                                             registration
                      col_coarse_cell_size : cell dimension in the column
                                             direction for the coarse 
                                             registration
                      int_fact_row         : interpolation factor in the
                                             row direction for the coarse
                                             registration
                      int_fact_col         : interpolation factor in the
                                             column direction for the coarse
                                             registration
                      row_fine_cell_size   : cell dimension in the row
                                             direction for the fine
                                             registration
                      col_fine_cell_size   : cell dimension in the column
                                             direction for the fine
                                             registration
                      coher_wsiz           : size of the square window for
                                             the coherence evaluation
                      coher_ftol           : tolerance in the function
                                             values for the convergence in
                                             the coherence evaluation
                      coher_vtol           : tolerance in the variables
                                             values for the convergence in
                                             the coherence evaluation
                      NImages              : number of input images
                      GCPFileName          : optional file name for the
                                             master GCPs

        $MODIFIED     NONE

        $OUTPUT       The array of structures that will contain the GCPs is
                      allocated

        $GLOBAL       IREGPV_GCP_mas_num_row     : number of GCPs in the rows
                                                   direction
                      IREGPV_GCP_mas_num_col     : number of GCPs in the columns
                                                   direction
                      IREGPV_coarse_cell_dim_row : cell dimension in the row
                                                   direction for the coarse
                                                   registration
                      IREGPV_coarse_cell_dim_col : cell dimension in the columns
                                                   direction for the coarse
                                                   registration
                      IREGPV_int_fact_row        : interpolation factor in the
                                                   rows direction for the coarse
                                                   registration
                      IREGPV_int_fact_col        : interpolation factor in the
                                                   columns direction for the
                                                   coarse registration
                      IREGPV_fine_cell_dim_row   : cell dimension in the rows
                                                   direction for the fine
                                                   registration
                      IREGPV_fine_cell_dim_col   : cell dimension in the columns
                                                   direction for the fine
                                                   registration
                      IREGPV_coher_wsiz          : size of the square window for
                                                   the coherence evaluation
                      IREGPV_coher_ftol          : tolerance in the function
                                                   values for the convergence in
                                                   the coherence evaluation
                      IREGPV_coher_vtol          : tolerance in the variables
                                                   values for the convergence in
                                                   the coherence evaluation
                      IREGPV_gcp                 : the structure with all the GCP
                                                   INFO

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_GCP_num_invalid
                      ERRSID_IREG_int_fact
                      ERRSID_IREG_coher_wsiz_null
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure initializes the structures that will
                      contain the GCPs and the related information

        $WARNING      THE VARIABLE THAT CONTAINS THE NUMBER OF OPENED IMAGES
                      AND THE VARIABLES WHITH THE NUMBER OF GCPS IN THE TWO
                      DIRECTIONS MUST BE FILLED BEFORE CALLING THIS PROCEDURE

        $PDL          - Fills the global variables and checks them
                      - Checks the image number
                      - If the number of GCPs is greather then the maximum
                        number
                            Sets the GCP number equals to the maximum number
                      - End if
                      - Evaluates the number of GCPs
                      - Zeroes the array of structures containing the GCPs info
                      - Loop over the images
                            - Allocates the array of structures with the GCPs
                            - Zeroes the allocated memories
                      - End loop
                      - Loop over the images
                            - Initializes the coordinates conversions
                      - End loop

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_Init
                        (/*IN    */ INTx4                NGCPRow,
                         /*IN    */ INTx4                NGCPCol,
                         /*IN    */ INTx4                row_coarse_cell_size,
                         /*IN    */ INTx4                col_coarse_cell_size,
                         /*IN    */ float                int_fact_row,
                         /*IN    */ float                int_fact_col,
                         /*IN    */ INTx4                row_fine_cell_size,
                         /*IN    */ INTx4                col_fine_cell_size,
                         /*IN    */ INTx2                coher_wsiz,
                         /*IN    */ double               coher_ftol,
                         /*IN    */ double               coher_vtol,
                         /*IN    */ INTx4                NImages,
                         /*IN    */ char                *GCPFileName,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_Close

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     The allocated memories to store the GCPs are free

        $OUTPUT       NONE

        $GLOBAL       IREGIV_ima_num : number of images involved in the tool
                      IREGPV_gcp     : array of structure with the GCPs info

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure deallocates the GCP info structure
                      allocated in the initialization procedure

        $WARNING      NONE

        $PDL          - Loop over the images
                            - Frees the gcp array
                      - End loop

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_Close
                        (/*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_GCPRegistrator

        $TYPE         PROCEDURE

        $INPUT        TLRow       : row coordinate of the top left corner of
                                    the AoI in which the registrator must act
                      TLCol       : column coordinate of the top left corner
                                    of the AoI in which the registrator must
                                    act
                      BRRow       : row coordinate of the bottom right corner
                                    of the AoI in which the registrator must
                                    act
                      BRCol       : column coordinate of the bottom right corner
                                    of the AoI in which the registrator must act
                      inp_io      : array of descriptors of the opened files
                      GCPFileName : name of the optional master GCP file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the driver for the GCPs registration

        $WARNING      NONE

        $PDL          - Creates the GCPs grid
                      - Makes the coarse registration
                      - Makes the fine registration

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_GCPRegistrator
                        (/*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                BRRow,
                         /*IN    */ INTx4                BRCol,
                         /*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ char                *GCPFileName,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_GridCreator

        $TYPE         PROCEDURE

        $INPUT        TLRow       : row coordinate of the top left corner of
                                    the AoI in which the registrator must act
                      TLCol       : column coordinate of the top left corner
                                    of the AoI in which the registrator must
                                    act
                      BRRow       : row coordinate of the bottom right corner
                                    of the AoI in which the registrator must
                                    act
                      BRCol       : column coordinate of the bottom right corner
                                    of the AoI in which the registrator must act
                      GCPFileName : name of the optional master GCP file

        $MODIFIED     The GCP grids are filled

        $OUTPUT       NONE

        $GLOBAL       IREGPV_GCP_mas_num_row
                      IREGPV_GCP_mas_num_col
                      IREGIV_ima_num

        $RET_STATUS   ERRSID_IREG_incons_corn
                      ERRSID_IREG_image_number_out
                      ERRSID_IREG_grid_number_out
                      ERRSID_IREG_GCP_num_invalid
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure creates the grids of GCP on the images
                      opened in the tool of co-registration

        $WARNING      THE INIT PROCEDURE MUST BE EXECUTED BEFORE ALL THE
                      OTHER PROCEDURES OF IREG AND AFTER THE IMAGE ANNOTATIONS
                      READING PROCEDURE

        $PDL          - Checks the number of GCP in the rows and columns
                        direction
                      - Checks the number of images
                      - Evaluates the total number of GCPs
                      - Creates the GCP grid on the master image
                      - Allocates a grid to contain the geodetic coordinates
                        of the master GCPs grid
                      - Converts the GCP grid from master image ( row, col )
                        into ( lat, lon ) coordinates
                      - Loop over the slaves images
                            - Fill the slave GCP grid
                      - End loop

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_GridCreator
                        (/*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                BRRow,
                         /*IN    */ INTx4                BRCol,
                         /*IN    */ char                *GCPFileName,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_MasterGCP

        $TYPE         PROCEDURE

        $INPUT        TLRow : row coordinate of the top left corner of the
                              AoI in which the registrator must act
                      TLCol : column coordinate of the top left corner of the
                              AoI in which the registrator must act
                      BRRow : row coordinate of the bottom right corner of the
                              AoI in which the registrator must act
                      BRCol : column coordinate of the bottom right corner of the
                              AoI in which the registrator must act

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[0] : the structure with the
                                             image annotations that
                                             must be filled

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_grid_number_out
                      ERRSID_IREG_GCP_num_invalid

        $DESCRIPTION  This procedure evaluates the grid of GCPs coordinates
                      for the image co-registration on the Master image
                      reference system

        $WARNING      NONE

        $PDL          - Evaluates the deltas between the GCPs
                      - Loop over the grid rows
                            - Loop over the grid columns
                                  - Evaluates the rows and columns row columns
                                    coordinates of each GCP
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_MasterGCP
                        (/*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                BRRow,
                         /*IN    */ INTx4                BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_MasRowCol2LatLon

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       geo_grid    : grid corresponding to the master image one
                                    evaluated in geodetic coordinates

        $GLOBAL       IREGPV_gcp[0]        : the structure with the GCP info
                      IANNIV_ImageAnnot[0] : the structure with the image
                                             annotations that must be filled

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_grid_number_out
                      ERRSID_IREG_GCP_num_invalid

        $DESCRIPTION  This procedure evaluates the master grid into geodetic
                      coordinates

        $WARNING      THE MASTER GRID MUST BE CREATED BEFORE

        $PDL          - Checks the numbers ID of master image and grid
                      - Checks the number of GCPs
                      - Converts the master grid in row columns coordinates
                        into geodetc coordinates

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_MasRowCol2LatLon
                        (/*   OUT*/ MATHIT_LLH          *geo_grid,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SlaveGCP

        $TYPE         PROCEDURE

        $INPUT        imanum   : image number among the others of the tool
                      gridnum  : grid number among the others of the tool
                      geo_grid : grid of geodetic values

        $MODIFIED     The global structure with the GCPs info is filled

        $OUTPUT       NONE

        $GLOBAL       IREGPV_GCP_mas_num_row    : number of wanted GCP in the
                                                  row direction
                      IREGPV_GCP_mas_num_col    : number of wanted GCP in the
                                                  column direction
                      IREGPV_gcp[gridnum]       : the structure with the GCPs
                                                  info
                      IANNIV_ImageAnnot[imanum] : the structure with the image
                                                  annotations

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_grid_number_out

        $DESCRIPTION  This procedure fills the slave GCPs info structure

        $WARNING      NONE

        $PDL          - Checks the image number
                      - Evaluates the number of GCPs
                      - Loop over the master GCPs
                            - Converts the GCP geodetic coordinates into
                              image coordinates in the slave reference system
                            - If the point is internal to the image range
                                  - Puts the GCP flag to TRUE
                                  - Increments the counter of valid GCP in the
                                    image
                            - Endif
                      - End loop
                      - Fill the number of GCP in the GCP info structure

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_SlaveGCP
                        (/*IN    */ INTx4                imanum,
                         /*IN    */ INTx4                gridnum,
                         /*IN    */ MATHIT_LLH          *geo_grid,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CellExtraction

        $TYPE         PROCEDURE

        $INPUT        inp_io    : input file descriptor
                      centre    : centre coordinates of the cell to extract
                      NRowInp   : number of rows to extract
                      NColInp   : number of columns to extract
                      imanum    : image ID
                      filler    : value to fill the out of borders pixel of the
                                  image

        $MODIFIED     valid     : flag indicating if the GCP is valid or not
                                  through three possible values that it returns:
                                  - value: 0      the cell has a portion
                                                  external to the image
                                  - value: 1      the cell is all inside the
                                                  image
                                  - value: - 1    the image is all out of image
                                                  borders

        $OUTPUT       ImageCell : image cell

        $GLOBAL       IANNID_NIMAMAX            : maximum number of images that
                                                  can be treated in the SAR -
                                                  Toolbox
                      IANNIV_ImageAnnot[imanum] : structure with the <imanum>
                                                  images INFO

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_null_cell_dim
                      ERRSID_IREG_cell_dim_out
                      ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure extract an image cell from a specified
                      image file channel. If the cell is not all inside the
                      image borders, the outlayer part is filled with a <filler>
                      value

        $WARNING      NONE

        $PDL          - Checks the image ID
                      - Checks the number of image rows and columns
                      - Evaluates the number of columns elements in a row
                        considering two for the complex images
                      - Loop over the image cell rows
                            - Loop over the image cell columns
                                  - Fills the image element with the filler
                                    value
                            - End loop
                      - End loop
                      - Evaluates the starting and stopping row and column
                        indices of the image cell to extract
                      - If the block is outside the image
                            - The flag is set to invalid
                      - Else If the block is part inside part out of the image
                            - Resets the extreems of the cell
                            - Opens the read mode of the input file
                            - Reads the image block
                            - Closes the read mode of the input file
                            - Sets the flag to 0
                      - Else If the block is inside the image
                            - Resets the extreems of the cell
                            - Opens the read mode of the input file
                            - Reads the image block
                            - Closes the read mode of the input file
                            - Sets the flag to 1
                      - End

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_CellExtraction
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ MATHIT_RC            centre,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ INTx1                imanum,
                         /*IN    */ float                filler,
                         /*   OUT*/ INTx1               *valid,
                         /*   OUT*/ float              **ImageCell,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FillImaCell

        $TYPE         PROCEDURE

        $INPUT        NRowInp   : number of rows of the image cell
                      NColInp   : number of columns of the image cell
                      DataType  : data type of the image cell
                      filler    : value with which to fill the outer part of
                                  the image cell

        $MODIFIED     ImageCell : image cell

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure fills the image cell to give in output

        $WARNING      NONE

        $PDL          - Evaluates the number of elements of the column
                      - Switch over the data type
                            - Loop over the cell rows
                                  - Loop over the columns of the row
                                        - Fills the cell element
                                  - End loop
                            - End loop
                      - End switch

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_FillImaCell
                        (/*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ float                filler,
                         /*IN OUT*/ void               **ImageCell,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_PointSubMatrix

        $TYPE         PROCEDURE

        $INPUT        DataType  : input data type
                      ImageCell : image block
                      NLines    : number of lines of the image block to copy
                      StartR    : starting row to point
                      StartC    : starting column to point

        $MODIFIED     NONE

        $OUTPUT       p         : array of pointers to the image block rows

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure makes an array of pointers to point to
                      the first elements of the rows of the sub matrix starting
                      in <StartR>, <StartC> element

        $WARNING      NONE

        $PDL          - Switch over data types
                            - Loop over the rows of the sub matrix
                                  - Point the array of pointers element to the
                                    first element of the sub matrix row
                            - End loop
                      - End switch

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_PointSubMatrix
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ void               **ImageCell,
                         /*IN    */ INTx4                NLines,
                         /*IN    */ INTx4                StartR,
                         /*IN    */ INTx4                StartC,
                         /*   OUT*/ void               **p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_RotAngleEval

        $TYPE         PROCEDURE

        $INPUT        mas_imanum : number identifing the master image
                      sla_imanum : number identifing the slave image

        $MODIFIED     NONE

        $OUTPUT       alpha      : angle of rotation between the two images
                                   (master and slave) in radians

        $GLOBAL       IANNIV_ImageAnnot : structure with the information about
                                          the images

        $RET_STATUS   ERRSID_IREG_image_number_out

        $DESCRIPTION  This procedure evaluates the angle between the orbits of
                      the two images

        $WARNING      THE STRUCTURES IANNIV_ImageAnnot OF THE TWO IMAGES MUST
                      BE FILLED BEFORE CALLING THIS PROCEDURE BY
                      IANNIP_GETP_ImageAnnotation

        $PDL 

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_RotAngleEval
                        (/*IN    */ INTx1                mas_imanum,
                         /*IN    */ INTx1                sla_imanum,
                         /*   OUT*/ double              *alpha,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SlaveCorners

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID number identifing the slave image
                      points_rc  : array with the row, col coordinates of the
                                   top left, top rigth and bottom left corners
                                   in the slave reference system

        $MODIFIED     NONE

        $OUTPUT       points_llh : array with the geodetic coordinates of the
                                   top left, top rigth and bottom left corners

        $GLOBAL       IANNIV_ImageAnnot : the structure with the global image
                                          info

        $RET_STATUS   ERRSID_IREG_image_number_out

        $DESCRIPTION  This procedure converts the top left, top rigth and
                      bottom left slave image corners from row, col coordinates
                      to geodetic coordinates

        $WARNING      NONE

        $PDL          - Initializes the coordinates conversions for the slave
                        image
                      - Fills the row, col coordinates of the top left corner
                      - Converts them into geodetic ones
                      - Fills the row, col coordinates of the top rigth corner
                      - Converts them into geodetic ones
                      - Fills the row, col coordinates of the bottom left corner
                      - Converts them into geodetic ones

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_SlaveCorners
                        (/*IN    */ INTx1                imanum,
                         /*IN    */ MATHIT_RC           *points_rc,
                         /*   OUT*/ MATHIT_LLH          *points_llh,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SlaveToMaster

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID number identifing the master image
                      points_llh : array with the geodetic coordinates of the
                                   top left, top rigth and bottom left corner

        $MODIFIED     NONE

        $OUTPUT       points_rc  : array with the row, col coordinates of the
                                   top left, top rigth and bottom left corners
                                   in the master reference system

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_image_number_out

        $DESCRIPTION  This procedure converts the slave corners in geodetic
                      coordinates into row, col master reference system

        $WARNING      NONE

        $PDL          - Initializes the maser coordinates conversions
                      - Converts the top left corner
                      - Converts the top rigth corner
                      - Converts the bottom left corner

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_SlaveToMaster
                        (/*IN    */ INTx1                imanum,
                         /*IN    */ MATHIT_LLH          *points_llh,
                         /*   OUT*/ MATHIT_RC           *points_rc,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_AngleEval

        $TYPE         PROCEDURE

        $INPUT        vers1     : versor of one of the axis
                      point1    : coordinates in row, col of the first corner
                      point2    : coordinates in row, col of the second corner

        $MODIFIED     NONE

        $OUTPUT       angle_rad : angle between the axes in radians

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the angle between two vectors
                      definited the first through its versor, the other through
                      two points of the vector describing the direction

        $WARNING      NONE

        $PDL          - Evaluates the versor to the second direction
                      - Makes the scalar product of the two versor of the two
                        directions
                      - Evaluates the angle between the two
                      - Makes a 3D vector with x and y on the (row, col) plane
                        (x = col, y = row, z = 0) for the first versor
                      - Makes the analogous for the second versor
                      - Makes the cross product of the two vectors
                      - If the z component of the cross product vector is lesser
                        than zero, changes the angle sign

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_AngleEval
                        (/*IN    */ MATHIT_RC            vers1,
                         /*IN    */ MATHIT_RC            point1,
                         /*IN    */ MATHIT_RC            point2,
                         /*   OUT*/ double              *angle_rad,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CellExtractor

        $TYPE         PROCEDURE

        $INPUT        inp_io       : input file descriptor
                      centre       : centre coordinates of the cell to
                                     extract
                      NRowInp      : number of rows to extract
                      NColInp      : number of columns to extract
                      imanum       : image ID
                      filler       : value to fill the out of borders pixel
                                     of the image
                      RotAngle_rad : angle of rotation (in radians) of which
                                     the cell must be rotated

        $MODIFIED     NONE

        $OUTPUT       valid     : flag indicating if the GCP is valid or not
                                  through three possible values that it returns:
                                  - value: 0      the cell has a portion
                                                  external to the image
                                  - value: 1      the cell is all inside the
                                                  image
                                  - value: - 1    the image is all out of image
                                                  borders

                      ImageCell : output image cell

        $GLOBAL       IANNID_NIMAMAX            : maximum number of images that
                                                  can be treated in the SAR -
                                                  Toolbox
                      IANNIV_ImageAnnot[imanum] : structure with the <imanum>
                                                  images INFO

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_null_cell_dim
                      ERRSID_IREG_cell_dim_out
                      ERRSID_IREG_err_mem_alloc
                      ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure extract an image cell from the file
                      described by the <inp_io> descriptor, and, if necessary,
                      rotates it by the indicated angle in anticlockwise
                      direction if positive

        $WARNING      NONE

        $PDL          - Checks the image ID number
                      - Checks the number of rows and columns of the cell
                      - Sets the parameters indicating the input image data
                        type and size
                      - If the angle of rotation is almost null
                            - Allocates a temporary matrix
                            - Extracts a cell of the wanted dimensions centered
                              in the centre coordinates and of the same type of
                              the input image
                            - Evaluates the number of row elements (
                              considering two if the image is complex )
                      - Else If
                            - Evaluates the half diagonal of the cell
                            - Evaluates the number of elements of the cell
                              of dimensions equals to the diagonal
                            - Allocates the enlarged cell and the grid for the
                              interpolation
                            - Fills the rotation grid with the coordinates of
                              the points of the rotated cell
                            - Extracts the enlarged cell of the same data type
                              of the input one
                            - Makes a bilinear interpolation of the cell
                      - End If
                      - Deallocates the allocated memories

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_CellExtractor
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ MATHIT_RC            centre,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ INTx1                imanum,
                         /*IN    */ float                filler,
                         /*IN    */ double               RotAngle_rad,
                         /*   OUT*/ INTx1               *valid,
                         /*   OUT*/ float              **ImageCell,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ElemSizeEval

        $TYPE         PROCEDURE

        $INPUT        DataType  : input data type

        $MODIFIED     NONE

        $OUTPUT       elem_size : size in bytes of a row element

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure fills two variables indicating the
                      element data size in bytes of an image

        $WARNING      NONE

        $PDL          - Evaluates the number of elements (time 2 if the
                        input image is complex)
                      - Switches over the image data type
                            - Sets the element size in bytes
                      - End switch

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_ElemSizeEval
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ size_t              *elem_size,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_EnlCellAndGridAlloc

        $TYPE         PROCEDURE

        $INPUT        NElem        : number of rows and columns of the cell
                      elem_size    : size in bytes of the image element
                      NGridRow     : number of rows of points for the grid
                      NGridCol     : number of columns of points for the grid

        $MODIFIED     NONE

        $OUTPUT       ImageCell    : image cell to allocate
                      rot_grid     : grid to allocate

        $GLOBAL       MATHIT_RC : the row, columns type

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure allocates the image cell to extract and
                      the grid of points for the interpolation

        $WARNING      NONE

        $PDL          - Allocates the array of pointers for the image cell
                      - Loop over the rows of the image cell
                            - Allocates the row of elements
                      - End Loop
                      - Loop over the rows of the grid points
                            - Allocates the row of grid points
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_EnlCellAndGridAlloc
                        (/*IN    */ UINTx4               NElem,
                         /*IN    */ size_t               elem_size,
                         /*IN    */ UINTx4               NGridRow,
                         /*IN    */ UINTx4               NGridCol,
                         /*   OUT*/ float             ***ImageCell,
                         /*   OUT*/ MATHIT_RC_float   ***rot_grid,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FillRotGrid

        $TYPE         PROCEDURE

        $INPUT        NRowInp   : number of rows of points to fill
                      NColInp   : number of columns of points to fill
                      Angle_rad : angle of rotation

        $MODIFIED     NONE

        $OUTPUT       Grid      : grid of points to be used for the
                                  interpolation

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the grid with the value of the pixels
                      coordinates rotated by the angle <Angle_rad>

        $WARNING      NONE

        $PDL          - Loop over the grid rows
                            - Evaluates the not rotated row coordinate
                            - Evaluates the part of the rotated row coordinate
                              depending by the not rotated row coordinate
                            - Evaluates the part of the rotated column
                              coordinate depending by the not rotated row
                              coordinate
                            - Loop over the grid columns
                                  - Evaluates the not rotated column coordinate
                                  - Sums to the rotated row coordinate the part
                                    depending by the not rotated column
                                    coordinate
                                  - Sums to the rotated column coordinate the
                                    part depending by the not rotated column
                                    coordinate
                            - End Loop
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_FillRotGrid
                        (/*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ double               Angle_rad,
                         /*IN OUT*/ MATHIT_RC_float    **Grid,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ShiftEvaluation

        $TYPE         PROCEDURE

        $INPUT        master_fft : FFT of the absolute value of the master cell
                                   to correlate
                      SlaveCell  : slave image cell to correlate
                      DataType   : flag indicating the image data type

        $MODIFIED     NONE

        $OUTPUT       Shift
                      QualityFlag : quality flag value indicating the goodness
                                    of the correlation

        $GLOBAL       IREGPV_coarse_cell_dim_row : dimension in the row direction of
                                            the image cell
                      IREGPV_coarse_cell_dim_col : dimension in the columns direction
                                            of the image cell
                      IREGPV_int_fact_row : interpolation factor in the row
                                            direction
                      IREGPV_int_fact_col : interpolation factor in the column
                                            direction

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the shift in the row and column
                      directions between two image cells using the maximum peak
                      of the cross-correlation matrix between them

        $WARNING      NONE

        $PDL          - Evaluates the dimensions of the temporary arrays
                      - Fills the array of the slave cell with the rows of
                        the slave matrix stored sequentially
                      - Evaluates the complex array with the absolute value of
                        the slave one in the real part
                      - Makes the direct FFT of the modulus of the slave cell
                      - Makes the conjugate of the FFT
                      - Makes the cross correlation matrix as the product of
                        the master and slave cells
                      - Interpolates the cross correlaction matrix by the
                        wanted interpolation factors vis zero-padding
                      - Makes the inverse FFT of the interpolated cross 
                        correlation matrix
                      - Finds the index of the maximum value in the absolute
                        value interpolated cross correlation matrix
                      - Evaluates the rescaled shifts values

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_ShiftEvaluation
                        (/*IN    */ MATHIT_array         master_fft,
                         /*IN    */ void               **SlaveCell,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_RC           *Shift,
                         /*   OUT*/ float               *QualityFlag,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FillArray

        $TYPE         PROCEDURE

        $INPUT        Matrix   : input matrix to convert into its modulus
                      DataType : data type flag

        $MODIFIED     NONE

        $OUTPUT       arrout   : array to fill with the elements of the input
                                 matrix stored sequentially by rows

        $GLOBAL       IREGPV_coarse_cell_dim_row : the matrix row dimension
                      IREGPV_coarse_cell_dim_col : the matrix col dimension

        $RET_STATUS   ERRSID_IREG_data_type_not_allow 

        $DESCRIPTION  This procedure fills a complex array with the values of
                      the input matrix stored sequentially

        $WARNING      THE ARRAY MUST BE ALLOCATED BEFORE THE CALLING TO THE
                      PROCEDURE

        $PDL          - Switch over the various data types
                            - Loop over the matrix rows
                                  - Loop over the matrix columns
                                        - Fills the array with the matrix cell
                                  - End Loop
                            - End Loop
                      - End Switch

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_FillArray
                        (/*IN    */ void               **Matrix,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ZeroPadding

        $TYPE         PROCEDURE

        $INPUT        MatrInp : input matrix to enlarge
                      NRowInp : number of input rows
                      NColInp : number of input columns
                      NRowOut : number of wanted output rows
                      NColOut : number of wanted output columns

        $MODIFIED     NONE

        $OUTPUT       MatrOut : output zero padded matrix

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_no_enlarge_zp

        $DESCRIPTION  This procedure makes the zero padding of the input matrix
                      described by a complex array that stores sequentially
                      the matrix

        $WARNING      NONE

        $PDL          - Checks the number of output rows and columns
                      - Evaluate the correction deltas for the arrays indices
                        for odd cell dimensions
                      - Evaluates the half dimensions of the input matrix
                      - Copies the half top left of the input matrix into the
                        output one
                      - The same for the top rigth part
                      - The same for the bottom left part
                      - The same for the bottom rigth part

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_ZeroPadding
                        (/*IN    */ MATHIT_array         MatrInp,
                         /*IN    */ INTx4                NRowInp,
                         /*IN    */ INTx4                NColInp,
                         /*IN    */ INTx4                NRowOut,
                         /*IN    */ INTx4                NColOut,
                         /*   OUT*/ MATHIT_array        *MatrOut,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CrossCorrInterp

        $TYPE         PROCEDURE

        $INPUT        cross_corr : cross correlation matrix
                      NRowInp    : number of rows of the cross correlation
                                   matrix
                      NColInp    : number of columns of the cross correlation
                                   matrix
                      NRowOut    : number of rows of the output interpolated
                                   matrix
                      NColOut    : number of columns of the output interpolated
                                   matrix

        $MODIFIED     NONE

        $OUTPUT       int_corr   : interpolated matrix

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the interpolated cross
                      correlation matrix via zero padding and makes its inverse
                      FFT

        $WARNING      NONE

        $PDL          - Evaluates the number of output elements
                      - Makes matrix zero padding
                      - Evaluates the inverse FFT of the interpolated matrix
                      - Evaluates its modulus

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_CrossCorrInterp
                        (/*IN    */ MATHIT_array         cross_corr,
                         /*IN    */ INTx4                NRowInp,
                         /*IN    */ INTx4                NColInp,
                         /*IN    */ INTx4                NRowOut,
                         /*IN    */ INTx4                NColOut,
                         /*   OUT*/ MATHIT_array        *int_corr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_RCRotate

        $TYPE         PROCEDURE

        $INPUT        Angle : the rotation angle in radians

        $MODIFIED     RC    : vector in row, col coordinates rotated

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure rotate the vector in row, col coordinates
                      by the rotation angle <Angle>

        $WARNING      NONE

        $PDL          - Rotates the row coordinate
                      - Rotates the column coordinate

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_RCRotate
                        (/*IN    */ double               Angle,
                         /*IN OUT*/ MATHIT_RC           *RC,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_StabilityTest

        $TYPE         PROCEDURE

        $INPUT        sla_io     : descriptor of the slave file
                      sla_imanum : slave ID number
                      slave      : matrix to fill with the slave image cell
                      DataType   : slave image data type
                      RotAngle   : rotation angle in radians
                      centre     : coordinates of the centre of the slave cell
                                   to extract
                      master_fft : FFT of the absolute value of the master cell
                                   to correlate with the slave

        $MODIFIED     NONE

        $OUTPUT       ok_test    : flag indicating if the test has been passed
                                   ( TRUE ) or not

        $GLOBAL       IREGPV_coarse_cell_dim_row     : cell dimensions
                      IREGPV_coarse_cell_dim_col     : cell dimensions
                      IREGPD_max_coarse_shift : maximum allowable shift

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure makes a test on the evaluated shift
                      coordinates between master and slave cells of the two
                      image passed

        $WARNING      NONE

        $PDL          - Zeroes the slave cell matrix
                      - Extracts the slave cell
                      - Sets the test flag to FALSE
                      - If the cell is all inside the image
                            - Evaluates the shifts
                            - Compensate the rotation
                               - If the absolute values of the shifts in the two
                              directions are lesser then the maximum allowable
                              value
                                  - Sets the test flag to TRUE
                            - End If
                      - End If

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_StabilityTest
                        (/*IN    */ GIOSIT_io           *sla_io,
                         /*IN    */ INTx1                sla_imanum,
                         /*IN    */ float              **slave,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ double               RotAngle,
                         /*IN    */ MATHIT_RC            centre,
                         /*IN    */ MATHIT_array         master_fft,
                         /*   OUT*/ LDEFIT_boolean      *ok_test,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FindMaximum

        $TYPE         PROCEDURE

        $INPUT        arr_inp : input array

        $MODIFIED     NONE

        $OUTPUT       index   : sequential index where ther's the array maximum
                                value in modulus
                      max_value : maximum absolute value of the array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_no_complex_out

        $DESCRIPTION  This procedure finds the index relative to the maximum
                      array value in modulus

        $WARNING      NONE

        $PDL          - Checks the type of the input array
                      - Loop over the elements of the array
                            - Evaluates the modulus of the complex element
                            - IF the array value is greather then the reference
                              maximum value set
                                  - Resets the reference maximum value
                                  - Fills the index
                            - End IF
                      - End Loop
                      - Sets the maximum value

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_FindMaximum
                        (/*IN    */ MATHIT_array         arr_inp,
                         /*   OUT*/ INTx4               *index,
                         /*   OUT*/ float               *max_value,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CoarseRegistrator

        $TYPE         PROCEDURE

        $INPUT        inp_io : array of descriptors of the opened files

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGIV_ima_num       : number of images opened
                      IREGPV_coarse_cell_dim_row  : cells dimension in the row
                                             direction
                      IREGPV_coarse_cell_dim_col  : cells dimension in the column
                                             direction
                      IREGPV_gcp[<imanum>] : array of structure with the GCP(s)
                                             INFO

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_err_mem_alloc
                      
        $DESCRIPTION  This procedure is the driver of the GCP(s) coarse
                      registration that evaluates the shifts between the GCP(s)
                      in the master image and each of the slaves using the image
                      geometry and the peak of the cross correlation matrix.
 
        $WARNING      NONE

        $PDL          - Checks the number of images opened
                      - Allocates the array for the rotation angle
                      - Allocates the necessary memories for the master and
                        slave cells matrix storage
                      - Evaluates the total number of elements of the cells
                      - Allocates the arrays
                      - Loop over the opened slaves images
                            - Evaluates the rotation angle between the master
                              and the current slave image
                      - End Loop
                      - Evaluates the number of total GCPs
                      - Sets the image data type
                      - Loop over the GCP(s)
                            - Extracts the master cell
                            - If the cell is all inside the master image
                                  - Sets the validity flag in the descriptor
                                    of the master GCP(s) TRUE for the current
                                    GCP
                                  - Evaluates the FFT of the absolute value
                                    of the master cell
                                  - Loop over the slave(s) image(s)
                                        - If the validity flag of the GCP in
                                          the slave is TRUE
                                              - Extracts the slave cell at the
                                                given centre coordinates
                                              - If the cell is all inside
                                                the slave image
                                                    - Evaluates the shifts
                                                      in row and col
                                                      directions between the
                                                      two cells
                                                    - Rotates the shifts for
                                                      the rotation angle to
                                                      compensate the cell
                                                      rotation
                                                    - Updates the centre
                                                      coordinates by the
                                                      compensated shifts
                                                    - Sets the quality
                                                      flag
                                                    - Checks the goodness
                                                      of the GCP with a
                                                      stability test
                                                    - If the test is not
                                                      passed
                                                          - Sets in the
                                                            slave GCP(s)
                                                            INFO structure
                                                            the validity
                                                            flag to FALSE
                                                    - Else
                                                          - Sets in the
                                                            slave GCP(s)
                                                            INFO structure
                                                            the validity
                                                            flag to TRUE
                                                    - End If
                                              - Else
                                                    - Sets in the slave GCP(s)
                                                      INFO structure the
                                                      validity flag to FALSE
                                              - End If
                                        - End If
                                  - End Loop
                            - Else
                                  - Sets in the master GCP(s) INFO structure
                                    the validity flag to FALSE
                            - End If
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_CoarseRegistrator
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SetDataType

        $TYPE         PROCEDURE

        $INPUT        inp_io   : descriptor of the image file

        $MODIFIED     NONE

        $OUTPUT       DataType : image data type

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure sets the image data type according to the
                      image file descriptor

        $WARNING      NONE

        $PDL          - Switch over the sample format flag
                            - Switch over the sample per pixel flag or bits per
                              sample flag
                            - Sets the data type
                      - End Switch

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_SetDataType
                        (/*IN    */ GIOSIT_io            inp_io,
                         /*   OUT*/ LDEFIT_data_type    *DataType,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ModulEval

        $TYPE         PROCEDURE

        $INPUT        ImaCell  : input image cell
                      NRowInp  : number of rows of the image cell
                      NColInp  : number of columns of the image cell
                      DataType : data type of the input image

        $MODIFIED     NONE

        $OUTPUT       ImaModul : array of complex type with the real part filled
                                 with the image cell modul

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure fills a complex array with the modulus of
                      the input image cell sequentially stored

        $WARNING      NONE

        $PDL          - Evaluates the number of elements of the array
                      - Allocates the arrays for the real and imaginary part
                      - Zeros the imaginary array
                      - Fills an array with the image
                      - Evaluates the image modulus
                      - Fills with the modulus the output array
                      - Frees all the allocated arrays

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_ModulEval
                        (/*IN    */ void               **ImaCell,
                         /*IN    */ INTx4                NRowInp,
                         /*IN    */ INTx4                NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *ImaModul,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FFTAbsImaEval

        $TYPE         PROCEDURE

        $INPUT        ImaCell  : input image cell
                      NRowInp  : number of image cell rows
                      NColInp  : number of image cell columns
                      DataType : image data type

        $MODIFIED     NONE

        $OUTPUT       ImaFFT   : array with the absolute image cell fft 

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the fft of the absolute value
                      of the image cell passed in input

        $WARNING      NONE

        $PDL          - Evaluates the image modulus
                      - Evaluates the image direct FFT

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_FFTAbsImaEval
                        (/*IN    */ void               **ImaCell,
                         /*IN    */ INTx4                NRowInp,
                         /*IN    */ INTx4                NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_array        *ImaFFT,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ArrayModulEval

        $TYPE         PROCEDURE

        $INPUT        NElements : number of elements of the input array

        $MODIFIED     arr_inp   : array with the matrix to transform

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the modulus of a complex array
                      and gives it in output

        $WARNING      NONE

        $PDL          - Allocates the real and the imaginary arrays
                      - Zeroes the imaginary array
                      - Evaluates the modulus of the array
                      - Fills the complex array with the array modulus
                      - Deallocates the real and imaginary arrays

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_ArrayModulEval
                        (/*IN    */ INTx4                NElements,
                         /*IN OUT*/ MATHIT_array        *arr_inp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_Shifts

        $TYPE         PROCEDURE

        $INPUT        matrix      : input matrix to which the maximum value and
                                    the corresponding index must be evaluated
                      NRow        : number of rows of the input matrix
                      NCol        : number of columns of the input matrix
                      fact_row    : interpolation factor in the row direction
                      fact_col    : interpolation factor in the column direction

        $MODIFIED     NONE

        $OUTPUT       Shift       : shifts in the row and columns directions
                      QualityFlag : quality flag

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the shifts in the rows and
                      columns directions and evaluates the quality flag

        $WARNING      NONE

        $PDL          - Finds the maximum value of the cross correlation
                        matrix and the index of the matrix corresponding
                        to the peak
                      - Evaluates the rows and columns indices from the
                        sequential one
                      - Checks the correctness of the shift range
                      - Evaluates the matrix mean value
                      - Evaluates the quality indicator as the ratio between
                        the peak value and the background

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_Shifts
                        (/*IN    */ MATHIT_array         matrix,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ float                fact_row,
                         /*IN    */ float                fact_col,
                         /*   OUT*/ MATHIT_RC           *Shift,
                         /*   OUT*/ float               *QualityFlag,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ArraysAllocation

        $TYPE         PROCEDURE

        $INPUT        inp_io     : input file descriptor array
                      mas_imanum : master image ID number
                      NRowInp    : master and slave number of rows
                      NColInp    : master and slave number of columns

        $MODIFIED     RotAngle   : pointer to the array that will store the
                                   rotation angles
                      master     : pointer to the master matrix that will
                                   store the master image cell
                      slave      : pointer to the slave matrix that will
                                   store the slave image cell

        $OUTPUT       NONE

        $GLOBAL       IREGIV_ima_num      : the number of opened images

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure allocates the rotation angles array and
                      the master and slave cells

        $WARNING      NONE

        $PDL          - Allocates the rotation angles array
                      - Allocates the master image cell
                      - Allocates the slave image cell

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_ArraysAllocation
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ INTx1                mas_imanum,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN OUT*/ double             **RotAngle,
                         /*IN OUT*/ float             ***master,
                         /*IN OUT*/ float             ***slave,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SmoothIma2float

        $TYPE         PROCEDURE

        $INPUT        InpIma : input image cell
                      NRow   : number of rows of the input image cell
                      NCol   : number of columns of the input image cell
                      Width  : width of the moving box

        $MODIFIED     NONE

        $OUTPUT       OutIma : output image cell

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the smooth as a blocking
                      average of an image cell of type 2 float

        $WARNING      NONE

        $PDL          - Evaluates the value of the scaling factor for the
                        average
                      - Loop over the image rows with step equals to the moving
                        box width
                            - Loop over the image columns with step equals to
                              the moving box width
                                  - Zeroes the output image elements
                                  - Loop over the rows of the moving box
                                        - Points to the top left pixel of the
                                          image in the current box
                                        - Loop over the columns of the box
                                              - Fills the output image elements
                                                with the sum of them in the box
                                        - End Loop
                                  - End Loop
                                  - Rescales the sum of the box with the factor
                                    to give the average value
                                  - Increments the output columns counter
                            - End Loop
                            - Increments the output rows counter
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_SmoothIma2float
                        (/*IN    */ float             **InpIma,
                         /*IN    */ UINTx4              NRow,
                         /*IN    */ UINTx4              NCol,
                         /*IN    */ UINTx4              Width,
                         /*   OUT*/ float             **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_SmoothImafloat

        $TYPE         PROCEDURE

        $INPUT        InpIma : input image cell
                      NRow   : number of rows of the input image cell
                      NCol   : number of columns of the input image cell
                      Width  : width of the moving box

        $MODIFIED     NONE

        $OUTPUT       OutIma : output image cell

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the smooth as a blocking
                      average of an image cell of type float

        $WARNING      NONE

        $PDL          - Evaluates the value of the scaling factor for the
                        average
                      - Loop over the image rows with step equals to the moving
                        box width
                            - Loop over the image columns with step equals to
                              the moving box width
                                  - Zeroes the output image elements
                                  - Loop over the rows of the moving box
                                        - Points to the top left pixel of the
                                          image in the current box
                                        - Loop over the columns of the box
                                              - Fills the output image elements
                                                with the sum of them in the box
                                        - End Loop
                                  - End Loop
                                  - Rescales the sum of the box with the factor
                                    to give the average value
                                  - Increments the output columns counter
                            - End Loop
                            - Increments the output rows counter
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_SmoothImafloat
                        (/*IN    */ float             **InpIma,
                         /*IN    */ UINTx4              NRow,
                         /*IN    */ UINTx4              NCol,
                         /*IN    */ UINTx4              Width,
                         /*   OUT*/ float             **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPF_GCPE_Coherfloat

        $TYPE         FUNCTION

        $INPUT        x    : the array of shift values

        $MODIFIED     NONE

        $OUTPUT       cohe : the value of 1 minus the coherence for the given
                             two image cells

        $GLOBAL       IREGPV_coher : the structure with the matrix and variables
                                     used in the coherence evaluation

        $RET_STATUS   NONE

        $DESCRIPTION  This function evaluates the quantity 1 minus the averaged
                      coherence on two master and slave cells with the second
                      one shifted by two shift values

        $WARNING      NONE

        $PDL          - Shifts the slave cell
                      - Resets the slave cell eliminating the borders
                      - Evaluates the covariance matrix between master and
                        slave cell
                      - Evaluates the variance of the master cell
                      - Evaluates the variance of the slave cell
                      - Smooths the covariance
                      - Evaluates the coherence numerator
                      - Smooths the master variance
                      - Smooths the slave variance
                      - Evaluates the coherence denominator
                      - Evaluates the output matrix dimensions
                      - Evaluates the averaged value of the coherence
                      - Returns 1 minus the coherence

   $EH
   ========================================================================== */
   extern double IREGPF_GCPE_Coherfloat
                        (/*IN    */ double              *x);

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPF_GCPE_Coher2float

        $TYPE         FUNCTION

        $INPUT        x    : the array of shift values

        $MODIFIED     NONE

        $OUTPUT       cohe : the value of 1 minus the coherence for the given
                             two image cells

        $GLOBAL       IREGPV_coher : the structure with the matrix and variables
                                     used in the coherence evaluation

        $RET_STATUS   NONE

        $DESCRIPTION  This function evaluates the quantity 1 minus the averaged
                      coherence on two master and slave cells with the second
                      one shifted by two shift values

        $WARNING      NONE

        $PDL          - Shifts the slave cell
                      - Resets the slave cell eliminating the borders
                      - Evaluates the covariance matrix between master and
                        slave cell
                      - Evaluates the variance of the master cell
                      - Evaluates the variance of the slave cell
                      - Smooths the covariance
                      - Evaluates the coherence numerator
                      - Smooths the master variance
                      - Smooths the slave variance
                      - Evaluates the coherence denominator
                      - Evaluates the output matrix dimensions
                      - Evaluates the averaged value of the coherence
                      - Returns 1 minus the coherence value

   $EH
   ========================================================================== */
   extern double IREGPF_GCPE_Coher2float
                        (/*IN    */ double              *x);

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_InitFineReg

        $TYPE         PROCEDURE

        $INPUT        DataType : data type of the images

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_coher             : structure for the coherence
                                                 maximization
                      IREGPV_fine_cell_dim_row : cell dimension in the row
                                                 direction
                      IREGPV_fine_cell_dim_col : cell dimension in the column
                                                 direction

        $RET_STATUS   ERRSID_IREG_low_cell_dim
                      ERRSID_IREG_data_type_not_allow
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure initializes the structure that contains
                      the matrices and variables for the GCP(s) fine
                      registration

        $WARNING      THE MASTER AND SLAVE CELLS MUST BE OD float TYPE AND
                      WITH DIMENSIONS DEFINED BY THAT FOR THE FINE REGISTRATION
                      (<IREGPV_fine_cell_dim_row> and
                      <IREGPV_fine_cell_dim_col>)

        $PDL          - Checks the cells dimensions
                      - Switch over the data type
                            - Sets the data type structure element
                      - End Switch
                      - Sets the initial number of rows and columns
                      - Sets the middle master and slave dimensions
                      - Evaluates the final dimensions
                      - Allocates the initial master matrix
                      - Allocates the initial slave matrix
                      - Allocates the middle master matrix array
                      - Allocates the middle slave matrix array
                      - Allocates the covariance matrix
                      - Allocates the master variance matrix
                      - Allocates the slave variance matrix
                      - Allocates the smoothed covariance matrix
                      - Allocates the smoothed master variance matrix
                      - Allocates the smoothed slave variance matrix
                      - Allocates the numerator matrix
                      - Allocates the denominator matrix

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_InitFineReg
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CloseFineReg

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_coher : the structure containing the fine
                                     registration INFO

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure closes the fine registration process
                      freeing all the allocated memories

        $WARNING      NONE

        $PDL          - Evaluates the rows and columns dimensions of the final
                        matrices
                      - Frees the middle master and slave arrays of pointers
                      - Frees the covariance matrix
                      - Frees the master and slave variance matrices
                      - Frees the smoothed covariance matrix
                      - Frees the smoothed master and slave variances
                      - Frees the numerator and denominator matrices

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_CloseFineReg
                        (/*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_CoherMaxim

        $TYPE         PROCEDURE

        $INPUT        master     : master image cell
                      slave      : slave image cell
                      DataType   : data size

        $MODIFIED     NONE

        $OUTPUT       eval_shift : shifts values that maximize the coherence
                                   between the two cells

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure evaluates the shifts values in the rows
                      and columns directions that maximize the coherence
                      between the two images cells

        $WARNING      THE INIIALIZATION PROCEDURE MUST BE CALLED YET WHEN THIS
                      ONE IS CALLED

        $PDL          - Points the initial master structure pointer to the
                        master matrix pointer
                      - Points the initial slave structure pointer to the
                        slave matrix pointer
                      - Fills the initial shifts values ( one more then the
                        problems dimensions )
                      - Fills with these values the ancillary matrix <p>
                      - Fills the ancillary array <y> with the values of the
                        function to maximize in the initial shifts values
                      - Evaluates the shifts that maximize the function of
                        coherence

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_CoherMaxim
                        (/*IN    */ float              **master,
                         /*IN    */ float              **slave,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ MATHIT_RC           *eval_shift,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_FineRegistrator

        $TYPE         PROCEDURE

        $INPUT        inp_io : array with the descriptors of the images

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGIV_ima_num           : number of images
                      IREGPV_gcp               : structure containing the GCP
                                                 INFO
                      IREGPV_fine_cell_dim_row : cell dimension in the rows
                                                 direction
                      IREGPV_fine_cell_dim_col : cell dimension in the columns
                                                 direction

        $RET_STATUS   ERRSID_IREG_ima_num_inv

        $DESCRIPTION  This procedure is the driver of the GCP(s) fine
                      registration that evaluates the shifts between the GCP(s)
                      in the master image and each of the slaves using the
                      coherence maximization

        $WARNING      NONE

        $PDL          - Checks the number of images opened
                      - Allocates the array for the rotation angle
                      - Allocates the necessary memories for the master and
                        slave cells matrix storage
                      - If the image is a real one
                            - Loop over the opened slaves images
                                  - Evaluates the rotation angle between the
                                    master and the current slave image
                            - End Loop
                      - Else
                            - Sets the rotation angle to zero
                      - End If
                      - Evaluates the number of total GCPs
                      - Sets the image data type
                      - Loop over the GCP(s)
                            - If the validity flag of the master GCP is TRUE
                                  - Extracts the master cell
                                  - Loop over the slave(s) image(s)
                                        - If the validity flag of the GCP in
                                          the slave is TRUE
                                              - Extracts the slave cell at the
                                                given centre coordinates
                                              - If the cell is all inside
                                                the slave image
                                                    - Evaluates the shifts
                                                      in row and col
                                                      directions between the
                                                      two cells
                                                    - Rotates the shifts for
                                                      the rotation angle to
                                                      compensate the cell
                                                      rotation
                                                    - Updates the centre
                                                      coordinates by the
                                                      compensated shifts
                                              - Else
                                                    - Sets in the slave GCP(s)
                                                      INFO structure the
                                                      validity flag to FALSE
                                              - End If
                                        - End If
                                  - End Loop
                            - End If
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_FineRegistrator
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_GCPE_ReadGCPs

        $TYPE         PROCEDURE

        $INPUT        TLRow        : row coordinate of the top left corner of
                                     the AoI in which the registrator must act
                      TLCol        : column coordinate of the top left corner
                                     of the AoI in which the registrator must
                                     act
                      BRRow        : row coordinate of the bottom right corner
                                     of the AoI in which the registrator must
                                     act
                      BRCol        : column coordinate of the bottom right
                                     corner of the AoI in which the registrator
                                     must act
                      gcp_filename : GCP file name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_gcp   : GCP INFO structure

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure read the master GCPs from an external
                      file

        $WARNING      NONE

        $PDL          - Opens the input file
                      - Gets the first file line
                      - Reads the first element of the line
                      - Fills the structure
                      - Reads the second element
                      - Checks if the point is in the fixed AoI
                      - While of the other lines
                            - Gets the line
                            - Read the first element of the line
                            - Fills the structure
                            - Read the second element of the line
                      - End While
                      - Close the input file

   $EH
   ========================================================================== */
   extern void IREGPP_GCPE_ReadGCPs
                        (/*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                BRRow,
                         /*IN    */ INTx4                BRCol,
                         /*IN    */ char                *gcp_filename,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_NormMatrEval

        $TYPE         PROCEDURE

        $INPUT        coor     : array with the coordinates to use to fill the
                                 normal matrix
                      degree   : transformation degree
                      Ngcp     : number of valid GCPs

        $MODIFIED     A        : pointer to the allocated normal matrix
                                 of the transformation

        $OUTPUT       NONE

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         to evaluate
                      IREGPC_norm_func : array of functions that evaluate the
                                         normal matrix

        $RET_STATUS   ERRSID_IREG_warp_deg_not_allow
                      ERRSID_IREG_insuff_GCPs
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure creates and fills the normal matrix for
                      the warp evaluation

        $WARNING      NONE

        $PDL          - Switch over the degrees
                            - Sets the index for the function to call
                      - End Switch
                      - Checks the number of GCPs
                      - Allocates the normal matrix
                      - Zeroes the normal matrix
                      - Calls the procedure for that degree

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_NormMatrEval
                        (/*IN    */ MATHIT_RC           *coor,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ INTx4                Ngcp,
                         /*IN OUT*/ double             **A,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_OneDegMatrEval

        $TYPE         PROCEDURE

        $INPUT        coor     : coordinates with which to fill the normal
                                 matrix
                      Ngcp     : the number of valid GCPs

        $MODIFIED     NONE

        $OUTPUT       A        : normal matrix

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         to evaluate

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the normal matrix for the one degree
                      warp with the GCP(s) previously evaluated

        $WARNING      THE GCP(S) INFO STRUCTURES MUST BE CREATED, FILLED AND
                      THE GCP(S) CO-REGISTERED BEFORE CALLING THIS PROCEDURE

        $PDL          - Loop over the gcps
                            - Fills the normal matrix in all the current
                              row with the master coordinates
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_OneDegMatrEval
                        (/*IN    */ MATHIT_RC           *coor,
                         /*IN    */ INTx4                Ngcp,
                         /*   OUT*/ double             **A,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_OneHalfDegMatrEval

        $TYPE         PROCEDURE

        $INPUT        coor     : coordinates with which to fill the normal
                                 matrix
                      Ngcp     : the number of valid GCPs

        $MODIFIED     NONE

        $OUTPUT       A        : normal matrix

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         to evaluate

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the normal matrix for the one and
                      half degree with the GCP(s) previously evaluated

        $WARNING      THE GCP(S) INFO STRUCTURES MUST BE CREATED, FILLED AND
                      THE GCP(S) CO-REGISTERED BEFORE CALLING THIS PROCEDURE

        $PDL          - Loop over the GCP(s)
                            - Fills the normal matrix in all the current
                              row with the master coordinates
                      - End loop

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_OneHalfDegMatrEval
                        (/*IN    */ MATHIT_RC           *coor,
                         /*IN    */ INTx4                Ngcp,
                         /*   OUT*/ double             **A,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_TwoDegMatrEval

        $TYPE         PROCEDURE

        $INPUT        coor     : coordinates with which to fill the normal
                                 matrix
                      Ngcp     : the number of valid GCPs

        $MODIFIED     NONE

        $OUTPUT       A        : normal matrix

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         to evaluate

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the normal matrix for the degree
                      two with the GCP(s) previously evaluated

        $WARNING      THE GCP(S) INFO STRUCTURES MUST BE CREATED, FILLED AND
                      THE GCP(S) CO-REGISTERED BEFORE CALLING THIS PROCEDURE

        $PDL          - Loop over the total number of GCP(s)
                            - Fills the normal matrix in all the current
                              row with the master coordinates
                      - End loop

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_TwoDegMatrEval
                        (/*IN    */ MATHIT_RC           *coor,
                         /*IN    */ INTx4                Ngcp,
                         /*   OUT*/ double             **A,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_ThreeDegMatrEval

        $TYPE         PROCEDURE

        $INPUT        coor     : coordinates with which to fill the normal
                                 matrix
                      Ngcp     : the number of valid GCPs

        $MODIFIED     NONE

        $OUTPUT       A        : normal matrix

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         to evaluate

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the normal matrix for the degree
                      three with the GCP(s) previously evaluated

        $WARNING      THE GCP(S) INFO STRUCTURES MUST BE CREATED, FILLED AND
                      THE GCP(S) CO-REGISTERED BEFORE CALLING THIS PROCEDURE

        $PDL          - Loop over the total number of GCP(s)
                            - Fills the normal matrix in all the current
                              row with the master coordinates
                      - End loop

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_ThreeDegMatrEval
                        (/*IN    */ MATHIT_RC           *coor,
                         /*IN    */ INTx4                Ngcp,
                         /*   OUT*/ double             **A,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_MatrEval

        $TYPE         PROCEDURE

        $INPUT        source  : array with the valid GCPs coordinates to be
                                used as the source coordinates in the
                                transformation
                      target  : array with the valid GCPs coordinates to be
                                used as the target coordinates in the
                                transformation
                      N       : number of input data
                      degree  : flag indicating the wanted transformation to
                                evaluate

        $MODIFIED     NONE

        $OUTPUT       Warp    : the transformation matrix that applied to a
                                particular combination of the source data gives
                                the transformed target data

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_insuff_GCPs
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the warp matrix that transform
                      the source coordinates into the target ones

        $WARNING      NONE

        $PDL          - Checks the number of data against the number of
                        parameters to evaluate for the wanted transformation
                      - Allocates the memories to store the input data, the
                        normal matrix and the expected parameters vector
                      - Loop over the coordinates
                            - Fills the vector of input data with the rows'
                              coordinates
                            - Fills the vector of input data with the columns'
                              coordinates
                      - End Loop
                      - Evaluates the normal matrix
                      - Zeroes the parameters vector
                      - Evaluates the parameters with the Least Mean Square
                        Adjustment
                      - Copy the parameters in the warp matrix

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_MatrEval
                        (/*IN    */ MATHIT_RC           *master,
                         /*IN    */ MATHIT_RC           *slave,
                         /*IN    */ INTx4                N,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN OUT*/ double             **Warp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_WarpEval

        $TYPE         PROCEDURE

        $INPUT        sla_num   : ID of the slave image from which to evaluate
                                  the warps matrices
                      masterpts : vector of coordinates of the master image GCPs
                      slavepts  : vector of coordinates of the slave image GCPs
                      N         : number of valid GCPs
                      degree    : wanted degree of the transformation

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_warp_matr : direct and inverse matrices

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_insuff_GCPs

        $DESCRIPTION  This procedure evaluates the direct warp ( from master
                      to slave coordinates ) and the inverse one

        $WARNING      NONE

        $PDL          - Checks the slave ID
                      - Evaluate the number of parameters
                      - Checks if the data are sufficient
                      - Evaluates the direct warp
                      - Evaluates the inverse warp

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_WarpEval
                        (/*IN    */ UINTx1               sla_num,
                         /*IN    */ MATHIT_RC           *masterpts,
                         /*IN    */ MATHIT_RC           *slavepts,
                         /*IN    */ INTx4                N,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_InitWarp

        $TYPE         PROCEDURE

        $INPUT        degree : the wanted degree of the transformation

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_warp_matr : structure with the pointers to the
                                         warp matrices

        $RET_STATUS   ERRSID_IREG_degree_undef
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure allocates the warp matrices

        $WARNING      THE CLOSE WARP MUST BE CALLED AT THE END OF THE PROGRAM

        $PDL          - Evaluates the number of parameters
                      - Checks them
                      - Allocates the direct warp matrix
                      - Zeroes the matrix row
                      - Allocates the inverse warp matrix
                      - Zeroes the matrix row

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_InitWarp
                        (/*IN    */ IREGPT_warp_deg      degree,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_Warp

        $TYPE         PROCEDURE

        $INPUT        NImages : number of input images
                      degree  : degree of the warp transformation required

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPC_warp_npar : array with the number of parameters
                                         for each degree of the warp
                      IREGPV_gcp       : structure with the GCPs INFO

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_insuff_GCPs
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the warp matrices starting
                      from the valid GCPs for each master and slave couples

        $WARNING      THE GCP EVALUATION MUST BE DONE BEFORE AND THE WARP
                      INIT PROCEDURE TOO

        $PDL          - Checks the image number
                      - Reads the number of parameters to evaluate
                      - Checks if the maximum number of GCPs is sufficient to
                        evaluate the warp matrices
                      - Loop over the slaves
                            - Zeroes a counter
                            - Loop over the master GCPs
                                  - If the slave GCP is valid
                                        - Increments the counter
                                  - End If
                            - End Loop
                            - Allocates two vectors for the master and slave
                              GCPs storage
                            - Loop over the master GCPs
                                  - If the corresponding slave GCP is valid
                                        - Stores the master ...
                                        - ... and the slave GCP
                                  - End If
                            - End Loop
                            - Evaluates the warp matrices
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_Warp
                        (/*IN    */ INTx4                NImages,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_CloseWarp

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure free all the memories allocated for the
                      warp matrices

        $WARNING      NONE

        $PDL          - Frees the direct warp
                      - Frees the inverse warp

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_CloseWarp
                        (/*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_OneDegConv

        $TYPE         PROCEDURE

        $INPUT        x : coordinates to transform
                      T : matrix of transformation

        $MODIFIED     NONE

        $OUTPUT       y : coordinates transformed

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure transform the coordinates with the matrix
                      <T>

        $WARNING      NONE

        $PDL          - Evaluates the row coordinate of the output point
                      - Evaluates the col coordinate of the output point

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_OneDegConv
                        (/*IN    */ MATHIT_RC            x,
                         /*IN    */ double             **T,
                         /*   OUT*/ MATHIT_RC           *y,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_OneAndHalfDegConv

        $TYPE         PROCEDURE

        $INPUT        x : coordinates to transform
                      T : matrix of transformation

        $MODIFIED     NONE

        $OUTPUT       y : coordinates transformed

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure transform the coordinates with the matrix
                      <T>

        $WARNING      NONE

        $PDL          - Evaluates the row coordinate of the output point
                      - Evaluates the col coordinate of the output point

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_OneAndHalfDegConv
                        (/*IN    */ MATHIT_RC            x,
                         /*IN    */ double             **T,
                         /*   OUT*/ MATHIT_RC           *y,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_TwoDegConv

        $TYPE         PROCEDURE

        $INPUT        x : coordinates to transform
                      T : matrix of transformation

        $MODIFIED     NONE

        $OUTPUT       y : coordinates transformed

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure transform the coordinates with the matrix
                      <T>

        $WARNING      NONE

        $PDL          - Evaluates the row coordinate of the output point
                      - Evaluates the col coordinate of the output point

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_TwoDegConv
                        (/*IN    */ MATHIT_RC            x,
                         /*IN    */ double             **T,
                         /*   OUT*/ MATHIT_RC           *y,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_ThreeDegConv

        $TYPE         PROCEDURE

        $INPUT        x : coordinates to transform
                      T : matrix of transformation

        $MODIFIED     NONE

        $OUTPUT       y : coordinates transformed

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure transform the coordinates with the matrix
                      <T>

        $WARNING      NONE

        $PDL          - Evaluates the row coordinate of the output point
                      - Evaluates the col coordinate of the output point

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_ThreeDegConv
                        (/*IN    */ MATHIT_RC            x,
                         /*IN    */ double             **T,
                         /*   OUT*/ MATHIT_RC           *y,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_Mas2Sla

        $TYPE         PROCEDURE

        $INPUT        maspt    : coordinates of the point to convert
                      degree   : degree of the transformation
                      sla_gnum : ID of the slave

        $MODIFIED     NONE

        $OUTPUT       slapt    : transformed point coordinates

        $GLOBAL       IREGPV_warp_matr : warp matrices global variables

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure converts the master coordinates of a
                      point in the slave ones

        $WARNING      NONE

        $PDL          - Switch over the degree
                            - Set the index to the procedure to use
                      - End Switch

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_Mas2Sla
                        (/*IN    */ MATHIT_RC            maspt,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ UINTx1               sla_gnum,
                         /*   OUT*/ MATHIT_RC           *slapt,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_Sla2Mas

        $TYPE         PROCEDURE

        $INPUT        slapt    : coordinates of the point to convert
                      degree   : degree of the transformation
                      sla_gnum : ID of the slave

        $MODIFIED     NONE

        $OUTPUT       maspt    : transformed point coordinates

        $GLOBAL       IREGPV_warp_matr : warp matrices global variables

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure converts the slave coordinates of a
                      point in the master ones

        $WARNING      NONE

        $PDL          - Switch over the degree
                            - Set the index to the procedure to use
                      - End Switch

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_Sla2Mas
                        (/*IN    */ MATHIT_RC            slapt,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ UINTx1               sla_gnum,
                         /*   OUT*/ MATHIT_RC           *maspt,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_VectMas2Sla

        $TYPE         PROCEDURE

        $INPUT        maspts   : master points to convert
                      NRow     : number of points to convert in the row direction
                      NCol     : number of points to convert in the row direction
                      degree   : degree of the used transformation
                      sla_gnum : ID of the slave image

        $MODIFIED     NONE

        $OUTPUT       slapts   : slave points converted

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_warp_not_create

        $DESCRIPTION  This procedure converts a set of master points into
                      their slave coordinates

        $WARNING      NONE

        $PDL          - Loop over the points to convert
                            - Converts the points coordinates
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_VectMas2Sla
                        (/*IN    */ MATHIT_RC_float    **maspts,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ UINTx1               sla_gnum,
                         /*   OUT*/ MATHIT_RC_float    **slapts,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_VectSla2Mas

        $TYPE         PROCEDURE

        $INPUT        slapts   : slave points to convert
                      NRow     : number of points to convert in the row direction
                      NCol     : number of points to convert in the row direction
                      degree   : degree of the used transformation
                      sla_gnum : ID of the slave image

        $MODIFIED     NONE

        $OUTPUT       maspts   : master points converted

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_warp_not_create

        $DESCRIPTION  This procedure converts a set of slave points into
                      their master coordinates

        $WARNING      NONE

        $PDL          - Loop over the points to convert
                            - Converts the points coordinates
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_VectSla2Mas
                        (/*IN    */ MATHIT_RC          **slapts,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ UINTx1               sla_gnum,
                         /*   OUT*/ MATHIT_RC          **maspts,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_WarpCheck

        $TYPE         PROCEDURE

        $INPUT        imanum : image ID
                      degree : degree of the transformation

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_gcp : the structure with the GCPs INFO

        $RET_STATUS   ERRSID_IREG_warp_not_good

        $DESCRIPTION  This procedure checks the warp matrices comparing the
                      residuals obtained with the warp between the master and
                      slave coordinates coarse registered and that evaluates with
                      the evaluated warps

        $WARNING      NONE

        $PDL          - Sets the number of GCPs
                      - Loop over the GCPs of the master image
                            - Converts the master point into the slave reference
                              system
                            - Sums the difference between the transformed
                              and the evaluated slave coordinates to the
                              previous value
                            - Sums the square of the difference
                            - Converts the slave point into the master reference
                              system
                            - Sums the difference between the transformed
                              and the evaluated master coordinates to the
                              previous value
                            - Sums the square of the difference
                      - End Loop
                      - Evaluates the mean values of the residual
                      - Evaluates the RMSs
                      - Checks the RMSs

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_WarpCheck
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_EditGCPs

        $TYPE         PROCEDURE

        $INPUT        sla_imanum : slave image ID
                      degree     : degree of the warp transformation

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_gcp           : the structure with the GCPs info
                      IREGPV_max_point_RMS : the maximum allowable point RMS
                                             value

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the RMS for each valid GCP
                      of the given slave image and re-write the master and
                      slave arrays with the only GCPs with the RMS lesser then
                      the fixed value

        $WARNING      NONE

        $PDL          - Loop over the GCPs
                            - If the GCP is valid for the master and the slave
                                  - Converts the current coordinates from
                                    master to slave
                                  - Evaluates the GCP residuals
                                  - If the RMS is lesser then the defined
                                    maximum RMS allowable value
                                        - Sets the GCP invalid for the slave
                                  - End If
                            - End If
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_EditGCPs
                        (/*IN    */ UINTx1               sla_imanum,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WAEV_WriteResid

        $TYPE         PROCEDURE

        $INPUT        NImages : number of total input mages
                      degree  : degree of the transformation used
                      fp      : output log file pointer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_ima_num_inv

        $DESCRIPTION  This procedure writes the statistics for each slave in
                      an output file

        $WARNING      THE OUTPUT FILE MUST BE OPENED BEFORE

        $PDL          - Checks the input parameters
                      - Loop over the images
                            - Prints in the file the slave number
                            - Zeroes the utility variables
                            - Prints the table header
                            - Loop over the master GCPs
                                  - If the slave GCP is valid
                                        - Increments the GCPs counter
                                        - Prints the master and slave GCPs
                                        - Transforms the master into slave GCP
                                          with the evaluates warp matrix
                                        - Evaluates the residual between the
                                          registered slave GCP and the evaluated
                                          one
                                        - Prints the residual
                                        - Increments the mean and the square
                                          residual variables
                                  - End If
                            - End Loop
                            - Evaluates the mean values of the residuals
                            - Evaluates the RMS of the residuals
                            - Writes them
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_WAEV_WriteResid
                        (/*IN    */ UINTx4               NImages,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ FILE                *fp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_MaxOverlap

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       TLRow : row coordinate of the top left output corner
                      TLCol : column coordinate of the top left output corner
                      BRRow : row coordinate of the bottom right output corner
                      BRCol : column coordinate of the bottom left output
                              corner

        $GLOBAL       IREGIV_ima_num   : number of images to co-register
                      IREGPV_bord_step : number of pixel to skip in the image
                                         contour covering

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the top left and bottom right
                      corners coordinates of the largest square containing all
                      the images to co-register evaluated in the master
                      reference system of coordinates

        $WARNING      NONE

        $PDL          - Allocates some useful variables
                      - Fills the array with the corners of each images with the
                        master image corners
                      - Loop over the slaves
                            - Evaluates the number of points covering the
                              image border
                            - Re-allocates the borders array
                            - Fills the borders array
                            - Transforms the borders points from the slave to
                              the master coordinates system
                            - Search the minima and the maxima values of
                              coordinates
                      - End Loop
                      - Search the minima and the maxima values of coordinates
                        among all the images corners
                      - Fills the output variables

   $EH
   ========================================================================== */
   extern void IREGPP_LAYO_MaxOverlap
                        (/*   OUT*/ INTx4               *TLRow,
                         /*   OUT*/ INTx4               *TLCol,
                         /*   OUT*/ INTx4               *BRRow,
                         /*   OUT*/ INTx4               *BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_MasterOverlap

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       TLRow : row coordinate of the top left output corner
                      TLCol : column coordinate of the top left output corner
                      BRRow : row coordinate of the bottom right output corner
                      BRCol : column coordinate of the bottom left output
                              corner

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the top left and bottom right
                      corners coordinates of the master image as the output
                      layout corners

        $WARNING      NONE

        $PDL          - Fills the output variables with the master corners

   $EH
   ========================================================================== */
   extern void IREGPP_LAYO_MasterOverlap
                        (/*   OUT*/ INTx4               *TLRow,
                         /*   OUT*/ INTx4               *TLCol,
                         /*   OUT*/ INTx4               *BRRow,
                         /*   OUT*/ INTx4               *BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_MinOverlap

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       TLRow : row coordinate of the top left output corner
                      TLCol : column coordinate of the top left output corner
                      BRRow : row coordinate of the bottom right output corner
                      BRCol : column coordinate of the bottom left output
                              corner

        $GLOBAL       IREGIV_ima_num   : number of images to co-register
                      IREGPV_bord_step : number of pixel to skip in the image
                                         contour covering

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the top left and bottom right
                      corners coordinates of the largest square containing all
                      the common parts of the images to co-register. They are
                      evaluated in the master reference system of coordinates

        $WARNING      NONE

        $PDL          - Allocates some useful variables
                      - Fills the array with the corners of each images with the
                        master image corners
                      - Loop over the slaves
                            - Evaluates the number of points covering the
                              slave image border
                            - Adds the four master corners
                            - (Re)allocates the borders array
                            - (Re)allocates the inner flag points array
                            - Zeroes the flag vector
                            - Fills the borders array with the slave points
                            - Fills the borders array with the master points
                            - Loop over the points
                                  - Transforms the borders points from the
                                    slave to the master coordinates system
                                  - Checks if the point is inside the master
                                    image
                                  - Fills the inner vector flag
                            - End Loop
                            - Loop over the master corners
                                  - Checks if the point is inside the slave
                                    contour
                                  - Fills the inner vector flag
                            - End Loop
                            - Search the minima and the maxima values
                              of coordinates among all the images corners
                              flagged as inner
                      - End Loop
                      - Search the minima and the maxima values of coordinates
                        among all the images corners flagged as inner
                      - Fills the output variables

   $EH
   ========================================================================== */
   extern void IREGPP_LAYO_MinOverlap
                        (/*   OUT*/ INTx4               *TLRow,
                         /*   OUT*/ INTx4               *TLCol,
                         /*   OUT*/ INTx4               *BRRow,
                         /*   OUT*/ INTx4               *BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_FillBorderArray

        $TYPE         PROCEDURE

        $INPUT        Np    : dimension of the array
                      NRow  : number of rows of the image
                      NCol  : number of columns of the image
                      Step  : step of the points

        $MODIFIED     NONE

        $OUTPUT       array : array to fill with the points on the border
                              of the image

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluate an array of points covering
                      the image border

        $WARNING      NONE

        $PDL          - Checks the inputs parameters
                      - Zeroes the array
                      - While the point has a column coordinate inside the
                        top image border
                            - Fill the column coordinate of the current
                              point
                            - Increments the counter
                      - End while
                      - While the point has a row coordinate inside the
                        left image border
                            - Fill the row coordinate of the current point
                            - Fill its column coordinate
                            - Increments the counter
                      - End while
                      - While the point has a column coordinate inside the
                        bottom image border
                            - Fill the row coordinate of the current point
                            - Fill its column coordinate
                            - Increments the counter
                      - End while
                      - While the point has a row coordinate inside the
                        right image border
                            - Fill the row coordinate of the current point
                            - Increments the counter
                      - End while

   $EH
   ========================================================================== */
   extern void IREGPP_LAYO_FillBorderArray
                        (/*IN    */ INTx4                Np,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ INTx4                Step,
                         /*   OUT*/ MATHIT_RC           *array,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_Slave2MasterContour

        $TYPE         PROCEDURE

        $INPUT        sla_gnum : ID of the slave
                      Np       : number of points to transform

        $MODIFIED     arr      : array of points to be transformed. In output
                                 it contains the transformed points

        $OUTPUT       NONE

        $GLOBAL       IREGPV_warp_deg : chosed warp degree

        $RET_STATUS   ERRSID_IREG_image_number_out
                      ERRSID_IREG_insuff_n_points

        $DESCRIPTION  This procedure applies the warp transformation to a
                      set of slave points coordinates and converts them into
                      master referred coordinates

        $WARNING      NONE

        $PDL          - Checks the slave image num
                      - Checks the number of points
                      - Loop over the points to convert
                            - Converts the point from slave to master
                              reference system coordinates
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_LAYO_Slave2MasterContour
                        (/*IN    */ UINTx1               sla_gnum,
                         /*IN    */ INTx4                Np,
                         /*IN OUT*/ MATHIT_RC           *arr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_MaxSlaveCorners

        $TYPE         PROCEDURE

        $INPUT        Np   : number of points of the array
                      arr  : array of points

        $MODIFIED     NONE

        $OUTPUT       corn : array with the image extreems

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure finds the maximum and the minimum among
                      the coordinates of an array and fills an output array
                      with the four vertices of the square surrounding the
                      array points

        $WARNING      NONE

        $PDL          - Loop over the array points
                            - Fills the minimum value for the rows with the
                              minimum between the row point coordinate and
                              the minimum value stored before
                            - Fills the minimum value for the columns with
                              the minimum between the row point coordinate
                              and the minimum value stored before
                            - Fills the maximum value for the rows with the
                              maximum between the row point coordinate and
                              the maximum value stored before
                            - Fills the maximum value for the columns with
                              the maximum between the row point coordinate
                              and the maximum value stored before
                      - End Loop
                      - Fills the output array with the values of the
                        coordinates of the corners of the square surrounding
                        the array curve of points

   $EH
   ========================================================================== */
   extern void IREGPP_LAYO_MaxSlaveCorners
                        (/*IN    */ INTx4                Np,
                         /*IN    */ MATHIT_RC           *arr,
                         /*   OUT*/ MATHIT_RC           *corn,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_MinSlaveCorners

        $TYPE         PROCEDURE

        $INPUT        Np      : number of points of the array
                      arr     : array of points
                      in_flag : array with the information about the inner
                                points

        $MODIFIED     NONE

        $OUTPUT       corn    : array with the image extreems

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure finds the maximum and the minimum among
                      the coordinates of a set of points of an array and fills
                      an output array with the four vertices of the square
                      surrounding the set of array points

        $WARNING      NONE

        $PDL          - Loop over the array points
                            - If the point is a inner point
                                  - Fills the minimum value for the rows with the
                                    minimum between the row point coordinate and
                                    the minimum value stored before
                                  - Fills the minimum value for the columns with
                                    the minimum between the row point coordinate
                                    and the minimum value stored before
                                  - Fills the maximum value for the rows with the
                                    maximum between the row point coordinate and
                                    the maximum value stored before
                                  - Fills the maximum value for the columns with
                                    the maximum between the row point coordinate
                                    and the maximum value stored before
                            - End If
                      - End Loop
                      - Fills the output array with the values of the
                        coordinates of the corners of the square surrounding
                        the array curve of points

   $EH
   ========================================================================== */
   extern void IREGPP_LAYO_MinSlaveCorners
                        (/*IN    */ INTx4                Np,
                         /*IN    */ MATHIT_RC           *arr,
                         /*IN    */ LDEFIT_boolean      *in_flag,
                         /*   OUT*/ MATHIT_RC           *corn,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_LAYO_CornersEval

        $TYPE         PROCEDURE

        $INPUT        mode  : overlap mode

        $MODIFIED     NONE

        $OUTPUT       TLRow : top left row coordinate in the master
                              reference system
                      TLCol : top left column coordinate in the master
                              reference system
                      BRRow : bottom right row coordinate in the master
                              reference system
                      BRCol : bottom right column coordinate in the master
                              reference system

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_over_mode_undef

        $DESCRIPTION  This procedure evaluates the corners of the layout of
                      the co-registered images

        $WARNING      NONE

        $PDL          - Switches over the different mode
                            - Sets the index for the function to call
                      - End Switch
                      - Calls the right function

   $EH
   ========================================================================== */
   extern void IREGPP_LAYO_CornersEval
                        (/*IN    */ IREGPT_over_mode     mode,
                         /*   OUT*/ INTx4               *TLRow,
                         /*   OUT*/ INTx4               *TLCol,
                         /*   OUT*/ INTx4               *BRRow,
                         /*   OUT*/ INTx4               *BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_InterpolateImages

        $TYPE         PROCEDURE

        $INPUT        inp_io     : input files descriptors array
                      NImages    : number of input (and output) images
                      TLRow      : top left row coordinate of the AoI to
                                   interpolate
                      TLCol      : top left column coordinate of the AoI to
                                   interpolate
                      BRRow      : bottom right row coordinate of the AoI to
                                   interpolate
                      BRCol      : bottom right column coordinate of the AoI to
                                   interpolate
                      RowWinSize : row block size
                      ColWinSize : column block size
                      InterpMode : interpolation mode

        $MODIFIED     out_io     : output files descriptors array

        $OUTPUT       NONE

        $GLOBAL       IREGPV_inter_bord : cell bord to add to avoid
                                          boreder effect in the interpolation

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_incons_corn
                      ERRSID_IREG_win_too_large
                      ERRSID_IREG_err_mem_alloc
                      ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure interpolates all the input images and
                      writes the output co-registered ones in their output
                      form using the warp matrices evaluated before

        $WARNING      THE GCPS COLLECTION AND THE WARP EVALUATION MUST BE
                      DONE BEFORE THA CALL TO THIS PROCEDURE

        $PDL          - Checks the number of input images
                      - Checks the corners coordinates
                      - Evaluates the number of rows and columns
                      - Checks the window sizes
                      - Allocates the array to store the numbers of slave
                        images IDs
                      - Initializes the interpolation procedures
                      - Evaluates the number of rows and columns of the slave
                        image cell to extract
                      - Sets the image data type
                      - Allocates the grid of points in which to interpolate
                      - Allocates the matrix to store the writing image
                      - Initializes the starting variables to read and write
                      - While the rows left are more then the row window size
                            - While the columns left are more then the column
                              window size
                                  - Interpolates the cell
                                  - Updates the starting variables
                            - End While
                            - If there are left columns
                                  - Evaluates the column size for the window
                                  - Interpolates the cell
                            - End If
                            - Updates the starting variables
                      - End While
                      - If there are left rows
                            - Evaluates the row size for the window
                            - While the columns left are more then the column
                              window size
                                  - Interpolates the cell
                                  - Updates the starting variables
                            - End While
                            - If there are left columns
                                  - Evaluates the column size for the window
                                  - Interpolates the cell
                            - End If
                            - Interpolates the cell
                      - End If
                      - Frees the allocated memories

   $EH
   ========================================================================== */
   extern void IREGPP_WRIM_InterpolateImages
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ INTx4                NImages,
                         /*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                BRRow,
                         /*IN    */ INTx4                BRCol,
                         /*IN    */ INTx4                RowWinSize,
                         /*IN    */ INTx4                ColWinSize,
                         /*IN    */ IREGPT_inter_mode    InterpMode,
                         /*IN OUT*/ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_InitInterp

        $TYPE         PROCEDURE

        $INPUT        mode       : interpolation mode
                      sla_inum   : vector with the image number of the slaves
                      NImages    : number of images to interpolate

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IREGPV_inter_bord :     bord to add to the interpolating
                                              images
                      MATHID_cubi_conv_elem : number of elements of the
                                              cubic convolution interpolator
                      MATHPV_sinc_elem      : number of elements of the sinc
                                              interpolator

        $RET_STATUS   ERRSID_IREG_err_mem_alloc
                      ERRSID_IREG_inter_not_def

        $DESCRIPTION  This procedure initializes the interpolation procedures

        $WARNING      THE IMAGE ANNOTATIONS MUST BE READ BEFORE CALLING THE
                      PROCEDURE

        $PDL          - Switch over the interpolation modes
                            - Set the image borders
                            - If the Case is Cubic Convolution interpolation
                                  - The initialization of the cubic convolution
                                    interpolator must be called
                            - Break
                            - If the Case is Sinc interpolation
                                  - Loop over the images on which the
                                    interpolation can be done
                                        - The doppler frequency at centre image is
                                          evaluated
                                  - End Loop
                                  - The sinc tables are evaluated
                            - Break
                      - End Switch

   $EH
   ========================================================================== */
   extern void IREGPP_WRIM_InitInterp
                        (/*IN    */ IREGPT_inter_mode    mode,
                         /*IN    */ UINTx1              *sla_inum,
                         /*IN    */ INTx4                NImages,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_CloseInterp

        $TYPE         PROCEDURE

        $INPUT        NImages : number of images that could be opened
                                simultaneously

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNID_NIMAMAX : maximum number of opened images

        $RET_STATUS   ERRSID_IREG_image_number_out

        $DESCRIPTION  This procedure closes all the co-registrator stuff

        $WARNING      NONE

        $PDL          - Checks the number od slaves
                      - Switch over the differents modes of interpolation

   $EH
   ========================================================================== */
   extern void IREGPP_WRIM_CloseInterp
                        (/*IN    */ IREGPT_inter_mode    mode,
                         /*IN    */ INTx4                NImages,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_CoreInterpolator

        $TYPE         PROCEDURE

        $INPUT        RStartR    : starting row to read from the master file
                      CStartR    : starting column to read from the master file
                      NRow       : number of rows to read
                      NCol       : number of columns to read
                      RStartW    : starting row to write in the master file
                      CStartW    : starting column to write in the master file
                      inp_io     : array of input files descriptors
                      out_io     : array of output files descriptors
                      NImages    : number of input images
                      mode       : interpolation mode
                      elem_size  : size of one image element

        $MODIFIED     points     : array to store the points in which to
                                   interpolate
                      ImageWrite : matrix in which to store the output image

        $OUTPUT       NONE

        $GLOBAL       IREGPV_warp_deg
                      IREGPV_inter_bord

        $RET_STATUS   ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure is the core of the blocking interpolation
                      procedure of the master image

        $WARNING      THE WARP MATRICES MUST BE EVALUATED AND THE GLOBAL
                      VARIABLES WITH THEM MUST BE FILLED BEFORE CALLING THE
                      INTERPOLATION PROCEDURES

        $PDL          - Fills the array of points in the master block
                      - Evaluates the total number of points
                      - Re-writes the master block
                      - Loop over the slave images
                            - Converts the points coordinates from the master
                              reference system to the slave referece system
                            - Finds the maximum overlap zone in the slave
                              reference system
                            - Evaluates the number of rows and columns of the
                              slave image cell
                            - Evaluates the centre of the image cell
                            - Enlarges the slave image cell borders
                            - Re-evaluates the Top Left coordinates of the cell
                            - Allocates the image matrix in which to store the
                              slave cell
                            - Extracts the slave cell
                            - Re-scale the points in the cell
                            - Interpolates the slave cell
                            - Writes the slave cell in its file
                            - Frees the allocated memories for the image read
                              slave cell
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_WRIM_CoreInterpolator
                        (/*IN    */ INTx4                RStartR,
                         /*IN    */ INTx4                CStartR,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ INTx4                RStartW,
                         /*IN    */ INTx4                CStartW,
                         /*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ INTx4                NImages,
                         /*IN    */ IREGPT_inter_mode    mode,
                         /*IN    */ size_t               elem_size,
                         /*IN OUT*/ MATHIT_RC_float    **points,
                         /*IN OUT*/ MATHIT_RC_float    **ref_points,
                         /*IN OUT*/ float              **ImageWrite,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_FillPointsArray

        $TYPE         PROCEDURE

        $INPUT        TLRow : top left row coordinate of the master block
                      TLCol : top left column coordinate of the master block
                      NRow  : number of rows of the block
                      NCol  : number of columns of the block

        $MODIFIED     NONE

        $OUTPUT       array : array of points coordinates describing the pixels
                              of the master block

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills an array of points coordinates with
                      the pixels master block coordinates

        $WARNING      NONE

        $PDL          - Loop over the rows
                            - Loop over the columns
                                  - Fills the row pixel coordinate
                                  - Fills the column pixel coordinate
                            - End Loop
                      - End Loop

   $EH
   ========================================================================== */
   extern void IREGPP_WRIM_FillPointsArray
                        (/*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*   OUT*/ MATHIT_RC_float    **array,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_WriteMasterBlock

        $TYPE         PROCEDURE

        $INPUT        inp_io     : input master file descriptor
                      RStartR    : starting row to read the master cell
                      CStartR    : starting column to read the master cell
                      RStartW    : starting row to write the master cell
                      CStartW    : starting column to write the master cell
                      NRow       : number of rows to write
                      NCol       : number of columns to write

        $MODIFIED     NONE

        $OUTPUT       ImageWrite : image matrix in which to store the output
                                   master cell
                      out_io     : output master file descriptor

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure write the master cell into the output file
                      in the new reference system

        $WARNING      NONE

        $PDL          - Evaluates the cell centre coordinates
                      - Extracts the master cell
                      - Opens the output master file writing mode
                            - Loop over the block rows
                                  - Writes the master image line
                            - End Loop
                      - Closes the output master file writing mode

   $EH
   ========================================================================== */
   extern void IREGPP_WRIM_WriteMasterBlock
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ INTx4                RStartR,
                         /*IN    */ INTx4                CStartR,
                         /*IN    */ INTx4                RStartW,
                         /*IN    */ INTx4                CStartW,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN OUT*/ float              **ImageWrite,
                         /*IN OUT*/ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_MaxOverlap

        $TYPE         PROCEDURE

        $INPUT        NRow   : number of rows of the grid
                      NCol   : number of columns of the grid
                      points : array of points

        $MODIFIED     NONE

        $OUTPUT       TLRow  : top left row coordinate of the square
                      TLCol  : top left column coordinate of the square
                      BRRow  : bottom right row coordinate of the square
                      BRCol  : bottom right column coordinate of the square

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the top left and bottom right
                      corners of the square surrounding the set of points
                      coordinates

        $WARNING      NONE

        $PDL          - Loop over the number of grid rows
                            - Loop over the number of columns of the grid
                                  - Finds the minima and the maxima of the
                                    points of the grid
                            - End Loop
                      - End Loop
                      - Fills the output square coordinates

   $EH
   ========================================================================== */
   extern void IREGPP_WRIM_MaxOverlap
                        (/*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN    */ MATHIT_RC_float    **points,
                         /*   OUT*/ INTx4               *TLRow,
                         /*   OUT*/ INTx4               *TLCol,
                         /*   OUT*/ INTx4               *BRRow,
                         /*   OUT*/ INTx4               *BRCol,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_Interpolate

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      mode       : interpolation mode
                      ImageRead  : image read
                      NRowInp    : number of rows of the read image
                      NColInp    : number of columns of the read image
                      points     : matrix of points in which to interpolate
                      NRowOut    : number of rows of the matrix of points
                      NColOut    : number of columns of the matrix of points
                      DataType   : data type of the image
                      filler     : value with which to fill the out regions

        $MODIFIED     NONE

        $OUTPUT       ImageWrite : output image

        $GLOBAL       IREGPV_inter_bord

        $RET_STATUS   ERRSID_IREG_data_type_not_allow
                      ERRSID_IREG_err_mem_alloc
                      ERRSID_IREG_inter_not_def

        $DESCRIPTION  This procedure interpolates the input image block on the
                      given matrix of points in the selected mode

        $WARNING      NONE

        $PDL          - Switch over the interpolation modes
                            - Interpolates the image
                            - In the case of global constant FFT shift
                                  - Evaluates the constant shift value as the
                                    fractional part of the central point shift
                                  - Interpoaltes the image block
                                  - Copies the image block without the added
                                    borders in a float ( or 2 float ) image
                                    block
                            - Break
                            - In the case of FFT shift column by column
                                  - Allocates the vector of shifts
                                  - Zeroes its elements
                                  - Fills it with the fractional part of the
                                    shift column by column
                                  - Interpoaltes the image block
                                  - Copies the image block without the added
                                    borders in a float ( or 2 float ) image
                                    block
                            - Break
                      - End Switch

   $EH
   ========================================================================== */
   extern void IREGPP_WRIM_Interpolate
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ IREGPT_inter_mode    mode,
                         /*IN    */ float              **ImageRead,
                         /*IN    */ INTx4                NRowInp,
                         /*IN    */ INTx4                NColInp,
                         /*IN    */ MATHIT_RC_float    **points,
                         /*IN    */ INTx4                NRowOut,
                         /*IN    */ INTx4                NColOut,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ float                filler,
                         /*   OUT*/ float              **ImageWrite,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_WriteSlave

        $TYPE         PROCEDURE

        $INPUT        RStartW    : starting row to write in the file
                      CStartW    : starting column to write in the file
                      NRow       : number of rows to write
                      NCol       : number of columns to write

        $MODIFIED     ImageWrite : image to write in the file
                      out_io     : output file descriptor

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure write in the output file a block of image

        $WARNING      NONE

        $PDL          - Opens the writing mode for the output file
                      - Loop over the image rows
                            - Writes the slave line
                      - End Loop
                      - Closes the writing mode for the output file

   $EH
   ========================================================================== */
   extern void IREGPP_WRIM_WriteSlave
                        (/*IN    */ INTx4                RStartW,
                         /*IN    */ INTx4                CStartW,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ INTx4                NCol,
                         /*IN OUT*/ float              **ImageWrite,
                         /*IN OUT*/ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_BSLN_BaselineEval

        $TYPE         PROCEDURE

        $INPUT        mas_imanum : master image ID
                      sla_imanum : array of IDs of the slave images
                      TLRow      : row coordinate of the top left corner of the
                                   AoI
                      TLCol      : column coordinate of the top left corner of
                                   the AoI
                      NRow       : number of rows of the AoI
                      NCol       : number of columns of the AoI
                      NImages    : number of images
                      degree     : degree of the warp used in the registration
                      out_fp     : pointer to the opened ASCII file that will
                                   contain the baseline informations

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot : image annotations INFO structure

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_image_number_out
                      ERRSID_IREG_incons_corn
                      ERRSID_IREG_warp_not_create
                      ERRSID_IREG_err_mem_alloc

        $DESCRIPTION  This procedure evaluates the baselines for all the slaves
                      WRT the master image co-registered and writes the
                      evaluated values into the ASCII file previously opened

        $WARNING      THE WARP MUST BE EVALUATE AND THE IMAGE ANNOTATIONS MUST
                      BE READ BEFORE

        $PDL          - Checks the input parameters
                      - Allocates the necessary memories
                      - Initializes the coordinates conversions for the master
                        image
                      - Sets the central points of the AoI in image coordinates
                      - Evaluates the satellite position and velocity for the
                        master central point
                      - Evaluates the cartesian coordinates of the central point
                        of the AoI on the master image
                      - Evaluates the Satellite - Target versor
                      - Loop over the slaves
                            - Evaluates the slave point corresponding to the
                              central master one
                            - Initializes the coordinates conversions for the
                              slave image
                            - Evaluates the satellite position and velocity
                              for the row of the point corresponding to the
                              master central one
                            - Evaluates the baseline cartesian components
                            - Evaluates the baseline component parallel to the
                              Satellite - Target direction
                            - Evaluates the sign to attribute to the normal
                              baseline component
                            - Evaluates the normal baseline component
                            - Writes the baseline information on the output
                              file
                      - End Loop
                      - Free the allocated memories

   $EH
   ========================================================================== */
   extern void IREGPP_BSLN_BaselineEval
                        (/*IN    */ UINTx1               mas_imanum,
                         /*IN    */ UINTx1              *sla_imanum,
                         /*IN    */ INTx4                TLRow,
                         /*IN    */ INTx4                TLCol,
                         /*IN    */ UINTx4               NRow,
                         /*IN    */ UINTx4               NCol,
                         /*IN    */ INTx4                NImages,
                         /*IN    */ IREGPT_warp_deg      degree,
                         /*IN    */ FILE                *out_fp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_COHE_AllocImages

        $TYPE         PROCEDURE

        $INPUT        DataType  : image data type
                      NImages   : number of input images
                      NRow      : number of rows of the image blocks
                      NCol      : number of columns of the image blocks

        $MODIFIED     NONE

        $OUTPUT       InpIma    : array of input images blocks
                      OutIma    : array of output image
                      inp_type  : input data type for read block procedures
                      elem_size : element size of the images

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_ima_num_inv
                      ERRSID_IREG_null_ima_dim
                      ERRSID_OVLS_err_mem_alloc

        $DESCRIPTION  This procedure allocates the array of input image blocks
                      for the Overlap And Save algorithm

        $WARNING      NONE

        $PDL          - Checks the input parameters
                      - Switch over the data types
                            - Defines the element size
                      - End Switch
                      - Allocates the blocks of images

   $EH
   ========================================================================== */
   extern void IREGPP_COHE_AllocImages
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ UINTx4               NImages,
                         /*IN    */ UINTx4               NRow,
                         /*IN    */ UINTx4               NCol,
                         /*   OUT*/ float            ****InpIma,
                         /*   OUT*/ float              **OutIma,
                         /*   OUT*/ DATA_TYPEIT         *inp_type,
                         /*   OUT*/ size_t              *elem_size,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_COHE_CoreFunc

        $TYPE         PROCEDURE

        $INPUT        DataType   : input image data type
                      NRow       : number of rows of the block
                      NCol       : number of columns of the block
                      RowWinSize : coherence window dimension
                      ColWinSize : coherence window dimension
                      WinSize    : coherence window dimension
                      InpIma     : input image block
                      out_io     : pointer to the output file descriptor
                      OutIma     : array to store a row of the output
                                   image

        $MODIFIED     RowW    : counter to the current writing row

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_null_win_size
                      ERRSID_IREG_kernel_dim_high

        $DESCRIPTION  This procedure evaluates the coherence of two co-
                      registered images moving a window with a unitary step
                      and sizes user defined

        $WARNING      NONE

        $PDL          - Checks the input parameters
                      - While the window is inside the image block in the rows
                        direction
                            - If the row is even
                                  - Set the starting column of the moving window
                                    at zero
                                  - While the window is inside the image block
                                    in the columns direction
                                        - If it's the first window in the block
                                              - Evaluates the covariance and the
                                                variances of the window
                                        - Else If the current window is at the
                                          left block margin
                                              - Evaluates the covariance and the
                                                variances with the new row above
                                                the window and taking off the
                                                old first row of it
                                        - Else
                                              - Evaluates the covariance and the
                                                variances with the new column on
                                                the right of the current window
                                                position and takes off the old
                                                column on the left of it
                                        - End If
                                        - Evaluate the coherence for that window
                                          position
                                        - Increments the columns counter
                                  - End While
                                  - Write the output image row in the output
                                    file
                                  - Increments the output row counter
                            - Else
                                  - Set the starting column of the moving window
                                    at the last decremented by the window size
                                    in the column direction
                                  - While the window is inside the image block
                                    in the columns direction
                                        - If it's the first window in the block
                                              - Evaluates the covariance and the
                                                variances with the new row above
                                                the window and taking off the
                                                old first row of it
                                        - Else
                                              - Evaluates the covariance and the
                                                variances with the new column on
                                                the left of the current window
                                                position and takes off the old
                                                column on the right of it
                                        - End If
                                        - Evaluate the coherence for that window
                                          position
                                        - Decrements the columns counter
                                  - End While
                                  - Write the output image row in the output
                                    file
                                  - Increments the output row counter
                            - End If
                            - Increments the input images rows counter
                      - End While

   $EH
   ========================================================================== */
   extern void IREGPP_COHE_CoreFunc
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ UINTx4               NRow,
                         /*IN    */ UINTx4               NCol,
                         /*IN    */ UINTx4               RowWinSize,
                         /*IN    */ UINTx4               ColWinSize,
                         /*IN    */ float             ***InpIma,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ float               *OutIma,
                         /*IN OUT*/ UINTx4              *RowW,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_COHE_FillVal

        $TYPE         PROCEDURE

        $INPUT        DataType : image data type
                      NRow     : window size in the row direction
                      NCol     : window size in the column direction
                      StartRow : starting row
                      StartCol : starting column
                      InpIma1  : first image to multiply
                      InpIma2  : second image to multiply

        $MODIFIED     NONE

        $OUTPUT       cov      : current covariance value to modify
                      var1     : current variance value of the first image
                                 to modify
                      var2     : current variance value of the second image
                                 to modify

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure fills the values of the covariance of
                      to images and their variances

        $WARNING      NONE

        $PDL          - Switches over the data types
                            - Loop over the rows
                                  - Loop over the columns
                                        - Fills the covariance value
                                        - Fills the variance of the first
                                          image
                                        - Fills the variance of the second
                                          image
                                  - End Loop
                            - End Loop
                      - End Switch

   $EH
   ========================================================================== */
   extern void IREGPP_COHE_FillVal
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ UINTx4               NRow,
                         /*IN    */ UINTx4               NCol,
                         /*IN    */ UINTx4               StartRow,
                         /*IN    */ UINTx4               StartCol,
                         /*IN    */ float              **InpIma1,
                         /*IN    */ float              **InpIma2,
                         /*IN OUT*/ double              *cov,
                         /*IN OUT*/ double              *var1,
                         /*IN OUT*/ double              *var2,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_COHE_MoveCol

        $TYPE         PROCEDURE

        $INPUT        DataType : image data type
                      Kr       : window size in the row direction
                      RStart   : starting row
                      COn      : column to add
                      COff     : column to exclude
                      InpIma1  : first image to multiply
                      InpIma2  : second image to multiply

        $MODIFIED     cov      : current covariance value to modify
                      var1     : current variance value of the first image
                                 to modify
                      var2     : current variance value of the second image
                                 to modify

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure updates the current value of the
                      covariance of two images windows and their variances
                      taking off the vaue at the given column and taking on the
                      other indicated

        $WARNING      NONE

        $PDL          - Switches over the data types
                            - Subtracts the old row from the covariance
                            - Sums the new one
                            - Subtracts the old row from the first image
                              variance
                            - Sums the new one
                            - Subtracts the old row from the second image
                              variance
                            - Sums the new one
                      - End Switch

   $EH
   ========================================================================== */
   extern void IREGPP_COHE_MoveCol
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               RStart,
                         /*IN    */ UINTx4               COn,
                         /*IN    */ UINTx4               COff,
                         /*IN    */ float              **InpIma1,
                         /*IN    */ float              **InpIma2,
                         /*IN OUT*/ double               *cov,
                         /*IN OUT*/ double               *var1,
                         /*IN OUT*/ double               *var2,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_COHE_MoveRow

        $TYPE         PROCEDURE

        $INPUT        DataType : image data type
                      Kc       : window size in the column direction
                      ROn      : row to add
                      ROff     : row to exclude
                      CStart   : starting col
                      InpIma1  : first image to multiply
                      InpIma2  : second image to multiply

        $MODIFIED     cov      : current covariance value to modify
                      var1     : current variance value of the first image
                                 to modify
                      var2     : current variance value of the second image
                                 to modify

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure updates the current value of the
                      covariance of two images windows and their variances
                      taking off the vaue at the given row and taking on the
                      other indicated

        $WARNING      NONE

        $PDL          - Switches over the data types
                            - Subtracts the old column from the covariance
                            - Sums the new one
                            - Subtracts the old column from the first image
                              variance
                            - Sums the new one
                            - Subtracts the old column from the second image
                              variance
                            - Sums the new one
                      - End Switch

   $EH
   ========================================================================== */
   extern void IREGPP_COHE_MoveRow
                        (/*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ UINTx4               ROn,
                         /*IN    */ UINTx4               ROff,
                         /*IN    */ UINTx4               CStart,
                         /*IN    */ float              **InpIma1,
                         /*IN    */ float              **InpIma2,
                         /*IN OUT*/ double               *cov,
                         /*IN OUT*/ double               *var1,
                         /*IN OUT*/ double               *var2,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGPP_WRIM_CheckMemory

        $TYPE         PROCEDURE

        $INPUT        inp_io     : array of tiff files descriptors

        $MODIFIED     NONE

        $OUTPUT       SquareSize : size of the square that can be allocated

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_data_type_not_allow

        $DESCRIPTION  This procedure evaluates the size of the square block
                      of image that can be interpolated without memory crash

        $WARNING      NONE

        $PDL          - Evaluates the available memory
                      - Evaluates the necessary memory as function of the size
                      - Evaluates the maximum square size

   $EH
   ========================================================================== */
   extern void IREGPP_WRIM_CheckMemory
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*   OUT*/ UINTx4              *SquareSize,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IREGPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 IREGPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IREGPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void IREGPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) IREGIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( IREGPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IREGIM_

      $DESCRIPTION  This procedure

                    IREGIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define IREGPM_
*/

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPC_norm_func

      $DESCRIPTION  This is the set of functions that create the normal matrix
                    for the various degrees

   $EH
   ========================================================================== */
#ifdef IREG_GLBL
   GLOBAL const IREGPT_norm_func IREGPC_norm_func[] = {
      IREGPP_WAEV_OneDegMatrEval,
      IREGPP_WAEV_OneHalfDegMatrEval,
      IREGPP_WAEV_TwoDegMatrEval,
      IREGPP_WAEV_ThreeDegMatrEval
   };
#else
   GLOBAL const IREGPT_norm_func IREGPC_norm_func[];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPC_conv_func

      $DESCRIPTION  This is the set of functions that converts a point
                    coordinates in row, col with a warp function

   $EH
   ========================================================================== */
#ifdef IREG_GLBL
   GLOBAL const IREGPT_conv_func IREGPC_conv_func[] = {
      IREGPP_WAEV_OneDegConv,
      IREGPP_WAEV_OneAndHalfDegConv,
      IREGPP_WAEV_TwoDegConv,
      IREGPP_WAEV_ThreeDegConv
   };
#else
   GLOBAL const IREGPT_conv_func IREGPC_conv_func[];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGPC_over_func

      $DESCRIPTION  This is the set of functions that evaluate the corners of
                    the output layout of the co-registered images

   $EH
   ========================================================================== */
#ifdef IREG_GLBL
   GLOBAL const IREGPT_over_func IREGPC_over_func[] = {
      IREGPP_LAYO_MinOverlap,
      IREGPP_LAYO_MaxOverlap,
      IREGPP_LAYO_MasterOverlap
   };
#else
   GLOBAL const IREGPT_over_func IREGPC_over_func[];
#endif

