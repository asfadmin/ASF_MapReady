/* ==========================================================================
   $MODULE_HEADER

      $NAME              FILS_INTF

      $FUNCTION          File Library Service interface module.

      $ROUTINE           FILSIP_open
                         FILSIP_close
                         FILSIP_delete
                         FILSIF_read
                         FILSIF_write
                         FILSIP_sizequota
                         FILSIP_read_block 

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       21-MAR-97     AG       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef FILS
#define FILS FILS


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H

#ifdef FILS_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FILSID_file_name_length

      $DESCRIPTION  Length of files name

   $EH
   ========================================================================== */
#define FILSID_file_name_length 256

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FILSIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum FILSIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FILSIC_

      $DESCRIPTION  The FILSIC_

   $EH
   ========================================================================== */
/*   const FILSIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FILSIT_

      $DESCRIPTION  

   ========================================================================== */
   typedef char FILSIT_file_name[ FILSID_file_name_length ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FILSIT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct FILSIT_*_def { 

   typedef struct FILSIT_*_def FILSIT_*
*/

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FILSIT_io

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct FILSIT_io_def { 
      char        fname[256];
      FILE       *fp;
      UINTx4      size;
      INTx4       curr_start_line;
      INTx4       curr_end_line;
      void      **curr_buff;
   };
   typedef struct FILSIT_io_def FILSIT_io;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FILSIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIP_open

      $TYPE         Procedure

      $INPUT        file_name    :  name of the file to be open
                    mode         :  opening mode
                    size	 :  required size in Kb or zero if the size
                                    cannot be predicted

      $MODIFIED     NONE

      $OUTPUT       fp            : pointer to the file

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure open a file and return a pointer to it. 

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void FILSIP_open 
                        (/*IN    */ FILSIT_file_name     file_name,
                         /*IN    */ char                *mode,
                         /*IN    */ UINTx4               size,
                         /*   OUT*/ FILE               **fp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIP_close

      $TYPE         Procedure

      $INPUT        NONE

      $MODIFIED     fp            : pointer to the file

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure close a file and null the pointer to it. 

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void FILSIP_close
                        (/*IN OUT*/ FILE               **fp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIP_delete

      $TYPE         Procedure

      $INPUT        file_name    :  name of the file to be removed

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure deletes a file. 

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern void FILSIP_delete
                        (/*IN    */ FILSIT_file_name     file_name,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIF_read

      $TYPE         Procedure

      $INPUT        fp           :  pointer to the file to be read
                    data_size    :  size of the buffer to be read

      $MODIFIED     data_ptr     :  pointer where store the bytes read

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure read from an open file and store the 
                    data_size bytes in the data_ptr. Returns the effective
                    number of bytes read. 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
   extern INTx4 FILSIF_read        
                        (/*IN    */ FILE                *fp,
                         /*IN    */ INTx4                data_size,
                         /*IN OUT*/ void                *data_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIF_write

      $TYPE         Procedure

      $INPUT        fp           :  pointer to the file to be read
                    data_size    :  size of the buffer to be read
                    data_ptr     :  pointer where store the bytes read

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure write into an open file data_size 
                    bytes from the data_ptr. Returns the effective
                    number of bytes write.

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
   extern INTx4 FILSIF_write
                        (/*IN    */ FILE                *fp,
                         /*IN    */ INTx4                data_size,
                         /*IN OUT*/ void                *data_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         FILSIP_sizequota

        $TYPE         PROCEDURE

        $INPUT        filename	: a file or a directory name

        $MODIFIED     NONE

        $OUTPUT       avail_diskspace  
                                : amount of available space on the file system
                                  where the file or the directory is placed on

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_FILS_uncomput_sizequota

        $DESCRIPTION  This procedure retrives the number of free bytes in
                      the passed directory

        $WARNING      NONE


   $EH
   ========================================================================== */
   extern void FILSIP_sizequota
                        (/*IN    */ char                *filename,
                         /*   OUT*/ UINTx4              *avail_diskspace,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIP_read_block

      $TYPE         Procedure

      $INPUT        descriptor   :  pointer to the media to be read
                    data_size    :  size of the buffer to be read
                    no_lines     :  number of lines

      $MODIFIED     data_ptr     :  pointer where store the bytes read

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure read a set lines from an open media and 
                    store the data_size bytes in the data_ptr. 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
   extern void FILSIP_read_block         
                        (/*IN    */ FILE                *fp,
                         /*IN    */ INTx4                data_size,
                         /*IN    */ INTx4                no_lines,
                         /*IN OUT*/ void               **data_ptr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void FILSIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) FILSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FILSIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    FILSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define FILSIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_FILS_err_open             2
#define ERRSID_FILS_err_read             3
#define ERRSID_FILS_err_write            4
#define ERRSID_FILS_err_delete           5
#define ERRSID_FILS_uncomput_sizequota   6

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef FILS_GLBL
   GLOBAL char *FILSIV_ERRS_error_message[] = 
                        { "No error happens",
                          "Generic error happens",
                          "Error opening file",
                          "Error reading from file",
                          "Error writing into the file",
                          "Error deleting",
			  "Available size cannot be computed"
                        };
#else
   GLOBAL char *FILSIV_ERRS_error_message[];
#endif


#endif
