/* ==========================================================================
   $MODULE_HEADER

      $NAME              BUFS_INTF

      $FUNCTION          interface module.

      $ROUTINE           BUFSIP_

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       08-OCT-97     AN       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef BUFS
#define BUFS BUFS


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H

#ifdef BUFS_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define BUFSID_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum BUFSIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSIC_

      $DESCRIPTION  The BUFSIC_

   $EH
   ========================================================================== */
/*   const BUFSIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSIT_io

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct BUFSIT_io_def {
      void                *Buffer;
      UINTx4               NRows;
      UINTx4               NColumns;
      LDEFIT_data_type     DataType;
   };
   typedef struct BUFSIT_io_def BUFSIT_io;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         BUFSIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_init_buffers

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Set the BUFSPV_gid global structure

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void BUFSIP_init_buffers
                       ( /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_open_buffer

        $TYPE	      PROCEDURE

        $INPUT        Buffer   : pointer to the buffer
                      NRows    : number of rows of the buffer
                      NColumns : number of columns of the buffer
                      DataType : descriptor of the type of buffer
                      mode     : mode of the buffer ( read = 'r' or write = 'w' )

        $MODIFIED     The global variable describing the buffer is filled

        $OUTPUT       chan     : channel assigned to the buffer

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_neg_dimensions
                      ERRSID_BUFS_mode_not_set
                      ERRSID_BUFS_max_chan
                      ERRSID_BUFS_not_allow_data_type

        $DESCRIPTION  This procedure fills the structure assigned to each buffer
                      and returns the first free chennel among that allowable
                      for the buffers

        $WARNING      NONE

        $PDL          - Makes the necessary checks on the parameters
                      - Checks the number of rows and columns
                      - Checks the mode of the buffer
                      - Searches for a free channel
                      - Checks the channel number
                      - Points the pointer in the structure to the buffer
                      - Fills the structure fields corresponding to the numbers
                        of rows and columns and mode
                      - Checks the buffer data type
                      - Fills the structure field of data type

   $EH
   ========================================================================== */
   extern void BUFSIP_open_buffer
                       ( /*IN    */ void                *Buffer,
                         /*IN    */ UINTx4               NRows,
                         /*IN    */ UINTx4               NColumns,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ char                 mode,
                         /*   OUT*/ UINTx4              *chan,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_close_buffer

        $TYPE	      PROCEDURE

        $INPUT        chan     : buffer channel

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_neg_dimensions
                      ERRSID_BUFS_mode_not_set
                      ERRSID_BUFS_max_chan
                      ERRSID_BUFS_not_allow_data_type

        $DESCRIPTION  This procedure fills the structure assigned to each buffer
                      and returns the first free chennel among that allowable
                      for the buffers

        $WARNING      NONE

        $PDL          - Nulls the structure field of data type

   $EH
   ========================================================================== */
   extern void BUFSIP_close_buffer
                       ( /*IN    */ UINTx4               chan,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_open_line

        $TYPE	      PROCEDURE

        $INPUT        chan        : buffer number
		      direction   : 'x' or 'y'
		      samplestart : first sample in line
		      sampleend   : last sample in line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_max_chan
                      ERRSID_BUFS_not_allow_data_type
                      ERRSID_BUFS_mode_not_set

        $DESCRIPTION  This procedure opens the reading or the writing of a line
                      buffer.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void BUFSIP_open_line
                       (/*IN    */ UINTx4               chan,
                        /*IN    */ char                 direction,
                        /*IN    */ UINTx4               samplestart,
                        /*IN    */ UINTx4               sampleend,
                        /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_read_block

        $TYPE	      PROCEDURE

        $INPUT        chan       : buffer channel
                      firstline  : first line to be read
		      lastline   : last line to read

        $MODIFIED     NONE

        $OUTPUT       buff       : double pointer to the output block

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_bad_dimensions
	              ERRSID_BUFS_err_no_block
                      ERRSID_BUFS_not_allow_data_type

        $DESCRIPTION  This procedure reads a block of lines from memory buffers.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void BUFSIP_read_block
                      ( /*IN    */ UINTx4               chan,
                        /*IN    */ UINTx4               firstline,
			/*IN    */ UINTx4               lastline,
                        /*   OUT*/ void               **buff,
                        /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_read_line

        $TYPE	      PROCEDURE

        $INPUT        chan       : buffer channel
                      linenumber : line to be read

        $MODIFIED     NONE

        $OUTPUT       bufout     : address of pointer to void buffer

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_max_chan
                      ERRSID_BUFS_not_allow_data_type

        $DESCRIPTION  This procedure reads a line from memory buffers.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void BUFSIP_read_line
                      ( /*IN    */ UINTx4               chan,
                        /*IN    */ UINTx4               linenumber,
                        /*   OUT*/ void               **bufout,
                        /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_write_line

        $TYPE	      PROCEDURE

        $INPUT        chan       : buffer channel
                      linenumber : line to be read
                      bufin      : pointer to void buffer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_BUFS_max_chan
                      ERRSID_BUFS_not_allow_data_type

        $DESCRIPTION  This procedure writes a line to buffers.

        $WARNING      NONE

        $PDL
	   -If la linea e' fuori dal buffer
	     -Salva il buffer dividendolo a blocks
	     -Aggiorna i flags relativi ai blocks salvati
	     -If tutti i blocks relativi allla linea da scrivere sono gia' 
              stati salvati 
	       -Carica i nuovi blocks relativi alla linea da scrivere
	     -Endif
	     -Aggiorna minline
	     -Ricopia la linea nel buffer
	   -Else la linea e' nel buffer
	     -Ricopia la linea nel buffer
	   -Endif                                     

   $EH
   ========================================================================== */
   extern void BUFSIP_write_line 
                       ( /*IN    */ UINTx4               chan,
                         /*IN    */ UINTx4               linenumber,
                         /*   OUT*/ void                *bufin,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         BUFSIP_close_line

        $TYPE	      PROCEDURE

        $INPUT        chan : buffer channel

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       BUFSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure close the reading or writing of a line on
                      buffers.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void BUFSIP_close_line
                       ( /*IN    */ UINTx4               chan,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         BUFSIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/*   extern void BUFSIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         BUFSIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void BUFSIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) BUFSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         BUFSIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    BUFSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define BUFSIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#ifdef __VMS__

#define ERRSID_BUFS_err_mem_alloc        2
#define ERRSID_BUFS_neg_dimensions       3
#define ERRSID_BUFS_mode_not_set         4
#define ERRSID_BUFS_max_chan             5
#define ERRSID_BUFS_not_allow_data_type  6
#define ERRSID_BUFS_bad_dimensions       7

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef BUFS_GLBL
   GLOBAL char *BUFSIV_ERRS_error_message[] = 
                        { "No error happens",                        /* 0 */
                          "Generic error happens",                   /* 1 */
                          "SYSTEM ERROR: memory allocation error",   /* 2 */
                          "Negative or null image dimension(s)",     /* 3 */
			  "The open file mode is not set",           /* 4 */
			  "Maximum number of channels reached",      /* 5 */
                          "Data type not allowed",                   /* 6 */
                          "Bad dimension(s)"                         /* 7 */
                        };
#else
   GLOBAL char *BUFSIV_ERRS_error_message[];
#endif

#else

#define ERRSID_BUFS_err_mem_alloc        2
#define ERRSID_BUFS_neg_dimensions       3
#define ERRSID_BUFS_mode_not_set         3
#define ERRSID_BUFS_max_chan             3
#define ERRSID_BUFS_not_allow_data_type  3
#define ERRSID_BUFS_bad_dimensions       3

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef BUFS_GLBL
   GLOBAL char *BUFSIV_ERRS_error_message[] = 
                        { "No error happens",                        /* 0 */
                          "Generic error happens",                   /* 1 */
                          "Memory allocation error",                 /* 2 */
                          "Memory Buffer library error happens"      /* 3 */
                        };
#else
   GLOBAL char *BUFSIV_ERRS_error_message[];
#endif

#endif

#endif
