/* ==========================================================================
   $MODULE_HEADER

      $NAME              IREG_INTF

      $FUNCTION          interface module.

      $ROUTINE           IREGIP_DRVR_Registrator

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       23-OCT-97     GRV       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef IREG
#define IREG IREG


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include TIFS_INTF_H
#include GIOS_INTF_H

#ifdef IREG_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_MaxImaNum

      $DESCRIPTION  It defines the maximum number of images that can be
                    simultaneously be opened by the co-registration tool

   $EH
   ========================================================================== */
#define IREGID_MaxImaNum   ( (UINTx4)(MAX_FILES / 2) )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_GCP_mas_num_row
                    IREGID_GCP_mas_num_col

      $DESCRIPTION  They define the default number of GCPs in the master image
                    of the co-registration

   $EH
   ========================================================================== */
#define IREGID_GCP_mas_num_row     5
#define IREGID_GCP_mas_num_col     10

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_coarse_cell_dim_row
                    IREGID_coarse_cell_dim_col

      $DESCRIPTION  They define the default sizes of the image cells for the
                    coarse co-registration

   $EH
   ========================================================================== */
#define IREGID_coarse_cell_dim_row   51
#define IREGID_coarse_cell_dim_col   51

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_max_coarse_shift

      $DESCRIPTION  The minimum value of the tollerable shift for the stability
                    test in the coarse registration procedure

   $EH
   ========================================================================== */
#define IREGID_max_coarse_shift   ( (float)1.1 )

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_fine_cell_dim_row
                    IREGID_fine_cell_dim_col

      $DESCRIPTION  They define the default sizes of the image cells for the
                    fine co-registration

   $EH
   ========================================================================== */
#define IREGID_fine_cell_dim_row   51
#define IREGID_fine_cell_dim_col   51

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_coher_wsiz

      $DESCRIPTION  It defines the default size of the image cell for the
                    coherence maximization

   $EH
   ========================================================================== */
#define IREGID_coher_wsiz   3

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_interp_win_size

      $DESCRIPTION  It defines the default size of the image cell for the
                    final interpolation

   $EH
   ========================================================================== */
#define IREGID_interp_win_size   1024

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_int_fact_row
                    IREGID_int_fact_col

      $DESCRIPTION  They define the default  values of the interpolation
                    factors in the coarse registration

   $EH
   ========================================================================== */
#define IREGID_int_fact_row   1.
#define IREGID_int_fact_col   1.

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_coher_ftol

      $DESCRIPTION  It defines the tolerance value of the function to
                    maximize

   $EH
   ========================================================================== */
#define IREGID_coher_ftol   1.e-06

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_coher_vtol

      $DESCRIPTION  It defines the tolerance value of the coordinates in the
                    coherence maximization

   $EH
   ========================================================================== */
#define IREGID_coher_vtol   1.e-03

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_warp_deg

      $DESCRIPTION  It defines the default warp degree in the co-registration

   $EH
   ========================================================================== */
#define IREGID_warp_deg   2

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_over_mode

      $DESCRIPTION  It defines the default overlapping mode in the co-
                    registration

   $EH
   ========================================================================== */
#define IREGID_over_mode   "MASTER"

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_baseline_fname

      $DESCRIPTION  It defines the default baseline file name

   $EH
   ========================================================================== */
#define IREGID_baseline_fname "baseline.txt"

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_interp_mode

      $DESCRIPTION  It defines the default interpolation mode in the image
                    co-registration

   $EH
   ========================================================================== */
#define IREGID_interp_mode   "CUBIC CONVOLUTION"

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_interp_prec

      $DESCRIPTION  It defines the default value for the length of the sinc 
                    or the cubic conv used in the interpolation of the
                    co-registration

   $EH
   ========================================================================== */
#define IREGID_interp_prec   1000

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_sinc_width

      $DESCRIPTION  It defines the default value for the width of the sinc 
                    used in the interpolation of the co-registration

   $EH
   ========================================================================== */
#define IREGID_sinc_width    7

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_cubconv_coeff

      $DESCRIPTION  It defines the default value for the cubic convolution
                    coefficient. The ERDAS value is -1

   $EH
   ========================================================================== */
#define IREGID_cubconv_coeff  -1.0

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGID_max_point_RMS

      $DESCRIPTION  It defines the RMS maximum value that a GCP can reach
                    after warp evaluation

   $EH
   ========================================================================== */
#define IREGID_max_point_RMS  ( (double)2. )

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum IREGIE_
*/

/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGIT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct IREGIT_*_def { 

   typedef struct IREGIT_*_def IREGIT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGIV_ima_num

      $DESCRIPTION  They contains the number of images to co-register

   $EH
   ========================================================================== */
   GLOBAL UINTx1 IREGIV_ima_num;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IREGIV_FineRegFlag

      $DESCRIPTION  They contains the character indicating the on / off choice
                    for the fine registration

   $EH
   ========================================================================== */
#ifdef IREG_GLBL
   GLOBAL char IREGIV_FineRegFlag = 'N';
#else
   GLOBAL char IREGIV_FineRegFlag;
#endif

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGIP_DRVR_Registrator

        $TYPE         PROCEDURE

        $INPUT        inp_io               : array with the input files
                                             descriptors
                      out_fnames           : array with the output files
                                             names
                      NImages              : number of images
                      NGCPRow              : number of GCP in the rows direction
                      NGCPCol              : number of GCP in the columns
                                             direction
                      GCPFileName          : name of the ASCII file with the
                                             master GCPs written ( optional )
                                             for GCP overriding
                      ResidFileName        : name of the file that will contain
                                             the GCPs residual
                      row_coarse_cell_size : cell size in the rows direction for
                                             the coarse registration
                      col_coarse_cell_size : cell size in the columns direction
                                             for the coarse registration
                      int_fact_row         : interpolation factor in the rows
                                             direction for the coarse
                                             registration
                      int_fact_col         : interpolation factor in the columns
                                             direction for the coarse
                                             registration
                      row_fine_cell_size   : cell size in the rows direction for
                                             the fine registration
                      col_fine_cell_size   : cell size in the columns direction
                                             for the fine registration
                      coher_wsiz           : window size for the coherence
                                             evaluation in the fine registration
                      coher_ftol           : tolerance for the function value
                                             in the iteratively evaluation of
                                             the coherence
                      coher_vtol           : tolerance for the coordinates
                                             values in the iteratively
                                             evaluation of the coherence
                      degree               : flag indicating the degree of the
                                             warp matrices
                      OverMode             : flag indicating the overlapping
                                             mode to determinate the output
                                             layover
                      IntRowWinSize        : interpolation window size in the
                                             rows direction
                      IntColWinSize        : interpolation window size in the
                                             columns direction
                      InterpMode           : flag indicating the interpolation
                                             mode
                      BaselineFileName     : name of the file that will contain
                                             the baseline evaluated info
                      SincWidth            : sinc elements
                      InterpPrec           : interpolation table length
                      CubConvCoeff         : coefficient of the cubic
                                             convolution function
                      CoarseMaxTol         : tolerance value for the coarse
                                             registration stability test
                      maxPointRMS          : maximum residual value for GCPs
                                             editing

        $MODIFIED     TLRow                : top left row coordinate of the
                                             input AoI
                      TLCol                : top left column coordinate of
                                             the input AoI
                      BRRow                : bottom right row coordinate of
                                             the input AoI
                      BRCol                : bottom right column coordinate
                                             of the input AoI

        $OUTPUT       out_io               : array with the output files
                                             descriptors

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This is the driver procedure for the image co-registrator

        $WARNING      THE OUTPUT IMAGES ARE OPENED IN THIS PROCEDURE BUT MUST
                      BE CLOSED OUT OF IT TO ALLOW THE TAG UPDATING AND WRITING

        $PDL          - Initializes the GCPs evaluation procedures
                      - Evaluates the GCPs on the images
                      - Initializes the warp matrices
                      - Evaluates the warp matrices
                      - If the overlapping mode have been set
                            - Evaluates the output layover WRT the overlapping
                              mode selected
                      - Else
                            - Copies the input corners into the output ones
                      - End If
                      - Interpolates the input images into the output layout
                        and writes them in the output files
                      - Opens the baselines file
                      - Evaluates the baselines
                      - Closes the baselines file
                      - Closes the warp related structures
                      - Closes all the GCPs structures INFO

   $EH
   ========================================================================== */
   extern void IREGIP_DRVR_Registrator
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ FILSIT_file_name    *out_fnames,
                         /*IN    */ INTx4                NImages,
                         /*IN    */ INTx4                NGCPRow,
                         /*IN    */ INTx4                NGCPCol,
                         /*IN    */ char                *GCPFileName,
                         /*IN    */ char                *ResidFileName,
                         /*IN    */ INTx4                row_coarse_cell_size,
                         /*IN    */ INTx4                col_coarse_cell_size,
                         /*IN    */ float                int_fact_row,
                         /*IN    */ float                int_fact_col,
                         /*IN    */ INTx4                row_fine_cell_size,
                         /*IN    */ INTx4                col_fine_cell_size,
                         /*IN    */ INTx2                coher_wsiz,
                         /*IN    */ double               coher_ftol,
                         /*IN    */ double               coher_vtol,
                         /*IN    */ UINTx1               degree,
                         /*IN    */ UINTx1               OverMode,
                         /*IN    */ INTx4                IntRowWinSize,
                         /*IN    */ INTx4                IntColWinSize,
                         /*IN    */ UINTx1               InterpMode,
                         /*IN    */ FILSIT_file_name     BaselineFileName,
                         /*IN    */ INTx4                SincWidth,
                         /*IN    */ INTx4                InterpPrec,
                         /*IN    */ float                CubConvCoeff,
                         /*IN    */ float                CoarseMaxTol,
                         /*IN    */ float                maxPointRMS,
                         /*IN OUT*/ INTx4               *TLRow,
                         /*IN OUT*/ INTx4               *TLCol,
                         /*IN OUT*/ INTx4               *BRRow,
                         /*IN OUT*/ INTx4               *BRCol,
                         /*   OUT*/ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IREGIP_COHE_OverlapAndSave

        $TYPE         PROCEDURE

        $INPUT        inp_io    : array of descriptors of the input files
                      out_io    : pointer to the descriptor of the output file
                      TLRow     : row coordinate of the top left images corner
                      TLCol     : column coordinate of the top left images
                                  corner
                      NRow      : number of rows of the input and of the output
                                  images
                      NCol      : number of columns of the input and of the
                                  output images
                      WinSize   : window sizes for the coherence evaluation

        $MODIFIED     NONE

        $OUTPUT       The output file is filled

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IREG_ima_not_comp
                      ERRSID_IREG_null_ima_dim
                      ERRSID_IREG_kernel_dim_high

        $DESCRIPTION  This procedure fills the coherence image starting from
                      two co-registered ones. The evaluation has step 1 and
                      a window size user defined

        $WARNING      NONE

        $PDL          - Checks the input parameters
                      - Evaluates the reading window row size regarding to the
                        allowable memory on the machine
                      - Allocates the input images blocks and the output image
                        array
                      - Opens the lines for the input and the output files
                      - Sets the utility variables and counters
                      - Zeroes the output array
                      - Loop over the rows for the first half window size of
                        the output image
                            - Writes the empty lines border in the output
                              image
                            - Updates the writing row counter
                      - End Loop
                      - While the window can be read from the file
                            - Reads the input images blocks
                            - Calls the core function
                            - Updates the starting counter
                      - End While
                      - If it is possible read a number of rows greather then
                        the window size
                            - Reads the input images blocks
                            - Calls the core function
                      - End If
                      - Zeroes the output array
                      - Loop over the rows for the last half window size of
                        the output image
                            - Writes the empty lines border in the output
                              image
                            - Updates the writing row counter
                      - End Loop
                      - Closes the lines for the input and the output files
                      - Frees the allocated memories

   $EH
   ========================================================================== */
   extern void IREGIP_COHE_OverlapAndSave
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               NRow,
                         /*IN    */ UINTx4               NCol,
                         /*IN    */ UINTx4               RowWinSize,
                         /*IN    */ UINTx4               ColWinSize,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IREGIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void IREGIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) IREGIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IREGIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    IREGIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define IREGIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_IREG_err_mem_alloc        2
#define ERRSID_IREG_TEST_ERROR           3
#define ERRSID_IREG_image_number_out     4
#define ERRSID_IREG_GCP_num_invalid      5
#define ERRSID_IREG_ima_num_inv          6
#define ERRSID_IREG_grid_number_out      7
#define ERRSID_IREG_null_cell_dim        8
#define ERRSID_IREG_data_type_not_allow  9
#define ERRSID_IREG_cell_dim_out        10
#define ERRSID_IREG_no_enlarge_zp       11
#define ERRSID_IREG_no_complex_out      12
#define ERRSID_IREG_low_cell_dim        13
#define ERRSID_IREG_warp_deg_not_allow  14
#define ERRSID_IREG_insuff_GCPs         15
#define ERRSID_IREG_no_elem_GCP         16
#define ERRSID_IREG_err_read_GCP_file   17
#define ERRSID_IREG_insuff_n_points     18
#define ERRSID_IREG_null_dimensions     19
#define ERRSID_IREG_warp_not_create     20
#define ERRSID_IREG_degree_undef        21
#define ERRSID_IREG_int_fact            22
#define ERRSID_IREG_coher_wsiz_null     23
#define ERRSID_IREG_over_mode_undef     24
#define ERRSID_IREG_incons_corn         25
#define ERRSID_IREG_win_too_large       26
#define ERRSID_IREG_inter_not_def       27
#define ERRSID_IREG_over_mode_not_allow 28
#define ERRSID_IREG_warp_not_good       29
#define ERRSID_IREG_ima_size_too_large  30
#define ERRSID_IREG_col_range_err       31
#define ERRSID_IREG_kernel_dim_high     32
#define ERRSID_IREG_bad_steps           33
#define ERRSID_IREG_bad_write_size      34
#define ERRSID_IREG_ima_not_comp        35
#define ERRSID_IREG_null_ima_dim        36
#define ERRSID_IREG_null_win_size       37
#define ERRSID_IREG_null_neg_val        38
#define ERRSID_IREG_few_sinc_elem       39
#define ERRSID_IREG_null_table_length   40
#define ERRSID_IREG_math_err            41

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef IREG_GLBL
   GLOBAL char *IREGIV_ERRS_error_message[] = 
                  { "No error happens",                                  /* 0 */
                    "Generic error happens",                             /* 1 */
                    "SYSTEM ERROR: memory allocation error",             /* 2 */
                    "TEST ERROR",                                        /* 3 */
                    "Image ID out of range",                             /* 4 */
                    "Invalid GCPs number required",                      /* 5 */
                    "Invalid number of images",                          /* 6 */
                    "Master grid ID out of range",                       /* 7 */
                    "Cell dimension(s) null",                            /* 8 */
                    "Data type not allowed",                             /* 9 */
                    "Cell dimension(s) out of range",                   /* 10 */
                    "No enlargment required in the zero padding",       /* 11 */
                    "Input array not of complex type",                  /* 12 */
                    "Cell dimension(s) too low",                        /* 13 */
                    "Warp degree not allowed",                          /* 14 */
                    "Insufficient number of GCP(s) for the slave num.", /* 15 */
                    "No elements in the GCPs file",                     /* 16 */
                    "Error reading the GCPs file",                      /* 17 */
                    "Insufficient number of border points",             /* 18 */
                    "Null image dimensions",                            /* 19 */
                    "The warp matrices have not been created",          /* 20 */
                    "The degree is not defined",                        /* 21 */
                    "Interpolation factor lesser then 1",               /* 22 */
                    "Coherence window size null",                       /* 23 */
                    "Overlapping mode not defined",                     /* 24 */
                    "Inconsistent corners",                             /* 25 */
                    "Window size(s) greather then the AoI",             /* 26 */
                    "Interpolation mode not defined",                   /* 27 */
                    "Overlapping mode not allowed",                     /* 28 */
                    "Warp matrix not good",                             /* 29 */
                    "Image cell sizes too large",                       /* 30 */
                    "Column coordinate out of image",                   /* 31 */
                    "Window dimensions too high",                       /* 32 */
                    "Steps sizes not good for coherence generation",    /* 33 */
                    "Bad writing counters",                             /* 34 */
                    "Images incompatible for coherence generation",     /* 35 */
                    "Null image(s) dimension(s)",                       /* 36 */
                    "Null or negative window size(s)",                  /* 37 */
                    "Negative or null value(s)",                        /* 38 */
                    "Few sinc elements",                                /* 39 */
                    "Null table length for the interpolation",          /* 40 */
                    "Mathematical Error",                               /* 41 */
                  };
#else
   GLOBAL char *IREGIV_ERRS_error_message[];
#endif


#endif
