/* ==========================================================================
   $MODULE_HEADER

      $NAME              GIOS_INTF

      $FUNCTION          General IO interface module.

      $ROUTINE           GIOSIP_init
                         GIOSIP_open_io
                         GIOSIP_close_io
                         GIOSIP_open_line
                         GIOSIP_read_block
                         GIOSIP_read_line
                         GIOSIP_write_line
                         GIOSIP_close_line

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       08-OCT-97     AN       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef GIOS
#define GIOS GIOS


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include BUFS_INTF_H
#include FILS_INTF_H
#include DEVS_INTF_H
#include TIFS_INTF_H

#ifdef GIOS_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         GIOSID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define GIOSID_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         GIOSIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
   

/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         GIOSIC_

      $DESCRIPTION  The GIOSIC_

   $EH
   ========================================================================== */
/*   const GIOSIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         GIOSIT_type

      $DESCRIPTION  Enumerated for different IO types

   $EH
   ========================================================================== */
   enum GIOSIE_type {
      GIOSIE_buffer,
      GIOSIE_tif,
      GIOSIE_device,
      GIOSIE_file
   };
   typedef enum GIOSIE_type GIOSIT_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         GIOSIT_io

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct GIOSIT_io_def { 
      GIOSIT_type           type;
      char		    mode;
      UINTx4                chan;
      INTx4                 img;
      UINTx2                bps;
      UINTx2                spp;
      UINTx2                spf;
      LDEFIT_data_type      dt;
      union {
         BUFSIT_io          buff;
         TIFSIT_io          tif;
         DEVSIT_io          exa;
         FILSIT_io          fil;
      } val;
   };

   typedef struct GIOSIT_io_def GIOSIT_io;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         GIOSIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_init

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Set the global structure

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void GIOSIP_init
                       ( /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_open_io

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     io   :   structure containing IO info

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_GIOS_not_supported_io

        $DESCRIPTION  This routine open an IO

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_open_io

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     io   :   structure containing IO info

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_GIOS_not_supported_io

        $DESCRIPTION  This routine open an IO

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void GIOSIP_open_io
                       ( /*IN OUT*/ GIOSIT_io           *io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_close_io

        $TYPE	      PROCEDURE

        $INPUT        NONE

        $MODIFIED     io   :   structure containing IO info

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine close an IO.

        $WARNING      NONE

        $PDL          

   $EH
   ========================================================================== */
   extern void GIOSIP_close_io
                       ( /*IN OUT*/ GIOSIT_io           *io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_open_line

        $TYPE	      PROCEDURE

        $INPUT        io          : io descriptor
		      direction   : 'x' or 'y'
		      samplestart : first sample in line
		      sampleend   : last sample in line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   

        $DESCRIPTION  This procedure opens the reading or the writing of a line.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void GIOSIP_open_line
                       (/*IN    */ GIOSIT_io           *io,
                        /*IN    */ char                 direction,
                        /*IN    */ UINTx4               samplestart,
                        /*IN    */ UINTx4               sampleend,
                        /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_read_block

        $TYPE	      PROCEDURE

        $INPUT        io         : io descriptor
                      firstline  : first line to be read
		      lastline   : last line to read

        $MODIFIED     NONE

        $OUTPUT       buff       : double pointer to the output block

        $GLOBAL       GIOSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   ERRSID_GIOS_bad_dimensions
	              ERRSID_GIOS_err_no_block
                      ERRSID_GIOS_not_allow_data_type

        $DESCRIPTION  This procedure reads a block of lines from memory buffers.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void GIOSIP_read_block
                      ( /*IN    */ GIOSIT_io           *io,
                        /*IN    */ UINTx4               firstline,
			/*IN    */ UINTx4               lastline,
                        /*IN    */ INTx4                data_size,
                        /*IN    */ DATA_TYPEIT          outtype,
                        /*   OUT*/ void               **buff,
                        /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_read_line

        $TYPE	      PROCEDURE

        $INPUT        io         : io descriptor
                      linenumber : line to be read
                      datasize   : size of record for devices

        $MODIFIED     NONE

        $OUTPUT       bufout     : address of pointer to void buffer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure reads a line (next line for devices).

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void GIOSIP_read_line
                      ( /*IN    */ GIOSIT_io           *io,
                        /*IN    */ UINTx4               linenumber,
                        /*IN    */ INTx4                data_size,
                        /*   OUT*/ void               **bufout,
                        /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_write_line

        $TYPE	      PROCEDURE

        $INPUT        io         : io descriptor
                      linenumber : line to be written
                      bufin      : pointer to void buffer

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure writes a line.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void GIOSIP_write_line 
                       ( /*IN    */ GIOSIT_io           *io,
                         /*IN    */ UINTx4               linenumber,
                         /*   OUT*/ void                *bufin,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         GIOSIP_close_line

        $TYPE	      PROCEDURE

        $INPUT        io          : io descriptor

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       GIOSPV_gid[ chan ] : the structure array with the buffer
                                           descriptor

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure close the reading or writing of a line on
                      buffers.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void GIOSIP_close_line
                       ( /*IN    */ GIOSIT_io           *io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         GIOSIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/*   extern void GIOSIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         GIOSIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void GIOSIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) GIOSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         GIOSIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    GIOSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define GIOSIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_GIOS_err_mem_alloc        2
#define ERRSID_GIOS_not_supported_io     3
#define ERRSID_GIOS_not_supported_dt     4
#define ERRSID_GIOS_err_line             5

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef GIOS_GLBL
   GLOBAL char *GIOSIV_ERRS_error_message[] = 
                        { "No error happens",                        /* 0 */
                          "Generic error happens",                   /* 1 */
                          "SYSTEM ERROR: memory allocation error",   /* 2 */
                          "Mode not supported",                      /* 3 */
                          "Data type not supported",                 /* 4 */
                          "Line error"                               /* 5 */
                        };
#else
   GLOBAL char *GIOSIV_ERRS_error_message[];
#endif

#endif
