/* ==========================================================================
   $MODULE_HEADER

      $NAME              IRES_INTF

      $FUNCTION          IMAGE RESAMPLING interface module.

      $ROUTINE           IRESIP_OVER_Interpolate
                         IRESIP_OVER_DoppCentFreqEval
                         IRESIP_OVER_FdcToIndx
                         IRESIP_OVER_InterpolateRowCol
                         IRESIP_OVER_InterpolateRow
                         IRESIP_OVER_InterpolateCol
		         IRESIP_UNDR_Interpolate
                         IRESIP_UNDR_ConvCore
                         IRESIP_UNDR_ConvCoreConstKern
                         IRESIP_UNDR_OverlapAndSave
                         IRESIF_UNDR_Convol
                         IRESIF_UNDR_ConstConvol
			 IRESIP_UNDR_ReadFilter

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       09-MAY-97     GRV       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef IRES
#define IRES IRES


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include GIOS_INTF_H
#include OVLS_INTF_H

#ifdef IRES_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IRESID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define IRESID_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IRESIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum IRESIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IRESIC_

      $DESCRIPTION  The IRESIC_

   $EH
   ========================================================================== */
/*   const IRESIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IRESIV_FilterSizeRow
		    IRESIV_FilterSizeCol

      $DESCRIPTION  These variables describe the filter size in the row and
		    column direction. They're initialized to 1

   $EH
   ========================================================================== */
#ifdef IRES_GLBL
   UINTx2		  IRESIV_FilterSizeRow = 1;
   UINTx2		  IRESIV_FilterSizeCol = 1;
#else
   GLOBAL UINTx2	  IRESIV_FilterSizeRow;
   GLOBAL UINTx2	  IRESIV_FilterSizeCol;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         IRESIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_OVER_Interpolate

        $TYPE         PROCEDURE

        $INPUT        inp_io  	: structure with the IO parameters of the
                                  input image
                      imanum	: number identifing the image in the tool
                      TLRow	: the top left row image coordinate of the 
                                  image pixel in the full reference frame
                      TLCol	: the top left column image coordinate of the 
                                  image pixel in the full reference frame
                      nrow_inp	: number of rows of the input image
                      ncol_inp	: number of columns of the input image
                      out_io    : structure with the IO parameters of the
                                  output image
                      nrow_out	: number of rows of the output interpolated
                                  image
                      ncol_out	: number of columns of the output interpolated
                                  image
                      tmp_io    : structure with the IO parameters of the
                                  intermediate image

        $MODIFIED     The output image file is filled with the interpolated
                      image

        $OUTPUT       

        $GLOBAL       IANNID_IRES   : the flag that indicates the tool type

        $RET_STATUS   ERRSID_IRES_fact_not_good
                      ERRSID_IRES_no_undersampling
                      ERRSID_IRES_no_interp_req
                      ERRSID_IRES_start_stop_col_err
                      ERRSID_IRES_err_mem_alloc
                      ERRSID_IRES_log_vol_id_undef

        $DESCRIPTION  This procedure is the main one for the oversampling task

        $WARNING      NONE

        $PDL          - Evaluate the doppler centroide frequencies for all the
                        columns of the required subimage
                      - Transform the doppler centroide frequencies in spectrum
                        index
                      - Interpolate the image

   $EH
   ========================================================================== */
   extern void IRESIP_OVER_Interpolate
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN OUT*/ GIOSIT_io           *tmp_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   
        $NAME         IRESIP_OVER_InterpolateRowCol

        $TYPE         PROCEDURE

        $INPUT        inp_io  	: structure with the IO parameters of the
                                  input image
                      nrow_inp	: number of rows of the input image to
                                  interpolate
                      ncol_inp	: number of columns of the input image to
                                  interpolate
                      nrow_out	: number of rows of the output interpolated
                                  image
                      ncol_out	: number of columns of the output interpolated
                                  image
                      TLRow	: the row image coordinate of the first image
                                  pixel in the full reference frame
                      TLCol	: the column image coordinate of the first image
                                  pixel in the full reference frame
                      min_indx	: array of indices of the minimum spectrum
                                  values
                      out_io    : structure with the IO parameters of the
                                  output image
                      tmp_io    : structure with the IO parameters of the
                                  intermediate image

        $MODIFIED     The output file filled with the interpolated image

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the image
                                                  annotations of the imanum
                                                  image

        $RET_STATUS   ERRSID_IRES_indx_array_empty
                      ERRSID_IRES_incorrect_rows_cols
                      ERRSID_IRES_no_undersampling
                      ERRSID_IRES_incorrect_rows_cols
                      ERRSID_IRES_err_mem_alloc
                      ERRSID_IRES_data_type_not_allow
                      ERRSID_IRES_not_allowed_prod

        $DESCRIPTION  This procedure interpolates the input image with the
                      FFT and zero-padding method

        $WARNING      The input and the output files must be only opened before
                      the calling of this procedure. The opening of the read or
                      the write mode and subsequent operations must be done in
                      the procedure

   ========================================================================== */
   extern void IRESIP_OVER_InterpolateRowCol
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ UINTx4              *min_indx,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN OUT*/ GIOSIT_io           *tmp_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_OVER_DoppCentFreqEval

        $TYPE         PROCEDURE

        $INPUT        imanum	: the number identified the image among all
                                  that treated in the tool
                      start_col	: the actual starting column of the image in
                                  the full resolution image
                      stop_col	: the actual last column of the image in the
                                  full resolution image

        $MODIFIED     NONE

        $OUTPUT       fdc	: the array with the doppler centroid
                                  frequencies evaluated

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the image annotation
                                                  structure
                      CVEL	: speed of ligth definition

        $RET_STATUS   ERRSID_IRES_imanum_not_allow
                      ERRSID_IRES_start_stop_col_err

        $DESCRIPTION  This procedure evaluates the doppler centroid frequencies
                      of the image numerated by <imanum> for the columns indices
                      starting with start_col and ending with stop_col

        $WARNING      The column indices passed in input are in the full
                      reference frame

        $PDL          - Start a column loop
                            - Evaluate the acquisition time corresponding to
                              the current column
                            - Evaluate the frequency corresponding to the
                              current column
                      - End loop

   $EH
   ========================================================================== */
   extern void IRESIP_OVER_DoppCentFreqEval
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ INTx4                start_col,
                         /*IN    */ INTx4                stop_col,
                         /*   OUT*/ double              *fdc,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_OVER_FdcToIndx

        $TYPE	      PROCEDURE

        $INPUT        imanum	: the number with which the image is identified
                                  among the others of the tool
                      fdc	: the pointer to the array with the doppler
                                  centroid frequency
                      fdc_len	: the length of the fdc array
                      fftlen	: the normalizing factor (it's the length of the
                                  array of which the FFT must be evaluated with
                                  the zero padding at the index that must be
                                  evaluated by the procedure 
                      

        $MODIFIED     NONE

        $OUTPUT       min_indx	: the array index of the spectrum at which the
                                  minimum is reached

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the global variable containing
                                                  the image annotations of the
                                                  imanum image

        $RET_STATUS   ERRSID_IRES_imanum_not_allow
                      ERRSID_IRES_neg_size_par
                      ERRSID_IRES_not_allowed_prod

        $DESCRIPTION  This procedure evaluates from the doppler centroid
                      frequency the corresponding index in the spectrum

        $WARNING      NONE

        $PDL          - Evaluates the Fdc in the range -PRF/2, PRF/2
                      - Rescale the Fdc to the index in the range
                        -fftlen/2,fftlen/2
                      - Evaluate the index in the spectrum

   $EH
   ========================================================================== */
   extern void IRESIP_OVER_FdcToIndx
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ double              *fdc,
                         /*IN    */ UINTx4               fdc_len,
                         /*IN    */ UINTx4               fftlen,
                         /*   OUT*/ UINTx4              *min_indx,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   
        $NAME         IRESIP_OVER_InterpolateRowCol

        $TYPE         PROCEDURE

        $INPUT        inp_io  	: structure with the IO parameters of the
                                  input image
                      nrow_inp	: number of rows of the input image to
                                  interpolate
                      ncol_inp	: number of columns of the input image to
                                  interpolate
                      nrow_out	: number of rows of the output interpolated
                                  image
                      ncol_out	: number of columns of the output interpolated
                                  image
                      TLRow	: the row image coordinate of the first image
                                  pixel in the full reference frame
                      TLCol	: the column image coordinate of the first image
                                  pixel in the full reference frame
                      min_indx	: array of indices of the minimum spectrum
                                  values
                      out_io    : structure with the IO parameters of the
                                  output image
                      tmp_io    : structure with the IO parameters of the
                                  intermediate image

        $MODIFIED     The output file filled with the interpolated image

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the image
                                                  annotations of the imanum
                                                  image

        $RET_STATUS   ERRSID_IRES_indx_array_empty
                      ERRSID_IRES_incorrect_rows_cols
                      ERRSID_IRES_no_undersampling
                      ERRSID_IRES_incorrect_rows_cols
                      ERRSID_IRES_err_mem_alloc
                      ERRSID_IRES_data_type_not_allow
                      ERRSID_IRES_not_allowed_prod

        $DESCRIPTION  This procedure interpolates the input image with the
                      FFT and zero-padding method

        $WARNING      The input and the output files must be only opened before
                      the calling of this procedure. The opening of the read or
                      the write mode and subsequent operations must be done in
                      the procedure

   ========================================================================== */
   extern void IRESIP_OVER_InterpolateRowCol
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ UINTx4              *min_indx,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN OUT*/ GIOSIT_io           *tmp_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_OVER_InterpolateRow

        $TYPE         PROCEDURE

        $INPUT        inp_chan	: channel of the opened TIFF input file
                      inp_img	: number of the image in the input TIFF file
                      inp_bpar	: structure with the basic parameters of the
                                  input image
                      nrow_inp	: number of rows of the input image to
                                  interpolate
                      ncol_inp	: number of columns of the input image to
                                  interpolate
                      ncol_out	: number of columns of the output interpolated
                                  image
                      TLRow	: the row image coordinate of the first image
                                  pixel in the full reference frame
                      TLCol	: the column image coordinate of the first image
                                  pixel in the full reference frame
                      out_chan	: channel of the opened output TIFF file that
                                  will contain the interpolated output image
                      out_img	: number of the output image in the output
                                  TIFF file
                      out_bpar  : structure with the basic parameters of the
                                  output image

        $MODIFIED     The output file filled with the interpolated image

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_incorrect_rows_cols
                      ERRSID_IRES_no_undersampling
                      ERRSID_IRES_err_mem_alloc

        $DESCRIPTION  This procedure interpolates the input image with the
                      FFT and zero-padding method in the rows direction

        $WARNING      The input and the output files must be only opened before
                      the calling of this procedure. The opening of the read or
                      the write mode and subsequent operations must be done in
                      the procedure

        $PDL          - Open the read mode for the input file
                      - Open the write mode for the output file
                      - Makes the interpolation for each row
                      - Close the write mode for the output file
                      - Close the read mode for the input file

   $EH
   ========================================================================== */
   extern void IRESIP_OVER_InterpolateRow
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_OVER_InterpolateCol

        $TYPE         PROCEDURE


        $INPUT        inp_chan	: channel of the opened TIFF input file
                      inp_img	: number of the image in the input TIFF file
                      inp_bpar	: structure with the basic parameters of the
                                  input image
                      nrow_inp	: number of rows of the input image to
                                  interpolate
                      ncol_inp	: number of columns of the input image to
                                  interpolate
                      nrow_out	: number of rows of the output interpolated
                                  image
                      TLRow	: the row image coordinate of the first image
                                  pixel in the full reference frame
                      TLCol	: the column image coordinate of the first image
                                  pixel in the full reference frame
                      min_indx	: array of indices of the minimum spectrum
                                  values
                      out_chan	: channel of the opened output TIFF file that
                                  will contain the interpolated output image
                      out_img	: number of the output image in the output
                                  TIFF file
                      out_bpar  : structure with the basic parameters of the
                                  output image

        $MODIFIED     The output file filled with the interpolated image

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_indx_array_empty
                      ERRSID_IRES_incorrect_rows_cols
                      ERRSID_IRES_no_undersampling
                      ERRSID_IRES_err_mem_alloc

        $DESCRIPTION  This procedure interpolates the input image with the
                      FFT and zero-padding method in the columns direction

        $WARNING      The input and the output files must be only opened before
                      the calling of this procedure. The opening of the read or
                      the write mode and subsequent operations must be done in
                      the procedure

        $PDL          - Open the read mode for the input file
                      - Open the write mode for the output file
                      - Makes the interpolation by column
                      - Close the write mode for the output file
                      - Close the read mode for the input file

   $EH
   ========================================================================== */
   extern void IRESIP_OVER_InterpolateCol
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4              *min_indx,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_UNDR_Interpolate

        $TYPE         PROCEDURE

        $INPUT        inp_chan	    : channel of the TTIFF file containing the
				      input image
                      inp_img	    : ID of the input image in the input file
                      inp_bpar	    : descriptor of the basic input parameters
                      imanum	    : ID of the input image among that of the
				      tool
                      TLRow	    : row coordinate of the top left pixel of
				      the input image to filter
                      TLCol	    : column coordinate of the top left pixel of
				      the input image to filter
                      nrow_inp	    : number of rows of the input image
                      ncol_inp	    : number of columns of the input image
                      nrow_out	    : number of rows of the output image
                      ncol_out	    : number of columns of the output image
                      kern_filename : name of the file containing the kernel
				      matrix to convolve with the input image
                      out_chan	    : channel of the file that will contain the
				      output filtered image
                      out_img	    : ID of the output image in the output file

        $MODIFIED     NONE

        $OUTPUT       The file that will contain the output filtered image is
		      filled

        $GLOBAL       IANNIV_ImageAnnot[imanum]	: the structure with the image
						  annotations of the <imanum>
						  image

        $RET_STATUS   ERRSID_IRES_imanum_not_allow
                      ERRSID_IRES_not_under_allow
                      ERRSID_IRES_start_stop_col_err
		      ERRSID_IRES_bad_kernel_dim
                      ERRSID_IRES_kernel_dim_high
		      ERRSID_IRES_no_over
                      ERRSID_IRES_err_mem_alloc

        $DESCRIPTION  This procedure undersamples the input image convolving it
		      with an user defined kernel.

        $WARNING      The input and the output TTIFF files must be initialized
		      and opened before calling the procedure

        $PDL	      - Make all the checks on the input parameters
		      - Read the kernel from the kernel file
		      - Make some consistency checks on the kernel sizes
		      - Check if the kernel is a constant one
		      - Interpolate the image

   $EH
   ========================================================================== */
   extern void IRESIP_UNDR_Interpolate
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               imanum,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               nrow_out,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ char                *kern_filename,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_UNDR_ConvCore

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI

        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_kernel_dim_high
		      ERRSID_IRES_bad_steps
		      ERRSID_IRES_bad_write_size
		      ERRSID_IRES_err_mem_alloc
		      ERRSID_IRES_not_under_allow

        $DESCRIPTION  This procedure convolves the kernel given in input with
                      the image block also given and writes the output in the
                      file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
                                        - Convolve the image block with the
                                          kernel
                                        - Fill the output vector
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */
   extern void IRESIP_UNDR_ConvCore
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_UNDR_ConvCoreConstKern

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI

        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_kernel_dim_high
		      ERRSID_IRES_bad_steps
		      ERRSID_IRES_bad_write_size
		      ERRSID_IRES_err_mem_alloc
		      ERRSID_IRES_not_under_allow

        $DESCRIPTION  This procedure convolves the constant kernel given in
		      input with the image block also given and writes the
		      output in the file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
                                        - Sum the window element
                                        - Fill the output vector rescaling it
					  by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */
   extern void IRESIP_UNDR_ConvCoreConstKern
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIP_UNDR_ReadFilter

        $TYPE         PROCEDURE

        $INPUT        kern_filename : name of the ASCII file to be read

        $MODIFIED     NONE

        $OUTPUT       Kern	    : pointer to the pointer to the matrix that
				      will return filled
		      Kr	    : number of rows of the matrix
		      Kc	    : number of columns of the matrix

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_IRES_error_read_kern
                      ERRSID_IRES_no_elem_kern
                      ERRSID_IRES_kern_spec_not_good
                      ERRSID_IRES_err_mem_alloc

        $DESCRIPTION  This procedure read an ASCII file containing a matrix of
		      floating point objects returning also its number of rows
		      and columns

        $WARNING      - The only consistency required on the read values is that
			the number of rows is equals to the number of file rows
			and the number of columns is the same of the first row
			written in the file.
		      - The matrix can be written also as a row and a column.
			The procedure returns, in this case, the matrix product
			of the two vectors
		      - The kernel matrix is allocated in this procedure but
			must be deallocated in the caller of it

        $PDL	      - Open the kernel file name
		      - Read the first line
		      - Count the number of kernel columns
		      - Read the second line
		      - IF the kernel is a 2D matrix
			   - Loop overl the matrix rows
				 - Loop over the columns elements
				       - Fill the matrix element
				 - End loop
			   - End loop
		      - End IF
		      - ELSE IF there are two 1D vectors
			   - Fill the row vector
			   - Loop over the elements of the column vector
				 - Read and fill the column vector
			   - End loop
			   - Fill the 2D matrix with the matricial product of
			     the row vector time the column one
		      - End ELSE
		      - Close the kernel file name

   $EH
   ========================================================================== */
   extern void IRESIP_UNDR_ReadFilter
                        (/*IN    */ char                *kern_filename,
                         /*   OUT*/ float             ***Kern,
			 /*   OUT*/ UINTx4	        *Kr,
			 /*   OUT*/ UINTx4              *Kc,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIF_UNDR_Convol

        $TYPE         FUNCTION

        $INPUT        inp_ima      : pointer to the input image
                      inp_ima_dt   : input image data type
                      row_start    : start row index of image window
                      col_start    : start column index of image window
                      Kern         : kernel filter
                      Kr           : kernel row size
                      Kc           : kernel column size

        $MODIFIED     NONE

        $OUTPUT       OutPoint     : result of the convolution

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine executes the convolution between an image
                      and a kernel

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern float IRESIF_UNDR_Convol
                        (/*IN    */ void               **inp_ima,
                         /*IN    */ LDEFIT_data_type     inp_ima_dt,
                         /*IN    */ UINTx4               row_start,
                         /*IN    */ UINTx4               col_start,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         IRESIF_UNDR_ConstConvol

        $TYPE         FUNCTION

        $INPUT        inp_ima      : pointer to the input image
                      inp_ima_dt   : input image data type
                      row_start    : start row index of image window
                      col_start    : start column index of image window
                      K            : kernel filter constant value
                      Kr           : kernel row size
                      Kc           : kernel column size

        $MODIFIED     NONE

        $OUTPUT       OutPoint     : result of the convolution

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine executes the convolution between an image
                      and a constant kernel

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern float IRESIF_UNDR_ConstConvol
                        (/*IN    */ void               **inp_ima,
                         /*IN    */ LDEFIT_data_type     inp_ima_dt,
                         /*IN    */ UINTx4               row_start,
                         /*IN    */ UINTx4               col_start,
                         /*IN    */ float                K,   
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         IRESIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    IRESIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define IRESIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_IRES_err_mem_alloc        2
#define ERRSID_IRES_not_allowed_prod     3
#define ERRSID_IRES_tmp_fname_too_long   4
#define ERRSID_IRES_not_open_tmp         5
#define ERRSID_IRES_dimens_not_set       6
#define ERRSID_IRES_data_type_not_allow  7
#define ERRSID_IRES_indx_array_empty     8
#define ERRSID_IRES_no_undersampling     9
#define ERRSID_IRES_not_space           10
#define ERRSID_IRES_incorrect_rows_cols 11
#define ERRSID_IRES_imanum_not_allow    12
#define ERRSID_IRES_start_stop_col_err  13
#define ERRSID_IRES_zero_size_par       14
#define ERRSID_IRES_no_interp_req       15
#define ERRSID_IRES_err_open_file       16
#define ERRSID_IRES_fact_not_good       17
#define ERRSID_IRES_log_vol_id_undef    18
#define ERRSID_IRES_not_under_allow     19
#define ERRSID_IRES_kernel_dim_high     20
#define ERRSID_IRES_read_block_dim_low  21
#define ERRSID_IRES_bad_steps		22
#define ERRSID_IRES_no_over		23
#define ERRSID_IRES_bad_write_size	24
#define ERRSID_IRES_bad_kernel_dim      25
#define ERRSID_IRES_error_read_kern     26
#define ERRSID_IRES_no_elem_kern        27
#define ERRSID_IRES_kern_spec_not_good  28

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef IRES_GLBL
    char *IRESIV_ERRS_error_message[] = 
               { "No error happens",                             /* 0 */
                 "Generic error happens",                        /* 1 */
                 "SYSTEM ERROR: memory allocation error",        /* 2 */
                 "Oversampling not defined for such product",    /* 3 */
                 "Temp file name too long",                      /* 4 */
                 "Error opening temporary file",                 /* 5 */
                 "File dimensions wrong",                        /* 6 */
                 "Data type not allowed",                        /* 7 */
                 "Indices of spectra minimum not evaluated",     /* 8 */
                 "No undersampling in this procedure",           /* 9 */
                 "Not enough space on disk",                     /* 10 */
                 "The number of rows and columns is incorrect",  /* 11 */
                 "The image number is not in the allowed range", /* 12 */
                 "Error in the starting (ending) row (column)",  /* 13 */
                 "Zero size for parameter",                      /* 14 */
                 "No interpolation required",                    /* 15 */
                 "SYSTEM ERROR: Error opening the file",         /* 16 */
                 "Interpolation factors not good",               /* 17 */
                 "Tag LOG_VOL_ID not defined for the file",      /* 18 */
                 "Undersampling not defined for such product",   /* 19 */
                 "Kernel dimensions too high",                   /* 20 */
                 "Reading block dimensions too low",             /* 21 */
		 "Steps sizes not good for undersampling",	 /* 22 */
		 "No oversampling in this procedure",            /* 23 */
		 "Bad writing counters",                         /* 24 */
		 "Mono dimensional kernel not allowed",          /* 25 */
		 "Error reading the filter kernel from file",    /* 26 */
		 "No elements in the filter kernel",             /* 27 */
		 "Kernel specification not good"                 /* 28 */
               };
#else
   GLOBAL char *IRESIV_ERRS_error_message[];
#endif


#endif
