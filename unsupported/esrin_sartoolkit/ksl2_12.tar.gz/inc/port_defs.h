/* ==========================================================================
   $MODULE_HEADER

      $NAME          PORT_DEFS

      $FUNCTION      Portable Definitions

      $DESCRIPTION   This file contains some useful definitions for porting
                     purposes

      $HISTORY

            SCR NO.      DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       03-SEP-97    AG        Initial Release

    $EH
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

   $NAME         Super types definition

   $DESCRIPTION  Defines INTx1, INTx2, INTx4, INTx8, UINTx1, UINTx2, UINTx4
		 and UINTx8 super types in order to allow porting

   $EH
   ========================================================================== */
#ifdef __VMS__
   typedef char INTx1;
   typedef short INTx2;
   typedef int INTx4;
   typedef long int INTx8;
   typedef unsigned char UINTx1;
   typedef unsigned short UINTx2;
   typedef unsigned int UINTx4;
   typedef unsigned long int UINTx8;
#endif

/* SUN, SGI, OSF, HP and IBM platforms */
#ifdef __UNIX__
#ifdef __SGI__
#define __SGI_SIGNED__ signed
#else
#define __SGI_SIGNED__ /* signed */
#endif
   typedef __SGI_SIGNED__ char INTx1;
   typedef __SGI_SIGNED__ short INTx2;
   typedef __SGI_SIGNED__ int INTx4;
   typedef __SGI_SIGNED__ long int INTx8;
   typedef unsigned char UINTx1;
   typedef unsigned short UINTx2;
   typedef unsigned int UINTx4;
   typedef unsigned long int UINTx8;
#ifndef __OSF__
#define __SWAP__ TRUE
#endif
#endif

#ifdef  __WIN95__
   typedef char INTx1;
   typedef short INTx2;
   typedef long int INTx4;
   typedef long int INTx8;
   typedef unsigned char UINTx1;
   typedef unsigned short UINTx2;
   typedef unsigned long int UINTx4;
   typedef unsigned long int UINTx8;
#endif

#ifdef  __DOS__
   typedef char INTx1;
   typedef short INTx2;
   typedef long int INTx4;
   typedef long int INTx8;
   typedef unsigned char UINTx1;
   typedef unsigned short UINTx2;
   typedef unsigned long int UINTx4;
   typedef unsigned long int UINTx8;
#endif

#if defined __MC68K__ || defined __POWERPC__
   typedef char              INTx1;
   typedef short             INTx2;
   typedef int               INTx4;
   typedef long int          INTx8;
   typedef unsigned char     UINTx1;
   typedef unsigned short    UINTx2;
   typedef unsigned int      UINTx4;
   typedef unsigned long int UINTx8;
#define __SWAP__ TRUE
#endif


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         [U]INTxn_MIN
                    [U]INTxn_MAX

      $DESCRIPTION  Portable definition of types minimum and maximum values
		    (n = 1,2,4,8)

   $EH
   ========================================================================== */
#ifdef __VMS__
#define INTx1_MAX     127
#define UINTx1_MAX    255u
#define INTx1_MIN     (-INTx1_MAX - 1)
#define INTx2_MAX     32767
#define UINTx2_MAX    65535u
#define INTx2_MIN     (-INTx2_MAX -1)
#define INTx4_MAX     2147483647
#define UINTx4_MAX    4294967295u
#define INTx4_MIN     (-INTx4_MAX -1)
#define INTx8_MAX     2147483647
#define UINTx8_MAX    4294967295u
#define INTx8_MIN     (-INTx8_MAX -1)
#endif

/* SUN, SGI, OSF, HP and IBM platforms */
#ifdef __UNIX__
#define INTx1_MAX     127
#define UINTx1_MAX    255u
#define INTx1_MIN     (-INTx1_MAX - 1)
#define INTx2_MAX     32767
#define UINTx2_MAX    65535u
#define INTx2_MIN     (-INTx2_MAX -1)
#define INTx4_MAX     2147483647
#define UINTx4_MAX    4294967295u
#define INTx4_MIN     (-INTx4_MAX -1)
#define INTx8_MAX     2147483647
#define UINTx8_MAX    4294967295u
#define INTx8_MIN     (-INTx8_MAX -1)
#endif

#ifdef __WIN95__
#define INTx1_MAX     127
#define UINTx1_MAX    255u
#define INTx1_MIN     (-INTx1_MAX - 1)
#define INTx2_MAX     32767
#define UINTx2_MAX    65535u
#define INTx2_MIN     (-INTx2_MAX -1)
#define INTx4_MAX     2147483647
#define UINTx4_MAX    4294967295u
#define INTx4_MIN     (-INTx4_MAX -1)
#define INTx8_MAX     2147483647
#define UINTx8_MAX    4294967295u
#define INTx8_MIN     (-INTx8_MAX -1)
#endif

#ifdef __DOS__
#define INTx1_MAX     127
#define UINTx1_MAX    255u
#define INTx1_MIN     (-INTx1_MAX - 1)
#define INTx2_MAX     32767
#define UINTx2_MAX    65535u
#define INTx2_MIN     (-INTx2_MAX -1)
#define INTx4_MAX     2147483647
#define UINTx4_MAX    4294967295u
#define INTx4_MIN     (-INTx4_MAX -1)
#define INTx8_MAX     2147483647
#define UINTx8_MAX    4294967295u
#define INTx8_MIN     (-INTx8_MAX -1)
#endif

#if defined __MC68K__ || defined __POWERPC__
#define INTx1_MAX     127
#define UINTx1_MAX    255u
#define INTx1_MIN     (-INTx1_MAX - 1)
#define INTx2_MAX     32767
#define UINTx2_MAX    65535u
#define INTx2_MIN     (-INTx2_MAX -1)
#define INTx4_MAX     2147483647
#define UINTx4_MAX    4294967295u
#define INTx4_MIN     (-INTx4_MAX -1)
#define INTx8_MAX     2147483647
#define UINTx8_MAX    4294967295u
#define INTx8_MIN     (-INTx8_MAX -1)
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         REGISTER

      $DESCRIPTION  Defines the register type for portability purposal

   $EH
   ========================================================================== */
#define REGISTER register

