/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_PGLB

      $FUNCTION          STBX global module.

      $ROUTINE           STBXPP_set_par
                         STBXPP_bld_file_name
                         STBXPP_get_coordinates
                         STBXPP_open_temp_comp_file
                         STBXPF_task_no
                         STBXPP_set_config
                         STBXPP_update_coordinates
                         STBXPP_check_dirs
                         STBXPP_STAT_global
                         STBXPP_STAT_local
                         STBXPP_STAT_pca
                         STBXPP_RSMP_oversam
                         STBXPP_RSMP_undrsam
                         STBXPP_SPKF_filter
                         STBXPP_CONV_amp2pow
                         STBXPP_CONV_pow2amp
                         STBXPP_CONV_complex2amp
                         STBXPP_CONV_gaincvs
                         STBXPP_CONV_ugaincvs
                         STBXPP_CONV_sgaincvs
                         STBXPP_CONV_int2float
                         STBXPP_CONV_bilgen
                         STBXPP_CONV_tiffgen
                         STBXPP_CONV_dumpannot
                         STBXPP_CONV_impraster
                         STBXPP_CONV_lin2db
                         STBXPP_EXTR_MediaAnalysis
                         STBXPP_EXTR_HeaderDecode
                         STBXPP_EXTR_FullResolution
                         STBXPP_EXTR_QuickLook
                         STBXPP_EXTR_Preview
                         STBXPP_EXTR_CoordRetr
                         STBXPP_REGI_Registrator
                         STBXPP_REGI_CoherImaGenerator

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       10-MAR-97     AN       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include FIIS_INTF_H
#include STAT_INTF_H
#include STBX_INTF_H


#ifdef  STBX_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_num_pca_img

      $DESCRIPTION  Number of input images and pca output images. This constant 
                    can be changed here but the routine of PCA always accept 
                    two input images.

   $EH
   ========================================================================== */
#define STBXPD_num_pca_img    2

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_num_tgen_img

      $DESCRIPTION  Number of input images for standard TIFF generation.

   $EH
   ========================================================================== */
#define STBXPD_num_tgen_img    3

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_num_bgen_img

      $DESCRIPTION  Number of input images for BIL generation.

   $EH
   ========================================================================== */
#define STBXPD_num_bgen_img    10

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_task_name_length

      $DESCRIPTION  Length for the TASK name string

   $EH
   ========================================================================== */
#define STBXPD_task_name_length 40

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_stbx_version

      $DESCRIPTION  SAR Toolbox version

   $EH
   ========================================================================== */
#define STBXPD_sar_toolbox_version            "Generic Tool ver. 1.2"
#define STBXPD_resampling_tool_version        "Resampling Tool ver. 1.2"
#define STBXPD_statistical_tool_version       "Statistical Tool ver. 1.2"
#define STBXPD_extraction_tool_version        "Extraction Tool ver. 1.2"
#define STBXPD_speckle_filtering_tool_version "Speckle Filtering Tool ver. 1.2"
#define STBXPD_convertion_tool_version        "Convertion Tool ver. 1.2"
#define STBXPD_coregistr_tool_version         "Co-registration Tool ver. 1.2"
#define STBXPD_calibration_tool_version       "Calibration Tool ver. 1.2"

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_cfg_dir

      $DESCRIPTION  SAR Toolbox configuration dir

   $EH
   ========================================================================== */
#define STBXPD_cfg_dir "cfg"

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_default_parm_no

      $DESCRIPTION  Number of parameters always read from INI

   $EH
   ========================================================================== */
#define STBXPD_default_parm_no 4

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_if_arg

      $DESCRIPTION  String used for the input parameter file

   $EH
   ========================================================================== */
#define STBXPD_if_arg "-if"

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_prefix_line_arg

      $DESCRIPTION  String used as prefix for the parameter on the command
		    line

   $EH
   ========================================================================== */
#define STBXPD_prefix_line_arg '-'

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_max_vertex

      $DESCRIPTION  Define the maximum number of vertex for an AOI

   $EH
   ========================================================================== */
#define STBXPD_max_vertex 20

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_total_task_no

      $DESCRIPTION  Define the total number of SAR Toolbox task

   $EH
   ========================================================================== */
#define STBXPD_total_task_no  30

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_...

      $DESCRIPTION  Define string for each SAR Toolbox Task

   $EH
   ========================================================================== */
/* GLOBAL VARIABLE SETTINGS */
#define STBXPD_global_setting                 "GLOBAL SETTING"
/* RESAMPLING TOOL */
#define STBXPD_image_oversampling             "IMAGE OVERSAMPLING"
#define STBXPD_image_undersampling            "IMAGE UNDERSAMPLING"
/* STATISTICAL TOOL */
#define STBXPD_global_statistic		      "GLOBAL STATISTIC"
#define STBXPD_local_statistic		      "LOCAL STATISTIC"
#define STBXPD_princ_component		      "PRINCIPAL COMPONENT ANALYSIS"
/* EXTRACTION TOOL */
#define STBXPD_media_analysis                 "MEDIA ANALYSIS"
#define STBXPD_header_decode                  "HEADER ANALYSIS"
#define STBXPD_quick_look                     "QUICK LOOK"
#define STBXPD_image_preview                  "IMAGE PREVIEW"
#define STBXPD_coord_retr                     "COORDINATES RETRIEVING"
#define STBXPD_full_resolution                "FULL RESOLUTION"
#define STBXPD_support_data                   "SUPPORT DATA"
#define STBXPD_new_format                     "NEW FORMAT"
#define STBXPD_portion_extraction             "PORTION EXTRACTION"

/* SPECKLE FILTERING TOOL */
#define STBXPD_speckle_filter                 "SPECKLE FILTER"
/* CONVERTION TOOL */
#define STBXPD_ampl_power                     "AMPLITUDE TO POWER"
#define STBXPD_power_ampl                     "POWER TO AMPLITUDE"
#define STBXPD_complex_ampl                   "COMPLEX TO AMPLITUDE"
#define STBXPD_pixel_float                    "PIXEL TO FLOAT"
#define STBXPD_gain_conversion                "GAIN CONVERSION"
#define STBXPD_tiff_generation                "TIFF GENERATION"
#define STBXPD_bil_generation                 "BIL GENERATION"
#define STBXPD_ancillary_data                 "ANCILLARY DATA DUMP"
#define STBXPD_import_raster                  "IMPORT RASTER"
#define STBXPD_linear_db                      "LINEAR TO DB"
/* CO-REGISTRATION TOOL */
#define STBXPD_image_coregistration           "IMAGE CO-REGISTRATION"
#define STBXPD_coherence_image_generation     "COHERENCE IMAGE GENERATION"
/* CALIBRATION TOOL */
#define STBXPD_image_backscattering           "IMAGE BACKSCATTERING"
#define STBXPD_image_gamma                    "IMAGE GAMMA"
#define STBXPD_image_adc_sat                  "ADC COMPENSATION GENERATION"

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_...

      $DESCRIPTION  Define string for each SAR Toolbox Task parameter name

   $EH
   ========================================================================== */
#define STBXPD_input_dir                      "Input Dir"
#define STBXPD_output_dir                     "Output Dir"
#define STBXPD_temporary_dir                  "Temporary Dir"
#define STBXPD_input_image                    "Input Image"
#define STBXPD_input_images                   "Input Images"
#define STBXPD_delete_input_image	      "Delete Input Image"
#define STBXPD_filter_name                    "Filter File Name"
#define STBXPD_output_image                   "Output Image"
#define STBXPD_pca_output_images              "PCA Output Images"
#define STBXPD_output_image_size              "Output Image Size"
#define STBXPD_output_image_ratio             "Output Image Ratio"
#define STBXPD_coordinate_system	      "Coordinate System"
#define STBXPD_row_col                        "ROWCOL"
#define STBXPD_lat_lon                        "LATLON"
#define STBXPD_top_left_corner                "Top Left Corner"
#define STBXPD_bottom_right_corner	      "Bottom Right Corner"
#define STBXPD_top_right_corner               "Top Right Corner"
#define STBXPD_bottom_left_corner             "Bottom Left Corner"
#define STBXPD_centre			      "Centre"
#define STBXPD_size                           "Size"
#define STBXPD_size_unit		      "Size Unit"
#define STBXPD_vertex_no                      "Number of Vertex"
#define STBXPD_vertex                         "Vertex"
#define STBXPD_size_unit_km                   "KM"
#define STBXPD_size_unit_pixel	              "PIXEL"
#define STBXPD_output_file                    "Output File"
#define STBXPD_window_sizes                   "Window Sizes"
#define STBXPD_window_increments              "Window Steps"
#define STBXPD_class_min_val		      "Class Min"
#define STBXPD_class_max_val		      "Class Max"
#define STBXPD_class_no                       "Classes Number"
#define STBXPD_output_image_type	      "Output Image Type"
#define STBXPD_output_image_type_mean         "MEAN"
#define STBXPD_output_image_type_sddv	      "SDDV"
#define STBXPD_output_image_type_cfvr	      "CFVR"
#define STBXPD_filler_value		      "Filler Value"

#define STBXPD_input_media_path               "Input Media Path"
#define STBXPD_input_media_type               "Input Media Type"
#define STBXPD_product_type                   "Product Type"
#define STBXPD_sensor_id                      "Sensor Id"
#define STBXPD_data_format                    "Data Format"
#define STBXPD_source_id                      "Source Id"
#define STBXPD_number_of_volumes              "Number Of Volumes"
#define STBXPD_annotation_file                "Annotation File"
#define STBXPD_head_an_file                   "Header Analysis File"
#define STBXPD_ackn_mount_flag                "Acknowledge Mount"
#define STBXPD_dismount_flag                  "Dismount Volume"
#define STBXPD_output_quick_look_image        "Output Quick Look Image"
#define STBXPD_output_grid_image              "Output Grid Image"
#define STBXPD_grid_lines_num                 "Number Of Grid Lines"
#define STBXPD_grid_type                      "Grid Type"
#define STBXPD_grid_drawing_mode              "Grid Drawing Mode"
#define STBXPD_quick_look_presentation        "Quick Look Presentation"
#define STBXPD_quick_look_normal              "NORMAL"
#define STBXPD_quick_look_geo                 "GEOGRAPHIC"
#define STBXPD_grid_none                      "NONE"
#define STBXPD_grid_overwrite                 "OVERWRITE"
#define STBXPD_grid_transparent               "TRANSPARENT"
#define STBXPD_cropped_tiff_image             "Cropped Tiff Image"
#define STBXPD_output_coord_file              "Output Coordinates File"
#define STBXPD_input_support_data_file        "Input Support Data File"
#define STBXPD_output_mcr_file                "Output MCR File"

#define STBXPD_pfa                            "PFA"
#define STBXPD_look_no                        "Number of Look"
#define STBXPD_mask_file_name                 "Mask File"
#define STBXPD_edge_threshold                 "Edge Threshold"
#define STBXPD_line_threshold                 "Line Threshold"
#define STBXPD_scatter_threshold              "Scatter Threshold"

#define STBXPD_data_type                      "Data Type"
#define STBXPD_data_type_2i                   "2I"
#define STBXPD_data_type_complex2i            "Complex 2I"
#define STBXPD_media_file_skip                "Media File Skip"
#define STBXPD_file_head_bytes                "File Header Bytes"
#define STBXPD_line_head_bytes                "Line Header Bytes"
#define STBXPD_image_record_length            "Image Record Length"
#define STBXPD_number_of_rows                 "Number of Rows"
#define STBXPD_number_of_cols                 "Number of Columns"
#define STBXPD_swap_bytes                     "Swap Bytes"
#define STBXPD_map_projection_type            "Map Projection Descriptor"
#define STBXPD_map_projection_slant           "SLANT"
#define STBXPD_map_projection_ground          "GROUND"
#define STBXPD_map_projection_utm             "UTM"
#define STBXPD_map_projection_ups             "UPS"
#define STBXPD_user_lut                       "User LUT"
#define STBXPD_min_perc                       "Min Percentage"
#define STBXPD_max_perc                       "Max Percentage"
#define STBXPD_no_black                       "Number of Black Levels"
#define STBXPD_scale_factor                   "Scaling Factor"

#define STBXPD_db_file_name                   "db_file.dat"

#define STBXPD_output_images                  "Output Images"
#define STBXPD_baseline_file_name             "Baseline File Name"
#define STBXPD_GCPs_number                    "GCPs Numbers"
#define STBXPD_GCPs_file_name                 "GCPs File Name"
#define STBXPD_coarse_cell_dim                "Coarse Reg Window Sizes"
#define STBXPD_interp_fact                    "Coarse Reg Interp Factors"
#define STBXPD_coarse_tolerance               "Coarse Reg Tolerance"
#define STBXPD_fine_cell_dim                  "Fine Reg Window Sizes"
#define STBXPD_coher_win_size                 "Coherence Window Size"
#define STBXPD_coher_ftol                     "Coherence Func Tolerance"
#define STBXPD_coher_vtol                     "Coherence Value Tolerance"
#define STBXPD_warp_deg                       "Transformation Degree"
#define STBXPD_max_RMS                        "Editing RMS"
#define STBXPD_over_mode                      "Overlapping Mode"
#define STBXPD_over_min                       "MIN"
#define STBXPD_over_max                       "MAX"
#define STBXPD_over_master                    "MASTER"
#define STBXPD_interp_win_siz                 "Interp Window Sizes"
#define STBXPD_interp_mode                    "Interpolation Mode"
#define STBXPD_interp_nn                      "NEAREST NEIGHBOUR"
#define STBXPD_interp_bil                     "BILINEAR"
#define STBXPD_interp_cconv                   "CUBIC CONVOLUTION"
#define STBXPD_interp_FFTshift                "CONSTANT SHIFT"
#define STBXPD_interp_sinc                    "SINC"
#define STBXPD_interp_CCFFTShift              "CONSTANT SHIFT CUBIC CONV"
#define STBXPD_interp_SincFFTShift            "CONSTANT SHIFT SINC"
#define STBXPD_resid_file_name                "Residual File Name"
#define STBXPD_interp_precision               "Interpolation Inverse Precision"
#define STBXPD_sinc_width                     "Sinc Width"
#define STBXPD_cc_coeff                       "Cubic Convolution Coefficient"
#define STBXPD_fine_reg_flag                  "Real Image Fine Reg"

#define STBXPD_output_image_scale             "Output Image Scale"
#define STBXPD_linear_scale                   "LINEAR"
#define STBXPD_db_scale                       "DB"
#define STBXPD_antenna_pattern_lut            "Antenna Pattern Correction"
#define STBXPD_range_spread_loss_lut          "Range Spreading Loss Correction"
#define STBXPD_calib_const_lut                "Calibration Constant Correction"
#define STBXPD_replica_power_lut              "Replica Power Correction"
#define STBXPD_lut_apply                      "APPLY"
#define STBXPD_lut_remove                     "REMOVE"
#define STBXPD_antenna_pattern_file           "Antenna Pattern File"
#define STBXPD_user_calibration_constant      "Calibration Constant"
#define STBXPD_refer_replica_power            "Reference Replica Power"
#define STBXPD_refer_chirp_average            "Reference Chirp Average Density"
#define STBXPD_adc_satur_correct              "ADC Saturation Correction"
#define STBXPD_adc_satur_correct_file         "ADC Saturation Correction File"
#define STBXPD_rms_window_size                "RMS Window Size"
#define STBXPD_pri_smooth_window_size         "PRI Smoothing Window Size"
#define STBXPD_slc_smooth_window_size         "SLC Smoothing Window Size"

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum STBXPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPC_

      $DESCRIPTION  The STBXPC_

   $EH
   ========================================================================== */
/*   const STBXPC_   = ;
*/

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPC_toolbox_name

      $DESCRIPTION  This array of pointers to functions contains
                    all the SAR TOOLBOX task names

   $EH
   ========================================================================== */
#ifdef STBX_GLBL
   GLOBAL const char *STBXPC_toolbox_name[] = {
      STBXPD_global_setting,
      STBXPD_image_oversampling,
      STBXPD_image_undersampling,
      STBXPD_global_statistic,
      STBXPD_local_statistic,
      STBXPD_princ_component,
      STBXPD_media_analysis,
      STBXPD_header_decode,
      STBXPD_quick_look,
      STBXPD_image_preview,
      STBXPD_coord_retr,
      STBXPD_full_resolution,
      STBXPD_portion_extraction,
      STBXPD_support_data,
      STBXPD_new_format,
      STBXPD_speckle_filter,
      STBXPD_ampl_power,
      STBXPD_power_ampl,
      STBXPD_complex_ampl,
      STBXPD_pixel_float,
      STBXPD_gain_conversion,
      STBXPD_tiff_generation,
      STBXPD_bil_generation,
      STBXPD_ancillary_data,
      STBXPD_import_raster,
      STBXPD_linear_db,
      STBXPD_image_coregistration,
      STBXPD_coherence_image_generation,
      STBXPD_image_backscattering,
      STBXPD_image_gamma,
      STBXPD_image_adc_sat
   };
#else
   GLOBAL const char *STBXPC_toolbox_name[];
#endif

/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_toolbox_func

      $DESCRIPTION  This type defines the prototype of the core functions for
                    the cubic convolution interpolation

   $EH
   ========================================================================== */
   typedef void (*STBXPT_toolbox_func)
         (char *, UINTx4, INTx4, char **, ERRSIT_status *);

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_task

      $DESCRIPTION  Definition of structure to hold a TASK

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          name                             name of the task
          parmNo                           number of the parameter needed
          parm                             array of parameter

   $EH
   ========================================================================== */
   struct STBXPT_task_def {
      char                  name[ STBXPD_task_name_length ];
      INTx4                 parmNo;
      FIISIT_parm          *parm;
   };

  typedef struct STBXPT_task_def STBXPT_task;
   
/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_task_file_ext

      $DESCRIPTION  Structure to hold the file name extension corresponding
                    to a task

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          task_name                        name of the task
          ext                              extension of generated file(s)

   $EH
   ========================================================================== */
   struct STBXPT_task_file_ext_def {
      char                  task_name[ STBXPD_task_name_length ];
      char                  ext[ 10 ];
   };

   typedef struct STBXPT_task_file_ext_def STBXPT_task_file_ext;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPV_task_file_ext

      $DESCRIPTION  Global Variable to hold the file name extension 
                    corresponding to a task

   $EH
   ========================================================================== */
#ifdef STBX_GLBL
   GLOBAL STBXPT_task_file_ext STBXPV_task_file_ext[ STBXPD_total_task_no ] 
     = { { STBXPD_image_oversampling,           "OV"  },
         { STBXPD_image_undersampling,          "UN"  },
         { STBXPD_global_statistic,             "txt" },
         { STBXPD_local_statistic,              "LS"  },
         { STBXPD_princ_component,              "PC"  },
         { STBXPD_media_analysis,               "txt" },
         { STBXPD_header_decode,                "HAN" },
         { STBXPD_quick_look,                   "tif" },
         { STBXPD_image_preview,                "tif" },
         { STBXPD_coord_retr,                   "txt" },
         { STBXPD_full_resolution,              "XT"  },
         { STBXPD_portion_extraction,           "XT"  },
         { STBXPD_support_data,                 "SD"  },
         { STBXPD_new_format,                   ""    },
         { STBXPD_speckle_filter,               "SF"  },
         { STBXPD_power_ampl,                   "PA"  },
         { STBXPD_ampl_power,                   "AP"  },
         { STBXPD_complex_ampl,                 "CA"  },
         { STBXPD_gain_conversion,              "GC"  },
         { STBXPD_pixel_float,                  "IF"  },
         { STBXPD_tiff_generation,              "tif" },
         { STBXPD_bil_generation,               ""    },
         { STBXPD_ancillary_data,               "txt" },
         { STBXPD_import_raster,                "RI"  },
         { STBXPD_linear_db,                    "DB"  },
         { STBXPD_image_coregistration,         "CR"  },
         { STBXPD_coherence_image_generation,   "CH"  },
         { STBXPD_image_backscattering,         "BS"  },
         { STBXPD_image_gamma,                  "GA"  },
         { STBXPD_image_adc_sat,                "AD"  },
       };
#else
   GLOBAL STBXPT_task_file_ext STBXPV_task_file_ext[ STBXPD_total_task_no ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPV_inp_dir_val

      $DESCRIPTION  It contains the directory name containing the input,
                    output, temporary files and the value of delete input
                    flag

   $EH
   ========================================================================== */
#ifdef STBX_GLBL
   GLOBAL char STBXPV_inp_dir_val[ 256 ] = "";
   GLOBAL char STBXPV_out_dir_val[ 256 ] = "";
   GLOBAL char STBXPV_temp_dir_val[ 256 ] = "";
   GLOBAL char STBXPV_delete_input_val = ' ';
#else
   GLOBAL char STBXPV_inp_dir_val[ 256 ];
   GLOBAL char STBXPV_out_dir_val[ 256 ];
   GLOBAL char STBXPV_temp_dir_val[ 256 ];
   GLOBAL char STBXPV_delete_input_val;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_gaincvs_type

      $DESCRIPTION  Type of GAIN convertion

   $EH
   ========================================================================== */
   enum STBXPE_gaincvs_type {
      STBXPE_gaincvs_none,
      STBXPE_gaincvs_std,
      STBXPE_gaincvs_lut,
      STBXPE_gaincvs_scf
   };
   typedef enum STBXPE_gaincvs_type STBXPT_gaincvs_type;

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_set_par

        $TYPE         PROCEDURE

        $INPUT        value   : value to be set in parm

        $MODIFIED     parm    : parm to be changed

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_type

        $DESCRIPTION  This procedure set the value of a parm according 
                      to its type.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void STBXPP_set_par     
                        (/*IN    */ void                *value,
                         /*IN OUT*/ FIISIT_parm         *parm,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_bld_file_name

        $TYPE         PROCEDURE

        $INPUT        brief_name   : name of file to be built
                      task_name    : task name requesting creation
                      data_type    : data type of the output file

        $MODIFIED     NONR

        $OUTPUT       file_name    : file name with directory and extension

        $GLOBAL       STBXPV_task_file_ext

        $RET_STATUS   ERRSID_STBX_undef_task

        $DESCRIPTION  This procedure set the file name according to the
                      task creating it in the LDEFIV_out_dir

        $WARNING      NONE

        $PDL          - Look for ext in the STBXPV_task_file_ext
                      - Exit if the requested task does not exists
                      - Build full file name specification

   $EH
   ========================================================================== */
   extern void STBXPP_bld_file_name    
                        (/*IN    */ char                *brief_name,
                         /*IN    */ char                *task_name,
                         /*IN    */ LDEFIT_data_type     data_type,
                         /*   OUT*/ char                *file_name,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_get_coordinates

        $TYPE         PROCEDURE

        $INPUT        ini_file	    : name of ini file to be read
                      section	    : section where to read
                      inp_bpar	    : TIFF basic parameter of input image
                      imanum	    : image number for annotation

        $MODIFIED     NONE

        $OUTPUT       TLRow	    : row top left coorner in 
                                      ROWCOL coordinates
                      TLCol         : column top left coorner in 
                                      ROWCOL coordinates
		      BRRow	    : row bottom right coorner in
                                      ROWCOL coordinates
                      BRCol         : column bottom right coorner in
                                      ROWCOL coordinates
                      vertex_no     : number of vertex of an area of interest
                      vertex	    : vertex of an area of interest in
				      ROWCOL coordinates
                      real_aoi      : TRUE when AOI is explicitly defined

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_parm_invalid
	              ERRSID_STBX_parm_not_defined

        $DESCRIPTION  This procedure read from an INI file the parameters
		      related to the area of interest and using the image
		      annotation transform it to TL-BR coorners. 

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void STBXPP_get_coordinates
                        (/*IN    */ char		*ini_file,
                         /*IN    */ char                *section,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ UINTx1               imanum,
                         /*   OUT*/ UINTx4              *TLRow,
                         /*   OUT*/ UINTx4              *TLCol,
                         /*   OUT*/ UINTx4              *BRRow,
                         /*   OUT*/ UINTx4              *BRCol,
                         /*   OUT*/ UINTx4              *vertex_no,
			 /*   OUT*/ MATHIT_RC          **vertex,
                         /*   OUT*/ LDEFIT_boolean      *real_aoi,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_open_temp_comp_file

        $TYPE         PROCEDURE

        $INPUT        tmp_file	: name of the temporary file to open
                      nrow_inp	: number of rows of the file to open
                      ncol_inp	: number of columns of the file to open
                      disp	: disposition ( faster direction in subsequent
                                  file reading)

        $MODIFIED     NONE

        $OUTPUT       chan      : the TIFF file channel of the opened file
                      bpar	: the structure with the basic parameters info
                                  to store in the temporary TIFF file

        $GLOBAL       LDEFIV_temp_dir	: temporary directory in which put the
                                          file

        $RET_STATUS   ERRSID_STBX_dimens_not_set
                      
        $DESCRIPTION  This procedure opens the temporary TIFF file in which
                      to store a floating point complex data file

        $WARNING      This procedure makes no check about the free space on the 
                      device indicated by the <temp_dir> variable

   $EH
   ========================================================================== */
   extern void STBXPP_open_temp_comp_file
                        (/*IN    */ char                *tmp_file,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ const char           disp,
                         /*   OUT*/ GIOSIT_io           *tmp_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_STAT_global

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the GLOBAL STATISTIC task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
		      - Open the input file
                      - Get the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
		      - Call STATIP_GLOB_stat routine
                      - Close input file
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_STAT_global
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_STAT_local

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the LOCAL STATISTIC task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call STATIP_LOCA_stat routine
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_STAT_local
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_STAT_pca

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid
                      ERRSID_STBX_not_poly_aoi

        $DESCRIPTION  This routine executes the PRINCIPAL COMPONENT ANALYSIS 
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Open input files getting the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Exit for non rectangular AOI
                      - Compute nrow_inp/ncol_inp of input images
		      - Set nrow_out/ncol_out of output image to 
                        nrow_inp/ncol_inp
                      - Initialize output files TIFF parameters
                      - Open output files
                      - Call STATIP_PCAN_pca routine
                      - Set the image annotations of the output files
                      - Close output and input files
                      - Delete input files, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_STAT_pca
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_RSMP_oversam

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_not_poly_aoi
                      ERRSID_STBX_parm_not_negative

        $DESCRIPTION  This routine executes the IMAGE OVERSAMPLING task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Open the input file
                      - Get the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of output image
                      - Initialize output file TIFF parameters
                      - Open output file
                      - Call IRESIP_OVER_Interpolate routine
		      - Set the image annotations of the output file
                      - Close input and output files
                      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_RSMP_oversam
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_RSMP_undrsam

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_not_poly_aoi
                      ERRSID_STBX_parm_not_negative

        $DESCRIPTION  This routine executes the IMAGE UNDERSAMPLING task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Open the input file
                      - Get the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of output image
                      - Initialize output file TIFF parameters
                      - Open output file
                      - Call IRESIP_UNDR_Interpolate routine
		      - Set the image annotations of the output file
                      - Close input and output files
                      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_RSMP_undrsam
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_MediaAnalysis

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call media_analysis routine

   $EH
   ========================================================================== */
   extern void STBXPP_EXTR_MediaAnalysis
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_HeaderDecode

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call header_decoding routine
                      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_EXTR_HeaderDecode
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_FullResolution

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Select output image type according to a supplied
                        parameter
                      - Call deformat routine
                      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_EXTR_FullResolution
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_Portion

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the PORTION EXTRACTION task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call STATIP_LOCA_stat routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_EXTR_Portion
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_QuickLook

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Select output image type according to a supplied
                        parameter
                      - Call quick look routine
                      - Call stretching image routine
                      - Call drawing grid routine
                      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_EXTR_QuickLook
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_Preview

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call Preview routine

   $EH
   ========================================================================== */
   extern void STBXPP_EXTR_Preview
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_EXTR_CoordRetr

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the <task> task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call PMDSIP_RETR_CheckImage routine

   $EH
   ========================================================================== */
   extern void STBXPP_EXTR_CoordRetr
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_REGI_Registrator

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_insuff_input_num
                      ERRSID_STBX_insuff_output_num
                      ERRSID_STBX_invalid_warp_val
                      ERRSID_STBX_invalid_ov_mode
                      ERRSID_STBX_invalid_in_mode
                      ERRSID_STBX_not_poly_aoi

        $DESCRIPTION  This procedure executes the IMAGE CO-REGISTRATION task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Open the input file
                      - Get the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of output image
                      - Initialize output file TIFF parameters
                      - Open output file
                      - Calls the core routine
                      - Updates the image annotations
                      - Close input and output files
                      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_REGI_Registrator
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_REGI_CoherImaGenerator

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_inp_files_not_two
                      ERRSID_STBX_not_poly_aoi

        $DESCRIPTION  This procedure executes the COHERENCE IMAGE GENERATION
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Open the input files
                      - Get the image annotations
                      - Read Coordinate definition from INI file, if any
                      - Initialize output file TIFF parameters
                      - Open output file
                      - Calls the core routine
                      - Updates the image annotations
                      - Close input and output files
                      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_REGI_CoherImaGenerator
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
 
   $ROUTINE_HEADER
 
        $NAME         STBXPP_EXTR_SupportData
 
        $TYPE         PROCEDURE
 
        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line
 
        $MODIFIED     NONE
 
        $OUTPUT       NONE
 
        $GLOBAL       NONE
 
        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid
 
        $DESCRIPTION  This routine executes the <task> task
 
        $WARNING      NONE
 
        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call PMDSIP_SUPP_SetSupportData routine
 
   $EH
   ========================================================================== */
extern void STBXPP_EXTR_SupportData
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_SPKF_filter

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the SPECKLE FILTERING task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call SPKFIP_filter routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_SPKF_filter
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_amp2pow

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the AMPLITUDE TO POWER conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_amp2pow routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_CONV_amp2pow
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_pow2amp

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the POWER TO AMPLITUDE conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_pow2amp routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_CONV_pow2amp
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_complex2amp

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the COMPLEX TO AMPLITUDE conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_complex2amp routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_CONV_complex2amp
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_gaincvs

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the GAIN conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_gaincvs routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_CONV_gaincvs  
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_int2float

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the INTEGER TO FLOAT conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_int2float routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_CONV_int2float
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_bilgen

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the BIL generation conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_bilgen routine
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_CONV_bilgen
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_tiffgen

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the TIF generation conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_tiffgen routine
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_CONV_tiffgen
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_dumpannot

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the AMPLITUDE TO POWER conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
		      - Call CONVIP_dumpannot routine
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_CONV_dumpannot
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_impraster

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the INTEGER TO FLOAT conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_impraster routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_CONV_impraster
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CONV_lin2db

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the LINEAR TO DB conversion
                      task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any
                      - Select output image type according to a supplied 
                        parameter
		      - Open input file
                      - Get the input image annotations
                      - Read Coordinate definition from INI file, if any
                      - Compute nrow_inp/ncol_inp of input image
                      - Compute nrow_out/ncol_out of input image
                      - Initialize output file TIFF parameters
		      - Open output file
		      - Call CONVIP_lin2db routine
		      - Update the processing history of output file
                      - Set the image annotations of the output file
		      - Close output and input files
		      - Delete input file, if requested

   $EH
   ========================================================================== */
   extern void STBXPP_CONV_lin2db
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CALI_Backscattering

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the IMAGE BACKSCATTERING tasks

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call media_analysis routine

   $EH
   ========================================================================== */
   extern void STBXPP_CALI_Backscattering 
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CALI_Gamma

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the GAMMA IMAGE tasks

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
                        and command line parameters, if any
                      - Call gamma image task

   $EH
   ========================================================================== */
   extern void STBXPP_CALI_Gamma
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_CALI_AdcSaturation

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the ADC SATURATION CORRECTION task

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void STBXPP_CALI_AdcSaturation
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc,
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPF_task_no

        $TYPE         PROCEDURE

        $INPUT        name    : name of a SAR TOOLBOX task

        $MODIFIED     NONE

        $OUTPUT       task_no : number of a SAR TOOLBOX task

        $GLOBAL       NONE

        $RET_STATUS   

        $DESCRIPTION  This procedure returns the number of a SAR TOOLBOX task
                      given its name. 

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern INTx4 STBXPF_task_no    
                        (/*IN    */ char                *name,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_set_config

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       dir     : dir to be set

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure set the value of dir according
                      to STBXPD_cfg_dir

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void STBXPP_set_config  
                        (/*   OUT*/ char                *dir,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_update_coordinates

        $TYPE         PROCEDURE

        $INPUT        imanum : image annotation index

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure set the value of the coordinates tag

        $WARNING      Please be sure that SubImageTopLeft and ScalingFactor
                      tags have been already updated (if needed)

        $PDL

   $EH
   ========================================================================== */
   extern void STBXPP_update_coordinates
                        (/*IN    */ UINTx1               imanum,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_global_setting

        $TYPE         PROCEDURE

        $INPUT        task_name  :  name of the task to be executed
                      section_no :  number of section or 0 if unknown
                      argc       :  argc value of command line
                      argv       :  argv vector of command line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_parm_not_defined
                      ERRSID_STBX_parm_not_negative
                      ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine executes the GLOBAL SETTING task

        $WARNING      NONE

        $PDL          - Initialize the task structure
                      - Read the parameter file into the task structure
		        and command line parameters, if any

   $EH
   ========================================================================== */
   extern void STBXPP_global_setting
                        (/*IN    */ char                *task_name,
                         /*IN    */ UINTx4               section_no,
                         /*IN    */ INTx4                argc, 
                         /*IN    */ char                *argv[],
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_check_dirs

        $TYPE         PROCEDURE

        $INPUT        NONE
        
        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_parm_invalid

        $DESCRIPTION  This routine checks the validity of specified input, output and 
                      temporary dirs
                      
        $WARNING      ONLY ON TARGET PLATFORMS

        $PDL          - Check if the ending char of input, output and temporary dir
                        is the separator directory one.
                        
   $EH
   ========================================================================== */
   extern void STBXPP_check_dirs
                        (/*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPC_toolbox_func

      $DESCRIPTION  This array of pointers to functions contains the functions
                    needed to execute all the SAR TOOLBOX tasks

   $EH
   ========================================================================== */
#ifdef STBX_GLBL
   GLOBAL const STBXPT_toolbox_func STBXPC_toolbox_func[] = {
      STBXPP_global_setting,
      STBXPP_RSMP_oversam,
      STBXPP_RSMP_undrsam,
      STBXPP_STAT_global,
      STBXPP_STAT_local,
      STBXPP_STAT_pca,
      STBXPP_EXTR_MediaAnalysis,
      STBXPP_EXTR_HeaderDecode,
      STBXPP_EXTR_QuickLook,
      STBXPP_EXTR_Preview,
      STBXPP_EXTR_CoordRetr,
      STBXPP_EXTR_FullResolution,
      STBXPP_EXTR_Portion,
      STBXPP_EXTR_SupportData,
      NULL,
      STBXPP_SPKF_filter,
      STBXPP_CONV_amp2pow,
      STBXPP_CONV_pow2amp,
      STBXPP_CONV_complex2amp,
      STBXPP_CONV_int2float,
      STBXPP_CONV_gaincvs,
      STBXPP_CONV_tiffgen,
      STBXPP_CONV_bilgen,
      STBXPP_CONV_dumpannot,
      STBXPP_CONV_impraster,
      STBXPP_CONV_lin2db,
      STBXPP_REGI_Registrator,
      STBXPP_REGI_CoherImaGenerator,
      STBXPP_CALI_Backscattering,
      STBXPP_CALI_Gamma,
      STBXPP_CALI_AdcSaturation
   };
#else
   GLOBAL const STBXPT_toolbox_func STBXPC_toolbox_func[];
#endif

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STBXPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 STBXPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STBXPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void STBXPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) STBXIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( STBXPF_GLBL_set_error(status_code) )

#define STBXPM_start_task( name ) (fprintf(stdout, "\n\nDoing %s\n", name))

#define STBXPM_end_task( name ) (fprintf(stdout, "\n\n%s completed.\n", name))

#define STBXPM_reset_global                                                   \
   if( strcmp( STBXPV_inp_dir_val, "" ) ) {                                   \
      sprintf( LDEFIV_inp_dir, "%s", STBXPV_inp_dir_val );                    \
   }                                                                          \
   else {                                                                     \
      sprintf( LDEFIV_inp_dir, "%s", LDEFIC_inp_dir_val );                    \
   }                                                                          \
   if( strcmp( STBXPV_out_dir_val, "" ) ) {                                   \
      sprintf( LDEFIV_out_dir, "%s", STBXPV_out_dir_val );                    \
   }                                                                          \
   else {                                                                     \
      sprintf( LDEFIV_out_dir, "%s", LDEFIC_out_dir_val );                    \
   }                                                                          \
   if( strcmp( STBXPV_temp_dir_val, "" ) ) {                                  \
      sprintf( LDEFIV_temp_dir, "%s", STBXPV_temp_dir_val );                  \
   }                                                                          \
   else {                                                                     \
      sprintf( LDEFIV_temp_dir, "%s", LDEFIC_temp_dir_val );                  \
   }                                                                          \
   if( STBXPV_delete_input_val != ' ' ) {                                     \
      LDEFIV_delete_input = STBXPV_delete_input_val;                          \
   }                                                                          \
   else {                                                                     \
      LDEFIV_delete_input = LDEFIC_delete_input_val;                          \
   }                                                                          \

#ifdef __HAVEIDL__
#define STBXPM_log_version( version )                                         \
{                                                                             \
   char   msg[ 132 ];                                                         \
   sprintf( msg, "SAR TOOLBOX: %s", version);                                 \
   IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, " " );                            \
   IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, msg );                            \
   IDL_Message( IDL_M_GENERIC, IDL_MSG_RET, " " );                            \
}
#else
#define STBXPM_log_version( version ) fprintf(stdout, "\nSAR TOOLBOX: %s\n", version)
#endif

