/* ==========================================================================
   $MODULE_HEADER

      $NAME              MATH_INTF

      $FUNCTION          interface module.

      $ROUTINE           MATHIP_SPLN_spline      MATHIP_SPLN_splint
                         MATHIP_FMIN_amoeba      MATHIP_ROOF_Newton
                         MATHIP_EIGV_tred        MATHIP_EIGV_tqli
                         MATHIP_LIAL_MatrInve    MATHIP_LIAL_InveGene
                         MATHIP_LIAL_LLSQEval    MATHIP_STYP_RCSum
                         MATHIP_STYP_RCSubt      MATHIP_STYP_RCScalProd
                         MATHIP_STYP_RCModu      MATHIP_STYP_RCVers
                         MATHIP_STYP_XYZSum      MATHIP_STYP_XYZSubt
                         MATHIP_STYP_XYZScalProd MATHIP_STYP_XYZCrosProd
                         MATHIP_STYP_XYZModu     MATHIP_STYP_XYZVers
                         MATHIP_STYP_CSum        MATHIP_STYP_CSubt
                         MATHIP_STYP_CProd       MATHIP_STYP_CConstMult
                         MATHIP_STYP_CConj       MATHIP_STYP_CModu
                         MATHIP_STYP_CReal       MATHIP_STYP_CImag
                         MATHIP_STYP_CPhase      MATHIP_STYP_CExp
                         MATHIP_VECT_Make	 MATHIP_VECT_Free
                         MATHIP_VECT_SetZero     MATHIP_VECT_Copy
                         MATHIP_VECT_SubCopy     MATHIP_VECT_Sum         
                         MATHIP_VECT_Subt        MATHIP_VECT_ConstMult
                         MATHIP_VECT_Prod        MATHIP_VECT_HeterProd
			 MATHIP_VECT_HeterInnerProd
                         MATHIP_VECT_Pow         MATHIP_VECT_Extract
                         MATHIP_VECT_Size        MATHIP_VECT_Total
                         MATHIP_VECT_Mean	 MATHIP_VECT_Sigma
                         MATHIP_VECT_FillConst	 MATHIP_VECT_FillArray
                         MATHIP_VECT_ToFloat
                         MATHIP_VECT_ToUChar	 MATHIP_VECT_ToInt
                         MATHIP_VECT_ToIntFloor	 MATHIP_VECT_ToUInt
                         MATHIP_VECT_Complex	 MATHIP_VECT_Conj
                         MATHIP_VECT_Modul	 MATHIP_VECT_Real
                         MATHIP_VECT_Imaginary	 MATHIP_VECT_Phase
                         MATHIP_VECT_CTo2Float   MATHIP_VECT_2FloatToC
                         MATHIP_VECT_Exp         MATHIP_VECT_MatrixProduct
                         MATHIP_VECT_MinMax
                         MATHIP_DFFT_1D		 MATHIP_DFFT_2D
			 MATHIP_INTR_Linear	 MATHIP_INTR_NearestNeighbor
			 MATHIP_INTR_Bilinear    MATHIP_INTR_CubiConvInit
                         MATHIP_INTR_CubicConvolution
                         MATHIP_INTR_CubiConvClose
                         MATHIP_INTR_SincInit    MATHIP_INTR_Sinc
                         MATHIP_INTR_SincClose   MATHIP_INTR_FFTConstShift
                         MATHIP_INTR_ImageColShift
                         MATHIP_INTR_ImageRowShift

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       15-APR-97     GRV       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef MATH
#define MATH MATH


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <math.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H

#ifdef MATH_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHID_cubi_conv_elem

      $DESCRIPTION  It defines the number of points involved in one cubic
                    convolution

   $EH
   ========================================================================== */
#define MATHID_cubi_conv_elem    4

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIE_arr_type

      $DESCRIPTION  It enumerates the possible type of array elements for the
                    type MATHIT_array. The correspondence between the 
                    enumerated elements and the types is described below

   $EH
   ========================================================================== */
   enum MATHIE_arr_type {
      MATHIE_undef,      /* null value    */
      MATHIE_uchar,      /* unsigned byte */
      MATHIE_uintx2,     /* unsigned int 2 byte */
      MATHIE_uintx4,     /* unsigned int  */
      MATHIE_sintx4,     /* signed int    */
      MATHIE_float,      /* float         */
      MATHIE_complex     /* complex       */
   };

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum MATHIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIC_

      $DESCRIPTION  The MATHIC_

   $EH
   ========================================================================== */
/*   const MATHIC_   = ;
*/

/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */



/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIT_complex

      $DESCRIPTION  This type is the type complex, that is a vector with two
                    components that respect a complex arithmetic defined in
                    the module STYP of the MATH package

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          rea                              Real part of the complex number
          ima                              Imaginary part of the complex number

   $EH
   ========================================================================== */
   struct MATHIT_complex_def {
      float      rea;
      float      ima;
   };

   typedef struct MATHIT_complex_def MATHIT_complex;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIT_dcomplex

      $DESCRIPTION  This type is the type complex, that is a vector with two
                    components that respect a complex arithmetic defined in
                    the module STYP of the MATH package. The two components
		    are double defined

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          rea                              Real part of the complex number
          ima                              Imaginary part of the complex number

   $EH
   ========================================================================== */
   struct MATHIT_dcomplex_def {
      double     rea;
      double     ima;
   };

   typedef struct MATHIT_dcomplex_def MATHIT_dcomplex;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIT_RC

      $DESCRIPTION  This type defines the vector row column of the coordinates
                    in the image reference system.

                    *** They are expressed in number of pixels ***

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          row                              Number of pixels of the point from
                                           the reference system origin of the
                                           image in the row direction (pix)
          col                              Number of pixels of the point from
                                           the reference system origin of the
                                           image in the column direction (pix)

   $EH
   ========================================================================== */
   struct MATHIT_RC_def {
      double	row;
      double	col;
   };

   typedef struct MATHIT_RC_def MATHIT_RC;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIT_XYZ

      $DESCRIPTION  This type defines the vector representing a point in a
                    spatial 3D cartesian reference system.

                    *** They are expressed in meters ***

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          x                                x component in the cartesian 
                                           reference system (m)
          y                                y component in the cartesian 
                                           reference system (m)
          z                                z component in the cartesian 
                                           reference system (m)

   $EH
   ========================================================================== */
   struct MATHIT_XYZ_def {
      double	x;
      double	y;
      double	z;
   };

   typedef struct MATHIT_XYZ_def MATHIT_XYZ;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIT_LLH

      $DESCRIPTION  This type defines the three component object representing
                    the geodetic coordinates.

                    *** They are expressed in decimal degrees and meters ***

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          lat                              geodetic latitude (deg)
          lon                              geodetic longitude (deg)
          h                                geodetic height (deg)

   $EH
   ========================================================================== */
   struct MATHIT_LLH_def {
      double	lat;
      double	lon;
      double	h;
   };

   typedef struct MATHIT_LLH_def MATHIT_LLH;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIT_EN

      $DESCRIPTION  This type defines a structure with the values of East
                    and North coordinates in a UTM projection.

                    *** They are expressed in meters ***

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          east                             East coordinate (m)
          north                            North coordinate (m)

   $EH
   ========================================================================== */
   struct MATHIT_EN_def {
      double	east;
      double	north;
   };

   typedef struct MATHIT_EN_def MATHIT_EN;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIT_LUT1D

      $DESCRIPTION  This type defines the structure containing a typical
                    Look Up Table of values for image strethcing, corrections
                    and so on. This Look Up Table is an array.

                    *** They are pure numbers ***

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          N                                Number of elements of the LUT
          p                                Pointer to the LUT array

   $EH
   ========================================================================== */
   struct MATHIT_LUT1D_def {
      INTx4	N;
      double   *p;
   };

   typedef struct MATHIT_LUT1D_def MATHIT_LUT1D;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIT_LUT2D

      $DESCRIPTION  This type defines the structure containing a typical
                    Look Up Table of values for image strethcing, corrections
                    and so on. This Look Up Table is a 2-dimensional array.

                    *** They are pure numbers ***

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          Nrows                            Number of rows of the LUT
          Ncolumns                         Number of columns of the LUT
          p                                Pointer to the pointer to the LUT
                                           matrix

   $EH
   ========================================================================== */
   struct MATHIT_LUT2D_def {
      INTx4	Nrows;
      INTx4	Ncolumns;
      double  **p;
   };

   typedef struct MATHIT_LUT2D_def MATHIT_LUT2D;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIT_RC_float

      $DESCRIPTION  This type defines the vector row column of the coordinates
                    in the image reference system.

                    *** They are expressed in number of pixels ***

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          row                              Number of pixels of the point from
                                           the reference system origin of the
                                           image in the row direction (pix)
          col                              Number of pixels of the point from
                                           the reference system origin of the
                                           image in the column direction (pix)

   $EH
   ========================================================================== */
   struct MATHIT_RC_f_def {
      float 	row;
      float 	col;
   };

   typedef struct MATHIT_RC_f_def MATHIT_RC_float;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIT_arr_type

      $DESCRIPTION  This type enumerates the possible types of array

   $EH
   ========================================================================== */
   typedef enum MATHIE_arr_type MATHIT_arr_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIT_array

      $DESCRIPTION  This type describe the structure of a 1D array of values
                    of various types

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          nelem                            Number of elements of the 1D array
          atype                            A flag to indicate the type of the
                                           array elements
          ap                               Pointer to the first element of the
                                           array
   $EH
   ========================================================================== */
   struct MATHIT_array_def {
      INTx4                  nelem;
      MATHIT_arr_type        atype;
      void                  *ap;
   }; 

   typedef struct MATHIT_array_def MATHIT_array;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIV_err_flag

      $DESCRIPTION  It contains a flag to activate(de-activate) the mathematical
                    warnings in the FFT evaluation

   $EH
   ========================================================================== */
#ifdef MATH_GLBL
   GLOBAL LDEFIT_boolean MATHIV_err_flag = TRUE;
#else
   GLOBAL LDEFIT_boolean MATHIV_err_flag;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIV_sinc_elem

      $DESCRIPTION  It defines the number of points involved in a sinc
                    interpolation

      $WARNING      THE NUMBER OF ELEMENTS OF THE TABLE MUST BE EVEN

   $EH
   ========================================================================== */
#ifdef MATH_GLBL
   GLOBAL INTx2 MATHIV_sinc_elem = 5;
#else
   GLOBAL INTx2 MATHIV_sinc_elem;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIV_CCTableLength

      $DESCRIPTION  It contains the length of the table for the cubic
                    convolution. The length is the reciproc of the precision
                    of the interpolation values

   $EH
   ========================================================================== */
#ifdef MATH_GLBL
   GLOBAL INTx4 MATHIV_CCTableLength = 1000;
#else
   GLOBAL INTx4 MATHIV_CCTableLength;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIV_cubi_conv_coeff

      $DESCRIPTION  It defines the coefficient of the cubic convolution kernel.
                    ERDAS value is 0.5 IDL value is - 1.0

   $EH
   ========================================================================== */
#ifdef MATH_GLBL
   GLOBAL float MATHIV_cubi_conv_coeff = -1.0;
#else
   GLOBAL float MATHIV_cubi_conv_coeff;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIV_SincTableLength

      $DESCRIPTION  It contains the length of the table for the sinc
                    interpolation. The length is the reciproc of the precision
                    of the interpolation values

   $EH
   ========================================================================== */
#ifdef MATH_GLBL
   GLOBAL UINTx4 MATHIV_SincTableLength = 1000;
#else
   GLOBAL UINTx4 MATHIV_SincTableLength;
#endif


/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_SPLN_spline

        $TYPE         PROCEDURE

        $INPUT        x	   : array of ordered abscissa values
                      y	   : array of values of the function to interpolate
                             evaluated in the abscissa points x
                      n    : number of tabulated function values
                      yp1  : value of the first derivative of the function
                             evaluated in the point x[0]
                      ypn  : value of the first derivative of the function
                             evaluated in the point x[n-1]

        $MODIFIED     NONE

        $OUTPUT       y2   : array with the second derivatives of the function
                             to interpolate evaluated in the abscissa values
                             x

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_one_point

        $DESCRIPTION  This procedure initializes the variables to be used by
                      the Numerical Recipes' procedure spline, that evaluates
                      the second derivatives of the function to interpolate
                      subsequently

        $WARNING      The tabulated abscissa values must be monotonically
                      incrising, that is x[0] < x[1] < ... < x[n-2] < x[n-1]

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_SPLN_spline
                        (/*IN    */ double              *x,
                         /*IN    */ double              *y,
                         /*IN    */ INTx4                n,
                         /*IN    */ double               yp1,
                         /*IN    */ double               ypn,
                         /*   OUT*/ double              *y2, 
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_SPLN_splint

        $TYPE         PROCEDURE

        $INPUT        xa  : the abscissa values of the tabulated function to
                            interpolate
                      ya  : the values of the function to interpolate
                            corresponding to the abscissa value xa
                      y2a : the values of the second derivatives of the
                            tabulated function evaluated at the points xa
                      n   : the number of elements of xa
                      x   : the abscissa value at which the function must be
                            interpolated

        $MODIFIED     NONE

        $OUTPUT       y   : the value of the function interpolated at the point
                            x

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_one_point

        $DESCRIPTION  This procedure initializes the variables to be used by
                      the Numerical Recipes' procedure splint, that interpolates
                      the tabulated function at a given point contained in the
                      range of abscissa values defined

        $WARNING      The tabulated abscissa values must be monotonically
                      incrising, that is x[0] < x[1] < ... < x[n-2] < x[n-1]

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_SPLN_splint
                        (/*IN    */ double              *xa,
                         /*IN    */ double              *ya,
                         /*IN    */ double              *y2a,
                         /*IN    */ INTx4                n,
                         /*IN    */ double               x,
                         /*   OUT*/ double              *y,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_FMIN_amoeba

        $TYPE         PROCEDURE

        $INPUT        ndim  : the number of dimensions of the independent
                              variable X of the function to minimize
                      ftol  : the fractional convergence tolerance value for
                              the function
                      vtol  : the convergence tolerance value for the variables
                              to evaluate
                      funk  : function to minimize

        $MODIFIED     p     : an [ndim+1][ndim] array in which each one of the
                              ndim+1 rows contains the ndim dimensional vectors
                              with the coordinates of the starting simplex
                      y     : an [ndim+1] vector that contains the values of the
                              function to minimize in the simplex vertices

        $OUTPUT       nfunk : counter of the number of times the function funk
                              is called

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure initializes the variables to pass to the
                      Numerical Recipes's procedure amoeba, that minimizes the
                      multivariate function funk

        $WARNING

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_FMIN_amoeba
                        (/*IN    */ INTx4                ndim,
                         /*IN    */ double               ftol,
                         /*IN    */ double               vtol,
                         /*IN    */ double             (*funk)(),
                         /*IN OUT*/ double              *p,
                         /*IN OUT*/ double              *y,
                         /*   OUT*/ INTx4               *nfunk,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_ROOF_Newton

        $TYPE         PROCEDURE

        $INPUT        ntrial : maximum number of Newton-Raphson steps to improve
                               the root
                      n      : dimensions of the root
                      usrfun : pointer to the user defined function to evaluate
                               the first derivatives of the equations
                      tolx   : tolerance to stop the iteration WRT the summed
                               absolute variables increments
                      tolf   : tolerance to stop the iteration WRT the summed
                               absolute functions values

        $MODIFIED     x      : initial guess x[0...n-1] for an n-dimensional
                               root. In output x is the final root

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure initializes the variables to pass to the
                      Numerical Recipes's procedure mnewt, that solves
                      numerically a system of non linear equations

        $WARNING      The routine uses an user function defined as void usrfun()
                      that must be declared by the user.

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_ROOF_Newton
                        (/*IN    */ INTx4                ntrial,
                         /*IN    */ INTx4                n,
                         /*IN    */ void               (*usrfun)(),
                         /*IN    */ double               tolx,
                         /*IN    */ double               tolf,
                         /*IN OUT*/ double              *x,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_EIGV_tred

        $TYPE         PROCEDURE

        $INPUT        n : number of the two dimensions of the matrix a

        $MODIFIED     a : a[0...n-1][0...n-1] is the matrix we want to transform
                          In output it returns the orthogonal matrix
                          transformed by the Householder transformation.

        $OUTPUT       d : an array d[0...n-1] with the diagonals elements of the
                          tridiagonal matrix
                      e : an array e[0...n-1] with the off-diagonal elements,
                          with e[0]=1

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure set the parameters one-offset to be used
                      by the Numerical Recipes routine tred2 that makes an
                      HouseHolder transformation of the given n times n symmetric
                      matrix.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_EIGV_tred
                        (/*IN    */ INTx4                n,
                         /*IN OUT*/ double             **a,
                         /*   OUT*/ double              *d,
                         /*   OUT*/ double              *e,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_EIGV_tqli

        $TYPE         PROCEDURE

        $INPUT        n : number of the two dimensions of the matrix z

        $MODIFIED     d : an array d[0...n-1] with in input the diagonals
                          elements of the tridiagonal matrix and returns the
                          eigenvalues

                      e : an array e[0...n-1] with in input the off-diagonal
                          elements, with e[0] arbitrary. The vector in output
                          is destroid

                      z : the tridiagonal matrix z[0...n-1][0...n-1] obtained by
                          tred2 previously called and returns the eigenvectors

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure set the parameters one-offset to be used
                      by the Numerical Recipes routine tqli that evaluates the
                      eigenvalues and the eigenvectors of the given matrix

        $WARNING      The matrix to process must be obtained by a previous call
                      to the routine MATHIP_EIGV_tred

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_EIGV_tqli
                        (/*IN    */ INTx4                n,
                         /*IN OUT*/ double              *d,
                         /*IN OUT*/ double              *e,
                         /*IN OUT*/ double             **z,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_LIAL_MatrInve

        $TYPE         PROCEDURE

        $INPUT        n	    : square dimension of the matrix to invert

        $MODIFIED     a	    : matrix a[n][n] to invert. In output it will be
                              destroied

        $OUTPUT       am    : inverse matrix am[n][n]

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_num_err

        $DESCRIPTION  This procedure makes the matrix inversion using the LU
                      decomposition

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_LIAL_MatrInve
                        (/*IN    */ INTx4                n,
                         /*IN OUT*/ double             **a,
                         /*   OUT*/ double             **am,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_LIAL_InveGene

        $TYPE         PROCEDURE

        $INPUT        n	    : rows dimension of the matrix to invert
                      m	    : column dimension of the matrix to invert
                      a	    : the matrix a[n][m] to inverte

        $MODIFIED     NONE

        $OUTPUT       aig   : the matrix aig[m][m] that contains the inverted
                              matrix

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_err_mem_alloc

        $DESCRIPTION  This procedure creates the so called inverse generalized
                      of a given matrix a[n][m]. The inverse generalized matrix
                      is an aig[m][m] matrix defined as:

                                       T     -1
                               aig = (a  . a )

                      where the apices T stands for transposed, the apices
                      -1 stands for inverse and the symbol . stands for the
                      matrix rows by columns products

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_LIAL_InveGene
                        (/*IN    */ INTx4                n,
                         /*IN    */ INTx4                m,
                         /*IN    */ double             **a,
                         /*   OUT*/ double             **aig,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_LIAL_LLSQEval

        $TYPE	      PROCEDURE

        $INPUT        n	: number of elements of the array y
                      y	: array y[n] with the data known
                      m	: number of parameters to estimate
                      a	: the design matrix of the fitting problem that is
                          a[n][m]

        $MODIFIED     NONE

        $OUTPUT       p	: array p[m] with the estimated parameters

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure solves the linear least square problem
                      of finding a set of m p[m] parameters giving a set of n
                      equations that are linear functions of the parameters
                      themselves. The knowing data are assumed to have all
                      the same unitary variance and we don't have a priori
                      values. So the problem is of kind:

                                       y = a . p

                      where the symbol . stands for the application of the 
                      matrix a to the vector p. The solution p is given by:
                                     ^     T    -1   T
                                     p = (a . a)  . a  . y

                      where T stands for the transpose of the matrix and -1
                      stands for the inverse operator.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_LIAL_LLSQEval
                        (/*IN    */ INTx4                n,
                         /*IN    */ double              *y,
                         /*IN    */ INTx4                m,
                         /*IN    */ double             **a,
                         /*   OUT*/ double              *p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_RCSum

        $TYPE         PROCEDURE

        $INPUT        a:    the first row,column vector to sum
                      b:    the second row,column vector to sum

        $MODIFIED     NONE

        $OUTPUT       c:    the row,column vector sum of the two given in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure sums together two image coordinates
                      vectors

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_RCSum
                        (/*IN    */ MATHIT_RC           a,
                         /*IN    */ MATHIT_RC           b,
                         /*   OUT*/ MATHIT_RC          *c,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_RCSubt

        $TYPE         PROCEDURE

        $INPUT        a:    the first row,column vector to subtract
                      b:    the second row,column vector to subtract

        $MODIFIED     NONE

        $OUTPUT       c:    the row,column vector difference of the two given
                            in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure subtracts together two image coordinates
                      vectors

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_RCSubt
                        (/*IN    */ MATHIT_RC           a,
                         /*IN    */ MATHIT_RC           b,
                         /*   OUT*/ MATHIT_RC          *c,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_RCScalProd

        $TYPE         PROCEDURE

        $INPUT        a:    the first vector of the scalar product
                      b:    the second vector of the scalar product

        $MODIFIED     NONE

        $OUTPUT       c:    the scalar product of the two vectors given
                            in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure do the scalar product of two image
                      vectors given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_RCScalProd
                        (/*IN    */ MATHIT_RC            a,
                         /*IN    */ MATHIT_RC            b,
                         /*   OUT*/ double              *c,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_RCModu

        $TYPE         PROCEDURE

        $INPUT        a:    the image vector of which the modulus is nedeed

        $MODIFIED     NONE

        $OUTPUT       modu: the vector modulus

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the modulus of the image vector
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_RCModu
                        (/*IN    */ MATHIT_RC            a,
                         /*   OUT*/ double              *modu,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_RCVers

        $TYPE         PROCEDURE

        $INPUT        a:    the vector of which the versor is needed

        $MODIFIED     NONE

        $OUTPUT       v:    the versor of a

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_modu

        $DESCRIPTION  This procedure evaluates the versor of the image vector
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_RCVers
                        (/*IN    */ MATHIT_RC            a,
                         /*   OUT*/ MATHIT_RC           *v,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZSum

        $TYPE         PROCEDURE

        $INPUT        a:    the first cartesian vector to sum
                      b:    the second cartesian vector to sum

        $MODIFIED     NONE

        $OUTPUT       c:    the cartesian vector sum of the two given in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure sums together two cartesian coordinates
                      vectors

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_XYZSum
                        (/*IN    */ MATHIT_XYZ           a,
                         /*IN    */ MATHIT_XYZ           b,
                         /*   OUT*/ MATHIT_XYZ          *c,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZSubt

        $TYPE         PROCEDURE

        $INPUT        a:    the first cartesian vector to subtract
                      b:    the second cartesian vector to subtract

        $MODIFIED     NONE

        $OUTPUT       c:    the cartesian vector difference of the two given
                            in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure subtracts together two cartesian
                      coordinates vectors

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_XYZSubt
                        (/*IN    */ MATHIT_XYZ           a,
                         /*IN    */ MATHIT_XYZ           b,
                         /*   OUT*/ MATHIT_XYZ          *c,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZScalProd

        $TYPE         PROCEDURE

        $INPUT        a:    the first vector of the scalar product
                      b:    the second vector of the scalar product

        $MODIFIED     NONE

        $OUTPUT       c:    the scalar product of the two vectors given
                            in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure do the scalar product of two cartesian
                      vectors given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_XYZScalProd
                        (/*IN    */ MATHIT_XYZ           a,
                         /*IN    */ MATHIT_XYZ           b,
                         /*   OUT*/ double              *c,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZCrosProd

        $TYPE         PROCEDURE

        $INPUT        a:    the first cartesian vector of the cross product
                      b:    the second cartesian vector of the cross product

        $MODIFIED     NONE

        $OUTPUT       c:    the cross product of the two vectors passed in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure do the cartesian cross product of two
                      vectors

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_XYZCrosProd
                        (/*IN    */ MATHIT_XYZ           a,
                         /*IN    */ MATHIT_XYZ           b,
                         /*   OUT*/ MATHIT_XYZ          *c,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZModu

        $TYPE         PROCEDURE

        $INPUT        a:    the cartesian vector of which the modulus is nedeed

        $MODIFIED     NONE

        $OUTPUT       modu: the vector modulus

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the modulus of the cartesian
                      vector given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_XYZModu
                        (/*IN    */ MATHIT_XYZ           a,
                         /*   OUT*/ double              *modu,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_XYZVers

        $TYPE         PROCEDURE

        $INPUT        a:    the cartesian vector of which the versor is needed

        $MODIFIED     NONE

        $OUTPUT       v:    the versor of the vector a

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_modu

        $DESCRIPTION  This procedure evaluates the versor of the input given
                      cartesian vector

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_XYZVers
                        (/*IN    */ MATHIT_XYZ           a,
                         /*   OUT*/ MATHIT_XYZ          *v,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CSum

        $TYPE         PROCEDURE

        $INPUT        z1    : the first complex number to sum
                      z2    : the second complex number to sum

        $MODIFIED     NONE

        $OUTPUT       zout  : the sum of the two complex numbers

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine evaluate the sum of two complex numbers

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_CSum
                        (/*IN    */ MATHIT_complex       z1,
                         /*IN    */ MATHIT_complex       z2,
                         /*   OUT*/ MATHIT_complex      *zout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CSubt

        $TYPE         PROCEDURE

        $INPUT        z1    : the first complex number of the subtraction
                      z2    : the complex number to subtract

        $MODIFIED     NONE

        $OUTPUT       zout  : the difference of the two complex numbers

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine evaluate the difference of two complex
                      numbers

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_CSubt
                        (/*IN    */ MATHIT_complex       z1,
                         /*IN    */ MATHIT_complex       z2,
                         /*   OUT*/ MATHIT_complex      *zout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CProd

        $TYPE         PROCEDURE

        $INPUT        z1    : the first complex number to multiply
                      z2    : the second complex number to multiply

        $MODIFIED     NONE

        $OUTPUT       zout  : the complex number product of the two given in
                              input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the complex product of two
                      complex numbers

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_CProd
                        (/*IN    */ MATHIT_complex       z1,
                         /*IN    */ MATHIT_complex       z2,
                         /*   OUT*/ MATHIT_complex      *zout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CConstMult

        $TYPE         PROCEDURE

        $INPUT        c	    : the constant that must multiply the complex number
                      z	    : the complex number to rescale

        $MODIFIED     NONE

        $OUTPUT       zout  : the complex number rescaled

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure rescale a complex number by a constant
                      scalar value passed in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_CConstMult
                        (/*IN    */ double               c,
                         /*IN    */ MATHIT_complex       z,
                         /*   OUT*/ MATHIT_complex      *zout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CConj

        $TYPE         PROCEDURE

        $INPUT        zinp  : the complex number to conjugate

        $MODIFIED     NONE

        $OUTPUT       zout  : the complex number conjugate of the input one

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the complex conjugate of the
                      input compelx number

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_CConj
                        (/*IN    */ MATHIT_complex       zinp,
                         /*   OUT*/ MATHIT_complex      *zout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CModu

        $TYPE         PROCEDURE

        $INPUT        zinp  : the complex number of which the modulus must be
                              computated

        $MODIFIED     NONE

        $OUTPUT       modu  : the complex modulus of the complex number given 
                              in input

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the modulus of the complex number
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_CModu
                        (/*IN    */ MATHIT_complex       zinp,
                         /*   OUT*/ double              *modu,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CPhase

        $TYPE         PROCEDURE

        $INPUT        z	    : the complex number of which the phase must be
                              extracted

        $MODIFIED     NONE

        $OUTPUT       phase : the phase of the complex number, that is the
                              arctangent of the real / imaginary ratio of z
                              in the range   - pi , pi

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluate the argument of the complex
                      number given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_CPhase
                        (/*IN    */ MATHIT_complex       z,
                         /*   OUT*/ double              *phase,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_STYP_CExp

        $TYPE         PROCEDURE

        $INPUT        phase : the phase of the complex number in radians

        $MODIFIED     NONE

        $OUTPUT       z     : the complex number to fill

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the complex number <z> with the
                      complex exponential evaluated at the given phase <phase>

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_STYP_CExp
                        (/*IN    */ double               phase,
                         /*   OUT*/ MATHIT_complex      *z,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Make

        $TYPE         PROCEDURE

        $INPUT        nelem : the wanted number of elements of the array
                      atype : the wanted array type

        $MODIFIED     NONE

        $OUTPUT       array : the pointer to the array we want to fill

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_err_mem_alloc

        $DESCRIPTION  This procedure allocates the wanted array of the wanted
                      type, setting to zero the values of its elements

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Make
                        (/*IN    */ INTx4                nelem,
                         /*IN    */ MATHIT_arr_type      atype,
                         /*   OUT*/ MATHIT_array        *array,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Free

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     array : the pointer to the array we want to free

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure free the allocated memory of the passed
                      array

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Free
                        (/*IN OUT*/ MATHIT_array        *array,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_SetZero

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     array      : the array to set zero

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure set all arry elements to zero

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */

void MATHIP_VECT_SetZero
                        (/*IN OUT*/ MATHIT_array        *array,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Copy

        $TYPE         PROCEDURE

        $INPUT        source	: the source array to copy

        $MODIFIED     NONE

        $OUTPUT       target	: the target array in which the source must
                                  be copied

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure copies an array into another

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Copy
                        (/*IN    */ MATHIT_array         source,
                         /*   OUT*/ MATHIT_array        *target,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_SubCopy

        $TYPE         PROCEDURE

        $INPUT        source	: the source array to copy
                      start_in	: the index of the elements of the source
                                  array from which start to copy the sub array
                      nelem	: the number of elements to copy
                      start_out	: the index of the element of the target array
                                  from which start to fill

        $MODIFIED     target	: the target array in which the source must
                                  be copied

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure copies a part of an array into another in
                      the indicated position

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_SubCopy
                        (/*IN    */ MATHIT_array         source,
                         /*IN    */ INTx4                start_in,
                         /*IN    */ INTx4                nelem,
                         /*IN OUT*/ MATHIT_array        *target,
                         /*IN    */ INTx4                start_out,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Sum

        $TYPE         PROCEDURE

        $INPUT        arr1	: first array to sum
                      arr2	: second array to sum

        $MODIFIED     NONE

        $OUTPUT       arrout	: array sum of the two passed in input

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure sums together two array

        $WARNING      No checks of overflowing problems are done

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Sum
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ MATHIT_array         arr2,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Subt

        $TYPE         PROCEDURE

        $INPUT        arr1	: first array
                      arr2	: array to subtract

        $MODIFIED     NONE

        $OUTPUT       arrout	: array difference of the input given two

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure subtract the elements of one array from
                      another

        $WARNING      No checks of overflowing problems are done

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Subt
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ MATHIT_array         arr2,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ConstMult

        $TYPE         PROCEDURE

        $INPUT        fconst	: a constant double value
                      arrinp	: the array to multiply

        $MODIFIED     NONE

        $OUTPUT       arrout	: the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes a multiplication of an array by
                      a constant

        $WARNING      No check of oferflowing problems is done

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_ConstMult
                        (/*IN    */ double               fconst,
                         /*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ConstAdd

        $TYPE         PROCEDURE

        $INPUT        fconst	: a constant double value
                      arrinp	: the array to be added

        $MODIFIED     NONE

        $OUTPUT       arrout	: the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure adds an array by a constant

        $WARNING      No check of oferflowing problems is done

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_ConstAdd
                        (/*IN    */ double               fconst,
                         /*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Prod

        $TYPE         PROCEDURE

        $INPUT        arr1	: the first array of the product
                      arr2	: the second array of the product

        $MODIFIED     NONE

        $OUTPUT       arrout	: the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes the product element by element of
                      two vectors

        $WARNING      No check of overflowing problems is done

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Prod
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ MATHIT_array         arr2,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_HeterProd

        $TYPE         PROCEDURE

        $INPUT        arr1	: the first array of the product
                      arr2	: the second array of the product

        $MODIFIED     NONE

        $OUTPUT       arrout	: the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes the product element by element of
                      two vectors of different type

        $WARNING      No check of overflowing problems is done

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_HeterProd
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ MATHIT_array         arr2,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_HeterInnerProd

        $TYPE         PROCEDURE

        $INPUT        arr1	: the first array of the product
                      arr2	: the second array of the product

        $MODIFIED     NONE

        $OUTPUT       val    	: the output value

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes the inner products of
                      two vectors of different type

        $WARNING      No check of overflowing problems is done

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_HeterInnerProd
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ MATHIT_array         arr2,
                         /*   OUT*/ double              *val,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Pow

        $TYPE         PROCEDURE

        $INPUT        exp	: the exponent of power

        $MODIFIED     arr       : the array to be powered

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes the power element by element

        $WARNING      No check of overflowing problems is done

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Pow
                        (/*IN    */ MATHIT_array         arrin,
                         /*IN    */ double               exp,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Extract

        $TYPE         PROCEDURE

        $INPUT        source	: the array from which extract the new array
                      start	: index from which start in the subarray
                                  extraction
                      nelem	: number of elements to extract

        $MODIFIED     NONE

        $OUTPUT       subarr	: the target array for the extraction

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure extracts a subarray of the wanted
                      dimensions starting from the wanted position from an
                      array given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Extract
                        (/*IN    */ MATHIT_array         source,
                         /*IN    */ INTx4                start,
                         /*IN    */ INTx4                nelem,
                         /*   OUT*/ MATHIT_array        *subarr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Size

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the input array of which we want to know
                                  the size

        $MODIFIED     NONE

        $OUTPUT       Nelements	: the number of elements of the array

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure returns the number of elements of the array
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Size
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ INTx4               *Nelements,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Total

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the array of which we want know the sum of
                                  the elements

        $MODIFIED     NONE

        $OUTPUT       sum	: the sum of the input array' s elements

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure returns the evaluated sum of the elements
                      of the array passed in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Total
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ double              *sum,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_MinMax

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the array of which we want know the sum of
                                  the elements
                      mask      : the array of UINTx1 element to be used (1)
                                  or not (0)

        $MODIFIED     NONE

        $OUTPUT       min	: the min value of the input array' s elements
                      max       : the max value of the input array' s elements

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure returns the min and the max of the elements
                      of the array passed in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_MinMax
                        (/*IN    */ MATHIT_array         arrinp,
                         /*IN    */ MATHIT_array         mask,
                         /*   OUT*/ float               *min,
                         /*   OUT*/ float               *max,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Mean

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the array to which the mean value must be
                                  done

        $MODIFIED     NONE

        $OUTPUT       mean	: the mean value of the array elements

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates the mean value of the elements
                      of the array passed in input

        $WARNING      No check of overflowing problems must be done

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Mean
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ double              *mean,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Sigma

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the array of which the sigma must be
                                  evaluated
                      nconst	: the number of constraints to consider in
                                  the count

        $MODIFIED     NONE

        $OUTPUT       sigma	: the sigma value. It's the standard deviation
                                  with nconst = 1, or the RMS WRT the mean value
                                  with nconst = 0

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure evaluates the root sum of square of the
                      elements of the input array minus their mean value,
                      divided by the number of elements of the array decreased
                      by the number of constraints imposed to the data

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Sigma
                        (/*IN    */ MATHIT_array         arrinp,
                         /*IN    */ INTx4                nconst,
                         /*   OUT*/ double              *sigma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_FillConst

        $TYPE         PROCEDURE

        $INPUT        const	: the value to assign to the array elements

        $MODIFIED     arrinp	: the input array to fill

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure assignes a value user defined to the
                      elements of the input array

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_FillConst
                        (/*IN    */ void                *k,
                         /*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_FillArray

        $TYPE         PROCEDURE

        $INPUT        inp_array_p    : pointer to the input array
                      n_elem         : number of elements of the input array
                      inp_data_type  : input data type among that defined by:
                                       LDEFIE_dt_type:
                                       - LDEFIE_dt_UINTx1    ( byte data )
                                       - LDEFIE_dt_UINTx2    ( real data )
                                       - LDEFIE_dt_2_INTx2   ( complex data )
                                       - LDEFIE_dt_float     ( real floating )
                                       - LDEFIE_dt_2_float   ( complex
                                                               floating )

        $MODIFIED     out_array      : output array to fill

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_arr_uncomp
                      ERRSID_MATH_no_conv
                      ERRSID_MATH_arr_undef

        $DESCRIPTION  This procedure fills the array in output with the
                      elements of the buffer pointed by the passed pointer
                      <inp_array_p>

        $WARNING      THE ARRAY OF OUTPUT MUST BE CREATED BEFORE.
                      NOT ALL THE POSSIBLE CONVERSIONS ARE HANDLED

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_FillArray
                        (/*IN    */ void                *inp_array_p,
                         /*IN    */ INTx4                n_elem,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN OUT*/ MATHIT_array        *out_array,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ToFloat

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     arrinp	: the array to cast

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_no_conv

        $DESCRIPTION  This procedure makes a cast of an array to float type

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_ToFloat
                        (/*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ToUChar

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     arrinp	: the array to cast

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_no_conv

        $DESCRIPTION  This procedure makes a cast of an array to type unsigned
                      character

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_ToUChar
                        (/*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ToInt

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     arrinp	: the array to cast

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_no_conv

        $DESCRIPTION  This procedure makes a cast of an array to type int

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_ToInt
                        (/*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ToIntFloor

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     arrinp	: the array to cast

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_no_conv

        $DESCRIPTION  This procedure makes a cast of an array to type int
                      with floor conventions for float numbers

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_ToIntFloor
                        (/*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_ToUInt

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     arrinp	: the array to cast

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_no_conv

        $DESCRIPTION  This procedure makes a cast of an array to type unsigned
                      int

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_ToUInt
                        (/*IN OUT*/ MATHIT_array        *arrinp,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Complex

        $TYPE         PROCEDURE

        $INPUT        arrea	: the array with the real part of the complex
                                  output array
                      arima	: the array with the imaginary part of the
                                  complex output array

        $MODIFIED     NONE

        $OUTPUT       arrout	: the complex array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_no_complex

        $DESCRIPTION  This procedure makes a complex array with the real and
                      the imaginary part equals to that given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Complex
                        (/*IN    */ float               *arrea,
                         /*IN    */ float               *arima, 
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Conj

        $TYPE         PROCEDURE

        $INPUT        arrinp    : the array to conjugate

        $MODIFIED     NONE

        $OUTPUT       arrout	: the array conjugate

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_arr_uncomp

        $DESCRIPTION  This procedure makes the complex conjugation of a complex
                      array

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Conj
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ MATHIT_array        *arrout,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Modul

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the input array

        $MODIFIED     NONE

        $OUTPUT       modul	: the array of module of each element of the 
                                  input array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure evaluates the modulus of the elemens of
                      the input array

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Modul
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ float               *modul,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Real

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the input array

        $MODIFIED     NONE

        $OUTPUT       rearr	: the array with the real part of the elements
                                  of the input one

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure evaluates the real part of the array 
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Real
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ float               *rearr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Imaginary

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the input array

        $MODIFIED     NONE

        $OUTPUT       rearr	: the array with the imaginary part of the 
                                  elements of the input one

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure evaluates the imaginary part of the array 
                      given in input

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Imaginary
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ float               *imarr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Phase

        $TYPE         PROCEDURE

        $INPUT        arrinp	: the input array

        $MODIFIED     NONE

        $OUTPUT       phase	: the array with the phase of the elements
                                  of the input array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr

        $DESCRIPTION  This procedure evaluates the phase of the elements of
                      the array given in input. The phase is defined in the
                      range - pi , + pi

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Phase
                        (/*IN    */ MATHIT_array         arrinp,
                         /*   OUT*/ double              *phase,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_CTo2Float

        $TYPE         PROCEDURE

        $INPUT        inp_arr : array to cast

        $MODIFIED     NONE

        $OUTPUT       out_arr : transformed array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_wrong_type

        $DESCRIPTION  This procedure copies a complex array into a 2 float one

        $WARNING      NONE

        $PDL          - Checks if the types of array are the right ones
                      - Checks if the number of elements are compatible
                      - If they aren't compatible
                            - Set the new number of elements
                            - Re-allocates the output array
                      - Endif
                      - Loop over the elements of the input array
                            - Copies the real part
                            - Copies the imaginary part
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_CTo2Float
                        (/*IN    */ MATHIT_array         inp_arr,
                         /*   OUT*/ MATHIT_array        *out_arr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_2FloatToC

        $TYPE         PROCEDURE

        $INPUT        inp_arr : array to cast

        $MODIFIED     NONE

        $OUTPUT       out_arr : transformed array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_wrong_type

        $DESCRIPTION  This procedure copies a 2 float array into a complex one

        $WARNING      NONE

        $PDL          - Checks if the types of array are the right ones
                      - Checks if the number of elements are compatible
                      - If they aren't compatible
                            - Set the new number of elements
                            - Re-allocates the output array
                      - Endif
                      - Loop over the elements of the input array
                            - Copies the real part
                            - Copies the imaginary part
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_2FloatToC
                        (/*IN    */ MATHIT_array         inp_arr,
                         /*   OUT*/ MATHIT_array        *out_arr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_Exp

        $TYPE         PROCEDURE

        $INPUT        phase   : array with the phase values

        $MODIFIED     NONE

        $OUTPUT       exp_arr : array with the exponential of the phase

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure evaluates an array with the exponential
                      of the phase given in input

        $WARNING      NONE

        $PDL          - Checks the number of elements of the two arrays
                      - Checks the output array type
                      - Loop over the phase array elements
                            - Evaluates the real part of the exponential value
                              of the phase
                            - Evaluates the imaginary  part of the exponential
                              value of the phase
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_Exp
                        (/*IN    */ MATHIT_array         phase,
                         /*   OUT*/ MATHIT_array        *exp_arr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_DFFT_1D

        $TYPE         PROCEDURE

        $INPUT        signal_s	: the input complex signal to transform
                      n_in	: the lenght of the input signal
                      f_flag	: a flag indicating what kind of FFT operation
                                  the procedure must computate:
                                  -> 0	: direct FFT
                                  -> 1	: inverse FFT
                                  -> -1	: clean the left memories

        $MODIFIED     NONE

        $OUTPUT       signal_f	: the FFT of the input signal

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_arr_uncomp
                      ERRSID_MATH_err_mem_alloc
                      ERRSID_MATH_not_allowed_flg_val

        $DESCRIPTION  This procedure evaluates the direct or the inverse FFT
                      of the input signal.

        $WARNING      The procedure allocates some bytes of memories declared
                      static. At the end of the FFTs of the block that calls
                      MATHIP_DFFT_1D many times, the procedure must be called
                      with f_flag = -1, to free all the memories allocated by it

        $PDL          - Switch among the various functions to do
                            - Case direct FFT
                                  - Checks the input signal number of elements
                                    and type
                                  - Print the warning message if the number of
                                    elements is lesser then the number of samles
                                    that makes the FFT optimized
                                  - Copies the signal array into a float one
                                  - If it's the first FFT of that length
                                        - Allocates the temporary buffer if
                                          it's not yet done
                                        - Makes the FFT initialization
                                  - Endif
                                  - Makes the direct FFT
                                  - Normalizes the FFT
                                  - Copies the float signal into the output one
                                  - Frees the temporary allocated memories
                            - End case
                            - Case inverse FFT
                                  - Checks the input signal number of elements
                                    and type
                                  - Print the warning message if the number of
                                    elements is lesser then the number of samles
                                    that makes the FFT optimized
                                  - Copies the signal array into a float one
                                  - If it's the first FFT of that length
                                        - Allocates the temporary buffer if
                                          it's not yet done
                                        - Makes the FFT initialization
                                  - Endif
                                  - Makes the inverse FFT
                                  - Copies the float signal into the output one
                                  - Frees the temporary allocated memories
                            - End case
                            - Case Clean up
                                  - Frees the static allocated memories
                                  - Reset some variables
                            - End case
                      - End switch

   $EH
   ========================================================================== */
   extern void MATHIP_DFFT_1D
                        (/*IN    */ MATHIT_array         signal_s,
                         /*IN    */ INTx4                n_in,
                         /*IN    */ INTx1                f_flag,
                         /*   OUT*/ MATHIT_array        *signal_f,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_DFFT_2D

        $TYPE         PROCEDURE

        $INPUT        signal_inp    : 2D complex array containing the input
                                      signal
                      nrow_in	    : number of rows of the input 2D signal
                      ncol_in	    : number of columns of the input 2D signal
                      f_flag	    : a flag indicating what kind of FFT 
                                      operation the procedure must computate:
					-> 0	: direct FFT
					-> 1	: inverse FFT

        $MODIFIED     NONE

        $OUTPUT       signal_out    : 2D complex array containing the output
                                      signal in the frequency domain

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_arr
                      ERRSID_MATH_arr_uncomp
                      ERRSID_MATH_not_allowed_flg_val

        $DESCRIPTION  This procedure evaluates the 2D direct or inverse FFT of
                      the input signal

        $WARNING      NONE

        $PDL          - Checks the number of elements of the input signal
                      - Allocates a temporary line array
                      - Switch WRT the required FFT operations
                            - Case direct FFT
                                  - Loop over the image rows
                                        - Extracts the current row
                                        - Makes its FFT
                                        - Copies the result in the output array
                                  - End loop
                                  - Re-allocates the temporary array
                                  - Loop over the FFT image columns
                                        - Copies the column in the temporary
                                          array
                                        - Make its direct FFT
                                        - Copies the result in the output array
                                  - End loop
                            - End case
                            - Case inverse FFT
                                  - Loop over the image rows
                                        - Extracts the current row
                                        - Makes its inverse FFT
                                        - Copies the result in the output array
                                  - End loop
                                  - Re-allocates the temporary array
                                  - Loop over the FFT image columns
                                        - Copies the column in the temporary
                                          array
                                        - Make its inverse FFT
                                        - Copies the result in the output array
                                  - End loop
                            - End case
                      - End switch
                      - Clean up the allocated static memories
                      - De-allocates the allocated temporary array

   $EH
   ========================================================================== */
   extern void MATHIP_DFFT_2D
                        (/*IN    */ MATHIT_array         signal_inp,
                         /*IN    */ INTx4                nrow_in,
                         /*IN    */ INTx4                ncol_in,
                         /*IN    */ INTx1                f_flag,
                         /*   OUT*/ MATHIT_array        *signal_out,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_Linear

        $TYPE         PROCEDURE

        $INPUT        x	      : array with the abscissa values
		      y	      : array with the ordinate values
		      x_curr  : actual abscissa at which the interpolated value
				must be interpolated

        $MODIFIED     NONE

        $OUTPUT       out_val : interpolated value

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_no_suff_arr_elem
                      ERRSID_MATH_xy_num_diff
		      ERRSID_MATH_abscissa_out
                      ERRSID_MATH_math_err
                      ERRSID_MATH_arr_uncomp
                      ERRSID_MATH_arr_undef

        $DESCRIPTION  This procedure evaluates the linear interpolation of the
		      array <y> at the abscissa value <x>

        $WARNING      The abscissa value must be increasing ordered

        $PDL          - Search the class of abscissa values in which the
                        actual value fall
                      - Evaluate the coefficients of the interpolation
                      - Evaluate the interpolated value

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_Linear
                        (/*IN    */ MATHIT_array	 x,
			 /*IN    */ MATHIT_array         y,
			 /*IN    */ float		 x_curr,
                         /*   OUT*/ void 	        *out_val,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_NearestNeighbor

        $TYPE	      PROCEDURE

        $INPUT        InpIma	 : input matrix
		      NRowInp	 : number of rows of the input matrix
		      NColInp	 : number of columns of the input matrix
		      OutPoint	 : 2D array with the row, col coordinates of the
				   the points in which to interpolate
		      NRowOut	 : number of rows of the output matrix
		      NColOut	 : number of columns of the output matrix
		      InvVal	 : value for the points out of borders
		      DataType	 : flag to indicate the type of the input and
				   the output matrices

        $MODIFIED     NONE

        $OUTPUT       OutIma	 : matrix with the values of the input matrix
				   into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_interp_not_allow

        $DESCRIPTION  This procedure makes the Nearest Neighbor interpolation
		      of a matrix on the points coordinates given by an array
		      of row, col coordinates

        $WARNING      The invalid value <InvVal> is a number. For the complex
		      type matrix, the real and imaginary part of each element
		      are filled both with the value <InvVal>.
		      The type of the input and the output matrix must be equal.
		      No check is done here

        $PDL          - Loop over the number of output rows
                           - Loop over the number of output columns
                                 - Evaluate the nearest point coordinates
                                 - Fill the output block
                           - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_NearestNeighbor
                        (/*IN    */ void               **InpIma,
			 /*IN    */ UINTx4               NRowInp,
			 /*IN    */ UINTx4               NColInp,
			 /*IN    */ MATHIT_RC_float    **OutPoint,
			 /*IN    */ UINTx4               NRowOut,
			 /*IN    */ UINTx4               NColOut,
			 /*IN    */ void                *InvVal,
			 /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_Bilinear

        $TYPE	      PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders
                      DataType   : flag to indicate the data type of the input
                                   and the output matrices among the enumerate
                                   LDEFIE_dt_type:
                                   - LDEFIE_dt_UINTx1    ( byte data )
                                   - LDEFIE_dt_UINTx2    ( real data )
                                   - LDEFIE_dt_2_INTx2   ( complex data )
                                   - LDEFIE_dt_float     ( real floating )
                                   - LDEFIE_dt_2_float   ( complex floating )

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_interp_not_allow

        $DESCRIPTION  This procedure makes the Bilinear interpolation of a
		      matrix on the points coordinates given by an array of row,
		      col coordinates

        $WARNING      The invalid value <InvVal> is a number. For the complex
                      type matrix, the real and imaginary part of each element
                      are filled both with the value <InvVal>

        $PDL	      - Loop over the number of output rows' coordinates
		            - Loop over the number of output columns'
			      coordinates
			          - Evaluate the image coordinates of the image
				    point on the top left of the square
				    surrounding the wanted point
                                  - If it is in the image or not
				        - Evaluate the value of the point with
					  coordinates equals to the top square
					  row at the wanted fractionary column
					  with a linear interpolation
				        - Evaluate the value of the point with
					  coordinates equals to the bottom
					  square row at the wanted fractionary
					  column with a linear interpolation
					- Evaluated the output value with a
					  linear interpolation between the two
					  interpolated points at the fractionary
					  row
                                  - End if
				  - Else
				        - Put the invalid value as output
					  interpolated value
				  - End else
			    - End loop
		      - End loop

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_Bilinear
                        (/*IN    */ void               **InpIma,
			 /*IN    */ UINTx4               NRowInp,
			 /*IN    */ UINTx4               NColInp,
			 /*IN    */ MATHIT_RC_float    **OutPoint,
			 /*IN    */ UINTx4               NRowOut,
			 /*IN    */ UINTx4               NColOut,
			 /*IN    */ float                InvVal,
			 /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_CubiConvInit

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MATHPV_CubiConvTable : table with the values of the
                                             cubic convolution kernel

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the table with the values of the
                      cubic convolution kernel that will be used to convolve
                      the image to interpolate

        $WARNING      NONE

        $PDL          - Loop over the intervals of delta
                            - Evaluates the value of the coordinates normalized
                              at the rigth range
                            - Loop over the points of the image to interpolate
                                  - Evaluates the complement of the delta
                                  - Evaluates the cubic convolution kernel
                            - End loop
                      - End loop

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_CubiConvInit
                        (/*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_CubicConvolution

        $TYPE         PROCEDURE

        $INPUT        InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders
                      DataType   : flag to indicate the data type of the input
                                   and the output matrices among the enumerate
                                   LDEFIE_dt_type:
                                   - LDEFIE_dt_UINTx1    ( byte data )
                                   - LDEFIE_dt_UINTx2    ( real data )
                                   - LDEFIE_dt_2_INTx2   ( complex data )
                                   - LDEFIE_dt_float     ( real floating )
                                   - LDEFIE_dt_2_float   ( complex floating )

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHPC_cc_func : array of functions to make the cubic
                                       convolution with a given input image
                                       type

        $RET_STATUS   ERRSID_MATH_negative_dimen
                      ERRSID_MATH_interp_not_allow

        $DESCRIPTION  This procedure makes the Cubic Convolution interpolation
                      of a matrix on the points coordinates given by an array
                      of row, col coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Checks the number of rows and columns
                      - Switch WRT the input data type
                            - Puts the index WRT the data type
                      - End switch
                      - Calls the interpolation function

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_CubicConvolution
                        (/*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_CubiConvClose

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MATHPV_CubiConvTable : table with the values of the
                                             cubic convolution kernel in the
                                             columns direction

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure frees the memories allocated to store the
                      tabulated values for the cubic convolution interpolation

        $WARNING      NONE

        $PDL          - Check if the double pointer to the table is not NULL
                            - Loop over the rows of the table
                                  - Frees the allocated rows memory
                            - End loop
                            - Deallocates the double pointer memories
                      - End if

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_CubiConvClose
                        (/*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_SincInit

        $TYPE         PROCEDURE

        $INPUT        Fdc     : array of frequences for the azimuth
                                modulation
                      NImages : number of images on which the sinc
                                interpolation can be done
        $MODIFIED     NONE

        $OUTPUT       The azimuth and range sinc tables are created and filled

        $GLOBAL       MATHPV_SincRowTable       : the table of sinc values to
                                                  interpolate in the range
                                                  direction
                      MATHPV_SincColTable       : the table of sinc values to
                                                  interpolate in the azimuth
                                                  direction
                      MATHIV_SincTableLength    : the reciprocal of the
                                                  precision required in the
                                                  interpolation

        $RET_STATUS   ERRSID_MATH_even_sinc_num
                      ERRSID_MATH_err_mem_alloc

        $DESCRIPTION  This procedure initialize the tables for the sinc
                      interpolation.

        $WARNING      AT THE END OF THE TOOL THE COLSURE PROCEDURE MUST BE
                      CALLED.

        $PDL          - Checks the number of images
                      - Checks the table dimensions
                      - Allocates the sinc tables
                      - Loop over the images
                            - Allocates the range table
                            - Zeroes the table
                            - Allocates the azimuth table
                            - Zeroes the table
                              interpolate
                                  - Evaluates the delta
                                  - Fills the corresponding tables row
                            - End loop
                      - End Loop

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_SincInit
                        (/*IN    */ float               *Fdc,
                         /*IN    */ INTx4                NImages,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_Sinc

        $TYPE         PROCEDURE

        $INPUT        imanum     : ID of the image
                      InpIma     : input matrix
                      NRowInp    : number of rows of the input matrix
                      NColInp    : number of columns of the input matrix
                      OutPoint   : 2D array with the row, col coordinates of the
                                   the points in which to interpolate
                      NRowOut    : number of rows of the output matrix
                      NColOut    : number of columns of the output matrix
                      InvVal     : value for the points out of borders
                      DataType   : flag to indicate the data type of the input
                                   and the output matrices among the enumerate
                                   LDEFIE_dt_type:
                                   - LDEFIE_dt_UINTx1    ( byte data )
                                   - LDEFIE_dt_UINTx2    ( real data )
                                   - LDEFIE_dt_2_INTx2   ( complex data )
                                   - LDEFIE_dt_float     ( real floating )
                                   - LDEFIE_dt_2_float   ( complex floating )

        $MODIFIED     NONE

        $OUTPUT       OutIma     : matrix with the values of the input matrix
                                   into the interpolated points

        $GLOBAL       MATHPC_sinc_func : array of functions to make the sinc
                                         interpolation of a matrix on the points
                                         coordinates given by an array of row,
                                         col coordinates

        $RET_STATUS   ERRSID_MATH_imanum_out
                      ERRSID_MATH_negative_dimen
                      ERRSID_MATH_interp_not_allow

        $DESCRIPTION  This procedure makes the Sinc interpolation of a matrix
                      on the points coordinates given by an array of row, col
                      coordinates

        $WARNING      THE INVALID VALUE <InvVal> IS A NUMBER. FOR THE COMPLEX
                      TYPE MATRIX, THE REAL AND IMAGINARY PART OF EACH ELEMENT
                      ARE FILLED BOTH WITH THE VALUE <InvVal>

        $PDL          - Checks the number of rows and columns
                      - Switch WRT the input data type
                            - Puts the index WRT the data type
                      - End switch
                      - Calls the interpolation function

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_Sinc
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ MATHIT_RC_float    **OutPoint,
                         /*IN    */ UINTx4               NRowOut,
                         /*IN    */ UINTx4               NColOut,
                         /*IN    */ float                InvVal,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_SincClose

        $TYPE         PROCEDURE

        $INPUT        NImages : number of images opened

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       MATHIV_SincTableLength : inverse of the precision required
                                               for the sinc interpolator kernel
                      MATHPV_SincRowTable    : tabulated values of the sinc
                                               function for various delta values
                                               in the range direction
                      MATHPV_SincColTable    : tabulated values of the sinc
                                               function for various delta values
                                               in the azimuth direction

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure deallocates the memories allocated in the
                      initialization procedure for the sinc tables

        $WARNING      THIS PROCEDURE MUST BE CALLED AT THE END OF ALL THE
                      INTERPOLATION PROCEDURES THAT USES THE SINC INTERPOLATION
                      FUNCTION

        $PDL          - Deallocates the row table
                      - Deallocate the column table

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_SincClose
                        (/*IN    */ INTx4                NImages,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_FFTConstShift

        $TYPE         PROCEDURE

        $INPUT        NRowInp  : number of rows of the image block
                      NColInp  : number of columns of the image block
                      DataType : image data type
                      InpIma   : input image block
                      shift    : shifts values in row and column direction

        $MODIFIED     NONE

        $OUTPUT       OutIma   : output image block

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_dim
                      ERRSID_MATH_shift_too_high

        $DESCRIPTION  This procedure shifts the image block of the wanted
                      constant amount in the row and column directions

        $WARNING      THE OUTPUT IMAGE MUST BE OF THE SAME TYPE OF THE INPUT
                      ONE

        $PDL          - Checks the numbers of rows and columns
                      - Checks the shifts values
                      - Allocates the necessary vectors
                      - Fills an array with the input image
                      - Evaluates the utility variables for the row shift
                      - Loop over the image columns
                            - Evaluates the phase value
                            - Evaluates the corresponding exponential values
                      - End loop
                      - Makes the 2D FFT of the image
                      - Re-allocates the arrays
                      - Loop over the image rows
                            - Copies the row in a temporary array
                            - Multiplicates the row by the exponential before
                              evaluated
                            - Copies the modified row in the FFT matrix
                      - End loop
                      - Evaluates the constants for the column shift
                      - Re-allocates the necessary memories
                      - Loop over the rows
                            - Evaluates the phase value
                            - Evaluates the corresponding exponential values
                      - End loop
                      - Loop over the FFT columns
                            - Copies the column in a temporary array
                            - Multiplicates the column by the exponential before
                              evaluated
                            - Copies the modified column in the FFT matrix
                      - End loop
                      - De-allocates the memories
                      - Makes the inverse FFT
                      - Copies the obtained shifted image in the output variable
                      - Clean-up the FFT lefted static memories

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_FFTConstShift
                        (/*IN    */ UINTx4               NRowInp,
                         /*IN    */ UINTx4               NColInp,
                         /*IN    */ LDEFIT_data_type     DataType,
                         /*IN    */ void               **InpIma,
                         /*IN    */ MATHIT_RC            shift,
                         /*   OUT*/ void               **OutIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_ImageColShift

        $TYPE         PROCEDURE

        $INPUT        NRowInp  : number of rows of the image portion
                      NColInp  : number of columns of the image portion
                      shift    : array of shifts to apply to the image rows
                      DataType : data type of the image

        $MODIFIED     InpIma   : the image to shift

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_dim

        $DESCRIPTION  This procedure shifts each row of a block image of a
                      wanted number (floating) of pixels in the columns
                      direction

        $WARNING      NONE

        $PDL          - Checks the number of rows and columns of the block
                        image
                      - Initializes the usefull variables
                      - Allocates the wanted memories
                      - Loop over the number of columns
                            - Evaluates the phase of the multiplicator factor
                            - Fills the vector element with the multiplication
                              factor
                            - Fills the vector element complementar to the
                              current column
                      - End loop
                      - Fills the central element of the multiplication factors
                        vector if the total number of elements if odd
                      - Loop over the rows of the image block
                            - Evaluates the factor depending by the row shift
                            - Re-scales the phase array by the evaluate factor
                            - Zeroes the signal vector
                            - Fills the signal vector with the image row
                            - Makes the FFT of the signal
                            - Multiplicates the signal FFT with the phase
                              vector
                            - Makes the inverse FFT of the signal FFT
                            - Fills the image row with the new values
                      - End loop
                      - Clears all the memories of the FFT evaluation
                      - Frees the allocated memories

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_ImageColShift
                        (/*IN    */ UINTx4              NRowInp,
                         /*IN    */ UINTx4              NColInp,
                         /*IN    */ float              *shift,
                         /*IN    */ LDEFIT_data_type    DataType,
                         /*IN OUT*/ void              **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_INTR_ImageRowShift

        $TYPE         PROCEDURE

        $INPUT        NRowInp  : number of rows of the image portion
                      NColInp  : number of columns of the image portion
                      shift    : array of shifts to apply to the image columns
                      DataType : data type of the image

        $MODIFIED     InpIma   : the image to shift

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_dim

        $DESCRIPTION  This procedure shifts the columns of a block image of a
                      wanted number (floating) of pixels in the row direction

        $WARNING      NONE

        $PDL          - Checks the number of rows and columns of the block
                        image
                      - Initializes the usefull variables
                      - Allocates the wanted memories
                      - Loop over the number of columns
                            - Evaluates the phase of the multiplicator factor
                            - Fills the vector element with the multiplication
                              factor
                            - Fills the vector element complementar to the
                              current row
                      - End loop
                      - Fills the central element of the multiplication factors
                        vector if the total number of elements if odd
                      - Loop over the columns of the image block
                            - Evaluates the factor depending by the column shift
                            - Re-scales the phase array by the evaluate factor
                            - Zeroes the signal vector
                            - Fills the signal vector with the image column
                            - Makes the FFT of the signal
                            - Multiplicates the signal FFT with the phase
                              vector
                            - Makes the inverse FFT of the signal FFT
                            - Fills the image row with the new values
                      - End loop
                      - Clears all the memories of the FFT evaluation
                      - Frees the allocated memories

   $EH
   ========================================================================== */
   extern void MATHIP_INTR_ImageRowShift
                        (/*IN    */ UINTx4              NRowInp,
                         /*IN    */ UINTx4              NColInp,
                         /*IN    */ float              *shift,
                         /*IN    */ LDEFIT_data_type    DataType,
                         /*IN OUT*/ void              **InpIma,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         MATHIP_VECT_MatrixProduct

        $TYPE         PROCEDURE

        $INPUT        arr1    : array to multiply from left
                      NRow    : Number of rows of the first matrix to
                                multiply
                      arr2    : array to multiply from rigth
                      NCol    : Number of columns of the second matrix to
                                multiply

        $MODIFIED     NONE

        $OUTPUT       arr_out : output array with the rows columns product of
                                the two 2D array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_MATH_null_dim
                      ERRSID_MATH_arr_uncomp
                      ERRSID_MATH_arr_undef
                      ERRSID_MATH_wrong_dim
                      ERRSID_MATH_no_suff_arr_elem

        $DESCRIPTION  This procedure evaluates the rows by columns product of
                      two matrix written as array monodimensional

        $WARNING      THE RESULT IS ALWAYS A FLOATING POINT ARRAY WITH THE
                      RESULT STORED BY ROWS SEQUENTIALLY

        $PDL          - Checks the input array
                      - Checks the consistency od the array
                      - Checks mutually consistency of input and output
                      - Evaluates the internal number of rows and columns
                      - Switches over the different input data type
                            - Makes the rows by columns products of two
                              matrices
                      - End Switch

   $EH
   ========================================================================== */
   extern void MATHIP_VECT_MatrixProduct
                        (/*IN    */ MATHIT_array         arr1,
                         /*IN    */ INTx4                NRow,
                         /*IN    */ MATHIT_array         arr2,
                         /*IN    */ INTx4                NCol,
                         /*   OUT*/ MATHIT_array        *arr_out,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MATHIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/*   extern void MATHIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         MATHIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void MATHIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) MATHIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         POW

      $TYPE         MACRO

      $INPUT        base    : base to exponentiate
                    exp	    : exponent to which the base must be elevated

      $MODIFIED     NONE

      $OUTPUT       value   : the result of the exponentiation of the base
                              to the exponent

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  Evaluate the pow function of math.h with the correct
                    check for pow(0,0) in order to allow the porting

                    POW( (*IN    *) base,
                         (*IN    *) exp,
                         (*   OUT*) value )

      $WARNING      NONE

   $EH
   ========================================================================== */
#ifdef POW
#undef POW
#endif
#ifndef __IBM__
#define POW( base, exp ) \
   ( ( ( base == 0 ) && ( exp == 0 ) ) ? 1 : pow( (double)base, (double)exp ) )
#else
#define POW( base, exp ) (pow( (double)base, (double)exp ))
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         POLY 

      $TYPE         MACRO

      $INPUT        inp_val	: value at which the polynomial must be
                                  evaluated
                    degree	: polynomial degree
                    coeff	: coefficients of the polynomial to evaluate

      $MODIFIED     NONE

      $OUTPUT       value	: the result of the polynomial evaluation

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  Evaluate the polynomial value given by the <inp_val>
                    exponentiated to the degree <degree> with the polynomial
                    coefficients given by <coeff>

                    POLY( value ) ( (*IN    *) inp_val,
                                    (*IN    *) degree,
                                    (*IN    *) coeff,
                                    (*   OUT*) value )

      $WARNING      NONE

   $EH
   ========================================================================== */
#ifdef POLY
#undef POLY
#endif
#define POLY( inp_val, degree, coeff, value )                                  \
{                                                                              \
   UINTx2      deg;                                                            \
                                                                               \
   value = 0.;                                                                 \
   for ( deg=0; deg<=degree; deg++ )                                           \
      value += coeff[ deg ] * POW( inp_val, deg );                             \
}

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIM_init_array

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     array   : array to initialize

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  Initializes the array of type MATHIT_array 

                    MATHIM_init_array
                                ( (*IN OUT*) MATHIT_array array )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
#define MATHIM_init_array( array )                                         \
{                                                                          \
   array.nelem = 0;                                                        \
   array.atype = MATHIE_undef;                                             \
   array.ap = (void *) NULL;                                               \
}                                                                          \

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIM_init_complex

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     z	: complex number to initialize

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  Initializes the complex object of type MATHIT_complex 

                    MATHIM_init_complex
                                ( (*IN OUT*) MATHIT_complex z )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
#define MATHIM_init_complex( z )                                           \
{                                                                          \
   z.rea = 0.;                    /* real part ... */                      \
   z.ima = 0.;                    /* ... and imaginary part */             \
}                                                                          \

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         MATHIM_arr_elem_val

      $TYPE         MACRO

      $INPUT        arr : an array variable
	            i   : the index to be dereferenced

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  Return the value of the index i of the array according its
                    type

                    MATHIM_arr_elem_val
                                ( (*IN    *) MATHIT_array arr
                                  (*IN    *) UINTx4       i )

      $WARNING      DO NOT USE FOR COMPLEX ARRAY TYPE !!!
		    DO NOT USE INSIDE LOOP (Test are expensive in terms
                    of CPU time)

      $PDL

   $EH
   ========================================================================== */
#define MATHIM_arr_elem_val( arr, i )                                      \
((arr.atype == MATHIE_float) ? (*( (float *)arr.ap + i)) :                 \
 ((arr.atype == MATHIE_uchar) ? (*( (UINTx1 *)arr.ap + i)) :               \
  ((arr.atype == MATHIE_sintx4) ? (*( (INTx4 *)arr.ap + i)) :              \
   ((arr.atype == MATHIE_uintx4) ? (*( (UINTx4 *)arr.ap + i)) :            \
                                   (*( (UINTx2 *)arr.ap + i))              \
   )                                                                       \
  )                                                                        \
 )                                                                         \
)                                                                          \

/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#ifdef __VMS__

#define ERRSID_MATH_err_mem_alloc        2
#define ERRSID_MATH_one_point            3
#define ERRSID_MATH_num_err              4
#define ERRSID_MATH_insuff_num_of_data   5
#define ERRSID_MATH_null_modu            6
#define ERRSID_MATH_arr_uncomp           7
#define ERRSID_MATH_null_arr             8
#define ERRSID_MATH_no_suff_arr_elem     9
#define ERRSID_MATH_no_conv             10
#define ERRSID_MATH_no_complex          11
#define ERRSID_MATH_not_allowed_flg_val 12
#define ERRSID_MATH_FFT_few_elem        13
#define ERRSID_MATH_insuff_coeff        14
#define ERRSID_MATH_xy_num_diff         15
#define ERRSID_MATH_arr_undef           16
#define ERRSID_MATH_math_err            17
#define ERRSID_MATH_interp_not_allow    18
#define ERRSID_MATH_TEST_error          19
#define ERRSID_MATH_abscissa_out        20
#define ERRSID_MATH_negative_dimen      21
#define ERRSID_MATH_even_sinc_num       22
#define ERRSID_MATH_delta_out           23
#define ERRSID_MATH_table_not_allocated 24
#define ERRSID_MATH_null_dim            25
#define ERRSID_MATH_data_type_not_allow 26
#define ERRSID_MATH_shift_too_high      27
#define ERRSID_MATH_wrong_type          28
#define ERRSID_MATH_change_nelem        29
#define ERRSID_MATH_wrong_dim           30
#define ERRSID_MATH_imanum_out          31

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef MATH_GLBL
   GLOBAL char *MATHIV_ERRS_error_message[] = 
                        { "No error happens",                           /* 0 */
                          "Generic error happens",                      /* 1 */
                          "SYSTEM ERROR: memory allocation error",      /* 2 */
                          "Dimension error",                            /* 3 */
                          "Numerical error:",                           /* 4 */
                          "Not enough data",                            /* 5 */
                          "The vector has zero modulus",                /* 6 */
                          "Array not compatible",                       /* 7 */
                          "Array with no elements",                     /* 8 */
                          "Array with unsufficient number of elements", /* 9 */
                          "Conversion not possible",                    /* 10 */
                          "Output array not of complex type",           /* 11 */
                          "Flag value not allowed",                     /* 12 */
                          "The FFT is not optimized:too few elements",  /* 13 */
                          "Insufficient number of coefficients",        /* 14 */
		   "Different number of ordinates and absissa values",  /* 15 */
			  "Array type not defined",                     /* 16 */
			  "MATHEMATIC ERROR",                           /* 17 */
		"Interpolation not applicable to this data type",       /* 18 */
			  "MATH TEST ERROR",                            /* 19 */
			  "Abscissa out of range of tabulated values",  /* 20 */
                          "Negative dimension(s)",                      /* 21 */
                          "Number of different sinc is even",           /* 22 */
                          "Sinc delta out of range",                    /* 23 */
                          "Interpolation tables not allocated",         /* 24 */
                          "Null dimension(s)",                          /* 25 */
                          "Data type not allowed",                      /* 26 */
                          "Shift(s) too high",                          /* 27 */
                          "Wrong array type",                           /* 28 */
            "The number of elements of the output array is changed",    /* 29 */
                          "Wrong dimension",                            /* 30 */
                          "Image number out of range",                  /* 31 */
                       };
#else
   GLOBAL char *MATHIV_ERRS_error_message[];
#endif

#else

#define ERRSID_MATH_err_mem_alloc        2
#define ERRSID_MATH_one_point            2
#define ERRSID_MATH_num_err              2
#define ERRSID_MATH_insuff_num_of_data   2
#define ERRSID_MATH_null_modu            2
#define ERRSID_MATH_arr_uncomp           2
#define ERRSID_MATH_null_arr             2
#define ERRSID_MATH_no_suff_arr_elem     2
#define ERRSID_MATH_no_conv              2
#define ERRSID_MATH_no_complex           2
#define ERRSID_MATH_not_allowed_flg_val  2
#define ERRSID_MATH_FFT_few_elem         2
#define ERRSID_MATH_insuff_coeff         2
#define ERRSID_MATH_xy_num_diff          2
#define ERRSID_MATH_arr_undef            2
#define ERRSID_MATH_math_err             2
#define ERRSID_MATH_interp_not_allow     2
#define ERRSID_MATH_TEST_error           2
#define ERRSID_MATH_abscissa_out         2
#define ERRSID_MATH_negative_dimen       2
#define ERRSID_MATH_even_sinc_num        2
#define ERRSID_MATH_delta_out            2
#define ERRSID_MATH_table_not_allocated  2
#define ERRSID_MATH_null_dim             2
#define ERRSID_MATH_data_type_not_allow  2
#define ERRSID_MATH_shift_too_high       2
#define ERRSID_MATH_wrong_type           2
#define ERRSID_MATH_change_nelem         2
#define ERRSID_MATH_wrong_dim            2
#define ERRSID_MATH_imanum_out           2

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef MATH_GLBL
   GLOBAL char *MATHIV_ERRS_error_message[] = 
                        { "No error happens",                           /* 0 */
                          "Generic error happens",                      /* 1 */
                          "Mathematical library error happens"          /* 2 */
                       };
#else
   GLOBAL char *MATHIV_ERRS_error_message[];
#endif

#endif

#endif
