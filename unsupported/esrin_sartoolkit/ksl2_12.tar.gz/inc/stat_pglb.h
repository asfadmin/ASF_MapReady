/* ==========================================================================
   $MODULE_HEADER

      $NAME              STAT_PGLB

      $FUNCTION          STATISTIC TOOL global module.

      $ROUTINE           STATPP_KERN_Mean
		         STATPP_KERN_Sddv
			 STATPP_KERN_Cfvr
                         STATPP_KERN_Copy

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       29-JUL-97     AG       Initial Release
          SCR #4      26-NOV-97     AG       Added STATPD_sqrt_epsilon define
            N/A       23-MAR-97     AG       Add for Reqs B10/B18

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include GIOS_INTF_H
#include STAT_INTF_H


#ifdef  STAT_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STATPD_sqrt_epsilon

      $DESCRIPTION  Threshold for sqrt when computing sddv and cfvr

   $EH
   ========================================================================== */
#define STATPD_sqrt_epsilon ((double) 1.0e-6)

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STATPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum STATPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STATPC_

      $DESCRIPTION  The STATPC_

   $EH
   ========================================================================== */
/*   const STATPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STATPT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct STATPT_*_def { 

   typedef struct STATPT_*_def STATPT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STATPV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STATPP_KERN_Mean

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI

        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STAT_kernel_dim_high
		      ERRSID_STAT_bad_steps
		      ERRSID_STAT_bad_write_size
		      ERRSID_STAT_err_mem_alloc
		      ERRSID_STAT_data_type_not_allow

        $DESCRIPTION  This procedure convolves the constant kernel given in
		      input with the image block also given and writes the
		      output in the file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
					- Check if whole window is inside AOI
                                        - Sum the window element
                                        - Fill the output vector rescaling it
					  by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */
   extern void STATPP_KERN_Mean
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
			 /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STATPP_KERN_Sddv

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI

        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STAT_kernel_dim_high
		      ERRSID_STAT_bad_steps
		      ERRSID_STAT_bad_write_size
		      ERRSID_STAT_err_mem_alloc
		      ERRSID_STAT_data_type_not_allow

        $DESCRIPTION  This procedure convolves the constant kernel given in
		      input with the image block also given and writes the
		      output in the file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
					- Check if whole window is inside AOI
                                        - Sum the window element
					- Sum the square of the window element
                                        - Fill the output vector rescaling it
					  by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */
   extern void STATPP_KERN_Sddv
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
			 /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STATPP_KERN_Cfvr

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI


        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STAT_kernel_dim_high
		      ERRSID_STAT_bad_steps
		      ERRSID_STAT_bad_write_size
		      ERRSID_STAT_err_mem_alloc
		      ERRSID_STAT_data_type_not_allow

        $DESCRIPTION  This procedure convolves the constant kernel given in
		      input with the image block also given and writes the
		      output in the file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
					- Sum the square of the window element
                                        - Sum the 4th power of the window 
                                          element
                                        - Fill the output vector rescaling it
					  by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */
   extern void STATPP_KERN_Cfvr
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
			 /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STATPP_KERN_Copy

        $TYPE         PROCEDURE

        $INPUT        nrow_inp	    : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
		      RStartR	    : start row in the input image reference
				      system of the image block passed at the
				      current procedure
                      StepR	    : step size in the rows direction
                      StepC	    : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern	    : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr	    : rows' kernel size
                      Kc	    : columns' kernel size
                      InpIma	    : pointer to the pointer to the input image
                                      block
                      RStartW	    : start row to write the output image
                      RStopW   	    : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan	    : channel of the output TIFF image
                      out_img	    : image number of the output TIFF image
                      fill_val      : value for the image if the window is
                                      not in the AOI

        $MODIFIED     NONE

        $OUTPUT       The output file is written

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STAT_kernel_dim_high
		      ERRSID_STAT_bad_steps
		      ERRSID_STAT_bad_write_size
		      ERRSID_STAT_err_mem_alloc
		      ERRSID_STAT_data_type_not_allow

        $DESCRIPTION  This procedure convolves the constant kernel given in
		      input with the image block also given and writes the
		      output in the file passed by its channel and img parameter

        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.

        $PDL	      - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
					- Check if whole window is inside AOI
                                        - Sum the window element
                                        - Fill the output vector rescaling it
					  by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch

   $EH
   ========================================================================== */
   extern void STATPP_KERN_Copy
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
			 /*IN    */ UINTx4	         RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
			 /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STATPP_

      $DESCRIPTION  

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/*   extern void STATPP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STATPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 STATPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STATPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void STATPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) STATIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( STATPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STATIM_

      $DESCRIPTION  This procedure

                    STATIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define STATPM_
*/
