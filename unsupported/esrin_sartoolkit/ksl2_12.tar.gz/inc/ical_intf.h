/* ==========================================================================
   $MODULE_HEADER

      $NAME              ICAL_INTF

      $FUNCTION          interface module.

      $ROUTINE           ICALIP_

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       14-MAR-98     AG       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef ICAL
#define ICAL ICAL


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include GIOS_INTF_H
#include IANN_INTF_H

#ifdef ICAL_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ICALID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define ICALID_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ICALIE_lut_direct

      $DESCRIPTION  It enumerate the possible lut direction

   $EH
   ========================================================================== */
   enum ICALIE_lut_direct {
      ICALIE_lut_none,
      ICALIE_lut_apply,
      ICALIE_lut_remove
   };

/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ICALIC_

      $DESCRIPTION  The ICALIC_

   $EH
   ========================================================================== */
/*   const ICALIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ICALIT_lut_direct

      $DESCRIPTION  Type of ICALIE_lut_direct

   $EH
   ========================================================================== */
   typedef enum ICALIE_lut_direct ICALIT_lut_direct;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         ICALIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALIP_IMAG_backscattering

        $TYPE         PROCEDURE

        $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                      inp_ima_num
                                : number identifing the image inside the tool
                      TLRow     : the row image coordinate in the full
                                  reference frame of the image
                      TLCol     : the column image coordinate in the full
                                  reference frame of the image
                      nrow_inp  : number of rows of the image
                      ncol_inp  : number of columns of the images
                      ant_patt_lut_direct
                                : LUT direction of antenna pattern
                      antenna_pattern_file
                                : antenna pattern file name
                      use_antenna_patt_file
                               : TRUE if antenna_pattern_file has to be used
                      ran_spre_loss_lut_direct
                                : LUT direction of range spreading loss
                      calib_const_lut_direct
                                : LUT direction of calibration constant
                      in_calib_const
                                : user defined calibration constant
                      use_calib_const
                                : TRUE if this value override the annotation
                      replica_power_lut_direct
                                : LUT direction of replica power
                      ref_replica_power
                                : reference replica power
                      ref_chirp_average
                                : reference chirp average
                      adc_lut_direction
                                : LUT direction of ADC
                      adc_io    : structure with the IO basic parameters of the
                                  LUT file
                      adc_ima_num
                                : number identifing the ADC image inside the tool
                      out_io    : structure with the IO basic parameters of the
                                  output image
                      out_ima_scale
                                : scale type of output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine drives the creation of the BACKSCATTERING
                      calibrated image

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void ICALIP_IMAG_backscattering
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ ICALIT_lut_direct    ant_patt_lut_direct,
                         /*IN    */ char                *antenna_pattern_file,
                         /*IN    */ LDEFIT_boolean       use_antenna_patt_file,
                         /*IN    */ ICALIT_lut_direct    ran_spre_loss_lut_direct,
                         /*IN    */ ICALIT_lut_direct    calib_const_lut_direct,
                         /*IN    */ float                in_calib_const,
                         /*IN    */ LDEFIT_boolean       use_calib_const,
                         /*IN    */ ICALIT_lut_direct    replica_power_lut_direct,
                         /*IN    */ float               *ref_replica_power,
                         /*IN    */ float               *ref_chirp_average,
                         /*IN    */ ICALIT_lut_direct    adc_lut_direction,
                         /*IN    */ GIOSIT_io           *adc_io,
                         /*IN    */ UINTx1               adc_ima_num,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ IANNIT_ImageScale    out_ima_scale,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALIP_IMAG_gamma

        $TYPE         PROCEDURE

        $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                      inp_ima_num
                                : number identifing the image inside the tool
                      TLRow     : the row image coordinate in the full
                                  reference frame of the image
                      TLCol     : the column image coordinate in the full
                                  reference frame of the image
                      nrow_inp  : number of rows of the image
                      ncol_inp  : number of columns of the images
                      out_io    : structure with the IO basic parameters of the
                                  output image
                      out_ima_scale
                                : scale type of output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine drives the creation of the GAMMA IMAGE
                      calibrated image

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void ICALIP_IMAG_gamma
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ IANNIT_ImageScale    out_ima_scale,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         ICALIP_IMAG_adc_saturation

        $TYPE         PROCEDURE

        $INPUT        inp_io    : structure with the IO basic parameters of the
                                input image
                      inp_ima_num
                                : number identifing the image inside the tool
                      TLRow     : the row image coordinate in the full
                                  reference frame of the image
                      TLCol     : the column image coordinate in the full
                                  reference frame of the image
                      nrow_inp  : number of rows of the image
                      ncol_inp  : number of columns of the images
                      in_calib_const
                                : user defined calibration constant
                      use_calib_const
                                : TRUE if this value override the annotation
                      out_io    : structure with the IO basic parameters of the
                                  output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This routine drives the creation of the ADC SATURATION
                      CORRECTION image

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void ICALIP_IMAG_adc_saturation
                        (/*IN    */ GIOSIT_io           *inp_io,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx4               TLRow,
                         /*IN    */ UINTx4               TLCol,
                         /*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ float                in_calib_const,
                         /*IN    */ LDEFIT_boolean       use_calib_const,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ICALIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/*   extern void ICALIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ICALIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void ICALIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) ICALIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         ICALIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    ICALIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define ICALIM_
*/



/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_ICAL_err_mem_alloc        2
#define ERRSID_ICAL_imanum_not_allow     3
#define ERRSID_ICAL_inv_data_type        4
#define ERRSID_ICAL_start_stop_col_err   5
#define ERRSID_ICAL_no_lut               6
#define ERRSID_ICAL_inv_annot            7
#define ERRSID_ICAL_inv_adc_lut          8

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef ICAL_GLBL
   GLOBAL char *ICALIV_ERRS_error_message[] = { 
      "No error happens",
      "Generic error happens",
      "SYSTEM ERROR: memory allocation error",
      "Image number for annotation not allowed",
      "Invalid data type",
      "Row-column error",
      "Lut not computed",
      "Invalid Annotation",
      "ADC Compensation is not applicable to the input image"
   };
#else
   GLOBAL char *ICALIV_ERRS_error_message[];
#endif


#endif
