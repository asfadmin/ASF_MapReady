/* ==========================================================================
   $MODULE_HEADER

      $NAME              PMDS_PGLB

      $FUNCTION          Product Media Deformatter Service global module.

      $ROUTINE           PMDSPP_StoreVar
                         PMDSPP_StoreVarAndValue
                         PMDSPP_GetVar
                         PMDSPP_InitPMDSLibrary
                         PMDSPP_DefRecField
                         PMDSPP_ReadCurrRec
                         PMDSPF_IsComment
                         PMDSPP_GetCfgLine
                         PMDSPP_ReadGlobalVar
                         PMDSPF_ReadLogVolStru
                         PMDSPF_VolumeType
                         PMDSPP_DefLogVolField
                         PMDSPP_SeekCfgFile
                         PMDSPP_SeekNextMarker
                         PMDSPF_GetCurrRecordSize
                         PMDSPP_ReadCurrRepeat
                         PMDSPP_FreeRec
                         PMDSPP_FreeGrpRec
                         PMDSPF_ReadProdRec
                         PMDSPF_GetCurrFileSize
                         PMDSPP_DeformatProdRecord
                         PMDSPP_GenerateTifImage
                         PMDSPP_DeformatGrpProdRecord
                         PMDSPP_DeformatFile
                         PMDSIP_TFDM_AddTiffField
                         PMDSIP_TFDM_FreeTiffField
                         PMDSIP_TFDM_GetTagFromDescr
                         PMDSIP_TFDM_GetTagsFromFile
                         PMDSIP_ANNF_FormatFieldData
                         PMDSIP_ANNF_SetAnnFile
                         PMDSIP_ANNF_WriteAnnFile
                         PMDSIP_RETR_CheckBuffer
                         PMDSIP_GRID_DrawCoord
                         PMDSIP_GRID_DrawPoint
                         PMDSIP_MDAN_AddRecord
                         PMDSIP_MDAN_AddFile
                         PMDSIP_MDAN_AddVolume
                         PMDSIP_MDAN_ReadProductRecord
                         PMDSIP_MDAN_CompareProduct
                         PMDSIP_MDAN_ReadTape
                         PMDSIP_MDAN_CreateMCR
                         PMDSPP_UNDR_ConvCoreConstKern

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       07-FEB-97     AG       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include <stdio.h>
#include <ctype.h>

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include MATH_INTF_H
#include DEVS_INTF_H
#include PMDS_INTF_H


#ifdef  PMDS_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_number_of_new_par

      $DESCRIPTION  Number of parameter(s) to be added to the output tiff file

   $EH
   ========================================================================== */
#define PMDSPD_number_of_new_par 18

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_max_global_vars

      $DESCRIPTION  Maximum number of global variable

   $EH
   ========================================================================== */
#define PMDSPD_max_global_vars 100

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_version

      $DESCRIPTION  PMDS VERSION

   $EH
   ========================================================================== */
#define PMDSPD_version "CEOS-02"

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_date_last_release_qc_sw

      $DESCRIPTION  Maximum number of global variable

   $EH
   ========================================================================== */
#define PMDSPD_date_last_release_qc_sw "940525"

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_max_log_vol_item

      $DESCRIPTION  Maximum number of product logical volume

   $EH
   ========================================================================== */
#define PMDSPD_max_log_vol_item 10

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_max_number_cfg_field

      $DESCRIPTION  Maximum number of configuration field

   $EH
   ========================================================================== */
#define PMDSPD_max_number_cfg_field 10

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_max_image

      $DESCRIPTION  Maximum number of product image

   $EH
   ========================================================================== */
#define PMDSPD_max_image 5

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_single_vol

      $DESCRIPTION  single volume (tape) id

   $EH
   ========================================================================== */
#define PMDSPD_single_vol 0

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_first_vol

      $DESCRIPTION  first volume (tape) id

   $EH
   ========================================================================== */
#define PMDSPD_first_vol 1

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_center_vol

      $DESCRIPTION  center volume (tape) id

   $EH
   ========================================================================== */
#define PMDSPD_center_vol 2

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_last_vol

      $DESCRIPTION  last volume (tape) id

   $EH
   ========================================================================== */
#define PMDSPD_last_vol 3

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_max_tags_num

      $DESCRIPTION  maximum number fo tags allowed

   $EH
   ========================================================================== */
#define PMDSPD_max_tags_num 2000

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_max_rec_num

      $DESCRIPTION  Maximum number of records into the tape

   $EH
   ========================================================================== */
#define PMDSPD_max_rec_num 20

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_max_file_num

      $DESCRIPTION  Maximum number of files into the tape

   $EH
   ========================================================================== */
#define PMDSPD_max_file_num 10

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_max_vol_num

      $DESCRIPTION  Maximum number of volumes (tapes)

   $EH
   ========================================================================== */
#define PMDSPD_max_vol_num 10

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPD_cfg_name_len

      $DESCRIPTION  Maximum length of the CFG file name

   $EH
   ========================================================================== */
#define PMDSPD_cfg_name_len 256


/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum PMDSPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPC_

      $DESCRIPTION  The PMDSPC_

   $EH
   ========================================================================== */
/*   const PMDSPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_tmp_buf

      $DESCRIPTION  Temporary buffer type definition

   $EH
   ========================================================================== */
   typedef char PMDSPT_tmp_buf[ 1024 ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_parm_name

      $DESCRIPTION  Parameter name type definition

   $EH
   ========================================================================== */
   typedef char PMDSPT_parm_name[ 40 ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_parm_value

      $DESCRIPTION  Parameter value type definition

   $EH
   ========================================================================== */
   typedef char PMDSPT_parm_value[ 1000 ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_file_code

      $DESCRIPTION  File code type definition

   $EH
   ========================================================================== */
   typedef char PMDSPT_file_code[ 10 ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_parm_type

      $DESCRIPTION  Enumerated for different parameter types

   $EH
   ========================================================================== */
   enum PMDSPE_parm_type {
      PMDSPE_int_parm,
      PMDSPE_real_parm,
      PMDSPE_string_parm,
      PMDSPE_date_parm
   };
   typedef enum PMDSPE_parm_type PMDSPT_parm_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_volume_type

      $DESCRIPTION  Enumerated for different volume types

   $EH
   ========================================================================== */
   enum PMDSPE_volume_type {
      PMDSPE_vdf_volume,
      PMDSPE_ldr_volume,
      PMDSPE_img_volume,
      PMDSPE_nul_volume
   };
   typedef enum PMDSPE_volume_type PMDSPT_volume_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_global_vars

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct PMDSPT_global_vars_def { 
            PMDSPT_parm_name               name;
            PMDSPT_parm_type               type;
            union
            {
               PMDSPT_parm_value           string;
               INTx8                       date_seconds;
               double                      number;

            } val;
   };

   typedef struct PMDSPT_global_vars_def PMDSPT_global_vars;


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_TagData

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct PMDSPT_TagData_def { 
            PMDSPT_parm_name           name;
            UINTx2                     tag;
   };

   typedef struct PMDSPT_TagData_def PMDSPT_TagData;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_TagList

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct PMDSPT_TagList_def { 
            INTx4                      num;
            PMDSPT_TagData             list[PMDSPD_max_tags_num];
   };

   typedef struct PMDSPT_TagList_def PMDSPT_TagList;


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_TiffField

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct PMDSPT_TiffField_def { 
            UINTx2                     tag;
            PMDSPT_parm_name           name;
            PMDSPT_parm_type           type;
            PMDSPT_parm_value          value;
   };

   typedef struct PMDSPT_TiffField_def PMDSPT_TiffField;


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_TiffList

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct PMDSPT_TiffList_def { 
            INTx4                      num;
            PMDSPT_TiffField           *list;
   };

   typedef struct PMDSPT_TiffList_def PMDSPT_TiffList;


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_presence_type

      $DESCRIPTION  Enumerated for different presence types

   $EH
   ========================================================================== */
   enum PMDSPE_presence_type {
      PMDSPE_all_pres,
      PMDSPE_first_pres,
      PMDSPE_last_pres,
      PMDSPE_none_pres
   };
   typedef enum PMDSPE_presence_type PMDSPT_presence_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_record_format

      $DESCRIPTION  Enumerated for different record formats

   $EH
   ========================================================================== */
   enum PMDSPE_record_format {
      PMDSPE_rfm_fixed_size = 0,
      PMDSPE_rfm_variable_size,
      PMDSPE_rfm_stream_lf,
      PMDSPE_rfm_stream_cr
   };
   typedef enum PMDSPE_record_format PMDSPT_record_format;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_prod_images

      $DESCRIPTION  Product image structure

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
   $EH
   ========================================================================== */
   struct PMDSPT_prod_images_def { 
        INTx4                       bytes_skip;
        INTx4                       bytes_keep;
        INTx4                       sample_per_pix;
        INTx4                       bits_per_sample;
        INTx4                       image_width;          /* In pixels */
        INTx4                       image_height;         /* Lines */
   };

   typedef struct PMDSPT_prod_images_def PMDSPT_prod_images;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_prod_data_type

      $DESCRIPTION  Enumerated for product image data type

   $EH
   ========================================================================== */
   enum PMDSPE_prod_data_type {
      PMDSPE_data_none= 0,

      PMDSPE_data_1_unsigned16,
      PMDSPE_data_1_unsigned16_nodec,

      PMDSPE_data_1_signed8

   };
   typedef enum PMDSPE_prod_data_type PMDSPT_prod_data_type;


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_log_vol

      $DESCRIPTION  PMDS logical volume structure

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          num                                   file ordinal number
          file                             file name
          file_code                        file code
          presence_type                    presence of file on volume
          is_interruptable                 can be interrupt on several volumes
          rec_format                       record format
   $EH
   ========================================================================== */
   struct PMDSPT_log_vol_def { 
        INTx4                            num;
        char                            file[ 256 ];
        PMDSPT_file_code            file_code;
        PMDSPT_presence_type            presence_type;
        LDEFIT_boolean                    is_interruptable;
        PMDSPT_record_format            rec_format;
   };

   typedef struct PMDSPT_log_vol_def PMDSPT_log_vol;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_align_type

      $DESCRIPTION  Enumerated for different alignment types

   $EH
   ========================================================================== */
   enum PMDSPE_align_type {
      PMDSPE_align_left,
      PMDSPE_align_centered,
      PMDSPE_align_right
   };
   typedef enum PMDSPE_align_type PMDSPT_align_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_field_format

      $DESCRIPTION  Field format type definition

   $EH
   ========================================================================== */
   typedef char PMDSPT_field_format;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_field_name

      $DESCRIPTION  Field name type definition

   $EH
   ========================================================================== */
   typedef char PMDSPT_field_name[ 31 ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_var_name

      $DESCRIPTION  Var name type definition

   $EH
   ========================================================================== */
   typedef char PMDSPT_var_name[ 31 ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_def_value

      $DESCRIPTION  Default value type definition

   $EH
   ========================================================================== */
   typedef char PMDSPT_def_value[ 132 ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_esa_name

      $DESCRIPTION  Esa equivalent name

   $EH
   ========================================================================== */
   typedef char PMDSPT_esa_name[ 82 ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_units

      $DESCRIPTION  Measure units

   $EH
   ========================================================================== */
   typedef char PMDSPT_units[ 22 ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_remark

      $DESCRIPTION  Comment inserted by the user

   $EH
   ========================================================================== */
   typedef char PMDSPT_remark[ 102 ];

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_fill_type

      $DESCRIPTION  Enumerated for different filling 

   $EH
   ========================================================================== */
   enum PMDSPE_fill_type {
      PMDSPE_fill_default,
      PMDSPE_fill_blank,
      PMDSPE_fill_computable,
      PMDSPE_fill_geo,
      PMDSPE_fill_null,
      PMDSPE_fill_sar
   };
   typedef enum PMDSPE_fill_type PMDSPT_fill_type;


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_cfg_field

      $DESCRIPTION  cfg field structure

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
   $EH
   ========================================================================== */
   struct PMDSPT_cfg_field_def {
        INTx4                            num;          /* Field number           */
        INTx4                            byte_start;   /* Byte of start          */
        LDEFIT_boolean              write_tif;    /* Write to tif           */
        PMDSPT_align_type           align;        /* Alignment code         */
        PMDSPT_field_format         format;       /* Format type            */
        INTx4                       format_size;
        INTx4                       after_comma_size;
        PMDSPT_field_name           name;
        PMDSPT_fill_type            fill_type;
        PMDSPT_var_name             in_var;       /* Input variable         */
        char                        check_field[31]; 
                                                  /* field used for valid   */
        PMDSPT_def_value            default_value;
        PMDSPT_esa_name             esa_name;
        PMDSPT_units                units;
        PMDSPT_remark               remark;
        LDEFIT_boolean              begin_repeat;
        LDEFIT_boolean              end_repeat;
        PMDSPT_parm_name            max_rep_str;
   };
   typedef struct PMDSPT_cfg_field_def PMDSPT_cfg_field;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_cfg_rec

      $DESCRIPTION  cfg record structure

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
   $EH
   ========================================================================== */
   struct PMDSPT_cfg_rec_def {
        INTx4                             max_repeat;
        INTx4                             max_field;
        PMDSPT_cfg_field           **cfg_field;
   };
   typedef struct PMDSPT_cfg_rec_def PMDSPT_cfg_rec;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_cfg_grp_rec

      $DESCRIPTION  cfg GRP record structure

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          max_repeat                       number of times of REPEAT
          max_rec                          number of records
          cfg_rec                           pointer to cfg_rec
   $EH
   ========================================================================== */
   struct PMDSPT_cfg_grp_rec_def {
        INTx4                             max_repeat;
        INTx4                             max_rec;
        PMDSPT_cfg_rec             **cfg_rec;
   };
   typedef struct PMDSPT_cfg_grp_rec_def PMDSPT_cfg_grp_rec;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_input

      $DESCRIPTION  Global variable for input

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          media_type                       type of the media of product file
          media_pointer                    pointer to the media
   $EH
   ========================================================================== */
   struct PMDSPT_input_def {
         DEVSIT_media_type       media_type;
         char                    name[ 132 ];
         union desc {
            FILE                *fp;
            INTx4                exa;
            INTx4                cdrom;
         } media_pointer;
   };
   typedef struct PMDSPT_input_def PMDSPT_input;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_gm

      $DESCRIPTION  PMDS global variable type

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          cfg_pos                           position in cfg file
          cur_file_num                     current file number
          cur_mvol_rec_num                 current mvol number
          cur_rec_num                      current record number
          cur_vol_num                      current volume number
          phsy_vol_num                     current phsycal volume number
          global_vars_stored               total global variable
          global_vars                      global variables
   $EH
   ========================================================================== */
   struct PMDSPT_gm_def {
         INTx4                         cfg_pos;
         INTx4                         cur_file_num;
         INTx4                         cur_mvol_rec_num;
         INTx4                         cur_rec_num;
         INTx4                         cur_vol_num;
         INTx4                         phsy_vol_num;
         INTx4                         global_vars_stored;
         PMDSPT_global_vars            global_vars[ PMDSPD_max_global_vars ]; 
   };
   typedef struct PMDSPT_gm_def PMDSPT_gm;


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_marker_type

      $DESCRIPTION  Enumerated for different marker

   $EH
   ========================================================================== */
   enum PMDSPE_marker_type {
      PMDSPE_mrk_var_begin = 0,
      PMDSPE_mrk_var_end,
      PMDSPE_mrk_log_vol_begin,
      PMDSPE_mrk_log_vol_end,
      PMDSPE_mrk_record_begin,
      PMDSPE_mrk_record_end,
      PMDSPE_mrk_file_begin,
      PMDSPE_mrk_file_end,
      PMDSPE_mrk_field_begin,
      PMDSPE_mrk_field_end,
      PMDSPE_mrk_repeat_begin,
      PMDSPE_mrk_repeat_end,
      PMDSPE_mrk_img_begin,
      PMDSPE_mrk_img_end,
      PMDSPE_mrk_skip_next_block_if_more_vol,
      PMDSPE_mrk_assign
   };
   typedef enum PMDSPE_marker_type PMDSPT_marker_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_mode_type

      $DESCRIPTION  Enumerated for different file access type

   $EH
   ========================================================================== */
   enum PMDSPE_mode_type {
      PMDSPE_ANNF_FileNameOpen = 0,
      PMDSPE_ANNF_FileNameWrite,
      PMDSPE_ANNF_FileNameClose
   };
   typedef enum PMDSPE_mode_type PMDSPT_mode_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_data_type

      $DESCRIPTION  Enumerated for different data to be written into
                    annotation file

   $EH
   ========================================================================== */
   enum PMDSPE_data_type {
      PMDSPE_ANNF_FileNameType = 0,
      PMDSPE_ANNF_DataType,
      PMDSPE_ANNF_HeaderType,
      PMDSPE_ANNF_FieldType
   };
   typedef enum PMDSPE_data_type PMDSPT_data_type;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_marker

      $DESCRIPTION  Marker variable type

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          type                             type of marker
          code                             code of marker
          nb_iterations                    number of repetition allowed
   $EH
   ========================================================================== */
   struct PMDSPT_marker_def {
         PMDSPT_marker_type         type;
         INTx4                   code;
         INTx4                   nb_iterations;
   };
   typedef struct PMDSPT_marker_def PMDSPT_marker;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPV_prod_image

      $DESCRIPTION  Global variables for the image extracted

   $EH
   ========================================================================== */
   GLOBAL PMDSPT_prod_images PMDSPV_prod_image;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPV_product_type

      $DESCRIPTION  Global variables for the PMDS product type

   $EH
   ========================================================================== */
#ifdef PMDS_GLBL
   GLOBAL PMDSIT_product_type PMDSPV_product_type = PMDSIE_unk_prod;
#else
   GLOBAL PMDSIT_product_type PMDSPV_product_type;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPV_input

      $DESCRIPTION  Global variables for PMDS package

   $EH
   ========================================================================== */
#ifdef PMDS_GLBL
   GLOBAL PMDSPT_input PMDSPV_input = { DEVSIE_mt_none };
#else
   GLOBAL PMDSPT_input PMDSPV_input;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPV_gm

      $DESCRIPTION  Global variables for PMDS package

   $EH
   ========================================================================== */
   GLOBAL PMDSPT_gm PMDSPV_gm;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPV_prod_data_type

      $DESCRIPTION  Global variables for PMDS data type

   $EH
   ========================================================================== */
#ifdef PMDS_GLBL
   GLOBAL PMDSPT_prod_data_type PMDSPV_prod_data_type = PMDSPE_data_none;
#else
   GLOBAL PMDSPT_prod_data_type PMDSPV_prod_data_type;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPV_TiffList

      $DESCRIPTION  Global variables for the PMDS product type

   $EH
   ========================================================================== */
#ifdef PMDS_GLBL
   GLOBAL PMDSPT_TiffList PMDSPV_TiffList;
#else
   GLOBAL PMDSPT_TiffList PMDSPV_TiffList;
#endif



/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPV_volume_name

      $DESCRIPTION  volume name string

   $EH
   ========================================================================== */
#ifdef PMDS_GLBL
   GLOBAL char *PMDSPV_volume_name[] =
{
    "VDF",
    "LDR",
    "IMG",
    "NUL"
};
#else
   GLOBAL char *PMDSPV_volume_name[];
#endif


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPV_marker_name

      $DESCRIPTION  marker names for CFG file

   $EH
   ========================================================================== */
#ifdef PMDS_GLBL
   GLOBAL char *PMDSPV_marker_name[] =
{
   ".VAR_BEGIN",
   ".VAR_END",
   ".LOG_VOL_BEGIN",
   ".LOG_VOL_END",
   ".RECORD_BEGIN",
   ".RECORD_END",
   ".FILE_BEGIN",
   ".FILE_END",
   ".FIELD_BEGIN",
   ".FIELD_END",
   ".REPEAT_BEGIN",
   ".REPEAT_END",
   ".IMG_BEGIN",
   ".IMG_END",
   ".SKIP_NEXT_BLOCK_IF_MORE_VOL"
};
#else
   GLOBAL char *PMDSPV_marker_name[];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPV_max_marker

      $DESCRIPTION  Number of markers

   $EH
   ========================================================================== */
#ifdef PMDS_GLBL
   GLOBAL INTx4          PMDSPV_max_marker = 
                    (sizeof(PMDSPV_marker_name)/sizeof(char *));
#else
   GLOBAL INTx4          PMDSPV_max_marker;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPV_max_volume

      $DESCRIPTION  Number of volume type

   $EH
   ========================================================================== */
#ifdef PMDS_GLBL
   GLOBAL INTx4          PMDSPV_max_volume = 
                    (sizeof(PMDSPV_volume_name)/sizeof(char *));
#else
   GLOBAL INTx4          PMDSPV_max_volume;
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_RecordData

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct PMDSPT_RecordData_def { 
            INTx4                      recNum;
            INTx4                      size;
            char                       necessary[16];
   };

   typedef struct PMDSPT_RecordData_def PMDSPT_RecordData;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_RecordDataList

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct PMDSPT_RecordDataList_def { 
            INTx4                      num;
            PMDSPT_RecordData          list[PMDSPD_max_rec_num];
   };

   typedef struct PMDSPT_RecordDataList_def PMDSPT_RecordDataList;


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_FileData

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct PMDSPT_FileData_def {
            INTx4                      fileNum;
            INTx4                      size;
            char                       necessary[16];
            PMDSPT_RecordDataList      rec;
   };

   typedef struct PMDSPT_FileData_def PMDSPT_FileData;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_FileDataList

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct PMDSPT_FileDataList_def {
            INTx4                      num;
            PMDSPT_FileData            list[PMDSPD_max_file_num];
   };

   typedef struct PMDSPT_FileDataList_def PMDSPT_FileDataList;


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_VolData

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct PMDSPT_VolData_def { 
            INTx4                      volNum;
            char                       cfgName[PMDSPD_cfg_name_len];
            PMDSPT_FileDataList        file;
   };

   typedef struct PMDSPT_VolData_def PMDSPT_VolData;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         PMDSPT_VolDataList

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
   struct PMDSPT_VolDataList_def {
            char                       product[256];
            char                       sensor[256];
            char                       format[256];
            char                       source[256];
            INTx4                      num;
            PMDSPT_VolData             list[PMDSPD_max_vol_num];
            double                     score;
   };

   typedef struct PMDSPT_VolDataList_def PMDSPT_VolDataList;


/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_AdjustImageLine

        $TYPE              PROCEDURE

        $INPUT        var           : string containing the variable assignment
                      type       : variable type

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Assign variable

        $WARNING      NONE

   $EH
   ========================================================================== */
extern void PMDSPP_AdjustImageLine
   (
   void                   *val_ptr,
   INTx4                   max_bytes,    /* image width in byte */
   PMDSPT_prod_data_type   prod_data_type
   );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_StoreVar

        $TYPE              PROCEDURE

        $INPUT        var           : string containing the variable assignment
                      type       : variable type

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Assign variable

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_StoreVar
                          (/*IN    */ char                *var,
                           /*IN    */ PMDSPT_parm_type     type,
                           /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_StoreVarAndValue

        $TYPE              PROCEDURE

        $INPUT        var           : string containing the variable
                      value      : string containing the value
                      type       : variable type

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Assign variable

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_StoreVarAndValue
                            (/*IN    */ char                *var,
                             /*IN    */ char                *value,
                             /*IN    */ PMDSPT_parm_type     type,
                             /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_GetVar

        $TYPE              PROCEDURE

        $INPUT        var           : variable name

        $MODIFIED     NONE

        $OUTPUT       out_value  : value variable

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Find variable value

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_GetVar      
                        (/*IN    */ PMDSPT_parm_name     var,
                         /*   OUT*/ char                *out_value,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_GetType

        $TYPE              PROCEDURE

        $INPUT        var           : variable name

        $MODIFIED     NONE

        $OUTPUT       out_type      : variable type

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Find variable value

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_GetType     
                        (/*IN    */ PMDSPT_parm_name     var,
                         /*   OUT*/ PMDSPT_parm_type    *out_type,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_EvalAssign

        $TYPE              PROCEDURE

        $INPUT        expr          : variable name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Execute simple assignment 
                      @VAR = [@VAR|CONST] +/- [@VAR|CONST] +/- ...

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_EvalAssign  
                        (/*IN    */ char                *expr,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_InitLibrary

        $TYPE              PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       PMDSPV_gm

        $RET_STATUS   NONE

        $DESCRIPTION  Init PMDS library

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_InitLibrary
                          (/*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_DefRecField

        $TYPE         PROCEDURE

        $INPUT        buffer         : buffer line

        $MODIFIED     NONE

        $OUTPUT       field_ptr  : cfg field pointer

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This service fill the 'field_ptr' structure which the 
                      values contained into 'buffer' vector.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_DefRecField 
                        (/*IN    */ char                 *buffer,
                         /*   OUT*/ PMDSPT_cfg_field     *field_ptr,
                         /*   OUT*/ INTx4                *nb_rec_field,
                         /*   OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_ReadCurrRec

        $TYPE         PROCEDURE

        $INPUT        cfg_fp   : pointer to cfg file

        $MODIFIED     NONE

        $OUTPUT       rec_ptr : pointer to cfg record

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read the next record contained into cfg file and load all
                      into memory.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_ReadCurrRec 
                        (/*IN    */ FILE                 *cfg_fp,
                         /*   OUT*/ PMDSPT_cfg_rec       *rec_ptr,
                         /*   OUT*/ INTx4                *nb_rec_field,
                         /*   OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_IsComment

        $TYPE              FUNCTION

        $INPUT        buffer         : CFG file line

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   TRUE if the line is a comment one

        $DESCRIPTION  check if a CFG file line is a comment

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern LDEFIT_boolean PMDSPF_IsComment
                          (/*IN    */ char                *buffer );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_GetCfgLine

        $TYPE              PROCEDURE

        $INPUT        fpCfg         : pointer to CFG file
                      max        : max character for the line

        $MODIFIED     NONE

        $OUTPUT       str        : CFG line

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read a line from CFG file

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_GetCfgLine
                          (/*IN    */ FILE                *fpCfg,
                           /*IN    */ INTx4                max,
                           /*IN    */ char                *str,
                           /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_ReadGlobalVar

        $TYPE              PROCEDURE

        $INPUT        fpCfg         : pointer to CFG file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       ?

        $RET_STATUS   NONE

        $DESCRIPTION  Read the global var section from the CFG file

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_ReadGlobalVar 
                          (/*IN    */ FILE                *fpCfg,
                           /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_ReadLogVolStru

        $TYPE              FUNCTION

        $INPUT        fpCfg         : pointer to CFG file

        $MODIFIED     NONE

        $OUTPUT       prodLogVol : logical volume structure data

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read the log vol section from the CFG file

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 PMDSPF_ReadLogVolStru
                          (/*IN    */ FILE                *fpCfg,
                           /*   OUT*/ PMDSPT_log_vol      *prodLogVol,
                           /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_VolumeType

        $TYPE              FUNCTION

        $INPUT        file_code        :   file code 

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Return the volume type on the file_code

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern PMDSPT_volume_type PMDSPF_VolumeType  
                        (/*IN    */ PMDSPT_file_code     file_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_DefLogVolField

        $TYPE              PROCEDURE

        $INPUT        buffer            : CFG file line

        $MODIFIED     NONE

        $OUTPUT       prodLogVol  : Product logical volume structure

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Define the prodLogVol for the given line

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_DefLogVolField
                          (/*IN    */ char                *buffer,
                           /*   OUT*/ PMDSPT_log_vol      *prodLogVol,
                           /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_SeekCfgFile

        $TYPE              PROCEDURE

        $INPUT        fpCfg         : pointer to CFG file
                      file_code  : code file where to position

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Position in the CFG file at file_code

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_SeekCfgFile
                          (/*IN    */ FILE                *fpCfg,
                           /*IN    */ PMDSPT_file_code     file_code,
                           /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_SeekNextMarker

        $TYPE              PROCEDURE

        $INPUT        fpCfg         : pointer to CFG file

        $MODIFIED     NONE

        $OUTPUT       marker     : found marker
                      marker_value_str
                                 : found marker string

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Position in the CFG file at next file marker

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_SeekNextMarker
                          (/*IN    */ FILE                *fpCfg,
                           /*   OUT*/ PMDSPT_marker       *marker,
                           /*   OUT*/ char                *marker_value_str,
                           /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_GetCurrRecordSize

        $TYPE              FUNCTION

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read the record size of the current record from
                      F_R(f,r) variable

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 PMDSPF_GetCurrRecordSize
                          (/*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_ReadCurrRepeat

        $TYPE         PROCEDURE

        $INPUT        fCfg        : pointer to CFG file

        $MODIFIED     NONE

        $OUTPUT       grp_rec_ptr : pointer to record

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read the next record contained into CFG file and load all
                      into memory.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_ReadCurrRepeat 
                           (/*IN    */ FILE                 *fpCfg,
                            /*IN    */ PMDSIT_deformat_mode  mode,
                            /*   OUT*/ PMDSPT_cfg_grp_rec   *grp_rec_ptr,
                            /*   OUT*/ INTx4                *nb_rec_field,
                            /*   OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_FreeRec

        $TYPE         PROCEDURE

        $INPUT        rec_ptr  : pointer to record

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This service free all memory allocated by
                      'PMDSPP_ReadCurrRec' function for store all fields 
                      of the CFG record.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_FreeRec
                        (/*IN    */ PMDSPT_cfg_rec       *rec_ptr,
                         /*   OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_FreeGrpRec

        $TYPE         PROCEDURE

        $INPUT        grp_rec_ptr  : pointer to record

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This service free all memory allocated by
                      'PMDSPP_ReadCurrRepeat' function for store all fields 
                      of the CFG record.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_FreeGrpRec  
                        (/*IN    */ PMDSPT_cfg_grp_rec   *grp_rec_ptr,
                         /*   OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_ReadProdRec

        $TYPE         FUNCTION

        $INPUT        record_data_size   : byte to read

        $MODIFIED     NONE

        $OUTPUT       prod_ptr    : pointer to product data

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read product record data

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 PMDSPF_ReadProdRec
                           ( /*IN    */ INTx4                record_data_size,
                             /*   OUT*/ void                *prod_ptr,
                             /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPF_GetCurrFileSize

        $TYPE              FUNCTION

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Read the variable MAX_F_SZ and return the value

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 PMDSPF_GetCurrFileSize
                        (/*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_DeformatProdRecord

        $TYPE              PROCEDURE

        $INPUT        data_size   : record data size
                      mode        : deformatting mode
                      cfg_rec     : pointer to CFG record
                      annotate    : TRUE if the value has to be written to
                                    annotation listing

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_DeformatProdRecord
                       ( /*IN    */ INTx4                data_size,
                         /*IN    */ PMDSIT_deformat_mode mode,
                         /*IN    */ PMDSPT_cfg_rec      *cfg_rec,
                         /*IN    */ LDEFIT_boolean       annotate,
                         /*IN    */ INTx4                nb_rec_field,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_GenerateTifImage

        $TYPE         PROCEDURE

        $INPUT        record_data_size  : size of product image data
                      mode              : deformatting mode
                      record_num        : number of image records
                      record_skipped    : record to be skipped
                      record_kept       : record to be kept
                      width_skipped     : width to be skipped
                      width_kept        : width to be kept
                      ql_width          : width of the output quick look
                      ql_height         : height of the output quick look
                      win_width         : width of the window to be used
                      win_height        : height of the window to be used
                      vol_id            : current volume (tape) id
                      tif_ann_file      : tif annotation file name
                      out_img_name      : output tiff image name

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This service call the various image generation.

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_GenerateTifImage
                        (/*IN    */ INTx4                record_data_size,
                         /*IN    */ PMDSIT_deformat_mode mode,
                         /*IN    */ INTx4                record_num,
                         /*IN    */ INTx4                record_skipped,
                         /*IN    */ INTx4                record_kept,
                         /*IN    */ INTx4                width_skipped,
                         /*IN    */ INTx4                width_kept,
                         /*IN    */ INTx4                ql_width,
                         /*IN    */ INTx4                ql_height,
                         /*IN    */ UINTx4               win_width,
                         /*IN    */ UINTx4               win_height,
                         /*IN    */ INTx4                vol_id,
                         /*IN    */ char                *tif_ann_file,
                         /*IN    */ char                *out_img_name,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx1               out_ima_num,
                         /*   OUT*/ LDEFIT_boolean      *image_completed,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_DeformatGrpProdRecord

        $TYPE         PROCEDURE

        $INPUT        curr_rec_size   : record size
                      grp_rec_repeat  : group of record
                      mode            : deformatting mode
                      vol_id          : current volume (tape) id
                      start_row       : starting row
                      start_col       : starting column
                      end_row         : end row
                      end_col         : end column
                      ql_width        : width of the output quick look
                      ql_height       : height of the output quick look
                      win_width       : width of the window to be used
                      win_height      : height of the window to be used
                      tif_ann_file    : tif annotation file name
                      tif_output_file : output tiff file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Deformat a group of product record

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_DeformatGrpProdRecord
                        (/*IN    */ INTx4                record_data_size,
                         /*IN    */ PMDSPT_cfg_grp_rec  *grp_rec_ptr,
                         /*IN    */ PMDSIT_deformat_mode mode,
                         /*IN    */ LDEFIT_boolean       is_img,
                         /*IN    */ INTx4                vol_id,
                         /*IN    */ INTx4                start_row,
                         /*IN    */ INTx4                start_col,
                         /*IN    */ INTx4                end_row,
                         /*IN    */ INTx4                end_col,
                         /*IN    */ INTx4                ql_width,
                         /*IN    */ INTx4                ql_height,
                         /*IN    */ UINTx4               win_width,
                         /*IN    */ UINTx4               win_height,
                         /*IN    */ char                *tif_ann_file,
                         /*IN OUT*/ char                *tif_output_file,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*IN    */ UINTx1               out_ima_num,
                         /*IN    */ INTx4                nb_rec_field,
                         /*   OUT*/ LDEFIT_boolean      *image_completed,
                         /*   OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_DeformatFile

        $TYPE              PROCEDURE

        $INPUT        prod_file_name      : product file name
                      volume_type         : file extension
                      mode                : deformatting mode
                      fpCfg               : pointer to CFG file
                      vol_id              : current volume (tape) id
                      start_row           : starting row
                      start_col           : starting column
                      end_row             : end row
                      end_col             : end column
                      ql_width            : width of the output quick look
                      ql_height           : height of the output quick look
                      win_width           : width of the window to be used
                      win_height          : height of the window to be used
                      tif_ann_file        : tif annotation file name
                      tif_output_file     : output tiff file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Deformat the product file

        $WARNING      NONE

   $EH
   ========================================================================== */
   extern void PMDSPP_DeformatFile  
                          (/*IN    */ char                *prod_file_name,
                           /*IN    */ UINTx1               inp_ima_num,
                           /*IN    */ UINTx1               out_ima_num,
                           /*IN    */ PMDSPT_volume_type   volume_type,
                           /*IN    */ PMDSIT_deformat_mode mode,
                           /*IN    */ FILE                *fpCfg,
                           /*IN    */ INTx4                vol_id,
                           /*IN    */ INTx4                start_row,
                           /*IN    */ INTx4                start_col,
                           /*IN    */ INTx4                end_row,
                           /*IN    */ INTx4                end_col,
                           /*IN    */ INTx4                ql_width,
                           /*IN    */ INTx4                ql_height,
                           /*IN    */ UINTx4               win_width,
                           /*IN    */ UINTx4               win_height,
                           /*IN    */ char                *tif_ann_file,
                           /*IN OUT*/ char                *tif_output_file,
                           /*   OUT*/ LDEFIT_boolean      *image_completed,
                           /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_TFDM_AddTiffField

        $TYPE         PROCEDURE

        $INPUT        field_name_p        : tiff field name (description)
                      field_value_p       : pointer to the tiff field value

        $MODIFIED     tiff_field_list_p   : pointer to the tiff fields list

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_alloc_memory

        $DESCRIPTION  This procedure allows to add the list containing the
                      fields to be put into the output tiff file.

        $WARNING      BE SURE TO SET TO NULL THE LIST POINTER AND THE LIST
                      INDEX COUNTER AT THE START-UP.

        $PDL

   $EH
   ========================================================================== */
   extern void PMDSPP_TFDM_AddTiffField
                        (/*IN    */ char                *field_name_p,
                         /*IN    */ char                *field_value_p,
                         /*IN OUT*/ PMDSPT_TiffList     *tiff_field_list_p,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_TFDM_FreeTiffField

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     tiff_field_list_p   : pointer to the tiff fields list

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure allows to free the list containing the
                      fields to be put into the output tiff file.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void PMDSPP_TFDM_FreeTiffField
                        (/*IN OUT*/ PMDSPT_TiffList     *tiff_field_list_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_TFDM_GetTagFromDescr

        $TYPE         PROCEDURE

        $INPUT        descr_p             : tiff field name (description)

        $MODIFIED     NONE

        $OUTPUT       tag_p               : pointer to the tag to be returned

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_alloc_memory
                      ERRSID_PMDS_not_found

        $DESCRIPTION  This procedure allows to find a tag into the tag list
                      according to its description (tiff field name)

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void PMDSPP_TFDM_GetTagFromDescr
                        (/*IN    */ char                *descr_p,
                         /*   OUT*/ UINTx2              *tag_p,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSPP_TFDM_GetTagsFromFile

        $TYPE         PROCEDURE

        $INPUT        file_name_p         : file name with tags definitions

        $MODIFIED     NONE

        $OUTPUT       tag_data_p          : pointer to the tags list

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_not_found

        $DESCRIPTION  This procedure allows to fill tag list from file data.

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void PMDSPP_TFDM_GetTagsFromFile
                        (/*IN    */ char                *file_name_p,
                         /*   OUT*/ PMDSPT_TagList      *tag_data_p,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_ANNF_SetAnnFile

        $TYPE

        $INPUT        mode        : operation type onto the annotation file
                      data_type   : type of data to be read
                      label_p     : pointer to the current data label
                      data_p      : pointer to the current data to be read

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_error_paramaters
                      ERRSID_PMDS_error_create_file
                      ERRSID_PMDS_error_close_file

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern void PMDSIP_ANNF_SetAnnFile
                        (/*IN    */ PMDSPT_mode_type     mode,
                         /*IN    */ PMDSPT_data_type     data_type,
                         /*IN    */ char                *label_p,
                         /*IN    */ void                *data_p,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_ANNF_WriteAnnFile

        $TYPE

        $INPUT        label_p     : label data to be written into file line
                      data_p      : data to be written into file line
                      fp          : pointer to the annotation file

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure allows to write a new line into the file

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern void PMDSIP_ANNF_WriteAnnFile
                        (/*IN    */ char                *label_p,
                         /*IN    */ char                *data_p,
                         /*IN    */ FILE                *fp);


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_ANNF_FormatFieldData

        $TYPE

        $INPUT        max_field_len : maximum length reachable by field data
                      pos_list_p    : array of positions
                      len_list_p    : array of length(s)
                      pos_num_p     : number of positions
                      data_p        : pointer to field data

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure allows to split field data in multi-line

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern void PMDSIP_ANNF_FormatFieldData
                        (/*IN    */ INTx4                max_field_len,
                         /*IN    */ INTx4               *pos_list_p,
                         /*IN    */ INTx4               *len_list_p,
                         /*IN    */ INTx4               *pos_num_p,
                         /*IN    */ char                *data_p);

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_RETR_CheckBuffer

        $TYPE

        $INPUT        image_buffer     : image buffer to be checked
                      sub_image_buffer : image buffer to use as check
                      image_width      : image width
                      image_height     : image height
                      sub_image_width  : sub image width
                      sub_image_height : sub image height
                      start_row        : starting row in the image
                      start_col        : starting column in the image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_PMDS_alloc_memory

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern INTx4 PMDSIP_RETR_CheckBuffer
                        (/*IN    */ unsigned char       *image_buffer,
                         /*IN    */ unsigned char       *sub_image_buffer,
                         /*IN    */ INTx4                image_width,
                         /*IN    */ INTx4                image_height,
                         /*IN    */ INTx4                sub_image_width,
                         /*IN    */ INTx4                sub_image_height,
                         /*   OUT*/ INTx4               *start_row_p,
                         /*   OUT*/ INTx4               *start_col_p);

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_GRID_DrawCoord

        $TYPE

        $INPUT        pos          : position into the image buffer
                      file_type    : font tif file type
                      drawing_mode : overwrite or transparent drawing mode
                      width        : width of the image
                      height       : height of the image
                      image_buf    : image buffer to be updated

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern void PMDSIP_GRID_DrawCoord
                        (/*IN    */ INTx4                pos,
                         /*IN    */ char                *file_type,
                         /*IN    */ PMDSIT_drawing_mode  drawing_mode,
                         /*IN    */ INTx4                width,
                         /*IN    */ INTx4                height,
                         /*IN OUT*/ UINTx1              *image_buf,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_GRID_DrawPoint

        $TYPE

        $INPUT        point        : array of points
                      npoint       : number of points
                      max_ipoint   : maximum number of columns
                      max_jpoint   : maximum number of rows
                      width        : width of the image
                      height       : height of the image
                      image_buf    : image buffer to be updated

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern void PMDSIP_GRID_DrawPoint
                        (/*IN    */ MATHIT_RC           *point,
                         /*IN    */ INTx4                npoint,
                         /*IN    */ INTx4                max_ipoint,
                         /*IN    */ INTx4                max_jpoint,
                         /*IN    */ INTx4                width,
                         /*IN    */ INTx4                height,
                         /*IN OUT*/ UINTx1              *image_buf,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_ReadTape

        $TYPE

        $INPUT        input_media_path : source product media


        $MODIFIED     NONE

        $OUTPUT       vol_p            : list of volume data found into the tape

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern void PMDSIP_MDAN_ReadTape
                        (/*IN    */ char                *input_media_path,
                         /*   OUT*/ PMDSPT_VolDataList  *vol_p,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_AddRecord

        $TYPE

        $INPUT        record_data : record data found reading tape


        $MODIFIED     NONE

        $OUTPUT       rec_p       : record data list

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern INTx4 PMDSIP_MDAN_AddRecord
                        (/*IN    */ PMDSPT_RecordData     *record_data,
                         /*   OUT*/ PMDSPT_RecordDataList *rec_p);

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_AddFile

        $TYPE

        $INPUT        file_data : file data found reading tape


        $MODIFIED     NONE

        $OUTPUT       file_p    : file data list

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern INTx4 PMDSIP_MDAN_AddFile
                        (/*IN    */ PMDSPT_FileData     *file_data,
                         /*   OUT*/ PMDSPT_FileDataList *file_p);


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_AddVolume

        $TYPE

        $INPUT        vol_data : volume data found reading tape


        $MODIFIED     NONE

        $OUTPUT       vol_p    : volume data list

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern INTx4 PMDSIP_MDAN_AddVolume
                        (/*IN    */ PMDSPT_VolData     *vol_data,
                         /*   OUT*/ PMDSPT_VolDataList *vol_p);


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_ReadProductRecord

        $TYPE

        $INPUT        db_file_name_p : product(s) data base file name
                      vol_p          : volume data list

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern INTx4 PMDSIP_MDAN_ReadProductRecord
                        (/*IN    */ char                *db_file_name_p,
                         /*IN    */ PMDSPT_VolDataList  *vol_p,
                         /*   OUT*/ PMDSPT_VolDataList **db_vols_p,
                         /*   OUT*/ INTx4               *count_db_vols );


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_CompareProduct

        $TYPE

        $INPUT        db_record : product(s) data base record
                      vol_p     : volume data list


        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern void PMDSIP_MDAN_CompareProduct
                        (/*IN    */ PMDSPT_VolDataList  *db_record,
                         /*IN    */ PMDSPT_VolDataList  *vol_p);


/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         PMDSIP_MDAN_CreateMCR

        $TYPE

        $INPUT        vol_p           : volume data list


        $MODIFIED     NONE

        $OUTPUT       mcr_file_name_p : media content report file name

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  Please fill the form

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
extern void PMDSIP_MDAN_CreateMCR
                        (/*IN    */ PMDSPT_VolDataList  *db_vols_p,
                         /*IN    */ INTx4                count_db_vols,
                         /*IN    */ PMDSPT_VolDataList  *vol_p,
                         /*   OUT*/ char                *mcr_file_name_p,
                         /*   OUT*/ ERRSIT_status       *status_code );


/* ==========================================================================
 
   $ROUTINE_HEADER
 
        $NAME         PMDSPP_UNDR_ConvCoreConstKern
 
        $TYPE         PROCEDURE
 
        $INPUT        nrow_inp      : number of rows of the input image block
                      ncol_inp      : number of columns of the input image block
                      RStartR       : start row in the input image reference
                                      system of the image block passed at the
                                      current procedure
                      StepR         : step size in the rows direction
                      StepC         : step size in the columns direction
                      vertex_no     : number of vertex in AOI (0, if any)
                      vertex        : arry of vertex(0 .. vertex_no-1)
                      Kern          : pointer to the pointer to the kernel of
                                      the filtering matrix
                      Kr            : rows' kernel size
                      Kc            : columns' kernel size
                      InpIma        : pointer to the pointer to the input image
                                      block
                      RStartW       : start row to write the output image
                      RStopW        : stop row to write the output image
                      inp_data_type : flag that indicates the image data type
                      out_chan      : channel of the output TIFF image
                      out_img       : image number of the output TIFF image
                      fill_val      : float value of initial skip in line
 
        $MODIFIED     NONE
 
        $OUTPUT       The output file is written
 
        $GLOBAL       NONE
 
        $RET_STATUS   ERRSID_PMDS_kernel_dim_high
                      ERRSID_PMDS_bad_steps
                      ERRSID_PMDS_bad_write_size
                      ERRSID_PMDS_err_mem_alloc
                      ERRSID_PMDS_not_under_allow
 
        $DESCRIPTION  This procedure convolves the constant kernel given in
                      input with the image block also given and writes the
                      output in the file passed by its channel and img parameter
 
        $WARNING      The output file must be previously opened and initialized
                      by the driver of this procedure.
 
        $PDL          - Allocate the output vector
                      - Switch on the various types of input image data
                            - Loop on the rows' steps
                                  - Loop on the columns' steps
                                        - Reset the index of start and stop
                                        - Sum the window element
                                        - Fill the output vector rescaling it
                                          by the kernel constant value
                                  - End columns' loop
                                  - Write the output row in the output file
                            - End rows' loop
                      - End Switch
 
   $EH
   ========================================================================== */
   extern void PMDSPP_UNDR_ConvCoreConstKern
                        (/*IN    */ UINTx4               nrow_inp,
                         /*IN    */ UINTx4               ncol_inp,
                         /*IN    */ UINTx4               RStartR,
                         /*IN    */ double               StepR,
                         /*IN    */ double               StepC,
                         /*IN    */ UINTx4               vertex_no,
                         /*IN    */ MATHIT_RC           *vertex,
                         /*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*IN    */ void               **InpIma,
                         /*IN    */ UINTx4               RStartW,
                         /*IN    */ UINTx4               RStopW,
                         /*IN    */ LDEFIT_data_type     inp_data_type,
                         /*IN    */ GIOSIT_io           *out_io,
                         /*IN    */ UINTx4               ncol_out,
                         /*IN    */ float                fill_val,
                         /*IN    */ UINTx1               inp_ima_num,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         PMDSPP_

      $DESCRIPTION  

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/*   extern void PMDSPP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         PMDSPF_GLBL_set_error

      $DESCRIPTION  Set the status code inside the package

      $TYPE         FUNCTION

      $INPUT        local_status_code

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
   extern INTx4 PMDSPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         PMDSPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void PMDSPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) PMDSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
#define STC( status_code ) ( PMDSPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         PMDSIM_

      $DESCRIPTION  This procedure

                    PMDSIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define PMDSPM_
*/

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         PMDSPM_vdf_volume
                    PMDSPM_ldr_volume
                    PMDSPM_img_volume
                    PMDSPM_nul_volume

      $DESCRIPTION  String volumes

      $TYPE         MACRO


   $EH
   ========================================================================== */
#define PMDSPM_vdf_volume \
         PMDSPV_volume_name[PMDSPE_vdf_volume]
#define PMDSPM_ldr_volume \
         PMDSPV_volume_name[PMDSPE_ldr_volume]
#define PMDSPM_img_volume \
         PMDSPV_volume_name[PMDSPE_img_volume]
#define PMDSPM_nul_volume \
         PMDSPV_volume_name[PMDSPE_nul_volume]

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         PMDSPM_mrk_var_begin
                    PMDSPM_mrk_var_end
                    PMDSPM_mrk_log_vol_begin
                    PMDSPM_mrk_log_vol_end
                    PMDSPM_mrk_record_begin
                    PMDSPM_mrk_record_end
                    PMDSPM_mrk_file_begin
                    PMDSPM_mrk_file_end
                    PMDSPM_mrk_repeat_begin
                    PMDSPM_mrk_repeat_end
                    PMDSPM_mrk_img_begin
                    PMDSPM_mrk_img_end
                    PMDSPM_mrk_skip_next_block_if_more_vol

      $DESCRIPTION  String markers

      $TYPE         MACRO


   $EH
   ========================================================================== */
#define PMDSPM_mrk_var_begin        \
         PMDSPV_marker_name[PMDSPE_mrk_var_begin]
#define PMDSPM_mrk_var_end          \
         PMDSPV_marker_name[PMDSPE_mrk_var_end]

#define PMDSPM_mrk_log_vol_begin    \
         PMDSPV_marker_name[PMDSPE_mrk_log_vol_begin]
#define PMDSPM_mrk_log_vol_end      \
         PMDSPV_marker_name[PMDSPE_mrk_log_vol_end]

#define PMDSPM_mrk_record_begin     \
         PMDSPV_marker_name[PMDSPE_mrk_record_begin]
#define PMDSPM_mrk_record_end       \
         PMDSPV_marker_name[PMDSPE_mrk_record_end]

#define PMDSPM_mrk_file_begin       \
         PMDSPV_marker_name[PMDSPE_mrk_file_begin]
#define PMDSPM_mrk_file_end         \
         PMDSPV_marker_name[PMDSPE_mrk_file_end]

#define PMDSPM_mrk_repeat_begin     \
         PMDSPV_marker_name[PMDSPE_mrk_repeat_begin]
#define PMDSPM_mrk_repeat_end       \
         PMDSPV_marker_name[PMDSPE_mrk_repeat_end]

#define PMDSPM_mrk_img_begin     \
         PMDSPV_marker_name[PMDSPE_mrk_img_begin]
#define PMDSPM_mrk_img_end       \
         PMDSPV_marker_name[PMDSPE_mrk_img_end]

#define PMDSPM_mrk_skip_next_block_if_more_vol \
         PMDSPV_marker_name[PMDSPE_mrk_skip_next_block_if_more_vol]

