#ifdef __HAVEIDL__
/* ==========================================================================
   $MODULE_HEADER

      $NAME              STBX_IDLI

      $FUNCTION          SAR TOOLBOX - IDL interface module.

      $ROUTINE           stbx_oversampling
                         stbx_kernelfiltering
			 stbx_globalstatistic
			 stbx_localmean
			 stbx_localsddv
			 stbx_localcfvr
			 stbx_first_pca
			 stbx_second_pca
                         stbx_speckle
                         stbx_gainconv
                         stbx_lutconv
                         STBXPP_IDLI_IDLOverGetInputPar
                         STBXPP_IDLI_IDLOverFillAnno
                         STBXPP_IDLI_IDLOverFillBpar
			 STBXPP_IDLI_IDLGstaGetInputPar
			 STBXPP_IDLI_IDLGstaFillAnno
			 STBXPP_IDLI_IDLLstaGetInputPar
			 STBXPP_IDLI_IDLLstaFillAnno
			 STBXPP_IDLI_IDLLocalStatistic
			 STBXPP_IDLI_IDLPcaGetInputPar
			 STBXPP_IDLI_IDLPcaFillAnno
			 STBXPP_IDLI_IDLPca
                         STBXPP_IDLI_IDLFillImage
                         STBXPP_IDLI_IDLUnderCheckFilter
                         STBXPP_IDLI_IDLUnderFiltCopy
                         STBXPP_IDLI_IDLSpckGetInputPar
                         STBXPP_IDLI_GetImage
                         STBXPP_IDLI_GetArray
                         STBXPP_IDLI_GetParValue
                         STBXPP_IDLI_GetParAddress
                         STBXPP_IDLI_GetArrayAddress
			 STBXPP_IDLI_CreateArray
			 STBXPP_IDLI_CreateMatrix
                         STBXPP_IDLI_IDLVar2INTx2
                         STBXPP_IDLI_IDLVar2INTx4
                         STBXPP_IDLI_IDLVar2UINTx2
                         STBXPP_IDLI_IDLVar2UINTx4
                         STBXPP_IDLI_IDLVar2float
                         STBXPP_IDLI_IDLVar2double
                         STBXPP_IDLI_IDLArray2INTx2
                         STBXPP_IDLI_IDLArray2INTx4
                         STBXPP_IDLI_IDLArray2UINTx2
                         STBXPP_IDLI_IDLArray2UINTx4
                         STBXPP_IDLI_IDLArray2float
                         STBXPP_IDLI_IDLArray2double

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       10-MAR-97     AN       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef STBX_I
#define STBX_I STBX_I


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */
#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include IDLI_INTF_H
#include TIFS_INTF_H
#include STAT_INTF_H
#include STBX_PGLB_H
#include STBX_INTF_H

#ifdef STBX_IDLI_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

	 $NAME         STBXPD_IDLI_max_mess_length

	 $DESCRIPTION  Maximum message size for IDL help

   $EH
   ========================================================================== */
#define STBXPD_IDLI_max_mess_length 2048

/* ==========================================================================
   $DECLARATION_HEADER

         $NAME         STBXPD_IDLI_max_rout_length

         $DESCRIPTION  Maximum message size for IDL help

   $EH
   ========================================================================== */
#define STBXPD_IDLI_max_rout_length 128


/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_strn_...
      $DESCRIPTION  Define the name of each SAR Toolbox task called by
                    inside IDL

   $EH
   ========================================================================== */
#define STBXPD_strn_image_oversampling        "stbx_oversampling"
#define STBXPD_strn_image_undersampling       "stbx_kernelfiltering"
#define STBXPD_strn_global_statistic	      "stbx_globalstatistic"
#define STBXPD_strn_local_statistic	      "stbx_local"
#define STBXPD_strn_princ_component	      "stbx_pca"
#define STBXPD_strn_media_analysis            " "
#define STBXPD_strn_header_decode             " "
#define STBXPD_strn_quick_look                " "
#define STBXPD_strn_image_preview             " "
#define STBXPD_strn_retrieve_coord            " "
#define STBXPD_strn_full_resolution           " "
#define STBXPD_strn_support_data              " "
#define STBXPD_strn_new_format                " "
#define STBXPD_strn_speckle_filter            "stbx_speckle"
#define STBXPD_strn_ampl_power                " "
#define STBXPD_strn_power_ampl                " "
#define STBXPD_strn_complex_ampl              " "
#define STBXPD_strn_pixel_float               " "
#define STBXPD_strn_gain_conversion           "stbx_gainconv"
#define STBXPD_strn_lut_conversion            "stbx_lutconv"
#define STBXPD_strn_scl_conversion            "stbx_sclconv"
#define STBXPD_strn_tiff_generation           " "
#define STBXPD_strn_bil_generation            " "
#define STBXPD_strn_ancillary_data            "stbx_dump"
#define STBXPD_strn_import_raster             " "

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_total_idl_task_no

      $DESCRIPTION  Define the total number of SAR Toolbox task called by
                    inside IDL

   $EH
   ========================================================================== */
#define STBXPD_idl_total_task_no  25

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPD_IDLI_gsta_nopar

      $DESCRIPTION  It contais the number of parameters necessary for 
                    STATISTIC tasks IDL STBX call, when needed 

   $EH
   ========================================================================== */
#define STBXPD_IDLI_gsta_nopar 9
#define STBXPD_IDLI_lsta_nopar 4

/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum STBXIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXIC_

      $DESCRIPTION  The STBXIC_

   $EH
   ========================================================================== */
/*   const STBXIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXIT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct STBXIT_*_def { 

   typedef struct STBXIT_*_def STBXIT_*
*/

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_over_idl_par

      $DESCRIPTION  Structure to hold the input parameters of IMAGE 
                    OVERSAMPLING task

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          inp_ima                          Pointer to the first data element
                                           of the input image
          NRowsInp                         Number of input image rows
          NColsInp                         Number of input image columns
          InpDataType                      Input data type using the enumerate
                                           LDEFIT_data_type
          TLRow                            Top left row of the input image in
                                           the full image reference system
          TLCol                            Top left col of the input image in
                                           the full image reference system
          PixSpa                           Pixel spacing in range
          FdcCoeff                         Array of coefficients for the zero
                                           doppler centroide evaluation
          prf                              Pulse Repetition Frequency
          out_ima                          Pointer to the first data element
                                           of the output image
          NRowsOut                         Number of output image rows
          NColsOut                         Number of output image columns
          OutDataType                      Output data type using the enumerate
                                           LDEFIT_data_type

   $EH
   ========================================================================== */
   struct STBXPT_over_idl_par_def {
      void                  *inp_ima;
      UINTx4                 NRowsInp;
      UINTx4                 NColsInp;
      LDEFIT_data_type       InpDataType;
      INTx4                  TLRow;
      INTx4                  TLCol;
      float                  PixSpa;
      float                 *FdcCoeff;
      float                  prf;
      void                  *out_ima;
      UINTx4                 NRowsOut;
      UINTx4                 NColsOut;
      LDEFIT_data_type       OutDataType;
   };

   typedef struct STBXPT_over_idl_par_def STBXPT_over_idl_par;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_under_idl_par

      $DESCRIPTION  Structure to hold the input parameters of IMAGE
                    UNDERSAMPLING task

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          inp_ima                          Pointer to the first data element
                                           of the input image
          NRowsInp                         Number of input image rows
          NColsInp                         Number of input image columns
          InpDataType                      Input data type using the enumerate
                                           LDEFIT_data_type
          Kern                             Pointer to the matrix with which
                                           the input image must be convolved
          Kr                               Filter size in the rows direction
          Kc                               Filter size in the columns direction
          out_ima                          Pointer to the first data element
                                           of the output image
          NRowsOut                         Number of output image rows
          NColsOut                         Number of output image columns
          OutDataType                      Output data type using the enumerate
                                           LDEFIT_data_type

   $EH
   ========================================================================== */
   struct STBXPT_under_idl_par_def {
      void                 **inp_ima;
      UINTx4                 NRowsInp;
      UINTx4                 NColsInp;
      LDEFIT_data_type       InpDataType;
      float                **Kern;
      UINTx4                 Kr;
      UINTx4                 Kc;
      void                  *out_ima;
      UINTx4                 NRowsOut;
      UINTx4                 NColsOut;
      LDEFIT_data_type       OutDataType;
   };

   typedef struct STBXPT_under_idl_par_def STBXPT_under_idl_par;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_gsta_idl_par

      $DESCRIPTION  Structure to hold the input parameters of LOCAL STATISTIC
                    task

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          inp_ima                          Pointer to the first data element
                                           of the input image
          NRowsInp                         Number of input image rows
          NColsInp                         Number of input image columns
          InpDataType                      Input data type using the enumerate
                                           LDEFIT_data_type
          ClassMin                         Minimum value for histogram vector
          ClassMax                         Maximum value for histogram vector
          ClassNo                          Number of Class 
          vertex                           number of coordinates
          Mean                             Output mean value
          Sddv                             Output standard deviation value
          Cfvr                             Output coefficient of variation value
          Min                              Image Min
          Max                              Image Max
          Classes                          Class histogram values

   $EH
   ========================================================================== */
   struct STBXPT_gsta_idl_par_def {
      void                  *inp_ima;
      UINTx4                 NRowsInp;
      UINTx4                 NColsInp;
      LDEFIT_data_type       InpDataType;
      float                  ClassMin;
      float                  ClassMax;
      UINTx4                 ClassNo;
      float                 *Mean;
      float                 *Sddv;
      float                 *Cfvr;
      float                 *Min;
      float                 *Max;
      INTx4                 *Classes;
      UINTx4                 vertex;
      float                 *NClasses;
      float                 *LClasses;
      INTx4                 *x_aoi;
      INTx4                 *y_aoi;
   };

   typedef struct STBXPT_gsta_idl_par_def STBXPT_gsta_idl_par;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_lsta_idl_par

      $DESCRIPTION  Structure to hold the input parameters of GLOBAL STATISTIC
                    task

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          inp_ima                          Pointer to the first data element
                                           of the input image
          NRowsInp                         Number of input image rows
          NColsInp                         Number of input image columns
          InpDataType                      Input data type using the enumerate
                                           LDEFIT_data_type
          ClassMin                         Minimum value for histogram vector
          ClassMax                         Maximum value for histogram vector
          ClassNo                          Number of Class 
          vertex                           number of coordinates
          win_sizes                        window sizes
          win_increments                   window steps
          out_ima                          Pointer to the first data element
                                           of the output image
          NRowsOut                         Number of output image rows
          NColsOut                         Number of output image columns
          OutDataType                      Output data type using the enumerate
                                           LDEFIT_data_type

   $EH
   ========================================================================== */
   struct STBXPT_lsta_idl_par_def {
      void                  *inp_ima;
      UINTx4                 NRowsInp;
      UINTx4                 NColsInp;
      LDEFIT_data_type       InpDataType;
      INTx4                 *x_aoi;
      INTx4                 *y_aoi;
      UINTx4                 vertex;
      INTx4                 *win_sizes;
      double                *win_steps;
      float                  fill_val;
      void                  *out_ima;
      UINTx4                 NRowsOut;
      UINTx4                 NColsOut;
      LDEFIT_data_type       OutDataType;   
   };

   typedef struct STBXPT_lsta_idl_par_def STBXPT_lsta_idl_par;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_pca_idl_par

      $DESCRIPTION  Structure to hold the input parameters of PCA
                    task

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          inp_ima1                         Pointer to the first data element
                                           of the first input image
          NRowsInp1                        Number of first input image rows
          NColsInp1                        Number of first input image columns
          InpDataType1                     First nput data type using the 
                                           enumerate LDEFIT_data_type
          inp_ima2                         Pointer to the first data element
                                           of the second input image
          NRowsInp2                        Number of second input image rows
          NColsInp2                        Number of second input image columns
          InpDataType2                     Second input data type using the 
                                           enumerate LDEFIT_data_type
          x_aoi                            X coordinates of AOI
          y_aoi                            Y coordinates of AOI
          vertex                           number of coordinates
          out_ima1                         Pointer to the first data element
                                           of the first output image
          NRowsOut1                        Number of first output image rows
          NColsOut1                        Number of first output image columns
          OutDataType1                     First output data type using the 
                                           enumerate LDEFIT_data_type
          out_ima2                         Pointer to the first data element
                                           of the second output image
          NRowsOut2                        Number of second output image rows
          NColsOut2                        Number of second output image columns
          OutDataType2                     Second output data type using the 
                                           enumerate LDEFIT_data_type

   $EH
   ========================================================================== */
   struct STBXPT_pca_idl_par_def {
      void                  *inp_ima1;
      UINTx4                 NRowsInp1;
      UINTx4                 NColsInp1;
      LDEFIT_data_type       InpDataType1;
      void                  *inp_ima2;
      UINTx4                 NRowsInp2;
      UINTx4                 NColsInp2;
      LDEFIT_data_type       InpDataType2;
      void                  *out_ima1;
      UINTx4                 NRowsOut1;
      UINTx4                 NColsOut1;
      LDEFIT_data_type       OutDataType1;   
      void                  *out_ima2;
      UINTx4                 NRowsOut2;
      UINTx4                 NColsOut2;
      LDEFIT_data_type       OutDataType2;   
   };

   typedef struct STBXPT_pca_idl_par_def STBXPT_pca_idl_par;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_speckle_idl_par

      $DESCRIPTION  Structure to hold the input parameters of IMAGE
                    SPECKLE FILTERING task

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          inp_ima                          Pointer to the first data element
                                           of the input image
          NRowsInp                         Number of input image rows
          NColsInp                         Number of input image columns
          InpDataType                      Input data type using the enumerate
                                           LDEFIT_data_type
          Kern                             Pointer to the matrix with which
                                           the input image must be convolved
          Kr                               Filter size in the rows direction
          Kc                               Filter size in the columns direction
          out_ima                          Pointer to the first data element
                                           of the output image
          NRowsOut                         Number of output image rows
          NColsOut                         Number of output image columns
          OutDataType                      Output data type using the enumerate
                                           LDEFIT_data_type

   $EH
   ========================================================================== */
   struct STBXPT_speckle_idl_par_def {
      void                  *inp_ima;
      UINTx4                 NRowsInp;
      UINTx4                 NColsInp;
      LDEFIT_data_type       InpDataType;
      float                  look_no;
      UINTx4                 Kr;
      UINTx4                 Kc;
      FILSIT_file_name       mask_file;
      float                  pfa;
      float                  edge_th;
      float                  line_th;
      float                  scatter_th;
      void                  *out_ima;
      UINTx4                 NRowsOut;
      UINTx4                 NColsOut;
      LDEFIT_data_type       OutDataType;
   };

   typedef struct STBXPT_speckle_idl_par_def STBXPT_speckle_idl_par;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_gain_idl_par

      $DESCRIPTION  Structure to hold the input parameters of the
                    GAIN CONVERTION task

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          inp_ima                          Pointer to the first data element
                                           of the input image
          NRowsInp                         Number of input image rows
          NColsInp                         Number of input image columns
          InpDataType                      Input data type using the enumerate
                                           LDEFIT_data_type
          min_perc                         a value associated to the starting 
                                           level of the linear conversion
          max_perc                         a value associated to the ending 
                                           level of the linear conversion
          no_black_founded                 TRUE if no_black has been defined
          no_black                         a value to be used as the initial
                                           image levels outside the conversion
          out_ima                          Pointer to the first data element
                                           of the output image
          NRowsOut                         Number of output image rows
          NColsOut                         Number of output image columns
          OutDataType                      Output data type using the enumerate
                                           LDEFIT_data_type

   $EH
   ========================================================================== */
   struct STBXPT_gain_idl_par_def {
      void                  *inp_ima;
      UINTx4                 NRowsInp;
      UINTx4                 NColsInp;
      LDEFIT_data_type       InpDataType;
      float                  min_perc;
      float                  max_perc;
      LDEFIT_boolean         no_black_founded;
      float                  no_black;
      void                  *out_ima;
      UINTx4                 NRowsOut;
      UINTx4                 NColsOut;
      LDEFIT_data_type       OutDataType;
   };

   typedef struct STBXPT_gain_idl_par_def STBXPT_gain_idl_par;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_lut_idl_par

      $DESCRIPTION  Structure to hold the input parameters of the
                    GAIN CONVERTION with LUT task

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          inp_ima                          Pointer to the first data element
                                           of the input image
          NRowsInp                         Number of input image rows
          NColsInp                         Number of input image columns
          InpDataType                      Input data type using the enumerate
                                           LDEFIT_data_type
          lut_file                         the file name of a user-defined
                                           look-up table
          out_ima                          Pointer to the first data element
                                           of the output image
          NRowsOut                         Number of output image rows
          NColsOut                         Number of output image columns
          OutDataType                      Output data type using the enumerate
                                           LDEFIT_data_type

   $EH
   ========================================================================== */
   struct STBXPT_lut_idl_par_def {
      void                  *inp_ima;
      UINTx4                 NRowsInp;
      UINTx4                 NColsInp;
      LDEFIT_data_type       InpDataType;
      FILSIT_file_name       lut_file;
      void                  *out_ima;
      UINTx4                 NRowsOut;
      UINTx4                 NColsOut;
      LDEFIT_data_type       OutDataType;
   };

   typedef struct STBXPT_lut_idl_par_def STBXPT_lut_idl_par;

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPT_scale_idl_par

      $DESCRIPTION  Structure to hold the input parameters of the
                    GAIN CONVERTION with scaling factor task

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------
          inp_ima                          Pointer to the first data element
                                           of the input image
          NRowsInp                         Number of input image rows
          NColsInp                         Number of input image columns
          InpDataType                      Input data type using the enumerate
                                           LDEFIT_data_type
          scale_fact                       the convertion scaling factor
          out_ima                          Pointer to the first data element
                                           of the output image
          NRowsOut                         Number of output image rows
          NColsOut                         Number of output image columns
          OutDataType                      Output data type using the enumerate
                                           LDEFIT_data_type

   $EH
   ========================================================================== */
   struct STBXPT_scale_idl_par_def {
      void                  *inp_ima;
      UINTx4                 NRowsInp;
      UINTx4                 NColsInp;
      LDEFIT_data_type       InpDataType;
      float                  scale_fact;
      void                  *out_ima;
      UINTx4                 NRowsOut;
      UINTx4                 NColsOut;
      LDEFIT_data_type       OutDataType;
   };

   typedef struct STBXPT_scale_idl_par_def STBXPT_scale_idl_par;

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXPV_IDLI_routine_name

      $DESCRIPTION  It contais the name of the STBX routine as called 
                    from IDL

   $EH
   ========================================================================== */
#ifdef STBX_IDLI_GLBL
   GLOBAL char STBXPV_IDLI_routine_name[ STBXPD_idl_total_task_no ]
                                       [ STBXPD_IDLI_max_rout_length ] =
           { STBXPD_strn_image_oversampling,
             STBXPD_strn_image_undersampling,
	     STBXPD_strn_global_statistic,
	     STBXPD_strn_local_statistic,
	     STBXPD_strn_princ_component,
	     STBXPD_strn_media_analysis,
	     STBXPD_strn_header_decode,
	     STBXPD_strn_quick_look,
	     STBXPD_strn_image_preview,
	     STBXPD_strn_retrieve_coord,
	     STBXPD_strn_full_resolution,
	     STBXPD_strn_support_data,
	     STBXPD_strn_new_format,
	     STBXPD_strn_speckle_filter,
             STBXPD_strn_ampl_power,
             STBXPD_strn_power_ampl,
             STBXPD_strn_complex_ampl,
             STBXPD_strn_pixel_float,
             STBXPD_strn_gain_conversion,
             STBXPD_strn_lut_conversion,
             STBXPD_strn_scl_conversion,
             STBXPD_strn_tiff_generation,
             STBXPD_strn_bil_generation,
             STBXPD_strn_ancillary_data,
             STBXPD_strn_import_raster
};
#else
   GLOBAL char STBXPV_IDLI_routine_name[ STBXPD_idl_total_task_no ]
                                       [ STBXPD_IDLI_max_rout_length ];
#endif

#ifdef STBX_IDLI_GLBL
   GLOBAL char STBXPV_IDLI_help_message[ STBXPD_idl_total_task_no ]
                                       [ STBXPD_IDLI_max_mess_length ] = {

   /* Image oversampling  */
"$\
   Calling Sequence$$\
\
      OutIma = stbx_oversampling( InpIma, TLRow, TLCol, RangeSpacing,$\
                       FdcPoly, PRF, OutRowSize, OutColumnSize [, /RATIO ])$$\
\
   Arguments$$\
\
      InpIma$\
         The input image to resample$$\
\
      TLRow$\
         Top left row of the first image pixel in the full image$\
         reference frame$$\
\
      TLCol$\
         Top left column of the first image pixel in the full image$\
         reference frame$$\
\
      RangeSpacing$\
         Spacing in the range direction (take it from image annotations)$$\
\
      FdcPoly$\
         Array with the coefficients of the doppler centroid frequency$\
         polynomial (take them from image annotations)$$\
\
      PRF$\
         The Pulse Repetition Frequency of the image$$\
\
      OutRowSize$\
         The row size of the output image or the row ratio (if /RATIO)$$\
\
      OutColumnSize$\
         The column size of the output image or the column ratio (if /RATIO)$$\
\
      OutIma$\
         Output image always of FLOAT data type or COMPLEX for complex$\
         input images$$",

   /* Image undersampling */
"$\
   Calling Sequence$$\
\
      OutIma = stbx_kernelfiltering( InpIma, Kern, OutRowSize,$\
                                     OutColumnSize [, /RATIO ])$$\
\
   Arguments$$\
\
      InpIma$\
         The input image to resample$$\
\
      Kern$\
         Kernel FLOAT matrix with which the input image$\
         must be filtered$$\
\
      OutRowSize$\
         The row size of the output image or the row ratio (if /RATIO)$$\
\
      OutColumnSize$\
         The column size of the output image or the column ratio (if /RATIO)$$\
\
      OutIma$\
         Output image always of FLOAT data type or COMPLEX for complex$\
         input images$$",

   /* Global Statistic */
"$\
   Calling Sequence$$\
\
      Classes = stbx_globalstatistic( InpIma, ClassMin, ClassMax, ClassNo,$\
                             Mean, Sddv, Cfvr, Min, Max [, X, Y]$\
                             [, NCLASSES = nclasses] [, LIMITS = lclasses])$$\
\
   Arguments$$\
\
      InpIma$\
         The input image matrix$$\
\
      ClassMin$\
         A FLT value for the minimum class of the histogram$$\
\
      ClassMax$\
         A FLT value for the maximum class for the histogram$$\
\
      ClassNo$\
         An INT value for the histogram classes number$$\
\
      Mean$\
         A variable where the mean is stored as a FLT value$$\
\
      Sddv$\
         A variable where the standard deviation is stored as a FLT value$$\
\
      Cfvr$\
         A variable where the coefficient of variation$\
         is stored as a FLT value$$\
\
      Min$\
         A variable where the image min$\
         is stored as a FLT value$$\
\
      Max$\
         A variable where the image max$\
         is stored as a FLT value$$\
\
      nclasses$\
         An array where ClassNo+2 normalized histogram class values are stored$\
         as FLT values$$\
\
      lclasses$\
         An array where ClassNo+2 limit class values are stored$\
         as FLT value$$\
\
      Classes$\
         An array where ClassNo+2 histogram class values are stored$\
         as LONG values$$\
\
      X (optional)$\
         A LONG array containing the row coordinates of AOI$$\
\
      Y (optional)$\
         A LONG array containing the column coordinates of AOI$$",

   /* Local Statistic */
"$\
   Calling Sequence$$\
\
      OutIma = stbx_localmean( InpIma, Wsize, Wstep, F [, X, Y] [, /RATIO ])$\
      OutIma = stbx_localsddv( InpIma, Wsize, Wstep, F [, X, Y] [, /RATIO ])$\
      OutIma = stbx_localcfvr( InpIma, Wsize, Wstep, F [, X, Y] [, /RATIO ])$\
\
   Arguments$$\
\
      InpIma$\
         The input image matrix$$\
\
      Wsize$\
         A LONG array containing the row and column window size$$\
\
      WSteps$\
         A DBL array containing the row and column window steps or image ratio$$\
\
      F$\
	 A FLT value to be used as filler for pixels outside the AOI$$\
\
      OutIma$\
         The output image always of FLT data type$$\
\
      X (optional)$\
         A LONG array containing the row coordinates of AOI$$\
\
      Y (optional)$\
         A LONG array containing the column coordinates of AOI$$",

   /* Principal Component Analysis */
"$\
   Calling Sequence$$\
\
      OutIma = stbx_first_pca( InpIma1, InpIma2 )$\
      OutIma = stbx_second_pca( InpIma1, InpIma2 )$\
\
   Arguments$$\
\
      InpIma1$\
         First input image$$\
\
      InpIma2$\
         Second input image$$\
\
      OutIma$\
         First or Second PCA output image of FLOAT data type$$",

" ",     /* 1 */
" ",     /* 2 */
" ",     /* 3 */
" ",     /* 4 */
" ",     /* 5 */
" ",     /* 6 */
" ",     /* 7 */
" ",     /* 8 */
   /* Speckle Filtering */
"$\
   Calling Sequence$$\
\
      OutIma = stbx_speckle( InpIma, RowWinSize, ColWinSize, LookNo, Pfa,$\
                          ScatterTh [, EDGE_TH=EdgeTh]$\
                          [, LINE_TH=LineTh ] [, MASK_FILE=UserMaskFile] )$\
\
   Arguments$$\
\
      InpIma$\
         Input image$$\
\
      RowWinSize$\
         A INT value to be used as the row window size$$\
\
      ColWinSize$\
         A INT value to be used as the column window size$$\
\
      LookNo$\
         A FLT value to be used as the equivalent number of look$$\
\
      Pfa$\
         A FLT value to be used as the Pfa value$$\
\
      ScatterTh$\
         A FLT value to be used as the threshold for the scatter mask$$\
\
      EdgeTh$\
         A FLT value to be used as the threshold for the edge mask$$\
\
      LineTh$\
         A FLT value to be used as the threshold for the line mask$$\
\
      UserMaskFile$\
         A STRING value to be used as the file name$\
         for a user defined mask file$$\
\
      OutIma$\
         Speckle filtered image always of FLOAT type$$", 
" ",     /* 1 */
" ",     /* 2 */
" ",     /* 3 */
" ",     /* 4 */

   /* GAIN CONVERSION */
"$\
   Calling Sequence$$\
\
      OutIma = stbx_gainconv( InpIma, MinPerc, MaxPerc$\
                              [, NO_BLACK = NoBlacks] )$\
\
   Arguments$$\
\
      InpIma$\
         The input image matrix$$\
\
      MinPerc$\
         A FLT value associated to the starting level of the linear conversion$$\
\
      MaxPerc$\
         A FLT value associated to the ending level of the linear conversion$$\
\
      NoBlacks$\
	 A LONG value to be used as the initial image levels outside the conversion$$\
\
      OutIma$\
         The output image always of BYTE data type$$",

   /* LUT CONVERSION */
"$\
   Calling Sequence$$\
\
      OutIma = stbx_lutconv( InpIma, UserLutFile )$\
\
   Arguments$$\
\
      InpIma$\
         The input image matrix$$\
\
      UserLutFile$\
         A STRING containing the file name of a user-defined look-up table$$\
\
      OutIma$\
         The output image always of BYTE data type$$",

   /* SCALE FACTOR CONVERSION */
"$\
   Calling Sequence$$\
\
      OutIma = stbx_sclconv( InpIma, ScaleFactor )$\
\
   Arguments$$\
\
      InpIma$\
         The input image matrix$$\
\
      ScaleFactor$\
         A FLT value to be used as the scaling factor in image convertion$$\
\
      OutIma$\
         The output image always of BYTE data type$$",

" ",     /* 8 */
" ",     /* 9 */

   /* ANCILLARY DATA DUMP */
"$\
   Calling Sequence$$\
\
      stbx_dump, InpImaFileName, OutFileName$\
\
   Arguments$$\
\
      InpImaFileName$\
         The input image file name$$\
\
      OutFileName$\
         The output file name containing the ancillary data dump listing$$",

" "      /* 11 */
};
#else
   GLOBAL char STBXPV_IDLI_help_message[ STBXPD_idl_total_task_no ]
                                       [ STBXPD_IDLI_max_mess_length ];
#endif

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         STBXIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_oversampling

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             - InpIma       : pointer to the input image
                             - TLRow        : top left row of the zone of the
                                              input image to oversample
                             - TLCol        : top left column of the zone of
                                              the input image to oversample
                             - RangeSpacing : spacing in the range direction of
                                              the input image
                             - FdcPoly      : array with the values of the
                                              coefficients to evaluate the
                                              doppler centroide frequency
                             - PRF          : Pulse Repetition Frequency
                             - OutIma       : pointer to the buffer in which
                                              the output image will be stored

        $MODIFIED     NONE

        $OUTPUT       The output image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the oversampling
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREBLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_oversampling
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_kernelfiltering

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             - InpIma : pointer to the input image
                             - Kern   : pointer to the kernel matrix
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored

        $MODIFIED     NONE

        $OUTPUT       The output image is filled

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the undersampling
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Fills the input parameters structure
                      - Tests if the kernel matrix is a constant one
                      - Initializes the images reading and writing
                      - Evaluates the steps of the moving window
                      - Switch WRT the kernel is constant or not
                            - Calls the Core Convolution function
                      - End switch
                      - Closes the reading and writing of the images

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_kernelfiltering
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_globalstatistic

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - ClassMin     : minimun class value for the 
                                              histogram
			     - ClassMax     : maximum class value for the
                                              histogram
                             - X            : vector of AOI X coordinates
                             - Y            : vector of AOI Y coordinates
                             OUTPUT:
                             - Mean         : mean value
			     - Sddv         : standard deviation value
			     - Cfvr         : coefficient of variation value
			     - Classes      : histogram class value

        $MODIFIED     NONE

        $OUTPUT       The Mean, Sddv, Cfvr variable and Classes histogram
                      vector

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the global statistic
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_globalstatistic
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_localmean

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - X            : vector of AOI X coordinates
                             - Y            : vector of AOI Y coordinates
                             - WSIZE        : vector of Window Size (X,Y)
                             - WSTEP        : vector of Window Steps (X,Y)
                             - FILL VAL     : filler value for pixel outsize AOI
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored


        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the local 
                      statistic (MEAN) of SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_localmean
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_localsddv

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             OUTPUT:

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the local 
                      statistic (SDDV) of SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_localsddv
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_localcfvr

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             OUTPUT:

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the local 
                      statistic (CFVR) of SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_localcfvr
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_first_pca           

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma1      : pointer to the first input image
                             - InpIma2      : pointer to the second input image
                             - X            : vector of AOI X coordinates
                             - Y            : vector of AOI Y coordinates
                             OUTPUT:
                             - OutIma1      : pointer to the first output image
                             - OutIma2      : pointer to the second output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the global statistic
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_first_pca
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_second_pca           

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma1      : pointer to the first input image
                             - InpIma2      : pointer to the second input image
                             - X            : vector of AOI X coordinates
                             - Y            : vector of AOI Y coordinates
                             OUTPUT:
                             - OutIma1      : pointer to the first output image
                             - OutIma2      : pointer to the second output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the global statistic
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_second_pca
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_speckle

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma1      : pointer to the first input image
                             - X            : vector of AOI X coordinates
                             - Y            : vector of AOI Y coordinates
                             OUTPUT:
                             - OutIma1      : pointer to the first output image
                             - OutIma2      : pointer to the second output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the global statistic
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_speckle
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_gainconv

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - MinPerc      : a value associated to the 
                                              starting level of the linear 
                                              conversion
                             - MaxPerc      : a value associated to the 
                                              ending level of the linear 
                                              conversion
                             - NoBlacks     : a value to be used as the 
                                              initial image levels outside
                                              the conversion
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored


        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the GAIN
                      CONVERTION of the SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_gainconv
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLGainGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the gain conversion task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLGainGetInputPar
                        (/*IN    */ IDL_VPTR             *val,
                         /*IN    */ INTx4                 npar,
                         /*IN    */ char                 *kw,
                         /*   OUT*/ STBXPT_gain_idl_par  *idl_par,
                         /*   OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLGainFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      gain conversion taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLGainFillAnno
                        (/*IN    */ UINTx1                imanum,
                         /*IN    */ STBXPT_gain_idl_par   idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_lutconv

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - UserLutFile  : a file name of a user-defined 
                                              look-up table
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored


        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the GAIN
                      CONVERTION of the SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_lutconv
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLLutGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the LUT gain conversion task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLLutGetInputPar
                        (/*IN    */ IDL_VPTR             *val,
                         /*IN    */ INTx4                 npar,
                         /*   OUT*/ STBXPT_lut_idl_par   *idl_par,
                         /*   OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLLutFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      LUT gain conversion taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLLutFillAnno
                        (/*IN    */ UINTx1                imanum,
                         /*IN    */ STBXPT_lut_idl_par    idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_sclconv

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - ScaleFact    : image scaling factor value
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored


        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the GAIN
                      CONVERTION of the SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT IDL_VPTR stbx_sclconv
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLSclGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the Scale factor gain conversion task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLSclGetInputPar
                        (/*IN    */ IDL_VPTR             *val,
                         /*IN    */ INTx4                 npar,
                         /*   OUT*/ STBXPT_scale_idl_par *idl_par,
                         /*   OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLSclFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      Scale factor gain conversion taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLSclFillAnno
                        (/*IN    */ UINTx1                imanum,
                         /*IN    */ STBXPT_scale_idl_par  idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_dump

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - OutFile      : Output Dump File Namevalue

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the DUMP
                      ANCILLARY ANNOTATION of the SAR Toolbox called by IDL. 
                      It must be called giving the input arguments explained 
                      in the INPUT field of this header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information

   $EH
   ========================================================================== */
   extern EXPORT void stbx_dump
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         stbx_help

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the help
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern EXPORT void stbx_help
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLOverGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the resampling tool

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLOverGetInputPar
                        (/*IN    */ INTx4                 npar,
                         /*IN    */ IDL_VPTR             *val,
                         /*IN    */ char                 *kw,
                         /*   OUT*/ STBXPT_over_idl_par  *idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLOverFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      oversampling taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLOverFillAnno
                        (/*IN    */ UINTx1               imanum,
                         /*IN    */ STBXPT_over_idl_par  idl_par,
                         /*IN OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLOverFillBpar

        $TYPE         PROCEDURE

        $INPUT        idl_par  : structure with the input variables of the task

        $MODIFIED     NONE

        $OUTPUT       inp_bpar : basic TIFF parameter structure for the input
                                 image
                      out_bpar : basic TIFF parameter structure for the output
                                 image

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      

        $DESCRIPTION  This procedure fills the basic parameter structures of
                      the input and the output images

        $WARNING      NONE

        $PDL          - Fills the input image basic parameters structure
                        using the input image info
                      - Fills the output image basic parameters structure
                        knowing the image type is always float or complex

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLOverFillBpar
                        (/*IN    */ STBXPT_over_idl_par  idl_par,
                         /*   OUT*/ TIFSIT_basicpar     *inp_bpar,
                         /*   OUT*/ TIFSIT_basicpar     *out_bpar,
                         /*IN OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLUnderGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_kernel_inv_dim
                      ERRSID_STBX_kernel_dim_high
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the resampling tool

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Gets the info about the input image
                      - Checks the number of rows and columns and the input
                        image data type
                      - Fills the descriptor of the input parameters with the
                        pointer to the input image reallocated
                      - Gets the info about the kernel matrix
                      - Checks the dimensions of the kernel
                      - If the kernel image type is not float
                            - Converts the kernel matrix into a float one
                      - Endif
                      - Fills the descriptor of the input parameters with the
                        pointer to the filter matrix reallocated
                      - Gets the info about the output image
                      - Checks the number of rows and columns and the output
                        image data type
                      - Fills the descriptor of the input parameters with the
                        pointer to the output image reallocated

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLUnderGetInputPar
                        (/*IN    */ INTx4                 npar,
                         /*IN    */ IDL_VPTR             *val,
                         /*IN    */ char                 *kw,
                         /*   OUT*/ STBXPT_under_idl_par *idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLGstaGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the global statistic task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLGstaGetInputPar
                        (/*IN    */ INTx4                 npar,
                         /*IN    */ IDL_VPTR             *val,
                         /*IN    */ char                 *kw,
                         /*   OUT*/ STBXPT_gsta_idl_par  *idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLGstaFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      oversampling taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLGstaFillAnno
                        (/*IN    */ UINTx1                imanum,
                         /*IN    */ STBXPT_gsta_idl_par   idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLLstaGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the local statistic task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLLstaGetInputPar
                        (/*IN    */ INTx4                 npar,
                         /*IN    */ IDL_VPTR             *val,
                         /*IN    */ char                 *kw,
                         /*   OUT*/ STBXPT_lsta_idl_par  *idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLLstaFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      oversampling taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLLstaFillAnno
                        (/*IN    */ UINTx1                imanum,
                         /*IN    */ STBXPT_lsta_idl_par   idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLLocalStatistic

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma       : pointer to the input image
                             - X            : vector of AOI X coordinates
                             - Y            : vector of AOI Y coordinates
                             - WSIZE        : vector of Window Size (X,Y)
                             - WSTEP        : vector of Window Steps (X,Y)
                             - FILL VAL     : filler value for pixel outsize AOI
                             OUTPUT:
                             - OutIma : pointer to the buffer in which the
                                        output image will be stored

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the global statistic
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern IDL_VPTR STBXPP_IDLI_IDLLocalStatistic
                        (/*IN    */ STATIT_image_type    imageType,
                         /*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*   OUT*/ char                *kw,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLPcaGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the pca task

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLPcaGetInputPar
                        (/*IN    */ IDL_VPTR             *val,
                         /*   OUT*/ STBXPT_pca_idl_par   *idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLPcaFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum1 : number identifing the first image in the tool
                      imanum2 : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structures describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum*] : the image annotation
                                                   structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      oversampling taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLPcaFillAnno
                        (/*IN    */ UINTx1                imanum1,
                         /*IN    */ UINTx1                imanum2,
                         /*IN    */ STBXPT_pca_idl_par    idl_par,
                         /*IN OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLPca

        $TYPE         PROCEDURE

        $INPUT        npar : number of parameters passed to the routine
                      val  : array of pointers to the passed parameters in
                             which the following parameters MUST be passed to
                             the procedure:
                             INPUT:
                             - InpIma1      : pointer to the first input image
                             - InpIma2      : pointer to the second input image
                             OUTPUT:
                             - OutIma[ 0 ]  : pointer to the first output image
                             - OutIma[ 1 ]  : pointer to the second output image

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the structure with the
                                                  annotations of the input image

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure is the main procedure for the global statistic
                      of SAR Toolbox called by IDL. It must be called giving
                      the input arguments explained in the INPUT field of this
                      header

        $WARNING      MAKE SURE TO HAVE THE SHAREABLE LIBRARY DEFINED IN THE
                      LINKIMAGE PROCEDURE

        $PDL          - Initializes the annotation structure
                      - Initializes the input parameters structure
                      - Checks the input parameters number
                      - Gets the input parameters information
                      - Fills the basic parameters structure

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLPca 
                        (/*IN    */ INTx4                npar,
                         /*IN OUT*/ IDL_VPTR            *val,
                         /*IN OUT*/ IDL_VPTR            *idl_out_ima,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLFillImage

        $TYPE         PROCEDURE

        $INPUT        ima_p     : pointer to the image sequentially allocated
                      data_type : image data type
                      nrows     : image number of rows
                      ncols     : image number of columns

        $MODIFIED     NONE

        $OUTPUT       image     : double pointer to the image to allocate

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_image_dim
                      ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure constructs a matrix image through a
                      pointers array pointing to the first elements of
                      each row of the input image sequentially allocated

        $WARNING      NONE

        $PDL          - Checks the input parameters
                      - Switch WRT the wanted image type
                            - Allocates the array of pointers to makes to
                              them to point to the input image rows
                            - Points the elements of the array to the image
                              rows
                      - End of switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLFillImage
                        (/*IN    */ void                *ima_p,
                         /*IN    */ LDEFIT_data_type     data_type,
                         /*IN    */ UINTx4               nrows,
                         /*IN    */ UINTx4               ncols,
                         /*   OUT*/ void              ***image,
                         /*IN OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLUnderCheckFilter

        $TYPE         PROCEDURE

        $INPUT        kernel : filtering kernel
                      Kr     : rows kernel dimension
                      Kc     : columns kernel dimension

        $MODIFIED     NONE

        $OUTPUT       flag   : flag to indicate if the kernel is constant
                               or not

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_kernel_inv_dim

        $DESCRIPTION  This procedure cheks if the kernel is constant or not

        $WARNING      NONE

        $PDL          - Checks the kernel dimensions
                      - Checks if the kernel is a constant

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLUnderCheckFilter
                        (/*IN    */ float              **Kern,
                         /*IN    */ UINTx4               Kr,
                         /*IN    */ UINTx4               Kc,
                         /*   OUT*/ LDEFIT_boolean      *const_kern,
                         /*IN OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLUnderFiltCopy

        $TYPE         PROCEDURE

        $INPUT        descr     : the descriptor of the kernel matrix

        $MODIFIED     kern_type : type of the filter matrix

        $OUTPUT       filter    : array of float type to store the kernel

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This procedure fills the float array with the kernel
                      contents

        $WARNING      NONE

        $PDL          -	If the kernel type is not float
                            - Converts it in float
                      - End if
                      - Else
                            - Copyes the filter
                      - End Else

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLUnderFiltCopy
                        (/*IN    */ IDL_VPTR              descr,
                         /*IN OUT*/ LDEFIT_data_type     *kern_type,
                         /*   OUT*/ float                *filter,
                         /*   OUT*/ ERRSIT_status        *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLSpckGetInputPar

        $TYPE         PROCEDURE

        $INPUT        val     : array of structures with the descriptors of
                                each input variable

        $MODIFIED     NONE

        $OUTPUT       idl_par : structure containing all the parameters that
                                must be extracted from the list of input
                                variables

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_inv_out_ima_type

        $DESCRIPTION  This procedure fills the structure with all the input
                      variables necessary to the resampling tool

        $WARNING      THE INPUT PARAMETERS MUST BE GIVEN IN THE EXACT ORDER

        $PDL          - Extracts from the input array of structures the info
                        about the input parameters
                      - Makes a check about each parameter

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLSpckGetInputPar
                        (/*IN    */ INTx4                      npar,
                         /*IN    */ IDL_VPTR                  *val,
                         /*IN    */ char                      *kw,
                         /*   OUT*/ STBXPT_speckle_idl_par    *idl_par,
                         /*IN OUT*/ ERRSIT_status             *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLSpeckleFillAnno

        $TYPE         PROCEDURE

        $INPUT        imanum  : number identifing the image in the tool
                      idl_par : input parameters descriptor

        $MODIFIED     NONE

        $OUTPUT       The global structure describing the image is filled

        $GLOBAL       IANNIV_ImageAnnot[imanum] : the image annotation
                                                  structure

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure fills the global structure describing the
                      image characteristics with the values necessary for the
                      speckle filtering taking them from the input parameters
                      descriptor

        $WARNING      NONE

        $PDL          - Fills the fields of the global structure IANNIV_* that
                        are necessary to the oversampling tool

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLSpeckleFillAnno
                        (/*IN    */ UINTx1                   imanum,
                         /*IN    */ STBXPT_speckle_idl_par   idl_par,
                         /*IN OUT*/ ERRSIT_status           *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetImage

        $TYPE         PROCEDURE

        $INPUT        descr     : descriptor of the IDL array

        $MODIFIED     NONE

        $OUTPUT       ima_p     : pointer to the image
                      nrows     : number of rows of the array
                      ncols     : number of columns of the array
                      data_type : type of the IDL array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_inv_inp_param

        $DESCRIPTION  This procedure extracts the dimensions and the data type
                      of an IDL 2-dimensional array

        $WARNING      NONE

        $PDL          - Checks the IDL object is an array
                      - Checks that the array dimensions are two
                      - Fills the image pointer to the first data element
                      - Fills rows and columns dimensions
                      - Fills the array type

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_GetImage
                        (/*IN    */ IDL_VPTR             descr,
                         /*   OUT*/ void               **ima_p,
                         /*   OUT*/ UINTx4              *nrows,
                         /*   OUT*/ UINTx4              *ncols,
                         /*   OUT*/ LDEFIT_data_type    *data_type,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetArray

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
                      out_type : flag to indicate which type of output array
                                 must be passed
        $MODIFIED     NONE

        $OUTPUT       n_elem   : number of array elements
                      array_p  : pointer to the array of parameters

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure extracts from an IDL object an array of
                      values

        $WARNING      NONE

        $PDL          - Checks if the array is a true array
                      - Checks the array dimension
                      - Fills the array elements
                      - Switches among the various data type
                            - Converts the array into the wanted array type
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_GetArray
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx1               out_type,
                         /*   OUT*/ UINTx4              *n_elem,
                         /*   OUT*/ void               **array_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetParValue

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
                      out_type : flag to indicate which type of output variable
                                 must be passed
        $MODIFIED     NONE

        $OUTPUT       value    : output parameter value

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure extract from the IDL descriptor of each
                      parameter it's value if it isn't an array

        $WARNING      NONE

        $PDL          - Checks that the variable is not an array
                      - Switch among the various possible output data type

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_GetParValue
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx1               out_type,
                         /*IN OUT*/ void                *value,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetString

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
        $MODIFIED     NONE

        $OUTPUT       value    : output parameter value

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure extract from the IDL descriptor of each
                      parameter it's string value

        $WARNING      value should be ALLOCATED

        $PDL          - Checks that the variable is not an array

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_GetString
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ char                *value,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetParAddress

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
                      out_type : flag to indicate which type of output variable
                                 must be passed
        $MODIFIED     NONE

        $OUTPUT       address  : output parameter address

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_par_type_not_all
                      ERRSID_STBX_par_flag_not_all

        $DESCRIPTION  This procedure extract from the IDL descriptor of each
                      parameter its address if it isn't an array

        $WARNING      NONE

        $PDL          - Checks that the variable is not an array
                      - Switch among the various possible output data type

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_GetParAddress
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx1               out_type,
                         /*IN OUT*/ void               **address,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_GetArrayAddress

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
                      out_type : flag to indicate which type of output array
                                 must be passed
        $MODIFIED     NONE

        $OUTPUT       n_elem   : number of array elements
                      array_p  : pointer to the array of parameters

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure extracts from an IDL object an array of
                      values

        $WARNING      NONE

        $PDL          - Checks if the array is a true array
                      - Checks the array dimension
                      - Set array_p to the address of the array

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_GetArrayAddress
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx1               out_type,
                         /*   OUT*/ UINTx4              *n_elem,
                         /*   OUT*/ void               **array_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_CreateArray

        $TYPE         PROCEDURE

        $INPUT        descr    : IDL structure describing the parameter
                                 properties
                      out_type : flag to indicate which type of output array
                                 must be passed
        $MODIFIED     NONE

        $OUTPUT       n_elem   : number of array elements
                      array_p  : pointer to the array of parameters

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure create an IDL array of values whose
                      data points to array_p

        $WARNING      NONE

        $PDL          - Create the array
                      - Set array_p to the address of the array

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_CreateArray
                        (/*IN    */ IDL_VPTR            *descr,
                         /*IN    */ LDEFIT_data_type     out_type,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ void               **array_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_CreateMatrix

        $TYPE         PROCEDURE

        $INPUT        descr       : IDL structure describing the parameter
                                    properties
                      out_type    : flag to indicate which type of output array
                                    must be passed
        $MODIFIED     NONE

        $OUTPUT       row_n_elem  : number of array row elements
                      col_n_elem  : number of array columns elements
                      array_p     : pointer to the array of parameters

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_arr_par
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_err_mem_alloc
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure create an IDL matrix of values whose
                      data points to array_p

        $WARNING      NONE

        $PDL          - Create the array
                      - Set array_p to the address of the array

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_CreateMatrix
                        (/*IN    */ IDL_VPTR            *descr,
                         /*IN    */ LDEFIT_data_type     out_type,
                         /*IN    */ UINTx4               row_n_elem,
                         /*IN    */ UINTx4               col_n_elem,
                         /*   OUT*/ void               **array_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2INTx2

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into an INTx2 one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to INTx2 if possible
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLVar2INTx2
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ INTx2               *var,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2INTx4

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into an INTx4 one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to INTx4 if possible
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLVar2INTx4
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ INTx4               *var,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2UINTx2

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into an UINTx2 one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to UINTx2 if possible
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLVar2UINTx2
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ UINTx2               *var,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2UINTx4

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into an UINTx4 one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to UINTx4 if possible
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLVar2UINTx4
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ UINTx4              *var,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2float

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into an float one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to float if possible
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLVar2float
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ float               *var,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLVar2double

        $TYPE         PROCEDURE

        $INPUT        descr : IDL variable descriptor

        $MODIFIED     NONE

        $OUTPUT       var   : output variable

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_undef_par_type
                      ERRSID_STBX_conv_not_allow
                      ERRSID_STBX_par_type_not_all

        $DESCRIPTION  This procedure convert an IDL variable into a double one

        $WARNING      NONE

        $PDL          - Switch WRT the variable type
                            - Casts the variable to double if possible
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLVar2double
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN OUT*/ double              *var,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2INTx2

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type INTx2

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLArray2INTx2
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ INTx2               *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2INTx4

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type INTx4

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLArray2INTx4
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ INTx4               *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2UINTx2

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type UINTx2

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLArray2UINTx2
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ UINTx2              *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2UINTx4

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type UINTx4

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLArray2UINTx4
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ UINTx4              *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2float

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type float

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLArray2float
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ float               *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         STBXPP_IDLI_IDLArray2double

        $TYPE         PROCEDURE

        $INPUT        descr  : array descriptor
                      n_elem : number of array elements

        $MODIFIED     NONE

        $OUTPUT       arr_p  : pointer to the output array

        $GLOBAL       NONE

        $RET_STATUS   ERRSID_STBX_n_elem_out_of_range
                      ERRSID_STBX_inv_inp_param
                      ERRSID_STBX_conv_not_allow

        $DESCRIPTION  This procedure copyes and converts an IDL array into an
                      array of type double

        $WARNING      NONE

        $PDL          - Checks the required number of elements
                      - Switch among the possible IDL type
                            - Copyes and converts the array elements
                      - End switch

   $EH
   ========================================================================== */
   extern void STBXPP_IDLI_IDLArray2double
                        (/*IN    */ IDL_VPTR             descr,
                         /*IN    */ UINTx4               n_elem,
                         /*   OUT*/ double              *arr_p,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STBXIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void STBXIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) STBXIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $MACRO HEADER

      $NAME         STBXPM_print_help_message
                    ( (*IN    *) help_code )

      $DESCRIPTION  This MACRO prints an help message and exit from the
                    procedure

   $EH   
   ========================================================================== */
#define STBXPM_print_help_messages ( help_code )                               \
{                                                                              \
   fprintf ( stdout, "%s", STBXPV_IDLI_help_message[ help_code ] );            \
   goto error_exit;							       \
}

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STBXIM_

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure... 

                    STBXIM_
                                ( (*IN    *) ,
                                  (*IN OUT*) )

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/* #define STBXIM_
*/

#endif
#endif /* __HAVEIDL__ */
