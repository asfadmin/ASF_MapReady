/* ==========================================================================
   $MODULE_HEADER

      $NAME              FIIS_PGLB

      $FUNCTION          global module.

      $ROUTINE           FIISPP_GETS_get_last_section

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       gg-mmm-aa     AD       Initial Release

   $EH
   ========================================================================== */

/* ==========================================================================
                        DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 

/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H
#include FIIS_INTF_H


#ifdef  FIIS_GLBL
#undef  GLOBAL
#define GLOBAL /* */
#endif
 
/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISPD_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*#define FIISPD_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISPE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum FIISPE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISPC_

      $DESCRIPTION  The FIISPC_

   $EH
   ========================================================================== */
/*   const FIISPC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISPT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct FIISPT_*_def { 

   typedef struct FIISPT_*_def FIISPT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         FIISPV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

   $NAME         FIISPP_GETS_get_last_section

   $DESCRIPTION  Finds the last section.

   $TYPE         PROCEDURE

   $INPUT        file_name  : name of the INI file

   $MODIFIED     NONE

   $OUTPUT       section    : last section of the INI file
                 founded    : flag that indicated if the last section has
                              been founded

   $GLOBAL       NONE

   $RET_STATUS   ERRSID_FIIS_err_bad_input
                 ERRSID_FIIS_err_open_file

   $WARNING      NONE

   $PDL
                 - Input check
                 - Search last section
                 - Search the tag

   $EH
   ========================================================================== */
   extern void FIISPP_GETS_get_last_section
                   ( /*IN    */ FILSIT_file_name         file_name,
                     /*   OUT*/ char                    *section,
                     /*   OUT*/ LDEFIT_boolean          *founded,
                     /*   OUT*/ ERRSIT_status           *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

   $NAME         FIISPP_PUTS_put_info

   $DESCRIPTION  Write the info on the specified file in ascii format.

   $TYPE         Procedure

   $INPUT

   $MODIFIED     NONE

   $OUTPUT       NONE.

   $GLOBAL       NONE

   $RET_STATUS   NONE

   $WARNING      NONE

   $EH
   ========================================================================== */
   extern void FIISIP_PUTS_put_info
                   ( /*IN    */ char           *file_name,
                     /*IN    */ char           *section,
                     /*IN    */ char           *tag,
                     /*IN    */ void           *buffer,
                     /*IN    */ FIISIT_tag_type tag_type,
                     /*   OUT*/ ERRSIT_status  *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME             FIISPF_GLBL_set_error;

      $FUNCTION         Return global error from the package error. On first
                        call the package message array is registered.

      $INPUT            local_staus_code    : local package status code.

      $MODIFIED         NONE

      $OUTPUT           Global status code.

      $GLOBAL           NONE

      $RET_STATUS       NONE

      $DESCRIPTION      Return global error from the package error. On first
                        call the package message array is registered.

      $WARNING          NONE


   ========================================================================== */
   extern INTx4 FIISPF_GLBL_set_error
                         ( /*IN    */ ERRSIT_status  local_staus_code );

/* ==========================================================================

   $ROUTINE_HEADER

   $NAME         FIISPP_GETS_get_last_section

   $DESCRIPTION  Finds the last section.

   $TYPE         Procedure

   $INPUT

   $MODIFIED     NONE

   $OUTPUT       NONE.

   $GLOBAL       NONE

   $RET_STATUS   NONE

   $WARNING      NONE

   $EH
   ========================================================================== */
   extern void FIISPP_GETS_get_last_section
                   ( /*IN    */ char            *file_name,
                     /*   OUT*/ char            *section,
                     /*   OUT*/ LDEFIT_boolean  *founded,
                     /*   OUT*/ ERRSIT_status   *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FIISPP_

      $DESCRIPTION  

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/*   extern void FIISPP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FIISPP_PDMP_var_type

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      The variable name must be already inserted in var_string.

   $EH
   ========================================================================== */
/*   extern void FIISPP_PDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) FIISIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/
/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         STC

      $TYPE         MACRO

      $INPUT        status_code

      $MODIFIED     NONE

      $OUTPUT       Global error code

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure...

                    STC( (*IN    *)ERRSIT_status  status_code );

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
#define STC( status_code ) ( FIISPF_GLBL_set_error(status_code) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         FIISIM_

      $DESCRIPTION  This procedure

                    FIISIM_
                                ( (*IN    *) ,
                                  (*   OUT*) )

      $TYPE         MACRO

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $WARNING      NONE

   $EH
   ========================================================================== */
/* #define FIISPM_
*/
