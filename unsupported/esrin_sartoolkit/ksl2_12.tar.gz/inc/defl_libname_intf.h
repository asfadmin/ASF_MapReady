#ifndef LIBNAME
#define LIBNAME LIBNAME

/* ==========================================================================
   DEFINE INTERFACE MODULE LOGICAL NAMES FOR LOW LEVEL LIBRARIES
   ========================================================================== */
#define PORT_DEFS_H "port_defs.h"

#define ERRS_INTF_H "errs_intf.h"
#define ERRS_PGLB_H "errs_pglb.h"

#define MEMS_INTF_H "mems_intf.h"
#define MEMS_PGLB_H "mems_pglb.h"

#define LDEF_INTF_H "ldef_intf.h"
#define LDEF_PGLB_H "ldef_pglb.h"

#define MATH_INTF_H "math_intf.h"
#define MATH_PGLB_H "math_pglb.h"
#define MATH_NREC_H "math_nrec.h"

#define FILS_INTF_H "fils_intf.h"
#define FILS_PGLB_H "fils_pglb.h"

#define BUFS_INTF_H "bufs_intf.h"
#define BUFS_PGLB_H "bufs_pglb.h"

#define DEVS_INTF_H "devs_intf.h"
#define DEVS_PGLB_H "devs_pglb.h"

#define FIIS_INTF_H "fiis_intf.h"
#define FIIS_PGLB_H "fiis_pglb.h"

#define TIFS_INTF_H "tifs_intf.h"
#define TIFS_PGLB_H "tifs_pglb.h"

#define GIOS_INTF_H "gios_intf.h"
#define GIOS_PGLB_H "gios_pglb.h"

#define SRVS_INTF_H "srvs_intf.h"
#define SRVS_PGLB_H "srvs_pglb.h"

#define COOR_INTF_H "coor_intf.h"
#define COOR_PGLB_H "coor_pglb.h"

#define STAT_INTF_H "stat_intf.h"
#define STAT_PGLB_H "stat_pglb.h"

#define CONV_INTF_H "conv_intf.h"
#define CONV_PGLB_H "conv_pglb.h"

#define SPKF_INTF_H "spkf_intf.h"
#define SPKF_PGLB_H "spkf_pglb.h"

#define IANN_INTF_H "iann_intf.h"
#define IANN_PGLB_H "iann_pglb.h"
#define IANN_TAGS_H "iann_tags.h"

#define IRES_INTF_H "ires_intf.h"
#define IRES_PGLB_H "ires_pglb.h"

#define PMDS_INTF_H "pmds_intf.h"
#define PMDS_PGLB_H "pmds_pglb.h"

#define EXTR_INTF_H "extr_intf.h"
#define EXTR_PGLB_H "extr_pglb.h"

#define OVLS_INTF_H "ovls_intf.h"
#define OVLS_PGLB_H "ovls_pglb.h"

#define TEST_INTF_H "test_intf.h"
#define TEST_PGLB_H "test_pglb.h"

#define IDLI_INTF_H "export.h"

#define CEOS_INTF_H "ceos_intf.h"
#define CEOS_PGLB_H "ceos_pglb.h"

#define IREG_INTF_H "ireg_intf.h"
#define IREG_PGLB_H "ireg_pglb.h"

#define ICAL_INTF_H "ical_intf.h"
#define ICAL_PGLB_H "ical_pglb.h"

/* ==========================================================================
   DEFINE INTERFACE MODULE LOGICAL NAMES FOR MAIN PROCESSES
   ========================================================================== */
#define STBX_INTF_H "stbx_intf.h"
#define STBX_PGLB_H "stbx_pglb.h"
#define STBX_IDLI_H "stbx_idli.h"

#endif
