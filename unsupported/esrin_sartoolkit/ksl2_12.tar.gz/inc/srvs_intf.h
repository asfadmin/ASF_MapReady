/* ==========================================================================
   $MODULE_HEADER

      $NAME              SRVS_INTF

      $FUNCTION          SERVICE interface module.

      $ROUTINE           SRVSIP_avail_memory
                         SRVSIP_trace_comp

      $HISTORY

            PR           DATE    INITIALS    DESCRIPTION
   --------------------------------------------------------------------------
            N/A       28-AUG-97     AG       Initial Release

   $EH
   ========================================================================== */
/* ==========================================================================
                          DIRECTIVE DECLARATION SECTION
   ========================================================================== */

#ifndef SRVS
#define SRVS SRVS


#ifdef GLOBAL
#undef GLOBAL
#endif
#define GLOBAL  extern
 
/* ==========================================================================
                        INCLUDE DECLARATION SECTION
   ========================================================================== */

#include "defl_libname_intf.h"

#include ERRS_INTF_H
#include LDEF_INTF_H

#ifdef SRVS_GLBL
#undef GLOBAL
#define GLOBAL /* */
#endif

/* ==========================================================================
                        DEFINE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSID_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/* #define SRVSID_
*/
/* ==========================================================================
                        ENUMERATED DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSIE_

      $DESCRIPTION  

   $EH
   ========================================================================== */
/*   enum SRVSIE_
*/
/* ==========================================================================
                        CONSTANT DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSIC_

      $DESCRIPTION  The SRVSIC_

   $EH
   ========================================================================== */
/*   const SRVSIC_   = ;
*/
/* ==========================================================================
                        TYPE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSIT_

      $DESCRIPTION  

      $CONTENTS

           FIELD                            DESCRIPTION
          ----------------------------     ----------------------------------

   $EH
   ========================================================================== */
/*   struct SRVSIT_*_def { 

   typedef struct SRVSIT_*_def SRVSIT_*
*/

/* ==========================================================================
                        VARIABLE DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================
   $DECLARATION_HEADER

      $NAME         SRVSIV_

      $DESCRIPTION  

   $EH
   ========================================================================== */

/* ==========================================================================
                      ROUTINES DECLARATION SECTION
   ========================================================================== */

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SRVSIP_avail_memory

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       avail_memsiz  :  amount of available memory

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This function returns the amount of available memory
                      in Kb as a user setting minus the size allocated via
                      MEMSIP_alloc

        $WARNING      NONE

        $PDL

   $EH
   ========================================================================== */
   extern void SRVSIP_avail_memory
                        (/*   OUT*/ UINTx4              *avail_memsize,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SRVSIP_trace_comp

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This function is used to give a glance of the computation
                      running

        $WARNING      NONE

        $PDL          - If the modulus of sum for const is zero prints a point
                      - Flush the buffer

   $EH
   ========================================================================== */
   extern void SRVSIP_trace_comp
                        (/*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================

   $ROUTINE_HEADER

        $NAME         SRVSIP_set_comp

        $TYPE         PROCEDURE

        $INPUT        NONE

        $MODIFIED     NONE

        $OUTPUT       NONE

        $GLOBAL       NONE

        $RET_STATUS   NONE

        $DESCRIPTION  This function is used to set the target value of 
                      computation

        $WARNING      NONE

        $PDL          NONE

   $EH
   ========================================================================== */
   extern void SRVSIP_set_comp 
                        (/*IN    */ INTx4                target_value,
                         /*   OUT*/ ERRSIT_status       *status_code );

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SRVSIP_

      $TYPE

      $INPUT        NONE

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure 

      $WARNING      NONE

      $PDL

   $EH
   ========================================================================== */
/*   extern void SRVSIP_
*/
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SRVSIP_IDMP_var_type 

      $TYPE         PROCEDURE

      $INPUT        var_string                : variable name
                    variable                  : Variable to dump
                    ind                       : Indentation level

      $MODIFIED     NONE

      $OUTPUT       NONE

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure dumps the input variable in the format:
                        variable name : variable value.

      $WARNING      The variable name must be already inserted in var_string.

      $PDL

   $EH
   ========================================================================== */
/*   extern void SRVSIP_IDMP_var_type
                       ( (*IN    *) char             *var_string,
                         (*IN    *) SRVSIT_var_type   variable,
                         (*IN    *) INTx4             ind );
*/

/* ==========================================================================
                          MACRO DECLARATION SECTION
   ========================================================================== */
/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SRVSIM_step

      $TYPE         MACRO

      $INPUT        ninp : number of input
                    k    : size of kernel
                    nout : number of output

      $MODIFIED     NONE

      $OUTPUT       step : step of moving window

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure is used to find out the step of a moving window

      $WARNING      NONE

   $EH
   ========================================================================== */
#define SRVSIM_step(ninp, k, nout) \
( ((double)(ninp - k))/((double)(nout-1)) )

/* ==========================================================================
   $ROUTINE_HEADER

      $NAME         SRVSIM_out

      $TYPE         MACRO

      $INPUT        ninp : number of input
                    k    : size of kernel
                    step : step of moving window

      $MODIFIED     NONE

      $OUTPUT       nout : number of output

      $GLOBAL       NONE

      $RET_STATUS   NONE

      $DESCRIPTION  This procedure is used to find out the output given the
                    step of a moving window of size k on a image of size
                    ninp

      $WARNING      NONE

   $EH
   ========================================================================== */
#define SRVSIM_out(ninp, k, step) \
(((UINTx4) ((double)(ninp - k))/((double) step)) + 1)

/* ==========================================================================
                        ERROR CODE DECLARATION SECTION
   ========================================================================== */
/* Generic error. Must be setted if used without ERRS package */

#ifndef ERRS
#define ERRSID_normal                    0
#define ERRSID_error                     1
#endif

#define ERRSID_SRVS_err_mem_alloc        2
#define ERRSID_SRVS_uncomput_mem_avail   3
#define ERRSID_SRVS_not_mem_avail        4

/* ==========================================================================
                        ERROR MESSAGE DECLARATION SECTION
   ========================================================================== */

#ifdef SRVS_GLBL
   GLOBAL char *SRVSIV_ERRS_error_message[] = 
                        { "No error happens",
                          "Generic error happens",
                          "SYSTEM ERROR: memory allocation error",
			  "Available memory cannot be computed",
                          "Not enough memory available"
                        };
#else
   GLOBAL char *SRVSIV_ERRS_error_message[];
#endif


#endif
