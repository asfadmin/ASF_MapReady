function message {
  echo ${0##*/} $* >> log1
  echo ${0##*/} $*
}

function math {
  typeset math_return #Make the variable local
  math_return=`echo 1 | gawk "{printf(\"%-20.20g\",$*)}" `
  echo $math_return
}

function norm {
  a=${1:-0}
  b=${2:-0}
  c=${3:-0}
  math "sqrt(($a)*($a)+($b)*($b)+($c)*($c))"
}


function check_writable {
  typeset status file 
  status=0
  for file in $*
  do 
    if [ -e "$file" ]; then 
      if ! [ -w "$file" ] ; then
        message "$file is not writable" ; status=1 
      fi
    else 
      if ! [ touch $file ]; then
        message "cannot create $file" ; status=1
        fi
      rm $file
    fi
  done
  return $status
}

function check_readable {
  typeset status file 
  status=0
  for file in $*
  do if ! [ -r "$file" ]; then 
       if ! [ -e "$file" ] 
         then message "$file does not exist" ; status=1 
         else message "$file cannot be read" ; status=1 
       fi
     fi
  done
  return $status
}

function no_newer_input {
  typeset InF OutF
  for InF in $InputFiles; do
    for OutF in $OutputFiles; do
      if ( ! [ -e $OutF ] ) || [ $OutF -ot $InF ]; then
        message $InF newer than $OutF
        return 1
      fi
    done
  done
return 0
}

function io_check {
  if no_newer_input ; then
    message "already done"
    exit 0
  fi
  if ! check_readable $InputFiles ; then
    echo no input_file EXITING
    ls -l $InputFiles
    exit 1
  fi
  if ! check_writable $OutputFiles ; then
    echo cannot write to output EXITING
    ls -l $OutputFiles
    exit 1
  fi
}


function log {
echo `date +%Y%m%d:%H%M%S` "*" $* >> log
}

function link_here {
  typeset file name dir
  for file in $*; do
    name=${file##*/}
    dir=${file%/*}

    if [ -e "$name" ]  ; then
      echo $file already exists, assuming ok
    fi

    if ! [ -e "$name" ]  ; then
      ln -fs $dir/$name $name
    fi

  done
}





    
