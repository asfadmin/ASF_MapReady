void underscore()
{
  printf("*************************************************************\n") ;
  printf("* Your Fortran compiler adds no underscore to routine names *\n") ;
  printf("*************************************************************\n") ;
}
void underscore_()
{
  printf("****************************************************************\n") ;
  printf("* Your Fortran compiler appends an underscore to routine names *\n") ;
  printf("****************************************************************\n") ;
  printf("-DUNDERSCOREAFTER\n") ;
}
void _underscore()
{
  printf("*****************************************************************\n") ;
  printf("* Your Fortran compiler prepends an underscore to routine names *\n") ;
  printf("*****************************************************************\n") ;
  printf("-DUNDERSCOREBEFORE\n") ;
}
