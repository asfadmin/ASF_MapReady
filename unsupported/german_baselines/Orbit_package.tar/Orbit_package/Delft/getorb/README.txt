                           GETORB 2.0.5 -- README

----------------------------------------------------------------------------

This README file pertains to the distribution of getorb_2.0.x.tar.gz. Read
this file carefully before installing or using the different components.

Last modification: Tue 17 Feb 1997

----------------------------------------------------------------------------

Contents

   * Introduction
   * What's new
   * Installation
   * Delft Orbits
   * Listing ODRs with lodr
   * Interpolating orbits with getorb.a and getorb
   * More Information

----------------------------------------------------------------------------

Introduction

This is the latest release of the software supporting the Delft ERS orbits.
The software consists of a program lodr to list the content of the Orbital
Data Records (ODRs), a subroutine library getorb.a that can be ported to
some other program to interpolate the orbits and any given moment, and an
example program getorb to demonstrate the use of the getorb.a library.

The FORTRAN source code works on nearly all Unix workstations, including
Little Endian machines such as DEC workstations (running Ultrix) and PCs
(running Linux), as well as Big Endian machines: IBM RS6000, Convex, Mac,
HP.

----------------------------------------------------------------------------

What's new ?

New in Version 2.0 is the use of a new format for the ODRs. Because of the
demand from the InSAR community to have a more accurate cross-track
resolution, the latitude and longitude coordinates are now in 10^-7 degrees
(0.1 microdegree). This also meant changing the interval for the longitudes
from 0/360 to -180/+180 degrees. Obviously, the new subroutine handles both
the old (1.0 microdegrees) and new resolution data sets.

A couple of additional enhancements have been made to reduce the number of
code lines and to prepare the software for future satellites ENVISAT and
Jason.

Those who have been using former versions of the getorb.a library are
recommended to use the new one. It avoids problems when switching to the
enhanced resolution data sets in the near future.

With Version 2.0 all previous versions expired.

Additional changes after the release of Version 2.0 are:

2.0.1 (2 Dec 1996)
     Change in getorb.F to close the arc properly in case arcs are missing
     or when last arc is loaded.
2.0.2 (6 Dec 1996)
     Error in supplementory files caused test not to succeed. New test
     results included. More standard settings in Makefile. This is no
     relvance to the software itself.
2.0.3 (8 Dec 1996)
     Archive supplied with new orbit file; the same as in opr2gdr. This is
     no relevance to the software itself.
2.0.4 (16 Jan 1997)
     Minor modification to getorb.F not affecting Delft ODRs.
2.0.6 (25 Feb 1997)
     Modification to getorb_main.F such that it also gives XYZ as output.
     Has no effect on the subroutines.

----------------------------------------------------------------------------

Installation

There are only a couple considerations for making the programs work
properly:

   * The programs use low-level C I/O. For simplicity the Fortran/C
     interface in file fastio.c simply passes parameters for opening files
     directly from the Fortran program to the C routines. The o_flag
     parameter for opening files can differ between machines, but we now use
     routine ioconst in fastio.c to return the proper read/write flags for
     your system. The Makefile tells the C-compiler to check in /usr/include
     for the file fcntl.h which contains the necessary I/O constants. If for
     some reason your fcntl.h file is not in this location, you can modify
     the Makefile's CFLAGS to check the proper include directories.
   * Since version 2.0 two system dependencies are hardwired into the source
     code. The representation of integers (Big or Little Endian) is checked
     by a little program syscheck before the rest of the code is compiled.
     Also, it checks whether your compiler expects underscores prepended or
     appended to the Fortran function or routine names when accessed by C.
     So you won't need to worry about your system specifics for this issue.
   * Finally you might like to make some changes to the Makefile regarding
     your preferred location of the executables (currently set to
     /usr/local/bin). Consult the Makefile for more information on system
     dependencies and values that you should change or set manually.

Once any changes have been made to the makefile, you should be able to
compile the library and the two programs via make all or simply make.

After you make the program, you can make test to check that the outputs
agree with reference files included in the tar archive. It runs the programs
lodr and getorb and compares the resulting output files with included
references.

Finally, once you've successfully tested the program you can make install to
place the executables in /usr/local/bin (or wherever you like if you modify
the BIN_DIR parameter in the Makefile); and then make clean to remove the
relocatable files.

----------------------------------------------------------------------------

Delft Orbits

Delft ERS-1 orbits are generally available through the anonymous FTP site at
NOAA: ftp://harpo.grdl.noaa.gov/pub/delft/ODR.ERS-1. Various subdirectories
relate to the different orbit determination versions (different gravity
models or tracking data). Recently also ERS-2 orbits are added on the same
site: ftp://harpo.grdl.noaa.gov/pub/delft/ODR.ERS-2.

These directories contain the Orbital Data Records (ODRs) spanning each
5.5-days with a 2-day overlap with consecutive ODRs. The binary format of
the ODRs (and some more information) is given in the file docs/odr_fmt.txt.
To list the contents of the ODRs use the program lodr.

For the most up-to-date information of the status of the ERS-1 and ERS-2
orbit determination and details consult the DUT/DEOS Web page with the URL:

http://dutlru8.lr.tudelft.nl/ers/precorbs/

Orbit files can also be accessed through this page.

Store all the ODR files (at least for your required period) in one directory
together with the list of ODR files arclist. The name of this directory is
one of the input variables for the orbit interpolation routine.

----------------------------------------------------------------------------

Listing ODRs with lodr

The program lodr lists the contents of an ODR. The syntax is:

        lodr [-s n=n0,n1 t=t0,t1] ODR-filename

where

-s
     Print a summary only
n=n0,n1
     Request listing of record numbers n0 through n1 only
t=t0,t1
     Requests listing of records of period t0 through t1 only, where t0 and
     t1 may be in YYMMDD.D, YYDDD.D, MJD.D, YYMMDDHHMMSS.S, SEC85
ODR-filename
     Name of the input ODR file.

This program is included in the getorb package and is made with make lodr,
but also with make all or just make. When executing the tests (make test)
the proper functioning of lodr is checked as well.

----------------------------------------------------------------------------

Interpolating orbits with getorb.a and getorb

The program getorb is a little quick'n'dirty front-end to the getorb library
getorb.a. The program allows you to interpolate the DUT orbit at any
required epoch (during the span of the data files). The program prints out
time, error value, latitude, longitude, orbital altitude, and XYZ. The
syntax:

        getorb epoch dir

where:

epoch
     epoch for the orbit interpolation in almost any format: YYMMDD.D,
     YYDDD.D, MJD.D, YYMMDDHHMMSS.S, SEC85
dir
     name of the directory in which the ODR files are stored

The getorb.a library contains all subroutines used by the getorb program.
See the file getorb.F for a detailed information of the use of this routine.

----------------------------------------------------------------------------

More Information

For more up-to-date information on this package and the DUT orbits, netsurf
to http://dutlru8.lr.tudelft.nl/ers/precorbs/ or contact: Remko Scharroo
(remko.scharroo@lr.tudelft.nl)

----------------------------------------------------------------------------

 [DEOS]  This was brought to you by Remko Scharroo,
         remko.scharroo@lr.tudelft.nl
