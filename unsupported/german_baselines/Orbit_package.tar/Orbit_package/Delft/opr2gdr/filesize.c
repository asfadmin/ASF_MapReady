#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

/*  filesize -- returns the size, in bytes, of input filename
    Returns -1 if any error occurs in determining the filesize.
    This routine is callable from FORTRAN: 

	integer filesize, size
	character*256 str

        (... initialize str )

	size = filesize(str)

                                   Ed Timmerman 7/19/91
*/

long filesize_(fname,slen)
char *fname;
int slen;

{
  long filesize();
  return (filesize(fname,slen));
}


long filesize(fname,slen)
char *fname;
int slen;
{
  struct stat s,*sbuf = &s;             /* For stat system call */
  long SizeOfFile;                      /* Returned size of file */
  char temp[256];                       /* Scratch string...could malloc() */
  int  len = slen - 1;                  /* String length variable */

  strncpy(temp,fname,slen);             /* Use copy of F77 string */

/* Strip off trailing blanks. */

  while (temp[len] == ' ' && len >= 0)
       len--;

  temp[len+1] = '\0';                  /* Null terminate string for C call */

  if (stat(temp,sbuf) != 0) {
    fprintf(stderr,"Can't stat file %s\n",temp);
    SizeOfFile = -1;
  }
  else
    SizeOfFile = sbuf->st_size;

  return SizeOfFile;
}
