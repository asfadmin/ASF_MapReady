/* defines the sizes of the four datatypes */
extern int datasize[];
