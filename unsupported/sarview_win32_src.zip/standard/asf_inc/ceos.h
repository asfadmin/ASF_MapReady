/********************************************************************
NAME:               CEOS.H

PURPOSE:  Include file defining structure for CEOS file header/trailer/
	  data record contents.

PROGRAM HISTORY:
VERSION         DATE   AUTHOR
-------         ----   ------
  1.0           5/92   R. Guritz (ASF)
  1.1           9/93   T. Logan (ASF)   Added Imagery option file
					file descriptor record
  1.2		10/93  T. Logan (ASF)   Added Radiometric Data Record
  1.3		02/94  M. Shindle <ASF> Added Map Projection Data Record
  2.0		5/96   T. Logan (ASF)   Added all the rest of the record types
					Modified existing value structures to 
					include string values
  3.0		9/96   T. Logan (ASF)   Added all fields for post Radarsat CEOS
					structures
  3.1		11/97  T. Logan (ASF)   Made all records consistent with hdrs.
  
*********************************************************************/
#ifndef __CEOS_H

#define __CEOS_H	/* include ceos.h only once */

#include	<stdio.h>


/*** MODES *****/
#define CEOS_SIC     0
#define CEOS_FUL     1
#define CEOS_LOW     2
#define CEOS_CCSD    3

/*** RECORD TYPES ***/
#define IOFDR   10003		/* Imagery Option File Descriptor 	*/
#define LFDR	10004		/* Leader File Descriptor		*/
#define DSSR	10005		/* Data Set Summary 			*/
#define MPDR	10006		/* Map Projection Data			*/
#define PPDR    10007		/* Platform Position Data		*/
#define ATDR    10008		/* Attitude Data			*/
#define RADR	10009		/* Radiometric Data 			*/
#define DQSR    10010		/* Data Quality Summary 		*/
#define SDHR    10011		/* Signal Data Histogram Record		*/
#define PDHR    10012		/* Processed Data Histogram		*/
#define RNSR	10013		/* Range Spectra Record			*/
#define DEMR	10014		/* Digital Elevation Model	 	*/	
#define FACDR	10015		/* Facility Data Record			*/

/*** RECORD SIZES ***/
#define H_SZ    12
#define R_SZ    180
#define FDR_SZ  720


#define SIC_AVG 32768.0

struct IMG_STATS {
int   nbins;
float min_val; float max_val; float mean_val; float std_dev_val;
float min_tbl; float max_tbl; float mean_tbl; float std_dev_tbl;
int  tbl[32];
};

/* appears at the beginning of each record in all ASF files */
struct  HEADER {
        unsigned char   recnum[4];/*1 BIG-ENDIAN Int.*/
        unsigned char   rectyp[4];
        unsigned char   recsiz[4];/*1 BIG-ENDIAN Int.*/
};

/* appears at the beginning of each Radarsat Era Data Record */
struct RHEADER {
  int           line_num,
                rec_num,
                n_left_pixel,
                n_data_pixel,
                n_right_pixel,
                sensor_updf,
                acq_year,
                acq_day,
                acq_msec;
  short int     sar_cib,
                sar_chan_code,
                tran_polar,
                recv_polar;
  float         prf_bin,
                spare_1,
                sr_first,
                sr_mid,
                sr_last,
                fdc_first,
                fdc_mid,
                fdc_last,
                ka_first,
                ka_mid,
                ka_last,
                nadir_ang,
                squint_ang,
                null_f;
  int           spare_2_1,
                spare_2_2,
                spare_2_3,
                spare_2_4,
                geo_updf,
                lat_first,
                lat_mid,
                lat_last,
                long_first,
                long_mid,
                long_last,
                north_first,
                spare_3,
                north_last,
                east_first,
                spare_4,
                east_last,
                heading;
  double        spare_5;
};


/* Radiometric Data Record */
struct RADDR {
 char     seqnum[4],    /* Radiometric Data Record Sequence Number */
          datfield[4],  /* Number of radiometric data fields in this rec */
          setsize[8],   /* Radiometric data set size in bytes */
          sarchan[4],   /* SAR channel indicator */
          spare[4],
          luttype[24],  /* Look Up Table Designator */
          nosample[8],  /* Number of samples in LUT */
          samptype[16], /* Sample Type Designator */
          a[3][16],     /* Calibration coefficients */
          spare2[4],
          noise[512][16]; /* noise values */
};

/* Values for the Radiometric Data Record */
struct VRADDR {
   short  seqnum;       /* Radiometric Data Record Sequence Number */
   short  datfield;     /* Number of radiometric data fields in this rec */
   int   setsize;      /* Radiometric data set size in bytes */
   char   sarchan[5];   /* SAR channel indicator */
   char   spare[5]; 
   char   luttype[25];  /* Look Up Table Designator */
   int   nosample;     /* Number of samples in LUT */
   char   samptype[17]; /* Sample Type Designator */
   double a[3];         /* Calibration Coefficients */
   char   spare2[5]; 
   double noise[256];   /* noise values */
};

/* Imagery Options File -- File Descriptor Record */
struct IOF_FDR {
   char   ascii_flag[2],
	  spare1[2],
	  format_doc[12],
	  format_rev[2],
	  design_rev[2],
	  software_id[12],
	  file_num[4],
	  product_id[16],
	  rec_seq_flag[4],
	  seq_loc[8],
	  seq_len[4],
	  rec_code[4],
	  code_loc[8],
	  code_len[4],
	  rec_len[4],
	  rlen_loc[8],
	  rlen_len[4],
	  spare2[4],
	  spare3[64],
	  
	  numofrec[6],	/* data records */
	  reclen[6],	/* Record Length */
	  blanks[24],	/* Reserved -- Blanks */
	  
	  /* sample group data */
	  bitssamp[4],  /* bits per sample */
	  sampdata[4],  /* samples per data group */
	  bytgroup[4],  /* bytes per group */
          justific[4],  /* Justification and order of samples in data group */
	  
	  /* SAR related data in the record */
          sarchan[4],	/* SAR channels in this file */
	  linedata[8],  /* lines per data set */
	  lbrdrpxl[4],  /* left border pixels per line */
	  datgroup[8],  /* Total number of data groups */
          rbrdrpxl[4],  /* right border pixels per line */
  	  topbrdr[4],   /* top border lines */
	  botbrdr[4],	/* bottom border lines */
	  interlv[4],   /* Interleave Indicator */

	  /* Record Data in the file */
	  recline[2],	/* physical records per line */
	  mrecline[2],  /* physical records per multi channel line */
	  predata[4],   /* bytes of prefix data per record */
	  sardata[8],  	/* bytes of sar data per record */
	  sufdata[4],   /* bytes of suffix data per record */
	  repflag[4],   /* prefix/suffix repeat flag */

     	  /* Prefix/Suffix Data Locators */
	  DataLoc[104], /* I don't know what this stuff is for */

  	  /* SAR Data Pixel Description */
	  formatid[28], /* SAR data format identifier */
	  formcode[4],  /* SAR data format type code */
	  leftfill[4],  /* Left fill bits per pixel */
          rigtfill[4],  /* Right fill bits per pixel */
	  maxidata[8],  /* Maximum data range of pixel */

	  padding[588];          
};

/* Imagery Option File -- Values in File Descriptor Record */
struct IOF_VFDR {
   char   ascii_flag[2],
          spare1[2],
          format_doc[12],
          format_rev[2],
          design_rev[2],
          software_id[12];
   int    file_num;
   char   product_id[16],
          rec_seq_flag[4];
   int    seq_loc,
          seq_len;
   char   rec_code[4];
   int    code_loc,
          code_len;
   char   rec_len[4];
   int    rlen_loc,
          rlen_len;
   char   spare2[4],
          spare3[64];
   int	  numofrec,  	/* data records 			*/
          reclen,    	/* Record Length 			*/
          bitssamp,  	/* bits per sample 			*/
          sampdata,  	/* samples per data group 		*/
          bytgroup;  	/* bytes per group 			*/
   char   justific[5];  /* Justification and order of samples in data group */
   int    sarchan,   	/* SAR channels in this file 		*/
          linedata,  	/* lines per data set 			*/
          lbrdrpxl,  	/* left border pixels per line 		*/
          datgroup,  	/* Total number of data groups 		*/
          rbrdrpxl,  	/* right border pixels per line 	*/
          topbrdr,   	/* top border lines 			*/
          botbrdr;   	/* bottom border lines 			*/
   char   interlv[5];   /* Interleave Indicator 		*/
   int    recline,   	/* physical records per line 		*/
          mrecline,  	/* physical recs per multi-channel line */
          predata,   	/* bytes of prefix data per record 	*/
          sardata,   	/* bytes of sar data per record 	*/
          sufdata;   	/* bytes of suffix data per record 	*/
   char   repflag[5],   /* prefix/suffix repeat flag 		*/
          formatid[29], /* SAR data format identifier 		*/
          formcode[5];  /* SAR data format type code 		*/
   int    leftfill,  	/* Left fill bits per pixel 		*/
          rigtfill,  	/* Right fill bits per pixel 		*/
          maxidata;  	/* Maximum data range of pixel 		*/
};

/*********************************************
*   SAR Leader File: File Descriptor Record  *
*********************************************/
struct FDR {
   char   ascii_flag[2],
          spare1[2],
          format_doc[12],
          format_rev[2],
          design_rev[2],
          software_id[12];
   int    file_num;
   char   product_id[16],
          rec_seq_flag[4];
   int    seq_loc,
          seq_len;
   char   rec_code[4];
   int    code_loc,
          code_len;
   char   rec_len[4];
   int    rlen_loc,
          rlen_len;
   char   spare2[4],
          spare3[64];
   int    n_dssr,
	  l_dssr,
	  n_mpdr,
	  l_mpdr,
	  n_ppdr,
	  l_ppdr,
	  n_atdr,
	  l_atdr,
	  n_raddr,
	  l_raddr,
	  n_rcr,
	  l_rcr,
	  n_qsr,
	  l_qsr,
	  n_dhr,
	  l_dhr,
	  n_rsr,
  	  l_rsr,
	  n_demdr,
	  l_demdr,
 	  n_rpr,
	  l_rpr,
	  n_adr,
	  l_adr,
	  n_dpr,
	  l_dpr,
	  n_calr,
	  l_calr,
	  n_gcp,
	  l_gcp,
	  spare4[10],
	  n_facdr,
	  l_facdr;
    char  spare5[288];
};

/*Facility Related Data Record.*/

struct VFDRECV {
   short  seq_num;
   char   spare_frd_1[5];
   char   dataid[15],   /* Data take id */
          imageid[12],  /* SPS image identifier */
          coryear[6],   /* UTC year of image correlation */
          cortime[18],  /* UTC time of image correlation */
          sitename[34], /* Name of site covered */
          imgyear[6],   /* UTC year at the image center */
          imgtime[18];  /* UTC time at the image center */
   double imgclat,  /* Latitude of the image center (F16.7) in degrees */
          imgclon,  /* Longitude of the image center (F16.7) in degrees */
          nearslat, /* Lat at start of image frame in the near swath (F16.7) */
          nearslon, /* Long at start of image frame in the near swath (F16.7)*/
          nearelat, /* Lat at end of image frame in the near swath (F16.7) */
          nearelon, /* Long at end of image frame in the near swath (F16.7) */
          farslat,  /* Lat at start of image frame in the far swath (F16.7) */
          farslon,  /* Long at start of image frame in the far swath (F16.7) */
          farelat,  /* Lat at end of image frame in the far swath (F16.7) */
          farelon,  /* Long at end of image frame in the far swath (F16.7) */
          swazim,   /* Actual swath width (km) in azimuth direction (F16.7)*/
          swrange;  /* Actual swath width (km) in range direction (F16.7)*/
   int   npixels,   /* Actual (without filler) number of pixels per line(I8)*/
          nlines,    /* Actual (without filler) number of image lines (I8) */
          apixels,   /* Total (with filler) number of pixels per line (I8) */
          alines;    /* Total (with filler) number of image lines (I8) */
   char   mediaid[8],   /* Identification label of the media written to */
          sblock[18],   /* Location on the DCRSI where data begins */
          eblock[18],   /* Location on the DCRSI where data ends */
          platform[18], /* Name of platform for the sensor data was acquired */
          sensmode[34]; /* Sensor and mode of operation */
   double prfreq,   /* Pulse repitition frequency (F16.7) */
          antlook,  /* SAR antenna look angle (F16.7) */
          datarate, /* Data rate (F16.7) */
          datawin,  /* Data window position (F16.7) */
          rangegd,  /* Range gate delay (F16.7) */
          trackang; /* Track angle to True North (F16.7) */
   char   ascdesc[3];   /* Flag indicating whether the pass is asc/desc */
   double scalt,    /* Altitude of the spacecraft at the image center (F16.7)*/
          scxpos,   /* Spacecraft X-position at the image center (D22.15) */
          scypos,   /* Spacecraft Y-position at the image center (D22.15) */
          sczpos,   /* Spacecraft Z-position at the image center (D22.15) */
          scxvel,   /* Spacecraft X-velocity at the image center (D22.15) */
          scyvel,   /* Spacecraft Y-velocity at the image center (D22.15) */
          sczvel,   /* Spacecraft Z-velocity at the image center (D22.15) */
          scroll,   /* Spacecraft roll at the image center (E14.6) */
          scyaw,    /* Spacecraft yaw at the image center (E14.6) */
          scpitch;  /* Spacecraft pitch at the image center (E14.6) */
   int    qroll,     /* Quality flag for the spacecraft roll (I4) */
          qyaw,      /* Quality flag for the spacecraft yaw (I4) */
          qpitch;    /* Quality flag for the spacecraft pitch (I4) */
   double rroll,     /* Spacecraft roll rate at the image center (E14.6) */
          ryaw,      /* Spacecraft yaw rate at the image center (E14.6) */
          rpitch;    /* Spacecraft pitch rate at the image center (E14.6) */
   int    rqroll,    /* Quality flag for the spacecraft roll rate (I4) */
          rqyaw,     /* Quality flag for the spacecraft yaw rate (I4) */
          rqpitch;   /* Quality flag for the spacecraft pitch rate (I4) */
   double eradnadr,  /* Radius of the earth at nadir (F16.7) */
          eradcntr,  /* Radius of the earth at image center (F16.7) */
          incedang;  /* Incidence angle at the center of the image (F16.7) */
   char   procvers[9],  /* Version of the ASP (F7.2) */
          imgproct[4],  /* Image processing type identifier */
          ephemert[3];  /* Type of Ephemeris used identifier */
   double nlooksaz, /* Effective number of looks in azimuth (F16.7) */
          nlooksra, /* Effective number of looks in range (F16.7) */
          weightaz, /* Weighting pedestal height in azimuth (F16.7) */
          weightra; /* Weighting pedestal height in range (F16.7) */
   char   normener[5];  /* Look energy normalization flag */
   double indistaz, /* Known processing induced distortions in azimuth(F16.7)*/
          indistra, /* Known processing induced distortions in range (F16.7) */
          recgain,  /* Receiver gain (F16.7) */
          swathvel, /* Swath velocity (F16.7) */
          squintan, /* Squint angle (F16.7) */
          avgterht; /* Average terrain height above Geoid image center(F16.7)*/
   char   procgain[5],  /* Processor gain */
          deskewf[5],   /* Flag indicating whether Doppler Skew was removed */
          grndslnt[8];  /* Ground range / slant range flag */
   double sltrngfp, /* Slant range to the first image pixel (F16.7) */
          sltrnglp; /* Slant range to the last image pixel (F16.7) */
   int    strtsamp;  /* Start sample of signal data range line processed (I8)*/
   char   clttrlkf[5];  /* Flag indicating whether clutterlock was used */
   double dpplrfrq, /* Doppler frequency at the near range (F16.7)*/
          dpplrslp, /* Doppler frequency slope (F16.7)*/
          dpplrqdr; /* Doppler frequency quadratic term (F16.7)*/
   char   autfocsf[5];  /* Flag indicating whether autofocus was used */
   double dpplrrat, /* Doppler frequency rate at the near range (F16.7) */
          dpratslp, /* Doppler frequency rate slope (F16.7) */
          dpratqdr, /* Doppler frequency rate quadratic term (F16.7) */
          imresaz,  /* Nominal image resolution in azimuth (F16.7) */
          imresra,  /* Nominal image resolution in range (F16.7) */
          azpixspc, /* Pixel spacing in azimuth (F16.7) */
          rapixspc; /* Pixel spacing in range (F16.7) */
   char   rngcompf[5];  /* On-board range compression flag */
   int    bitssamp;  /* Bits per sample of the SAR signal data (I4) */
   double calestim, /* Calibrator estimate (F16.7) */
          biterrrt, /* Data transfer bit error rate (F16.7) */
          sigtonoi, /* Signal to noise ratio (F16.7) */
          estnoifl, /* Estimated noise floor (F16.7) */
          radiores; /* Radiometric resolution (F16.7) */
   int    nsatpnts;  /* Number of saturated points determined from hist (I8) */
   char   inspecf[5];   /* Flag to indicate whether image is within spec */

  /***** Values included in RADARSAT era CEOS structure ******/
  double  repl_agc;             /* chirp replica AGC value   */
  double  temp_rx_lna;          /* temp of rcvr LNA          */
  double  temp_rx_sub;          /* temp of rcvr subsystem    */
  double  temp_rx_prot;         /* temp of rcvr protector    */
  double  temp_cal_sys;         /* temp of calib system      */
  double  rx_agc;               /* rcvr AGC value            */
  double  pre_cal1_pow;         /* pre cal1 avg power        */
  double  pre_cal2_pow;         /* pre cal2 avg power        */
  double  post_cal1_pow;        /* post cal1 avg power       */
  double  post_cal2_pow;        /* post cal2 avg power       */
  double  repl_pow;             /* Replica avg power         */
  double  ssar_roll_ang;        /* est ScanSAR roll angle    */
  /***** Values included in RADARSAT era CEOS structure ******/

   char   comment[101];         /* comment field */
};

/* Map Projection Data Record - Value Structure */
struct VMPDREC {
  char    mpdesc[33];    /* Map projection descriptor */
  int     npixels,       /* number of pixels per line of image */
	  nlines;        /* number of lines in image */
  double  nomipd,        /* nominal inter-pixel distance in output (meters) */
	  nomild,        /* nominal inter-line distance in output (meters) */
	  orient,        /* Orientation at output scene center */
	  orbitincl,     /* Actual platform orbital inclination (degrees) */
	  ascnode,       /* Actual ascending node (degrees) */
	  distplat,      /* Distance of platform from geocenter (meters) */
	  altplat,       /* Altitude of platform rel. to ellipsoid (meters) */
	  velnadir,      /* Actual ground speed at nadir (m/s) */
	  plathead;      /* platform heading (degrees) */
  char    refelip[33];   /* Name of reference ellipsoid */
  double  remajor,       /* Semimajor axis of ref. ellipsoid (m) */
	  reminor,       /* Semiminor axis of ref. ellipsoid (m) */
	  datshiftx,     /* Datum shift parameter ref. to Greenwich dx (m) */
          datshifty,     /* datum shift perpendicular to Greenwich dy (m) */
	  datshiftz,     /* datum shift direction of rotation axis dz (m) */
	  datshift1,     /* 1st additional datum shift, rotation angle */
	  datshift2,     /* 2nd additional datum shift, rotation angle */
	  datshift3,     /* 3rd additional datum shift, rotation angle */
	  rescale;       /* Scale factor of referenced ellipsoid */
  char    mpdesig[33],   /* Alphanumeric description of map projection */
	  utmdesc[33],   /* UTM descriptor */
	  utmzone[5];    /* Signature of UTM Zone */
  double  utmeast,       /* Map origin - false easting */
	  utmnorth,      /* Map origin - false north */
	  utmlong,       /* Center of projection longitude (deg) */
	  utmlat,        /* Center of projection latitude (deg) */
	  utmpara1,      /* 1st standard parallel (deg) */
	  utmpara2,      /* 2nd standard parallel (deg) */
	  utmscale;      /* UTM scale factor */
  char    upsdesc[33];   /* UPS descriptor */
  double  upslong,       /* Center of projection longitude (deg) */
	  upslat,        /* Center of projection latitude (deg) */
	  upsscale;      /* UPS scale factor */
  char    nspdesc[33];   /* NSP projection description */
  double  nspeast,       /* Map origin - false east */
	  nspnorth,      /* Map origin - false north */
	  nsplong,       /* Center of projection longitude (deg) */
	  nsplat,        /* Center of projection latitude (deg) */
          nsppara1,      /* Standard parallels */
	  nsppara2,      /* Standard parallels */
	  nsppara3,      /* Standard parallels */
	  nsppara4,      /* Standard parallels */
	  nspcm1,        /* Central meridian */
	  nspcm2,        /* Central meridian */
	  nspcm3;        /* Central meridian */
  double  tlcnorth,      /* Top left corner north (m) */
	  tlceast,       /* Top left corner east (m) */
	  trcnorth,      /* Top right corner north (m) */
	  trceast,       /* Top right corner east (m) */
	  brcnorth,      /* Bottom right corner north (m) */
	  brceast,       /* Bottom right corner east (m) */
	  blcnorth,      /* Bottom left corner north (m) */
	  blceast,       /* Bottom left corner east (m) */
	  tlclat,        /* Top left corner latitude (deg) */
	  tlclong,       /* Top left corner longitude (deg) */
          trclat,        /* Top right corner lat (deg) */
	  trclong,       /* Top right corner int (deg) */
	  brclat,        /* Bottom right corner latitude (deg) */
	  brclong,       /* Bottom right corner longitude (deg) */
	  blclat,        /* Bottom left corner latitude (deg) */
	  blclong,       /* Bottom left corner longitude (deg) */
	  tlcheight,     /* Top left corner terrain height (m) */
	  trcheight,     /* Top right corner terrain height (m) */
	  brcheight,     /* Bottom right corner terrain height (m) */
	  blcheight,     /* Bottom left corner terrain height (m) */
	  a11,           /* 8 coeff. to convert a line (L) and pixel (p) */
	  a12,           /* position to the map projection frame of      */
	  a13,           /* reference, say (E,N) where:                  */
	  a14,           /*                                              */
	  a21,           /*  E=A11+A12+A13+A14TL                         */
	  a22,           /*  N=A21+A22+A23+A24+nP                        */
	  a23,           /*                                              */
	  a24,           /*                                              */
	  b11,           /* 8 coeff. to convert from the map projection  */
	  b12,           /* (E,N) to line (L) and pixel (P) position.    */
	  b13,           /*                                              */
	  b14,           /* L=B11+B12+B13+B14TETN                        */
	  b21,           /* P=B21+B22+B23+B24TN                          */
	  b22,           /*                                              */
	  b23,           /*                                              */
	  b24;           /*                                              */
};


/****************************
*                           *
*  SAR Leader File:         *
*  Data Set Summary Record  *
*                           *
****************************/

struct dataset_sum_rec {
    short  seq_num;              /* Data Set Summary: record sequence number */
    short  sar_chan;             /* SAR channel indicator */
    char   product_id[17];       /* site ID = product id */
    char   scene_des[33];        /* site name */
    char   inp_sctim[33];        /* image center GMT: YYYYMMDDhhmmssttt */
    char   asc_des[17];          /* Ascending/descending */
    double pro_lat;              /* latitude at scene center */
    double pro_long;             /* longitude at scene center */
    double pro_head;             /* Processed scene center heading */
    char   ellip_des[17];        /* ellipsoid designator */
    double ellip_maj;            /* ellipsoid semimajor axis (km) */
    double ellip_min;            /* ellipsoid semiminor axis (km) */
    double earth_mass;           /* Earth's mass */
    double grav_const;           /* Gravitational constant */
    double ellip_j[3];           /* Ellipsoid J2-4 parameters */

    /***** Value included in RADARSAT era CEOS structure ******/
    char  spare1[17];            /* spare */
    /***** Value included in RADARSAT era CEOS structure ******/

    double terrain_h;            /* average terrain height */
    double sc_lin;               /* image center line number (azimuth) */
    double sc_pix;               /* image center pixel number (range) */
    double scene_len;            /* image length in km */
    double scene_wid;            /* image width in km */
    char  spare2[17];            /* spare */
    short nchn;                  /* number of SAR channels */
    char  spare3[5];             /* spare */
    char  mission_id[17];        /* mission id */
    char  sensor_id[33];         /* sensor id: AAAAAA-BB-CCDD-EEFF */
    char  revolution[9];         /* orbit number */
    double plat_lat;             /* spacecraft latitude at nadir */
    double plat_long;            /* spacecraft longitude at nadir */
    double plat_head_scene;      /* sensor platform heading (degrees) */
    double clock_ang;            /* sensor clock angle rel to flight dir */
    double incident_ang;         /* incidence angle at image center */
    double frequency;            /* radar frequency (GHz) */
    double wave_length;          /* radar wavelength (m) */
    char  motion_comp[3];        /* motion compensation indicator */
    char  pulse_code[17];        /* range pulse code specifier */
    double ampl_coef[5];         /* range chirp coefficients */
    double phas_coef[5];         /* range phase coefficients */
    int  chirp_ext_ind;         /* chirp extraction index */
    char  spare4[9];             /* spare */
    double rng_samp_rate;        /* range complex sampling rate */
    double rng_gate;             /* range gate at early edge */
    double rng_length;           /* range pulse length */
    char  baseband_f[5];         /* base band conversion flag */
    char  rngcmp_f[5];           /* range compressed flag */
    double gn_polar;             /* receiver gain for like pol */
    double gn_cross;             /* receiver gain for cross pol */
    int  chn_bits;              /* quantization bits per channel */
    char  quant_desc[13];        /* quantizer description */
    double i_bias;               /* I channel DC bias */
    double q_bias;               /* Q channel DC bias */
    double iq_ratio;             /* I/Q channel ratio */
    double spare_dss_7;          /* spare */
    double spare_dss_8;          /* spare */
    double ele_sight;            /* electronic boresight */
    double mech_sight;           /* mechanical boresight */
    char   echo_track[5];        /* echo tracker flag */
    double prf;                  /* nominal PRF */
    double elev_beam;            /* antenna elevation 3dB beam width */
    double azi_beam;             /* antenna azimuth 3dB beam width */
    char   sat_bintim[17];       /* Satellite binary time */
    char   sat_clktim[33];       /* Satellite clock time */
    int   sat_clkinc;           /* Satellite clock increment */
    char   spare5[9];            /* spare */
    char   fac_id[17];           /* processing facility */
    char   sys_id[9];            /* processing system */
    char   ver_id[9];            /* processor version */
    char   fac_code[17];         /* facility process code */
    char   lev_code[17];         /* product code */
    char   product_type[33];     /* product type */
    char   algor_id[33];         /* processing algorithm */
    double n_azilok;             /* number of looks in azimuth */
    double n_rnglok;             /* number of looks in range */
    double bnd_azilok;           /* bandwidth per look in azimuth */
    double bnd_rnglok;           /* bandwidth per look in range */
    double bnd_azi;              /* processor bandwidth (azimuth) */
    double bnd_rng;              /* processor bandwidth (range) */
    char   azi_weight[33];       /* weighting function (azimuth) */
    char   rng_weight[33];       /* weighting function (range) */
    char   data_inpsrc[17];      /* data input source: HDDC id */
    double rng_res;              /* nominal resolution (range) */
    double azi_res;              /* nominal resolution (azimuth) */
    double radi_stretch[2];      /* radiometric stretch terms (bias, gain) */
    double alt_dopcen[3];        /* along track Doppler freq terms */
    char   spare6[17];           /* spare */
    double crt_dopcen[3];        /* cross track Doppler freq terms */
    char   time_dir_pix[9];      /* time direction (range) */
    char   time_dir_lin[9];      /* time direction (azimuth) */
    double alt_rate[3];          /* Aint track Doppler rate terms */
    char   spare7[17];           /* spare */
    double crt_rate[3];          /* Cross track Doppler rate terms */
    char   spare8[17];           /* spare */
    char   line_cont[9];         /* line content indicator */
    char   clutterlock_flg[5];   /* clutter lock flag */
    char   auto_focus[5];        /* autofocussing flag */
    double line_spacing;         /* line spacing (m) */
    double pixel_spacing;        /* pixel spacing (m) */
    char   rngcmp_desg[17];      /* range compression designator */

    /****** Values included in PRE RADARSAT era data files *****/
    char   spare9[273];          /* spare */
    int    annot_pts;            /* number of annotation points */
    int    spare10[9];           /* spare */
    int    annot_line[64];       /* Line number of annotation start */
    int    annot_pixel[64];      /* Pixel number of annotation start */
    char   annot_text[64][37];   /* Annotation text */
    char   spare11[26];          /* spare */
    /****** Values included in PRE RADARSAT era data files *****/

    /****** Values included in RADARSAT era data files *****/
    char   spare_dss_14[17];     /* spare */
    char   spare_dss_15[17];     /* spare */
    int    no_beams;             /* number of beams */
    char   beam1[5];             /* beam 1 identifier */
    char   beam2[5];             /* beam 2 identifier */
    char   beam3[5];             /* beam 3 identifier */
    char   beam4[5];             /* beam 4 identifier */
    float  prf1;                 /* PRF of beam 1 Hz */
    float  prf2;                 /* PRF of beam 2 Hz */
    float  prf3;                 /* PRF of beam 3 Hz */
    float  prf4;                 /* PRF of beam 4 Hz */
    float  rng_gate1;            /* range gate of beam 1 (usec) */
    float  rng_gate2;            /* range gate of beam 2 (usec) */
    float  rng_gate3;            /* range gate of beam 3 (usec) */
    float  rng_gate4;            /* range gate of beam 4 (usec) */
    int    tot_pls_burst;        /* total pulses per burst */
    int    val_pls_burst;        /* valid pulses per burst */
    int    az_ovlp_nxt_img;      /* Range lines overlap in azimuth with next */
    int    rg_off_nxt_img;       /* pixel of offset in range with next */
    char   cal_params_file[33];  /* calibration parameter file used */
    char   scan_results_file[33]; /* name of scan results file used */
    char   scanner_version[17];  /* version of the scanner used     */
    char   decode_version[17];   /* version of the decode used      */
    char   spare_dss_16[2130];   /* spare */
    /****** Values included in RADARSAT era data files *****/
};


/****************************
*                           *
*  SAR Leader File:         *
*  Platform Position Rec    *
*                           *
****************************/
struct pos_data_rec {
    short seq_num;              /* Platform Position: record sequence # */
    char  orbit_ele_desg[33];   /* Orbital elements designator          */
    double orbit_ele[6];        /* orbital elements                     */
    short  ndata;               /* number of data sets                  */
    short  year;                /* year of first data point             */
    short  month;               /* month of first data point            */
    short  day;                 /* day of first data point              */
    short  gmt_day;             /* day in year of first data point      */
    double gmt_sec;             /* seconds in day of first data point   */
    double data_int;            /* time interval between data points(s) */
    char  ref_coord[65];        /* reference coordinate system          */
    double hr_angle;            /* GMT hour angle (degrees)             */
    double alt_poserr;          /* Aint track position error           */
    double crt_poserr;          /* Cross track position error           */
    double rad_poserr;          /* radial position error                */
    double alt_velerr;          /* Aint track velocity error           */
    double crt_velerr;          /* Cross track velocity error           */
    double rad_velerr;          /* Radial velocity error                */
    double pos_vec[64][6];      /* Data point position/velocity         */
                                /* 0-2 position,  3-5  velocity         */
    char spare_ppr_1[243];      /* spare 				*/
};

/******************************************
*                                         *
*  SAR Leader File: Attitude Data Record  *
*                                         *
******************************************/

struct  att_vect_rec {
    short gmt_day;              /* day in the year (GMT) 	*/
    int  gmt_msec;             /* millisecond of the day (GMT) */
    short pitch_flag;           /* pitch data quality flag 	*/
    short roll_flag;            /* roll data quality flag 	*/
    short yaw_flag;             /* yaw data quality flag 	*/
    double pitch;               /* pitch (degrees) 		*/
    double roll;                /* roll (degrees) 		*/
    double yaw;                 /* yaw (degrees) 		*/
    short pitch_rate_flag;      /* pitch rate data quality flag */
    short roll_rate_flag;       /* roll rate data quality flag 	*/
    short yaw_rate_flag;        /* yaw rate data quality flag 	*/
    double pitch_rate;          /* pitch rate (degrees/sec) 	*/
    double roll_rate;           /* roll rate (degrees/sec) 	*/
    double yaw_rate;            /* yaw_rate (degrees/sec) 	*/
    struct att_vect_rec *next;  /* pointer to next data set 	*/
};

struct  att_data_rec {
    short npoint;               /* number of attitude data sets */
    struct att_vect_rec *data;  /* pointer to list of data sets */
    char spare_adr_1[641];      /* spare 			*/
};

/*********************************************
*                                            *
*  SAR Leader File: Radiometric Comp Record  *
*  Not in the ASF set for the Radarsat era   *
*                                            *
*********************************************/

struct Radio_Comp_Tbl {
    double sample_offset;       /* compensation sample offset */
    double sample_gain;         /* compensation sample gain */
    struct Radio_Comp_Tbl *next; /* link */
};

struct Rad_Comp_Set {
    char  comp_data_type[8];    /* compensation data type designator */
    char  data_descr[33];       /* data descriptor */
    short req_recs;             /* number of required records */
    short table_seq_num;        /* table sequence number */
    int  num_pairs;            /* total number of tables */
    int  first_pixel;          /* pixel corresponding to first correction */
    int  last_pixel;           /* pixel corresponding to last correction */
    int  pixel_size;           /* pixel group size (subsample factor) */
    double min_samp_index;      /* minimum sample index */
    double min_comp_value;      /* minimum radiometric compensation value */
    double max_samp_index;      /* maximum sample index */
    double max_comp_value;      /* maximum radiometric compensation value */
    char  spare_rcr_2[17];      /* spare */
    int  n_table_entries;      /* number of comp pairs */
    struct Radio_Comp_Tbl *tbl; /* pointer to linked list */
    struct Rad_Comp_Set *next;  /* pointer to next pol */
};

struct radi_comp_rec {
    short    seq_num;           /* radio comp record seq number */
    short    sar_chan;          /* sar channel indicator */
    int     n_dset;            /* number of data sets */
    int     dset_size;         /* data set size */
    char     spare_rcr_1[5];    /* padding for link list */
    struct Rad_Comp_Set  *set;  /* pointer to comp, dataset */
    struct radi_comp_rec *next; /* pointer to next radi. comp. record */
};

/*******************************************
*                                          *
*  SAR Leader File:  Data Quality Summary  *
*                                          *
*******************************************/

struct qual_sum_rec {
    short seq_num;              /* dqs record sequence number       */
    char  chan_ind[5];          /* sar channel indicator            */
    char  cali_date[7];         /* calibration date                 */
    short nchn;                 /* number of channels               */
    double islr;                /* integrated side lobe ratio       */
    double pslr;                /* peak side lobe ratio             */
    double azi_ambig;           /* azimuth ambiguity                */
    double rng_ambig;           /* range ambiguity  		    */
    double snr;                 /* signal-to-noise ratio estimate   */
    double ber;                 /* nominal bit error rate           */
    double rng_res;             /* nominal slant range resolution   */
    double azi_res;             /* nominal azimuth resolution       */
    double rad_res;             /* nominal radiometric resolution   */
    double dyn_rng;             /* instantaneous dynamic range      */
    double abs_rad_unc_db;      /* nominal abs. radiometric uncertainty, db  */
    double abs_rad_unc_deg;     /* nominal abs. radiometric uncertainty, deg */
    double rel_rad_unc[2][16];  /* rel short term radio calibr uncertainty   */
                                /* 16 pairs of values in db and deg */
    double alt_locerr;          /* location error along track       */
    double crt_locerr;          /* location error cross track       */
    double alt_scale;           /* along track scale error          */
    double crt_scale;           /* cross track scale error          */
    double dis_skew;            /* geometric skew error             */
    double ori_err;             /* image orientation error          */
    double misreg[2][16];       /* misregistration error: 16 pairs  */
				/* for along track and cross track  */

    /****** Value included in PRE RADARSAT era CEOS structure ******/
    char  spare2[279];          /* spare */
    /****** Value included in PRE RADARSAT era CEOS structure ******/

    /****** Value included in RADARSAT era CEOS structure **********/
    double nesz;                /* nominal noise equiv sigma zero  */
    double enl;                 /* Nominal equiv no of looks       */
    char  tb_update[9];         /* default param table update date */
    char  cal_status[17];	/* Calibration status of data      */
    char  spare3[23];           /* spare 			   */
    char  cal_comment[201];     /* Calibration comment field       */
    /****** Value included in RADARSAT era CEOS structure **********/
};


/****************************
*                           *
*  SAR Leader File:         *
* Data Histograms Record    *
*                           *
****************************/

struct hist_dset {
    char  hist_desc[33];       /* histogram descriptor 		*/
    short nrec;                /* required records 		*/
    short tab_seq;             /* table sequence number 	*/
    int  nbin;                /* table size, bytes 		*/
    int  ns_lin;              /* number of pixels in line 	*/
    int  ns_pix;              /* number of lines in image 	*/
    int  ngrp_lin;            /* pixels/group, cross track 	*/
    int  ngrp_pix;            /* pixels/group, along track 	*/
    int  nsamp_lin;           /* number of groups, cross track	*/
    int  nsamp_pix;           /* number of groups, along track */
    double min_smp;            /* minimum pixel value 		*/
    double max_smp;            /* maximum pixel value 		*/
    double mean_smp;           /* mean sample value 		*/
    double std_smp;            /* std deviation of sample value */
    double smp_inc;            /* sample value increment 	*/
    double min_hist;           /* minimum table value 		*/
    double max_hist;           /* maximum table value 		*/
    double mean_hist;          /* histogram mean value 		*/
    double std_hist;           /* histogram standard deviation  */
    int  nhist;               /* histogram table size 		*/
    int  *data_values_hist;   /* table values 1-256 		*/
    struct hist_dset *next;    /* pointer to next table set 	*/
};

struct data_hist_rec {
    short seq_num;             /* data histogram record seq no. */
    short sar_chan;            /* SAR channel  		 	*/
    int  ntab;                /* number of table sets 		*/
    int  ltab;                /* data set size 		*/
    struct hist_dset *data;    /* pointer to list of tables 	*/
};

/****************************
*                           *
*  SAR Leader File:         *
*  Range Spectra Record     *
*                           *
****************************/

struct rng_spec_rec {
    short seq_num;                /* range spectra sequence no. */
    short sar_chan;               /* SAR channel */
    int  n_dset;                 /* number of data sets */
    int  dset_size;              /* data set size */
    short req_recs;               /* number of records required */
    short table_no;               /* table sequence number */
    int  n_pixels;               /* number of pixels in line */
    int  pixel_offset;           /* offset from first pixel */
    int  n_lines;                /* number of lines integrated for spectra */
    double first_freq;            /* center freq of first spectra bin */
    double last_freq;             /* center freq of last spectra bin */
    double min_power;             /* minimum spectral power */
    double max_power;             /* maximum spectral power */
    char  spare_rsr_1[17];        /* spare */
    char  spare_rsr_2[17];        /* spare */
    int  n_bins;                 /* number of freq bins in table */
    double data_values_spec[256]; /* spectral data values 1-256 */
    char  spare_rsr_3[1053];      /* spare */
};

/****************************
*                           *
*  SAR Leader File:         *
*  Digital Elevation Record *
*                           *
****************************/

struct corner_pts_rec {
    float cp_lat_1;              /* polygon corner pt. latitude */
    float cp_lon_1;              /* polygon corner pt. longitude */
    struct corner_pts_rec *next; /* pointer to next corner point */
};

struct dem_desc_data {
    short poly_seq_num;         /* polygon sequence number */
    short num_crnr_pts;         /* Number of corner pts. for this record */
    char  spare_dem_1[9];       /* spare */
    struct corner_pts_rec* pts; /* pointer to corner pts/lat/int */
    struct dem_desc_data *next; /* pointer to next DEM data desc. data set */
};

struct dig_elev_rec {
    short seq_num;              /* sequence no. */
    int  ttl_num_sets;         /* total number of DEM datasets */
    short DEM_seq_num;          /* Sequence num. of this DEM descriptor */
    char  source_DEM[33];       /* Original src of DEM */
    char  HT_ref_name[33];      /* Height datum reference name */
    char  gen_method[33];       /* generation method */
    char  raster_unit[13];      /* raster spacing unit */
    char  presentation_proj[33];/* presentation projection */
    float NS_raster;            /* North/South raster spacing */
    float EW_raster;            /* East/West raster spacing */
    char  resample[33];         /* Applied resampling method */
    float height_err;           /* RMS height error */
    float NS_loc_err;           /* RMS location error North/South */
    float EW_loc_err;           /* RMS location error East/West */
    float max_height;           /* Max height */
    float min_height;           /* Min height */
    float MEAN_height;          /* MEAN height */
    float STD_height;           /* STD of height */
    short num_polys;            /* Number of polygons in record */
    struct dem_desc_data* set;  /* pointer to list of DEM desc data sets */
    char spare_dem_2[533];      /* spare */
};

/***************************************************
*                                                  *
*  SAR Leader File:  Detail Processing Parameters  *
*  As defined by CSA in their CDPF product specs   *
*  issue/rev = 3/0  date = apr22,1994              *
*                                                  *
***************************************************/

typedef struct beam_info_rec {
    char beam_type[4];          /* Beam type                            (a3) */
    char beam_look_src[10];     /* Elevation beam look angle source     (a9) */
    float beam_look_ang;        /* Applied elev beam look angle, deg (f16.7) */
    float prf;                  /* Actual PRF (Hz)                   (f16.7) */
    struct beam_info_rec *next; /* pointer to next beam info rec             */
} Beam_Info;

typedef struct pix_count_rec {
    char pix_update[22];        /* pixel count update time             (a21) */
    int n_pix[4];              /* count of image pixels in beams      (4i8) */
    struct pix_count_rec *next; /* pointer to next pix count rec             */
} Pix_Count;

typedef struct temp_rec {
    int temp_set[4];           /* temperature settings                (4i4) */
    struct temp_rec *next;      /* pointer to next temp rec                  */
} Temp_Rec;

typedef struct dopcen_est_rec {
    float dopcen_conf;          /* Doppler Centroid conf measure     (f16.7) */
    float dopcen_ref_tim;       /* Doppler Centroid ref time         (f16.7) */
    float dopcen_coef[4];       /* Doppler Centroid coefficients    (4f16.7) */
    struct dopcen_est_rec *next; /* pointer to next dopcen rec               */
} Dopcen_Est;

typedef struct srgr_coefset_rec {
    char srgr_update[22];       /* SRGR update date/time               (a21) */
    float srgr_coef[6];         /* SRGR coefficients                (6f16.7) */
    struct srgr_coefset_rec *next; /* pointer to next SRGR rec               */
} SRGR_Coefset;

struct proc_parm_rec {
    short seq_num;              /* record sequence no.                  (i4) */
    char spare_dpp_1[5];        /* spare                                (a4) */
    char inp_media[4];          /* Input media                          (a3) */
    short n_tape_id;            /* Number of input tape id              (i4) */
    char tape_id[10][9];        /* tape identifier                    (10a8) */
    char exp_ing_start[22];     /* Expected ingest start time          (a21) */
    char exp_ing_stop[22];      /* Expected ingest stop time           (a21) */
    char act_ing_start[22];     /* Actual ingest start time            (a21) */
    char act_ing_stop[22];      /* Actual ingest stop time             (a21) */
    char proc_start[22];        /* Processing start time               (a21) */
    char proc_stop[22];         /* Processing stop time                (a21) */
    float mn_sig_lev[10];       /* Mean signal levels across range (10f16.7) */
    short src_data_ind;         /* Source data quality indicator        (i4) */
    int miss_ln;               /* Number of missing lines              (i8) */
    int rej_ln;                /* Number of rejected lines             (i8) */
    int large_gap;             /* Number of time inconsistencies       (i8) */
    float bit_error_rate;       /* Measured bit error rate           (f16.7) */
    float fm_crc_err;           /* Percent of frames with CRC errors (f16.7) */
    int date_incons;           /* Number of date inconsistencies       (i8) */
    int prf_changes;           /* Number of unexpected PRF changes     (i8) */
    int delay_changes;         /* Number of delay changes              (i8) */
    int skipd_frams;           /* Number of skippped frames            (i8) */
    int rej_bf_start;          /* Rng lines reject before start time   (i8) */
    int rej_few_fram;          /* Rng lines reject: too few frames     (i8) */
    int rej_many_fram;         /* Rng lines reject: too many frames    (i8) */
    int rej_mchn_err;          /* Frames reject: master ch err         (i8) */
    int rej_vchn_err;          /* Frames reject: virtual ch err        (i8) */
    int rej_rec_type;          /* Frames reject: rec type err          (i8) */
    int prd_qual_ind;          /* Product quality index                (i4) */
    char qc_rating[7];          /* Quality control rating               (a6) */
    char qc_comment[81];        /* Quality control comment             (a80) */
    char sens_config[11];       /* Sensor configuration                (a10) */
    char sens_orient[10];       /* Sensor orientation                   (a9) */
    char sych_marker[9];        /* Frame synch marker                   (a8) */
    char rng_ref_src[13];       /* Range ref function source           (a12) */
    float rng_amp_coef[4];      /* Range ref ampl coeff             (4f16.7) */
    float rng_phas_coef[4];     /* Range ref phase coeff            (4f16.7) */
    float err_amp_coef[4];      /* Error function ampl coeff        (4f16.7) */
    float err_phas_coef[4];     /* Error function phase coeff       (4f16.7) */
    int pulse_bandw;           /* Pulse bandwidth code                 (i4) */
    char adc_samp_rate[6];      /* ADC sampling rate                    (a5) */
    float rep_agc_attn;         /* Replica AGC attenuation           (f16.7) */
    float gn_corctn_fctr;       /* Gain correction factor (dB)       (f16.7) */
    float rep_energy_gn;        /* Replica energy gain correction    (f16.7) */
    char orb_data_src[12];      /* Orbit data source                   (a11) */
    int pulse_cnt_1;           /* Pulse count 1                        (i4) */
    int pulse_cnt_2;           /* Pulse count 2                        (i4) */
    char beam_edge_rqd[4];      /* Beam edge detection requested        (a3) */
    float beam_edge_conf;       /* Beam edge confidence measure      (f16.7) */
    int pix_overlap;           /* Number of pixels in beam overlap     (i4) */
    int n_beams;               /* Number of beams                      (i4) */
    Beam_Info* beam_info;       /* Beam info               (repeats 4 times) */
    int n_pix_updates;         /* Number of pixel count updates        (i4) */
    Pix_Count* pix_count;       /* Beam pixel count       (repeats 20 times) */
    float pwin_start;           /* Processing window start time, sec (f16.7) */
    float pwin_end;             /* Processing window end time, sec   (f16.7) */
    char recd_type[9];          /* Recording type                       (a9) */
    float temp_set_inc;         /* Time increment btwn temp set, sec (f16.7) */
    int n_temp_set;            /* Number of temp settings              (i4) */
    Temp_Rec* temp;             /* Temperature settings   (repeats 20 times) */
    int n_image_pix;           /* Number of image pixels               (i8) */
    float prc_zero_pix;         /* Percent zero pixels               (f16.7) */
    float prc_satur_pix;        /* Percent saturated pixels          (f16.7) */
    float img_hist_mean;        /* Image histogram mean intensity    (f16.7) */
    float img_cumu_dist[3];     /* Image cumulative distribution    (3f16.7) */
    float pre_img_gn;           /* Pre-image calibration gain factor (f16.7) */
    float post_img_gn;          /* Post-image calibration gain factor(f16.7) */
    float dopcen_inc;           /* Time inc btwn Doppler Cen est, sec(f16.7) */
    int n_dopcen;              /* Number of Doppler Centroid est       (i4) */
    Dopcen_Est* dopcen_est;     /* Doppler Centroid rec   (repeats 20 times) */
    int dopamb_err;            /* Doppler ambiguity error              (i4) */
    float dopamb_conf;          /* Doppler ambiguity confidence meas.(f16.7) */
    float eph_orb_data[7];      /* Ephemeris orbit data             (7f16.7) */
    char appl_type[13];         /* Application type                    (a12) */
    double first_lntim;         /* Slow time of first image line    (d22.15) */
    double lntim_inc;           /* time inc btwn image lines        (d22.15) */
    int n_srgr;                /* Number of SRGR coeff sets            (i4) */
    SRGR_Coefset* srgr_coefset; /* SRGR coeff set         (repeats 20 times) */
    float pixel_spacing;        /* SGF product pixel spacing         (f16.7) */
    char pics_reqd[4];          /* GICS product required                (a3) */
    char wo_number[9];          /* Work order identifier                (a8) */
    char wo_date[21];           /* Work order entry date               (a20) */
    char satellite_id[11];      /* Satellite identifier                (a10) */
    char user_id[21];           /* User id                             (a20) */
    char complete_msg[4];       /* Completion message required flag     (a3) */
    char scene_id[16];          /* SGF product scene identifier        (a15) */
    char density_in[5];         /* Density of SGF product media         (a4) */
    char media_id[9];           /* SGF product identifer                (a8) */
    float angle_first;          /* Incidence angle of first pixel    (f16.7) */
    float angle_last;           /* Incidence angle of last pixel     (f16.7) */
    char prod_type[4];          /* GICS output product type             (a3) */
    char map_system[17];        /* Map system identifier               (a16) */
    double centre_lat;          /* GICS output, centre latitude     (d22.15) */
    double centre_long;         /* GICS output, centre longitude    (d22.15) */
    double span_x;              /* GICS output, size eastings, km   (d22.15) */
    double span_y;              /* GICS output, size northings, km  (d22.15) */
    char apply_dtm[4];          /* DTM correction to be applied flag    (a3) */
    char density_out[5];        /* GICS output product density          (a4) */
    char spare_dpp_2[248];      /* unused                             (a247) */
    struct proc_parm_rec *next; /* pointer to next detail proc parm record   */
};



/*Prototypes for converting character buffers to records, and back again.*/
typedef enum {toASCII,fromASCII} codingDir;
void   Code_FDR_common(unsigned char *bf, struct FDR* q,codingDir dir);
void   Code_FDR(unsigned char *bf, struct FDR* q,codingDir dir);
void   Code_IOF(unsigned char *bf, struct IOF_VFDR* q,codingDir dir);
void   Code_MPDR(unsigned char *bf, struct VMPDREC* q,codingDir dir);
void   Code_DSSR(unsigned char *bf,struct dataset_sum_rec *q,int era, codingDir dir);
void   Code_PPDR (unsigned char *bf, struct pos_data_rec* q, codingDir dir);
void   Code_ATDR(unsigned char *bf, struct att_data_rec *q, codingDir dir);
int    Code_ATVR(unsigned char *bf, struct att_vect_rec *q, codingDir dir);
void   Code_RADDR(unsigned char *bf, struct VRADDR* q,codingDir dir);
void   Code_DQS(unsigned char* bf,struct qual_sum_rec* q,int era,codingDir dir);
void   Code_DHR(unsigned char* bf, struct data_hist_rec* q, codingDir dir);
void   Code_DH(unsigned char *bf, struct hist_dset* q, codingDir dir);
void   Code_RSR(unsigned char *bf, struct rng_spec_rec *q, codingDir dir);
void   Code_FACDR(unsigned char *bf, struct VFDRECV *q, int era, codingDir dir);

int set_era(const char *inbasename,char *outldrname,int operation);

/*Easier-to-use prototypes for fetching a single record from a CEOS file.*/
int get_atdr(char *filename,struct att_data_rec *rec);
int get_dhr(char *filename,struct data_hist_rec *rec);
int get_sdhr(char *filename,struct data_hist_rec *rec);
int get_dqsr(char *filename,struct qual_sum_rec *rec);
int get_dssr(char *filename,struct dataset_sum_rec *rec);
int get_facdr(char *filename,struct VFDRECV *rec);
int get_mpdr(char *filename,struct VMPDREC *rec);
int get_ppdr(char *filename,struct pos_data_rec *rec);
int get_raddr(char *filename,struct VRADDR *rec);
int get_rsr(char *filename,struct rng_spec_rec *rec);
int get_ifiledr(char *filename,struct IOF_VFDR *vfdr);

#endif /* end of ceos.h */
