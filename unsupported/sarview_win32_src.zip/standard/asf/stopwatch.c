/****************************************************************
FUNCTION NAME: StartWatch()  & StopWatch()

SYNTAX: void StartWatch();
	void StopWatch();

PARAMETERS:
    NAME:	TYPE:		PURPOSE:
    --------------------------------------------------------

DESCRIPTION:
    Keeps track of when a program starts and stops. Stopwatch will print out
    the elapsed time.

RETURN VALUE:
    None.

SPECIAL CONSIDERATIONS:

PROGRAM HISTORY:
     1.0 - Mike Shindle    4/96  Original Creation
****************************************************************/
#include "asf.h"

#if defined(__MWERKS__)||defined(WIN32)
/*Win32 or Mac systems use this*/
#include <time.h>
	clock_t startTime;

	void StartWatch()
	{
	  startTime=clock();
	}

	void StopWatch()
	{
	  float elapsed;
	  clock_t stopTime=clock();
	  elapsed = stopTime-startTime;
	  elapsed/=CLOCKS_PER_SEC;
	  printf("Total wall clock time = %f seconds.\n\n",elapsed);
	}

#else
#include <sys/time.h>
/* This half for running under UNiX */
	struct timeval tp1;

	void StartWatch()
	{
	  struct timezone tzp1;

	  gettimeofday(&tp1,&tzp1);
	}

	void StopWatch()
	{
	  long elapsed;
	  struct timeval tp2;
	  struct timezone tzp2;

	  gettimeofday(&tp2,&tzp2);
	  elapsed = tp2.tv_sec - tp1.tv_sec;
	  printf("Total wall clock time = %li seconds.\n\n",elapsed);
	}
#endif

