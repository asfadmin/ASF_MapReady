#include "asf.h"



#include "asf_meta.h"

baseline read_baseline(char *fName)
{
	baseline b;
	FILE *fbase;
	fbase = FOPEN(fName,"r");
	printf("Reading in baseline values from '%s'...\n",fName);
	if (4!=fscanf(fbase, "%lf %lf %lf %lf", &b.Bn, &b.dBn,
									 &b.Bp, &b.dBp))
	{
		printf("Error! Couldn't read 4 baseline components\n"
			"from baseline file named '%s'!\n",fName);
		exit(1);
	}
	if (1!=fscanf(fbase,"%lf",&b.temporal))
	{
		printf("Assuming 1-day temporal baseline...\n");
		b.temporal=1.0;
	}
	fclose(fbase);
	printf(" Baselines:\n\tNormal: %f, delta: %f\n",b.Bn,b.dBn);
	printf("\tParallel: %f, delta: %f\n",b.Bp,b.dBp);
	printf("\tTemporal: %f days\n",b.temporal);
	return b;
}
