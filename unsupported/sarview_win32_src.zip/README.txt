SARview SOURCE Readme File: 6/21/1999

This is the Visual C++ 6.0 source code & project
files for SARview and its supporting libraries.

This is a program from the ASF-STEP lab called
SARview.  It can be used to view, zoom, extract
info from, and export LAS and CEOS images.

To use it, open the "bin" directory and open
"sarview.exe".  Then choose "Open..." from
the "File" menu and open "Welcome.img" or
any other LAS or CEOS image.  SARview also
supports drag-and-drop-- just drag a .img
or .D file onto "sarview.exe" to view the
image.

Orion Sky Lawlor
Win32 ASF-STEP Tools
contact Rick Guritz, rguritz@images.alaska.edu 
or visit http://www.images.alaska.edu/
