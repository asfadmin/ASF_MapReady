/*cproc_hist.c:
	Implements Tcl/Tk-callable histogram routines in C.
These are called by the "routing" routines in tkCommand.c.
*/
#include "main.h"
#include "image.h"

void cproc_renderhist(int width,int height,double *maxHt)/* TCL asks C to render 
	the image histogram into img_hist.*/
{

#if defined(lil_endian)
	Tk_PhotoImageBlock block={NULL,-1,-1,-1,-1, {2,1,0}};
#elif defined(big_endian)
	Tk_PhotoImageBlock block={NULL,-1,-1,-1,-1, {sizeof(int)-3,sizeof(int)-2,sizeof(int)-1}};
#else
#   error "You must define either lil_endian or big_endian!"
#endif
	Tk_PhotoImageBlock *blockPtr=&block;
	Tk_PhotoHandle hPhoto=Tk_FindPhoto(interp,"img_hist");
	
	int *dest=(int *)MALLOC(sizeof(int)*width*height);

	/*Compute histogram, staying within the current selection*/
	histogram *h=createHist(2048,image.min,image.max);
	int selWid,selHt;
	selection *s=selBounds(&selWid,&selHt);
	float *inBuf=(float *)MALLOC(sizeof(float)*selWid);
	float *selBuf=(float *)MALLOC(sizeof(float)*selWid);/*Contains just the selected pixels from inBuf*/
	float nonSelectedPixel=-1001234.567;/*A floating-point value to designate non-selected areas*/
	int x,y;
	for (y=0;y<selHt;y++)
	{
		int numSelected=0;
		selLine(s,0,y,inBuf,nonSelectedPixel);
		for (x=0;x<selWid;x++)
			if (inBuf[x]!=nonSelectedPixel)
				selBuf[numSelected++]=inBuf[x];
		addToHist(h,selBuf,numSelected);
	}
	deleteSel(s);
	FREE(inBuf);
	FREE(selBuf);

	/*Render histogram into "dest" buffer (black & white)*/
	renderHist(h,image.min,image.max,maxHt,0x00000000,0x00FFffFF,dest,width,height);
	
	/*Tell TCL about the block of pixels we'll be feeding it*/
	blockPtr->pixelPtr=(unsigned char *)dest;
	blockPtr->width=width;
	blockPtr->height=height;
	blockPtr->pitch=sizeof(int)*width;
	blockPtr->pixelSize=sizeof(int);

	/*Feed TCL with pixels*/
	Tk_PhotoPutBlock(hPhoto, blockPtr, 0,0, width, height);

	deleteHist(h);
	FREE(dest);
}
